with open('app/src/main/java/com/example/ui/components/HeaderSection.kt', 'r', encoding='utf-8') as f:
    c = f.read()

old_cond = """                val isConnected =
                    (shellState.mode == ShellMode.SHIZUKU && shellState.isShizukuPermissionGranted) ||
                        (shellState.mode == ShellMode.WIRELESS_ADB && shellState.isWirelessAdbConnected) ||
                        (shellState.mode == ShellMode.ROOT && shellState.isRootAvailable)"""

new_cond = """                val isConnected =
                    (shellState.mode == ShellMode.SHIZUKU && shellState.isShizukuRunning && shellState.isShizukuPermissionGranted) ||
                        (shellState.mode == ShellMode.WIRELESS_ADB && shellState.isWirelessAdbConnected) ||
                        (shellState.mode == ShellMode.ROOT && shellState.isRootAvailable)"""

if old_cond in c:
    c = c.replace(old_cond, new_cond)
    with open('app/src/main/java/com/example/ui/components/HeaderSection.kt', 'w', encoding='utf-8') as f:
        f.write(c)
    print("Updated HeaderSection.kt successfully!")
else:
    print("HeaderSection condition not found!")
