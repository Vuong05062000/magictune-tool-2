with open('app/src/main/java/com/example/core/shell/ShellEngine.kt', 'r', encoding='utf-8') as f:
    c = f.read()

old_adb_ready = """    val isAdbReady: Boolean
        get() =
            (mode == ShellMode.SHIZUKU && isShizukuPermissionGranted) ||
                (mode == ShellMode.WIRELESS_ADB && isWirelessAdbConnected) ||
                (mode == ShellMode.ROOT && isRootAvailable) ||
                hasPersistentGrant"""

new_adb_ready = """    val isAdbReady: Boolean
        get() =
            (mode == ShellMode.SHIZUKU && isShizukuRunning && isShizukuPermissionGranted) ||
                (mode == ShellMode.WIRELESS_ADB && isWirelessAdbConnected) ||
                (mode == ShellMode.ROOT && isRootAvailable)"""

if old_adb_ready in c:
    c = c.replace(old_adb_ready, new_adb_ready)
    with open('app/src/main/java/com/example/core/shell/ShellEngine.kt', 'w', encoding='utf-8') as f:
        f.write(c)
    print("Updated ShellEngine.kt isAdbReady successfully!")
else:
    print("old_adb_ready not found in ShellEngine.kt")
