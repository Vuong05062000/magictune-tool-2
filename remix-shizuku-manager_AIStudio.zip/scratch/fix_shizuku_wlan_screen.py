with open('app/src/main/java/com/example/ui/components/ShizukuWlanScreen.kt', 'r', encoding='utf-8') as f:
    c = f.read()

# Replace condition 1: Overview Card border
old_border = "border(1.dp, if (shizukuInfo.isPermissionGranted) MagicEmerald else MagicAmber, RoundedCornerShape(12.dp))"
new_border = "border(1.dp, if (shizukuInfo.isRunning && shizukuInfo.isPermissionGranted) MagicEmerald else MagicAmber, RoundedCornerShape(12.dp))"
c = c.replace(old_border, new_border)

# Replace condition 2: Status text
old_text = 'text = if (shizukuInfo.isPermissionGranted) "✅ ĐÃ GHÉP NỐI THÀNH CÔNG VỚI SHIZUKU (UID 2000)" else "⚠️ CHƯA KẾT NỐI SHIZUKU",'
new_text = 'text = if (shizukuInfo.isRunning && shizukuInfo.isPermissionGranted) "✅ ĐÃ KẾT NỐI SHIZUKU THÀNH CÔNG (UID 2000)" else if (shizukuInfo.isRunning) "⚠️ SHIZUKU ĐANG CHẠY - CẦN CẤP QUYỀN" else "⚠️ SHIZUKU CHƯA KHỞI CHẠY",'
c = c.replace(old_text, new_text)

# Replace condition 3: Status color
old_color = 'color = if (shizukuInfo.isPermissionGranted) MagicEmerald else MagicAmber,'
new_color = 'color = if (shizukuInfo.isRunning && shizukuInfo.isPermissionGranted) MagicEmerald else MagicAmber,'
c = c.replace(old_color, new_color)

# Replace condition 4: Description text
old_desc = 'text = if (shizukuInfo.isPermissionGranted) "Tất cả tính năng mod nâng cao, gỡ bloatware và in hóa đơn K80 đang hoạt động hoàn hảo." else "Vui lòng làm theo 3 bước bên dưới để kích hoạt kết nối Shizuku.",'
new_desc = 'text = if (shizukuInfo.isRunning && shizukuInfo.isPermissionGranted) "Tất cả tính năng mod nâng cao, gỡ bloatware và in hóa đơn K80 đang hoạt động hoàn hảo." else if (shizukuInfo.isRunning) "Vui lòng bấm nút số 3 bên dưới để cấp quyền cho MagicTune." else "Vui lòng mở Shizuku và bấm Bắt đầu (qua Ghép nối wifi) để chạy dịch vụ.",'
c = c.replace(old_desc, new_desc)

# Replace condition 5: Button 3 text
old_btn = 'text = if (shizukuInfo.isPermissionGranted) "✓ ĐÃ CẤP QUYỀN SHIZUKU (UID 2000)" else "3. CẤP QUYỀN SHIZUKU NGAY",'
new_btn = 'text = if (shizukuInfo.isRunning && shizukuInfo.isPermissionGranted) "✓ ĐÃ CẤP QUYỀN SHIZUKU (UID 2000)" else if (shizukuInfo.isRunning) "3. CẤP QUYỀN SHIZUKU NGAY" else "3. CẦN BẬT SHIZUKU TRƯỚC",'
c = c.replace(old_btn, new_btn)

# Replace badge at top: KẾT NỐI DUY NHẤT: SHIZUKU (UID 2000)
old_badge = """                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(MagicEmerald.copy(alpha = 0.2f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "KẾT NỐI DUY NHẤT: SHIZUKU (UID 2000)",
                        color = MagicEmerald,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Black
                    )
                }"""

new_badge = """                val isLiveReady = shizukuInfo.isRunning && shizukuInfo.isPermissionGranted
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isLiveReady) MagicEmerald.copy(alpha = 0.2f) else MagicAmber.copy(alpha = 0.2f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (isLiveReady) "TRẠNG THÁI: SHIZUKU HOẠT ĐỘNG (UID 2000)" else "TRẠNG THÁI: SHIZUKU CHƯA KẾT NỐI",
                        color = if (isLiveReady) MagicEmerald else MagicAmber,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Black
                    )
                }"""
c = c.replace(old_badge, new_badge)

with open('app/src/main/java/com/example/ui/components/ShizukuWlanScreen.kt', 'w', encoding='utf-8') as f:
    f.write(c)

print('Updated ShizukuWlanScreen.kt successfully!')
