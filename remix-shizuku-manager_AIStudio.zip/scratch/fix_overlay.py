with open('app/src/main/java/com/example/ui/components/FloatingAutomationOverlay.kt', 'r', encoding='utf-8') as f:
    lines = f.readlines()

new_lines = []
skip = False
for i, line in enumerate(lines):
    if 'Row(verticalAlignment = Alignment.CenterVertically) {' in line and i > 220 and i < 230:
        new_lines.append('                                Icon(\n')
        new_lines.append('                                    imageVector = Icons.Default.Close,\n')
        new_lines.append('                                    contentDescription = "Dong",\n')
        new_lines.append('                                    tint = Color.White,\n')
        new_lines.append('                                    modifier = Modifier.size(13.dp)\n')
        new_lines.append('                                )\n')
        skip = True
    elif skip:
        if line.strip() == '}' and lines[i+1].strip() == '}':
            skip = False
        continue
    else:
        new_lines.append(line)

with open('app/src/main/java/com/example/ui/components/FloatingAutomationOverlay.kt', 'w', encoding='utf-8') as f:
    f.writelines(new_lines)
print("Updated FloatingAutomationOverlay.kt successfully")
