with open('app/src/main/java/com/example/ui/components/TerminalBottomSheet.kt', 'r', encoding='utf-8') as f:
    c = f.read()

# Add import if needed
if 'import androidx.compose.foundation.layout.defaultMinSize' not in c:
    c = c.replace('import androidx.compose.foundation.layout.Box\n', 'import androidx.compose.foundation.layout.Box\nimport androidx.compose.foundation.layout.defaultMinSize\n')

# Replace .height(48.dp) with .defaultMinSize(minHeight = 52.dp)
c = c.replace('.height(48.dp),\n                        shape = RoundedCornerShape(10.dp),', '.defaultMinSize(minHeight = 52.dp),\n                        shape = RoundedCornerShape(10.dp),')

# Also adjust Send button Box size to 52.dp so it matches the input height
c = c.replace('modifier = Modifier\n                            .size(48.dp)\n                            .clip(RoundedCornerShape(10.dp))\n                            .background(MagicCyan)', 'modifier = Modifier\n                            .size(52.dp)\n                            .clip(RoundedCornerShape(10.dp))\n                            .background(MagicCyan)')

with open('app/src/main/java/com/example/ui/components/TerminalBottomSheet.kt', 'w', encoding='utf-8') as f:
    f.write(c)

print('Updated TerminalBottomSheet.kt successfully')
