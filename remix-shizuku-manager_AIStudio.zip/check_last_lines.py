with open('E:/remix-shizuku-manager/app/src/main/java/com/example/ui/components/TuneScreen.kt', 'r', encoding='utf-8') as f:
    lines = f.readlines()

print("File total lines:", len(lines))
for i in range(len(lines)-15, len(lines)):
    print(f"{i+1}: {repr(lines[i])}")
