with open('E:/remix-shizuku-manager/app/src/main/java/com/example/ui/components/TuneScreen.kt', 'r', encoding='utf-8') as f:
    lines = f.readlines()

stack = []
for i in range(698, 2182):
    for char in lines[i]:
        if char == '{':
            stack.append((i+1, lines[i].strip()))
        elif char == '}':
            if stack:
                s_line, s_text = stack.pop()
                if "Card(" in s_text or s_line in [699, 715]:
                    print(f"Closed {s_line} at {i+1}")

print(f"Remaining in 698-2182: {len(stack)}")
for s in stack:
    print(f"Unclosed: line {s[0]} -> {s[1][:50]}")
