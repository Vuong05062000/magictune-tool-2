with open('E:/remix-shizuku-manager/app/src/main/java/com/example/ui/components/TuneScreen.kt', 'r', encoding='utf-8') as f:
    text = f.read()

import re

# Find any offset or negative paddings or absolute alignments
matches = re.findall(r'(\.offset|\.absoluteOffset|Arrangement\.spacedBy\(-|padding\(-)', text)
print("Negative/offset:", matches)

# Check Box with align modifier
aligns = re.findall(r'Modifier[^\n]*\.align\([^\)]+\)', text)
print("Aligns in TuneScreen:", len(aligns))
for a in aligns[:10]:
    print(" -", a)
