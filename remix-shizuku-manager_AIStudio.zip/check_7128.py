with open('E:/remix-shizuku-manager/app/src/main/java/com/example/ui/components/TuneScreen.kt', 'r', encoding='utf-8') as f:
    lines = f.readlines()

stack = []
for i, line in enumerate(lines):
    for char in line:
        if char == '{':
            stack.append(i+1)
        elif char == '}':
            if stack:
                start_l = stack.pop()
                if i+1 in [7128, 7129]:
                    print(f"Line {i+1} closes brace opened at {start_l}: {lines[start_l-1].strip()[:60]}")
