with open('E:/remix-shizuku-manager/app/src/main/java/com/example/ui/components/TuneScreen.kt', 'r', encoding='utf-8') as f:
    lines = f.readlines()

for idx in range(1380, 1405):
    print(f"{idx+1}: {repr(lines[idx])}")
