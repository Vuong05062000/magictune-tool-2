with open('E:/remix-shizuku-manager/app/src/main/java/com/example/ui/components/TuneScreen.kt', 'r', encoding='utf-8') as f:
    lines = f.readlines()

stack = []
for i, line in enumerate(lines):
    # simple tokenization for { and }
    idx = 0
    while idx < len(line):
        char = line[idx]
        if char == '{':
            stack.append((i+1, line.strip()))
        elif char == '}':
            if stack:
                start_l, start_t = stack.pop()
                if "CollapsibleSectionHeader" in start_t:
                    print(f"Header opened at {start_l} -> closed at {i+1}")
        idx += 1
