with open('E:/remix-shizuku-manager/app/src/main/java/com/example/ui/components/TuneScreen.kt', 'r', encoding='utf-8') as f:
    lines = f.readlines()

stack = []
for i in range(698, 2180): # from Card at 699 to end of Group 1
    for char in lines[i]:
        if char == '{':
            stack.append(i+1)
        elif char == '}':
            if stack:
                stack.pop()
            else:
                print(f"Extra close at {i+1}")

print(f"Group 1 unclosed braces: {len(stack)}")
for s in stack:
    print(f"Unclosed opened at {s}: {lines[s-1].strip()[:40]}")
