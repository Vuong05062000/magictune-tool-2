import glob

files = glob.glob('E:/remix-shizuku-manager/app/src/main/java/**/*.kt', recursive=True)
for f in files:
    try:
        with open(f, 'r', encoding='utf-8') as fl:
            content = fl.read()
            if 'đa năng' in content or 'ngầm đa năng' in content:
                print(f"Match in: {f}")
    except Exception as e:
        pass
