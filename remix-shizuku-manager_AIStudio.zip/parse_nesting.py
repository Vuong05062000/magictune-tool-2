with open('E:/remix-shizuku-manager/app/src/main/java/com/example/ui/components/TuneScreen.kt', 'r', encoding='utf-8') as f:
    text = f.read()

lines = text.splitlines()

stack = []
for i, line in enumerate(lines):
    for char in line:
        if char == '{':
            stack.append((i+1, line.strip()))
        elif char == '}':
            if stack:
                start_line, start_text = stack.pop()
                if "CollapsibleSectionHeader(" in start_text or "TuneScreen(" in start_text or "Column(" in start_text:
                    print(f"Closed block: opened at {start_line} [{start_text[:30]}], closed at {i+1}")
            else:
                print(f"Extra closing brace at {i+1}")

print(f"Remaining open braces: {len(stack)}")
for s in stack:
    print("Unclosed:", s)
