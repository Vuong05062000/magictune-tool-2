# ProGuard / R8 rules for MagicTune Commercial Release (Shizuku + Direct WLAN ADB + System Reflection)
-keep class rikka.shizuku.** { *; }
-keep interface rikka.shizuku.** { *; }
-keep class moe.shizuku.** { *; }
-keep interface moe.shizuku.** { *; }
-keepclassmembers class rikka.shizuku.Shizuku {
    private static *** newProcess(...);
    <methods>;
    <fields>;
}
-dontwarn rikka.shizuku.**
-dontwarn moe.shizuku.**

# Direct WLAN ADB (libadb-android, sun-security-android X.509, Conscrypt TLS 1.3 / SPAKE2)
-keep class io.github.muntashirakon.adb.** { *; }
-keep interface io.github.muntashirakon.adb.** { *; }
-keep class android.sun.security.** { *; }
-keep class org.conscrypt.** { *; }
-dontwarn io.github.muntashirakon.adb.**
-dontwarn android.sun.security.**
-dontwarn org.conscrypt.**

# Keep MagicTune core & data models
-keep class com.example.data.** { *; }
-keep class com.example.core.** { *; }
-keep class com.example.ui.** { *; }

# Firebase
-keep class com.google.firebase.** { *; }
-dontwarn com.google.firebase.**


