package com.example

import com.example.core.adb.AdbNsdState
import com.example.core.adb.DirectAdbManager
import com.example.core.shell.ShellEngineState
import com.example.core.shell.ShellMode
import com.example.core.shell.ShellResult
import com.example.data.APP_VERSION_NAME
import io.github.muntashirakon.adb.AbsAdbConnectionManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
class ExampleRobolectricTest {

    @Test
    fun `check app version badge and NSD state logic`() {
        assertEquals("v2.5", APP_VERSION_NAME)

        val nsdIdle = AdbNsdState()
        assertFalse(nsdIdle.isScanning)
        assertEquals(null, nsdIdle.pairingPort)
        assertEquals(null, nsdIdle.connectPort)

        val nsdDiscovered = AdbNsdState(
            isScanning = true,
            pairingPort = 38491,
            pairingHost = "127.0.0.1",
            connectPort = 41555,
            connectHost = "127.0.0.1",
            statusText = "Đã bắt được cổng Ghép nối: 38491"
        )
        assertTrue(nsdDiscovered.isScanning)
        assertEquals(38491, nsdDiscovered.pairingPort)
        assertEquals(41555, nsdDiscovered.connectPort)
    }

    @Test
    fun `test DirectAdbManager certificate generation and isConnected`() {
        val kpg = java.security.KeyPairGenerator.getInstance("RSA")
        kpg.initialize(2048, java.security.SecureRandom())
        val kp = kpg.generateKeyPair()

        val unsafe = sun.misc.Unsafe::class.java.getDeclaredField("theUnsafe").apply {
            isAccessible = true
        }.get(null) as sun.misc.Unsafe
        val mgr = unsafe.allocateInstance(DirectAdbManager::class.java) as DirectAdbManager

        val method = DirectAdbManager::class.java.getDeclaredMethod(
            "generateSelfSignedCertificate",
            java.security.KeyPair::class.java
        )
        method.isAccessible = true
        val cert = method.invoke(mgr, kp) as java.security.cert.X509Certificate
        assertTrue(cert.encoded.isNotEmpty())
        assertFalse(mgr.isConnected)
        assertFalse(DirectAdbManager.isInstanceConnectedFast())
    }

    @Test
    fun `test AbsAdbConnectionManager timeout and pair signatures exist`() {
        val pairMethod = AbsAdbConnectionManager::class.java.getMethod(
            "pair",
            String::class.java,
            Int::class.javaPrimitiveType,
            String::class.java
        )
        assertNotNull(pairMethod)
        val connectMethod = AbsAdbConnectionManager::class.java.getMethod(
            "connect",
            String::class.java,
            Int::class.javaPrimitiveType
        )
        assertNotNull(connectMethod)
    }

    @Test
    fun `test strict ShellEngineState readiness without false positives`() {
        val defaultState = ShellEngineState()
        assertFalse(defaultState.isAdbReady)
        assertFalse(defaultState.isWirelessAdbConnected)

        val wirelessReadyState = ShellEngineState(
            mode = ShellMode.WIRELESS_ADB,
            isWirelessAdbConnected = true,
            wirelessAdbPort = 41555
        )
        assertTrue(wirelessReadyState.isAdbReady)

        val wirelessDisconnectedState = ShellEngineState(
            mode = ShellMode.WIRELESS_ADB,
            isWirelessAdbConnected = false,
            wirelessAdbPort = 41555
        )
        assertFalse(wirelessDisconnectedState.isAdbReady)
    }

    @Test
    fun `test ShellResult timeout and error classification`() {
        val timeoutRes = ShellResult(
            command = "sleep 60",
            exitCode = -1,
            output = "",
            error = "Quá thời gian thực thi lệnh (Timeout > 15s)",
            modeUsed = ShellMode.WIRELESS_ADB
        )
        assertFalse(timeoutRes.isSuccess)
        assertTrue(timeoutRes.errorReason.contains("Timeout"))
    }

    @Test
    fun `test UiAutomatorSwitchHelper locates Gentle Notification and Banner switches accurately`() {
        val sampleHonorXml = """
            <?xml version='1.0' encoding='UTF-8' standalone='yes' ?>
            <hierarchy rotation="0">
              <node index="0" text="Cho phép thông báo" class="android.widget.TextView" bounds="[64,320][540,380]" />
              <node index="1" text="" class="android.widget.Switch" checkable="true" checked="true" bounds="[900,310][1020,390]" />
              <node index="2" text="Thông báo nhẹ nhàng" class="android.widget.TextView" bounds="[64,520][540,580]" />
              <node index="3" text="" class="android.widget.Switch" checkable="true" checked="true" bounds="[900,510][1020,590]" />
              <node index="4" text="Biểu ngữ" class="android.widget.TextView" bounds="[64,720][440,780]" />
              <node index="5" text="" class="android.widget.Switch" checkable="true" checked="false" bounds="[900,710][1020,790]" />
            </hierarchy>
        """.trimIndent()

        val nodes = com.example.core.shell.UiAutomatorSwitchHelper.parseUiNodes(sampleHonorXml)
        assertEquals(6, nodes.size)

        val gentleSwitch = com.example.core.shell.UiAutomatorSwitchHelper.findSwitchForLabel(
            nodes,
            listOf("thông báo nhẹ nhàng", "gentle notification")
        )
        assertTrue(gentleSwitch != null && gentleSwitch.isChecked)
        assertEquals(960, gentleSwitch?.tapX)
        assertEquals(550, gentleSwitch?.tapY)

        val bannerSwitch = com.example.core.shell.UiAutomatorSwitchHelper.findSwitchForLabel(
            nodes,
            listOf("biểu ngữ", "banners")
        )
        assertTrue(bannerSwitch != null && !bannerSwitch.isChecked)
        assertEquals(960, bannerSwitch?.tapX)
        assertEquals(750, bannerSwitch?.tapY)
    }

    @Test
    fun `test parseDumpsysNotificationChannels detects Gentle low importance channels`() {
        val sampleDumpsys = """
            Preferences:
              AppSettings: com.zing.zalo (10245)
                NotificationChannel{mId='zalo_msg', mName=Tin nhắn, mImportance=2}
              AppSettings: com.facebook.orca (10246)
                NotificationChannel{mId='orca_call', mName=Cuộc gọi, mImportance=4}
        """.trimIndent()

        val parsed = com.example.core.shell.UiAutomatorSwitchHelper.parseDumpsysNotificationChannels(
            sampleDumpsys,
            setOf("com.zing.zalo", "com.facebook.orca")
        )
        val zalo = parsed["com.zing.zalo"]
        val orca = parsed["com.facebook.orca"]

        assertTrue(zalo != null && zalo.hasLowOrGentleChannel)
        assertFalse(zalo?.hasHighBannerChannel ?: true)
        assertTrue(orca != null && orca.hasHighBannerChannel)
        assertFalse(orca?.hasLowOrGentleChannel ?: true)
    }

    @Test
    fun `test all vector drawables declare mandatory width and height attributes`() {
        val drawableDir = java.io.File("src/main/res/drawable")
        val xmlFiles = drawableDir.listFiles { f -> f.extension == "xml" }.orEmpty()
        assertTrue("Expected drawable XML files", xmlFiles.isNotEmpty())
        for (file in xmlFiles) {
            val content = file.readText()
            if (content.contains("<vector")) {
                assertTrue(
                    "Vector drawable ${file.name} is missing android:width",
                    content.contains("android:width=")
                )
                assertTrue(
                    "Vector drawable ${file.name} is missing android:height",
                    content.contains("android:height=")
                )
            }
        }
    }
}
