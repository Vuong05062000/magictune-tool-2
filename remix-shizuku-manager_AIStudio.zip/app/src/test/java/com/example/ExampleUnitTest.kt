package com.example

import com.example.core.shell.ShellEngineState
import com.example.core.shell.ShellMode
import com.example.core.shell.ShellResult
import com.example.data.ShizukuInfo
import org.junit.Assert.*
import org.junit.Test
import rikka.shizuku.Shizuku

class ExampleUnitTest {
    @Test
    fun addition_isCorrect() {
        assertEquals(4, 2 + 2)
    }

    @Test
    fun testShizukuDeclaredNewProcessMethodPresent() {
        // Kiểm tra phương thức newProcess tồn tại trên rikka.shizuku.Shizuku
        val newProcMethod = Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java
        )
        assertNotNull("Shizuku.newProcess method must exist", newProcMethod)
        newProcMethod.isAccessible = true
        assertEquals("rikka.shizuku.ShizukuRemoteProcess", newProcMethod.returnType.name)
    }

    @Test
    fun testShellEngineStateWithShizukuReady() {
        val state = ShellEngineState(
            mode = ShellMode.SHIZUKU,
            isShizukuInstalled = true,
            isShizukuRunning = true,
            isShizukuPermissionGranted = true,
            isShizukuSeveredFromAdb = false
        )
        assertTrue("Shizuku ready state must evaluate to true", state.isAdbReady)
    }

    @Test
    fun testShellResultSuccessAndErrorDetection() {
        val successRes = ShellResult(
            command = "echo ok",
            exitCode = 0,
            output = "ok",
            error = "",
            modeUsed = ShellMode.SHIZUKU
        )
        assertTrue(successRes.isSuccess)

        val deniedRes = ShellResult(
            command = "settings put global test 1",
            exitCode = 1,
            output = "",
            error = "java.lang.SecurityException: Permission denial: WRITE_SECURE_SETTINGS",
            modeUsed = ShellMode.SHIZUKU
        )
        assertFalse(deniedRes.isSuccess)
        assertTrue(deniedRes.errorReason.contains("Từ chối quyền hệ thống Android"))
    }
}
