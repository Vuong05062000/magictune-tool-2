package com.example.data

import android.app.ActivityManager
import android.bluetooth.BluetoothManager
import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.hardware.Sensor
import android.hardware.SensorManager
import android.hardware.display.DisplayManager
import android.location.LocationManager
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.net.wifi.WifiManager
import android.nfc.NfcAdapter
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.os.StatFs
import android.os.SystemClock
import android.provider.Settings
import android.view.Display
import com.example.core.shell.ShellEngine
import com.example.core.shell.ShellMode
import com.example.core.shell.ShellResult
import com.example.core.license.LicenseManager
import com.example.core.auth.FirebaseAuthManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions

class MagicTuneRepository(
    private val context: Context,
    val shellEngine: ShellEngine
) {
    private val db = FirebaseFirestore.getInstance()
    private val deviceId = LicenseManager.getDeviceId(context).uppercase()
    // Secondary constructor for backward compatibility in tests
    constructor(shellEngine: ShellEngine) : this(
        context = extractContextFromEngine(shellEngine),
        shellEngine = shellEngine
    )

    private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    private fun formatNow(): String = synchronized(timeFormat) {
        timeFormat.format(Date())
    }

    private val _logs = MutableStateFlow<List<LogItem>>(emptyList())
    val logs: StateFlow<List<LogItem>> = _logs

    private val _deviceInfo = MutableStateFlow(DeviceInfo())
    val deviceInfo: StateFlow<DeviceInfo> = _deviceInfo

    private val _setupStatus = MutableStateFlow(NewDeviceSetupStatus())
    val setupStatus: StateFlow<NewDeviceSetupStatus> = _setupStatus

    private val _shizukuInfo = MutableStateFlow(ShizukuInfo())
    val shizukuInfo: StateFlow<ShizukuInfo> = _shizukuInfo

    private val _appsList = MutableStateFlow<List<DebloatApp>>(emptyList())
    val appsList: StateFlow<List<DebloatApp>> = _appsList

    private val _diagnosticScan = MutableStateFlow(DiagnosticScanResult())
    val diagnosticScan: StateFlow<DiagnosticScanResult> = _diagnosticScan

    private val _floatingWindowState = MutableStateFlow(FloatingMiniWindowState())
    val floatingWindowState: StateFlow<FloatingMiniWindowState> = _floatingWindowState

    private val _tuneStatus = MutableStateFlow(TuneStatus())
    val tuneStatus: StateFlow<TuneStatus> = _tuneStatus

    fun saveSyncData(tuneStatus: TuneStatus, appsList: List<DebloatApp>) {
        val frozenPackages = appsList.filter { it.isFrozen }.map { it.packageName }
        val data = mapOf(
            "tuneStatus" to tuneStatus,
            "frozenPackages" to frozenPackages,
            "lastSyncedAt" to com.google.firebase.firestore.FieldValue.serverTimestamp()
        )
        db.collection("user_data").document(deviceId).set(data, SetOptions.merge())
    }

    fun loadSyncData(onLoaded: (TuneStatus?, List<String>?) -> Unit) {
        db.collection("user_data").document(deviceId).get().addOnSuccessListener { doc ->
            if (doc.exists()) {
                val status = doc.toObject(TuneStatus::class.java)
                @Suppress("UNCHECKED_CAST")
                val frozen = (doc.get("frozenPackages") as? List<*>)?.filterIsInstance<String>()
                onLoaded(status, frozen)
            }
        }
    }

    // Danh sách các gói CỐT LÕI HỆ THỐNG TUYỆT ĐỐI KHÔNG HIỂN THỊ / KHÔNG ĐƯỢC PHÉP GỠ (Bảo vệ ROM 100%, chống treo logo/bootloop)
    val CRITICAL_ROM_PACKAGES = setOf(
        "android",
        "com.android.systemui",
        "com.android.settings",
        "com.android.phone",
        "com.android.server.telecom",
        "com.android.keychain",
        "com.android.packageinstaller",
        "com.google.android.packageinstaller",
        "com.android.permissioncontroller",
        "com.google.android.permissioncontroller",
        "com.android.shell",
        "com.android.bluetooth",
        "com.android.networkstack",
        "com.android.networkstack.inprocess",
        "com.android.networkstack.tethering.inprocess",
        "com.android.providers.settings",
        "com.android.providers.telephony",
        "com.android.providers.media",
        "com.android.providers.contacts",
        "com.android.providers.calendar",
        "com.android.providers.downloads",
        "com.android.providers.userdictionary",
        "com.android.se",
        "com.android.externalstorage",
        "com.android.mtp",
        "com.android.vpndialogs",
        "com.google.android.webview",
        "com.android.webview",
        "com.android.captiveportallogin",
        "com.android.inputdevices",
        "com.android.bms",
        "com.android.cts.priv.ctsshim",
        "com.android.cts.ctsshim"
    )

    val knownDebloatApps = listOf(
        // CẤP 1: RÁC AN TOÀN (Safe Bloatware - Gỡ thoải mái 100% không ảnh hưởng gì tới máy)
        DebloatApp("com.hihonor.powergenius", "PowerGenius", "Trình AI diệt app ngầm gây trễ thông báo Facebook, Zalo (An toàn gỡ)", 1, isUserApp = false),
        DebloatApp("com.hihonor.iaware", "iAware AI", "AI phân tích ngầm của MagicOS, gián tiếp tắt tiến trình ngầm (An toàn gỡ)", 1, isUserApp = false),
        DebloatApp("com.huawei.powergenie", "PowerGenie (Legacy)", "Quản lý pin cũ Huawei để lại trên ROM Honor (An toàn gỡ)", 1, isUserApp = false),
        DebloatApp("com.hihonor.video", "Honor Video", "Trình phát video nội địa, chứa nhiều quảng cáo tiếng Trung (An toàn gỡ)", 1, isUserApp = false),
        DebloatApp("com.hihonor.gamecenter", "Trung tâm trò chơi", "Gây phiền nhiễu thông báo game tiếng Trung (An toàn gỡ)", 1, isUserApp = false),
        DebloatApp("com.hihonor.search", "Honor Search", "Tìm kiếm vuốt xuống từ màn hình chính, gây giật lag (An toàn gỡ)", 1, isUserApp = false),
        DebloatApp("com.hihonor.browser", "Trình duyệt Honor", "Trình duyệt mặc định nội địa TQ, nên dùng Chrome (An toàn gỡ)", 1, isUserApp = false),
        DebloatApp("com.hihonor.magazinesettings", "Tạp chí màn hình khóa", "Tự tải ảnh nền 4K từ TQ, hao pin & dữ liệu ngầm (An toàn gỡ)", 1, isUserApp = false),
        DebloatApp("com.hihonor.music", "Honor Music", "App nghe nhạc bản quyền Trung Quốc (An toàn gỡ)", 1, isUserApp = false),
        DebloatApp("com.hihonor.reader", "Honor Reader", "Sách truyện tiếng Trung không có ích tại VN (An toàn gỡ)", 1, isUserApp = false),
        DebloatApp("com.hihonor.mall", "Honor Mall", "Sàn mua sắm Honor nội địa TQ (An toàn gỡ)", 1, isUserApp = false),
        DebloatApp("com.hihonor.live", "Honor Live", "Livestream bán hàng tiếng Trung chạy ngầm (An toàn gỡ)", 1, isUserApp = false),
        DebloatApp("com.hihonor.vmall", "Honor Vmall", "Cửa hàng mua sắm Honor TQ chạy ngầm (An toàn gỡ)", 1, isUserApp = false),
        DebloatApp("com.hihonor.phoneservice", "Honor Club & Thành viên", "Dịch vụ câu lạc bộ Honor TQ (An toàn gỡ)", 1, isUserApp = false),
        DebloatApp("com.hihonor.findmyphone", "Tìm thiết bị Honor TQ", "Dịch vụ định vị nội địa TQ, nên dùng Google Find My (An toàn gỡ)", 1, isUserApp = false),
        DebloatApp("com.hihonor.feedback", "Honor Feedback", "Phản hồi báo lỗi gửi dữ liệu về máy chủ TQ (An toàn gỡ)", 1, isUserApp = false),
        DebloatApp("com.hihonor.hiai.engine", "HiAI Engine Service", "Nền tảng AI quảng cáo & gợi ý nội địa TQ (An toàn gỡ)", 1, isUserApp = false),

        // CẤP 2: CÂN NHẮC (Dịch vụ phụ trợ - Gỡ an toàn nhưng cân nhắc nếu có dùng tính năng này)
        DebloatApp("com.hihonor.hiboard", "Honor HiBoard", "Bảng tin vuốt trái màn hình chính tiếng Trung (Cân nhắc)", 2, isUserApp = false),
        DebloatApp("com.hihonor.appmarket", "Chợ Ứng dụng Honor", "Tự động cập nhật app VN đè sang tiếng Trung (Cân nhắc)", 2, isUserApp = false),
        DebloatApp("com.hihonor.assistant", "Trợ lý YOYO", "Trợ lý ảo YOYO tiếng Trung khi nhấn giữ thanh điều hướng (Cân nhắc)", 2, isUserApp = false),
        DebloatApp("com.hihonor.wallet", "Ví Honor Wallet", "Ví thanh toán Trung Quốc (Cân nhắc)", 2, isUserApp = false),
        DebloatApp("com.hihonor.health", "Honor Health", "App theo dõi sức khỏe nội địa TQ (Cân nhắc)", 2, isUserApp = false),
        DebloatApp("com.hihonor.cloud", "Honor Cloud", "Dịch vụ đám mây Honor TQ (Cân nhắc)", 2, isUserApp = false),
        DebloatApp("com.hihonor.tips", "Honor Tips", "Mẹo & hướng dẫn sử dụng máy Honor (Cân nhắc)", 2, isUserApp = false),
        DebloatApp("com.hihonor.notepad", "Ghi chú Honor", "Ứng dụng ghi chú mặc định của máy (Cân nhắc)", 2, isUserApp = false),
        DebloatApp("com.hihonor.compass", "La bàn Honor", "Công cụ la bàn tích hợp sẵn (Cân nhắc)", 2, isUserApp = false),
        DebloatApp("com.hihonor.calculator", "Máy tính Honor", "Công cụ tính toán mặc định của máy (Cân nhắc)", 2, isUserApp = false),
        DebloatApp("com.hihonor.soundrecorder", "Ghi âm Honor", "Công cụ ghi âm tích hợp sẵn (Cân nhắc)", 2, isUserApp = false),
        DebloatApp("com.hihonor.lens", "Honor Lens / AI Lens", "Quét mã QR và dịch văn bản hình ảnh (Cân nhắc)", 2, isUserApp = false),
        DebloatApp("com.hihonor.quicksearch", "Tìm kiếm nhanh", "Công cụ tìm kiếm trên thanh trạng thái (Cân nhắc)", 2, isUserApp = false),
        DebloatApp("com.hihonor.magicedge", "Magic Edge", "Cử chỉ thông minh vuốt viền màn hình (Cân nhắc)", 2, isUserApp = false),
        DebloatApp("com.hihonor.hwsuggestion", "Gợi ý thông minh YOYO", "Đề xuất thói quen sử dụng ứng dụng (Cân nhắc)", 2, isUserApp = false),

        // CẤP 3: CẢNH BÁO NGUY HIỂM CAO (Chỉ cho phép gỡ app gây trễ thông báo; khóa cứng các app không gây trễ thông báo)
        DebloatApp("com.hihonor.systemmanager", "Quản lý hệ thống (Phone Manager)", "CẤP 3: Quản lý pin & kill tiến trình ngầm • Trực tiếp gây trễ thông báo Zalo, Facebook (Cho phép gỡ/đóng băng)", 3, isUserApp = false, causesNotificationDelay = true),
        DebloatApp("com.hihonor.push", "Dịch vụ Push Honor", "CẤP 3: Dịch vụ Push Honor nội địa • Xung đột kênh FCM làm trễ tin nhắn (Cho phép gỡ/đóng băng)", 3, isUserApp = false, causesNotificationDelay = true),
        DebloatApp("com.hihonor.ouc", "Trình cập nhật MagicOS (FOTA)", "CẤP 3: Cập nhật hệ điều hành qua OTA • Tiến trình kiểm tra ngầm chiếm sóng & pin (Cho phép gỡ/đóng băng)", 3, isUserApp = false, causesNotificationDelay = true),
        DebloatApp("com.huawei.android.hwouc", "Trình cập nhật hệ thống cũ", "CẤP 3: Dịch vụ cập nhật OTA cũ còn sót lại • Chiếm sóng ngầm (Cho phép gỡ/đóng băng)", 3, isUserApp = false, causesNotificationDelay = true),
        DebloatApp("com.hihonor.id", "Tài khoản Honor ID", "CẤP 3: Đăng nhập đám mây Honor • Không gây trễ thông báo (Khóa cứng chống gỡ)", 3, isUserApp = false, causesNotificationDelay = false),
        DebloatApp("com.hihonor.android.totemweather", "Thời tiết Honor", "CẤP 3: Widget thời tiết màn hình • Không gây trễ thông báo (Khóa cứng chống gỡ)", 3, isUserApp = false, causesNotificationDelay = false),
        DebloatApp("com.hihonor.trustagent", "Honor TrustAgent", "CẤP 3: Mở khóa thông minh Bluetooth • Không gây trễ thông báo (Khóa cứng chống gỡ)", 3, isUserApp = false, causesNotificationDelay = false),
        DebloatApp("com.hihonor.android.instantshare", "Honor Share", "CẤP 3: Chia sẻ dữ liệu nhanh Wi-Fi Direct • Không gây trễ thông báo (Khóa cứng chống gỡ)", 3, isUserApp = false, causesNotificationDelay = false),
        DebloatApp("com.hihonor.airsharing", "Trình chiếu AirSharing", "CẤP 3: Chiếu màn hình không dây TV/PC • Không gây trễ thông báo (Khóa cứng chống gỡ)", 3, isUserApp = false, causesNotificationDelay = false),
        DebloatApp("com.hihonor.printservice", "Dịch vụ In ấn Honor", "CẤP 3: Kết nối & in tài liệu qua mạng • Không gây trễ thông báo (Khóa cứng chống gỡ)", 3, isUserApp = false, causesNotificationDelay = false),
        DebloatApp("com.hihonor.securitymanager", "Bảo mật nâng cao Honor", "CẤP 3: Quét virus tích hợp • Không gây trễ thông báo (Khóa cứng chống gỡ)", 3, isUserApp = false, causesNotificationDelay = false),
        DebloatApp("com.hihonor.photos", "Bộ sưu tập ảnh Honor", "CẤP 3: Xem ảnh/video mặc định • Không gây trễ thông báo (Khóa cứng chống gỡ)", 3, isUserApp = false, causesNotificationDelay = false),
        DebloatApp("com.hihonor.deskclock", "Đồng hồ & Báo thức Honor", "CẤP 3: Báo thức mặc định • Không gây trễ thông báo (Khóa cứng chống gỡ)", 3, isUserApp = false, causesNotificationDelay = false),
        DebloatApp("com.hihonor.contacts", "Danh bạ & Cuộc gọi Honor", "CẤP 3: Danh bạ mặc định • Không gây trễ thông báo (Khóa cứng chống gỡ)", 3, isUserApp = false, causesNotificationDelay = false),
        DebloatApp("com.hihonor.android.launcher", "Honor Launcher (Màn hình chính)", "CẤP 3: Giao diện Trang chủ mặc định • Không gây trễ thông báo (Khóa cứng chống gỡ)", 3, isUserApp = false, causesNotificationDelay = false)
    )

    fun isAppCausingNotificationDelay(pkg: String): Boolean {
        val known = knownDebloatApps.find { it.packageName == pkg }
        if (known != null) {
            return known.causesNotificationDelay
        }
        val lower = pkg.lowercase()
        return lower.contains("systemmanager") || lower.contains("push") ||
            lower.contains("ouc") || lower.contains("powergenie") ||
            lower.contains("powergenius") || lower.contains("iaware") ||
            lower.contains("battery") || lower.contains("powersaving") ||
            lower.contains("joyose") || lower.contains("powerkeeper") ||
            lower.contains("athena")
    }

    fun classifySystemApp(pkg: String, appLabel: String): Triple<Int, String, String> {
        val known = knownDebloatApps.find { it.packageName == pkg }
        if (known != null) {
            return Triple(known.level, known.name, known.desc)
        }
        val lower = pkg.lowercase()
        val friendly = appLabel.ifBlank { pkg.substringAfterLast('.').replaceFirstChar { it.uppercase() } }
        return when {
            lower.contains("ad") || lower.contains("analytic") || lower.contains("log") ||
                lower.contains("demo") || lower.contains("game") || lower.contains("video") ||
                lower.contains("music") || lower.contains("mall") || lower.contains("shop") ||
                lower.contains("news") || lower.contains("reader") || lower.contains("browser") ||
                lower.contains("market") || lower.contains("banner") || lower.contains("promo") ||
                lower.contains("live") || lower.contains("powergenie") || lower.contains("powergenius") -> {
                Triple(1, friendly, "Rác hệ thống thương mại/quảng cáo • An toàn gỡ bỏ 100%")
            }
            lower.contains("assistant") || lower.contains("cloud") || lower.contains("wallet") ||
                lower.contains("health") || lower.contains("hiboard") || lower.contains("tips") ||
                lower.contains("note") || lower.contains("recorder") || lower.contains("compass") ||
                lower.contains("lens") || lower.contains("theme") || lower.contains("weather") ||
                lower.contains("widget") || lower.contains("smart") || lower.contains("card") ||
                lower.contains("calculator") -> {
                Triple(2, friendly, "Dịch vụ phụ trợ hệ thống • Cân nhắc nhu cầu cá nhân trước khi gỡ")
            }
            else -> {
                val causesDelay = isAppCausingNotificationDelay(pkg)
                val desc = if (causesDelay) {
                    "CẤP 3: Quản lý pin & tiến trình • Có ảnh hưởng và gây chậm thông báo (Được phép gỡ/đóng băng)"
                } else {
                    "CẤP 3: Dịch vụ hệ thống chuyên sâu • Không gây trễ thông báo (Khóa cứng chống gỡ)"
                }
                Triple(3, friendly, desc)
            }
        }
    }

    val commonUserAppsCatalog = listOf(
        "com.zing.zalo" to ("Zalo" to "Ứng dụng nhắn tin & gọi điện tại Việt Nam (Cần ưu tiên thông báo & biểu ngữ)"),
        "com.facebook.katana" to ("Facebook" to "Mạng xã hội Facebook (Cần bật biểu ngữ nổi & chống trễ FCM)"),
        "com.facebook.orca" to ("Messenger" to "Nhắn tin & gọi điện Facebook Messenger (Cần chạy ngầm 24/24)"),
        "com.google.android.gm" to ("Gmail" to "Thư điện tử Google Gmail (Cần phá gom cụm 0s để nhận mail tức thì)"),
        "org.telegram.messenger" to ("Telegram" to "Ứng dụng nhắn tin Telegram (Cần quyền chạy ngầm & biểu ngữ)"),
        "com.zhiliaoapp.musically" to ("TikTok" to "Ứng dụng video ngắn TikTok (Ứng dụng người dùng)"),
        "com.ss.android.ugc.trill" to ("TikTok" to "Ứng dụng video ngắn TikTok (Ứng dụng người dùng)"),
        "com.shopee.vn" to ("Shopee" to "Ứng dụng mua sắm Shopee Việt Nam (Ứng dụng người dùng)"),
        "com.vng.inputmethod.labankey" to ("Laban Key" to "Bàn phím gõ Tiếng Việt Laban Key (Ứng dụng người dùng)"),
        "com.lazada.android" to ("Lazada" to "Ứng dụng mua sắm Lazada Việt Nam (Ứng dụng người dùng)"),
        "com.mbmobile" to ("MB Bank" to "Ngân hàng Quân Đội MB Bank (Cần xác thực thanh toán tức thì)"),
        "com.VCB" to ("Vietcombank" to "Ngân hàng Vietcombank Digibank (Cần xác thực thanh toán tức thì)"),
        "vn.com.techcombank.bb.app" to ("Techcombank Mobile" to "Ngân hàng Techcombank (Cần xác thực thanh toán tức thì)")
    )

    init {
        loadUserAppsImmediately()
        loadSyncData { status, frozen ->
            if (status != null) _tuneStatus.value = status
            if (frozen != null) {
                _appsList.value = _appsList.value.map { app ->
                    if (frozen.contains(app.packageName)) app.copy(isFrozen = true) else app
                }
            }
        }
    }

    /**
     * Nạp ngay lập tức danh sách ứng dụng người dùng VÀ ứng dụng hệ thống Cấp 1, 2, 3 từ PackageManager & từ điển knownDebloatApps
     * ngay khi ứng dụng khởi chạy, bảo đảm 100% hiển thị đầy đủ ngay cả khi CHƯA KẾT NỐI ADB.
     * Hoàn toàn độc lập, không phụ thuộc vào ADB để hiển thị danh sách app.
     */
    fun loadUserAppsImmediately() {
        try {
            val pm = context.packageManager
            val combined = LinkedHashMap<String, DebloatApp>()

            // 1. Nạp app người dùng đã cài đặt (fallback an toàn nếu một phương thức bị lỗi)
            val installedApps = try {
                pm.getInstalledApplications(0)
            } catch (_: Throwable) {
                try {
                    pm.getInstalledPackages(0).mapNotNull { it.applicationInfo }
                } catch (_: Throwable) {
                    emptyList()
                }
            }

            for (appInfo in installedApps) {
                val pkg = appInfo.packageName ?: continue
                if (pkg == context.packageName) continue
                val isSys = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0 &&
                    (appInfo.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
                if (!isSys) {
                    val label = try { pm.getApplicationLabel(appInfo).toString().ifBlank { pkg } } catch (_: Exception) { pkg }
                    val catalogEntry = commonUserAppsCatalog.find { it.first == pkg }?.second
                    val isNotifOk = shellEngine.isAppWhitelistedOrFixed(pkg) || shellEngine.isAppActuallyNotificationEnabled(pkg)
                    val isPermOk = shellEngine.isAppPermissionGranted(pkg) || shellEngine.isAppActuallyBackgroundWhitelisted(pkg)
                    combined[pkg] = DebloatApp(
                        packageName = pkg,
                        name = catalogEntry?.first ?: label,
                        desc = catalogEntry?.second ?: "Ứng dụng người dùng cài đặt • Có thể Gỡ cài đặt hoặc Cấp full quyền & Biểu ngữ",
                        level = 0,
                        isInstalled = true,
                        isFrozen = !appInfo.enabled,
                        isUserApp = true,
                        isFullNotificationFixed = isNotifOk,
                        isFullPermissionGranted = isPermOk
                    )
                }
            }

            // 2. Nạp các app hệ thống Cấp 1, Cấp 2, Cấp 3 từ knownDebloatApps vào danh sách ngay lập tức
            for (sysApp in knownDebloatApps) {
                val pkg = sysApp.packageName
                if (CRITICAL_ROM_PACKAGES.contains(pkg)) continue
                val appInfo = try {
                    pm.getApplicationInfo(pkg, 0)
                } catch (_: Throwable) { null }
                val isDis = appInfo?.enabled == false || shellEngine.isPackageMarkedDisabled(pkg)
                val isUninstalled = shellEngine.isPackageMarkedUninstalled(pkg)
                val isInst = (appInfo != null) && !isUninstalled

                // Nếu gói có tồn tại trên máy hoặc đã được ghi nhận gỡ/tắt -> Đưa vào danh sách
                if (appInfo != null || isUninstalled || isDis) {
                    combined[pkg] = sysApp.copy(
                        isInstalled = isInst,
                        isFrozen = isDis,
                        isUserApp = false,
                        isFullNotificationFixed = shellEngine.isAppWhitelistedOrFixed(pkg),
                        isFullPermissionGranted = shellEngine.isAppPermissionGranted(pkg)
                    )
                }
            }

            if (combined.isNotEmpty()) {
                _appsList.value = combined.values.sortedWith(
                    compareBy<DebloatApp> { app ->
                        when {
                            app.isUserApp && app.isInstalled && !app.isFrozen && (!app.isFullNotificationFixed || !app.isFullPermissionGranted) -> 0
                            !app.isUserApp && app.isInstalled && !app.isFrozen && app.level == 1 -> 1
                            app.isUserApp && app.isInstalled && !app.isFrozen -> 2
                            !app.isUserApp && app.isInstalled && !app.isFrozen && app.level == 2 -> 3
                            !app.isUserApp && app.isInstalled && !app.isFrozen && app.level == 3 -> 4
                            else -> 5
                        }
                    }.thenBy { it.name.lowercase() }
                )
            }
        } catch (_: Throwable) {}
    }

    /**
     * Lọc và che giấu các chuỗi lệnh Shell / ADB nhạy cảm để bảo vệ bản quyền công nghệ:
     * - Chỉ Admin đã đăng nhập mới được xem chi tiết mã lệnh thô.
     * - Với người dùng thông thường, chỉ hiển thị thông báo tiến trình tổng quát.
     */
    private fun sanitizeLogForUser(rawMessage: String, type: LogType): String {
        try {
            val isLiveAdmin = FirebaseAuthManager.getCurrentUser() != null &&
                    (FirebaseAuthManager.isCurrentAdmin(context, null) || LicenseManager.isCurrentUserAdmin(context))
            if (isLiveAdmin) return rawMessage // Admin xem toàn bộ chi tiết không che

            // Với người dùng thường, che các lệnh Shell thô và chi tiết lệnh
            if (type == LogType.COMMAND || rawMessage.startsWith("> ") || rawMessage.startsWith("$ ")) {
                return "⚡ Đang xử lý cấu hình hệ thống..."
            }
            if (rawMessage.startsWith("✅ OK: ") || rawMessage.startsWith("✅ [OK]: ")) {
                return "✅ Đã áp dụng thiết lập tối ưu thành công."
            }
            if (rawMessage.startsWith("✅ THÀNH CÔNG: ")) {
                return "✅ Đã hoàn tất cài đặt tối ưu hệ thống."
            }
            if (rawMessage.startsWith("❌ THẤT BẠI [") || rawMessage.startsWith("❌ LỆNH THẤT BẠI [")) {
                return "⚠️ Một mục cài đặt hệ thống không phản hồi hoặc đã được tối ưu trước đó."
            }
            // Che các câu lệnh chứa cú pháp kỹ thuật đặc thù
            if (rawMessage.contains("cmd ") || rawMessage.contains("settings put") || 
                rawMessage.contains("pm disable") || rawMessage.contains("service call") ||
                rawMessage.contains("setprop") || rawMessage.contains("device_config")) {
                return "⚙️ Đang đồng bộ hóa dịch vụ chuyên sâu..."
            }
        } catch (_: Throwable) {}
        return rawMessage
    }

    fun log(message: String, type: LogType = LogType.INFO) {
        val sanitized = sanitizeLogForUser(message, type)
        val item = LogItem(sanitized, type, formatNow())
        synchronized(_logs) {
            _logs.value = (_logs.value + item).takeLast(300)
        }
        if (type == LogType.ERROR && shellEngine.state.value.isAdbReady && (message.contains("❌") || message.contains("THẤT BẠI") || message.contains("LỆNH THẤT BẠI"))) {
            val extractedCmd = if (message.contains("[") && message.contains("]")) {
                message.substringAfter("[").substringBefore("]")
            } else {
                message.take(80)
            }
            LicenseManager.saveAdminAdbErrorLog(
                context = context,
                command = extractedCmd,
                exitCode = 1,
                errorOutput = message,
                connectionMode = shellEngine.state.value.mode.name,
                featureSource = "TERMINAL_LOG"
            )
        }
    }

    fun clearLogs() {
        _logs.value = emptyList()
    }

    /**
     * Executes a single shell command or a semicolon-separated command string.
     * Splits multiple commands so each command's exit code and stderr are verified individually.
     */
    suspend fun runShell(cmd: String, showLog: Boolean = true): String = withContext(Dispatchers.IO) {
        val subCommands = splitShellCommands(cmd)
        if (subCommands.size <= 1) {
            if (showLog) log("> $cmd", LogType.COMMAND)
            val res = shellEngine.execute(cmd)
            if (showLog) {
                if (res.isSuccess) {
                    val outMsg = if (res.output.isNotBlank()) "✅ OK: ${res.output.take(300)}" else "✅ OK: $cmd"
                    log(outMsg, LogType.SUCCESS)
                } else {
                    log("❌ THẤT BẠI [$cmd]: ${res.errorReason}", LogType.ERROR)
                    if (shellEngine.state.value.isAdbReady) {
                        LicenseManager.saveAdminAdbErrorLog(
                            context = context,
                            command = cmd,
                            exitCode = res.exitCode,
                            errorOutput = res.combinedOutput.ifBlank { res.errorReason },
                            connectionMode = res.modeUsed.name,
                            featureSource = "RUN_SHELL"
                        )
                    }
                }
            }
            // Khi showLog = false (đọc thông số ngầm), tuyệt đối KHÔNG trả về chuỗi lỗi res.error để tránh hiển thị nhầm lên thẻ thông tin máy!
            return@withContext if (res.isSuccess) {
                res.output.takeIf { !it.contains("Lỗi kết nối", ignoreCase = true) } ?: ""
            } else {
                if (showLog) res.output.ifBlank { res.error } else ""
            }
        } else {
            val outputs = mutableListOf<String>()
            for (single in subCommands) {
                if (showLog) log("> $single", LogType.COMMAND)
                val res = shellEngine.execute(single)
                if (showLog) {
                    if (res.isSuccess) {
                        val outMsg = if (res.output.isNotBlank()) "✅ OK: ${res.output.take(200)}" else "✅ OK: $single"
                        log(outMsg, LogType.SUCCESS)
                    } else {
                        log("❌ THẤT BẠI [$single]: ${res.errorReason}", LogType.ERROR)
                        if (shellEngine.state.value.isAdbReady) {
                            LicenseManager.saveAdminAdbErrorLog(
                                context = context,
                                command = single,
                                exitCode = res.exitCode,
                                errorOutput = res.combinedOutput.ifBlank { res.errorReason },
                                connectionMode = res.modeUsed.name,
                                featureSource = "RUN_SHELL_MULTI"
                            )
                        }
                    }
                }
                if (res.isSuccess) {
                    outputs.add(res.output)
                } else if (showLog) {
                    outputs.add(res.output.ifBlank { res.error })
                }
            }
            return@withContext outputs.joinToString("\n")
        }
    }

    /**
     * Đọc thuộc tính hệ thống (SystemProperties) siêu tốc trực tiếp qua Reflection / Local getprop,
     * đảm bảo 100% không bao giờ trả về chuỗi lỗi kết nối Shizuku trên các ô thông tin điện thoại!
     */
    private fun readSysPropFast(key: String, default: String = ""): String {
        try {
            val spClass = Class.forName("android.os.SystemProperties")
            val getMethod = spClass.getMethod("get", String::class.java, String::class.java)
            val value = (getMethod.invoke(null, key, default) as? String)?.trim() ?: ""
            if (value.isNotBlank() && !value.equals("null", ignoreCase = true) && !value.contains("Lỗi kết nối", ignoreCase = true)) {
                return value
            }
        } catch (_: Throwable) {}
        return try {
            val proc = Runtime.getRuntime().exec(arrayOf("getprop", key))
            val out = proc.inputStream.bufferedReader().use { it.readText() }.trim()
            proc.destroy()
            if (out.isNotBlank() && !out.equals("null", ignoreCase = true) && !out.contains("Lỗi kết nối", ignoreCase = true)) out else default
        } catch (_: Throwable) {
            default
        }
    }

    /**
     * Runs a batch of ADB commands, verifying each command individually and reporting exact
     * success/failure counts without ever showing a fake success summary.
     */
    suspend fun runVerifiedBatch(actionTitle: String, commands: List<String>): Boolean = withContext(Dispatchers.IO) {
        val flatCommands = commands.flatMap { splitShellCommands(it) }.filter { it.isNotBlank() }
        var successCount = 0
        var failCount = 0
        val failedList = mutableListOf<String>()

        val isHighSpeedAdbLive = shellEngine.state.value.isAdbReady

        // Tối ưu hóa siêu tốc Turbo v2.5 khi Shizuku/ADB đang Live:
        // Chạy qua shellEngine.executeBatch (mỗi lô 25 lệnh chỉ tạo ĐÚNG 1 tiến trình Shizuku duy nhất),
        // vừa có kết quả riêng biệt từng lệnh vừa triệt tiêu 100% lỗi "Shizuku Binder không phản hồi"!
        if (isHighSpeedAdbLive && flatCommands.size >= 2) {
            val chunkSize = 80 // Split commands into chunks so ADB/Shizuku socket never freezes on huge batches (e.g. 4854 commands)
            val chunks = flatCommands.chunked(chunkSize)
            val modeLabel = if (shellEngine.state.value.isWirelessAdbConnected) "Direct WLAN ADB (UID 2000)" else "Shizuku (UID 2000)"
            log("⚡ [Turbo v2.5] Đang thực thi ${flatCommands.size} lệnh qua ${chunks.size} đợt siêu tốc ($modeLabel)...", LogType.INFO)

            for ((chunkIndex, chunk) in chunks.withIndex()) {
                if (chunks.size > 1) {
                    log("🔄 Đang xử lý đợt ${chunkIndex + 1}/${chunks.size} (${chunk.size} lệnh)...", LogType.INFO)
                }
                val batchResults = shellEngine.executeBatch(chunk)
                for (res in batchResults) {
                    val cmd = res.command
                    if (res.isSuccess) {
                        successCount++
                        val detail = if (res.output.isNotBlank()) " -> ${res.output.take(120)}" else ""
                        log("✅ [OK]: $cmd$detail", LogType.SUCCESS)
                    } else {
                        failCount++
                        failedList.add(cmd)
                        log("❌ LỆNH THẤT BẠI [$cmd]: ${res.errorReason}", LogType.ERROR)
                        if (shellEngine.state.value.isAdbReady) {
                            LicenseManager.saveAdminAdbErrorLog(
                                context = context,
                                command = cmd,
                                exitCode = res.exitCode,
                                errorOutput = res.combinedOutput.ifBlank { res.errorReason },
                                connectionMode = res.modeUsed.name,
                                featureSource = "BATCH: $actionTitle"
                            )
                        }
                    }
                }
                if (chunkIndex < chunks.size - 1) {
                    kotlinx.coroutines.delay(50L) // Tiny pause between chunks to let system ADB socket process smoothly
                }
            }
        } else {
            for (cmd in flatCommands) {
                log("> $cmd", LogType.COMMAND)
                val res: ShellResult = shellEngine.execute(cmd)
                if (res.isSuccess) {
                    successCount++
                    val detail = if (res.output.isNotBlank()) " -> ${res.output.take(140)}" else ""
                    log("✅ THÀNH CÔNG: $cmd$detail", LogType.SUCCESS)
                } else {
                    failCount++
                    failedList.add(cmd)
                    log("❌ LỆNH THẤT BẠI [$cmd]: ${res.errorReason}", LogType.ERROR)
                    if (shellEngine.state.value.isAdbReady) {
                        LicenseManager.saveAdminAdbErrorLog(
                            context = context,
                            command = cmd,
                            exitCode = res.exitCode,
                            errorOutput = res.combinedOutput.ifBlank { res.errorReason },
                            connectionMode = res.modeUsed.name,
                            featureSource = "ACTION: $actionTitle"
                        )
                    }
                }
            }
        }

        val total = flatCommands.size
        return@withContext when {
            failCount == 0 && total > 0 -> {
                log("🎉 HOÀN TẤT THÀNH CÔNG 100% ($successCount/$total lệnh): $actionTitle", LogType.SUCCESS)
                true
            }
            successCount > 0 && failCount > 0 -> {
                val isShizukuActive = shellEngine.state.value.mode == ShellMode.SHIZUKU &&
                    shellEngine.state.value.isShizukuRunning &&
                    shellEngine.state.value.isShizukuPermissionGranted
                val adviseWeb = if (isShizukuActive) " 👉 Hãy truy cập https://magictunehonor.ai.studio để dùng WebADB hoặc xem hướng dẫn fix chuyên sâu cho Honor!" else " 👉 Hãy kết nối WLAN / Shizuku hoặc truy cập https://magictunehonor.ai.studio."
                log(
                    "⚠️ KẾT QUẢ THỰC TẾ [$actionTitle]: Thành công $successCount/$total lệnh, THẤT BẠI $failCount lệnh! (Xem chi tiết lỗi đỏ ❌ ở trên).$adviseWeb",
                    LogType.ERROR
                )
                false
            }
            else -> {
                val isShizukuActive = shellEngine.state.value.mode == ShellMode.SHIZUKU &&
                    shellEngine.state.value.isShizukuRunning &&
                    shellEngine.state.value.isShizukuPermissionGranted
                val msg = if (isShizukuActive) {
                    "❌ THẤT BẠI ($failCount/$total lệnh bị từ chối): '$actionTitle' gặp lỗi quyền trên MagicOS dù đã có Shizuku! 👉 Bạn hãy mở website tiện ích https://magictunehonor.ai.studio để chạy công cụ gỡ lỗi chuyên sâu hoặc kết nối WebADB."
                } else {
                    "❌ THẤT BẠI ($failCount/$total lệnh bị từ chối): '$actionTitle' không thể áp dụng do chưa kết nối Gỡ lỗi Wi-Fi (WLAN ADB)! 👉 Vui lòng mở tab Kết Nối để ghép nối trực tiếp bằng mã 6 số."
                }
                log(msg, LogType.ERROR)
                false
            }
        }
    }

    private fun splitShellCommands(raw: String): List<String> {
        val result = mutableListOf<String>()
        val current = StringBuilder()
        var inQuotes = false
        for (ch in raw) {
            when (ch) {
                '"' -> {
                    inQuotes = !inQuotes
                    current.append(ch)
                }
                ';' -> {
                    if (inQuotes) {
                        current.append(ch)
                    } else {
                        val built = current.toString().trim()
                        if (built.isNotEmpty()) result.add(built)
                        current.clear()
                    }
                }
                else -> current.append(ch)
            }
        }
        val last = current.toString().trim()
        if (last.isNotEmpty()) result.add(last)
        return result
    }

    private data class StaticHardwareSpecs(
        val manufacturer: String,
        val brand: String,
        val model: String,
        val deviceCodename: String,
        val board: String,
        val androidVer: String,
        val sdkInt: Int,
        val securityPatch: String,
        val displayId: String,
        val kernelVer: String,
        val abi: String,
        val socName: String,
        val cpuCoresText: String,
        val cpuFreqText: String,
        val gpuName: String,
        val sensorCount: Int,
        val capturedWithAdb: Boolean
    )

    @Volatile
    private var cachedStaticSpecs: StaticHardwareSpecs? = null

    @Volatile
    private var cachedBatteryCycleCount: String? = null

    @Volatile
    private var lastBatteryCycleShellCheckMs: Long = 0L

    private suspend fun getOrLoadStaticSpecs(): StaticHardwareSpecs {
        val adbNow = shellEngine.state.value.isAdbReady
        val existing = cachedStaticSpecs
        if (existing != null &&
            (existing.capturedWithAdb || !adbNow) &&
            !existing.model.contains("Lỗi kết nối", ignoreCase = true) &&
            !existing.socName.contains("Lỗi kết nối", ignoreCase = true) &&
            !existing.gpuName.contains("Lỗi kết nối", ignoreCase = true)
        ) {
            return existing
        }

        val manufacturer = Build.MANUFACTURER.ifBlank { readSysPropFast("ro.product.manufacturer", "HONOR") }.ifBlank { "HONOR" }
        val brand = Build.BRAND.ifBlank { manufacturer }.uppercase()
        val rawModel = Build.MODEL.ifBlank { readSysPropFast("ro.product.model", "Honor Device") }.ifBlank { "Honor Device" }
        val marketName = readSysPropFast("ro.config.marketing_name", "").trim()
        val customName = try {
            Settings.Global.getString(context.contentResolver, "device_name")?.takeIf { it.isNotBlank() && it != "null" && !it.contains("Lỗi kết nối", true) }
                ?: Settings.Secure.getString(context.contentResolver, "bluetooth_name")?.takeIf { it.isNotBlank() && it != "null" && !it.contains("Lỗi kết nối", true) }
        } catch (_: Exception) { null }
            ?: if (adbNow) {
                runShell("settings get global device_name", false).trim().takeIf { it.isNotBlank() && it != "null" && !it.contains("Lỗi kết nối", true) }
            } else null

        val model = when {
            marketName.isNotBlank() && !marketName.equals("null", ignoreCase = true) -> {
                val clean = if (marketName.startsWith("荣耀")) "Honor " + marketName.removePrefix("荣耀").trim() else marketName
                if (customName != null && customName.contains(clean, ignoreCase = true)) customName else clean
            }
            !customName.isNullOrBlank() -> customName
            rawModel.equals("PPG-AN00", ignoreCase = true) -> "Honor GT Pro"
            else -> rawModel
        }
        val deviceCodename = Build.DEVICE.ifBlank { Build.PRODUCT }.ifBlank { "Unknown" }
        val board = "${Build.BOARD} (${Build.HARDWARE})"
        val androidVer = Build.VERSION.RELEASE.ifBlank { "15" }
        val sdkInt = Build.VERSION.SDK_INT
        val securityPatch = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Build.VERSION.SECURITY_PATCH.ifBlank { "N/A" }
        } else "N/A"
        val displayId = Build.DISPLAY.ifBlank { readSysPropFast("ro.build.display.id", "MagicOS") }.ifBlank { "MagicOS" }
        val kernelVer = System.getProperty("os.version") ?: "Linux"
        val abi = Build.SUPPORTED_ABIS.joinToString(", ")

        val socFromBuild = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            Build.SOC_MODEL.takeIf { it != Build.UNKNOWN && it.isNotBlank() }
        } else null
        val socProp = readSysPropFast("ro.board.platform", Build.HARDWARE).trim()
        val cpuHardware = readCpuHardwareName()
        val socName = listOfNotNull(socFromBuild, cpuHardware, socProp.takeIf { it.isNotBlank() })
            .distinct()
            .joinToString(" • ")
            .ifBlank { Build.HARDWARE }

        val cores = Runtime.getRuntime().availableProcessors()
        val maxFreqGhz = readMaxCpuFreqGhz()
        val cpuCoresText = "$cores nhân xử lý"
        val cpuFreqText = if (maxFreqGhz.isNotBlank()) "Xung tối đa $maxFreqGhz" else abi

        val gpuProp = readSysPropFast("ro.hardware.egl", "").trim()
        val gpuName = if (gpuProp.isNotBlank()) "GPU $gpuProp (${socProp.ifBlank { Build.HARDWARE }})" else "Adreno / Mali (${socProp.ifBlank { Build.HARDWARE }})"

        val sensorCount = try {
            val sm = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
            sm?.getSensorList(Sensor.TYPE_ALL)?.size ?: 0
        } catch (_: Exception) { 0 }

        return StaticHardwareSpecs(
            manufacturer = manufacturer,
            brand = brand,
            model = model,
            deviceCodename = deviceCodename,
            board = board,
            androidVer = androidVer,
            sdkInt = sdkInt,
            securityPatch = securityPatch,
            displayId = displayId,
            kernelVer = kernelVer,
            abi = abi,
            socName = socName,
            cpuCoresText = cpuCoresText,
            cpuFreqText = cpuFreqText,
            gpuName = gpuName,
            sensorCount = sensorCount,
            capturedWithAdb = adbNow
        ).also { cachedStaticSpecs = it }
    }

    // -------------------------------------------------------------
    // ĐỌC ĐẦY ĐỦ PHẦN CỨNG & TRẠNG THÁI BẬT/TẮT TÍNH NĂNG REALTIME
    // -------------------------------------------------------------
    suspend fun refreshDeviceInfo() = withContext(Dispatchers.IO) {
        val specs = getOrLoadStaticSpecs()
        val manufacturer = specs.manufacturer
        val brand = specs.brand
        val model = specs.model
        val deviceCodename = specs.deviceCodename
        val board = specs.board
        val androidVer = specs.androidVer
        val sdkInt = specs.sdkInt
        val securityPatch = specs.securityPatch
        val displayId = specs.displayId
        val kernelVer = specs.kernelVer
        val abi = specs.abi
        val socName = specs.socName
        val cpuCoresText = specs.cpuCoresText
        val cpuFreqText = specs.cpuFreqText
        val gpuName = specs.gpuName

        var ramString = "N/A"
        var ramPercent = 0f
        try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            if (am != null) {
                val memInfo = ActivityManager.MemoryInfo()
                am.getMemoryInfo(memInfo)
                val totalGb = memInfo.totalMem.toDouble() / (1024.0 * 1024.0 * 1024.0)
                val availGb = memInfo.availMem.toDouble() / (1024.0 * 1024.0 * 1024.0)
                val usedGb = (totalGb - availGb).coerceAtLeast(0.0)
                ramPercent = if (totalGb > 0) ((usedGb / totalGb) * 100.0).toFloat().coerceIn(0f, 100f) else 0f
                ramString = String.format(
                    Locale.US,
                    "Đang dùng %.1f GB / %.1f GB (Trống %.1f GB • %.0f%%)",
                    usedGb,
                    totalGb,
                    availGb,
                    ramPercent
                )
            }
        } catch (_: Exception) {}

        var storageString = "N/A"
        var storagePercent = 0f
        try {
            val stat = StatFs(Environment.getDataDirectory().path)
            val totalBytes = stat.blockSizeLong * stat.blockCountLong
            val availBytes = stat.blockSizeLong * stat.availableBlocksLong
            val usedBytes = (totalBytes - availBytes).coerceAtLeast(0L)
            val totalGb = totalBytes.toDouble() / (1024.0 * 1024.0 * 1024.0)
            val availGb = availBytes.toDouble() / (1024.0 * 1024.0 * 1024.0)
            val usedGb = usedBytes.toDouble() / (1024.0 * 1024.0 * 1024.0)
            storagePercent = if (totalGb > 0) ((usedGb / totalGb) * 100.0).toFloat().coerceIn(0f, 100f) else 0f
            storageString = String.format(
                Locale.US,
                "Đã dùng %.1f GB / %.1f GB (Trống %.1f GB • %.0f%%)",
                usedGb,
                totalGb,
                availGb,
                storagePercent
            )
        } catch (_: Exception) {}

        var batLevel = 100
        var batStatusText = "Đang hoạt động"
        var batTempText = "N/A"
        var batVoltText = "N/A"
        var batTechText = "Li-poly"
        var batHealthText = "Tốt"
        var batCycleCountText = "N/A"
        try {
            val batteryIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            if (batteryIntent != null) {
                val level = batteryIntent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val scale = batteryIntent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
                if (level >= 0 && scale > 0) {
                    batLevel = (level * 100) / scale
                }
                val status = batteryIntent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                val plugged = batteryIntent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)
                val plugType = when (plugged) {
                    BatteryManager.BATTERY_PLUGGED_AC -> "Sạc nguồn AC"
                    BatteryManager.BATTERY_PLUGGED_USB -> "Cáp USB"
                    BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Sạc không dây"
                    else -> ""
                }
                batStatusText = when (status) {
                    BatteryManager.BATTERY_STATUS_CHARGING -> "⚡ Đang sạc ($plugType)"
                    BatteryManager.BATTERY_STATUS_FULL -> "✅ Đã sạc đầy 100%"
                    BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "Không sạc"
                    else -> "Đang dùng pin"
                }
                val tempTenths = batteryIntent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1)
                if (tempTenths > 0) {
                    batTempText = String.format(Locale.US, "%.1f°C", tempTenths / 10.0f)
                }
                val voltage = batteryIntent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1)
                if (voltage > 0) {
                    batVoltText = "${voltage} mV"
                }
                batTechText = batteryIntent.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY) ?: "Li-poly"
                val health = batteryIntent.getIntExtra(BatteryManager.EXTRA_HEALTH, BatteryManager.BATTERY_HEALTH_GOOD)
                batHealthText = when (health) {
                    BatteryManager.BATTERY_HEALTH_GOOD -> "Tốt (Good)"
                    BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Quá nhiệt!"
                    BatteryManager.BATTERY_HEALTH_DEAD -> "Chai pin"
                    BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Quá áp"
                    else -> "Bình thường"
                }

                // Đọc số chu kỳ sạc (Battery Cycle Count) tương tự DevCheck / Android 14+ BatteryManager
                var cycleCount = -1
                if (Build.VERSION.SDK_INT >= 34) { // Android 14+
                    cycleCount = batteryIntent.getIntExtra("android.os.extra.CYCLE_COUNT", -1)
                    if (cycleCount < 0) {
                        try {
                            val bm = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
                            if (bm != null) {
                                // 7 là hằng số BatteryManager.BATTERY_PROPERTY_CYCLE_COUNT giới thiệu từ API 34
                                cycleCount = bm.getIntProperty(7)
                            }
                        } catch (_: Exception) {}
                    }
                }
                if (cycleCount > 0) {
                    batCycleCountText = "$cycleCount chu kỳ"
                }
            }
        } catch (_: Exception) {}

        // Fallback: Đọc trực tiếp file sysfs trước, chỉ truy vấn qua Shell tối đa 10 phút/lần và lưu cache để không làm nghẽn Shizuku/ADB mỗi 3.5s
        if (batCycleCountText == "N/A") {
            val cachedCycle = cachedBatteryCycleCount
            if (cachedCycle != null) {
                batCycleCountText = cachedCycle
            } else {
                var parsedCycle: Int? = null
                for (sysPath in listOf("/sys/class/power_supply/bk_battery/cycle_count", "/sys/class/power_supply/battery/cycle_count")) {
                    try {
                        val f = File(sysPath)
                        if (f.exists() && f.canRead()) {
                            val v = f.readText().trim().toIntOrNull()
                            if (v != null && v > 0) {
                                parsedCycle = v
                                break
                            }
                        }
                    } catch (_: Exception) {}
                }
                val nowMs = SystemClock.elapsedRealtime()
                if (parsedCycle == null && shellEngine.state.value.isAdbReady && (nowMs - lastBatteryCycleShellCheckMs > 600_000L || lastBatteryCycleShellCheckMs == 0L)) {
                    lastBatteryCycleShellCheckMs = nowMs
                    try {
                        val cycleSysfs = runShell("cat /sys/class/power_supply/bk_battery/cycle_count 2>/dev/null || cat /sys/class/power_supply/battery/cycle_count 2>/dev/null", false).trim()
                        val v = cycleSysfs.lineSequence().firstOrNull()?.trim()?.toIntOrNull()
                        if (v != null && v > 0) {
                            parsedCycle = v
                        }
                    } catch (_: Exception) {}
                }
                if (parsedCycle != null && parsedCycle > 0) {
                    val formatted = "$parsedCycle chu kỳ"
                    cachedBatteryCycleCount = formatted
                    batCycleCountText = formatted
                }
            }
        }

        var screenText = "Unknown"
        var refreshText = "60Hz"
        try {
            val dm = context.resources.displayMetrics
            screenText = "${dm.widthPixels}x${dm.heightPixels} px (${dm.densityDpi} dpi)"
            val displayManager = context.getSystemService(Context.DISPLAY_SERVICE) as? DisplayManager
            val defaultDisplay = displayManager?.getDisplay(Display.DEFAULT_DISPLAY)
            if (defaultDisplay != null) {
                val persistedHz = shellEngine.getPersistedSetting("system", "user_refresh_rate")?.toIntOrNull()
                val currentHz = persistedHz ?: defaultDisplay.refreshRate.toInt()
                val maxHz = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    defaultDisplay.supportedModes.maxOfOrNull { it.refreshRate.toInt() } ?: currentHz
                } else currentHz
                refreshText = "${currentHz}Hz (Tối đa ${maxHz}Hz)"
            }
        } catch (_: Exception) {}

        val sensorCount = specs.sensorCount

        val elapsedMillis = SystemClock.elapsedRealtime()
        val hours = elapsedMillis / (1000 * 60 * 60)
        val minutes = (elapsedMillis / (1000 * 60)) % 60
        val uptimeText = "${hours}h ${minutes}p"

        val features = readPhoneFeatureStates()

        _deviceInfo.value = DeviceInfo(
            model = model,
            manufacturer = manufacturer,
            brand = brand,
            deviceCodename = deviceCodename,
            board = board,
            version = "Android $androidVer (API $sdkInt)",
            sdkInt = sdkInt,
            securityPatch = securityPatch,
            magicOS = displayId,
            kernel = kernelVer,
            soc = socName,
            cpuCores = cpuCoresText,
            cpuFreq = cpuFreqText,
            abi = abi,
            gpu = gpuName,
            ram = ramString,
            ramUsedPercent = ramPercent,
            storage = storageString,
            storageUsedPercent = storagePercent,
            batteryLevel = batLevel,
            batteryStatus = batStatusText,
            batteryVoltage = batVoltText,
            batteryTech = batTechText,
            batteryHealth = batHealthText,
            batteryCycleCount = batCycleCountText,
            temp = batTempText,
            screen = screenText,
            refreshRate = refreshText,
            sensorCount = sensorCount,
            uptime = uptimeText,
            serial = when (shellEngine.state.value.mode) {
                ShellMode.SHIZUKU -> "SHIZUKU_UID_2000"
                ShellMode.WIRELESS_ADB -> "WLAN_127.0.0.1:${shellEngine.state.value.wirelessAdbPort}"
                ShellMode.ROOT -> "ROOT_SU_UID_0"
                else -> if (shellEngine.state.value.hasPersistentGrant) "PERSISTENT_FIX_ACTIVE" else "LOCAL_SHELL"
            },
            features = features
        )
        refreshTuneStatus()
        refreshFloatingPermissionsState()
    }

    private fun readPhoneFeatureStates(): List<PhoneFeatureItem> {
        val cr = context.contentResolver
        val list = mutableListOf<PhoneFeatureItem>()

        // 1. Wi-Fi
        val wifiEnabled = try {
            val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            wm?.isWifiEnabled ?: (Settings.Global.getInt(cr, Settings.Global.WIFI_ON, 0) == 1)
        } catch (_: Exception) {
            try { Settings.Global.getInt(cr, Settings.Global.WIFI_ON, 0) == 1 } catch (_: Exception) { false }
        }
        list.add(
            PhoneFeatureItem(
                id = "wifi",
                name = "Wi-Fi",
                isEnabled = wifiEnabled,
                statusText = if (wifiEnabled) "ĐANG BẬT" else "ĐANG TẮT",
                detail = if (wifiEnabled) "Kết nối mạng không dây đang mở" else "Đã tắt kết nối Wi-Fi"
            )
        )

        // 2. Bluetooth
        val btEnabled = try {
            val bm = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
            val adapter = bm?.adapter
            adapter?.isEnabled ?: (Settings.Global.getInt(cr, Settings.Global.BLUETOOTH_ON, 0) == 1)
        } catch (_: Exception) {
            try { Settings.Global.getInt(cr, Settings.Global.BLUETOOTH_ON, 0) == 1 } catch (_: Exception) { false }
        }
        list.add(
            PhoneFeatureItem(
                id = "bluetooth",
                name = "Bluetooth",
                isEnabled = btEnabled,
                statusText = if (btEnabled) "ĐANG BẬT" else "ĐANG TẮT",
                detail = if (btEnabled) "Sẵn sàng kết nối tai nghe / phụ kiện" else "Bluetooth đang tắt"
            )
        )

        // 3. Mạng Di Động (Mobile Data 4G/5G)
        val mobileDataEnabled = try {
            val setting = Settings.Global.getInt(cr, "mobile_data", -1)
            if (setting != -1) {
                setting == 1
            } else {
                val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
                val net = cm?.activeNetwork
                val caps = cm?.getNetworkCapabilities(net)
                caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true
            }
        } catch (_: Exception) { false }
        list.add(
            PhoneFeatureItem(
                id = "mobile_data",
                name = "Dữ Liệu Di Động (4G/5G)",
                isEnabled = mobileDataEnabled,
                statusText = if (mobileDataEnabled) "ĐANG BẬT" else "ĐANG TẮT",
                detail = if (mobileDataEnabled) "Dữ liệu SIM đang bật" else "Dữ liệu SIM đang tắt"
            )
        )

        // 4. Định vị GPS (Location) - Ưu tiên đọc trạng thái phần cứng thực tế từ LocationManager / Settings.Secure
        val gpsEnabled = try {
            val lm = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P && lm != null) {
                lm.isLocationEnabled
            } else {
                @Suppress("DEPRECATION")
                Settings.Secure.getInt(cr, Settings.Secure.LOCATION_MODE, 0) != 0
            }
        } catch (_: Exception) {
            shellEngine.getPersistedSetting("secure", "location_mode")?.let { it != "0" } ?: false
        }
        list.add(
            PhoneFeatureItem(
                id = "gps",
                name = "Định Vị GPS",
                isEnabled = gpsEnabled,
                statusText = if (gpsEnabled) "ĐANG BẬT" else "ĐANG TẮT",
                detail = if (gpsEnabled) "Định vị bản đồ đang hoạt động" else "Đã tắt vị trí GPS"
            )
        )

        // 5. NFC
        val nfcAdapter = try { NfcAdapter.getDefaultAdapter(context) } catch (_: Throwable) { null }
        val nfcEnabled = try { nfcAdapter?.isEnabled == true } catch (_: Throwable) { false }
        val nfcStatus = when {
            nfcAdapter == null -> "KHÔNG HỖ TRỢ"
            nfcEnabled -> "ĐANG BẬT"
            else -> "ĐANG TẮT"
        }
        list.add(
            PhoneFeatureItem(
                id = "nfc",
                name = "NFC (Chạm Thanh Toán / CCCD)",
                isEnabled = nfcEnabled,
                statusText = nfcStatus,
                detail = if (nfcAdapter == null) "Máy không có chip NFC" else if (nfcEnabled) "Quét CCCD / Google Pay sẵn sàng" else "NFC đang tắt"
            )
        )

        // 6. Xoay màn hình tự động
        val autoRotate = try {
            Settings.System.getInt(cr, Settings.System.ACCELEROMETER_ROTATION, 0) == 1
        } catch (_: Exception) { false }
        list.add(
            PhoneFeatureItem(
                id = "auto_rotate",
                name = "Tự Động Xoay Màn Hình",
                isEnabled = autoRotate,
                statusText = if (autoRotate) "ĐANG BẬT" else "ĐANG TẮT (Khóa xoay)",
                detail = if (autoRotate) "Tự xoay theo cảm biến góc nghiêng" else "Đang khóa xoay dọc"
            )
        )

        // 7. Chế độ tối (Dark Mode) - Đọc trực tiếp từ Configuration / Settings.Secure thực tế trên máy
        val darkMode = try {
            val mask = context.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
            if (mask == Configuration.UI_MODE_NIGHT_YES) {
                true
            } else {
                val nightSetting = Settings.Secure.getInt(cr, "ui_night_mode", -1)
                if (nightSetting != -1) nightSetting == 2 else false
            }
        } catch (_: Exception) { false }
        list.add(
            PhoneFeatureItem(
                id = "dark_mode",
                name = "Giao Diện Tối (Dark Mode)",
                isEnabled = darkMode,
                statusText = if (darkMode) "ĐANG BẬT" else "ĐANG TẮT (Nền sáng)",
                detail = if (darkMode) "Đang bật chế độ nền tối OLED" else "Đang dùng giao diện sáng"
            )
        )

        // 8. Chặn Quảng Cáo DNS (AdBlocker Pro)
        val dnsMode = shellEngine.getPersistedSetting("global", "private_dns_mode")
            ?: try { Settings.Global.getString(cr, "private_dns_mode") } catch (_: Exception) { null }
        val dnsHost = shellEngine.getPersistedSetting("global", "private_dns_specifier")
            ?: try { Settings.Global.getString(cr, "private_dns_specifier") } catch (_: Exception) { null }
        val adBlockActive = dnsMode == "hostname" && !dnsHost.isNullOrBlank()
        list.add(
            PhoneFeatureItem(
                id = "adblocker_dns",
                name = "Chặn Quảng Cáo (Private DNS)",
                isEnabled = adBlockActive,
                statusText = if (adBlockActive) "ĐANG BẬT" else "ĐANG TẮT",
                detail = if (adBlockActive) "DNS: $dnsHost" else "Chưa bật lọc quảng cáo DNS"
            )
        )

        // 9. Công tắc nhấn thanh điều hướng đánh thức YOYO
        val yoyoDisabled = shellEngine.getPersistedSetting("secure", "navigation_bar_wakeup_yoyo") == "0" ||
            shellEngine.getPersistedSetting("secure", "yoyo_navigation_bar_wakeup") == "0" ||
            shellEngine.isPackageMarkedDisabled("com.hihonor.assistant")
        list.add(
            PhoneFeatureItem(
                id = "yoyo_nav_wake",
                name = "Chặn Đánh Thức YOYO Thanh Điều Hướng",
                isEnabled = yoyoDisabled,
                statusText = if (yoyoDisabled) "ĐÃ TẮT GỌI YOYO" else "CHƯA TẮT",
                detail = if (yoyoDisabled) "Nhấn giữ thanh điều hướng không còn bật YOYO" else "Nhấn giữ thanh điều hướng có thể gọi YOYO"
            )
        )

        // 10. Chặn Update Hệ Thống & Chợ App
        val updateBlocked = shellEngine.getPersistedSetting("global", "auto_update_app") == "0"
        list.add(
            PhoneFeatureItem(
                id = "block_update",
                name = "Chặn Tự Động Update ROM & Chợ Honor",
                isEnabled = updateBlocked,
                statusText = if (updateBlocked) "ĐANG CHẶN UPDATE" else "CHƯA CHẶN",
                detail = if (updateBlocked) "Đã khóa tự động cập nhật đè app & ROM" else "Tự động cập nhật vẫn mở"
            )
        )

        // 11. Đồng bộ Tự động (Auto-Sync)
        val autoSync = try { ContentResolver.getMasterSyncAutomatically() } catch (_: Exception) { true }
        list.add(
            PhoneFeatureItem(
                id = "auto_sync",
                name = "Đồng Bộ Tài Khoản (Auto-Sync)",
                isEnabled = autoSync,
                statusText = if (autoSync) "ĐANG BẬT" else "ĐANG TẮT",
                detail = if (autoSync) "Gmail & Danh bạ tự động đồng bộ" else "Tự động đồng bộ đang tắt"
            )
        )

        // 12. Gỡ lỗi USB / Gỡ lỗi Wi-Fi (ADB)
        val usbAdb = try { Settings.Global.getInt(cr, Settings.Global.ADB_ENABLED, 0) == 1 } catch (_: Exception) { false }
        val wifiAdb = try { Settings.Global.getInt(cr, "adb_wifi_enabled", 0) == 1 } catch (_: Exception) { false } ||
            shellEngine.state.value.isWirelessAdbConnected
        val anyAdb = usbAdb || wifiAdb || shellEngine.state.value.isAdbReady
        list.add(
            PhoneFeatureItem(
                id = "adb_debug",
                name = "Trạng Thái Gỡ Lỗi & Duy Trì Fix",
                isEnabled = anyAdb,
                statusText = when {
                    shellEngine.state.value.isWirelessAdbConnected -> "WLAN: ĐANG KẾT NỐI"
                    shellEngine.state.value.isShizukuRunning && shellEngine.state.value.isShizukuPermissionGranted -> "SHIZUKU: ĐANG KẾT NỐI"
                    shellEngine.state.value.hasPersistentGrant -> "GIỮ FIX KHI TẮT WLAN"
                    else -> "CHƯA KẾT NỐI"
                },
                detail = when {
                    shellEngine.state.value.isShizukuRunning && shellEngine.state.value.isShizukuPermissionGranted -> "Shizuku UID 2000 đang hoạt động"
                    shellEngine.state.value.isWirelessAdbConnected -> "Gỡ lỗi qua WLAN cổng ${shellEngine.state.value.wirelessAdbPort} đang kết nối"
                    shellEngine.state.value.hasPersistentGrant -> "Đã ngắt WLAN nhưng giữ nguyên 100% các mục đã Fix"
                    else -> "Bấm nút WLAN trên thanh tiêu đề để kết nối"
                }
            )
        )

        return list
    }

    fun refreshTuneStatus() {
        val cr = context.contentResolver
        val dnsMode = shellEngine.getPersistedSetting("global", "private_dns_mode")
            ?: try { Settings.Global.getString(cr, "private_dns_mode") } catch (_: Exception) { null }
        val dnsHost = shellEngine.getPersistedSetting("global", "private_dns_specifier")
            ?: try { Settings.Global.getString(cr, "private_dns_specifier") } catch (_: Exception) { null }
        val adBlockEnabled = dnsMode == "hostname" && !dnsHost.isNullOrBlank()

        val yoyoDisabled = shellEngine.getPersistedSetting("secure", "navigation_bar_wakeup_yoyo") == "0" ||
            shellEngine.getPersistedSetting("secure", "yoyo_navigation_bar_wakeup") == "0" ||
            shellEngine.isPackageMarkedDisabled("com.hihonor.assistant")
        val navHidden = shellEngine.getPersistedSetting("secure", "hide_navigation_bar") == "1"
        val updateBlocked = shellEngine.getPersistedSetting("global", "auto_update_app") == "0"
        val audioFixed = shellEngine.getPersistedSetting("global", "bluetooth_absolute_volume") == "0"
        val screenshotUnlocked = shellEngine.getPersistedSetting("global", "block_screen_capture") == "0"
        val androidAutoFixed = shellEngine.getPersistedSetting("secure", "gearhead_fixed") == "1" ||
            shellEngine.isAppWhitelistedOrFixed("com.google.android.projection.gearhead")
        val googleAssistantWake = shellEngine.getPersistedSetting("secure", "google_assistant_wake") == "1" ||
            (shellEngine.getPersistedSetting("secure", "assistant")?.contains("google") == true &&
             shellEngine.getPersistedSetting("secure", "assist_long_press_home_enabled") == "1")
        val honorSearchDisabled = shellEngine.isPackageMarkedDisabled("com.hihonor.search") ||
            shellEngine.getPersistedSetting("secure", "honor_search_disabled") == "1"
        val fontBold = shellEngine.getPersistedSetting("system", "font_scale") == "1.15"
        val darkOled = shellEngine.getPersistedSetting("secure", "ui_night_mode") == "2"
        val hz = shellEngine.getPersistedSetting("system", "user_refresh_rate")?.toIntOrNull() ?: 120
        val anim = shellEngine.getPersistedSetting("global", "window_animation_scale")?.toFloatOrNull() ?: 1.0f

        val navModMode = shellEngine.getPersistedSetting("secure", "magictune_nav_mod_mode") ?: "NONE"
        val circleToSearch = navModMode == "CIRCLE_TO_SEARCH" ||
            shellEngine.getPersistedSetting("secure", "contextual_search_enabled") == "1"
        val geminiVoice = navModMode == "GEMINI_VOICE" ||
            (googleAssistantWake && !circleToSearch && navModMode != "DEFAULT" && navModMode != "DISABLED")

        val devStealth = shellEngine.getPersistedSetting("global", "magictune_dev_stealth") == "1" ||
            (shellEngine.getPersistedSetting("global", "development_settings_enabled") == "0" && shellEngine.state.value.isAdbReady)
        val restrictedUnlocked = shellEngine.getPersistedSetting("secure", "magictune_restricted_storage_unlocked") == "1"
        val dataCount = shellEngine.getPersistedSetting("secure", "magictune_data_folders_count")?.toIntOrNull() ?: 0
        val obbCount = shellEngine.getPersistedSetting("secure", "magictune_obb_folders_count")?.toIntOrNull() ?: 0
        val storageSummary = shellEngine.getPersistedSetting("secure", "magictune_restricted_storage_summary")
            ?: if (restrictedUnlocked) "Đã mở khóa truy cập trực tiếp Android/data ($dataCount app) & Android/obb ($obbCount gói)"
            else "Sẵn sàng mở khóa & đọc/ghi/giải nén trực tiếp Android/data & Android/obb"
        val camBlocked = shellEngine.getPersistedSetting("secure", "magictune_cam_blocked") == "1"
        val micBlocked = shellEngine.getPersistedSetting("secure", "magictune_mic_blocked") == "1"
        val locBlocked = shellEngine.getPersistedSetting("secure", "magictune_loc_blocked") == "1"
        val clipProtected = shellEngine.getPersistedSetting("secure", "magictune_clip_protected") == "1"
        val activeMacro = shellEngine.getPersistedSetting("secure", "magictune_active_macro") ?: "Mặc định"

        val locManager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
        val isLocEnabled = (locManager != null && locManager.isLocationEnabled) ||
            shellEngine.getPersistedSetting("secure", "location_mode") in listOf("1", "2", "3")
        val isSuplGoogle = shellEngine.getPersistedSetting("global", "supl_host")?.contains("google") == true ||
            try { Settings.Global.getString(context.contentResolver, "supl_host")?.contains("google") == true } catch (_: Exception) { false }
        val isHonorGpsFixedPersisted = shellEngine.getPersistedSetting("secure", "honor_gps_fixed") == "1"
        val isAmapDisabled = shellEngine.isPackageMarkedDisabled("com.amap.android.ams")
        val gpsFixed = (isSuplGoogle || isHonorGpsFixedPersisted || isAmapDisabled) && isLocEnabled

        _tuneStatus.value = TuneStatus(
            isAdBlockerEnabled = adBlockEnabled,
            activeDnsHost = if (adBlockEnabled) (dnsHost ?: "dns.adguard-dns.com") else "Tự động (Chưa bật chặn QC)",
            isYoyoWakeDisabled = yoyoDisabled,
            isNavBarHidden = navHidden,
            isAppMarketUpdateBlocked = updateBlocked,
            isAudio48kFixed = audioFixed,
            isScreenshotUnlocked = screenshotUnlocked,
            isFontBoldLarge = fontBold,
            isDarkModeOled = darkOled,
            isAndroidAutoFixed = androidAutoFixed,
            isGoogleAssistantWakeEnabled = googleAssistantWake || circleToSearch || geminiVoice,
            isCircleToSearchEnabled = circleToSearch,
            isGeminiVoiceEnabled = geminiVoice,
            activeNavModMode = navModMode,
            currentRefreshRate = hz,
            currentAnimationScale = anim,
            isHonorSearchDisabled = honorSearchDisabled,
            isDevModeStealthActive = devStealth,
            isRestrictedStorageUnlocked = restrictedUnlocked,
            restrictedDataFoldersCount = dataCount,
            restrictedObbFoldersCount = obbCount,
            restrictedStorageSummary = storageSummary,
            isCameraPrivacyBlocked = camBlocked,
            isMicPrivacyBlocked = micBlocked,
            isLocationPrivacyBlocked = locBlocked,
            isClipboardPrivacyActive = clipProtected,
            activeAutomationMacro = activeMacro,
            isGoogleAppInstalled = isPackageInstalledFast("com.google.android.googlequicksearchbox"),
            isGeminiAppInstalled = isPackageInstalledFast("com.google.android.apps.bard"),
            isOverlayPermissionGranted = Settings.canDrawOverlays(context),
            isHonorGpsFixed = gpsFixed
        )
    }

    fun refreshFloatingPermissionsState() {
        val current = _floatingWindowState.value
        _floatingWindowState.value = current.copy(
            hasOverlayPermission = shellEngine.hasOverlayPermission(),
            hasControlPermission = shellEngine.hasControlPermission()
        )
    }

    private fun readCpuHardwareName(): String? {
        return try {
            val file = File("/proc/cpuinfo")
            if (!file.exists()) return null
            file.useLines { lines ->
                for (line in lines) {
                    if (line.startsWith("Hardware", ignoreCase = true) ||
                        line.startsWith("model name", ignoreCase = true)
                    ) {
                        val parts = line.split(":")
                        if (parts.size >= 2) {
                            return@useLines parts[1].trim()
                        }
                    }
                }
                null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun readMaxCpuFreqGhz(): String {
        return try {
            val cores = Runtime.getRuntime().availableProcessors()
            var maxKhz = 0L
            for (i in 0 until cores) {
                val f = File("/sys/devices/system/cpu/cpu$i/cpufreq/cpuinfo_max_freq")
                if (f.exists()) {
                    val khz = f.readText().trim().toLongOrNull() ?: 0L
                    if (khz > maxKhz) maxKhz = khz
                }
            }
            if (maxKhz > 0) {
                String.format(Locale.US, "%.2f GHz", maxKhz / 1_000_000.0)
            } else ""
        } catch (_: Exception) {
            ""
        }
    }

    suspend fun refreshSetupStatus() = withContext(Dispatchers.IO) {
        val cr = context.contentResolver
        val pm = context.packageManager

        val requiredSettings = listOf(
            "system" to "system_locales",
            "system" to "time_12_24",
            "secure" to "google_service_switch",
            "system" to "min_match",
            "global" to "captive_portal_https_url",
            "system" to "hw_volte_user_switch",
            "system" to "use_default_notification_sound",
            "global" to "auto_update_app",
            "secure" to "navigation_bar_wakeup_yoyo",
            "secure" to "location_mode",
            "secure" to "hiboard_switch",
            "system" to "iaware_switch",
            "secure" to "yoyo_navigation_bar_wakeup",
            "global" to "supl_host"
        )

        val resolvedMap = HashMap<String, String>()
        val missingForShell = mutableListOf<Pair<String, String>>()

        for ((ns, key) in requiredSettings) {
            val mapKey = "$ns:$key"
            val fromCr = try {
                when (ns) {
                    "system" -> Settings.System.getString(cr, key)
                    "secure" -> Settings.Secure.getString(cr, key)
                    "global" -> Settings.Global.getString(cr, key)
                    else -> null
                }
            } catch (_: Exception) { null }

            if (!fromCr.isNullOrBlank() && fromCr != "null") {
                resolvedMap[mapKey] = fromCr.trim()
            } else {
                val persisted = shellEngine.getPersistedSetting(ns, key)?.takeIf { it.isNotBlank() && it != "null" }
                if (persisted != null) {
                    resolvedMap[mapKey] = persisted.trim()
                } else {
                    missingForShell.add(ns to key)
                }
            }
        }

        if (missingForShell.isNotEmpty() && shellEngine.state.value.isAdbReady) {
            val batchCmd = missingForShell.joinToString("; ") { (ns, key) ->
                "echo -n '__MT_${ns}_${key}='; settings get $ns $key 2>/dev/null"
            }
            val batchOut = runShell(batchCmd, false)
            for (line in batchOut.lineSequence()) {
                val trimmed = line.trim()
                if (trimmed.startsWith("__MT_") && trimmed.contains("=")) {
                    val rawKey = trimmed.substringAfter("__MT_").substringBefore("=")
                    val value = trimmed.substringAfter("=").trim()
                    val ns = rawKey.substringBefore("_")
                    val key = rawKey.substringAfter("_")
                    if (value.isNotBlank() && value != "null") {
                        resolvedMap["$ns:$key"] = value
                    }
                }
            }
        }

        fun readSettingFast(namespace: String, key: String): String {
            return resolvedMap["$namespace:$key"] ?: ""
        }

        fun isPkgInstalledFast(pkg: String): Boolean {
            if (shellEngine.isPackageMarkedUninstalled(pkg)) return false
            return try {
                pm.getPackageInfo(pkg, 0)
                true
            } catch (_: Exception) {
                false
            }
        }

        val locale = readSettingFast("system", "system_locales")
        val tz = java.util.TimeZone.getDefault().id.ifBlank { readSysPropFast("persist.sys.timezone", "Asia/Ho_Chi_Minh") }
        val time24 = readSettingFast("system", "time_12_24")
        val gms = readSettingFast("secure", "google_service_switch")
        val minMatch = readSettingFast("system", "min_match")
        val captiveUrl = readSettingFast("global", "captive_portal_https_url")
        val volte = readSettingFast("system", "hw_volte_user_switch")
        val useDefaultSound = readSettingFast("system", "use_default_notification_sound")
        val autoUpdate = readSettingFast("global", "auto_update_app")
        val yoyoWake = readSettingFast("secure", "navigation_bar_wakeup_yoyo")

        val isViLocale = locale.contains("vi", ignoreCase = true) || Locale.getDefault().language == "vi"
        val isViTz = tz.contains("Ho_Chi_Minh", ignoreCase = true) ||
            tz.contains("Saigon", ignoreCase = true) ||
            tz.contains("Bangkok", ignoreCase = true) ||
            isViLocale
        val hasGms = gms == "1" || isPkgInstalledFast("com.google.android.gms")
        val hasPlay = isPkgInstalledFast("com.android.vending") || gms == "1"
        val hasLaban = isPkgInstalledFast("com.vng.inputmethod.labankey") ||
            shellEngine.getPersistedSetting("secure", "default_input_method")?.contains("labankey") == true
        val hasGboard = isPkgInstalledFast("com.google.android.inputmethod.latin")
        val callerIdOk = minMatch == "7"
        val captiveOk = captiveUrl.contains("gstatic") || captiveUrl.contains("google")
        val volteOk = volte == "1"
        val suplSetting = readSettingFast("global", "supl_host")
            .ifBlank { shellEngine.getPersistedSetting("global", "supl_host") ?: "" }
        val locModeSetting = readSettingFast("secure", "location_mode")
            .ifBlank { shellEngine.getPersistedSetting("secure", "location_mode") ?: "" }
        val locManager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
        val isLocEnabled = (locManager != null && locManager.isLocationEnabled) ||
            locModeSetting in listOf("1", "2", "3") ||
            shellEngine.getPersistedSetting("secure", "location_mode") in listOf("1", "2", "3")
        val isSuplGoogle = suplSetting == "supl.google.com" || suplSetting.contains("google") ||
            shellEngine.getPersistedSetting("global", "supl_host")?.contains("google") == true
        val isHonorGpsFixedPersisted = shellEngine.getPersistedSetting("secure", "honor_gps_fixed") == "1"
        val isAmapDisabled = shellEngine.isPackageMarkedDisabled("com.amap.android.ams")
        val gpsOk = (isSuplGoogle || isHonorGpsFixedPersisted || isAmapDisabled) && isLocEnabled
        val noChinaFeeds = readSettingFast("secure", "hiboard_switch") == "0" ||
            shellEngine.isPackageMarkedDisabled("com.hihonor.hiboard")
        val noAutoUpdate = autoUpdate == "0"
        val noPowerGenius = shellEngine.isPackageMarkedDisabled("com.hihonor.powergenius") ||
            readSettingFast("system", "iaware_switch") == "0"
        val customSound = useDefaultSound == "0"
        val yoyoWakeOff = yoyoWake == "0" ||
            readSettingFast("secure", "yoyo_navigation_bar_wakeup") == "0"

        var score = 0
        if (isViLocale && isViTz) score++
        if (hasGms && hasPlay) score++
        if (hasLaban || hasGboard) score++
        if (callerIdOk && captiveOk) score++
        if (noChinaFeeds) score++
        if (noAutoUpdate) score++
        if (noPowerGenius) score++
        if (customSound) score++
        if (gpsOk) score++

        _setupStatus.value = NewDeviceSetupStatus(
            isVietnameseLocale = isViLocale,
            currentLocale = if (locale.isNotBlank() && locale != "null") locale else Locale.getDefault().toLanguageTag(),
            isVietnamTimezone = isViTz,
            currentTimezone = if (tz.isNotBlank() && tz != "null") tz else "Asia/Ho_Chi_Minh",
            is24HourFormat = time24 == "24" || android.text.format.DateFormat.is24HourFormat(context),
            gmsEnabled = hasGms,
            playStoreInstalled = hasPlay,
            labanKeyInstalled = hasLaban,
            gboardInstalled = hasGboard,
            callerId84Fixed = callerIdOk,
            captivePortalGlobal = captiveOk,
            volte5gUnlocked = volteOk,
            chineseUiCleaned = noChinaFeeds,
            honorMarketUpdateBlocked = noAutoUpdate,
            powerGeniusRemoved = noPowerGenius,
            customAppSoundsEnabled = customSound,
            yoyoNavWakeDisabled = yoyoWakeOff,
            gpsOptimized = gpsOk,
            readyScore = score
        )
        refreshTuneStatus()
    }

    suspend fun refreshShizukuInfo() = withContext(Dispatchers.IO) {
        val installed = shellEngine.isShizukuInstalled()
        val running = shellEngine.state.value.isShizukuRunning
        val granted = shellEngine.state.value.isShizukuPermissionGranted
        val isReady = shellEngine.state.value.isAdbReady

        var phantomMax = shellEngine.getPersistedSetting("global", "max_phantom_processes") ?: ""
        var chargingOnly = try {
            Settings.Global.getString(context.contentResolver, "adb_charging_only") ?: ""
        } catch (_: Exception) { "" }

        if (isReady && (phantomMax.isBlank() || chargingOnly.isBlank())) {
            val combined = runShell(
                "device_config get activity_manager max_phantom_processes 2>/dev/null; echo '---MT_SEP---'; settings get global adb_charging_only 2>/dev/null",
                false
            )
            val parts = combined.split("---MT_SEP---")
            if (parts.isNotEmpty() && phantomMax.isBlank()) {
                phantomMax = parts[0].trim()
            }
            if (parts.size >= 2 && chargingOnly.isBlank()) {
                chargingOnly = parts[1].trim()
            }
        }

        val adbWifiOn = shellEngine.state.value.isAdbWifiEnabled
        val dynamicVer = if (running) {
            try {
                val v = rikka.shizuku.Shizuku.getVersion()
                val p = rikka.shizuku.Shizuku.getServerPatchVersion()
                "v$v (Patch $p)"
            } catch (_: Exception) {
                "13.5+"
            }
        } else "13.5+"

        _shizukuInfo.value = ShizukuInfo(
            isInstalled = installed,
            isRunning = running,
            isPermissionGranted = granted,
            isAdbWifiEnabled = adbWifiOn,
            isShizukuSeveredFromAdb = false,
            version = dynamicVer,
            serverPid = if (running && granted) "UID 2000" else if (running) "Chờ cấp quyền" else if (shellEngine.state.value.isWirelessAdbConnected) "WLAN ADB" else "Chưa chạy",
            phantomKillerDisabled = phantomMax == "2147483647",
            usbChargingOnlyEnabled = chargingOnly == "1"
        )
    }

    /**
     * Loads BOTH User-Installed Apps (Ứng dụng người dùng) AND System/Honor Debloat Apps
     * so the user can view, manage, uninstall, freeze, or grant full permissions to User Apps as well as System Apps.
     * Protects critical ROM packages while classifying removable system apps into Levels 1, 2, and 3.
     */
    suspend fun refreshAppsList() = withContext(Dispatchers.IO) {
        val isAdb = shellEngine.state.value.isAdbReady
        var thirdPartyOutput = ""
        var disabledOutput = ""
        var systemOutput = ""

        if (isAdb) {
            val batchedPm = runShell(
                "pm list packages -3 --user 0 2>/dev/null; echo '---MT_DIS---'; pm list packages -d --user 0 2>/dev/null; echo '---MT_SYS---'; pm list packages -s --user 0 2>/dev/null",
                false
            )
            val s1 = batchedPm.split("---MT_DIS---")
            thirdPartyOutput = s1.getOrNull(0).orEmpty()
            val s2 = s1.getOrNull(1).orEmpty().split("---MT_SYS---")
            disabledOutput = s2.getOrNull(0).orEmpty()
            systemOutput = s2.getOrNull(1).orEmpty()
        }

        val combinedMap = LinkedHashMap<String, DebloatApp>()
        val pm = context.packageManager

        // 1. NẠP APP NGƯỜI DÙNG: Quét trực tiếp PackageManager (hoạt động 100% không phụ thuộc ADB)
        try {
            val installedApps = try {
                pm.getInstalledApplications(0)
            } catch (_: Throwable) {
                try {
                    pm.getInstalledPackages(0).mapNotNull { it.applicationInfo }
                } catch (_: Throwable) {
                    emptyList()
                }
            }

            for (appInfo in installedApps) {
                val pkg = appInfo.packageName ?: continue
                if (pkg == context.packageName) continue

                val isSys = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0 &&
                    (appInfo.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0

                val isUser = if (isAdb && thirdPartyOutput.isNotBlank()) {
                    !isSys || thirdPartyOutput.contains("package:$pkg")
                } else {
                    !isSys
                }

                val label = try {
                    pm.getApplicationLabel(appInfo).toString().ifBlank { pkg }
                } catch (_: Exception) { pkg }

                val isDis = !appInfo.enabled || (isAdb && (disabledOutput.contains("package:$pkg") || shellEngine.isPackageMarkedDisabled(pkg)))
                val isUninstalled = isAdb && shellEngine.isPackageMarkedUninstalled(pkg)

                if (isUser) {
                    val catalogEntry = commonUserAppsCatalog.find { it.first == pkg }?.second
                    val isNotifOk = shellEngine.isAppWhitelistedOrFixed(pkg) || shellEngine.isAppActuallyNotificationEnabled(pkg)
                    val isPermOk = shellEngine.isAppPermissionGranted(pkg) || shellEngine.isAppActuallyBackgroundWhitelisted(pkg)

                    combinedMap[pkg] = DebloatApp(
                        packageName = pkg,
                        name = catalogEntry?.first ?: label,
                        desc = catalogEntry?.second ?: "Ứng dụng người dùng cài đặt • Có thể Gỡ cài đặt hoặc Cấp full quyền & Biểu ngữ",
                        level = 0,
                        isInstalled = !isUninstalled,
                        isFrozen = isDis,
                        isUserApp = true,
                        isFullNotificationFixed = isNotifOk,
                        isFullPermissionGranted = isPermOk
                    )
                } else {
                    // System App tìm thấy trên máy:
                    if (CRITICAL_ROM_PACKAGES.contains(pkg) || pkg.startsWith("com.android.server") || pkg.startsWith("com.android.internal")) {
                        continue
                    }
                    val known = knownDebloatApps.find { it.packageName == pkg }
                    if (known != null) {
                        combinedMap[pkg] = known.copy(
                            isInstalled = !isUninstalled,
                            isFrozen = isDis,
                            isUserApp = false,
                            isFullNotificationFixed = shellEngine.isAppWhitelistedOrFixed(pkg),
                            isFullPermissionGranted = shellEngine.isAppPermissionGranted(pkg)
                        )
                    } else if (isAdb) {
                        val (level, sysName, sysDesc) = classifySystemApp(pkg, label)
                        combinedMap[pkg] = DebloatApp(
                            packageName = pkg,
                            name = sysName,
                            desc = sysDesc,
                            level = level,
                            isInstalled = !isUninstalled,
                            isFrozen = isDis,
                            isUserApp = false,
                            isFullNotificationFixed = shellEngine.isAppWhitelistedOrFixed(pkg),
                            isFullPermissionGranted = shellEngine.isAppPermissionGranted(pkg),
                            causesNotificationDelay = isAppCausingNotificationDelay(pkg)
                        )
                    }
                }
            }
        } catch (_: Exception) {}

        // 2. LUÔN NẠP ĐẦY ĐỦ CÁC APP RÁC HỆ THỐNG TRONG knownDebloatApps (KỂ CẢ KHI CHƯA CÓ ADB)
        // Giúp các tab Cấp 1, Cấp 2, Cấp 3 LUÔN ĐẦY ĐỦ VÀ KHÔNG BAO GIỜ BỊ TRỐNG TRƠN!
        for (sysApp in knownDebloatApps) {
            val pkg = sysApp.packageName
            if (CRITICAL_ROM_PACKAGES.contains(pkg)) continue
            if (!combinedMap.containsKey(pkg)) {
                val appInfo = try {
                    pm.getApplicationInfo(pkg, 0)
                } catch (_: Throwable) { null }

                val isDis = appInfo?.enabled == false || disabledOutput.contains("package:$pkg") || shellEngine.isPackageMarkedDisabled(pkg)
                val isUninstalled = shellEngine.isPackageMarkedUninstalled(pkg)
                val isInst = (appInfo != null || (isAdb && systemOutput.contains("package:$pkg"))) && !isUninstalled

                if (appInfo != null || (isAdb && systemOutput.contains("package:$pkg")) || isUninstalled || isDis) {
                    combinedMap[pkg] = sysApp.copy(
                        isInstalled = isInst,
                        isFrozen = isDis,
                        isUserApp = false,
                        isFullNotificationFixed = shellEngine.isAppWhitelistedOrFixed(pkg),
                        isFullPermissionGranted = shellEngine.isAppPermissionGranted(pkg)
                    )
                }
            } else {
                val existing = combinedMap[pkg]!!
                combinedMap[pkg] = existing.copy(
                    name = sysApp.name,
                    desc = sysApp.desc,
                    level = sysApp.level,
                    causesNotificationDelay = sysApp.causesNotificationDelay
                )
            }
        }

        // 3. KHI CÓ ADB: Bổ sung thêm các gói third-party và system từ shell output
        if (isAdb) {
            val thirdPartyPkgs = thirdPartyOutput.lineSequence()
                .map { it.removePrefix("package:").trim() }
                .filter { it.isNotBlank() && it != context.packageName }
                .toList()

            for (pkg in thirdPartyPkgs) {
                if (!combinedMap.containsKey(pkg)) {
                    val catalogEntry = commonUserAppsCatalog.find { it.first == pkg }?.second
                    val readableName = catalogEntry?.first ?: pkg.substringAfterLast('.').replaceFirstChar { it.uppercase() }
                    val isDis = disabledOutput.contains("package:$pkg") || shellEngine.isPackageMarkedDisabled(pkg)
                    val isUninstalled = shellEngine.isPackageMarkedUninstalled(pkg)
                    val isNotifOk = shellEngine.isAppWhitelistedOrFixed(pkg) || shellEngine.isAppActuallyNotificationEnabled(pkg)
                    val isPermOk = shellEngine.isAppPermissionGranted(pkg) || shellEngine.isAppActuallyBackgroundWhitelisted(pkg)
                    combinedMap[pkg] = DebloatApp(
                        packageName = pkg,
                        name = readableName,
                        desc = catalogEntry?.second ?: "Ứng dụng người dùng cài đặt trên máy",
                        level = 0,
                        isInstalled = !isUninstalled,
                        isFrozen = isDis,
                        isUserApp = true,
                        isFullNotificationFixed = isNotifOk,
                        isFullPermissionGranted = isPermOk,
                        causesNotificationDelay = false
                    )
                }
            }

            val sysPkgs = systemOutput.lineSequence()
                .map { it.removePrefix("package:").trim() }
                .filter { it.isNotBlank() && it != context.packageName && !CRITICAL_ROM_PACKAGES.contains(it) && !it.startsWith("com.android.server") && !it.startsWith("com.android.internal") }
                .toList()

            for (pkg in sysPkgs) {
                if (!combinedMap.containsKey(pkg)) {
                    val (level, sysName, sysDesc) = classifySystemApp(pkg, "")
                    val isDis = disabledOutput.contains("package:$pkg") || shellEngine.isPackageMarkedDisabled(pkg)
                    val isUninstalled = shellEngine.isPackageMarkedUninstalled(pkg)
                    combinedMap[pkg] = DebloatApp(
                        packageName = pkg,
                        name = sysName,
                        desc = sysDesc,
                        level = level,
                        isInstalled = !isUninstalled,
                        isFrozen = isDis,
                        isUserApp = false,
                        isFullNotificationFixed = shellEngine.isAppWhitelistedOrFixed(pkg),
                        isFullPermissionGranted = shellEngine.isAppPermissionGranted(pkg),
                        causesNotificationDelay = isAppCausingNotificationDelay(pkg)
                    )
                }
            }
        }

        // 4. BẢO VỆ DANH SÁCH: Chỉ cập nhật khi có dữ liệu, tuyệt đối không bao giờ ghi đè danh sách rỗng!
        if (combinedMap.isNotEmpty()) {
            _appsList.value = combinedMap.values.sortedWith(
                compareBy<DebloatApp> { app ->
                    when {
                        app.isUserApp && app.isInstalled && !app.isFrozen && (!app.isFullNotificationFixed || !app.isFullPermissionGranted) -> 0
                        !app.isUserApp && app.isInstalled && !app.isFrozen && app.level == 1 -> 1
                        app.isUserApp && app.isInstalled && !app.isFrozen -> 2
                        !app.isUserApp && app.isInstalled && !app.isFrozen && app.level == 2 -> 3
                        !app.isUserApp && app.isInstalled && !app.isFrozen && app.level == 3 -> 4
                        else -> 5
                    }
                }.thenBy { it.name.lowercase() }
            )
        }
    }

    // -------------------------------------------------------------
    // QUÉT CHẨN ĐOÁN TOÀN DIỆN (DEEP DIAGNOSTIC SCANNER)
    // Quét nguyên nhân chậm thông báo, app báo nhẹ nhàng/thiếu biểu ngữ, app thiếu quyền
    // -------------------------------------------------------------
    suspend fun resetAndRescanNotifications(): DiagnosticScanResult = withContext(Dispatchers.IO) {
        log("🔄 Đang xóa bộ đệm trạng thái thông báo cũ và quét lại thực tế toàn bộ ứng dụng trên máy...", LogType.INFO)
        shellEngine.resetNotificationScanCache()
        runDiagnosticScan()
    }

    suspend fun runDiagnosticScan(
        skipAppsAndSetupRefresh: Boolean = false,
        silentLog: Boolean = false
    ): DiagnosticScanResult = withContext(Dispatchers.IO) {
        _diagnosticScan.value = _diagnosticScan.value.copy(isScanning = true)
        if (!silentLog) {
            log("🔍 Bắt đầu Quét Chẩn Đoán Thực Tế: Kiểm tra kênh thông báo (dumpsys notification), công tắc Báo nhẹ nhàng, Biểu ngữ & Quyền chạy ngầm...", LogType.INFO)
        }

        if (!skipAppsAndSetupRefresh) {
            refreshAppsList()
            refreshSetupStatus()
        }

        val powerGeniusDisabled = shellEngine.isPackageMarkedDisabled("com.hihonor.powergenius") ||
            shellEngine.getPersistedSetting("system", "iaware_switch") == "0"
        val gentleDisabled = shellEngine.getPersistedSetting("system", "gentle_notification_enabled") == "0" &&
            shellEngine.getPersistedSetting("global", "heads_up_notifications_enabled") == "1"
        val batchingZero = shellEngine.getPersistedSetting("global", "job_scheduler_constants")?.contains("max_non_active_job_batch_delay_ms=0") == true
        val customSoundOk = shellEngine.getPersistedSetting("system", "use_default_notification_sound") == "0"
        val updateBlocked = shellEngine.getPersistedSetting("global", "auto_update_app") == "0"
        val yoyoWakeOff = shellEngine.getPersistedSetting("secure", "navigation_bar_wakeup_yoyo") == "0" ||
            shellEngine.getPersistedSetting("secure", "yoyo_navigation_bar_wakeup") == "0"

        val systemCauses = listOf(
            DiagnosticIssue(
                id = "power_genius",
                title = "Trình diệt ngầm PowerGenius & iAware AI",
                description = if (powerGeniusDisabled) "Đã vô hiệu hóa PowerGenius & iAware" else "Đang chạy ngầm và tự động tắt Zalo, Messenger, Facebook sau 3 phút khóa màn hình",
                isFixed = powerGeniusDisabled,
                fixCommandTag = "fix_power_genius"
            ),
            DiagnosticIssue(
                id = "gentle_banner",
                title = "Chế độ 'Báo nhẹ nhàng' & Tắt biểu ngữ nổi hệ thống",
                description = if (gentleDisabled) "Đã tắt Báo nhẹ nhàng & Bật đầy đủ Biểu ngữ (Heads-up Banner)" else "MagicOS đang xếp thông báo vào mục 'Báo nhẹ nhàng' (không đổ chuông, không hiện biểu ngữ nổi)",
                isFixed = gentleDisabled,
                fixCommandTag = "fix_gentle_banner"
            ),
            DiagnosticIssue(
                id = "job_batching",
                title = "Gom cụm thông báo trễ 15-30 phút (JobScheduler / TARE)",
                description = if (batchingZero) "Đã phá bỏ gom cụm (Độ trễ 0 giây)" else "Hệ thống đang gom thông báo Gmail, Facebook lại 15-30 phút mới đẩy 1 lần",
                isFixed = batchingZero,
                fixCommandTag = "fix_batching"
            ),
            DiagnosticIssue(
                id = "custom_sound",
                title = "Tự động hạ chuông / Gộp chung 1 tiếng chuông câm",
                description = if (customSoundOk) "Đã ưu tiên chuông riêng từng ứng dụng" else "Chưa bật ưu tiên chuông riêng từng App & chống hạ âm lượng thông báo",
                isFixed = customSoundOk,
                fixCommandTag = "fix_sound"
            ),
            DiagnosticIssue(
                id = "auto_update",
                title = "Tự động cập nhật ROM & Chợ App Honor đè app Việt",
                description = if (updateBlocked) "Đã chặn tự động cập nhật ngầm" else "Chợ App Honor có thể tự cập nhật ngầm đè Zalo/FB sang bản nội địa gây mất thông báo",
                isFixed = updateBlocked,
                fixCommandTag = "fix_update"
            ),
            DiagnosticIssue(
                id = "yoyo_wake",
                title = "Công tắc nhấn thanh điều hướng đánh thức YOYO",
                description = if (yoyoWakeOff) "Đã tắt đánh thức YOYO trên thanh điều hướng" else "Nhấn giữ thanh điều hướng dưới đáy màn hình vẫn gọi trợ lý YOYO tiếng Trung",
                isFixed = yoyoWakeOff,
                fixCommandTag = "fix_yoyo"
            )
        )

        val userApps = _appsList.value.filter { it.isUserApp && it.isInstalled && !it.isFrozen }

        // Đọc trực tiếp kênh thông báo từ dumpsys notification khi Shizuku sẵn sàng
        val channelMap = if (shellEngine.state.value.isAdbReady && userApps.isNotEmpty()) {
            try {
                val dumpRes = shellEngine.execute("dumpsys notification --noredact 2>/dev/null || dumpsys notification 2>/dev/null")
                com.example.core.shell.UiAutomatorSwitchHelper.parseDumpsysNotificationChannels(
                    dumpRes.output,
                    userApps.map { it.packageName }.toSet()
                )
            } catch (_: Exception) {
                emptyMap()
            }
        } else {
            emptyMap()
        }

        // Bảng xếp hạng ưu tiên các app nhắn tin / mạng xã hội / ngân hàng quan trọng lên đầu
        val priorityKeywords = listOf(
            "zalo", "zing.zalo", "facebook", "katana", "orca", "messenger",
            "telegram", "whatsapp", "viber", "tiktok", "trill", "shopee",
            "lazada", "gm", "gmail", "bank", "vcb", "mb", "tcb", "bidv", "acb", "momo", "zalopay"
        )

        val appDiagnostics = userApps.map { app ->
            val pkg = app.packageName
            val chStatus = channelMap[pkg]

            val lowerPkg = pkg.lowercase()
            val lowerName = app.name.lowercase()
            val isKnownNotificationApp = priorityKeywords.any { lowerPkg.contains(it) || lowerName.contains(it) } ||
                lowerPkg.contains("chat") || lowerPkg.contains("msg") || lowerPkg.contains("call") || lowerPkg.contains("mail") ||
                lowerPkg.contains("news") || lowerPkg.contains("social") || lowerPkg.contains("game")

            val appUsesNotifications = isKnownNotificationApp || (chStatus != null && chStatus.foundInDumpsys)

            if (!appUsesNotifications) {
                // Nếu ứng dụng không có chức năng thông báo, tự động coi là đã đủ 100% thay vì báo thiếu
                AppNotificationDiagnostic(
                    packageName = pkg,
                    appName = app.name,
                    isUserApp = true,
                    hasGentleNotification = false,
                    hasBannerEnabled = true,
                    hasBackgroundPermission = true,
                    hasBatteryExemption = true,
                    hasOverlayPermission = true,
                    statusSummary = "✅ App không dùng chức năng thông báo (Đủ điều kiện)"
                )
            } else {
                val uiToggled = shellEngine.isAppVisuallyUiToggled(pkg)
                val dumpsysHasGentleOrMissingBanner = chStatus != null && chStatus.needsGentleOrBannerFix
                val notifFixed = uiToggled || !dumpsysHasGentleOrMissingBanner

                val realBgOptimized = shellEngine.isAppActuallyBackgroundWhitelisted(pkg)
                val permFixed = shellEngine.isAppPermissionGranted(pkg) || realBgOptimized

                AppNotificationDiagnostic(
                    packageName = pkg,
                    appName = app.name,
                    isUserApp = true,
                    hasGentleNotification = !notifFixed,
                    hasBannerEnabled = notifFixed,
                    hasBackgroundPermission = permFixed,
                    hasBatteryExemption = permFixed,
                    hasOverlayPermission = permFixed,
                    statusSummary = when {
                        notifFixed && permFixed -> "✅ Đã bật Biểu ngữ nổi & Full Quyền hệ thống"
                        !notifFixed && !permFixed -> "⚠️ Còn Báo nhẹ nhàng / Chưa gạt công tắc Biểu ngữ & Thiếu quyền ngầm"
                        !notifFixed -> "⚠️ Còn Báo nhẹ nhàng / Chưa gạt công tắc Biểu ngữ (Bấm 'Fix Âm Thầm')"
                        else -> "⚠️ Thiếu quyền chạy ngầm / Pin không hạn chế"
                    }
                )
            }
        }

        // Ưu tiên đẩy các ứng dụng gặp vấn đề (đặc biệt là Zalo, Messenger, FB, Gmail, Shopee, TikTok...) lên đầu danh sách
        val sortedSystemCauses = systemCauses.sortedBy { it.isFixed }
        val sortedGentleAndBannerApps = appDiagnostics.sortedWith(
            compareBy<AppNotificationDiagnostic> { !it.hasAnyNotificationIssue }
                .thenBy { diag ->
                    val lower = (diag.packageName + " " + diag.appName).lowercase()
                    priorityKeywords.none { lower.contains(it) }
                }
                .thenBy { !it.hasAnyPermissionIssue }
                .thenBy { it.appName.lowercase() }
        )
        val sortedMissingPermApps = appDiagnostics.sortedWith(
            compareBy<AppNotificationDiagnostic> { !it.hasAnyPermissionIssue }
                .thenBy { !it.hasAnyNotificationIssue }
                .thenBy { it.appName.lowercase() }
        )

        val scanResult = DiagnosticScanResult(
            isScanning = false,
            hasScanned = true,
            lastScanTime = formatNow(),
            systemDelayCauses = sortedSystemCauses,
            gentleAndBannerApps = sortedGentleAndBannerApps,
            missingPermissionApps = sortedMissingPermApps,
            allScannedAppsCount = userApps.size
        )

        _diagnosticScan.value = scanResult
        if (!silentLog) {
            log(
                "✅ Quét hoàn tất ${userApps.size} ứng dụng: Phát hiện ${scanResult.unfixedGentleBannerCount} app còn Báo nhẹ nhàng/chưa bật Biểu ngữ, ${scanResult.unfixedPermissionCount} app thiếu quyền chạy ngầm, ${scanResult.unfixedSystemCausesCount} nguyên nhân hệ thống.",
                if (scanResult.totalRemainingIssues == 0) LogType.SUCCESS else LogType.INFO
            )
        }
        scanResult
    }

    /**
     * Tạo danh sách lệnh gạt TẤT CẢ các công tắc quyền thực tế trên máy cho một ứng dụng:
     * 1. Tự động quét danh sách quyền Runtime mà ứng dụng khai báo trong AndroidManifest (`GET_PERMISSIONS`)
     *    để chạy `pm grant` bật công tắc thực sự trong `Cài đặt -> Ứng dụng -> Quyền` (Thông báo, Vị trí, Máy ảnh, Micro, Danh bạ, Bộ nhớ/Ảnh, Điện thoại, Bluetooth...).
     * 2. Bật công tắc AppOps ở cả cấp Package lẫn `--uid` (vì giao diện Cài đặt của Android 12–16 / MagicOS kiểm tra theo UID mode):
     *    - `POST_NOTIFICATION` (Công tắc Cho phép thông báo)
     *    - `SYSTEM_ALERT_WINDOW` (Công tắc Hiển thị trên ứng dụng khác / Cửa sổ nổi)
     *    - `RUN_IN_BACKGROUND` & `RUN_ANY_IN_BACKGROUND` (Công tắc Cho phép chạy nền / Pin không hạn chế)
     *    - `SCHEDULE_EXACT_ALARM` (Công tắc Báo thức & lời nhắc)
     *    - `WRITE_SETTINGS` & `ACCESS_RESTRICTED_SETTINGS`
     * 3. Đưa ứng dụng vào Doze Whitelist (`cmd deviceidle whitelist +pkg` & `dumpsys deviceidle whitelist +pkg`) và Active Standby Bucket.
     */
    private fun buildAppSwitchGrantCommands(pkg: String): List<String> {
        val cmds = mutableListOf(
            // 1. Phá rào cản pin Doze & Đặt mức ưu tiên chạy nền cao nhất (Active Standby Bucket)
            "cmd deviceidle whitelist +$pkg >/dev/null 2>&1; dumpsys deviceidle whitelist +$pkg >/dev/null 2>&1",
            "am set-standby-bucket $pkg active >/dev/null 2>&1; am set-inactive $pkg false >/dev/null 2>&1",

            // 2. BẬT FULL THÔNG BÁO CHO APP TRÊN HONOR MAGICOS (Chuông, Rung, Biểu ngữ nổi, Màn hình khóa):
            "cmd notification set_bubbles $pkg 1 >/dev/null 2>&1",
            "cmd appops set $pkg POST_NOTIFICATION allow >/dev/null 2>&1; cmd appops set --uid $pkg POST_NOTIFICATION allow >/dev/null 2>&1",

            // 3. Công tắc Chạy nền / Tự khởi chạy / Liên kết khởi chạy chuẩn MagicOS (Không bị PowerGenius & iAware đóng băng):
            "cmd appops set $pkg RUN_IN_BACKGROUND allow >/dev/null 2>&1; cmd appops set --uid $pkg RUN_IN_BACKGROUND allow >/dev/null 2>&1",
            "cmd appops set $pkg RUN_ANY_IN_BACKGROUND allow >/dev/null 2>&1; cmd appops set --uid $pkg RUN_ANY_IN_BACKGROUND allow >/dev/null 2>&1",
            "cmd appops set $pkg AUTO_REVOKE_PERMISSIONS_IF_UNUSED ignore >/dev/null 2>&1",

            // 4. Công tắc Cửa sổ nổi / Hiển thị trên app khác (Cần cho bong bóng chat Zalo, Messenger, biểu tượng cuộc gọi):
            "cmd appops set $pkg SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1; cmd appops set --uid $pkg SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1",

            // 5. Bật toàn bộ công tắc tính năng nâng cao & báo thức chính xác (FCM realtime 0s delay):
            "cmd appops set $pkg WAKE_LOCK allow >/dev/null 2>&1; cmd appops set --uid $pkg WAKE_LOCK allow >/dev/null 2>&1",
            "cmd appops set $pkg SCHEDULE_EXACT_ALARM allow >/dev/null 2>&1; cmd appops set --uid $pkg SCHEDULE_EXACT_ALARM allow >/dev/null 2>&1",
            "cmd appops set $pkg USE_EXACT_ALARM allow >/dev/null 2>&1 || true",
            "cmd appops set $pkg START_FOREGROUND allow >/dev/null 2>&1; cmd appops set --uid $pkg START_FOREGROUND allow >/dev/null 2>&1",
            "cmd appops set $pkg ACCESS_RESTRICTED_SETTINGS allow >/dev/null 2>&1; cmd appops set --uid $pkg ACCESS_RESTRICTED_SETTINGS allow >/dev/null 2>&1",
            "cmd appops set $pkg GET_USAGE_STATS allow >/dev/null 2>&1; cmd appops set --uid $pkg GET_USAGE_STATS allow >/dev/null 2>&1",
            "cmd appops set $pkg VIBRATE allow >/dev/null 2>&1"
        )

        // Tự động đọc các quyền Runtime thực tế mà app yêu cầu để gạt công tắc trong Cài đặt -> Ứng dụng -> Quyền sang BẬT
        val grantableRuntimePermissions = setOf(
            "android.permission.POST_NOTIFICATIONS",
            "android.permission.ACCESS_FINE_LOCATION",
            "android.permission.ACCESS_COARSE_LOCATION",
            "android.permission.ACCESS_BACKGROUND_LOCATION",
            "android.permission.CAMERA",
            "android.permission.RECORD_AUDIO",
            "android.permission.READ_CONTACTS",
            "android.permission.WRITE_CONTACTS",
            "android.permission.GET_ACCOUNTS",
            "android.permission.READ_CALENDAR",
            "android.permission.WRITE_CALENDAR",
            "android.permission.READ_CALL_LOG",
            "android.permission.WRITE_CALL_LOG",
            "android.permission.READ_PHONE_STATE",
            "android.permission.READ_PHONE_NUMBERS",
            "android.permission.CALL_PHONE",
            "android.permission.ANSWER_PHONE_CALLS",
            "android.permission.SEND_SMS",
            "android.permission.RECEIVE_SMS",
            "android.permission.READ_SMS",
            "android.permission.READ_EXTERNAL_STORAGE",
            "android.permission.WRITE_EXTERNAL_STORAGE",
            "android.permission.READ_MEDIA_IMAGES",
            "android.permission.READ_MEDIA_VIDEO",
            "android.permission.READ_MEDIA_AUDIO",
            "android.permission.READ_MEDIA_VISUAL_USER_SELECTED",
            "android.permission.BLUETOOTH_CONNECT",
            "android.permission.BLUETOOTH_SCAN",
            "android.permission.BLUETOOTH_ADVERTISE",
            "android.permission.NEARBY_WIFI_DEVICES",
            "android.permission.ACTIVITY_RECOGNITION",
            "android.permission.BODY_SENSORS"
        )

        try {
            @Suppress("DEPRECATION")
            val pkgInfo = context.packageManager.getPackageInfo(pkg, PackageManager.GET_PERMISSIONS)
            val requested = pkgInfo.requestedPermissions ?: emptyArray()
            for (perm in requested) {
                if (perm in grantableRuntimePermissions) {
                    cmds.add("pm grant --user 0 $pkg $perm >/dev/null 2>&1 || pm grant $pkg $perm >/dev/null 2>&1")
                } else if (perm == "android.permission.WRITE_SETTINGS") {
                    cmds.add("cmd appops set $pkg WRITE_SETTINGS allow >/dev/null 2>&1; cmd appops set --uid $pkg WRITE_SETTINGS allow >/dev/null 2>&1")
                } else if (perm == "android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS") {
                    cmds.add("cmd appops set $pkg REQUEST_INSTALL_PACKAGES allow >/dev/null 2>&1; cmd appops set --uid $pkg REQUEST_INSTALL_PACKAGES allow >/dev/null 2>&1")
                }
            }
        } catch (_: Exception) {
            cmds.add("pm grant --user 0 $pkg android.permission.POST_NOTIFICATIONS >/dev/null 2>&1 || pm grant $pkg android.permission.POST_NOTIFICATIONS >/dev/null 2>&1")
        }

        return cmds
    }

    /**
     * Fixes a single app's Gentle Notification, enables Full Banners (Heads-up + Lockscreen),
     * and grants full background/battery/overlay/runtime permissions so switches on the phone actually flip ON.
     */
    /**
     * Fixes a single app's Gentle Notification, enables Full Banners (Heads-up + Lockscreen),
     * grants full background/battery/overlay/runtime permissions, AND opens the app's Notification Settings
     * screen to physically flip the "Thông báo nhẹ nhàng" (OFF) & "Biểu ngữ" (ON) switches right before the user's eyes!
     */
    suspend fun fixSingleAppGentleAndPermissions(pkg: String, appName: String): Boolean = withContext(Dispatchers.IO) {
        log("🔔 Đang cấp full quyền chạy ngầm & tự động mở Cài đặt Thông báo của $appName ($pkg) để gạt công tắc tận mắt...", LogType.INFO)
        if (!shellEngine.hasOverlayPermission() || !shellEngine.hasControlPermission()) {
            grantSelfControlAndOverlayPermissions()
        }

        val cmds = mutableListOf(
            "pm disable-user --user 0 com.hihonor.powergenius",
            "settings put system gentle_notification_enabled 0",
            "settings put system hw_notification_gentle_switch 0",
            "settings put global heads_up_notifications_enabled 1",
            "settings put system notification_banner_enabled 1",
            "settings put secure lock_screen_show_notifications 1",
            "settings put secure lock_screen_allow_private_notifications 1",
            "settings put system lock_screen_show_notifications 1",
            "settings put system lock_screen_details_notification 1",
            "settings put system use_default_notification_sound 0",
            "settings put system notification_cooldown_enabled 0",
            "cmd appops set com.hihonor.systemmanager GET_USAGE_STATS ignore"
        )
        cmds.addAll(buildAppSwitchGrantCommands(pkg))

        val ok = runVerifiedBatch("Cấp Full Quyền Chạy Ngầm & Pin: $appName", cmds)
        if (ok) {
            shellEngine.markAppNotificationFixed(pkg, true)
        }

        // Hiển thị PiP HUD nổi trực tiếp trên màn hình Cài đặt Android
        val initHudState = FloatingMiniWindowState(
            isVisible = true,
            isMinimizedBubble = false,
            isRunningAutomation = true,
            currentStep = 1,
            totalSteps = 1,
            currentAppName = appName,
            currentPackageName = pkg,
            currentActionDetail = "👁️ Đang mở Cài đặt Thông báo của $appName...",
            completedApps = emptyList(),
            hasOverlayPermission = shellEngine.hasOverlayPermission(),
            hasControlPermission = shellEngine.hasControlPermission()
        )
        _floatingWindowState.value = initHudState
        com.example.core.service.SystemFloatingHudOverlay.updateAutomationHud(
            context = context,
            state = initHudState,
            onStopClick = { stopLiveFloatingAutomation() }
        )

        // Tự động mở trang Cài đặt Thông báo của ứng dụng và dùng UIAutomator + input tap gạt công tắc tận mắt người dùng
        val uiReport = com.example.core.shell.UiAutomatorSwitchHelper.autoToggleAppNotificationScreen(
            shellEngine = shellEngine,
            pkg = pkg,
            appName = appName,
            pressBackWhenDone = false,
            onProgressUpdate = { stepMsg ->
                val updated = _floatingWindowState.value.copy(currentActionDetail = stepMsg)
                _floatingWindowState.value = updated
                com.example.core.service.SystemFloatingHudOverlay.updateAutomationHud(
                    context = context,
                    state = updated,
                    onStopClick = { stopLiveFloatingAutomation() }
                )
            },
            onLog = { msg -> log(msg, LogType.INFO) }
        )
        if (uiReport.openedSettingsOk) {
            shellEngine.markAppVisuallyUiToggled(pkg, true)
        }

        com.example.core.service.SystemFloatingHudOverlay.hideAutomationHud(context)
        _floatingWindowState.value = _floatingWindowState.value.copy(
            isVisible = false,
            isRunningAutomation = false
        )

        // Đưa người dùng quay lại màn hình MagicTune mượt mà không trễ hoạt ảnh
        shellEngine.execute("am start --activity-clear-top --activity-single-top --activity-no-animation -n ${context.packageName}/com.example.MainActivity >/dev/null 2>&1 || true")

        refreshAppsList()
        runDiagnosticScan()
        ok && uiReport.openedSettingsOk
    }

    suspend fun grantSelfControlAndOverlayPermissions(): Boolean = withContext(Dispatchers.IO) {
        val myPkg = context.packageName
        log("🔑 Đang cấp Quyền Hiển Thị Trên Ứng Dụng Khác (PiP Overlay) & Quyền Điều Khiển Hệ Thống cho MagicTune ($myPkg)...", LogType.INFO)
        
        // 1. Chạy cơ chế tự cấp quyền nâng cao của ShellEngine (UID 2000)
        shellEngine.autoGrantSelfPermissions()
        
        val cmds = listOf(
            "pm grant --user 0 $myPkg android.permission.WRITE_SECURE_SETTINGS >/dev/null 2>&1 || pm grant $myPkg android.permission.WRITE_SECURE_SETTINGS >/dev/null 2>&1",
            "pm grant --user 0 $myPkg android.permission.POST_NOTIFICATIONS >/dev/null 2>&1 || pm grant $myPkg android.permission.POST_NOTIFICATIONS >/dev/null 2>&1",
            "cmd appops set $myPkg SCHEDULE_EXACT_ALARM allow",
            "cmd appops set $myPkg SYSTEM_ALERT_WINDOW allow",
            "cmd appops set $myPkg PICTURE_IN_PICTURE allow",
            "cmd appops set $myPkg PROJECT_MEDIA allow",
            "cmd appops set $myPkg WRITE_SETTINGS allow",
            "cmd appops set $myPkg GET_USAGE_STATS allow",
            "cmd appops set $myPkg POST_NOTIFICATION allow",
            "cmd appops set $myPkg WAKE_LOCK allow",
            "cmd appops set $myPkg START_FOREGROUND allow",
            "cmd appops set $myPkg TURN_SCREEN_ON allow",
            "cmd deviceidle whitelist +$myPkg >/dev/null 2>&1; dumpsys deviceidle whitelist +$myPkg >/dev/null 2>&1",
            "am set-standby-bucket $myPkg active",
            "settings put system iaware_switch 0",
            "settings put global iaware_switch 0"
        )
        val ok = runVerifiedBatch("Cấp Quyền PiP Overlay & Điều Khiển Hệ Thống", cmds)
        shellEngine.markPersistentGrantActive()
        com.example.core.service.SystemFloatingHudOverlay.syncNavBarBridge(context)
        refreshFloatingPermissionsState()
        ok
    }

    fun setFloatingMiniWindowVisible(visible: Boolean) {
        if (!visible) {
            cancelVisualAutomation = true
            com.example.core.service.SystemFloatingHudOverlay.hideAutomationHud(context)
        }
        refreshFloatingPermissionsState()
        _floatingWindowState.value = _floatingWindowState.value.copy(
            isVisible = visible,
            isMinimizedBubble = false
        )
    }

    fun setFloatingMiniWindowMinimized(minimized: Boolean) {
        _floatingWindowState.value = _floatingWindowState.value.copy(
            isMinimizedBubble = minimized
        )
    }

    @Volatile
    private var cancelVisualAutomation: Boolean = false

    fun stopLiveFloatingAutomation() {
        cancelVisualAutomation = true
        com.example.core.service.SystemFloatingHudOverlay.hideAutomationHud(context)
        _floatingWindowState.value = _floatingWindowState.value.copy(
            isRunningAutomation = false,
            currentActionDetail = "⏹ Đã dừng quá trình tự động gạt công tắc theo yêu cầu."
        )
    }

    /**
     * Opens the System Floating PiP HUD on top of Android Settings and visually opens each problematic app's
     * Notification Settings page on Honor MagicOS, physically tapping "Thông báo nhẹ nhàng" -> OFF and
     * "Biểu ngữ" -> ON right in front of the user's eyes with Turbo zero-animation speed!
     */
    suspend fun runLiveFloatingMiniWindowAutomation(): Boolean = withContext(Dispatchers.IO) {
        cancelVisualAutomation = false
        // 1. Luôn đảm bảo cấp đầy đủ quyền SYSTEM_ALERT_WINDOW + PICTURE_IN_PICTURE + WRITE_SECURE_SETTINGS trước khi mở Cài đặt
        grantSelfControlAndOverlayPermissions()
        val scan = runDiagnosticScan()

        val problematicDiagnostics = scan.gentleAndBannerApps.filter {
            it.hasAnyNotificationIssue || it.hasAnyPermissionIssue
        }
        val unfixedCauses = scan.systemDelayCauses.filter { !it.isFixed }

        if (problematicDiagnostics.isEmpty() && unfixedCauses.isEmpty()) {
            log("🎉 KIỂM TRA TRƯỚC KHI FIX: Toàn bộ ${scan.allScannedAppsCount} ứng dụng đều đã gạt tắt Báo nhẹ nhàng, bật Biểu ngữ & đủ quyền! (Nếu bạn muốn gạt lại tận mắt từ đầu, hãy bấm nút '🔄 Xóa Đệm & Quét Lại').", LogType.SUCCESS)
            com.example.core.service.SystemFloatingHudOverlay.hideAutomationHud(context)
            _floatingWindowState.value = FloatingMiniWindowState(
                isVisible = true,
                isMinimizedBubble = false,
                isRunningAutomation = false,
                currentStep = 1,
                totalSteps = 1,
                currentAppName = "100% Ứng dụng Đã Tốt (${scan.allScannedAppsCount} app)",
                currentPackageName = context.packageName,
                currentActionDetail = "✅ Tất cả ứng dụng đã được gạt công tắc chuẩn. Bấm 'Xóa Đệm & Quét Lại' nếu muốn chạy gạt tận mắt lại từ đầu.",
                completedApps = emptyList(),
                hasOverlayPermission = shellEngine.hasOverlayPermission(),
                hasControlPermission = shellEngine.hasControlPermission()
            )
            return@withContext true
        }

        // Giữ đúng thứ tự ưu tiên (Zalo, Messenger, FB, Gmail, Shopee, TikTok... lên đầu) từ kết quả quét
        val targetApps = problematicDiagnostics

        val totalSteps = targetApps.size + 1
        val completed = mutableListOf<String>()
        var stepCounter = 1

        val initialHudState = FloatingMiniWindowState(
            isVisible = true,
            isMinimizedBubble = false,
            isRunningAutomation = true,
            currentStep = stepCounter,
            totalSteps = totalSteps,
            currentAppName = "Hệ thống MagicOS / Android",
            currentPackageName = "android.system",
            currentActionDetail = "⚡ Đang cấp quyền nền hàng loạt & chuẩn bị gạt công tắc tận mắt cho ${targetApps.size} ứng dụng...",
            completedApps = emptyList(),
            hasOverlayPermission = shellEngine.hasOverlayPermission(),
            hasControlPermission = shellEngine.hasControlPermission()
        )
        _floatingWindowState.value = initialHudState
        com.example.core.service.SystemFloatingHudOverlay.updateAutomationHud(
            context = context,
            state = initialHudState,
            onStopClick = { stopLiveFloatingAutomation() }
        )

        // Step 1: Gộp chung mở khóa Biểu ngữ hệ thống + cấp quyền chạy ngầm/pin cho TẤT CẢ targetApps trong 1 batch duy nhất
        // để khi bắt đầu mở Cài đặt của từng app, màn hình chuyển đổi liên hoàn mượt mà không phải chờ lệnh ngầm giữa chừng!
        val preBatchCmds = mutableListOf(
            "pm disable-user --user 0 com.hihonor.powergenius",
            "settings put system iaware_switch 0",
            "settings put global iaware_switch 0",
            "settings put system gentle_notification_enabled 0",
            "settings put system hw_notification_gentle_switch 0",
            "settings put global heads_up_notifications_enabled 1",
            "settings put system notification_banner_enabled 1",
            "settings put system lock_screen_notification_style 0",
            "settings put system lock_screen_details_notification 1",
            "settings put secure lock_screen_show_notifications 1",
            "settings put secure lock_screen_allow_private_notifications 1",
            "settings put system lock_screen_show_notifications 1",
            "settings put system use_default_notification_sound 0",
            "settings put system notification_cooldown_enabled 0",
            "settings put global job_scheduler_constants \"min_ready_non_active_jobs_count=1,max_non_active_job_batch_delay_ms=0\""
        )
        for (appDiag in targetApps) {
            preBatchCmds.addAll(buildAppSwitchGrantCommands(appDiag.packageName))
            shellEngine.markAppNotificationFixed(appDiag.packageName, true)
        }
        runVerifiedBatch(
            "Bước 1: Cấp Quyền Chạy Ngầm & Mở Khóa Biểu Ngữ Cho ${targetApps.size} App",
            preBatchCmds
        )
        stepCounter++

        // Step 2..N: Mở trang Cài đặt thông báo của từng app (Zero-Animation) và tự động gạt công tắc tận mắt
        for (appDiag in targetApps) {
            if (cancelVisualAutomation) {
                log("⏹ Đã dừng quá trình tự động gạt công tắc tận mắt (Đã hoàn thành ${completed.size} app).", LogType.INFO)
                break
            }
            val pkg = appDiag.packageName
            val name = appDiag.appName

            val appStepState = _floatingWindowState.value.copy(
                currentStep = stepCounter,
                currentAppName = "$name (${completed.size + 1}/${targetApps.size})",
                currentPackageName = pkg,
                currentActionDetail = "👁️ Đang mở Cài đặt Thông báo của $name -> Tự gạt TẮT Báo nhẹ nhàng & BẬT Biểu ngữ..."
            )
            _floatingWindowState.value = appStepState
            com.example.core.service.SystemFloatingHudOverlay.updateAutomationHud(
                context = context,
                state = appStepState,
                onStopClick = { stopLiveFloatingAutomation() }
            )

            // Mở trực tiếp màn hình Cài đặt Thông báo của ứng dụng (không trễ hoạt ảnh) và dùng UIAutomator nén + Batched Tap gạt công tắc
            val uiReport = com.example.core.shell.UiAutomatorSwitchHelper.autoToggleAppNotificationScreen(
                shellEngine = shellEngine,
                pkg = pkg,
                appName = name,
                pressBackWhenDone = false,
                onProgressUpdate = { progressText ->
                    val progressState = _floatingWindowState.value.copy(
                        currentActionDetail = progressText
                    )
                    _floatingWindowState.value = progressState
                    com.example.core.service.SystemFloatingHudOverlay.updateAutomationHud(
                        context = context,
                        state = progressState,
                        onStopClick = { stopLiveFloatingAutomation() }
                    )
                },
                onLog = { msg -> log(msg, LogType.INFO) }
            )
            if (uiReport.openedSettingsOk) {
                shellEngine.markAppVisuallyUiToggled(pkg, true)
            }

            completed.add(name)
            _floatingWindowState.value = _floatingWindowState.value.copy(
                completedApps = completed.toList()
            )
            stepCounter++
        }

        // Ẩn cửa sổ nổi hệ thống và đưa người dùng quay lại giao diện MagicTune ngay lập tức
        com.example.core.service.SystemFloatingHudOverlay.hideAutomationHud(context)
        shellEngine.execute("am start --activity-clear-top --activity-single-top --activity-no-animation -n ${context.packageName}/com.example.MainActivity >/dev/null 2>&1 || true")

        _floatingWindowState.value = _floatingWindowState.value.copy(
            currentStep = totalSteps,
            currentAppName = "Bảo vệ Vĩnh Viễn",
            currentPackageName = context.packageName,
            currentActionDetail = "Đang cập nhật kết quả sau khi gạt công tắc tận mắt..."
        )
        refreshAppsList()
        refreshSetupStatus()
        refreshDeviceInfo()
        runDiagnosticScan()

        _floatingWindowState.value = _floatingWindowState.value.copy(
            isRunningAutomation = false,
            currentStep = totalSteps,
            currentAppName = "Hoàn tất (Đã tự động gạt ${completed.size} app)",
            currentActionDetail = "✅ Đã mở Cài đặt và tự động gạt tắt Báo nhẹ nhàng + bật Biểu ngữ tận mắt cho ${completed.size} ứng dụng!"
        )
        true
    }

    // -------------------------------------------------------------
    // 1-CHẠM SIÊU THIẾT LẬP 8-TRONG-1 TURBO v2.5 (SIÊU TỐC GỘP CỤM)
    // -------------------------------------------------------------
    suspend fun runOneClickSetupMaster(onlyPending: Boolean = true): Boolean = withContext(Dispatchers.IO) {
        refreshSetupStatus()
        val st = _setupStatus.value

        if (onlyPending && st.readyScore == 8) {
            log("🎉 TUYỆT VỜI: Tất cả 8/8 hạng mục đã được cấu hình hoàn hảo từ trước! Không cần chạy lại.", LogType.SUCCESS)
            return@withContext true
        }

        val modeLabel = if (onlyPending) "TURBO THÔNG MINH (CHỈ CHẠY CÁC MỤC CHƯA ĐẠT)" else "TOÀN DIỆN TẤT CẢ 8 HẠNG MỤC"
        log("⚡ [Turbo v2.5] BẮT ĐẦU SIÊU THIẾT LẬP $modeLabel...", LogType.INFO)

        val pkg = context.packageName
        val turboCmds = mutableListOf(
            // Tự cấp quyền nền tảng cho MagicTune ngay trong cùng 1 phiên
            "pm grant $pkg android.permission.WRITE_SECURE_SETTINGS",
            "pm grant $pkg android.permission.POST_NOTIFICATIONS",
            "cmd appops set $pkg SYSTEM_ALERT_WINDOW allow",
            "cmd appops set $pkg GET_USAGE_STATS allow",
            "cmd appops set $pkg RUN_IN_BACKGROUND allow",
            "cmd appops set $pkg RUN_ANY_IN_BACKGROUND allow",
            "dumpsys deviceidle whitelist +$pkg"
        )

        // 1. Tiếng Việt & Múi giờ
        if (!onlyPending || !st.isVietnameseLocale || !st.isVietnamTimezone) {
            log("⚡ [1/8] Đưa cấu hình Tiếng Việt (vi-VN) & Giờ GMT+7 vào cụm Turbo...", LogType.INFO)
            turboCmds.addAll(
                listOf(
                    "settings put system system_locales vi-VN",
                    "settings put global auto_time 1",
                    "settings put system time_12_24 24",
                    "cmd locale set-locales vi-VN"
                )
            )
        } else {
            log("✓ [1/8] Tiếng Việt & Giờ GMT+7 đã đạt chuẩn (Bỏ qua)", LogType.INFO)
        }

        // 2. Google GMS & Đồng bộ
        if (!onlyPending || !st.gmsEnabled || !st.playStoreInstalled) {
            log("⚡ [2/8] Đưa cấu hình Bật Google GMS & Auto-Sync vào cụm Turbo...", LogType.INFO)
            turboCmds.addAll(
                listOf(
                    "settings put secure google_service_switch 1",
                    "settings put global google_service_switch 1",
                    "settings put global auto_sync 1",
                    "cmd content set-master-sync-automatically true",
                    "pm enable --user 0 com.google.android.gms",
                    "dumpsys deviceidle whitelist +com.google.android.gms",
                    "am set-standby-bucket com.google.android.gms active"
                )
            )
        } else {
            log("✓ [2/8] Google GMS & Đồng bộ danh bạ đã bật sẵn (Bỏ qua)", LogType.INFO)
        }

        // 3. Bàn phím Tiếng Việt & Khóa bàn phím Trung
        if (!onlyPending || (!st.labanKeyInstalled && !st.gboardInstalled)) {
            log("⚡ [3/8] Đưa cấu hình Bàn phím Tiếng Việt & Đóng băng phím Baidu vào cụm Turbo...", LogType.INFO)
            turboCmds.addAll(
                listOf(
                    "dumpsys deviceidle whitelist +com.vng.inputmethod.labankey",
                    "ime enable com.vng.inputmethod.labankey/.LabanKey",
                    "ime set com.vng.inputmethod.labankey/.LabanKey",
                    "pm disable-user --user 0 com.baidu.input_hihonor"
                )
            )
        } else {
            log("✓ [3/8] Bàn phím Gõ Tiếng Việt đã sẵn sàng (Bỏ qua)", LogType.INFO)
        }

        // 4. Sửa danh bạ +84 & Chấm than Wi-Fi
        if (!onlyPending || !st.callerId84Fixed || !st.captivePortalGlobal) {
            log("⚡ [4/8] Đưa cấu hình Sửa Danh bạ +84, Xóa chấm than Wi-Fi & 5G/VoLTE vào cụm Turbo...", LogType.INFO)
            turboCmds.addAll(
                listOf(
                    "settings put system min_match 7",
                    "settings put global min_match 7",
                    "settings put global captive_portal_mode 1",
                    "settings put global captive_portal_https_url \"https://connectivitycheck.gstatic.com/generate_204\"",
                    "settings put global captive_portal_http_url \"http://connectivitycheck.gstatic.com/generate_204\"",
                    "settings put system hw_volte_user_switch 1",
                    "settings put global fiveg_user_switch 1"
                )
            )
        } else {
            log("✓ [4/8] Danh bạ +84 & Xóa chấm than Wi-Fi đã hoàn thành (Bỏ qua)", LogType.INFO)
        }

        // 5. Dọn sạch giao diện chữ Trung & Tắt YOYO
        if (!onlyPending || !st.chineseUiCleaned) {
            log("⚡ [5/8] Đưa cấu hình Dọn sạch HiBoard, Honor Search, Tạp chí khóa & YOYO vào cụm Turbo...", LogType.INFO)
            turboCmds.addAll(
                listOf(
                    "settings put secure hiboard_switch 0",
                    "settings put system hiboard_switch 0",
                    "pm disable-user --user 0 com.hihonor.hiboard",
                    "pm disable-user --user 0 com.hihonor.search",
                    "pm disable-user --user 0 com.hihonor.magazinesettings",
                    "settings put system auto_download_magazine_wifi 0",
                    "settings put secure navigation_bar_wakeup_yoyo 0",
                    "settings put secure yoyo_navigation_bar_wakeup 0"
                )
            )
        } else {
            log("✓ [5/8] HiBoard & chữ Trung đã được dọn sạch (Bỏ qua)", LogType.INFO)
        }

        // 6. Định vị GPS độ nhạy cao & Đặc trị Timestamp Camera (Ô #08)
        if (!onlyPending || !st.gpsOptimized) {
            log("⚡ [6/8] Đưa cấu hình GPS độ nhạy cao, A-GPS Google & Timestamp Camera vào cụm Turbo...", LogType.INFO)
            turboCmds.addAll(
                listOf(
                    "settings put secure location_mode 3",
                    "settings put secure location_providers_allowed +gps,+network",
                    "settings put global supl_host supl.google.com",
                    "settings put global supl_port 7275",
                    "settings put global assisted_gps_enabled 1",
                    "settings put global wifi_scan_always_enabled 1",
                    "settings put global ble_scan_always_enabled 1",
                    "settings put global wifi_scan_throttle_enabled 0",
                    "settings put secure location_nlp_pkg com.google.android.gms",
                    "settings put global location_nlp_pkg com.google.android.gms",
                    "settings put secure google_location_accuracy_enabled 1",
                    "pm disable-user --user 0 com.amap.android.ams >/dev/null 2>&1 || true",
                    "pm disable-user --user 0 com.amap.android.location >/dev/null 2>&1 || true",
                    "dumpsys deviceidle whitelist +com.google.android.gms >/dev/null 2>&1 || true",
                    "cmd appops set com.google.android.gms RUN_IN_BACKGROUND allow >/dev/null 2>&1 || true",
                    "cmd appops set com.google.android.gms FINE_LOCATION allow >/dev/null 2>&1 || true",
                    "cmd appops set com.google.android.gms COARSE_LOCATION allow >/dev/null 2>&1 || true"
                )
            )
            shellEngine.setPersistedSetting("global", "supl_host", "supl.google.com")
            shellEngine.setPersistedSetting("secure", "location_mode", "3")
            shellEngine.setPersistedSetting("secure", "honor_gps_fixed", "1")
        } else {
            log("✓ [6/8] Định vị GPS & Google Location đã tối ưu (Bỏ qua)", LogType.INFO)
        }

        // 7. Chặn Chợ App Honor tự cập nhật đè
        if (!onlyPending || !st.honorMarketUpdateBlocked) {
            log("⚡ [7/8] Đưa cấu hình Chặn Chợ App Honor tự cập nhật vào cụm Turbo...", LogType.INFO)
            turboCmds.addAll(
                listOf(
                    "settings put global auto_update_app 0",
                    "settings put secure auto_update_app 0",
                    "cmd appops set com.hihonor.appmarket REQUEST_INSTALL_PACKAGES ignore",
                    "cmd appops set com.hihonor.appmarket RUN_IN_BACKGROUND ignore"
                )
            )
        } else {
            log("✓ [7/8] Chặn Chợ Honor tự cập nhật đã hoàn thành (Bỏ qua)", LogType.INFO)
        }

        // 8. Bảo vệ Shizuku Bất Tử & Khóa đánh thức YOYO
        turboCmds.addAll(
            listOf(
                "device_config set_sync_disabled_for_tests persistent",
                "device_config put activity_manager max_phantom_processes 2147483647",
                "settings put global settings_enable_monitor_phantom_procs false",
                "settings put global adb_charging_only 0",
                "settings put secure adb_TakeEffectInChargingOnly 0",
                "dumpsys deviceidle whitelist +moe.shizuku.privileged.api",
                "cmd appops set moe.shizuku.privileged.api RUN_IN_BACKGROUND allow",
                "cmd appops set moe.shizuku.privileged.api RUN_ANY_IN_BACKGROUND allow",
                "settings put secure navigation_bar_wakeup_yoyo 0",
                "settings put secure yoyo_navigation_bar_wakeup 0",
                "settings put system navigation_bar_wakeup_yoyo 0"
            )
        )

        var allOk = runVerifiedBatch("Siêu Thiết Lập 8-trong-1 Turbo v2.5", turboCmds)

        // Mở 100% Thông báo & Quyền cho các ứng dụng gặp vấn đề
        if (!onlyPending || !st.powerGeniusRemoved || !st.customAppSoundsEnabled) {
            val notifOk = optimizeAllApps()
            if (!notifOk) allOk = false
        } else {
            log("✓ [8/8] Thông báo, biểu ngữ & Doze pin đã đạt chuẩn (Bỏ qua)", LogType.INFO)
        }

        refreshSetupStatus()
        refreshDeviceInfo()
        runDiagnosticScan()
        if (allOk) {
            log("🎉 HOÀN TẤT SIÊU THIẾT LẬP TURBO v2.5 THÀNH CÔNG! Thiết bị đã đạt chuẩn Quốc Tế.", LogType.SUCCESS)
        } else {
            log("⚠️ KẾT THÚC THIẾT LẬP: Có mục chưa thành công (Đã báo chi tiết ở trên).", LogType.ERROR)
        }
        allOk
    }

    suspend fun setupVietnameseLanguage(): Boolean = withContext(Dispatchers.IO) {
        log("🌐 Đang thiết lập Tiếng Việt (vi-VN), Múi giờ Asia/Ho_Chi_Minh & 24h...", LogType.INFO)
        val ok = runVerifiedBatch(
            "Tiếng Việt & Múi giờ GMT+7",
            listOf(
                "settings put system system_locales vi-VN",
                "settings put global auto_time 1",
                "settings put system time_12_24 24",
                "cmd locale set-locales vi-VN"
            )
        )
        refreshSetupStatus()
        ok
    }

    suspend fun setupGoogleAndSync(): Boolean = withContext(Dispatchers.IO) {
        log("📦 Đang bật Google GMS & Đồng bộ Danh bạ Google...", LogType.INFO)
        val ok = runVerifiedBatch(
            "Bật Google GMS & Đồng bộ Danh bạ",
            listOf(
                "settings put secure google_service_switch 1",
                "settings put global google_service_switch 1",
                "settings put global auto_sync 1",
                "cmd content set-master-sync-automatically true",
                "pm enable --user 0 com.google.android.gms",
                "dumpsys deviceidle whitelist +com.google.android.gms",
                "am set-standby-bucket com.google.android.gms active"
            )
        )
        refreshSetupStatus()
        ok
    }

    suspend fun fixCallerIdAndWifi(): Boolean = withContext(Dispatchers.IO) {
        log("📶 Đang sửa Danh bạ +84, Xóa chấm than Wi-Fi & Mở 5G/VoLTE...", LogType.INFO)
        val ok = runVerifiedBatch(
            "Fix Danh bạ +84, Wi-Fi & 5G/VoLTE",
            listOf(
                "settings put system min_match 7",
                "settings put global min_match 7",
                "settings put global captive_portal_mode 1",
                "settings put global captive_portal_https_url \"https://connectivitycheck.gstatic.com/generate_204\"",
                "settings put global captive_portal_http_url \"http://connectivitycheck.gstatic.com/generate_204\"",
                "settings put system hw_volte_user_switch 1",
                "settings put global fiveg_user_switch 1"
            )
        )
        refreshSetupStatus()
        ok
    }

    suspend fun cleanChineseUi(): Boolean = withContext(Dispatchers.IO) {
        log("🧹 Đang dọn sạch chữ Trung: HiBoard vuốt trái, Honor Search, Tạp chí khóa & Tắt YOYO thanh điều hướng...", LogType.INFO)
        val ok = runVerifiedBatch(
            "Dọn sạch chữ Trung (HiBoard, Search, Magazine, YOYO)",
            listOf(
                "settings put secure hiboard_switch 0",
                "settings put system hiboard_switch 0",
                "pm disable-user --user 0 com.hihonor.hiboard",
                "pm disable-user --user 0 com.hihonor.search",
                "pm disable-user --user 0 com.hihonor.magazinesettings",
                "settings put system auto_download_magazine_wifi 0",
                "settings put secure navigation_bar_wakeup_yoyo 0",
                "settings put secure yoyo_navigation_bar_wakeup 0"
            )
        )
        refreshSetupStatus()
        ok
    }

/**
     * Thay thế tìm kiếm mặc định Honor Search vuốt từ màn hình chính:
     * - Vô hiệu hóa ứng dụng tìm kiếm giật lag/quảng cáo của Honor (com.hihonor.search)
     * - Cấu hình mở trợ lý số / tìm kiếm Google hoặc các công cụ tìm kiếm chuẩn (Google / Gesture Search)
     */
    suspend fun replaceHonorSearch(disable: Boolean): Boolean = withContext(Dispatchers.IO) {
        val actionText = if (disable) "Tắt Honor Search & Chuyển sang tìm kiếm ứng dụng Google / Gesture Search" else "Khôi phục Honor Search gốc"
        log("🔍 Đang $actionText...", LogType.INFO)
        val cmds = if (disable) {
            listOf(
                "pm disable-user --user 0 com.hihonor.search",
                "settings put secure honor_search_disabled 1",
                "settings put secure hiboard_search_switch 0",
                "settings put system hiboard_search_switch 0"
            )
        } else {
            listOf(
                "pm enable com.hihonor.search",
                "settings put secure honor_search_disabled 0",
                "settings put secure hiboard_search_switch 1",
                "settings put system hiboard_search_switch 1"
            )
        }
        val ok = runVerifiedBatch(actionText, cmds)
        refreshSetupStatus()
        refreshDeviceInfo()
        refreshTuneStatus()
        ok
    }

    suspend fun blockHonorMarket(): Boolean = withContext(Dispatchers.IO) {
        log("🔒 Đang chặn Chợ App Honor tự động cập nhật đè app tiếng Việt...", LogType.INFO)
        val ok = runVerifiedBatch(
            "Chặn Chợ App Honor Tự Cập Nhật",
            listOf(
                "settings put global auto_update_app 0",
                "settings put secure auto_update_app 0",
                "cmd appops set com.hihonor.appmarket REQUEST_INSTALL_PACKAGES ignore",
                "cmd appops set com.hihonor.appmarket RUN_IN_BACKGROUND ignore"
            )
        )
        refreshSetupStatus()
        refreshDeviceInfo()
        refreshTuneStatus()
        ok
    }

    suspend fun unblockHonorMarket(): Boolean = withContext(Dispatchers.IO) {
        log("🔓 Đang mở lại Tự Động Cập Nhật App trong Chợ Honor & Google Play...", LogType.INFO)
        val ok = runVerifiedBatch(
            "Mở lại Tự Động Cập Nhật App",
            listOf(
                "settings put global auto_update_app 1",
                "settings put secure auto_update_app 1",
                "pm enable --user 0 com.hihonor.appmarket",
                "cmd appops reset com.hihonor.appmarket"
            )
        )
        refreshSetupStatus()
        refreshDeviceInfo()
        refreshTuneStatus()
        refreshAppsList()
        ok
    }

    suspend fun applyThermalCooling(): Boolean = withContext(Dispatchers.IO) {
        log("❄️ Đang kích hoạt giải pháp làm mát toàn diện (Hạ xung nhiệt, Tối ưu tần số quét & Giải phóng bộ đệm)...", LogType.INFO)
        val cmds = listOf(
            "settings put global user_powersaver_enable 1",
            "settings put global low_power 1",
            "settings put system peak_refresh_rate 60.0",
            "settings put system min_refresh_rate 60.0",
            "settings put system user_refresh_rate 60",
            "settings put system thermal_limit_refresh_rate 60",
            "settings put global window_animation_scale 0.5",
            "settings put global transition_animation_scale 0.5",
            "settings put global animator_duration_scale 0.5",
            "settings put secure ui_night_mode 2",
            "settings put system ui_night_mode 2",
            "settings put system auto_download_magazine_wifi 0",
            "settings put global wifi_scan_always_enabled 0",
            "settings put global ble_scan_always_enabled 0",
            "setprop persist.sys.purge_buffers 1"
        )
        val ok = runVerifiedBatch("Kích hoạt chế độ Siêu Làm Mát Phần Cứng", cmds)
        refreshDeviceInfo()
        refreshTuneStatus()
        ok
    }

    suspend fun setupKeyboard(): Boolean = withContext(Dispatchers.IO) {
        log("⌨️ Đang thiết lập bàn phím Tiếng Việt & đóng băng phím Trung...", LogType.INFO)
        val ok = runVerifiedBatch(
            "Thiết lập bàn phím Tiếng Việt",
            listOf(
                "dumpsys deviceidle whitelist +com.vng.inputmethod.labankey",
                "ime enable com.vng.inputmethod.labankey/.LabanKey",
                "ime set com.vng.inputmethod.labankey/.LabanKey",
                "pm disable-user --user 0 com.baidu.input_hihonor"
            )
        )
        refreshSetupStatus()
        ok
    }

    suspend fun setupGpsVietnam(): Boolean = withContext(Dispatchers.IO) {
        log("📍 Bắt đầu Đặc Trị Định Vị GPS & Fix Triệt Để Timestamp Camera trên Honor (Đặc biệt cho Honor Magic 6 / Magic 7 - MagicOS 8.0 & 9.0)...", LogType.INFO)

        // Tự động dò tìm mọi phiên bản ứng dụng Timestamp Camera / Geotag Camera đang cài trên máy
        val knownTimestampPkgs = mutableSetOf(
            "com.jeyluta.timestampcamerafree",
            "com.jeyluta.timestampcamera",
            "com.jeyluta.timestampcamerapro",
            "com.jeyluta.timestampcameraenterprise",
            "com.darinsoft.timestampcamera",
            "com.camera.timestamp",
            "com.gpsmapcamera.geotagginglocationonphoto",
            "com.gpsmapcamera.gpsmaplocationonphoto",
            "com.app.geotagcamera",
            "com.timestampcamera.free",
            "com.jkfantasy.gpsmapcamera",
            "com.SimpleMobilePhotoResizer"
        )
        try {
            val pm = context.packageManager
            val installed = pm.getInstalledPackages(0)
            for (p in installed) {
                val pkgName = p.packageName ?: continue
                val lower = pkgName.lowercase()
                if (lower.contains("timestamp") || lower.contains("geotag") || lower.contains("gpsmap") || lower.contains("mapcamera")) {
                    knownTimestampPkgs.add(pkgName)
                }
            }
        } catch (_: Exception) {}

        val selfPkg = context.packageName
        val whitelistLocationThrottlePkgs = (listOf(
            selfPkg,
            "com.google.android.gms",
            "com.google.android.apps.maps",
            "com.grabtaxi.passenger",
            "com.beegroup.be"
        ) + knownTimestampPkgs).distinct().joinToString(",")

        // Danh sách toàn bộ các dịch vụ định vị nội địa Trung Quốc gây lệch tọa độ Mars GCJ-02 (500m-2km) & lưu chết vị trí cũ:
        // ĐẶC BIỆT TRÊN HONOR MAGIC 6 & MAGIC 7 (MagicOS 8.0 / 9.0): Gói định vị Cao Đức ngầm có tên là `com.amap.android.ams`!
        val chineseLocationPkgs = listOf(
            "com.amap.android.ams",
            "com.amap.android.location",
            "com.baidu.map.location",
            "com.baidu.location.fused",
            "com.tencent.android.location"
        )

        val commands = mutableListOf(
            // 0. Tự động cấp full quyền vị trí chính xác cho chính MagicTune để khóa nóng tọa độ thực WGS-84 cho toàn hệ thống
            "pm grant $selfPkg android.permission.ACCESS_FINE_LOCATION >/dev/null 2>&1 || true",
            "pm grant $selfPkg android.permission.ACCESS_COARSE_LOCATION >/dev/null 2>&1 || true",
            "cmd appops set $selfPkg FINE_LOCATION allow >/dev/null 2>&1 || true",
            "cmd appops set $selfPkg COARSE_LOCATION allow >/dev/null 2>&1 || true",
            "cmd appops set $selfPkg FINE_LOCATION_SOURCE allow >/dev/null 2>&1 || true",
            "cmd appops set $selfPkg MONITOR_HIGH_POWER_LOCATION allow >/dev/null 2>&1 || true",

            // 1. Xóa sạch dữ liệu cache tọa độ cũ (GCJ-02 / trạm phát sóng cũ) và VÔ HIỆU HÓA định vị Cao Đức `com.amap.android.ams` trên Honor Magic 6 & Magic 7
        )

        for (cnPkg in chineseLocationPkgs) {
            commands.add("pm clear $cnPkg >/dev/null 2>&1 || true")
            commands.add("cmd appops set $cnPkg FINE_LOCATION ignore >/dev/null 2>&1 || true")
            commands.add("cmd appops set $cnPkg COARSE_LOCATION ignore >/dev/null 2>&1 || true")
            commands.add("cmd appops set $cnPkg MONITOR_LOCATION ignore >/dev/null 2>&1 || true")
            commands.add("cmd appops set $cnPkg MONITOR_HIGH_POWER_LOCATION ignore >/dev/null 2>&1 || true")
            commands.add("cmd appops set $cnPkg RUN_IN_BACKGROUND ignore >/dev/null 2>&1 || true")
            commands.add("cmd appops set $cnPkg RUN_ANY_IN_BACKGROUND ignore >/dev/null 2>&1 || true")
            commands.add("am force-stop $cnPkg >/dev/null 2>&1 || true")
            commands.add("pm disable-user --user 0 $cnPkg >/dev/null 2>&1 || true")
        }

        commands.addAll(
            listOf(
                // 2. Làm mới LocationManagerService (Tắt -> Bật nhanh để xả sạch tọa độ LastKnownLocation bị kẹt trong RAM của MagicOS)
                "cmd location set-location-enabled false >/dev/null 2>&1 || true",
                "cmd location set-location-enabled true >/dev/null 2>&1 || true",
                "settings put secure location_mode 3",
                "settings put secure location_providers_allowed +gps,+network",

                // 3. Mở khóa chip thu vệ tinh băng tần kép (L1+L5 Full GNSS Tracking) trên Honor Magic 6 (8 Gen 3) & Magic 7 (8 Elite)
                // Ngăn chặn hoàn toàn chế độ tiết kiệm pin GPS làm đóng băng tọa độ cũ khi di chuyển
                "settings put global location_gnss_raw_meas_full_tracking 1",
                "settings put global location_background_throttle_interval_ms 0",
                "settings put global location_background_throttle_proximity_alert_interval_ms 0",
                "settings put global location_background_throttle_package_whitelist \"$whitelistLocationThrottlePkgs\"",
                "device_config put location location_background_throttle_interval_ms 0 >/dev/null 2>&1 || true",
                "device_config put location min_location_request_interval_ms 0 >/dev/null 2>&1 || true",
                "settings put global gnss_satellite_blocklist \"\"",
                "settings put secure location_changer 0",
                "settings put secure location_fuzzy_enabled 0",
                "settings put system location_fuzzy_enabled 0",

                // 4. Ép hệ thống trỏ Network Location Provider (NLP) & Geocoder sang Google Play Services (Chuẩn tọa độ quốc tế WGS-84)
                "settings put secure location_nlp_pkg com.google.android.gms",
                "settings put global location_nlp_pkg com.google.android.gms",
                "settings put system location_nlp_pkg com.google.android.gms",
                "settings put secure location_Global_nlp_pkg com.google.android.gms",
                "settings put global supl_host supl.google.com",
                "settings put global supl_port 7275",
                "settings put global assisted_gps_enabled 1",

                // 5. Cho phép quét Wi-Fi & Bluetooth thời gian thực (0ms throttle) để định vị tức thì khi vào trong nhà / khu phố mới
                "settings put global wifi_scan_always_enabled 1",
                "settings put global ble_scan_always_enabled 1",
                "settings put global wifi_scan_throttle_enabled 0",

                // 6. Kích hoạt cờ Google Location Accuracy & Google Geocoder chính xác
                "settings put secure google_location_accuracy_enabled 1",
                "settings put secure google_location_accuracy 1",
                "settings put secure nlp_mode 1",

                // 7. Xóa sạch Cache vệ tinh & trạm phát sóng cũ (Khu B) và ép nạp lại lịch thiên văn vệ tinh XTRA mới nhất (Khu A)
                "cmd location send-extra-command gps delete_aiding_data >/dev/null 2>&1 || true",
                "cmd location send-extra-command gps force_xtra_injection >/dev/null 2>&1 || true",
                "cmd location send-extra-command gps force_time_injection >/dev/null 2>&1 || true",

                // 8. Cấp full quyền Android 14/15 (Bao gồm NEARBY_WIFI_DEVICES & BLUETOOTH_SCAN trên Magic 6/7) cho Google Play Services (GMS)
                "dumpsys deviceidle whitelist +com.google.android.gms >/dev/null 2>&1 || true",
                "cmd activity set-standby-bucket com.google.android.gms active >/dev/null 2>&1 || true",
                "cmd appops set com.google.android.gms RUN_IN_BACKGROUND allow >/dev/null 2>&1 || true",
                "cmd appops set com.google.android.gms RUN_ANY_IN_BACKGROUND allow >/dev/null 2>&1 || true",
                "cmd appops set com.google.android.gms FINE_LOCATION allow >/dev/null 2>&1 || true",
                "cmd appops set com.google.android.gms FINE_LOCATION_SOURCE allow >/dev/null 2>&1 || true",
                "cmd appops set com.google.android.gms COARSE_LOCATION allow >/dev/null 2>&1 || true",
                "cmd appops set com.google.android.gms MONITOR_LOCATION allow >/dev/null 2>&1 || true",
                "cmd appops set com.google.android.gms MONITOR_HIGH_POWER_LOCATION allow >/dev/null 2>&1 || true",
                "cmd appops set com.google.android.gms NEARBY_WIFI_DEVICES allow >/dev/null 2>&1 || true",
                "cmd appops set com.google.android.gms BLUETOOTH_SCAN allow >/dev/null 2>&1 || true",
                "pm grant com.google.android.gms android.permission.ACCESS_FINE_LOCATION >/dev/null 2>&1 || true",
                "pm grant com.google.android.gms android.permission.ACCESS_COARSE_LOCATION >/dev/null 2>&1 || true",
                "pm grant com.google.android.gms android.permission.ACCESS_BACKGROUND_LOCATION >/dev/null 2>&1 || true",
                "pm grant com.google.android.gms android.permission.NEARBY_WIFI_DEVICES >/dev/null 2>&1 || true",
                "pm grant com.google.android.gms android.permission.BLUETOOTH_SCAN >/dev/null 2>&1 || true",
                "pm grant com.google.android.gms android.permission.ACTIVITY_RECOGNITION >/dev/null 2>&1 || true",

                // 9. Chống MagicOS đóng băng / diệt ngầm Google Maps
                "dumpsys deviceidle whitelist +com.google.android.apps.maps >/dev/null 2>&1 || true",
                "cmd activity set-standby-bucket com.google.android.apps.maps active >/dev/null 2>&1 || true",
                "cmd appops set com.google.android.apps.maps RUN_IN_BACKGROUND allow >/dev/null 2>&1 || true",
                "cmd appops set com.google.android.apps.maps RUN_ANY_IN_BACKGROUND allow >/dev/null 2>&1 || true",
                "cmd appops set com.google.android.apps.maps FINE_LOCATION allow >/dev/null 2>&1 || true",
                "cmd appops set com.google.android.apps.maps FINE_LOCATION_SOURCE allow >/dev/null 2>&1 || true",
                "cmd appops set com.google.android.apps.maps COARSE_LOCATION allow >/dev/null 2>&1 || true",
                "cmd appops set com.google.android.apps.maps MONITOR_LOCATION allow >/dev/null 2>&1 || true",
                "cmd appops set com.google.android.apps.maps MONITOR_HIGH_POWER_LOCATION allow >/dev/null 2>&1 || true",
                "pm grant com.google.android.apps.maps android.permission.ACCESS_FINE_LOCATION >/dev/null 2>&1 || true",
                "pm grant com.google.android.apps.maps android.permission.ACCESS_COARSE_LOCATION >/dev/null 2>&1 || true",
                "pm grant com.google.android.apps.maps android.permission.ACCESS_BACKGROUND_LOCATION >/dev/null 2>&1 || true"
            )
        )

        // 10. ĐẶC TRỊ CẤP ĐỦ 100% QUYỀN CHÍNH XÁC TUYỆT ĐỐI (TẮT VỊ TRÍ GẦN ĐÚNG / FUZZY LOCATION CỦA MAGIC 6 & 7) CHO TIMESTAMP CAMERA
        var fixedTimestampCount = 0
        for (pkg in knownTimestampPkgs) {
            if (isPackageInstalledFast(pkg)) {
                fixedTimestampCount++
                commands.add("dumpsys deviceidle whitelist +$pkg >/dev/null 2>&1 || true")
                commands.add("cmd activity set-standby-bucket $pkg active >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg AUTO_REVOKE_PERMISSIONS_IF_UNUSED ignore >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg ACCESS_RESTRICTED_SETTINGS allow >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg RUN_IN_BACKGROUND allow >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg RUN_ANY_IN_BACKGROUND allow >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg FINE_LOCATION allow >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg FINE_LOCATION_SOURCE allow >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg COARSE_LOCATION allow >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg MONITOR_LOCATION allow >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg MONITOR_HIGH_POWER_LOCATION allow >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg NEARBY_WIFI_DEVICES allow >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg BLUETOOTH_SCAN allow >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg GPS allow >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg CAMERA allow >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg RECORD_AUDIO allow >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg ACCESS_MEDIA_LOCATION allow >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg READ_EXTERNAL_STORAGE allow >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg WRITE_EXTERNAL_STORAGE allow >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg MANAGE_EXTERNAL_STORAGE allow >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1 || true")

                commands.add("pm grant $pkg android.permission.ACCESS_FINE_LOCATION >/dev/null 2>&1 || true")
                commands.add("pm grant $pkg android.permission.ACCESS_COARSE_LOCATION >/dev/null 2>&1 || true")
                commands.add("pm grant $pkg android.permission.ACCESS_BACKGROUND_LOCATION >/dev/null 2>&1 || true")
                commands.add("pm grant $pkg android.permission.NEARBY_WIFI_DEVICES >/dev/null 2>&1 || true")
                commands.add("pm grant $pkg android.permission.BLUETOOTH_SCAN >/dev/null 2>&1 || true")
                commands.add("pm grant $pkg android.permission.ACCESS_MEDIA_LOCATION >/dev/null 2>&1 || true")
                commands.add("pm grant $pkg android.permission.CAMERA >/dev/null 2>&1 || true")
                commands.add("pm grant $pkg android.permission.RECORD_AUDIO >/dev/null 2>&1 || true")
                commands.add("pm grant $pkg android.permission.READ_EXTERNAL_STORAGE >/dev/null 2>&1 || true")
                commands.add("pm grant $pkg android.permission.WRITE_EXTERNAL_STORAGE >/dev/null 2>&1 || true")
                commands.add("pm grant $pkg android.permission.READ_MEDIA_IMAGES >/dev/null 2>&1 || true")
                commands.add("pm grant $pkg android.permission.READ_MEDIA_VIDEO >/dev/null 2>&1 || true")
                commands.add("pm grant $pkg android.permission.POST_NOTIFICATIONS >/dev/null 2>&1 || true")

                // Khóa cờ quyền Vị trí chính xác (Chống MagicOS 8/9 trên Magic 6 & 7 tự hạ xuống Vị trí gần đúng / Fuzzy Location)
                commands.add("pm set-permission-flags $pkg android.permission.ACCESS_FINE_LOCATION user-set user-fixed >/dev/null 2>&1 || true")
                commands.add("pm set-permission-flags $pkg android.permission.ACCESS_COARSE_LOCATION user-set user-fixed >/dev/null 2>&1 || true")

                // Xóa bộ đệm địa chỉ cũ (Cache Khu B) của Timestamp Camera và đóng tiến trình cũ để ép nạp tọa độ mới
                commands.add("rm -rf /sdcard/Android/data/$pkg/cache/* >/dev/null 2>&1 || true")
                commands.add("am force-stop $pkg >/dev/null 2>&1 || true")
            }
        }

        // 11. Tự động kiểm tra và whitelist các app gọi xe / giao đồ ăn
        val rideApps = listOf(
            "com.grabtaxi.passenger",
            "com.beegroup.be",
            "com.gojek.app",
            "com.gsm.customer",
            "com.shopee.food",
            "com.garena.delivery"
        )
        for (pkg in rideApps) {
            if (isPackageInstalledFast(pkg)) {
                commands.add("dumpsys deviceidle whitelist +$pkg >/dev/null 2>&1 || true")
                commands.add("cmd activity set-standby-bucket $pkg active >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg RUN_IN_BACKGROUND allow >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg RUN_ANY_IN_BACKGROUND allow >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg FINE_LOCATION allow >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg FINE_LOCATION_SOURCE allow >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg COARSE_LOCATION allow >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg MONITOR_LOCATION allow >/dev/null 2>&1 || true")
                commands.add("cmd appops set $pkg MONITOR_HIGH_POWER_LOCATION allow >/dev/null 2>&1 || true")
                commands.add("pm grant $pkg android.permission.ACCESS_FINE_LOCATION >/dev/null 2>&1 || true")
                commands.add("pm grant $pkg android.permission.ACCESS_COARSE_LOCATION >/dev/null 2>&1 || true")
                commands.add("pm grant $pkg android.permission.ACCESS_BACKGROUND_LOCATION >/dev/null 2>&1 || true")
            }
        }

        val ok = runVerifiedBatch("Đặc Trị Định Vị GPS & Timestamp Camera (Honor Magic 6 / Magic 7)", commands)
        shellEngine.setPersistedSetting("global", "supl_host", "supl.google.com")
        shellEngine.setPersistedSetting("secure", "location_mode", "3")
        shellEngine.setPersistedSetting("secure", "honor_gps_fixed", "1")

        // 12. KÍCH HOẠT BỘ KHÓA NÓNG TỌA ĐỘ THỰC WGS-84 (Ghi đè tọa độ mới nhất vào RAM của LocationManagerService ngay lập tức)
        warmupHardwareAndFusedGpsLock()

        refreshSetupStatus()
        refreshTuneStatus()
        refreshDeviceInfo()
        val tsNote = if (fixedTimestampCount > 0) " Đã khóa Vị trí chính xác tuyệt đối & xóa cache vị trí cũ cho $fixedTimestampCount app Timestamp Camera!" else ""
        log("🎉 ĐÃ FIX XONG ĐỊNH VỊ GPS & TIMESTAMP CAMERA TRÊN HONOR MAGIC 6/7: Đã gỡ bỏ gói định vị Cao Đức ngầm (com.amap.android.ams), tắt Vị trí gần đúng (Fuzzy Location), bật Full GNSS L1+L5 và khóa nóng tọa độ thực WGS-84!$tsNote", LogType.SUCCESS)
        ok
    }

    suspend fun refreshGpsSatellites(): Boolean = withContext(Dispatchers.IO) {
        log("🔄 Đang xóa bộ đệm vị trí cũ (chống kẹt vị trí Khu B trên Honor Magic 6/7) và ép nạp lại vệ tinh A-GPS thời gian thực...", LogType.INFO)
        val commands = mutableListOf(
            "pm clear com.amap.android.ams >/dev/null 2>&1 || true",
            "pm disable-user --user 0 com.amap.android.ams >/dev/null 2>&1 || true",
            "pm clear com.amap.android.location >/dev/null 2>&1 || true",
            "pm disable-user --user 0 com.amap.android.location >/dev/null 2>&1 || true",
            "pm clear com.baidu.map.location >/dev/null 2>&1 || true",
            "pm disable-user --user 0 com.baidu.map.location >/dev/null 2>&1 || true",
            "settings put global location_gnss_raw_meas_full_tracking 1",
            "settings put global location_background_throttle_interval_ms 0",
            "settings put global wifi_scan_throttle_enabled 0",
            "cmd location set-location-enabled false >/dev/null 2>&1 || true",
            "cmd location set-location-enabled true >/dev/null 2>&1 || true",
            "settings put secure location_mode 3",
            "cmd location send-extra-command gps delete_aiding_data >/dev/null 2>&1 || true",
            "cmd location send-extra-command gps force_xtra_injection >/dev/null 2>&1 || true",
            "cmd location send-extra-command gps force_time_injection >/dev/null 2>&1 || true"
        )
        val tsPkgs = listOf(
            "com.jeyluta.timestampcamerafree",
            "com.jeyluta.timestampcamera",
            "com.jeyluta.timestampcamerapro",
            "com.darinsoft.timestampcamera",
            "com.camera.timestamp",
            "com.gpsmapcamera.geotagginglocationonphoto"
        )
        for (pkg in tsPkgs) {
            if (isPackageInstalledFast(pkg)) {
                commands.add("rm -rf /sdcard/Android/data/$pkg/cache/* >/dev/null 2>&1 || true")
                commands.add("am force-stop $pkg >/dev/null 2>&1 || true")
            }
        }
        val ok = runVerifiedBatch("Nạp Lại Vệ Tinh GPS & Xóa Cache Vị Trí Cũ", commands)
        shellEngine.setPersistedSetting("global", "supl_host", "supl.google.com")
        shellEngine.setPersistedSetting("secure", "location_mode", "3")
        shellEngine.setPersistedSetting("secure", "honor_gps_fixed", "1")
        warmupHardwareAndFusedGpsLock()
        refreshSetupStatus()
        refreshTuneStatus()
        log("🛰️ Đã làm mới vệ tinh A-GPS, tắt Cao Đức AMap (com.amap.android.ams) và khóa nóng tọa độ mới cho Timestamp Camera thành công!", LogType.SUCCESS)
        ok
    }

    /**
     * Khóa nóng tọa độ thực WGS-84 (Live Hardware GPS + Fused Location Warmup):
     * Đánh thức ngay chip GPS băng tần kép L1+L5 và Fused Provider để hệ điều hành ghi đè tọa độ mới nhất
     * vào bộ nhớ RAM `LastKnownLocation` của `LocationManagerService` trước khi người dùng mở Timestamp Camera.
     */
    @Suppress("MissingPermission")
    private fun warmupHardwareAndFusedGpsLock() {
        try {
            val mainHandler = android.os.Handler(android.os.Looper.getMainLooper())
            mainHandler.post {
                try {
                    val lm = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return@post
                    val listener = object : android.location.LocationListener {
                        override fun onLocationChanged(location: android.location.Location) {}
                        @Deprecated("Deprecated in Java")
                        override fun onStatusChanged(provider: String?, status: Int, extras: android.os.Bundle?) {}
                        override fun onProviderEnabled(provider: String) {}
                        override fun onProviderDisabled(provider: String) {}
                    }
                    val providers = listOf("gps", "fused", "network")
                    for (p in providers) {
                        try {
                            if (lm.isProviderEnabled(p)) {
                                lm.requestLocationUpdates(p, 500L, 0f, listener, android.os.Looper.getMainLooper())
                            }
                        } catch (_: Throwable) {}
                    }
                    // Duy trì kích sóng GPS độ chính xác cao trong 25 giây để khóa chặt tọa độ mới
                    mainHandler.postDelayed({
                        try {
                            lm.removeUpdates(listener)
                        } catch (_: Throwable) {}
                    }, 25_000L)
                } catch (_: Throwable) {}
            }
        } catch (_: Throwable) {}
    }

    // -------------------------------------------------------------
    // FIX THÔNG BÁO THÔNG MINH (KIỂM TRA TRƯỚC - CHỈ SỬA APP GẶP LỖI)
    // -------------------------------------------------------------
    suspend fun optimizeAllApps(): Boolean = withContext(Dispatchers.IO) {
        log("🔍 Đang kiểm tra danh sách ứng dụng gặp lỗi thông báo / thiếu quyền trước khi sửa (Không chạy thừa trên app đã tốt)...", LogType.INFO)
        val scan = runDiagnosticScan()

        val unfixedCauses = scan.systemDelayCauses.filter { !it.isFixed }
        val problematicApps = scan.gentleAndBannerApps.filter {
            it.hasAnyNotificationIssue || it.hasAnyPermissionIssue
        }

        if (unfixedCauses.isEmpty() && problematicApps.isEmpty()) {
            log(
                "🎉 KIỂM TRA HOÀN TẤT: Toàn bộ ${scan.allScannedAppsCount} ứng dụng và hệ thống đều đã hoạt động chuẩn 100% (Đã bật đầy đủ biểu ngữ, tắt báo nhẹ nhàng & đủ quyền chạy ngầm)! Không có app nào bị lỗi cần sửa.",
                LogType.SUCCESS
            )
            return@withContext true
        }

        val skippedCount = (scan.allScannedAppsCount - problematicApps.size).coerceAtLeast(0)
        log(
            "⚡ Phát hiện ${problematicApps.size} ứng dụng & ${unfixedCauses.size} nguyên nhân hệ thống cần xử lý (Đã bỏ qua $skippedCount ứng dụng không bị lỗi để tiết kiệm thời gian)...",
            LogType.INFO
        )
        grantSelfControlAndOverlayPermissions()

        val cmds = mutableListOf<String>()

        if (unfixedCauses.isNotEmpty()) {
            cmds.addAll(
                listOf(
                    "pm disable-user --user 0 com.hihonor.powergenius",
                    "settings put system iaware_switch 0",
                    "settings put global iaware_switch 0",
                    "cmd appops set com.hihonor.systemmanager GET_USAGE_STATS ignore",
                    "settings put system lock_screen_notification_style 0",
                    "settings put system lock_screen_details_notification 1",
                    "settings put secure lock_screen_show_notifications 1",
                    "settings put secure lock_screen_allow_private_notifications 1",
                    "settings put system lock_screen_show_notifications 1",
                    "settings put global heads_up_notifications_enabled 1",
                    "settings put system notification_banner_enabled 1",
                    "settings put system gentle_notification_enabled 0",
                    "settings put system hw_notification_gentle_switch 0",
                    "settings put system use_default_notification_sound 0",
                    "settings put system notification_cooldown_enabled 0",
                    "settings put global job_scheduler_constants \"min_ready_non_active_jobs_count=1,max_non_active_job_batch_delay_ms=0\"",
                    "settings put global auto_update_app 0",
                    "settings put secure navigation_bar_wakeup_yoyo 0",
                    "settings put secure yoyo_navigation_bar_wakeup 0"
                )
            )
        }

        val targetPkgs = problematicApps.map { it.packageName }.distinct()

        for (pkg in targetPkgs) {
            cmds.addAll(buildAppSwitchGrantCommands(pkg))
        }

        val ok = runVerifiedBatch(
            "Sửa Thông Báo & Gạt Công Tắc Quyền cho ${targetPkgs.size} app gặp vấn đề (Bỏ qua $skippedCount app đã tốt)",
            cmds
        )
        if (ok) {
            for (pkg in targetPkgs) {
                shellEngine.markAppNotificationFixed(pkg, true)
            }
        }
        refreshAppsList()
        refreshSetupStatus()
        runDiagnosticScan()
        ok
    }

    suspend fun fixFacebookNuclear(): Boolean = withContext(Dispatchers.IO) {
        fixGmailAndFacebookNuclear()
    }

    /**
     * TÍNH NĂNG 1/2: CHỈ FIX THÔNG BÁO MÀN HÌNH KHÓA & BIỂU NGỮ
     * Tắt thông báo nhẹ nhàng, bật hiển thị đầy đủ chi tiết màn hình khóa, bật biểu ngữ nổi & chuông riêng.
     * Hoàn toàn không đụng tới quyền chạy ngầm hay tối ưu pin.
     */
    suspend fun fixNotificationSettingsOnly(pkgs: List<String> = listOf("com.google.android.gm", "com.facebook.katana")): Boolean = withContext(Dispatchers.IO) {
        log("🔔 [Đặc Trị Thông Báo 100%] Đang cấu hình toàn diện triệt để MỌI kênh, mức độ quan trọng & biểu ngữ cho ${pkgs.size} ứng dụng (Chạy ngầm chuyên sâu)...", LogType.INFO)
        val cmds = mutableListOf(
            "settings put system lock_screen_notification_style 0",
            "settings put system lock_screen_details_notification 1",
            "settings put secure lock_screen_show_notifications 1",
            "settings put secure lock_screen_allow_private_notifications 1",
            "settings put system lock_screen_show_notifications 1",
            "settings put global heads_up_notifications_enabled 1",
            "settings put system notification_banner_enabled 1",
            "settings put system gentle_notification_enabled 0",
            "settings put system hw_notification_gentle_switch 0",
            "settings put system use_default_notification_sound 0",
            "settings put system notification_cooldown_enabled 0"
        )
        for (pkg in pkgs) {
            cmds.addAll(
                listOf(
                    "cmd appops set $pkg POST_NOTIFICATION allow",
                    "cmd appops set --uid $pkg POST_NOTIFICATION allow",
                    "cmd appops set $pkg SYSTEM_ALERT_WINDOW allow",
                    "cmd appops set --uid $pkg SYSTEM_ALERT_WINDOW allow",
                    "cmd appops set $pkg RUN_IN_BACKGROUND allow",
                    "cmd appops set $pkg RUN_ANY_IN_BACKGROUND allow",
                    "cmd appops set $pkg WAKE_LOCK allow",
                    "cmd appops set $pkg START_FOREGROUND allow",
                    "cmd appops set $pkg AUTO_START allow",
                    "cmd appops set $pkg BOOT_COMPLETED allow",
                    "cmd appops set $pkg GET_USAGE_STATS allow",
                    "dumpsys deviceidle whitelist +$pkg",
                    "am set-standby-bucket $pkg active",
                    "am broadcast -a android.intent.action.MY_PACKAGE_REPLACED -p $pkg"
                )
            )
            try {
                val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? android.app.NotificationManager
                val channels = nm?.notificationChannels
                channels?.forEach { channel ->
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        channel.importance = android.app.NotificationManager.IMPORTANCE_HIGH
                        channel.enableVibration(true)
                        channel.enableLights(true)
                        channel.setShowBadge(true)
                        channel.lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
                        channel.setBypassDnd(true)
                    }
                }
            } catch (_: Exception) {}
        }

        val ok = runVerifiedBatch("Fix Chi Tiết & Toàn Diện Kênh Thông Báo App", cmds)
        if (ok) {
            pkgs.forEach { shellEngine.markAppNotificationFixed(it, true) }
        }
        refreshAppsList()
        refreshSetupStatus()
        runDiagnosticScan()
        ok
    }

    /**
     * TÍNH NĂNG 2/2: CHỈ FIX QUYỀN HẠN APP & TỰ ĐỘNG CHẠY NGẦM
     * Bắt buộc chạy ngầm bất tử, tự động đánh thức, miễn trừ tối ưu pin, bật SYSTEM_ALERT_WINDOW & AUTO_START.
     * Hoàn toàn không đụng tới cài đặt hiển thị thông báo màn hình khóa.
     */
    suspend fun fixAppPermissionsOnly(pkgs: List<String> = listOf("com.google.android.gm", "com.facebook.katana")): Boolean = withContext(Dispatchers.IO) {
        log("⚡ [TÁCH BIỆT 2/2] Đang thực thi CHỈ TÍNH NĂNG FIX QUYỀN HẠN CHẠY NGẦM & ĐÁNH THỨC APP...", LogType.INFO)
        val cmds = mutableListOf<String>()
        for (pkg in pkgs) {
            cmds.addAll(
                listOf(
                    "dumpsys deviceidle whitelist +$pkg",
                    "am set-standby-bucket $pkg active",
                    "cmd appops set $pkg SYSTEM_ALERT_WINDOW allow",
                    "cmd appops set --uid $pkg SYSTEM_ALERT_WINDOW allow",
                    "cmd appops set $pkg RUN_IN_BACKGROUND allow",
                    "cmd appops set $pkg RUN_ANY_IN_BACKGROUND allow",
                    "cmd appops set $pkg AUTO_START allow",
                    "cmd appops set $pkg BOOT_COMPLETED allow",
                    "cmd appops set $pkg GET_USAGE_STATS allow"
                )
            )
            cmds.addAll(buildAppSwitchGrantCommands(pkg))
        }

        val ok = runVerifiedBatch("Chỉ Fix Quyền Hạn App Chạy Ngầm & Đánh Thức", cmds)
        refreshAppsList()
        refreshSetupStatus()
        runDiagnosticScan()
        ok
    }

    suspend fun fixGmailAndFacebookNuclear(): Boolean = withContext(Dispatchers.IO) {
        log("🔥 [Đặc Trị Honor] Đang thi hành kịch bản sửa triệt để Mất thông báo & Trễ tin nhắn cho Gmail, Facebook, Messenger & Zalo...", LogType.INFO)
        val targets = listOf("com.google.android.gm", "com.facebook.katana", "com.facebook.orca", "com.zing.zalo")
        val cmds = mutableListOf(
            "pm disable-user --user 0 com.hihonor.powergenius >/dev/null 2>&1 || true",
            "pm disable-user --user 0 com.hihonor.iaware >/dev/null 2>&1 || true",
            "settings put system gentle_notification_enabled 0",
            "settings put system hw_notification_gentle_switch 0",
            "settings put global heads_up_notifications_enabled 1",
            "settings put system notification_banner_enabled 1",
            "settings put global job_scheduler_constants \"min_ready_non_active_jobs_count=1,max_non_active_job_batch_delay_ms=0\"",
            "device_config put jobscheduler min_ready_non_active_jobs_count 1",
            "device_config put jobscheduler max_non_active_job_batch_delay_ms 0"
        )
        for (pkg in targets) {
            cmds.add("am set-standby-bucket $pkg active")
            cmds.add("dumpsys deviceidle whitelist +$pkg >/dev/null 2>&1 || true")
            cmds.add("cmd appops set $pkg RUN_IN_BACKGROUND allow")
            cmds.add("cmd appops set $pkg RUN_ANY_IN_BACKGROUND allow")
            cmds.add("cmd appops set $pkg START_FOREGROUND allow")
            cmds.add("cmd appops set $pkg POST_NOTIFICATION allow")
            cmds.add("cmd appops set $pkg WAKE_LOCK allow")
            cmds.add("cmd appops set $pkg TURN_SCREEN_ON allow")
            cmds.add("cmd appops set $pkg GET_USAGE_STATS allow")
            cmds.add("cmd appops set $pkg AUTO_START allow >/dev/null 2>&1 || true")
        }
        val ok = runVerifiedBatch("Đặc Trị Thông Báo Gmail & Facebook Honor", cmds)
        for (pkg in targets) {
            shellEngine.markAppNotificationFixed(pkg, true)
        }
        refreshAppsList()
        refreshSetupStatus()
        runDiagnosticScan()
        log("✅ ĐÃ KHỐNG CHẾ THÀNH CÔNG THÔNG BÁO GMAIL & FACEBOOK TRÊN HONOR! Bạn sẽ nhận thông báo & tiếng chuông tức thì.", LogType.SUCCESS)
        ok
    }

    suspend fun restoreGmailAndFacebookDefault(): Boolean = withContext(Dispatchers.IO) {
        log("🔄 Đang khôi phục cài đặt thông báo mặc định của hệ thống Honor cho Gmail & Facebook...", LogType.INFO)
        val targets = listOf("com.google.android.gm", "com.facebook.katana", "com.facebook.orca", "com.zing.zalo")
        val cmds = mutableListOf<String>()
        for (pkg in targets) {
            cmds.add("am set-standby-bucket $pkg working_set")
            cmds.add("dumpsys deviceidle whitelist -$pkg >/dev/null 2>&1 || true")
            cmds.add("cmd appops set $pkg RUN_IN_BACKGROUND default")
            cmds.add("cmd appops set $pkg RUN_ANY_IN_BACKGROUND default")
            cmds.add("cmd appops set $pkg START_FOREGROUND default")
        }
        val ok = runVerifiedBatch("Khôi phục mặc định Gmail & Facebook", cmds)
        for (pkg in targets) {
            shellEngine.markAppNotificationFixed(pkg, false)
        }
        refreshAppsList()
        runDiagnosticScan()
        log("✅ Đã khôi phục cài đặt thông báo mặc định gốc cho Gmail & Facebook.", LogType.SUCCESS)
        ok
    }

    /**
     * TRANG CHỨC NĂNG NGẦM: FIX CHẬM THÔNG BÁO CHO TẤT CẢ CÁC HÃNG ANDROID NỘI ĐỊA
     * (Xiaomi, Redmi, POCO, Oppo, Realme, OnePlus, Vivo, iQOO, Huawei...)
     */
    suspend fun applyUniversalOemNotificationFix(): Boolean = withContext(Dispatchers.IO) {
        log("🌐 [CHỨC NĂNG NGẦM ĐA HÃNG] Khởi chạy Fix Chậm Thông Báo Tổng Lực trên toàn bộ nền tảng Android...", LogType.INFO)
        val targets = listOf(
            "com.google.android.gms",
            "com.google.android.gsf",
            "com.zing.zalo",
            "com.facebook.orca",
            "com.facebook.katana",
            "org.telegram.messenger",
            "com.google.android.gm",
            "com.viber.voip",
            "com.whatsapp",
            "com.instagram.android",
            "com.shopee.vn",
            "com.lazada.android",
            "com.mbmobile",
            "com.VCB",
            "vn.com.techcombank.bb.app"
        )
        val cmds = mutableListOf(
            // 1. Phá vỡ Doze Mode & Standby Buckets toàn cầu
            "settings put global device_idle_constants \"inactive_to=2592000000,sensing_to=0,locating_to=0,location_accuracy=20.0,max_temp_app_allowlist_duration_ms=2592000000\"",
            "settings put global heads_up_notifications_enabled 1",
            "settings put global app_standby_enabled 0",
            // 2. Vô hiệu hóa Phantom Process Killer (Android 12, 13, 14, 15, 16) kìm kẹp tiến trình nền
            "device_config put activity_manager max_phantom_processes 2147483647",
            "setprop persist.sys.fflag.override.settings_enable_monitor_phantom_procs false",
            // 3. Phá vỡ gom cụm JobScheduler & TARE (The Android Resource Economy)
            "settings put global job_scheduler_constants \"min_ready_non_active_jobs_count=1,max_non_active_job_batch_delay_ms=0\"",
            "device_config put jobscheduler min_ready_non_active_jobs_count 1",
            "device_config put jobscheduler max_non_active_job_batch_delay_ms 0",
            "device_config put tare enable_tare_mode 0",
            "settings put global tare_alarm_manager_constants \"default_min_action_delay_ms=0\"",
            // 4. Cho phép đánh thức màn hình khi có thông báo
            "settings put secure wake_gesture_enabled 1",
            "settings put system wake_when_plugged_or_unplugged 1"
        )

        for (pkg in targets) {
            cmds.add("am set-standby-bucket $pkg active >/dev/null 2>&1 || true")
            cmds.add("dumpsys deviceidle whitelist +$pkg >/dev/null 2>&1 || true")
            cmds.add("cmd appops set $pkg RUN_IN_BACKGROUND allow >/dev/null 2>&1 || true")
            cmds.add("cmd appops set $pkg RUN_ANY_IN_BACKGROUND allow >/dev/null 2>&1 || true")
            cmds.add("cmd appops set $pkg START_FOREGROUND allow >/dev/null 2>&1 || true")
            cmds.add("cmd appops set $pkg POST_NOTIFICATION allow >/dev/null 2>&1 || true")
            cmds.add("cmd appops set $pkg WAKE_LOCK allow >/dev/null 2>&1 || true")
            cmds.add("cmd appops set $pkg TURN_SCREEN_ON allow >/dev/null 2>&1 || true")
            cmds.add("cmd appops set $pkg AUTO_START allow >/dev/null 2>&1 || true")
            cmds.add("cmd tare set-vip $pkg true >/dev/null 2>&1 || true")
        }

        val ok = runVerifiedBatch("Fix Chậm Thông Báo Tổng Lực Đa Hãng Android", cmds)
        for (pkg in targets) {
            shellEngine.markAppNotificationFixed(pkg, true)
        }
        refreshAppsList()
        log("✅ [CHỨC NĂNG NGẦM] Đã thiết lập xong toàn bộ cơ chế chống trễ thông báo FCM & AppOps đa hãng!", LogType.SUCCESS)
        ok
    }

    suspend fun fixXiaomiMiuiNotificationLag(): Boolean = withContext(Dispatchers.IO) {
        log("📱 [XIAOMI / REDMI / POCO] Đang can thiệp MIUI & HyperOS để trị tận gốc trễ thông báo...", LogType.INFO)
        val cmds = listOf(
            // Vô hiệu hóa hoặc kiềm chế Joyose & PowerKeeper diệt ngầm khét tiếng
            "cmd appops set com.miui.powerkeeper RUN_IN_BACKGROUND ignore",
            "cmd appops set com.xiaomi.joyose RUN_IN_BACKGROUND ignore",
            "settings put secure miui_optimization 1",
            "settings put system miui_home_animation_rate 0",
            "settings put system power_mode_save 0",
            // Cấp autostart cho GMS và các app chat
            "cmd appops set com.google.android.gms AUTO_START allow",
            "cmd appops set com.zing.zalo AUTO_START allow",
            "cmd appops set com.facebook.orca AUTO_START allow",
            "cmd appops set com.facebook.katana AUTO_START allow",
            "cmd appops set org.telegram.messenger AUTO_START allow",
            "dumpsys deviceidle whitelist +com.google.android.gms",
            "dumpsys deviceidle whitelist +com.zing.zalo",
            "dumpsys deviceidle whitelist +com.facebook.orca",
            "dumpsys deviceidle whitelist +org.telegram.messenger"
        )
        val ok = runVerifiedBatch("Fix Thông Báo Xiaomi MIUI & HyperOS", cmds)
        log("✅ [XIAOMI / REDMI] Đã vô hiệu hóa cơ chế ép sleep MIUI/HyperOS!", LogType.SUCCESS)
        ok
    }

    suspend fun fixOppoRealmeNotificationLag(): Boolean = withContext(Dispatchers.IO) {
        log("📱 [OPPO / REALME / ONEPLUS] Đang vô hiệu hóa Athena & Deep Sleep trên ColorOS...", LogType.INFO)
        val cmds = listOf(
            // Vô hiệu hóa Athena Battery Manager trên ColorOS
            "pm disable-user --user 0 com.coloros.athena >/dev/null 2>&1 || true",
            "settings put global deep_sleep_enabled 0",
            "settings put secure oplus_customize_speed_mode 1",
            "cmd appops set com.google.android.gms RUN_IN_BACKGROUND allow",
            "cmd appops set com.zing.zalo RUN_IN_BACKGROUND allow",
            "cmd appops set com.facebook.orca RUN_IN_BACKGROUND allow",
            "cmd appops set org.telegram.messenger RUN_IN_BACKGROUND allow",
            "dumpsys deviceidle whitelist +com.google.android.gms",
            "dumpsys deviceidle whitelist +com.zing.zalo",
            "dumpsys deviceidle whitelist +com.facebook.orca"
        )
        val ok = runVerifiedBatch("Fix Thông Báo Oppo & Realme ColorOS", cmds)
        log("✅ [OPPO / REALME] Đã xử lý Athena & bỏ Deep Sleep trên ColorOS!", LogType.SUCCESS)
        ok
    }

    suspend fun fixVivoIqooNotificationLag(): Boolean = withContext(Dispatchers.IO) {
        log("📱 [VIVO / IQOO] Đang dỡ bỏ rào cản iManager & Night Idle Sleep trên OriginOS...", LogType.INFO)
        val cmds = listOf(
            "settings put global vivo_night_idle_sleep 0",
            "settings put global vivo_freeze_support 0",
            "cmd appops set com.google.android.gms AUTO_START allow",
            "cmd appops set com.zing.zalo AUTO_START allow",
            "cmd appops set com.facebook.orca AUTO_START allow",
            "cmd appops set org.telegram.messenger AUTO_START allow",
            "dumpsys deviceidle whitelist +com.google.android.gms",
            "dumpsys deviceidle whitelist +com.zing.zalo",
            "dumpsys deviceidle whitelist +com.facebook.orca"
        )
        val ok = runVerifiedBatch("Fix Thông Báo Vivo & iQOO OriginOS", cmds)
        log("✅ [VIVO / IQOO] Đã ngắt chế độ đóng băng ngầm OriginOS!", LogType.SUCCESS)
        ok
    }

    suspend fun fixHuaweiHarmonyNotificationLag(): Boolean = withContext(Dispatchers.IO) {
        log("📱 [HUAWEI] Đang ngắt PowerGenie & mở khóa thông báo FCM trên EMUI / HarmonyOS...", LogType.INFO)
        val cmds = listOf(
            "pm disable-user --user 0 com.huawei.powergenie >/dev/null 2>&1 || true",
            "pm disable-user --user 0 com.huawei.android.hwouc >/dev/null 2>&1 || true",
            "settings put global smart_power_saving 0",
            "settings put system gentle_notification_enabled 0",
            "cmd appops set com.google.android.gms AUTO_START allow",
            "cmd appops set com.zing.zalo AUTO_START allow",
            "cmd appops set com.facebook.orca AUTO_START allow",
            "dumpsys deviceidle whitelist +com.google.android.gms",
            "dumpsys deviceidle whitelist +com.zing.zalo",
            "dumpsys deviceidle whitelist +com.facebook.orca"
        )
        val ok = runVerifiedBatch("Fix Thông Báo Huawei EMUI & HarmonyOS", cmds)
        log("✅ [HUAWEI] Đã tắt PowerGenie & mở full kết nối ngầm EMUI/HarmonyOS!", LogType.SUCCESS)
        ok
    }

    suspend fun boostGmailAndFacebookBatching(): Boolean = withContext(Dispatchers.IO) {
        log("⚡ Đang phá gom cụm 0s cho Gmail & Facebook (JobScheduler / SyncManager)...", LogType.INFO)
        val ok = runVerifiedBatch(
            "Phá gom cụm 0s Gmail & Facebook",
            listOf(
                "settings put global job_scheduler_constants \"min_ready_non_active_jobs_count=1,max_non_active_job_batch_delay_ms=0\"",
                "device_config put jobscheduler min_ready_non_active_jobs_count 1",
                "device_config put jobscheduler max_non_active_job_batch_delay_ms 0",
                "settings put global sync_manager_constants \"initial_sync_retry_time_in_seconds=2,max_sync_retry_time_in_seconds=10\"",
                "settings put global bastet_switch 0",
                "settings put global smart_socket_switch 0",
                "am set-standby-bucket com.google.android.gm active"
            )
        )
        runDiagnosticScan()
        ok
    }

    suspend fun prioritizeAppCustomSounds(): Boolean = withContext(Dispatchers.IO) {
        log("🔊 Đang ưu tiên chuông riêng từng App & chống câm chuông...", LogType.INFO)
        val ok = runVerifiedBatch(
            "Ưu tiên Chuông riêng từng App",
            listOf(
                "settings put system notification_way_switch 0",
                "settings put system use_default_notification_sound 0",
                "settings put secure use_default_notification_sound 0",
                "settings put system app_custom_notification_sound_enabled 1",
                "settings put system notification_cooldown_enabled 0",
                "settings put secure notification_cooldown_enabled 0"
            )
        )
        refreshSetupStatus()
        runDiagnosticScan()
        ok
    }

    suspend fun removePowerGeniusAndIaware(): Boolean = withContext(Dispatchers.IO) {
        log("🗑 Đang gỡ bỏ PowerGenius & vô hiệu hóa iAware...", LogType.INFO)
        val ok = runVerifiedBatch(
            "Tắt PowerGenius & iAware",
            listOf(
                "pm disable-user --user 0 com.hihonor.powergenius",
                "settings put system iaware_switch 0",
                "settings put global iaware_switch 0",
                "cmd appops set com.hihonor.systemmanager GET_USAGE_STATS ignore"
            )
        )
        refreshSetupStatus()
        runDiagnosticScan()
        ok
    }

    suspend fun testPushNotification(pkg: String = "com.facebook.katana", appName: String = "Facebook"): Boolean = withContext(Dispatchers.IO) {
        log("🔔 Đang bắn thử thông báo kiểm tra rung chuông & biểu ngữ cho $appName...", LogType.INFO)
        val title = "MagicTune Push Tester ($appName)"
        val text = "Thông báo $appName hoạt động! Đã gỡ báo nhẹ nhàng và bật đầy đủ biểu ngữ nổi."
        runVerifiedBatch(
            "Bắn thử thông báo $appName",
            listOf(
                "cmd notification post -S bigtext -t \"$title\" \"magictune_test\" \"$text\""
            )
        )
    }

    // -------------------------------------------------------------
    // GỠ VÀ QUẢN LÝ APP (CẢ APP NGƯỜI DÙNG & APP HỆ THỐNG)
    // -------------------------------------------------------------
    suspend fun uninstallApp(pkg: String): Boolean = withContext(Dispatchers.IO) {
        log("🗑 Đang gỡ bỏ / đóng băng ứng dụng $pkg khỏi máy...", LogType.INFO)
        if (!shellEngine.state.value.isAdbReady) {
            return@withContext try {
                val intent = Intent(Intent.ACTION_DELETE).apply {
                    data = Uri.parse("package:$pkg")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                log("📱 Đã mở hộp thoại xác nhận gỡ cài đặt hệ thống cho $pkg", LogType.INFO)
                true
            } catch (e: Exception) {
                log("❌ Không thể mở trình gỡ cài đặt hệ thống: ${e.message}", LogType.ERROR)
                false
            }
        }
        val resUninstall = shellEngine.execute("pm uninstall --user 0 $pkg")
        log("> pm uninstall --user 0 $pkg", LogType.COMMAND)
        if (resUninstall.isSuccess && resUninstall.output.contains("Success", ignoreCase = true)) {
            log("✅ Đã gỡ bỏ hoàn toàn ứng dụng: $pkg", LogType.SUCCESS)
            // Cập nhật trạng thái trực tiếp trong danh sách để phản hồi tức thì
            updateSingleAppStatusInList(pkg, isInstalled = false, isFrozen = true)
            refreshAppsList()
            return@withContext true
        } else {
            log("⚠️ Chuyển sang đóng băng gói hệ thống: $pkg...", LogType.INFO)
            log("> pm disable-user --user 0 $pkg", LogType.COMMAND)
            val resDisable = shellEngine.execute("pm disable-user --user 0 $pkg")
            if (resDisable.isSuccess && resDisable.output.contains("disabled", ignoreCase = true)) {
                log("✅ Đã đóng băng thành công: $pkg", LogType.SUCCESS)
                updateSingleAppStatusInList(pkg, isInstalled = true, isFrozen = true)
                refreshAppsList()
                return@withContext true
            } else {
                log("❌ THẤT BẠI khi gỡ/đóng băng $pkg: ${resDisable.errorReason}", LogType.ERROR)
                refreshAppsList()
                return@withContext false
            }
        }
    }

    suspend fun restoreApp(pkg: String): Boolean = withContext(Dispatchers.IO) {
        log("🔄 Đang khôi phục ứng dụng $pkg...", LogType.INFO)
        val ok = runVerifiedBatch(
            "Khôi phục ứng dụng $pkg",
            listOf(
                "cmd package install-existing $pkg",
                "pm enable --user 0 $pkg",
                "cmd appops reset $pkg"
            )
        )
        // Cập nhật trạng thái trực tiếp để ứng dụng lập tức thoát khỏi tab "Đã gỡ/Tắt" sang tab người dùng/hệ thống
        updateSingleAppStatusInList(pkg, isInstalled = true, isFrozen = false)
        refreshAppsList()
        ok
    }

    private fun updateSingleAppStatusInList(pkg: String, isInstalled: Boolean, isFrozen: Boolean) {
        val currentList = _appsList.value.toMutableList()
        val index = currentList.indexOfFirst { it.packageName == pkg }
        if (index != -1) {
            val app = currentList[index]
            currentList[index] = app.copy(isInstalled = isInstalled, isFrozen = isFrozen)
            _appsList.value = currentList
        }
    }

    suspend fun fixAndroidAuto(): Boolean = withContext(Dispatchers.IO) {
        log("🚗 Đang cấp Full quyền & Fix lỗi kết nối Android Auto cho xe hơi (Gearhead)...", LogType.INFO)
        val pkg = "com.google.android.projection.gearhead"
        val cmds = listOf(
            "pm enable --user 0 $pkg",
            "dumpsys deviceidle whitelist +$pkg",
            "am set-standby-bucket $pkg active",
            "cmd appops set $pkg POST_NOTIFICATION allow",
            "cmd appops set $pkg SYSTEM_ALERT_WINDOW allow",
            "cmd appops set $pkg RUN_IN_BACKGROUND allow",
            "cmd appops set $pkg RUN_ANY_IN_BACKGROUND allow",
            "cmd appops set $pkg WAKE_LOCK allow",
            "cmd appops set $pkg PROJECT_MEDIA allow",
            "pm grant $pkg android.permission.ACCESS_FINE_LOCATION",
            "pm grant $pkg android.permission.ACCESS_COARSE_LOCATION",
            "pm grant $pkg android.permission.BLUETOOTH_CONNECT",
            "pm grant $pkg android.permission.BLUETOOTH_SCAN",
            "pm grant $pkg android.permission.RECORD_AUDIO",
            "settings put secure gearhead_fixed 1"
        )
        val ok = runVerifiedBatch("Fix Lỗi & Cấp Full Quyền Android Auto", cmds)
        if (ok) {
            shellEngine.markAppNotificationFixed(pkg, true)
            shellEngine.setPersistedSetting("secure", "gearhead_fixed", "1")
        }
        refreshTuneStatus()
        refreshAppsList()
        ok
    }

    suspend fun batchDebloatLevel1(): Boolean = withContext(Dispatchers.IO) {
        log("🗑 Đang kiểm tra danh sách app rác Cấp 1 thực tế có mặt trên máy...", LogType.INFO)
        refreshAppsList()
        val safeAppsToDisable = _appsList.value.filter { !it.isUserApp && it.level == 1 && it.isInstalled && !it.isFrozen }
        if (safeAppsToDisable.isEmpty()) {
            log("🎉 Toàn bộ app rác Cấp 1 đã được dọn sạch hoàn toàn trên thiết bị!", LogType.SUCCESS)
            return@withContext true
        }
        val cmds = safeAppsToDisable.map { "pm disable-user --user 0 " + it.packageName }
        val ok = runVerifiedBatch("Dọn sạch App rác Cấp 1 (${safeAppsToDisable.size} app)", cmds)
        refreshAppsList()
        refreshSetupStatus()
        runDiagnosticScan()
        ok
    }

    // -------------------------------------------------------------
    // TÙY BIẾN HIỆU NĂNG, TẮT YOYO THANH ĐIỀU HƯỚNG & CHẶN QUẢNG CÁO
    // -------------------------------------------------------------
    /**
     * Siêu Tiết Kiệm Pin Thông Minh (Không dùng Ultra Power Saving hệ thống, Không trễ thông báo)
     * - Bật Dark Mode OLED (tắt điểm ảnh màn hình OLED)
     * - Giảm animation scale về 0.5x tiết kiệm GPU render
     * - Whitelist các ứng dụng nhắn tin quan trọng (Zalo, Messenger, Telegram, Gmail, Viber, WhatsApp)
     *   để nhận thông báo tức thì (không bao giờ trễ)
     * - Ngăn dịch vụ crash / log vô ích gây hao pin
     */
    suspend fun applySmartBatterySaver(): Boolean = withContext(Dispatchers.IO) {
        log("🔋 Đang kích hoạt Chế độ Siêu Tiết Kiệm Pin Thông Minh (Zero Delay thông báo)...", LogType.INFO)
        val cmds = listOf(
            // 1. Chuyển sang Dark Mode OLED tiết kiệm năng lượng màn hình
            "settings put secure ui_night_mode 2",
            "settings put system ui_night_mode 2",
            // 2. Tinh chỉnh animation tiết kiệm GPU mà vẫn mượt mà
            "settings put global window_animation_scale 0.5",
            "settings put global transition_animation_scale 0.5",
            "settings put global animator_duration_scale 0.5",
            // 3. Tắt các dịch vụ theo dõi quảng cáo, gợi ý tốn pin
            "settings put secure advertising_id_opt_out 1",
            "settings put global personalized_ad_enabled 0",
            "settings put system auto_download_magazine_wifi 0",
            // 4. Đảm bảo whitelist không bị trễ thông báo cho các app nhắn tin phổ biến
            "dumpsys deviceidle whitelist +com.zing.zalo",
            "dumpsys deviceidle whitelist +com.facebook.orca",
            "dumpsys deviceidle whitelist +com.facebook.katana",
            "dumpsys deviceidle whitelist +org.telegram.messenger",
            "dumpsys deviceidle whitelist +org.telegram.plus",
            "dumpsys deviceidle whitelist +com.google.android.gm",
            "dumpsys deviceidle whitelist +com.whatsapp",
            "dumpsys deviceidle whitelist +com.viber.voip",
            // Đặt active bucket cho Zalo, Messenger, Telegram để không bị hạn chế ngầm
            "am set-standby-bucket com.zing.zalo active",
            "am set-standby-bucket com.facebook.orca active",
            "am set-standby-bucket org.telegram.messenger active",
            // 5. Giải phóng buffer dư thừa
            "setprop persist.sys.purge_buffers 1"
        )
        val ok = runVerifiedBatch("Siêu Tiết Kiệm Pin Thông Minh (Zero Delay)", cmds)
        refreshDeviceInfo()
        refreshTuneStatus()
        ok
    }

    /**
     * Tăng độ nhạy cảm ứng và nâng cao vùng nhận diện cử chỉ mép dưới màn hình:
     * Khắc phục triệt để tình trạng vuốt mép dưới khó ăn sau khi tắt YOYO hoặc do dán kính cường lực dày cản trở.
     */
    suspend fun enhanceBottomGestureSensitivity(): Boolean = withContext(Dispatchers.IO) {
        log("⚡ Đang xóa điểm chết cảm ứng đáy & kích hoạt cảm ứng ngay tại vị trí mép đáy (Fix kính cường lực & ẩn thanh điều hướng)...", LogType.INFO)
        val cmds = listOf(
            // 1. Giảm triệt để độ trễ và thời gian chặn cảm ứng chạm ở mép màn hình về 0
            "settings put secure touch_response_time 0",
            "settings put secure touch_responsiveness_level 1",
            "settings put secure tap_duration_threshold 0",
            "settings put secure touch_blocking_period 0",
            "settings put secure touch_edge_filter 0",
            "settings put system touch_edge_filter 0",
            
            // 2. Tinh chỉnh tốc độ con trỏ và kích hoạt cảm ứng sát mép kính dưới cùng
            "settings put system pointer_speed 7",
            
            // 3. Xóa điểm chết vùng từng hiện thanh kim: Nâng cao chiều cao và vùng nhận diện cử chỉ đáy
            "settings put secure gesture_nav_sensitivity 2",
            "settings put secure bottom_gesture_inset_scale 2",
            "settings put secure bottom_gesture_height 2",
            "settings put secure navigation_bar_gesture_height 2",
            "settings put system navigation_bar_gesture_height 2",
            "settings put secure back_gesture_inset_scale_left 0",
            "settings put secure back_gesture_inset_scale_right 0",
            
            // 4. Đảm bảo chế độ toàn màn hình không nuốt cảm ứng ở vùng thanh kim
            "settings put secure secure_gesture_navigation_immersive 0",
            "settings put global navigation_bar_touch_deadzone 0",
            "settings put secure navigation_bar_touch_deadzone 0",

            // 5. Tắt hoàn toàn cản trở từ YOYO điều hướng để trả lại 100% cảm ứng cho mép dưới
            "settings put secure navigation_bar_wakeup_yoyo 0",
            "settings put secure yoyo_navigation_bar_wakeup 0",
            "settings put system navigation_bar_wakeup_yoyo 0",
            "settings put secure wake_up_yoyo_by_nav_bar 0",
            "settings put secure assist_long_press_home_enabled 0"
        )
        val ok = runVerifiedBatch("Xóa điểm chết & Kích hoạt cảm ứng mép đáy", cmds)
        refreshDeviceInfo()
        refreshTuneStatus()
        ok
    }

    suspend fun applyMaxSettings(): Boolean = withContext(Dispatchers.IO) {
        log("🚀 Đang kích hoạt Max Settings toàn diện (120/144Hz, Animation 0.5x, Touch Boost, Tắt gọi YOYO)...", LogType.INFO)
        val ok = runVerifiedBatch(
            "Bật Max Settings Toàn Diện",
            listOf(
                "settings put system peak_refresh_rate 144.0",
                "settings put system min_refresh_rate 120.0",
                "settings put system user_refresh_rate 144",
                "settings put global window_animation_scale 0.5",
                "settings put global transition_animation_scale 0.5",
                "settings put global animator_duration_scale 0.5",
                "settings put secure touch_response_time 0",
                "settings put secure touch_responsiveness_level 1",
                "settings put global block_screen_capture 0",
                "settings put global 5g_mode 1",
                "settings put global nr_mode_switch 1",
                "settings put global bluetooth_absolute_volume 0",
                "settings put secure navigation_bar_wakeup_yoyo 0",
                "settings put secure yoyo_navigation_bar_wakeup 0",
                "settings put secure assistant com.google.android.googlequicksearchbox/com.google.android.voiceinteraction.GsaVoiceInteractionService",
                "settings put secure voice_interaction_service com.google.android.googlequicksearchbox/com.google.android.voiceinteraction.GsaVoiceInteractionService",
                "settings put secure assist_long_press_home_enabled 1",
                "settings put secure search_press_hold_nav_handle_enabled 1"
            )
        )
        refreshDeviceInfo()
        ok
    }

    suspend fun setRefreshRate(rate: Int): Boolean = withContext(Dispatchers.IO) {
        log("📺 Chỉnh tần số quét: ${rate}Hz...", LogType.INFO)
        val ok = runVerifiedBatch(
            "Chỉnh tần số quét ${rate}Hz",
            listOf(
                "settings put system peak_refresh_rate ${rate}.0",
                "settings put system min_refresh_rate ${if (rate > 90) 120 else 60}.0",
                "settings put system user_refresh_rate $rate"
            )
        )
        refreshDeviceInfo()
        ok
    }

    suspend fun setAnimationScale(scale: Float): Boolean = withContext(Dispatchers.IO) {
        log("⚡ Chỉnh tốc độ chuyển cảnh: ${scale}x...", LogType.INFO)
        val ok = runVerifiedBatch(
            "Chỉnh Animation ${scale}x",
            listOf(
                "settings put global window_animation_scale $scale",
                "settings put global transition_animation_scale $scale",
                "settings put global animator_duration_scale $scale"
            )
        )
        refreshTuneStatus()
        ok
    }

    /**
     * Danh sách đầy đủ các package tạo nên YOYO Agent / YOYO 助理 trên Honor MagicOS 8.0 / 9.0 / 10 / 11.
     * Trên ROM nội địa Trung Quốc, nếu còn bất kỳ package nào trong số này chạy ngầm (đặc biệt là com.hihonor.magicvoice và com.hihonor.yoyo),
     * HwPhoneWindowManager / SystemUI sẽ cưỡng bức chiếm quyền nhấn giữ thanh điều hướng để bật YOYO Agent bất chấp cài đặt Assistant mặc định!
     */
    private val honorYoyoAgentPackages = listOf(
        "com.hihonor.magicvoice",
        "com.hihonor.yoyo",
        "com.hihonor.assistant",
        "com.hihonor.ai.agent",
        "com.hihonor.aiagent",
        "com.hihonor.vassistant",
        "com.huawei.vassistant",
        "com.hihonor.voiceassistant",
        "com.hihonor.hiaction",
        "com.hihonor.hiaye"
    )

    private fun isPackageInstalledFast(pkg: String): Boolean {
        return try {
            context.packageManager.getPackageInfo(pkg, 0)
            true
        } catch (_: Exception) {
            false
        }
    }

    private suspend fun isPackageInstalledOnDevice(pkg: String): Boolean = withContext(Dispatchers.IO) {
        val pmInst = isPackageInstalledFast(pkg)
        if (pmInst) return@withContext true
        try {
            val path = shellEngine.execute("pm path $pkg 2>/dev/null").output
            path.isNotBlank() && path.contains("package:")
        } catch (_: Exception) {
            false
        }
    }

    private fun buildDisableAllYoyoAgentCommands(): List<String> {
        val cmds = mutableListOf(
            // 1. Khóa toàn bộ công tắc đánh thức YOYO Agent & HiAye ở cả 3 bảng secure / system / global của MagicOS 8 / 9 / 10 / 11
            "settings put secure navigation_bar_wakeup_yoyo 0",
            "settings put secure yoyo_navigation_bar_wakeup 0",
            "settings put system navigation_bar_wakeup_yoyo 0",
            "settings put global navigation_bar_wakeup_yoyo 0",
            "settings put secure wake_up_yoyo_by_nav_bar 0",
            "settings put secure yoyo_agent_nav_bar_wakeup 0",
            "settings put system yoyo_agent_nav_bar_wakeup 0",
            "settings put secure magic_voice_nav_wakeup 0",
            "settings put secure yoyo_assistant_gesture_switch 0",
            "settings put system yoyo_assistant_gesture_switch 0",
            "settings put secure voice_wakeup_switch 0",
            "settings put system ai_sub_switch 0",
            "settings put secure ai_sub_switch 0",
            "settings put secure smart_breath_switch 0",
            "settings put secure hiaye_switch 0",
            "settings put secure hiaction_enabled 0",

            // Cấu hình NÚT NGUỒN NHẤN GIỮ: Giữ ngắn (~0.5s) gọi Gemini Voice AI, Giữ lâu (>3s) hiện Menu Tắt Nguồn phần cứng
            "settings put global power_button_long_press 1",
            "settings put secure power_button_long_press 1",
            "settings put system power_button_long_press 1",
            "settings put global power_button_long_press_action 1",
            "settings put secure power_button_long_press_action 1",
            "settings put system power_button_long_press_action 1",
            "settings put secure key_power_long_press_action 1",
            "settings put system key_power_long_press_action 1",
            "settings put secure hw_power_key_long_press_assistant 1",
            "settings put system hw_power_key_long_press_assistant 1",
            "settings put secure power_key_long_press_timeout 500",
            "settings put global power_key_long_press_timeout 500",
            "settings put global long_press_on_power_behavior 5",
            "settings put secure long_press_on_power_behavior 5",
            "settings put global power_button_very_long_press 1",
            "settings put secure power_key_wakeup_yoyo 0",
            "settings put secure yoyo_power_key_wakeup 0"
        )
        // 2. Gỡ Role ASSISTANT khỏi YOYO Agent và khóa triệt để (disable-user / uninstall --user 0 / suspend / clear / appops ignore)
        for (pkg in honorYoyoAgentPackages) {
            cmds.add("cmd role remove-role-holder --user 0 android.app.role.ASSISTANT $pkg >/dev/null 2>&1 || true")
            cmds.add("pm disable-user --user 0 $pkg >/dev/null 2>&1 || true")
        }
        return cmds
    }

    /**
     * Mod phím điều hướng gọi YOYO thành gọi GOOGLE KHOANH TRÒN ĐỂ TÌM KIẾM (Circle to Search / Contextual Search).
     * Kết hợp 3 tầng:
     * 1. Gỡ chiếm quyền & khóa YOYO Agent / MagicVoice / HiAye cấp hệ thống.
     * 2. Gán Role ASSISTANT & Contextual Search cho Google App.
     * 3. Kích hoạt Cầu nối cảm ứng Thanh điều hướng đáy (Smart NavBar Bridge Overlay) & Chặn YOYO Foreground,
     *    đảm bảo nhấn giữ thanh điều hướng luôn gọi Google Khoanh Tròn Tìm Kiếm kể cả khi ROM Honor khóa cứng YOYO
     *    và giữ nguyên 100% khi TẮT Gỡ lỗi / Tắt Tùy chọn nhà phát triển!
     */
    private fun checkProOrTrialPermission(actionName: String): Boolean {
        val (allowed, msg) = LicenseManager.checkAndConsumeProOrTrial(context, actionName)
        if (!allowed) {
            log(msg, LogType.ERROR)
        }
        return allowed
    }

    suspend fun modNavBarToCircleToSearch(): Boolean = withContext(Dispatchers.IO) {
        // Miễn phí 100% cho TẤT CẢ người dùng (Google Khoanh Tròn Tìm Kiếm & Google Lens)
        log("⭕ Đang gỡ khóa cứng YOYO Agent & kích hoạt Ép Khoanh Tròn Tìm Kiếm + Dịch Màn Hình (Hoạt động cả khi TẮT Gỡ lỗi WLAN)...", LogType.INFO)
        grantSelfControlAndOverlayPermissions()

        val hasGoogleApp = isPackageInstalledOnDevice("com.google.android.googlequicksearchbox")
        if (!hasGoogleApp) {
            log("⚠️ LƯU Ý: Máy chưa cài ứng dụng 'Google' (com.google.android.googlequicksearchbox) từ CH Play! Tính năng Khoanh Tròn & Dịch Màn Hình vẫn hoạt động, nhưng bạn nên cài thêm app 'Google' để dùng Tìm Kiếm Giọng Nói.", LogType.INFO)
        }

        val ctsServiceFlat = "${context.packageName}/${com.example.core.service.MagicTuneCtsAccessibilityService::class.java.name}"
        val cmds = mutableListOf(
            "pm grant ${context.packageName} android.permission.WRITE_SECURE_SETTINGS",
            "pm grant ${context.packageName} android.permission.SYSTEM_ALERT_WINDOW",
            "pm grant ${context.packageName} android.permission.RECORD_AUDIO",
            "cmd appops set ${context.packageName} SYSTEM_ALERT_WINDOW allow",
            "cmd appops set --uid ${context.packageName} SYSTEM_ALERT_WINDOW allow",
            "cmd appops set ${context.packageName} RECORD_AUDIO allow",
            "cmd appops set --uid ${context.packageName} RECORD_AUDIO allow",
            "cmd appops set ${context.packageName} ACCESS_RESTRICTED_SETTINGS allow",
            "cmd appops set ${context.packageName} GET_USAGE_STATS allow"
        )
        cmds.addAll(buildDisableAllYoyoAgentCommands())
        cmds.addAll(
            listOf(
                // 3. Cấp quyền Micro & hiển thị nổi cho CẢ ứng dụng Google VÀ Google Gemini (để cả 2 tính năng hoạt động song song)
                "pm enable --user 0 com.google.android.googlequicksearchbox",
                "pm enable --user 0 com.google.android.apps.bard",
                "pm grant com.google.android.googlequicksearchbox android.permission.RECORD_AUDIO",
                "pm grant com.google.android.apps.bard android.permission.RECORD_AUDIO",
                "cmd appops set com.google.android.googlequicksearchbox RECORD_AUDIO allow",
                "cmd appops set com.google.android.apps.bard RECORD_AUDIO allow",
                "dumpsys deviceidle whitelist +com.google.android.googlequicksearchbox",
                "dumpsys deviceidle whitelist +com.google.android.apps.bard",
                "am set-standby-bucket com.google.android.googlequicksearchbox active",
                "am set-standby-bucket com.google.android.apps.bard active",
                "cmd appops set com.google.android.googlequicksearchbox SYSTEM_ALERT_WINDOW allow",
                "cmd appops set com.google.android.apps.bard SYSTEM_ALERT_WINDOW allow",
                "cmd appops set com.google.android.googlequicksearchbox RUN_IN_BACKGROUND allow",
                "cmd appops set com.google.android.googlequicksearchbox RUN_ANY_IN_BACKGROUND allow",
                "cmd appops set com.google.android.apps.bard RUN_IN_BACKGROUND allow",
                "cmd appops set com.google.android.apps.bard RUN_ANY_IN_BACKGROUND allow",
                "cmd appops set com.google.android.googlequicksearchbox GET_USAGE_STATS allow",

                // 4. Nhường quyền Trợ lý nổi hệ thống (ROLE_ASSISTANT & GsaVoiceInteractionService) cho Google Gemini
                // để khi người dùng gọi Gemini, Gemini luôn HIỆN NỔI NGAY TRÊN MÀN HÌNH mà không cần mở hẳn app Gemini,
                // trong khi Khoanh Tròn Tìm Kiếm vẫn hoạt động 100% qua Cầu nối Smart NavBar Bridge của MagicTune!
                "cmd role add-role-holder --user 0 android.app.role.ASSISTANT com.google.android.apps.bard 1",
                "cmd role add-role-holder --user 0 android.app.role.ASSISTANT com.google.android.googlequicksearchbox 1",
                "settings put secure assistant com.google.android.googlequicksearchbox/com.google.android.voiceinteraction.GsaVoiceInteractionService",
                "settings put secure voice_interaction_service com.google.android.googlequicksearchbox/com.google.android.voiceinteraction.GsaVoiceInteractionService",
                "settings put secure voice_recognition_service com.google.android.googlequicksearchbox/com.google.android.voicesearch.serviceapi.GoogleRecognitionService",
                "settings put secure assist_structure_enabled 1",
                "settings put secure assist_screenshot_enabled 1",
                "settings put secure assist_disclosure_enabled 1",

                // 5. Ngắt assist_long_press_home_enabled của hệ thống để Cầu nối Smart NavBar Bridge của MagicTune độc quyền bắt cử chỉ nhấn giữ thanh đáy
                "settings put secure assist_long_press_home_enabled 0",
                "settings put secure search_press_hold_nav_handle_enabled 0",
                "settings put secure key_home_long_press_action 0",
                "settings put system key_home_long_press_action 0",
                "settings put secure hw_assist_long_press_home_enabled 0",
                "settings put system hw_assist_long_press_home_enabled 0",
                "settings put secure contextual_search_enabled 1",
                "settings put global contextual_search_enabled 1",
                "settings put secure contextual_search_package com.google.android.googlequicksearchbox",
                "settings put global contextual_search_package com.google.android.googlequicksearchbox",
                "settings put secure visual_query_accessibility_detection_enabled 1",

                // 6. Đảm bảo thanh điều hướng hiển thị nhạy để nhấn giữ gọi Khoanh Tròn Tìm Kiếm
                "settings put secure hide_navigation_bar 0",
                "settings put system hide_navigation_bar 0",
                "settings put secure gesture_navigation_pill_display 0",

                // 7. Lưu cờ chế độ Mod Khoanh Tròn Tìm Kiếm Vĩnh Viễn
                "settings put secure google_assistant_wake 1",
                "settings put secure magictune_nav_mod_mode CIRCLE_TO_SEARCH"
            )
        )

        val ok = runVerifiedBatch(
            "Gỡ Khóa YOYO & Bật Ép Khoanh Tròn Tìm Kiếm + Dịch Màn Hình (Không cần WLAN)",
            cmds
        )
        // Giữ dịch vụ trợ năng ở trạng thái TẮT khi bình thường (chỉ tự bật trong 0.15 giây lúc chụp màn hình rồi tắt ngay để App Ngân Hàng không báo nguy hiểm)
        com.example.core.service.MagicTuneCtsAccessibilityService.disableServiceViaSecureSettings(context)
        com.example.core.service.SystemFloatingHudOverlay.savePersistentNavModMode(context, "CIRCLE_TO_SEARCH", explicitlyDisabled = false)
        shellEngine.setPersistedSetting("secure", "magictune_nav_mod_mode", "CIRCLE_TO_SEARCH")
        shellEngine.setPersistedSetting("secure", "contextual_search_enabled", "1")
        shellEngine.setPersistedSetting("secure", "google_assistant_wake", "1")
        shellEngine.enforceOfflineNavBarModGuard()
        shellEngine.startKeepAliveServiceIfNeeded()
        com.example.core.service.MagicTuneKeepAliveService.startOrUpdate(
            context,
            "Đang duy trì Google Khoanh Tròn & Trò chuyện Gemini 24/7 (Hoạt động cả khi tắt WLAN/ADB)",
            forceFromBootOrOverlay = true
        )
        com.example.core.service.SystemFloatingHudOverlay.syncNavBarBridge(context)
        log("✅ Đã kích hoạt Ép Khoanh Tròn Tìm Kiếm & Dịch Màn Hình (Đồng thời tự nhường quyền hiển thị nổi cho Gemini AI!): Nhấn giữ thanh điều hướng đáy để khoanh tròn tìm kiếm hoặc bấm nút ✨ Gemini / đọc 'Gemini' sau khi mở khóa khuôn mặt để gọi Gemini nổi tức thì.", LogType.SUCCESS)
        refreshSetupStatus()
        refreshDeviceInfo()
        refreshTuneStatus()
        ok
    }

    /**
     * Mod phím điều hướng gọi YOYO thành gọi GEMINI VOICE ĐỂ TRÒ CHUYỆN VỚI AI (Google Gemini Live / Voice Assistant).
     * Đảm bảo hoạt động bền vững kể cả khi TẮT Gỡ lỗi không dây / Tắt Shizuku / Tắt Tùy chọn nhà phát triển
     * mà không bao giờ bị quay về YOYO Agent.
     */
    suspend fun modNavBarToGeminiVoice(): Boolean = withContext(Dispatchers.IO) {
        val hasCustomKey = LicenseManager.getUserCustomGeminiKey(context).trim().isNotBlank()
        val canAccess = LicenseManager.canAccessGeminiLive(context)
        if (!canAccess) {
            log("🔒 Bạn đã hết lượt miễn phí cho Gemini Voice! Hãy nâng cấp PRO hoặc vào 'Ô #14 Thiết Lập' tự thêm Gemini API Key miễn phí từ aistudio.google.com để tiếp tục sử dụng.", LogType.ERROR)
            return@withContext false
        }
        if (!hasCustomKey) {
            checkProOrTrialPermission("Gọi Gemini Voice AI")
        }
        log("🎙️ Đang gỡ khóa cứng YOYO Agent & kích hoạt Cầu nối Mod Thanh Điều Hướng -> GỌI GEMINI VOICE NỔI TRÊN MÀN HÌNH...", LogType.INFO)
        grantSelfControlAndOverlayPermissions()

        val hasGoogleApp = isPackageInstalledOnDevice("com.google.android.googlequicksearchbox")
        val hasGeminiApp = isPackageInstalledOnDevice("com.google.android.apps.bard")
        if (!hasGoogleApp && !hasGeminiApp) {
            log("⚠️ LƯU Ý: Máy chưa cài ứng dụng 'Google' hoặc 'Google Gemini' từ CH Play! Đã khóa YOYO Agent, vui lòng tải 'Google' & 'Google Gemini' trên CH Play để gọi Gemini Voice.", LogType.ERROR)
        }

        val cmds = mutableListOf(
            "pm grant ${context.packageName} android.permission.WRITE_SECURE_SETTINGS",
            "pm grant ${context.packageName} android.permission.SYSTEM_ALERT_WINDOW",
            "pm grant ${context.packageName} android.permission.RECORD_AUDIO",
            "cmd appops set ${context.packageName} SYSTEM_ALERT_WINDOW allow",
            "cmd appops set --uid ${context.packageName} SYSTEM_ALERT_WINDOW allow",
            "cmd appops set ${context.packageName} RECORD_AUDIO allow",
            "cmd appops set --uid ${context.packageName} RECORD_AUDIO allow",
            "cmd appops set ${context.packageName} GET_USAGE_STATS allow"
        )
        cmds.addAll(buildDisableAllYoyoAgentCommands())
        cmds.addAll(
            listOf(
                // 3. Cấp full quyền chạy nền, Micro & cửa sổ nổi cho Google & Gemini
                "pm enable --user 0 com.google.android.googlequicksearchbox",
                "pm enable --user 0 com.google.android.apps.bard",
                "pm grant com.google.android.googlequicksearchbox android.permission.RECORD_AUDIO",
                "pm grant com.google.android.apps.bard android.permission.RECORD_AUDIO",
                "dumpsys deviceidle whitelist +com.google.android.googlequicksearchbox",
                "dumpsys deviceidle whitelist +com.google.android.apps.bard",
                "am set-standby-bucket com.google.android.googlequicksearchbox active",
                "am set-standby-bucket com.google.android.apps.bard active",
                "cmd appops set com.google.android.googlequicksearchbox SYSTEM_ALERT_WINDOW allow",
                "cmd appops set com.google.android.googlequicksearchbox RUN_IN_BACKGROUND allow",
                "cmd appops set com.google.android.googlequicksearchbox RUN_ANY_IN_BACKGROUND allow",
                "cmd appops set com.google.android.googlequicksearchbox RECORD_AUDIO allow",
                "cmd appops set com.google.android.apps.bard SYSTEM_ALERT_WINDOW allow",
                "cmd appops set com.google.android.apps.bard RUN_IN_BACKGROUND allow",
                "cmd appops set com.google.android.apps.bard RUN_ANY_IN_BACKGROUND allow",
                "cmd appops set com.google.android.apps.bard RECORD_AUDIO allow",

                // 4. Khóa Role Trợ lý mặc định sang Google Assistant
                "cmd role add-role-holder --user 0 android.app.role.ASSISTANT com.google.android.googlequicksearchbox >/dev/null 2>&1 || true",
                "settings put secure assistant com.google.android.googlequicksearchbox/com.google.android.voiceinteraction.GsaVoiceInteractionService",
                "settings put secure voice_interaction_service com.google.android.googlequicksearchbox/com.google.android.voiceinteraction.GsaVoiceInteractionService",
                "settings put secure voice_recognition_service com.google.android.googlequicksearchbox/com.google.android.voicesearch.serviceapi.GoogleRecognitionService",

                // 5. Cấu hình nhấn giữ thanh điều hướng & NHẤN 2 LẦN NÚT NGUỒN mở trực tiếp Trò chuyện Giọng nói Gemini Voice AI
                "settings put secure assist_long_press_home_enabled 1",
                "settings put secure key_home_long_press_action 1",
                "settings put system key_home_long_press_action 1",
                "settings put secure hw_assist_long_press_home_enabled 1",
                "settings put system hw_assist_long_press_home_enabled 1",
                "settings put secure search_press_hold_nav_handle_enabled 1",
                "settings put secure contextual_search_enabled 0",
                "settings put global contextual_search_enabled 0",
                "settings put secure assist_touch_gesture_enabled 1",
                "settings put secure assist_structure_enabled 1",
                "settings put secure assist_screenshot_enabled 1",
                "settings put secure assist_disclosure_enabled 1",

                // Cho phép gọi Gemini Voice ("Ok Google") ngay cả khi MÀN HÌNH KHÓA & TẮT MÀN HÌNH
                "settings put secure voice_unlock_switch 1",
                "settings put secure assist_screen_off_wake_enabled 1",
                "settings put secure lock_screen_voice_wake 1",
                "settings put secure assist_supports_show_when_locked 1",
                "settings put secure assist_supports_handles_speak_action 1",
                "settings put secure hotword_detection_enabled 1",

                // TẮT TỰ ĐỘNG LỐI TẮT MẶC ĐỊNH CỦA HONOR (Chụp ảnh nhanh / Ví Honor / HiVoice) ĐỂ TRÁNH XUNG ĐỘT KHÔNG HOẠT ĐỘNG
                "settings put secure camera_double_tap_power_gesture_disabled 1",
                "settings put global camera_double_tap_power_gesture_disabled 1",
                "settings put system camera_double_tap_power_gesture_disabled 1",
                "settings put secure double_click_power_key_launch_camera 0",
                "settings put system double_click_power_key_launch_camera 0",
                "settings put secure hw_double_click_power_key_launch_camera 0",
                "settings put system hw_double_click_power_key_launch_camera 0",
                "settings put secure double_click_power_key_launch_wallet 0",
                "settings put system double_click_power_key_launch_wallet 0",
                "settings put secure hw_double_click_power_key_launch_wallet 0",
                "settings put secure double_click_power_key_launch_hivoice 0",
                "settings put system double_click_power_key_launch_hivoice 0",
                "settings put secure double_click_power_key_launch_yoyo 0",
                "settings put system double_click_power_key_launch_yoyo 0",

                // 6. Kích hoạt Khoanh tròn màn hình & Trò chuyện Gemini AI trên thanh điều hướng đáy (Giữ nguyên 100% nút nguồn tắt máy gốc)
                "settings put secure contextual_search_enabled 1",
                "settings put global contextual_search_enabled 1",
                "settings put secure contextual_search_package com.google.android.googlequicksearchbox",
                "settings put secure visual_query_accessibility_detection_enabled 1",
                "device_config put launcher press_hold_nav_handle_to_search true",
                "device_config put systemui contextual_search_enabled true",
                "settings put global enable_freeform_support 1",
                "settings put global force_resizable_activities 1",
                "settings put secure google_assistant_wake 1",
                "settings put secure magictune_gemini_mic_wake 1",
                "settings put secure magictune_nav_mod_mode GEMINI_VOICE"
            )
        )

        val ok = runVerifiedBatch(
            "Gỡ Khóa YOYO & Mod Phím Điều Hướng -> Gọi Gemini Voice AI Nổi",
            cmds
        )
        com.example.core.service.SystemFloatingHudOverlay.savePersistentNavModMode(context, "GEMINI_VOICE", explicitlyDisabled = false)
        shellEngine.setPersistedSetting("secure", "magictune_nav_mod_mode", "GEMINI_VOICE")
        shellEngine.setPersistedSetting("secure", "magictune_gemini_mic_wake", "1")
        shellEngine.setPersistedSetting("secure", "contextual_search_enabled", "0")
        shellEngine.setPersistedSetting("secure", "google_assistant_wake", "1")
        shellEngine.enforceOfflineNavBarModGuard()
        shellEngine.startKeepAliveServiceIfNeeded()
        com.example.core.service.MagicTuneKeepAliveService.startOrUpdate(
            context,
            "Đang duy trì Google Khoanh Tròn & Trò chuyện Gemini 24/7 (Hoạt động cả khi tắt WLAN/ADB)",
            forceFromBootOrOverlay = true
        )
        com.example.core.service.SystemFloatingHudOverlay.syncNavBarBridge(context)
        log("✅ Đã BẬT Mod Phím Điều Hướng -> GỌI GEMINI VOICE AI NỔI TRỰC TIẾP TRÊN MÀN HÌNH thành công!", LogType.SUCCESS)
        log("👉 Bạn có thể nhấn giữ thanh điều hướng đáy bất cứ lúc nào để trò chuyện nổi với Gemini mà không cần mở app, hoặc bấm lại nút để TẮT khi muốn tiết kiệm pin Micro.", LogType.INFO)
        refreshSetupStatus()
        refreshDeviceInfo()
        refreshTuneStatus()
        ok
    }

    /**
     * Tắt tính năng lắng nghe giọng nói mở khóa 24/24 để tiết kiệm pin tối đa,
     * nhưng VẪN GIỮ NGUYÊN tính năng Google Khoanh Tròn & Vuốt Góc Gọi Gemini (không bật lại YOYO rác của Honor).
     */
    suspend fun disableGeminiVoiceMod(): Boolean = withContext(Dispatchers.IO) {
        log("🔋 Đang TẮT lắng nghe Micro mở khóa tự động để tiết kiệm pin (vẫn giữ nguyên Khoanh Tròn Google & vuốt góc gọi Gemini)...", LogType.INFO)
        com.example.core.service.SystemFloatingHudOverlay.releaseMicrophoneForGeminiImmediately(context)
        val cmds = listOf(
            "settings put secure magictune_gemini_mic_wake 0",
            "settings put secure magictune_nav_mod_mode CIRCLE_TO_SEARCH"
        )
        val ok = runVerifiedBatch("Tắt Lắng Nghe Micro Tự Động & Giữ Khoanh Tròn Google", cmds)
        com.example.core.service.SystemFloatingHudOverlay.savePersistentNavModMode(context, "CIRCLE_TO_SEARCH", explicitlyDisabled = false)
        shellEngine.setPersistedSetting("secure", "magictune_nav_mod_mode", "CIRCLE_TO_SEARCH")
        shellEngine.setPersistedSetting("secure", "magictune_gemini_mic_wake", "0")
        com.example.core.service.SystemFloatingHudOverlay.syncNavBarBridge(context)
        log("✅ Đã giải phóng Micro nền (Tiết kiệm pin tối đa) — Tính năng Khoanh Tròn Google & Vuốt góc gọi Gemini vẫn hoạt động 100%!", LogType.SUCCESS)
        refreshSetupStatus()
        refreshDeviceInfo()
        refreshTuneStatus()
        ok
    }

    /**
     * Đặt MagicTune làm Ứng Dụng Trợ Lý Ảo Mặc Định (Default Assistant) cho điện thoại Honor MagicOS.
     * Cho phép nhận diện "Ok Google" / "Hey Google" và cử chỉ hệ thống để gọi Gemini Live ngay cả khi màn hình đang khóa!
     */
    suspend fun setMagicTuneAsDefaultAssistant(): Boolean = withContext(Dispatchers.IO) {
        log("🌟 Đang thiết lập MagicTune thành ỨNG DỤNG TRỢ LÝ ẢO MẶC ĐỊNH cho điện thoại Honor...", LogType.INFO)
        val pkg = context.packageName
        val cmds = listOf(
            "pm grant $pkg android.permission.WRITE_SECURE_SETTINGS",
            "pm grant $pkg android.permission.SYSTEM_ALERT_WINDOW",
            "pm grant $pkg android.permission.RECORD_AUDIO",
            "cmd appops set $pkg SYSTEM_ALERT_WINDOW allow",
            "cmd appops set $pkg RECORD_AUDIO allow",
            // Đặt MagicTune làm Trợ lý mặc định hệ thống
            "cmd role add-role-holder --user 0 android.app.role.ASSISTANT $pkg >/dev/null 2>&1 || true",
            "settings put secure assistant $pkg/com.example.core.assistant.MagicTuneVoiceInteractionService",
            "settings put secure voice_interaction_service $pkg/com.example.core.assistant.MagicTuneVoiceInteractionService",
            "settings put secure voice_recognition_service $pkg/com.example.core.assistant.MagicTuneRecognitionService",
            // Bật đánh thức giọng nói khi màn hình khóa & tắt màn hình
            "settings put secure voice_unlock_switch 1",
            "settings put secure assist_screen_off_wake_enabled 1",
            "settings put secure lock_screen_voice_wake 1",
            "settings put secure assist_supports_show_when_locked 1",
            "settings put secure assist_supports_handles_speak_action 1",
            "settings put secure hotword_detection_enabled 1",
            "settings put secure assist_touch_gesture_enabled 1",
            "settings put secure assist_long_press_home_enabled 1",
            "settings put secure hw_assist_long_press_home_enabled 1",
            "settings put secure google_assistant_wake 1",
            "settings put secure magictune_nav_mod_mode GEMINI_VOICE"
        )
        val ok = runVerifiedBatch("Đặt MagicTune Làm Trợ Lý Ảo Mặc Định", cmds)
        com.example.core.service.SystemFloatingHudOverlay.savePersistentNavModMode(context, "GEMINI_VOICE", explicitlyDisabled = false)
        shellEngine.setPersistedSetting("secure", "magictune_nav_mod_mode", "GEMINI_VOICE")
        shellEngine.setPersistedSetting("secure", "magictune_gemini_mic_wake", "1")
        com.example.core.service.MagicTuneKeepAliveService.startOrUpdate(
            context,
            "Đang duy trì Google Khoanh Tròn & Trò chuyện Gemini 24/7",
            forceFromBootOrOverlay = true
        )
        com.example.core.service.SystemFloatingHudOverlay.syncNavBarBridge(context)

        // Mở cài đặt Ứng dụng hỗ trợ mặc định của hệ thống để người dùng kiểm tra trực quan
        withContext(Dispatchers.Main) {
            try {
                val intent = Intent(Settings.ACTION_VOICE_INPUT_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            } catch (_: Throwable) {
                try {
                    val intent = Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(intent)
                } catch (_: Throwable) {}
            }
        }

        log("✅ Đã thiết lập MagicTune thành Ứng Dụng Trợ Lý Ảo Mặc Định của máy Honor thành công!", LogType.SUCCESS)
        log("👉 Bạn có thể gọi 'Ok Google', 'Hey Google', 'Gemini' hoặc nhấn giữ nút nguồn/thanh đáy để gọi Gemini Live ngay cả khi màn hình đang khóa!", LogType.INFO)
        refreshSetupStatus()
        refreshDeviceInfo()
        refreshTuneStatus()
        ok
    }

    /**
     * Gọi thử ngay Google Khoanh Tròn Tìm Kiếm / Gemini Voice để kiểm tra trực tiếp
     * (Hoạt động cả trên các dòng máy Honor khóa cứng thanh điều hướng trong SystemUI và cả khi đã tắt Gỡ lỗi).
     */
    suspend fun testTriggerNavAssistantNow(): Boolean = withContext(Dispatchers.IO) {
        log("⚡ Đang kích hoạt trực tiếp Google Khoanh Tròn / Gemini Voice AI trên màn hình...", LogType.INFO)
        com.example.core.service.SystemFloatingHudOverlay.triggerConfiguredAssistantNow(context)
    }

    /**
     * Khôi phục lại trợ lý YOYO Agent gốc của Honor nếu người dùng muốn dùng lại YOYO
     */
    suspend fun restoreYoyoOriginal(): Boolean = withContext(Dispatchers.IO) {
        log("🔄 Đang cài đặt và mở lại YOYO Agent gốc của Honor...", LogType.INFO)
        val cmds = mutableListOf<String>()
        for (pkg in honorYoyoAgentPackages) {
            cmds.add("pm enable --user 0 $pkg")
        }
        cmds.addAll(
            listOf(
                "settings put secure navigation_bar_wakeup_yoyo 1",
                "settings put secure yoyo_navigation_bar_wakeup 1",
                "settings put system navigation_bar_wakeup_yoyo 1",
                "settings put secure wake_up_yoyo_by_nav_bar 1",
                "settings put secure yoyo_assistant_gesture_switch 1",
                "settings put secure google_assistant_wake 0",
                "settings put secure magictune_nav_mod_mode DEFAULT"
            )
        )
        val ok = runVerifiedBatch("Khôi phục YOYO Agent gốc", cmds)
        com.example.core.service.SystemFloatingHudOverlay.savePersistentNavModMode(context, "DEFAULT", explicitlyDisabled = true)
        shellEngine.setPersistedSetting("secure", "magictune_nav_mod_mode", "DEFAULT")
        shellEngine.setPersistedSetting("secure", "google_assistant_wake", "0")
        shellEngine.setPersistedSetting("secure", "navigation_bar_wakeup_yoyo", "1")
        com.example.core.service.SystemFloatingHudOverlay.syncNavBarBridge(context)
        refreshSetupStatus()
        refreshDeviceInfo()
        refreshTuneStatus()
        ok
    }

    /**
     * Chuyển đổi gọi YOYO sang gọi Google Assistant / Gemini Voice khi nhấn giữ thanh điều hướng dưới đáy
     * Giữ nguyên và hoạt động độc lập ngay cả khi rút cáp USB hoặc ngắt WLAN.
     */
    suspend fun remapNavBarToGoogleAssistant(): Boolean = withContext(Dispatchers.IO) {
        modNavBarToGeminiVoice()
    }

    /**
     * Bật hoặc Ẩn thanh kim cử chỉ điều hướng đáy màn hình (Navigation Pill Bar)
     */
    suspend fun toggleNavigationBarPill(hide: Boolean): Boolean = withContext(Dispatchers.IO) {
        val actionText = if (hide) "Ẩn thanh kim điều hướng MagicOS 11" else "Hiện thanh kim điều hướng"
        log("📱 Đang $actionText...", LogType.INFO)
        val hideVal = if (hide) "1" else "0"
        val pillDisplay = if (hide) "1" else "0"
        val hintVal = if (hide) "0" else "1"
        val immersiveVal = if (hide) "1" else "0"

        val cmds = listOf(
            "settings put secure gesture_navigation_pill_display $pillDisplay",
            "settings put system gesture_navigation_pill_display $pillDisplay",
            "settings put global gesture_navigation_pill_display $pillDisplay",
            "settings put system gesture_pill_display $pillDisplay",
            "settings put secure secure_gesture_navigation_immersive $immersiveVal",
            "settings put secure honor_hide_navigation_bar $hideVal",
            "settings put system honor_hide_navigation_bar $hideVal",
            "settings put secure hide_navigation_bar $hideVal",
            "settings put system hide_navigation_bar $hideVal",
            "settings put global hide_navigation_bar $hideVal",
            "settings put secure navigation_bar_hint $hintVal",
            "settings put system navigation_bar_hint $hintVal",
            "settings put secure show_gesture_bar $hintVal",
            "settings put system show_gesture_bar $hintVal",
            "settings put secure show_navigation_bar_hint $hintVal",
            "settings put system show_navigation_bar_hint $hintVal",
            "settings put secure gesture_hint_bar $hintVal"
        )
        val ok = runVerifiedBatch(actionText, cmds)
        refreshDeviceInfo()
        refreshTuneStatus()
        ok
    }

    /**
     * Tắt công tắc nhấn thanh điều hướng đánh thức YOYO (Không ẩn thanh điều hướng nếu người dùng chỉ muốn tắt YOYO)
     */
    suspend fun disableYoyoNavigationWake(): Boolean = withContext(Dispatchers.IO) {
        log("🛑 Đang gỡ bỏ hoàn toàn YOYO Agent khỏi thanh điều hướng & khôi phục cảm ứng mép đáy...", LogType.INFO)
        val cmds = mutableListOf<String>()
        cmds.addAll(buildDisableAllYoyoAgentCommands())
        cmds.addAll(
            listOf(
                "settings put secure assist_long_press_home_enabled 0",
                "settings put secure bottom_gesture_inset_scale 2",
                "settings put secure gesture_nav_sensitivity 2",
                "settings put secure touch_response_time 0",
                "settings put secure touch_responsiveness_level 1",
                "settings put secure touch_edge_filter 0",
                "settings put secure secure_gesture_navigation_immersive 0",
                "settings put global navigation_bar_touch_deadzone 0",
                "settings put secure navigation_bar_touch_deadzone 0"
            )
        )
        val ok = runVerifiedBatch(
            "Tắt sạch YOYO Agent & Khôi phục cảm ứng mép đáy",
            cmds
        )
        refreshSetupStatus()
        refreshDeviceInfo()
        refreshTuneStatus()
        runDiagnosticScan()
        ok
    }

    suspend fun hideNavigationBarPill(): Boolean = withContext(Dispatchers.IO) {
        toggleNavigationBarPill(true)
    }

    /**
     * Bật hoặc tắt tính năng phần cứng/hệ thống của điện thoại trực tiếp từ MagicTune
     */
    suspend fun toggleDeviceFeature(featureId: String, currentEnabled: Boolean): Boolean = withContext(Dispatchers.IO) {
        val targetState = !currentEnabled
        val stateNum = if (targetState) "1" else "0"
        log("⚡ Đang ${if (targetState) "BẬT" else "TẮT"} tính năng: $featureId...", LogType.INFO)

        val ok = when (featureId) {
            "wifi" -> {
                runVerifiedBatch(
                    "Bật/Tắt Wi-Fi",
                    listOf(
                        "svc wifi ${if (targetState) "enable" else "disable"}",
                        "cmd wifi set-wifi-enabled ${if (targetState) "enabled" else "disabled"}"
                    )
                )
            }
            "bluetooth" -> {
                runVerifiedBatch(
                    "Bật/Tắt Bluetooth",
                    listOf(
                        "svc bluetooth ${if (targetState) "enable" else "disable"}",
                        "cmd bluetooth_manager ${if (targetState) "enable" else "disable"}"
                    )
                )
            }
            "mobile_data" -> {
                runVerifiedBatch(
                    "Bật/Tắt Dữ liệu di động (4G/5G)",
                    listOf(
                        "svc data ${if (targetState) "enable" else "disable"}",
                        "settings put global mobile_data $stateNum"
                    )
                )
            }
            "gps", "gps_high_accuracy" -> {
                if (targetState) {
                    setupGpsVietnam()
                } else {
                    runVerifiedBatch(
                        "Tắt Định vị GPS",
                        listOf(
                            "settings put secure location_mode 0",
                            "cmd location set-location-enabled false"
                        )
                    )
                }
            }
            "nfc" -> {
                runVerifiedBatch(
                    "Bật/Tắt NFC",
                    listOf("svc nfc ${if (targetState) "enable" else "disable"}")
                )
            }
            "auto_rotate" -> {
                runVerifiedBatch(
                    "Tự động xoay màn hình",
                    listOf(
                        "settings put system accelerometer_rotation $stateNum",
                        if (targetState) "cmd window user-rotation free" else "cmd window user-rotation lock 0"
                    )
                )
            }
            "dark_mode" -> {
                setDarkModeOled(targetState)
            }
            "adblocker_dns" -> {
                if (targetState) enableAdBlocker() else disableAdBlocker()
            }
            "yoyo_nav_wake" -> {
                if (targetState) disableYoyoNavigationWake() else {
                    runVerifiedBatch(
                        "Khôi phục công tắc YOYO",
                        listOf(
                            "pm enable --user 0 com.hihonor.assistant",
                            "settings put secure navigation_bar_wakeup_yoyo 1",
                            "settings put system navigation_bar_wakeup_yoyo 1"
                        )
                    )
                }
            }
            "block_update" -> {
                if (targetState) blockHonorMarket() else {
                    runVerifiedBatch(
                        "Mở lại tự động cập nhật app",
                        listOf(
                            "pm enable --user 0 com.hihonor.appmarket",
                            "settings put global auto_update_app 1"
                        )
                    )
                }
            }
            "auto_sync" -> {
                try { ContentResolver.setMasterSyncAutomatically(targetState) } catch (_: Exception) {}
                runVerifiedBatch(
                    "Tự động đồng bộ tài khoản",
                    listOf(
                        "cmd content set-master-sync-automatically ${if (targetState) "true" else "false"}",
                        "settings put global auto_sync $stateNum"
                    )
                )
            }
            else -> false
        }

        refreshDeviceInfo()
        refreshTuneStatus()
        ok
    }

    suspend fun fixAudioDistortion(): Boolean = withContext(Dispatchers.IO) {
        log("🔊 Đang sửa lỗi méo tiếng loa & rè Bluetooth (Chuẩn 48kHz)...", LogType.INFO)
        val ok = runVerifiedBatch(
            "Chuẩn hóa Âm thanh 48kHz & Bluetooth",
            listOf(
                "settings put global bluetooth_absolute_volume 0",
                "settings put system sound_effects_enabled 0"
            )
        )
        refreshTuneStatus()
        ok
    }

    suspend fun setFontBoldLarge(enabled: Boolean): Boolean = withContext(Dispatchers.IO) {
        log("${if (enabled) "Bật" else "Tắt"} chữ to đậm dễ đọc...", LogType.INFO)
        val weight = if (enabled) 1.2 else 1.0
        val scale = if (enabled) 1.15 else 1.0
        val ok = runVerifiedBatch(
            "Chỉnh cỡ chữ & độ đậm",
            listOf(
                "settings put system font_weight_scale $weight",
                "settings put system font_scale $scale"
            )
        )
        refreshTuneStatus()
        ok
    }

    suspend fun setDarkModeOled(enabled: Boolean): Boolean = withContext(Dispatchers.IO) {
        log("${if (enabled) "Bật" else "Tắt"} Dark Mode OLED tiết kiệm pin...", LogType.INFO)
        val ok = runVerifiedBatch(
            "Chế độ tối Dark Mode OLED",
            listOf(
                "settings put secure ui_night_mode ${if (enabled) 2 else 1}",
                "settings put system ui_night_mode ${if (enabled) 2 else 1}",
                "cmd uimode night ${if (enabled) "yes" else "no"}"
            )
        )
        refreshDeviceInfo()
        refreshTuneStatus()
        ok
    }

    suspend fun unlockSecureScreenshot(): Boolean = withContext(Dispatchers.IO) {
        log("🔓 Đang mở khóa chụp màn hình ứng dụng bảo mật (Bank, Incognito)...", LogType.INFO)
        val ok = runVerifiedBatch(
            "Mở khóa chụp màn hình bảo mật",
            listOf(
                "settings put global block_screen_capture 0"
            )
        )
        refreshTuneStatus()
        ok
    }

    suspend fun enableAdBlocker(dnsHost: String = "dns.adguard-dns.com"): Boolean = withContext(Dispatchers.IO) {
        log("🛡 Đang kích hoạt Chặn Quảng Cáo Toàn Diện ($dnsHost)...", LogType.INFO)
        val ok = runVerifiedBatch(
            "Kích hoạt Chặn Quảng Cáo ($dnsHost)",
            listOf(
                "settings put global private_dns_mode hostname",
                "settings put global private_dns_specifier $dnsHost",
                "settings put secure advertising_id_opt_out 1",
                "settings put global personalized_ad_enabled 0",
                "settings put secure limit_ad_tracking 1",
                "settings put system auto_download_magazine_wifi 0"
            )
        )
        refreshDeviceInfo()
        ok
    }

    suspend fun disableAdBlocker(): Boolean = withContext(Dispatchers.IO) {
        log("🔄 Đang khôi phục cài đặt DNS mặc định...", LogType.INFO)
        val ok = runVerifiedBatch(
            "Tắt Chặn Quảng Cáo DNS",
            listOf(
                "settings put global private_dns_mode opportunistic",
                "settings delete global private_dns_specifier"
            )
        )
        refreshDeviceInfo()
        ok
    }

    suspend fun grantAllPermissionsAllApps(): Boolean = withContext(Dispatchers.IO) {
        log("🔍 Đang kiểm tra danh sách ứng dụng bị thiếu quyền chạy ngầm / thông báo trước khi cấp...", LogType.INFO)
        val scan = runDiagnosticScan()
        val problematicApps = scan.missingPermissionApps.filter {
            it.hasAnyPermissionIssue || it.hasAnyNotificationIssue
        }

        if (problematicApps.isEmpty()) {
            log(
                "🎉 KIỂM TRA HOÀN TẤT: Toàn bộ ${scan.allScannedAppsCount} ứng dụng người dùng đều đã có đủ 100% quyền chạy ngầm, pin & thông báo! Không cần chạy lại lệnh cho các app không bị lỗi.",
                LogType.SUCCESS
            )
            return@withContext true
        }

        val skippedCount = (scan.allScannedAppsCount - problematicApps.size).coerceAtLeast(0)
        log(
            "🛡 Phát hiện ${problematicApps.size} ứng dụng thiếu quyền (Đã bỏ qua $skippedCount ứng dụng đã đủ quyền). Đang tự động cấp FULL quyền...",
            LogType.INFO
        )
        grantSelfControlAndOverlayPermissions()

        val pkgs = problematicApps.map { it.packageName }.distinct()

        val cmds = pkgs.flatMap { pkg ->
            buildAppSwitchGrantCommands(pkg)
        }
        val ok = runVerifiedBatch("Tự động gạt công tắc Full quyền cho ${pkgs.size} ứng dụng thiếu quyền (Bỏ qua $skippedCount app đã đủ)", cmds)
        if (ok) {
            pkgs.forEach { shellEngine.markAppNotificationFixed(it, true) }
        }
        refreshAppsList()
        runDiagnosticScan()
        ok
    }

    // -------------------------------------------------------------
    // SHIZUKU CỦA MÁY
    // -------------------------------------------------------------
    suspend fun protectShizukuImmortal(): Boolean = withContext(Dispatchers.IO) {
        log("🛡 Đang kích hoạt Khiên Bất Tử cho Shizuku & giữ trạng thái Fix khi ngắt WLAN...", LogType.INFO)
        val ok = runVerifiedBatch(
            "Khiên Bất Tử Shizuku & Giữ Fix Vĩnh Viễn",
            listOf(
                "settings put global adb_charging_only 1",
                "settings put secure allow_charging_adb 1",
                "device_config put activity_manager max_phantom_processes 2147483647",
                "settings put global settings_enable_monitor_phantom_procs false",
                "dumpsys deviceidle whitelist +moe.shizuku.privileged.api",
                "am set-standby-bucket moe.shizuku.privileged.api active",
                "cmd appops set moe.shizuku.privileged.api RUN_IN_BACKGROUND allow",
                "cmd appops set moe.shizuku.privileged.api RUN_ANY_IN_BACKGROUND allow"
            )
        )
        shellEngine.markPersistentGrantActive()
        refreshShizukuInfo()
        ok
    }

    suspend fun authorizeShizukuCompanions(): Boolean = withContext(Dispatchers.IO) {
        log("🔑 Cấp Full đặc quyền cho MagicTune & các App hệ sinh thái Shizuku (Canta, Hail, AppOps, SD Maid)...", LogType.INFO)
        grantSelfControlAndOverlayPermissions()
        val installedRaw = runShell("pm list packages --user 0", false)
        val companions = listOf(
            context.packageName,
            "moe.shizuku.privileged.api",
            "io.github.samolego.canta",
            "com.aistra.hail",
            "rikka.appops",
            "eu.thedarken.sdm",
            "in.sunilpaulmathew.ashell"
        ).filter { installedRaw.isBlank() || installedRaw.contains(it) || it == context.packageName }

        val cmds = companions.flatMap { pkg ->
            listOf(
                "pm grant $pkg android.permission.WRITE_SECURE_SETTINGS",
                "pm grant $pkg android.permission.DUMP",
                "cmd appops set $pkg SYSTEM_ALERT_WINDOW allow",
                "dumpsys deviceidle whitelist +$pkg"
            )
        }
        runVerifiedBatch("Cấp quyền Hệ sinh thái Shizuku & MagicTune", cmds)
    }

    // -------------------------------------------------------------
    // HOÀN TÁC TOÀN DIỆN (RESTORE FACTORY SETTINGS)
    // -------------------------------------------------------------
    suspend fun restoreAllToFactoryDefault(): Boolean = withContext(Dispatchers.IO) {
        log("⏪ ĐANG KHÔI PHỤC TOÀN BỘ CÀI ĐẶT VỀ MẶC ĐỊNH GỐC CỦA HONOR...", LogType.INFO)
        val ok = runVerifiedBatch(
            "Khôi phục Cài đặt gốc",
            listOf(
                "settings put global window_animation_scale 1.0",
                "settings put global transition_animation_scale 1.0",
                "settings put global animator_duration_scale 1.0",
                "settings delete system peak_refresh_rate",
                "settings put system user_refresh_rate 0",
                "settings put system use_default_notification_sound 1",
                "settings put system lock_screen_notification_style 1",
                "settings put system gentle_notification_enabled 1",
                "settings put global auto_update_app 1",
                "pm enable --user 0 com.hihonor.appmarket",
                "settings put secure hiboard_switch 1",
                "settings put global bluetooth_absolute_volume 1",
                "settings put global private_dns_mode opportunistic",
                "settings delete global private_dns_specifier"
            )
        )
        refreshSetupStatus()
        refreshDeviceInfo()
        refreshAppsList()
        runDiagnosticScan()
        ok
    }

    // -------------------------------------------------------------
    // 5 QUYỀN NĂNG HỆ THỐNG CHUYÊN SÂU v2.5 (SUPPORT ANDROID 11 -> ANDROID 17)
    // -------------------------------------------------------------

    /**
     * 1. Vượt Chặn Chế Độ Nhà Phát Triển (Stealth Developer Mode Bypass):
     * Cho phép truy cập full 100% ứng dụng Ngân hàng, Ví điện tử, Game dù máy đang dùng Shizuku / Chế độ nhà phát triển.
     * Cơ chế: Ẩn cờ `development_settings_enabled` & `adb_enabled` khỏi các hàm kiểm tra của app bên thứ 3
     * trong khi giữ tiến trình `shizuku_server` (UID 2000) chạy ngầm bất tử trong RAM!
     */
    suspend fun enableStealthDeveloperModeBypass(): Boolean = withContext(Dispatchers.IO) {
        log("🛡️ [Stealth Bypass v2.5] Đang kích hoạt Ẩn Chế Độ Nhà Phát Triển & Gỡ Lỗi để mở full Banking / Ví điện tử / Game (Tương thích đến Android 17)...", LogType.INFO)
        val cmds = mutableListOf(
            // Giữ bất tử tiến trình Shizuku trong RAM trước khi ẩn cờ Developer Options
            "device_config set_sync_disabled_for_tests persistent",
            "device_config put activity_manager max_phantom_processes 2147483647",
            "settings put global settings_enable_monitor_phantom_procs false",
            "dumpsys deviceidle whitelist +moe.shizuku.privileged.api",
            "cmd appops set moe.shizuku.privileged.api RUN_IN_BACKGROUND allow",
            "cmd appops set moe.shizuku.privileged.api RUN_ANY_IN_BACKGROUND allow",
            // Ẩn cờ Chế độ nhà phát triển & Gỡ lỗi để App Ngân hàng kiểm tra thấy = 0 (An toàn tuyệt đối)
            "settings put global development_settings_enabled 0",
            "settings put secure development_settings_enabled 0",
            "settings put global adb_enabled 0",
            "settings put global adb_wifi_enabled 0",
            "settings put global bugreport_in_power_menu 0",
            "settings put secure mock_location 0",
            "settings put global wait_for_debugger 0",
            "settings put global magictune_dev_stealth 1"
        )

        // Chặn quyền tự quét danh sách gói/cài đặt nhạy cảm của các app kiểm tra gắt
        val bankingOrStrictApps = listOf(
            "com.vnpay.bidv",
            "com.vietcombank.mobile",
            "com.mbmobile",
            "com.techcombank.bb.app",
            "vn.com.techcombank.bb.app",
            "com.icb.igrp.mb", // VietinBank iPay
            "com.vnpay.agribank",
            "com.tpb.mb.gprsandroid",
            "com.vpbank.vpbankonline",
            "mobile.acb.com.vn",
            "com.mservice.momotransfer",
            "vn.zalopay.sdk"
        )
        for (pkg in bankingOrStrictApps) {
            cmds.add("cmd appops set $pkg GET_USAGE_STATS ignore")
            cmds.add("am force-stop $pkg")
        }

        val ok = runVerifiedBatch("Kích hoạt Ẩn Chế Độ Nhà Phát Triển (Truy cập Full App Banking & Game)", cmds)
        shellEngine.setPersistedSetting("global", "magictune_dev_stealth", "1")
        refreshTuneStatus()
        refreshDeviceInfo()
        log("✅ Đã ẩn hoàn toàn cờ Chế độ nhà phát triển & Gỡ lỗi USB/Wi-Fi trong khi vẫn giữ sống quyền Shizuku UID 2000! Bạn có thể mở các app Ngân hàng & Ví điện tử ngay lập tức.", LogType.SUCCESS)
        ok
    }

    /**
     * Khôi phục hiển thị menu Tùy chọn nhà phát triển trong Cài đặt khi người dùng cần chỉnh sửa.
     */
    suspend fun restoreDeveloperModeVisibility(): Boolean = withContext(Dispatchers.IO) {
        log("🔓 Đang hiển thị lại menu Tùy chọn nhà phát triển trong Cài đặt...", LogType.INFO)
        val ok = runVerifiedBatch(
            "Hiển thị lại Chế độ nhà phát triển",
            listOf(
                "settings put global development_settings_enabled 1",
                "settings put secure development_settings_enabled 1",
                "settings put global adb_enabled 1",
                "settings put global magictune_dev_stealth 0"
            )
        )
        shellEngine.setPersistedSetting("global", "magictune_dev_stealth", "0")
        refreshTuneStatus()
        refreshDeviceInfo()
        ok
    }

    /**
     * Sửa bệnh không mở được trang Cập nhật phần mềm hệ điều hành MagicOS (Honor / Huawei OUC / HOTA).
     */
    suspend fun fixMagicOSSystemUpdate(): Boolean = withContext(Dispatchers.IO) {
        log("🛠️ Đang khôi phục toàn diện tính năng Cập nhật hệ điều hành (OUC / HOTA / System Update)...", LogType.INFO)
        val cmds = listOf(
            // 1. Cài đặt lại nếu vô tình bị gỡ bằng pm uninstall -k --user 0
            "cmd package install-existing com.hihonor.ouc >/dev/null 2>&1 || true",
            "cmd package install-existing com.huawei.ouc >/dev/null 2>&1 || true",
            "cmd package install-existing com.hihonor.android.hwouc >/dev/null 2>&1 || true",
            "cmd package install-existing com.huawei.android.hwouc >/dev/null 2>&1 || true",
            "cmd package install-existing com.hihonor.systemupdate >/dev/null 2>&1 || true",
            "cmd package install-existing com.honor.systemupdate >/dev/null 2>&1 || true",

            // 2. Khôi phục trạng thái mặc định (default-state) & Kích hoạt lại an toàn (Chuẩn Android & MagicOS, loại bỏ hoàn toàn enable-user không tồn tại)
            "cmd package default-state --user 0 com.hihonor.ouc >/dev/null 2>&1 || true",
            "cmd package default-state --user 0 com.hihonor.android.hwouc >/dev/null 2>&1 || true",
            "cmd package default-state --user 0 com.hihonor.systemupdate >/dev/null 2>&1 || true",
            "cmd package default-state --user 0 com.huawei.ouc >/dev/null 2>&1 || true",
            "cmd package default-state --user 0 com.huawei.android.hwouc >/dev/null 2>&1 || true",
            "cmd package default-state --user 0 com.honor.systemupdate >/dev/null 2>&1 || true",

            // 3. Bật gói (pm enable an toàn có fallback || true chống bắn lỗi Exit Code 255/1 khi gói không có trong ROM)
            "pm enable com.hihonor.ouc >/dev/null 2>&1 || true",
            "pm enable com.hihonor.android.hwouc >/dev/null 2>&1 || true",
            "pm enable com.hihonor.systemupdate >/dev/null 2>&1 || true",
            "pm enable com.huawei.ouc >/dev/null 2>&1 || true",
            "pm enable com.huawei.android.hwouc >/dev/null 2>&1 || true",
            "pm enable com.honor.systemupdate >/dev/null 2>&1 || true",

            // 4. Mở khóa ẩn gói (unhide)
            "cmd package unhide com.hihonor.ouc >/dev/null 2>&1 || true",
            "cmd package unhide com.hihonor.android.hwouc >/dev/null 2>&1 || true",
            "cmd package unhide com.hihonor.systemupdate >/dev/null 2>&1 || true",
            "cmd package unhide com.huawei.ouc >/dev/null 2>&1 || true",
            "cmd package unhide com.huawei.android.hwouc >/dev/null 2>&1 || true",
            "cmd package unhide com.honor.systemupdate >/dev/null 2>&1 || true",

            // 4. Xóa các cờ chặn OTA do debloater hoặc phần mềm bên thứ 3 thiết lập
            "settings put global ota_disable_automatic_update 0",
            "settings put system ota_disable_automatic_update 0",
            "settings put secure ota_disable_automatic_update 0",
            "settings put global system_update_disabled 0",
            "settings delete global ota_disable_automatic_update >/dev/null 2>&1 || true",
            "settings delete system ota_disable_automatic_update >/dev/null 2>&1 || true",
            "settings delete secure ota_disable_automatic_update >/dev/null 2>&1 || true",

            // 5. Cấp quyền chạy ngầm & Whitelist pin cho OUC
            "dumpsys deviceidle whitelist +com.hihonor.android.hwouc >/dev/null 2>&1 || true",
            "dumpsys deviceidle whitelist +com.hihonor.ouc >/dev/null 2>&1 || true",
            "cmd appops set com.hihonor.android.hwouc RUN_IN_BACKGROUND allow >/dev/null 2>&1 || true",
            "cmd appops set com.hihonor.ouc RUN_IN_BACKGROUND allow >/dev/null 2>&1 || true",
            "cmd appops set com.hihonor.systemupdate RUN_IN_BACKGROUND allow >/dev/null 2>&1 || true",
            "settings put global magictune_systemupdate_fixed 1"
        )
        val ok = runVerifiedBatch("Khôi phục Cập nhật phần mềm MagicOS (OUC)", cmds)
        
        // Thử kích hoạt mở trang cập nhật bằng ADB am start
        shellEngine.execute("am start -a android.settings.SYSTEM_UPDATE_SETTINGS >/dev/null 2>&1 || am start -n com.hihonor.ouc/.ui.MainActivity >/dev/null 2>&1 || am start -n com.hihonor.android.hwouc/com.hihonor.android.hwouc.ui.NoticeActivity >/dev/null 2>&1 || true")

        try {
            val intent = Intent("android.settings.SYSTEM_UPDATE_SETTINGS").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Exception) {
            try {
                val intent = Intent().apply {
                    setClassName("com.hihonor.android.hwouc", "com.hihonor.android.hwouc.ui.NoticeActivity")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            } catch (_: Exception) {
                try {
                    val intent = Intent().apply {
                        setClassName("com.hihonor.ouc", "com.hihonor.ouc.ui.MainActivity")
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(intent)
                } catch (_: Exception) {}
            }
        }
        log("✅ ĐÃ KHÔI PHỤC THÀNH CÔNG: Đã bật lại OUC/HOTA, gỡ bỏ lệnh chặn OTA và mở trang Cập nhật phần mềm MagicOS!", LogType.SUCCESS)
        ok
    }

    /**
     * 2. Tương tác & Chỉnh sửa Tệp Hệ Thống (Android/data & Android/obb):
     * Mở khóa truy cập trực tiếp, đọc danh sách thư mục, kiểm tra dung lượng và cấp quyền đọc/ghi/giải nén cho Android 11 -> Android 17.
     */
    suspend fun unlockAndInspectRestrictedStorage(): Boolean = withContext(Dispatchers.IO) {
        log("📂 [System File Engine v2.5] Đang mở khóa & truy cập trực tiếp vào /sdcard/Android/data và /sdcard/Android/obb (Hỗ trợ Android 11 – Android 17)...", LogType.INFO)
        val selfPkg = context.packageName
        val fileManagerPkgs = listOf(
            selfPkg,
            "com.google.android.documentsui",
            "com.android.documentsui",
            "com.hihonor.filemanager",
            "com.huawei.hidisk",
            "pl.solidexplorer2",
            "com.lonelycatgames.Xplore",
            "bin.mt.plus",
            "ru.zdevs.zarchiver"
        )

        val unlockCmds = mutableListOf(
            "mkdir -p /sdcard/Android/data /sdcard/Android/obb /sdcard/MagicTune_Workspace",
            "chmod 777 /sdcard/MagicTune_Workspace"
        )
        for (pkg in fileManagerPkgs) {
            unlockCmds.add("cmd appops set $pkg MANAGE_EXTERNAL_STORAGE allow")
            unlockCmds.add("cmd appops set $pkg LEGACY_STORAGE allow")
            unlockCmds.add("cmd appops set $pkg READ_EXTERNAL_STORAGE allow")
            unlockCmds.add("cmd appops set $pkg WRITE_EXTERNAL_STORAGE allow")
            unlockCmds.add("cmd appops set $pkg NO_ISOLATED_STORAGE allow")
        }

        val ok = runVerifiedBatch("Mở khóa Toàn Quyền Truy Cập Android/data & Android/obb", unlockCmds)

        val dataListRaw = runShell("ls -1 /sdcard/Android/data 2>/dev/null | head -n 60", true)
        val obbListRaw = runShell("ls -1 /sdcard/Android/obb 2>/dev/null | head -n 60", true)

        val dataDirs = dataListRaw.lines().map { it.trim() }.filter { it.isNotBlank() && !it.startsWith("ls:") }
        val obbDirs = obbListRaw.lines().map { it.trim() }.filter { it.isNotBlank() && !it.startsWith("ls:") }

        val summary = "Đã mở khóa! Đọc trực tiếp ${dataDirs.size} thư mục Android/data & ${obbDirs.size} thư mục Android/obb"
        shellEngine.setPersistedSetting("secure", "magictune_restricted_storage_unlocked", "1")
        shellEngine.setPersistedSetting("secure", "magictune_data_folders_count", dataDirs.size.toString())
        shellEngine.setPersistedSetting("secure", "magictune_obb_folders_count", obbDirs.size.toString())
        shellEngine.setPersistedSetting("secure", "magictune_restricted_storage_summary", summary)

        if (dataDirs.isNotEmpty()) {
            log("📁 Danh sách thư mục trong /sdcard/Android/data (${dataDirs.size} mục): ${dataDirs.take(12).joinToString(", ")}${if (dataDirs.size > 12) "..." else ""}", LogType.SUCCESS)
        }
        if (obbDirs.isNotEmpty()) {
            log("📦 Danh sách thư mục trong /sdcard/Android/obb (${obbDirs.size} mục): ${obbDirs.take(12).joinToString(", ")}${if (obbDirs.size > 12) "..." else ""}", LogType.SUCCESS)
        }

        refreshTuneStatus()
        ok
    }

    /**
     * Giải nén (.zip / .obb) và đồng bộ tệp từ /sdcard/Download hoặc /sdcard/MagicTune_Workspace vào thẳng Android/data & Android/obb.
     */
    suspend fun extractAndSyncRestrictedObbAndData(): Boolean = withContext(Dispatchers.IO) {
        log("📦 Đang quét & giải nén tự động các tệp dữ liệu (.zip / .obb) vào thư mục hạn chế /sdcard/Android/data và /sdcard/Android/obb...", LogType.INFO)
        val script = listOf(
            "mkdir -p /sdcard/MagicTune_Workspace/Backup_Data /sdcard/MagicTune_Workspace/Extract_Out",
            "for z in /sdcard/Download/*.zip /sdcard/MagicTune_Workspace/*.zip; do if [ -f \"\$z\" ]; then unzip -o \"\$z\" -d /sdcard/MagicTune_Workspace/Extract_Out/ 2>/dev/null; fi; done",
            "ls -la /sdcard/Android/obb /sdcard/MagicTune_Workspace"
        ).joinToString("; ")
        runShell(script, true)
        log("✅ Hoàn tất giải nén & đồng bộ không gian làm việc /sdcard/MagicTune_Workspace <-> Android/data & Android/obb!", LogType.SUCCESS)
        unlockAndInspectRestrictedStorage()
    }

    /**
     * Dọn sạch bộ nhớ đệm rác (cache / logs / temp) nằm sâu trong /sdcard/Android/data mà trình dọn dẹp thường không thể chạm tới.
     */
    suspend fun cleanRestrictedAppCaches(): Boolean = withContext(Dispatchers.IO) {
        log("🧹 Đang dọn sạch bộ nhớ đệm rác nằm sâu trong /sdcard/Android/data/*/cache và code_cache qua quyền Shizuku UID 2000...", LogType.INFO)
        val ok = runVerifiedBatch(
            "Dọn Rác Sâu Trong Android/data/*/cache",
            listOf(
                "rm -rf /sdcard/Android/data/*/cache/* 2>/dev/null || true",
                "rm -rf /sdcard/Android/data/*/code_cache/* 2>/dev/null || true",
                "rm -rf /sdcard/Android/data/*/files/logs/* 2>/dev/null || true",
                "pm trim-caches 999999999999999999 2>/dev/null || true"
            )
        )
        refreshDeviceInfo()
        ok
    }

    /**
     * 3. Quản lý Gói Ứng Dụng Chuyên Sâu (Đóng băng / Vô hiệu hóa / Gỡ cài đặt / Cấp hoặc Thu hồi quyền hệ thống):
     */
    suspend fun freezeAppPackage(pkg: String, freeze: Boolean): Boolean = withContext(Dispatchers.IO) {
        val actionName = if (freeze) "Đóng băng (Suspend/Freeze) $pkg" else "Mở băng (Unsuspend) $pkg"
        log("❄️ Đang thực hiện: $actionName...", LogType.INFO)
        val cmds = if (freeze) {
            listOf(
                "am force-stop $pkg",
                "cmd package suspend --user 0 $pkg",
                "cmd appops set $pkg RUN_IN_BACKGROUND ignore",
                "cmd appops set $pkg RUN_ANY_IN_BACKGROUND ignore"
            )
        } else {
            listOf(
                "cmd package unsuspend --user 0 $pkg",
                "pm enable --user 0 $pkg",
                "cmd appops set $pkg RUN_IN_BACKGROUND allow",
                "cmd appops set $pkg RUN_ANY_IN_BACKGROUND allow"
            )
        }
        val ok = runVerifiedBatch(actionName, cmds)
        refreshAppsList()
        ok
    }

    suspend fun revokeSensitivePermissionsFromApp(pkg: String): Boolean = withContext(Dispatchers.IO) {
        log("🔒 Đang thu hồi các quyền nhạy cảm (Camera, Micro, Vị trí, Đọc bộ nhớ/Clipboard) của $pkg...", LogType.INFO)
        val cmds = listOf(
            "pm revoke --user 0 $pkg android.permission.CAMERA",
            "pm revoke --user 0 $pkg android.permission.RECORD_AUDIO",
            "pm revoke --user 0 $pkg android.permission.ACCESS_FINE_LOCATION",
            "pm revoke --user 0 $pkg android.permission.ACCESS_COARSE_LOCATION",
            "pm revoke --user 0 $pkg android.permission.READ_CONTACTS",
            "cmd appops set $pkg CAMERA ignore",
            "cmd appops set $pkg RECORD_AUDIO ignore",
            "cmd appops set $pkg FINE_LOCATION ignore",
            "cmd appops set $pkg COARSE_LOCATION ignore",
            "cmd appops set $pkg READ_CLIPBOARD ignore",
            "cmd appops set $pkg READ_CONTACTS ignore"
        )
        val ok = runVerifiedBatch("Thu hồi quyền nhạy cảm của $pkg", cmds)
        refreshAppsList()
        ok
    }

    /**
     * 4. Kiểm Soát Quyền Riêng Tư Cấp Độ Hệ Thống Sâu (Deep Privacy & Sensor Control - Android 11 -> Android 17):
     * Khóa/Mở cảm biến Camera, Microphone, Vị trí GPS và chống đọc trộm Clipboard ngầm trên toàn hệ thống.
     */
    suspend fun toggleDeepPrivacySensor(sensorType: String, block: Boolean): Boolean = withContext(Dispatchers.IO) {
        val stateVal = if (block) "1" else "0"
        val modeOp = if (block) "ignore" else "allow"
        val cmds = mutableListOf<String>()
        val title = when (sensorType.uppercase()) {
            "CAMERA" -> {
                cmds.add(if (block) "cmd sensor_privacy enable 0 camera" else "cmd sensor_privacy disable 0 camera")
                cmds.add(if (block) "cmd sensor_privacy enable camera" else "cmd sensor_privacy disable camera")
                shellEngine.setPersistedSetting("secure", "magictune_cam_blocked", stateVal)
                if (block) "Khóa Cảm Biến Camera Toàn Hệ Thống" else "Mở Lại Cảm Biến Camera"
            }
            "MICROPHONE" -> {
                cmds.add(if (block) "cmd sensor_privacy enable 0 microphone" else "cmd sensor_privacy disable 0 microphone")
                cmds.add(if (block) "cmd sensor_privacy enable microphone" else "cmd sensor_privacy disable microphone")
                shellEngine.setPersistedSetting("secure", "magictune_mic_blocked", stateVal)
                if (block) "Khóa Cảm Biến Micro Chống Nghe Lén" else "Mở Lại Cảm Biến Micro"
            }
            "LOCATION" -> {
                cmds.add(if (block) "settings put secure location_mode 0" else "settings put secure location_mode 3")
                cmds.add(if (block) "cmd location set-location-enabled false" else "cmd location set-location-enabled true")
                shellEngine.setPersistedSetting("secure", "magictune_loc_blocked", stateVal)
                if (block) "Đóng Băng Định Vị GPS Hệ Thống" else "Bật Lại Định Vị GPS Độ Chính Xác Cao"
            }
            "CLIPBOARD" -> {
                cmds.add("device_config put privacy clipboard_overlay_enabled ${if (block) "true" else "false"}")
                val thirdParty = runShell("pm list packages -3", false)
                    .lines()
                    .map { it.removePrefix("package:").trim() }
                    .filter { it.isNotBlank() && it != context.packageName && !it.contains("inputmethod") && !it.contains("labankey") }
                    .take(40)
                for (pkg in thirdParty) {
                    cmds.add("cmd appops set $pkg READ_CLIPBOARD $modeOp")
                }
                shellEngine.setPersistedSetting("secure", "magictune_clip_protected", stateVal)
                if (block) "Chặn Ứng Dụng Đọc Trộm Bộ Nhớ Tạm (Clipboard)" else "Mở Lại Quyền Clipboard Mặc Định"
            }
            else -> "Cập nhật Quyền Riêng Tư Hệ Thống"
        }

        val ok = runVerifiedBatch(title, cmds)
        refreshTuneStatus()
        refreshDeviceInfo()
        ok
    }

    /**
     * 5. Tự Động Hóa & Điều Khiển Hệ Thống (System Automation, Input Simulation & Hardware Key Macros):
     * Chạy các kịch bản tự động hóa sâu, mô phỏng thao tác cảm ứng/phím cứng và tối ưu luồng logic.
     */
    suspend fun runSystemAutomationMacro(macroType: String): Boolean = withContext(Dispatchers.IO) {
        log("🤖 [Automation Engine v2.5] Đang thực thi kịch bản tự động hóa: $macroType...", LogType.INFO)
        val cmds = when (macroType.uppercase()) {
            "RAM_PURGE_BOOST" -> {
                shellEngine.setPersistedSetting("secure", "magictune_active_macro", "Siêu Giải Phóng RAM & Tối Ưu Đa Nhiệm")
                listOf(
                    "am kill-all",
                    "pm trim-caches 999999999999999999",
                    "cmd activity idle-maintenance",
                    "settings put global window_animation_scale 0.5",
                    "settings put global transition_animation_scale 0.5",
                    "settings put global animator_duration_scale 0.5"
                )
            }
            "GAME_TURBO_MACRO" -> {
                shellEngine.setPersistedSetting("secure", "magictune_active_macro", "Kịch Bản Chiến Game 120Hz + Chặn Làm Phiền")
                listOf(
                    "settings put system peak_refresh_rate 120.0",
                    "settings put system min_refresh_rate 120.0",
                    "settings put secure game_gesture_disabled 1",
                    "cmd notification set_dnd priority",
                    "am kill-all"
                )
            }
            "SCREENSHOT_QUICK_KEY" -> {
                shellEngine.setPersistedSetting("secure", "magictune_active_macro", "Mô Phỏng Phím Chụp Màn Hình Nhanh")
                listOf(
                    "input keyevent 120" // KEYCODE_SYSRQ (Screenshot)
                )
            }
            "WAKE_AND_HOME_MACRO" -> {
                shellEngine.setPersistedSetting("secure", "magictune_active_macro", "Đánh Thức Màn Hình & Thu Gọn Về Home")
                listOf(
                    "input keyevent 224", // KEYCODE_WAKEUP
                    "input keyevent 3"    // KEYCODE_HOME
                )
            }
            "AUTO_SWIPE_CLEAN_RECENTS" -> {
                shellEngine.setPersistedSetting("secure", "magictune_active_macro", "Mô Phỏng Mở Đa Nhiệm & Giải Phóng")
                listOf(
                    "input keyevent 187", // KEYCODE_APP_SWITCH
                    "am kill-all"
                )
            }
            else -> listOf("echo automation_ok")
        }
        val ok = runVerifiedBatch("Kịch bản Tự động hóa: $macroType", cmds)
        refreshTuneStatus()
        refreshDeviceInfo()
        ok
    }

    companion object {
        fun openGoogleLocationAccuracySettings(context: Context): Boolean {
            val intents = listOf(
                Intent().apply {
                    setClassName("com.google.android.gms", "com.google.android.gms.location.settings.GoogleLocationAccuracyActivity")
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                },
                Intent("com.google.android.gms.location.settings.GOOGLE_LOCATION_ACCURACY").apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                },
                Intent().apply {
                    setClassName("com.google.android.gms", "com.google.android.location.settings.LocationSettingsActivity")
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                },
                Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
            )
            for (intent in intents) {
                try {
                    context.startActivity(intent)
                    return true
                } catch (_: Exception) {}
            }
            return false
        }

        fun openHonorAppLaunchSettings(context: Context): Boolean {
            val intents = listOf(
                Intent().apply {
                    setClassName("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity")
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                },
                Intent().apply {
                    setClassName("com.hihonor.systemmanager", "com.hihonor.systemmanager.startupmgr.ui.StartupNormalAppListActivity")
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                },
                Intent().apply {
                    setClassName("com.huawei.systemmanager", "com.huawei.systemmanager.appcontrol.activity.StartupAppControlActivity")
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                },
                Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                },
                Intent(Settings.ACTION_SETTINGS).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
            )
            for (intent in intents) {
                try {
                    context.startActivity(intent)
                    return true
                } catch (_: Exception) {}
            }
            return false
        }

        fun openGoogleMapsCompassCalibration(context: Context): Boolean {
            try {
                val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("geo:0,0?q=")).apply {
                    setPackage("com.google.android.apps.maps")
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
                return true
            } catch (_: Exception) {
                try {
                    val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://maps.google.com")).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(intent)
                    return true
                } catch (_: Exception) {
                    return false
                }
            }
        }

        private fun extractContextFromEngine(engine: ShellEngine): Context {
            val field = ShellEngine::class.java.getDeclaredField("context")
            field.isAccessible = true
            return field.get(engine) as Context
        }
    }
}
