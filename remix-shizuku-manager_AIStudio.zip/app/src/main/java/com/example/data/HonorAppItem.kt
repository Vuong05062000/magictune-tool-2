package com.example.data

import com.google.firebase.firestore.IgnoreExtraProperties

@IgnoreExtraProperties
data class HonorAppItem(
    val id: String = "",
    val name: String = "",
    val description: String = "",
    val downloadUrl: String = "",
    val category: String = "Tiện Ích", // "Tất cả", "Trợ Lý / AI", "Tiện Ích", "Tối Ưu / Mod", "Google Services"
    val version: String = "1.0",
    val author: String = "Admin VXM",
    val isProOnly: Boolean = false,
    val iconName: String = "apps",
    val status: String = "APPROVED", // "PENDING", "APPROVED", "REJECTED"
    val contributorEmail: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
