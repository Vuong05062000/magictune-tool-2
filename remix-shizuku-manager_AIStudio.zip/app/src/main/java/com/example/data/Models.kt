package com.example.data

const val APP_VERSION_NAME = "v3.3.5"

data class PhoneFeatureItem(
    val id: String,
    val name: String,
    val isEnabled: Boolean,
    val statusText: String,
    val detail: String = ""
)

data class DeviceInfo(
    val model: String = "Honor Device",
    val manufacturer: String = "HONOR",
    val brand: String = "HONOR",
    val deviceCodename: String = "Unknown",
    val board: String = "Unknown",
    val version: String = "Android 15",
    val sdkInt: Int = 35,
    val securityPatch: String = "Unknown",
    val magicOS: String = "MagicOS",
    val kernel: String = "Linux",
    val soc: String = "Unknown",
    val cpuCores: String = "8 nhân",
    val cpuFreq: String = "N/A",
    val abi: String = "arm64-v8a",
    val gpu: String = "Adreno / Mali",
    val ram: String = "Unknown",
    val ramUsedPercent: Float = 0f,
    val storage: String = "Unknown",
    val storageUsedPercent: Float = 0f,
    val batteryLevel: Int = 100,
    val batteryStatus: String = "Đang hoạt động",
    val batteryVoltage: String = "N/A",
    val batteryTech: String = "Li-poly",
    val batteryHealth: String = "Tốt",
    val batteryCycleCount: String = "N/A",
    val temp: String = "N/A",
    val screen: String = "Unknown",
    val refreshRate: String = "120Hz",
    val sensorCount: Int = 0,
    val uptime: String = "N/A",
    val serial: String = "LOCAL_ADB",
    val features: List<PhoneFeatureItem> = emptyList()
)

data class DebloatApp(
    val packageName: String,
    val name: String,
    val desc: String,
    val level: Int, // 0 = User App, 1 = Safe Bloatware, 2 = Caution System, 3 = Critical System
    val isInstalled: Boolean = true,
    val isFrozen: Boolean = false,
    val isUserApp: Boolean = false,
    val versionName: String = "",
    val isFullNotificationFixed: Boolean = false,
    val isFullPermissionGranted: Boolean = false,
    val causesNotificationDelay: Boolean = false
)

data class LogItem(
    val message: String,
    val type: LogType,
    val timestamp: String
)

enum class LogType {
    INFO,
    COMMAND,
    SUCCESS,
    ERROR
}

data class NewDeviceSetupStatus(
    val isVietnameseLocale: Boolean = false,
    val currentLocale: String = "zh-CN",
    val isVietnamTimezone: Boolean = false,
    val currentTimezone: String = "Asia/Shanghai",
    val is24HourFormat: Boolean = false,
    val gmsEnabled: Boolean = false,
    val playStoreInstalled: Boolean = false,
    val labanKeyInstalled: Boolean = false,
    val gboardInstalled: Boolean = false,
    val callerId84Fixed: Boolean = false,
    val captivePortalGlobal: Boolean = false,
    val volte5gUnlocked: Boolean = false,
    val chineseUiCleaned: Boolean = false,
    val honorMarketUpdateBlocked: Boolean = false,
    val powerGeniusRemoved: Boolean = false,
    val customAppSoundsEnabled: Boolean = false,
    val yoyoNavWakeDisabled: Boolean = false,
    val gpsOptimized: Boolean = false,
    val readyScore: Int = 0
)

data class ShizukuInfo(
    val isInstalled: Boolean = false,
    val isRunning: Boolean = false,
    val isPermissionGranted: Boolean = false,
    val isAdbWifiEnabled: Boolean = true,
    val isShizukuSeveredFromAdb: Boolean = false,
    val version: String = "13.5+",
    val serverPid: String = "UID 2000",
    val phantomKillerDisabled: Boolean = false,
    val usbChargingOnlyEnabled: Boolean = false
)

data class DiagnosticIssue(
    val id: String,
    val title: String,
    val description: String,
    val isFixed: Boolean,
    val fixCommandTag: String
)

data class AppNotificationDiagnostic(
    val packageName: String,
    val appName: String,
    val isUserApp: Boolean = true,
    val hasGentleNotification: Boolean = false,
    val hasBannerEnabled: Boolean = true,
    val hasBackgroundPermission: Boolean = true,
    val hasBatteryExemption: Boolean = true,
    val hasOverlayPermission: Boolean = true,
    val statusSummary: String = "Đã tối ưu"
) {
    val hasAnyNotificationIssue: Boolean
        get() = hasGentleNotification || !hasBannerEnabled

    val hasAnyPermissionIssue: Boolean
        get() = !hasBackgroundPermission || !hasBatteryExemption || !hasOverlayPermission
}

data class DiagnosticScanResult(
    val isScanning: Boolean = false,
    val hasScanned: Boolean = false,
    val lastScanTime: String = "Chưa quét",
    val systemDelayCauses: List<DiagnosticIssue> = emptyList(),
    val gentleAndBannerApps: List<AppNotificationDiagnostic> = emptyList(),
    val missingPermissionApps: List<AppNotificationDiagnostic> = emptyList(),
    val allScannedAppsCount: Int = 0
) {
    val unfixedSystemCausesCount: Int
        get() = systemDelayCauses.count { !it.isFixed }

    val unfixedGentleBannerCount: Int
        get() = gentleAndBannerApps.count { it.hasAnyNotificationIssue }

    val unfixedPermissionCount: Int
        get() = missingPermissionApps.count { it.hasAnyPermissionIssue }

    val totalRemainingIssues: Int
        get() = unfixedSystemCausesCount + unfixedGentleBannerCount + unfixedPermissionCount
}

data class FloatingMiniWindowState(
    val isVisible: Boolean = false,
    val isMinimizedBubble: Boolean = false,
    val isRunningAutomation: Boolean = false,
    val currentStep: Int = 0,
    val totalSteps: Int = 0,
    val currentAppName: String = "",
    val currentPackageName: String = "",
    val currentActionDetail: String = "Sẵn sàng chạy tự động...",
    val completedApps: List<String> = emptyList(),
    val hasOverlayPermission: Boolean = false,
    val hasControlPermission: Boolean = false
)

data class SearchableActionItem(
    val title: String,
    val description: String,
    val tab: String,
    val tag: String,
    val actionType: String
)

data class TuneStatus(
    val isAdBlockerEnabled: Boolean = false,
    val activeDnsHost: String = "Tự động (Mặc định)",
    val isYoyoWakeDisabled: Boolean = false,
    val isNavBarHidden: Boolean = false,
    val isAppMarketUpdateBlocked: Boolean = false,
    val isAudio48kFixed: Boolean = false,
    val isScreenshotUnlocked: Boolean = false,
    val isFontBoldLarge: Boolean = false,
    val isDarkModeOled: Boolean = false,
    val isAndroidAutoFixed: Boolean = false,
    val isGoogleAssistantWakeEnabled: Boolean = false,
    val isCircleToSearchEnabled: Boolean = false,
    val isGeminiVoiceEnabled: Boolean = false,
    val activeNavModMode: String = "NONE",
    val currentRefreshRate: Int = 120,
    val currentAnimationScale: Float = 1.0f,
    val isHonorSearchDisabled: Boolean = false,
    val isDevModeStealthActive: Boolean = false,
    val isRestrictedStorageUnlocked: Boolean = false,
    val restrictedDataFoldersCount: Int = 0,
    val restrictedObbFoldersCount: Int = 0,
    val restrictedStorageSummary: String = "Chưa quét thư mục giới hạn (Android/data & obb)",
    val isCameraPrivacyBlocked: Boolean = false,
    val isMicPrivacyBlocked: Boolean = false,
    val isLocationPrivacyBlocked: Boolean = false,
    val isClipboardPrivacyActive: Boolean = false,
    val activeAutomationMacro: String = "Mặc định",
    val isGoogleAppInstalled: Boolean = false,
    val isGeminiAppInstalled: Boolean = false,
    val isOverlayPermissionGranted: Boolean = false,
    val isHonorGpsFixed: Boolean = false
)
