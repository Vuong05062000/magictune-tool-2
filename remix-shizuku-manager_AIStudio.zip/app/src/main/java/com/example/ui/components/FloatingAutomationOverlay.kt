package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.PictureInPictureAlt
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.FloatingMiniWindowState
import com.example.ui.theme.*
import kotlin.math.roundToInt

@Composable
fun FloatingAutomationOverlay(
    state: FloatingMiniWindowState,
    onMinimizeToggle: (Boolean) -> Unit,
    onClose: () -> Unit,
    onStartLiveAutomation: () -> Unit,
    onEnterPipMultiWindow: () -> Unit,
    onOpenCurrentAppNotificationSettings: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    if (!state.isVisible) return

    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }

    Box(
        modifier = modifier
            .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    offsetX += dragAmount.x
                    offsetY += dragAmount.y
                }
            }
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .testTag("floating_mini_multiwindow")
    ) {
        if (state.isMinimizedBubble) {
            // Compact Floating Mini Bubble
            Row(
                modifier = Modifier
                    .shadow(12.dp, RoundedCornerShape(24.dp))
                    .clip(RoundedCornerShape(24.dp))
                    .background(Brush.horizontalGradient(listOf(MagicBlue, MagicCyan)))
                    .border(1.5.dp, Color.White.copy(alpha = 0.6f), RoundedCornerShape(24.dp))
                    .clickable { onMinimizeToggle(false) }
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (state.isRunningAutomation) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        color = Color.White,
                        strokeWidth = 2.dp
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.NotificationsActive,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                }
                Text(
                    text = if (state.isRunningAutomation) {
                        "Đang bật Full TB (${state.currentStep}/${state.totalSteps}): ${state.currentAppName}"
                    } else {
                        "Cửa sổ nổi Mini (${state.completedApps.size} app đã Fix)"
                    },
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black
                )
            }
        } else {
            // Expanded Floating Mini Multi-Window HUD
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(16.dp, RoundedCornerShape(18.dp)),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF060D1F)),
                border = androidx.compose.foundation.BorderStroke(
                    1.5.dp,
                    Brush.linearGradient(listOf(MagicCyan, MagicEmerald))
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Header Bar (Draggable Handle + PiP Mode + Minimize + Close X)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(if (state.isRunningAutomation) MagicCyan else MagicEmerald)
                            )
                            Text(
                                text = "🪟 CỬA SỔ NỔI ĐA NHIỆM MINI (LIVE)",
                                color = MagicCyanLight,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black
                            )
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            // Enter System PiP Multi-Window Button
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(MagicBlue.copy(alpha = 0.25f))
                                    .border(1.dp, MagicBlue, RoundedCornerShape(6.dp))
                                    .clickable { onEnterPipMultiWindow() }
                                    .padding(horizontal = 6.dp, vertical = 3.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.PictureInPictureAlt,
                                        contentDescription = "Cửa sổ nổi PiP",
                                        tint = MagicCyanLight,
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Text(
                                        text = "Thu nhỏ PiP",
                                        color = MagicCyanLight,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            // Minimize to Bubble
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(MagicSurfaceCard)
                                    .border(1.dp, MagicBorder, RoundedCornerShape(6.dp))
                                    .clickable { onMinimizeToggle(true) }
                                    .padding(horizontal = 6.dp, vertical = 3.dp)
                            ) {
                                Text(
                                    text = "—",
                                    color = TextPrimary,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }

                            // Close 'X'
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(MagicRose.copy(alpha = 0.25f))
                                    .border(1.dp, MagicRose, RoundedCornerShape(6.dp))
                                    .clickable { onClose() }
                                    .padding(horizontal = 7.dp, vertical = 3.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Dong",
                                    tint = Color.White,
                                    modifier = Modifier.size(13.dp)
                                )
                            }
                        }
                    }

                    // Live Progress Indicator
                    val progress = if (state.totalSteps > 0) {
                        (state.currentStep.toFloat() / state.totalSteps.toFloat()).coerceIn(0f, 1f)
                    } else 0f

                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = MagicEmerald,
                        trackColor = MagicSurfaceCard
                    )

                    // Current App & Action Box
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(MagicSurfaceCard)
                            .border(1.dp, MagicBorder, RoundedCornerShape(10.dp))
                            .padding(10.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (state.currentAppName.isNotBlank()) {
                                        "🎯 ${state.currentAppName}"
                                    } else {
                                        "🎯 Trình Tự Động Mở Full Thông Báo & Biểu Ngữ"
                                    },
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Black
                                )
                                if (state.totalSteps > 0) {
                                    Text(
                                        text = "Bước ${state.currentStep}/${state.totalSteps}",
                                        color = MagicEmerald,
                                        fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            Text(
                                text = state.currentActionDetail,
                                color = TextSecondary,
                                fontSize = 11.sp,
                                lineHeight = 15.sp
                            )
                        }
                    }

                    // Completed Apps Chips Stream (User sees each app turning green live!)
                    AnimatedVisibility(visible = state.completedApps.isNotEmpty()) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = "✅ ĐÃ GỠ BÁO NHẸ NHÀNG & BẬT FULL BIỂU NGỮ (${state.completedApps.size} APP):",
                                color = MagicEmerald,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Black
                            )
                            LazyRow(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(5.dp)
                            ) {
                                items(state.completedApps) { appName ->
                                    Row(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(MagicEmerald.copy(alpha = 0.18f))
                                            .border(1.dp, MagicEmerald.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                                            .padding(horizontal = 7.dp, vertical = 3.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.CheckCircle,
                                            contentDescription = null,
                                            tint = MagicEmerald,
                                            modifier = Modifier.size(10.dp)
                                        )
                                        Text(
                                            text = appName,
                                            color = MagicEmeraldLight,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Action Buttons inside Floating Mini Window
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onStartLiveAutomation,
                            enabled = !state.isRunningAutomation,
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MagicEmerald,
                                contentColor = Color(0xFF020617)
                            )
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (state.isRunningAutomation) "Đang tự động chạy..." else "Chạy Tự Động Ngay",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black
                            )
                        }

                        if (state.currentPackageName.isNotBlank() && state.currentPackageName != "android.system") {
                            Button(
                                onClick = { onOpenCurrentAppNotificationSettings(state.currentPackageName) },
                                modifier = Modifier.height(38.dp),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MagicSurfaceCard,
                                    contentColor = MagicCyan
                                )
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.OpenInNew,
                                    contentDescription = null,
                                    modifier = Modifier.size(13.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Xem Cài Đặt TB",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
