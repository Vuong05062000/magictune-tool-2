package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val MagicDarkBackground = Color(0xFF020617)
val MagicSurfaceDark = Color(0xFF0F172A)
val MagicSurfaceCard = Color(0xFF1E293B)
val MagicBorder = Color(0xFF334155)

val MagicBlue = Color(0xFF2563EB)
val MagicBlueLight = Color(0xFF60A5FA)
val MagicCyan = Color(0xFF06B6D4)
val MagicCyanLight = Color(0xFF67E8F9)
val MagicEmerald = Color(0xFF10B981)
val MagicEmeraldLight = Color(0xFF34D399)
val MagicAmber = Color(0xFFF59E0B)
val MagicAmberLight = Color(0xFFFCD34D)
val MagicRose = Color(0xFFF43F5E)
val MagicRoseLight = Color(0xFFFDA4AF)
val MagicPurple = Color(0xFF8B5CF6)
val MagicPurpleLight = Color(0xFFA78BFA)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
