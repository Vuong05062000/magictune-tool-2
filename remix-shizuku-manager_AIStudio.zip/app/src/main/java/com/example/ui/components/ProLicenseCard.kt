package com.example.ui.components

import android.Manifest
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.automirrored.filled.Login
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import com.example.core.license.LicenseManager
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun ProLicenseCard(
    modifier: Modifier = Modifier,
    cardNumberBadge: String = "Ô #21"
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var deviceId by remember { mutableStateOf(LicenseManager.getDeviceId(context)) }
    var isPro by remember { mutableStateOf(LicenseManager.isProActivated(context)) }
    var isAccountPro by remember { mutableStateOf(LicenseManager.isAccountProActivated(context)) }
    var previewAsNonPro by remember { mutableStateOf(false) }
    val effectiveIsPro = if (previewAsNonPro) false else isPro
    val effectiveIsAccountPro = if (previewAsNonPro) false else isAccountPro
    var licenseInput by remember { mutableStateOf("") }
    var upgradeKeyInput by remember { mutableStateOf("") }
    var showUpgradeToAccountProPanel by remember { mutableStateOf(false) }
    var selectedPurchaseTier by remember { mutableStateOf(0) } // 0 = Pro Thiết Bị (ID máy), 1 = Pro Tài Khoản
    var smsInputText by remember { mutableStateOf("") }
    var isKillSwitchTriggered by remember { mutableStateOf(false) }
    var isLoadingKillSwitch by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var successMessage by remember { mutableStateOf<String?>(null) }
    var showQrImage by remember { mutableStateOf(true) }
    var showSmsGuide by remember { mutableStateOf(false) }

    // VietQR is directly available without reading bank balance or SMS
    var isUserLoggedIn by remember {
        mutableStateOf(com.example.core.auth.FirebaseAuthManager.getCurrentUser() != null)
    }
    val openLoginScreen: () -> Unit = {
        try {
            val intent = Intent(context, com.example.MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra("TARGET_TAB", "LOGIN")
            }
            context.startActivity(intent)
        } catch (_: Exception) {}
    }

    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) {
                isPro = LicenseManager.isProActivated(context)
                isAccountPro = LicenseManager.isAccountProActivated(context)
                isUserLoggedIn = com.example.core.auth.FirebaseAuthManager.getCurrentUser() != null
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    val proStateVersion by LicenseManager.proStateVersionFlow.collectAsState()
    var bankName by remember { mutableStateOf(LicenseManager.getPaymentBankName(context)) }
    var bankCode by remember { mutableStateOf(LicenseManager.getPaymentBankCode(context)) }
    var accountNumber by remember { mutableStateOf(LicenseManager.getPaymentAccountNumber(context)) }
    var accountHolder by remember { mutableStateOf(LicenseManager.getPaymentAccountHolder(context)) }
    var currentProPrice by remember { mutableStateOf(LicenseManager.getProPrice(context)) }
    var accountProPrice by remember { mutableStateOf(LicenseManager.getAccountProPrice(context)) }
    var upgradeAccountProPrice by remember { mutableStateOf(LicenseManager.getUpgradeToAccountProPrice(context)) }

    LaunchedEffect(proStateVersion) {
        isPro = LicenseManager.isProActivated(context)
        isAccountPro = LicenseManager.isAccountProActivated(context)
        isUserLoggedIn = com.example.core.auth.FirebaseAuthManager.getCurrentUser() != null
        bankName = LicenseManager.getPaymentBankName(context)
        bankCode = LicenseManager.getPaymentBankCode(context)
        accountNumber = LicenseManager.getPaymentAccountNumber(context)
        accountHolder = LicenseManager.getPaymentAccountHolder(context)
        currentProPrice = LicenseManager.getProPrice(context)
        accountProPrice = LicenseManager.getAccountProPrice(context)
        upgradeAccountProPrice = LicenseManager.getUpgradeToAccountProPrice(context)
    }

    // Đăng ký nhận Broadcast tự động cập nhật UI khi SMS Receiver kích hoạt Pro hoặc Admin đổi cấu hình
    DisposableEffect(Unit) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                val ctx = context ?: return
                coroutineScope.launch {
                    val isProNow = LicenseManager.refreshProStatus(ctx)
                    isPro = isProNow
                    isAccountPro = LicenseManager.isAccountProActivated(ctx)
                    isUserLoggedIn = com.example.core.auth.FirebaseAuthManager.getCurrentUser() != null
                    bankName = LicenseManager.getPaymentBankName(ctx)
                    bankCode = LicenseManager.getPaymentBankCode(ctx)
                    accountNumber = LicenseManager.getPaymentAccountNumber(ctx)
                    accountHolder = LicenseManager.getPaymentAccountHolder(ctx)
                    currentProPrice = LicenseManager.getProPrice(ctx)
                    accountProPrice = LicenseManager.getAccountProPrice(ctx)
                    upgradeAccountProPrice = LicenseManager.getUpgradeToAccountProPrice(ctx)
                    if (isPro) {
                        successMessage = if (isAccountPro) {
                            "👑 ĐÃ KÍCH HOẠT PRO TÀI KHOẢN (ĐỔI MÁY TỰ DO - 1 MÁY/LẦN) THÀNH CÔNG!"
                        } else {
                            "⚡ TỰ ĐỘNG KÍCH HOẠT PRO THIẾT BỊ THÀNH CÔNG!"
                        }
                    }
                }
            }
        }
        val filter = IntentFilter().apply {
            addAction(LicenseManager.ACTION_PRO_ACTIVATED)
            addAction(LicenseManager.ACTION_CONFIG_UPDATED)
            addAction(com.example.core.auth.FirebaseAuthManager.ACTION_SINGLE_DEVICE_KICKED)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            context.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            context.registerReceiver(receiver, filter)
        }
        onDispose {
            try {
                context.unregisterReceiver(receiver)
            } catch (_: Exception) {}
        }
    }

    LaunchedEffect(Unit) {
        isLoadingKillSwitch = true
        coroutineScope.launch {
            val stopped = LicenseManager.checkKillSwitchRemote()
            isKillSwitchTriggered = stopped
            isLoadingKillSwitch = false

            if (!isPro && !stopped) {
                val isKnownDevicePro = LicenseManager.checkDeviceRecognizedProInCloud(context)
                if (isKnownDevicePro) {
                    isPro = true
                    isAccountPro = LicenseManager.isAccountProActivated(context)
                    Toast.makeText(context, "🔄 Nhận diện thiết bị quen thuộc! Khôi phục bản Pro vĩnh viễn thành công.", Toast.LENGTH_LONG).show()
                } else {
                    val isPaidOnline = LicenseManager.checkOnlinePaymentStatusRemote(context)
                    if (isPaidOnline) {
                        isPro = true
                        isAccountPro = LicenseManager.isAccountProActivated(context)
                        Toast.makeText(context, "🎉 Đã tự động phát hiện thanh toán thành công từ xa! Bản Pro đã kích hoạt vĩnh viễn!", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MagicSurfaceCard),
        border = androidx.compose.foundation.BorderStroke(
            1.5.dp,
            if (effectiveIsAccountPro) MagicAmber else if (effectiveIsPro) MagicEmerald else MagicPurple.copy(alpha = 0.6f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (previewAsNonPro && isPro) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(MagicAmber.copy(alpha = 0.2f))
                        .border(1.dp, MagicAmber, RoundedCornerShape(8.dp))
                        .padding(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "⚠️ XEM THỬ: Bạn đang thấy góc nhìn CHƯA CÓ PRO.",
                            color = MagicAmber,
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(
                            onClick = { previewAsNonPro = false },
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text("Thoát", color = MagicAmber, fontWeight = FontWeight.Black, fontSize = 11.sp)
                        }
                    }
                }
            }

            // Header Title
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (effectiveIsAccountPro) MagicAmber else if (effectiveIsPro) MagicEmerald else MagicPurpleLight)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = cardNumberBadge,
                            color = Color(0xFF020617),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                    Icon(
                        imageVector = if (effectiveIsPro) Icons.Default.CheckCircle else Icons.Default.Star,
                        contentDescription = null,
                        tint = if (effectiveIsAccountPro) MagicAmber else if (effectiveIsPro) MagicEmerald else MagicPurpleLight,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = when {
                            effectiveIsAccountPro -> "PRO TÀI KHOẢN (ĐỔI MÁY)"
                            effectiveIsPro -> "PRO THIẾT BỊ (THEO ID MÁY)"
                            else -> "MỞ KHÓA BẢN PRO VĨNH VIỄN"
                        },
                        modifier = Modifier.weight(1f),
                        color = if (effectiveIsAccountPro) MagicAmber else if (effectiveIsPro) MagicEmeraldLight else Color.White,
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Black,
                        softWrap = true
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(
                            if (effectiveIsAccountPro) MagicAmber.copy(alpha = 0.2f)
                            else if (effectiveIsPro) MagicEmerald.copy(alpha = 0.2f)
                            else MagicPurple.copy(alpha = 0.2f)
                        )
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = when {
                            effectiveIsAccountPro -> "👑 PRO TK"
                            effectiveIsPro -> "📱 PRO MÁY"
                            else -> "Tự Động 24/7"
                        },
                        color = if (effectiveIsAccountPro) MagicAmber else if (effectiveIsPro) MagicEmerald else MagicPurpleLight,
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            if (effectiveIsPro) {
                // Đã kích hoạt Pro (Pro Thiết Bị hoặc Pro Tài Khoản)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isAccountPro) MagicAmber.copy(alpha = 0.12f) else MagicEmerald.copy(alpha = 0.12f))
                        .border(
                            1.dp,
                            if (isAccountPro) MagicAmber.copy(alpha = 0.45f) else MagicEmerald.copy(alpha = 0.4f),
                            RoundedCornerShape(12.dp)
                        )
                        .padding(12.dp)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = if (isAccountPro) {
                                "👑 BẠN ĐANG SỬ DỤNG GÓI PRO TÀI KHOẢN (ĐỔI MÁY TỰ DO)"
                            } else {
                                "📱 BẠN ĐANG SỬ DỤNG GÓI PRO THIẾT BỊ (CỐ ĐỊNH THEO ID MÁY)"
                            },
                            color = if (isAccountPro) MagicAmber else MagicEmerald,
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Black,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (isAccountPro) {
                                val currentEmail = com.example.core.auth.FirebaseAuthManager.getCurrentUser()?.email
                                if (!currentEmail.isNullOrBlank()) {
                                    "Tài khoản liên kết: $currentEmail • Thiết bị đang hoạt động: $deviceId\n(Đăng nhập trên máy mới vẫn dùng được đầy đủ Pro • Máy cũ sẽ tự động đăng xuất)"
                                } else {
                                    "Mã máy: $deviceId • Hãy đăng nhập tài khoản ở mục Tài Khoản để lưu quyền Pro theo Email khi đổi máy!"
                                }
                            } else {
                                "Mã thiết bị (ID máy): $deviceId\n(Bản Pro hiện tại chỉ gắn với ID máy này. Nếu muốn đăng nhập sang máy khác vẫn dùng được Pro, hãy nâng cấp lên Pro Tài Khoản bên dưới)"
                            },
                            color = TextSecondary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            textAlign = TextAlign.Center,
                            lineHeight = 15.sp
                        )

                        val currentFixedKey = remember(deviceId) {
                            if (isAccountPro) LicenseManager.generateAccountProLicenseKeyForDevice(deviceId)
                            else LicenseManager.generateLicenseKeyForDevice(deviceId)
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Khung hiển thị Key cố định của thiết bị kèm nút Sao chép
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0xFF0F172A))
                                .border(1.dp, MagicCyan.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                                .padding(horizontal = 10.dp, vertical = 8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "🔑 KEY KÍCH HOẠT CỐ ĐỊNH CỦA MÁY:",
                                        color = MagicCyanLight,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = currentFixedKey,
                                        color = Color.White,
                                        fontSize = 12.5.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                                Button(
                                    onClick = {
                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        clipboard.setPrimaryClip(ClipData.newPlainText("ProKey", currentFixedKey))
                                        Toast.makeText(context, "📋 Đã sao chép Key: $currentFixedKey", Toast.LENGTH_SHORT).show()
                                    },
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                    shape = RoundedCornerShape(6.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = MagicCyan)
                                ) {
                                    Icon(imageVector = Icons.Default.ContentCopy, contentDescription = null, tint = Color(0xFF020617), modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Sao Chép", color = Color(0xFF020617), fontSize = 10.5.sp, fontWeight = FontWeight.Black)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Hộp nhắc nhở người dùng lưu giữ Key & Đăng nhập để đảm bảo 100% không mất Pro
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(MagicAmber.copy(alpha = 0.12f))
                                .border(1.dp, MagicAmber.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                                .padding(10.dp)
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(imageVector = Icons.Default.Bookmark, contentDescription = null, tint = MagicAmber, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "LƯU Ý BẢO LƯU PRO VĨNH VIỄN (QUAN TRỌNG):",
                                        color = MagicAmber,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                                Text(
                                    text = "• Mỗi thiết bị được hệ thống cấp cố định MỘT KEY DUY NHẤT. Bạn hãy sao chép lưu giữ Key này để dùng về sau nếu lỡ cài lại máy hoặc vô tình mất bản Pro.\n• HOẶC ĐĂNG NHẬP TÀI KHOẢN: Khi đăng nhập, thiết bị Pro sẽ được tự động ghi nhớ vĩnh viễn vào tài khoản của bạn trên đám mây. Về sau nếu lỡ lỗi không thấy Pro, CHỈ CẦN ĐĂNG NHẬP LÀ THIẾT BỊ 100% ĐƯỢC TỰ ĐỘNG KHÔI PHỤC BẢN PRO!",
                                    color = Color(0xFFE2E8F0),
                                    fontSize = 10.5.sp,
                                    lineHeight = 15.sp
                                )
                                if (!isUserLoggedIn) {
                                    Spacer(modifier = Modifier.height(2.dp))
                                    OutlinedButton(
                                        onClick = openLoginScreen,
                                        modifier = Modifier.fillMaxWidth().height(34.dp),
                                        shape = RoundedCornerShape(8.dp),
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MagicAmber),
                                        border = androidx.compose.foundation.BorderStroke(1.dp, MagicAmber)
                                    ) {
                                        Icon(imageVector = Icons.AutoMirrored.Filled.Login, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Đăng Nhập Ngay Để Bảo Lưu Quyền Pro 100%", fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }



                // NẾU ĐANG LÀ PRO THIẾT BỊ (CHƯA LÊN PRO TÀI KHOẢN) -> HIỆN KHUNG NÂNG CẤP LÊN PRO TÀI KHOẢN (TRẢ THÊM CHÊNH LỆCH)
                if (!isAccountPro) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(MagicAmber.copy(alpha = 0.1f))
                            .border(1.dp, MagicAmber.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                            .padding(12.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "🚀 NÂNG CẤP LÊN PRO TÀI KHOẢN",
                                    color = MagicAmber,
                                    fontSize = 12.5.sp,
                                    fontWeight = FontWeight.Black
                                )
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(MagicAmber.copy(alpha = 0.22f))
                                        .padding(horizontal = 8.dp, vertical = 3.dp)
                                ) {
                                    Text(
                                        text = "Phí nâng cấp: +$upgradeAccountProPrice",
                                        color = MagicAmber,
                                        fontSize = 10.5.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }

                            Text(
                                text = "• Chuyển từ Pro theo ID máy lên Pro Tài Khoản để có thể đăng nhập sang thiết bị khác và dùng toàn bộ tính năng Pro.\n• Lưu ý bảo mật: Mỗi tài khoản chỉ đăng nhập được trên 1 máy tại 1 thời điểm (khi đăng nhập trên máy mới, máy cũ sẽ tự động đăng xuất).",
                                color = TextSecondary,
                                fontSize = 11.sp,
                                lineHeight = 15.sp
                            )

                            Button(
                                onClick = { showUpgradeToAccountProPanel = !showUpgradeToAccountProPanel },
                                modifier = Modifier.fillMaxWidth().height(40.dp),
                                shape = RoundedCornerShape(9.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MagicAmber,
                                    contentColor = Color(0xFF020617)
                                )
                            ) {
                                Icon(
                                    imageVector = if (showUpgradeToAccountProPanel) Icons.Default.ExpandLess else Icons.Default.Upgrade,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (showUpgradeToAccountProPanel) "ẨN BẢNG NÂNG CẤP PRO TÀI KHOẢN" else "NÂNG CẤP TỪ PRO MÁY LÊN PRO TÀI KHOẢN (+$upgradeAccountProPrice)",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }

                            AnimatedVisibility(visible = showUpgradeToAccountProPanel) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(top = 6.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    if (!isUserLoggedIn) {
                                        // CHỈ HIỆN MÃ QR CHUYỂN KHOẢN KHI ĐÃ ĐĂNG NHẬP ĐỐI VỚI TRƯỜNG HỢP MÁY PRO MUỐN LÊN TÀI KHOẢN PRO
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(10.dp))
                                                .background(MagicRose.copy(alpha = 0.14f))
                                                .border(1.2.dp, MagicRose.copy(alpha = 0.6f), RoundedCornerShape(10.dp))
                                                .padding(12.dp)
                                        ) {
                                            Column(
                                                horizontalAlignment = Alignment.CenterHorizontally,
                                                verticalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.Center
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Lock,
                                                        contentDescription = null,
                                                        tint = MagicRoseLight,
                                                        modifier = Modifier.size(16.dp)
                                                    )
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Text(
                                                        text = "CẦN ĐĂNG NHẬP TÀI KHOẢN ĐỂ HIỆN MÃ QR NÂNG CẤP",
                                                        color = MagicRoseLight,
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.Black
                                                    )
                                                }
                                                Text(
                                                    text = "Máy của bạn đang là Pro Thiết Bị. Để tránh trường hợp bạn chuyển khoản nâng cấp (+$upgradeAccountProPrice) rồi nhưng chưa có tài khoản thật để hệ thống gắn quyền Pro Tài Khoản, vui lòng Đăng Nhập tài khoản trước khi quét mã QR!",
                                                    color = Color(0xFFE2E8F0),
                                                    fontSize = 10.5.sp,
                                                    lineHeight = 14.5.sp,
                                                    textAlign = TextAlign.Center
                                                )
                                                Button(
                                                    onClick = { openLoginScreen() },
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .defaultMinSize(minHeight = 38.dp),
                                                    shape = RoundedCornerShape(8.dp),
                                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                                                    colors = ButtonDefaults.buttonColors(containerColor = MagicAmber, contentColor = Color(0xFF020617))
                                                ) {
                                                    Icon(imageVector = Icons.Default.Person, contentDescription = null, modifier = Modifier.size(15.dp))
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Text("🔐 ĐĂNG NHẬP / ĐĂNG KÝ NGAY ĐỂ HIỆN MÃ QR", fontSize = 10.5.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
                                                }
                                            }
                                        }
                                    } else {
                                        val numericUpgradeAmount = upgradeAccountProPrice.replace(Regex("[^0-9]"), "").ifBlank { "50000" }
                                        val upgradeAddInfo = "UPPRO $deviceId"
                                        val encodedHolder = try {
                                            java.net.URLEncoder.encode(accountHolder, "UTF-8")
                                        } catch (_: Exception) { accountHolder }
                                        val encodedInfo = try {
                                            java.net.URLEncoder.encode(upgradeAddInfo, "UTF-8")
                                        } catch (_: Exception) { upgradeAddInfo }
                                        val upgradeQrUrl = "https://img.vietqr.io/image/$bankCode-$accountNumber-compact2.png?amount=$numericUpgradeAmount&addInfo=$encodedInfo&accountName=$encodedHolder"

                                        Text(
                                            text = "💳 Ngân hàng: $accountNumber ($bankName) - $accountHolder\n• Số tiền trả thêm: $upgradeAccountProPrice\n• Nội dung CK: $upgradeAddInfo",
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            lineHeight = 15.5.sp
                                        )

                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(10.dp))
                                                .background(Color.White)
                                                .padding(8.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                                AsyncImage(
                                                    model = upgradeQrUrl,
                                                    contentDescription = "Mã VietQR Nâng Cấp Pro Tài Khoản",
                                                    modifier = Modifier
                                                        .size(160.dp)
                                                        .clip(RoundedCornerShape(8.dp))
                                                )
                                                Spacer(modifier = Modifier.height(3.dp))
                                                Text(
                                                    text = "Quét VietQR nâng cấp Pro Tài Khoản ($upgradeAddInfo)",
                                                    color = Color(0xFF0F172A),
                                                    fontSize = 9.5.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        }

                                        OutlinedButton(
                                            onClick = {
                                                LicenseManager.logCustomerPaymentIntent(
                                                    context,
                                                    "BAO_DA_CHUYEN_KHOAN_NANG_CAP_PRO_TAI_KHOAN",
                                                    "Khách đang có Pro Thiết Bị ($deviceId) báo đã chuyển thêm $upgradeAccountProPrice để nâng cấp lên Pro Tài Khoản"
                                                )
                                                Toast.makeText(
                                                    context,
                                                    "✅ Đã gửi thông báo nâng cấp Pro Tài Khoản tới Admin! Bạn cũng có thể gửi ảnh Bill vào Chat Hỗ Trợ AI trên đầu màn hình để được duyệt tự động ngay.",
                                                    Toast.LENGTH_LONG
                                                ).show()
                                            },
                                            modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 38.dp),
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MagicEmerald),
                                            border = androidx.compose.foundation.BorderStroke(1.dp, MagicEmerald.copy(alpha = 0.6f))
                                        ) {
                                            Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(15.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("BÁO ĐÃ CHUYỂN KHOẢN NÂNG CẤP (+ $upgradeAccountProPrice)", fontSize = 10.5.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
                                        }
                                    }

                                    OutlinedTextField(
                                        value = upgradeKeyInput,
                                        onValueChange = {
                                            upgradeKeyInput = it
                                            errorMessage = null
                                            successMessage = null
                                        },
                                        modifier = Modifier.fillMaxWidth(),
                                        label = { Text("Nhập Mã Nâng Cấp Pro Tài Khoản (TKPR-...)", fontSize = 11.5.sp) },
                                        placeholder = { Text("TKPR-XXXX-XXXX-XXXX", fontSize = 11.sp) },
                                        singleLine = true,
                                        shape = RoundedCornerShape(10.dp),
                                        keyboardOptions = KeyboardOptions(
                                            capitalization = KeyboardCapitalization.Characters,
                                            imeAction = ImeAction.Done
                                        ),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = MagicAmber,
                                            unfocusedBorderColor = MagicBorder,
                                            focusedLabelColor = MagicAmber
                                        )
                                    )

                                    if (errorMessage != null) {
                                        Text(text = errorMessage!!, color = MagicRoseLight, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                    if (successMessage != null) {
                                        Text(text = successMessage!!, color = MagicEmerald, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }

                                    Button(
                                        onClick = {
                                            if (!isUserLoggedIn) {
                                                errorMessage = "🔒 Vui lòng Đăng Nhập tài khoản trước khi kích hoạt Key Pro Tài Khoản (TKPR)!"
                                                Toast.makeText(context, "🔒 Vui lòng đăng nhập tài khoản trước để gắn quyền Pro Tài Khoản!", Toast.LENGTH_LONG).show()
                                                openLoginScreen()
                                                return@Button
                                            }
                                            if (upgradeKeyInput.isBlank()) {
                                                errorMessage = "Vui lòng nhập Mã Key Pro Tài Khoản (TKPR-...)"
                                                return@Button
                                            }
                                            val ok = LicenseManager.verifyLicenseKey(context, upgradeKeyInput)
                                            if (ok && LicenseManager.isAccountProActivated(context)) {
                                                isPro = true
                                                isAccountPro = true
                                                successMessage = "👑 Nâng cấp lên PRO TÀI KHOẢN thành công!"
                                                Toast.makeText(context, "👑 Đã nâng cấp lên PRO TÀI KHOẢN! Bạn có thể đăng nhập sử dụng trên thiết bị khác (1 máy/lần).", Toast.LENGTH_LONG).show()
                                            } else {
                                                errorMessage = "Mã nâng cấp Pro Tài Khoản không hợp lệ cho thiết bị $deviceId!"
                                            }
                                        },
                                        modifier = Modifier.fillMaxWidth().height(42.dp),
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = MagicAmber, contentColor = Color(0xFF020617))
                                    ) {
                                        Icon(imageVector = Icons.Default.Key, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("KÍCH HOẠT MÃ PRO TÀI KHOẢN (TKPR)", fontSize = 11.5.sp, fontWeight = FontWeight.Black)
                                    }
                                }
                            }
                        }
                    }
                } else if (isKillSwitchTriggered) {
                // Kill-Switch kích hoạt: Tạm ngưng đăng ký mới
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MagicRose.copy(alpha = 0.15f))
                        .border(1.dp, MagicRose.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                        .padding(14.dp)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(imageVector = Icons.Default.Warning, contentDescription = null, tint = MagicRoseLight, modifier = Modifier.size(28.dp))
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "⚠️ TẠM NGƯNG NHẬN ĐĂNG KÝ BẢN PRO MỚI",
                            color = MagicRoseLight,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Hệ thống đang bảo trì hoặc tạm thời dừng nhận đăng ký mới. Xin vui lòng quay lại sau!",
                            color = TextSecondary,
                            fontSize = 11.5.sp,
                            textAlign = TextAlign.Center,
                            lineHeight = 16.sp
                        )
                    }
                }
            } else {
                // Chưa kích hoạt & Kill-Switch bình thường -> Hiện thông tin thanh toán & SMS Forwarder + Ô nhập Key
                
                // 1. Mã thiết bị (Device ID) + Nút Copy
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF020617))
                        .border(1.dp, MagicBorder, RoundedCornerShape(10.dp))
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "MÃ THIẾT BỊ CỦA BẠN (DEVICE ID):",
                                color = TextMuted,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = deviceId,
                                color = MagicCyanLight,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Black
                            )
                        }

                        OutlinedButton(
                            onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clip = ClipData.newPlainText("Device ID", deviceId)
                                clipboard.setPrimaryClip(clip)
                                Toast.makeText(context, "Đã sao chép Mã thiết bị!", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.height(34.dp),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MagicCyan),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MagicCyan.copy(alpha = 0.5f))
                        ) {
                            Icon(imageVector = Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = "SAO CHÉP", fontSize = 10.5.sp, fontWeight = FontWeight.Black)
                        }
                    }
                }

                // 1B. CHỌN GÓI NÂNG CẤP: PRO THIẾT BỊ (THEO ID MÁY) HOẶC PRO TÀI KHOẢN (ĐỔI MÁY TỰ DO - 1 MÁY/LẦN)
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "📦 CHỌN GÓI BẢN QUYỀN PRO MUỐN ĐĂNG KÝ:",
                        color = MagicAmber,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Gói 1: Pro Thiết Bị
                        val isTier0 = selectedPurchaseTier == 0
                        Surface(
                            onClick = { selectedPurchaseTier = 0 },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            color = if (isTier0) MagicEmerald.copy(alpha = 0.16f) else Color(0xFF0F172A),
                            border = androidx.compose.foundation.BorderStroke(
                                if (isTier0) 1.5.dp else 1.dp,
                                if (isTier0) MagicEmerald else MagicBorder
                            )
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                verticalArrangement = Arrangement.spacedBy(3.dp)
                            ) {
                                Text(
                                    text = "📱 PRO THIẾT BỊ",
                                    color = if (isTier0) MagicEmerald else Color.White,
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.Black
                                )
                                Text(
                                    text = currentProPrice,
                                    color = MagicCyanLight,
                                    fontSize = 13.5.sp,
                                    fontWeight = FontWeight.Black
                                )
                                Text(
                                    text = "Gắn cố định 1 máy theo ID máy hiện tại. Sau này có thể trả thêm +$upgradeAccountProPrice để lên Pro Tài Khoản.",
                                    color = TextSecondary,
                                    fontSize = 9.5.sp,
                                    lineHeight = 13.sp
                                )
                            }
                        }

                        // Gói 2: Pro Tài Khoản
                        val isTier1 = selectedPurchaseTier == 1
                        Surface(
                            onClick = { selectedPurchaseTier = 1 },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            color = if (isTier1) MagicAmber.copy(alpha = 0.16f) else Color(0xFF0F172A),
                            border = androidx.compose.foundation.BorderStroke(
                                if (isTier1) 1.5.dp else 1.dp,
                                if (isTier1) MagicAmber else MagicBorder
                            )
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                verticalArrangement = Arrangement.spacedBy(3.dp)
                            ) {
                                Text(
                                    text = "👑 PRO TÀI KHOẢN",
                                    color = if (isTier1) MagicAmber else Color.White,
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.Black
                                )
                                Text(
                                    text = accountProPrice,
                                    color = MagicAmber,
                                    fontSize = 13.5.sp,
                                    fontWeight = FontWeight.Black
                                )
                                Text(
                                    text = "Đăng nhập sang máy khác vẫn dùng được Pro. Tối đa 1 máy/lần (đăng nhập máy mới tự xuất máy cũ).",
                                    color = TextSecondary,
                                    fontSize = 9.5.sp,
                                    lineHeight = 13.sp
                                )
                            }
                        }
                    }
                }

                // 2. Xác Thực Bảo Mật SHA-256 & AI Duyệt Bill (Không đọc thông báo số dư / SMS của máy)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(MagicCyan.copy(alpha = 0.1f))
                        .border(1.dp, MagicCyan.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                        .padding(horizontal = 10.dp, vertical = 7.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.VerifiedUser,
                                    contentDescription = null,
                                    tint = MagicCyanLight,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(5.dp))
                                Text(
                                    text = "🛡️ Bảo mật quyền riêng tư 100%",
                                    color = MagicCyanLight,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black,
                                    maxLines = 1,
                                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                                )
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(5.dp))
                                    .background(MagicEmerald.copy(alpha = 0.18f))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "🟢 An toàn tuyệt đối",
                                    color = MagicEmerald,
                                    fontSize = 9.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    softWrap = false
                                )
                            }
                        }

                        Text(
                            text = "Ứng dụng tuyệt đối KHÔNG đọc SMS hay thông báo biến động số dư của bạn. Sau khi quét VietQR chuyển khoản, hãy gửi ảnh biên lai (bill) cho Trợ lý AI ở góc phải màn hình hoặc dán Mã Key SHA-256 để mở khóa Pro ngay tức thì!",
                            color = TextSecondary,
                            fontSize = 10.sp,
                            lineHeight = 13.5.sp
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedButton(
                                onClick = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    val clip = clipboard.primaryClip
                                    val text = clip?.getItemAt(0)?.text?.toString() ?: ""
                                    if (text.isBlank()) {
                                        Toast.makeText(context, "Bộ nhớ tạm trống! Hãy sao chép mã Key bản quyền do Admin hoặc AI cấp trước.", Toast.LENGTH_SHORT).show()
                                    } else {
                                        val activated = LicenseManager.processIncomingPaymentText(context, text, source = "PASTE")
                                        if (activated) {
                                            isPro = true
                                            isAccountPro = LicenseManager.isAccountProActivated(context)
                                            Toast.makeText(context, "🎉 ĐÃ KÍCH HOẠT PRO THÀNH CÔNG TỪ MÃ KEY BẢN QUYỀN VỪA DÁN!", Toast.LENGTH_LONG).show()
                                        } else {
                                            Toast.makeText(context, "Nội dung vừa dán không chứa Mã Key SHA-256 hợp lệ của máy $deviceId!", Toast.LENGTH_LONG).show()
                                        }
                                    }
                                },
                                modifier = Modifier.fillMaxWidth().height(32.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                                shape = RoundedCornerShape(7.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = MagicAmber),
                                border = androidx.compose.foundation.BorderStroke(1.dp, MagicAmber.copy(alpha = 0.5f))
                            ) {
                                Icon(imageVector = Icons.Default.ContentPaste, contentDescription = null, modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(5.dp))
                                Text("📋 Dán nhanh Mã Key SHA-256 từ bộ nhớ tạm", fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                            }
                        }
                    }
                }

                // 3. Thông tin thanh toán & Mã QR
                val activePriceText = if (selectedPurchaseTier == 1) accountProPrice else currentProPrice
                val activeTransferNote = if (selectedPurchaseTier == 1) "TKPRO $deviceId" else deviceId
                val activeTierTitle = if (selectedPurchaseTier == 1) "👑 GÓI PRO TÀI KHOẢN (Đổi máy tự do)" else "📱 GÓI PRO THIẾT BỊ (Cố định 1 máy)"
                val requiresLoginForTier1Qr = selectedPurchaseTier == 1 && !isUserLoggedIn

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(
                            if (requiresLoginForTier1Qr) MagicRose.copy(alpha = 0.1f)
                            else MagicAmber.copy(alpha = 0.1f)
                        )
                        .border(
                            1.dp,
                            if (requiresLoginForTier1Qr) MagicRose.copy(alpha = 0.45f)
                            else MagicAmber.copy(alpha = 0.4f),
                            RoundedCornerShape(10.dp)
                        )
                        .padding(10.dp)
                ) {
                    if (requiresLoginForTier1Qr) {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = null,
                                    tint = MagicRoseLight,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "CẦN ĐĂNG NHẬP ĐỂ HIỆN MÃ QR PRO TÀI KHOẢN",
                                    color = MagicRoseLight,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                            Text(
                                text = "Gói Pro Tài Khoản ($accountProPrice) gắn với tài khoản Email của bạn để đăng nhập đổi máy tự do. Vui lòng Đăng Nhập tài khoản trước khi quét mã QR chuyển khoản (hoặc chọn tab '📱 PRO THIẾT BỊ' nếu không muốn đăng nhập).",
                                color = TextSecondary,
                                fontSize = 10.5.sp,
                                lineHeight = 14.sp,
                                textAlign = TextAlign.Center
                            )
                            Button(
                                onClick = { openLoginScreen() },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(36.dp),
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MagicAmber, contentColor = Color(0xFF020617))
                            ) {
                                Icon(imageVector = Icons.Default.Person, contentDescription = null, modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("🔐 ĐĂNG NHẬP TÀI KHOẢN NGAY ĐỂ HIỆN MÃ QR", fontSize = 10.5.sp, fontWeight = FontWeight.Black)
                            }
                        }
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text(
                                text = "💳 THÔNG TIN CHUYỂN KHOẢN ($activeTierTitle):",
                                color = MagicAmber,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                text = "• Ngân hàng / Momo: $accountNumber ($bankName)",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "• Chủ tài khoản: $accountHolder",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            val numericAmount = activePriceText.replace(Regex("[^0-9]"), "").ifBlank {
                                if (selectedPurchaseTier == 1) "100000" else "50000"
                            }

                            Text(
                                text = "• Mức phí kích hoạt: $activePriceText",
                                color = MagicEmerald,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "• Nội dung CK (BẮT BUỘC): $activeTransferNote",
                                color = MagicCyanLight,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Black
                            )

                            val encodedAccountHolder = try {
                                java.net.URLEncoder.encode(accountHolder, "UTF-8")
                            } catch (_: Exception) {
                                accountHolder
                            }
                            val encodedAddInfo = try {
                                java.net.URLEncoder.encode(activeTransferNote, "UTF-8")
                            } catch (_: Exception) {
                                activeTransferNote
                            }
                            val qrUrl = "https://img.vietqr.io/image/$bankCode-$accountNumber-compact2.png?amount=$numericAmount&addInfo=$encodedAddInfo&accountName=$encodedAccountHolder"

                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color.White)
                                    .padding(6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    AsyncImage(
                                        model = qrUrl,
                                        contentDescription = "Mã VietQR Chuyển Khoản",
                                        modifier = Modifier
                                            .size(165.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "Quét mã VietQR tự điền số tiền & Nội dung: $activeTransferNote",
                                        color = Color(0xFF0F172A),
                                        fontSize = 9.5.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }

                // 4. Nút Khôi Phục Pro Theo ID Thiết Bị (1-Click Restore cho người dùng cũ) & Kiểm Tra Thanh Toán
                var isRestoringByDeviceId by remember { mutableStateOf(false) }
                Button(
                    onClick = {
                        isRestoringByDeviceId = true
                        coroutineScope.launch {
                            val recognized = LicenseManager.checkDeviceRecognizedProInCloud(context)
                            LicenseManager.syncDevicePresenceToCloud(context)
                            LicenseManager.fetchGlobalConfigNow(context)
                            val diagInfo = LicenseManager.lastCloudLookupDiag.takeIf { it.isNotBlank() }?.let { "\n($it)" }.orEmpty()
                            if (recognized || LicenseManager.isProActivated(context)) {
                                isPro = true
                                isAccountPro = LicenseManager.isAccountProActivated(context)
                                isRestoringByDeviceId = false
                                val tierLabel = if (isAccountPro) "👑 Pro Tài Khoản" else "📱 Pro Thiết Bị"
                                Toast.makeText(context, "🎉 KHÔI PHỤC PRO THÀNH CÔNG!\nHệ thống Truy vấn Đám mây Đa nguồn đã nhận diện thiết bị $deviceId và kích hoạt lại bản $tierLabel vĩnh viễn!$diagInfo", Toast.LENGTH_LONG).show()
                            } else {
                                val isPaidRemote = LicenseManager.checkOnlinePaymentStatusRemote(context)
                                isRestoringByDeviceId = false
                                if (isPaidRemote || LicenseManager.isProActivated(context)) {
                                    isPro = true
                                    isAccountPro = LicenseManager.isAccountProActivated(context)
                                    Toast.makeText(context, "🎉 Đã phát hiện thông tin Pro cho thiết bị $deviceId! Khôi phục thành công!$diagInfo", Toast.LENGTH_LONG).show()
                                } else {
                                    Toast.makeText(context, "⚠️ Đã quét đa nguồn (8 tầng dữ liệu)$diagInfo nhưng ID thiết bị $deviceId chưa nằm trong danh sách Pro.\nNếu bạn từng được cấp Pro, vui lòng bấm nút 'Gửi yêu cầu khôi phục' hoặc dán Key!", Toast.LENGTH_LONG).show()
                                }
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .defaultMinSize(minHeight = 46.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MagicEmerald,
                        contentColor = Color(0xFF020617)
                    )
                ) {
                    if (isRestoringByDeviceId) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color(0xFF020617), strokeWidth = 2.dp)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("ĐANG QUÉT MÃ THIẾT BỊ TRÊN FIREBASE...", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    } else {
                        Icon(imageVector = Icons.Default.Autorenew, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "⚡ KHÔI PHỤC PRO BẰNG ID THIẾT BỊ (1 CLICK - KHÔNG CẦN KEY)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            textAlign = TextAlign.Center
                        )
                    }
                }

                var isSyncingOnline by remember { mutableStateOf(false) }
                OutlinedButton(
                    onClick = {
                        isSyncingOnline = true
                        coroutineScope.launch {
                            val isPaid = LicenseManager.checkOnlinePaymentStatusRemote(context)
                            isSyncingOnline = false
                            if (isPaid) {
                                isPro = true
                                isAccountPro = LicenseManager.isAccountProActivated(context)
                                Toast.makeText(context, "🎉 Đã phát hiện giao dịch chuyển khoản! Bản Pro đã kích hoạt thành công!", Toast.LENGTH_LONG).show()
                            } else {
                                Toast.makeText(context, "Chưa thấy giao dịch chuyển khoản cho Device ID $deviceId trên hệ thống. Nếu đã chuyển tiền, hãy bấm lại sau vài giây!", Toast.LENGTH_LONG).show()
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .defaultMinSize(minHeight = 44.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MagicCyanLight),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MagicCyan.copy(alpha = 0.6f))
                ) {
                    if (isSyncingOnline) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp), color = MagicCyanLight, strokeWidth = 2.dp)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("ĐANG QUÉT GIAO DỊCH CHUYỂN KHOẢN...", fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                    } else {
                        Icon(imageVector = Icons.Default.Sync, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "🔄 BẤM VÀO ĐÂY ĐỂ KIỂM TRA THANH TOÁN TỰ ĐỘNG",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            textAlign = TextAlign.Center
                        )
                    }
                }

                // 5. Ô nhập Mã Kích Hoạt Thủ Công (Hỗ trợ cả Key Thiết Bị XXXX-... và Key Tài Khoản TKPR-...)
                OutlinedTextField(
                    value = licenseInput,
                    onValueChange = {
                        licenseInput = it
                        errorMessage = null
                        successMessage = null
                    },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Mã kích hoạt Pro Thiết Bị hoặc Pro Tài Khoản (TKPR-...)", fontSize = 11.5.sp) },
                    placeholder = { Text("XXXX-XXXX-XXXX-XXXX hoặc TKPR-XXXX-XXXX-XXXX", fontSize = 11.sp) },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.Characters,
                        imeAction = ImeAction.Done
                    ),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MagicPurpleLight,
                        unfocusedBorderColor = MagicBorder,
                        focusedLabelColor = MagicPurpleLight
                    )
                )

                if (errorMessage != null) {
                    Text(
                        text = errorMessage!!,
                        color = MagicRoseLight,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                if (successMessage != null) {
                    Text(
                        text = successMessage!!,
                        color = MagicEmerald,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Hướng dẫn lưu giữ Key & Đăng nhập để khôi phục 100%
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF0F172A))
                        .border(1.dp, MagicBorder, RoundedCornerShape(8.dp))
                        .padding(8.dp)
                ) {
                    Text(
                        text = "💡 Lưu ý quan trọng: Mỗi thiết bị được cấp cố định một Key duy nhất từ Admin hoặc AI. Sau khi nhận được Key, bạn hãy lưu giữ lại Key hoặc Đăng nhập tài khoản để thiết bị Pro được ghi nhớ vĩnh viễn trên hệ thống. Về sau nếu gặp lỗi không thấy Pro, bạn chỉ cần đăng nhập tài khoản là 100% được tự động khôi phục!",
                        color = TextMuted,
                        fontSize = 10.sp,
                        lineHeight = 14.sp
                    )
                }

                // Nút bấm Kích hoạt Pro
                Button(
                    onClick = {
                        if (licenseInput.isBlank()) {
                            errorMessage = "Vui lòng nhập Mã kích hoạt!"
                            return@Button
                        }
                        val ok = LicenseManager.verifyLicenseKey(context, licenseInput)
                        if (ok) {
                            isPro = true
                            isAccountPro = LicenseManager.isAccountProActivated(context)
                            successMessage = if (isAccountPro) {
                                "👑 Kích hoạt bản PRO TÀI KHOẢN thành công!"
                            } else {
                                "📱 Kích hoạt bản PRO THIẾT BỊ thành công!"
                            }
                            Toast.makeText(context, successMessage, Toast.LENGTH_LONG).show()
                        } else {
                            errorMessage = "Mã kích hoạt không hợp lệ cho thiết bị này!"
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MagicPurpleLight,
                        contentColor = Color(0xFF020617)
                    )
                ) {
                    Icon(imageVector = Icons.Default.Key, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "KÍCH HOẠT BẢN PRO BẰNG MÃ KEY",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }
    }
}
}
}
}
