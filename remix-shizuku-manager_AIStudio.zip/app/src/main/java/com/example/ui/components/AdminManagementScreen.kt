﻿package com.example.ui.components

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.auth.DeviceRecord
import com.example.core.auth.FirebaseAuthManager
import com.example.core.auth.UserProfile
import com.example.core.license.LicenseManager
import com.example.ui.theme.*
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun AdminManagementScreen(
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val scrollState = rememberScrollState()

    var currentUser by remember { mutableStateOf(FirebaseAuthManager.getCurrentUser()) }
    var userProfile by remember { mutableStateOf<UserProfile?>(null) }
    var allUsersList by remember { mutableStateOf<List<UserProfile>>(emptyList()) }
    var allDevicesList by remember { mutableStateOf<List<DeviceRecord>>(emptyList()) }
    var allStoreApps by remember { mutableStateOf<List<com.example.data.HonorAppItem>>(emptyList()) }
    var isAdmin by remember {
        mutableStateOf(
            FirebaseAuthManager.isCurrentAdmin(context, null) || LicenseManager.isCurrentUserAdmin(context)
        )
    }
    var isLoading by remember { mutableStateOf(!isAdmin) }
    var isSyncingMetrics by remember { mutableStateOf(false) }
    var lastMetricsSyncTime by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    var customPriceInput by remember { mutableStateOf(LicenseManager.getProPrice(context)) }
    var accountProPriceInput by remember { mutableStateOf(LicenseManager.getAccountProPrice(context)) }
    var upgradeAccountProPriceInput by remember { mutableStateOf(LicenseManager.getUpgradeToAccountProPrice(context)) }
    var autoFreeDaysInput by remember { mutableStateOf(LicenseManager.getAutoFreeInactivityDays(context).toString()) }
    var bankNameInput by remember { mutableStateOf(LicenseManager.getPaymentBankName(context)) }
    var bankCodeInput by remember { mutableStateOf(LicenseManager.getPaymentBankCode(context)) }
    var accountNumberInput by remember { mutableStateOf(LicenseManager.getPaymentAccountNumber(context)) }
    var accountHolderInput by remember { mutableStateOf(LicenseManager.getPaymentAccountHolder(context)) }
    var supportLinkInput by remember { mutableStateOf(LicenseManager.getFacebookLink(context)) }
    var globalUpdateLinkInput by remember { mutableStateOf(LicenseManager.getUpdateLink(context)) }
    var showVietQrPreview by remember { mutableStateOf(false) }

    var isAppFreeModeState by remember { mutableStateOf(LicenseManager.isAppFreeMode(context)) }
    var freeTrialLimitInput by remember { mutableStateOf(LicenseManager.getFreeTrialLimit(context).toString()) }
    var groqApiKeyPoolInput by remember { mutableStateOf(LicenseManager.getCombinedAiApiKeyPool(context)) }
    var autoApproveProEnabled by remember { mutableStateOf(LicenseManager.isAutoApproveNotificationPaymentEnabled(context)) }

    val proStateVersion by LicenseManager.proStateVersionFlow.collectAsState()

    // Tải trực tiếp cấu hình từ Firestore app_config/global ngay khi mở màn hình Quản Trị
    LaunchedEffect(Unit) {
        LicenseManager.fetchGlobalConfigNow(context) {
            customPriceInput = LicenseManager.getProPrice(context)
            accountProPriceInput = LicenseManager.getAccountProPrice(context)
            upgradeAccountProPriceInput = LicenseManager.getUpgradeToAccountProPrice(context)
            autoFreeDaysInput = LicenseManager.getAutoFreeInactivityDays(context).toString()
            bankNameInput = LicenseManager.getPaymentBankName(context)
            bankCodeInput = LicenseManager.getPaymentBankCode(context)
            accountNumberInput = LicenseManager.getPaymentAccountNumber(context)
            accountHolderInput = LicenseManager.getPaymentAccountHolder(context)
            supportLinkInput = LicenseManager.getFacebookLink(context)
            globalUpdateLinkInput = LicenseManager.getUpdateLink(context)
            isAppFreeModeState = LicenseManager.isAppFreeMode(context)
            freeTrialLimitInput = LicenseManager.getFreeTrialLimit(context).toString()
            groqApiKeyPoolInput = LicenseManager.getCombinedAiApiKeyPool(context)
            autoApproveProEnabled = LicenseManager.isAutoApproveNotificationPaymentEnabled(context)
        }
    }

    // Sync input values whenever global config is loaded/changed in LicenseManager or Firestore
    LaunchedEffect(proStateVersion) {
        customPriceInput = LicenseManager.getProPrice(context)
        accountProPriceInput = LicenseManager.getAccountProPrice(context)
        upgradeAccountProPriceInput = LicenseManager.getUpgradeToAccountProPrice(context)
        autoFreeDaysInput = LicenseManager.getAutoFreeInactivityDays(context).toString()
        bankNameInput = LicenseManager.getPaymentBankName(context)
        bankCodeInput = LicenseManager.getPaymentBankCode(context)
        accountNumberInput = LicenseManager.getPaymentAccountNumber(context)
        accountHolderInput = LicenseManager.getPaymentAccountHolder(context)
        supportLinkInput = LicenseManager.getFacebookLink(context)
        globalUpdateLinkInput = LicenseManager.getUpdateLink(context)
        isAppFreeModeState = LicenseManager.isAppFreeMode(context)
        freeTrialLimitInput = LicenseManager.getFreeTrialLimit(context).toString()
        groqApiKeyPoolInput = LicenseManager.getCombinedAiApiKeyPool(context)
        autoApproveProEnabled = LicenseManager.isAutoApproveNotificationPaymentEnabled(context)
    }

    // Admin Sub-tabs: 0 = Cài Đặt & Tạo Key, 1 = Quản Lý Tài Khoản, 2 = Quản Lý Thiết Bị
    var adminSubTab by remember { mutableIntStateOf(0) }
    var adminConfigVersion by remember { mutableIntStateOf(0) }

    // Search & Quick Filter & Pagination & Confirmation Dialog states
    var searchQuery by remember { mutableStateOf("") }
    var selectedFilterChip by remember { mutableStateOf("Tất cả") } // "Tất cả", "👑 Admin", "⚡ Pro", "👤 User"
    var deviceFilterTab by remember { mutableStateOf("Tất cả") } // "Tất cả", "⚡ ĐÃ LÊN PRO", "🔓 CHƯA LÊN PRO"
    var deviceCurrentPage by remember { mutableIntStateOf(0) }
    val devicePageSize = 6
    var currentPage by remember { mutableIntStateOf(0) }
    val pageSize = 5

    var targetUserForAction by remember { mutableStateOf<UserProfile?>(null) }
    var pendingActionType by remember { mutableStateOf<String?>(null) } // "pro" or "admin"
    var targetDeviceForAction by remember { mutableStateOf<DeviceRecord?>(null) }

    // License Key Generator states
    var genDeviceIdInput by remember { mutableStateOf(LicenseManager.getDeviceId(context)) }
    var generatedKeyOutput by remember { mutableStateOf("") }

    var paymentIntentsList by remember { mutableStateOf<List<com.example.core.auth.PaymentIntentRecord>>(emptyList()) }
    var proRecoveryRequestsList by remember { mutableStateOf<List<LicenseManager.ProRecoveryRecord>>(emptyList()) }
    var aiProChatLogsList by remember { mutableStateOf<List<LicenseManager.AiProChatLogRecord>>(emptyList()) }
    var aiLogFilterTab by remember { mutableStateOf("Tất cả") }
    var aiLogSearchQuery by remember { mutableStateOf("") }
    var adminAdbErrorLogsList by remember { mutableStateOf<List<LicenseManager.AdminAdbErrorLogRecord>>(emptyList()) }
    var adbErrorFilterTab by remember { mutableStateOf("Tất cả") }
    var adbErrorDateFilter by remember { mutableStateOf("ALL") }
    var adbErrorSearchQuery by remember { mutableStateOf("") }
    var showClearAllErrorsDialog by remember { mutableStateOf(false) }
    var isAnalyzingAdbErrors by remember { mutableStateOf(false) }
    var adbAiAnalysisResult by remember { mutableStateOf<String?>(null) }
    var showAdbAiAnalysisDialog by remember { mutableStateOf(false) }

    var autoApprovedCountSession by remember { mutableIntStateOf(0) }
    val autoProcessedDeviceIds = remember { mutableStateListOf<String>() }

    fun refreshAllAdminMetricsViaRest(showToastOnDone: Boolean = false) {
        if (isSyncingMetrics) return
        isSyncingMetrics = true
        coroutineScope.launch {
            try {
                val usersDeferred = async { FirebaseAuthManager.fetchAllUsersViaRest(context) }
                val devicesDeferred = async { FirebaseAuthManager.fetchAllDevicesViaRest(context) }
                val intentsDeferred = async { FirebaseAuthManager.fetchPaymentIntentsViaRest(context) }
                val recoveriesDeferred = async { LicenseManager.fetchProRecoveryRequestsViaRest(context) }
                val logsDeferred = async { LicenseManager.fetchAiProChatLogsViaRest(context) }
                val appsDeferred = async { FirebaseAuthManager.fetchHonorAppsViaRest(context) }
                val adbErrorsDeferred = async { LicenseManager.fetchAdminAdbErrorLogsViaRest(context) }

                val uList = usersDeferred.await()
                if (uList.isNotEmpty() || allUsersList.isEmpty()) allUsersList = uList

                val dList = devicesDeferred.await()
                if (dList.isNotEmpty() || allDevicesList.isEmpty()) allDevicesList = dList

                val iList = intentsDeferred.await()
                if (iList.isNotEmpty() || paymentIntentsList.isEmpty()) paymentIntentsList = iList

                val rList = recoveriesDeferred.await()
                if (rList.isNotEmpty() || proRecoveryRequestsList.isEmpty()) proRecoveryRequestsList = rList

                val lList = logsDeferred.await()
                if (lList.isNotEmpty() || aiProChatLogsList.isEmpty()) aiProChatLogsList = lList

                val eList = adbErrorsDeferred.await()
                if (eList.isNotEmpty() || adminAdbErrorLogsList.isEmpty()) adminAdbErrorLogsList = eList

                val aList = appsDeferred.await()
                if (aList.isNotEmpty() || allStoreApps.isEmpty()) allStoreApps = aList

                val sdf = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault())
                lastMetricsSyncTime = sdf.format(java.util.Date())
                if (showToastOnDone) {
                    Toast.makeText(
                        context,
                        "✅ Đã đồng bộ số liệu mới nhất (${allDevicesList.size} thiết bị, ${allUsersList.size} tài khoản)",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            } catch (_: Exception) {
            } finally {
                isSyncingMetrics = false
            }
        }
    }

    // Lắng nghe trạng thái Auth thời gian thực để không bao giờ bị mất trạng thái Admin khi Firebase làm mới token ngầm
    DisposableEffect(Unit) {
        val auth = try { FirebaseAuthManager.getAuth() } catch (_: Exception) { null }
        val listener = com.google.firebase.auth.FirebaseAuth.AuthStateListener { firebaseAuth ->
            currentUser = firebaseAuth.currentUser
            val verifiedAdmin = FirebaseAuthManager.isCurrentAdmin(context, userProfile) || LicenseManager.isCurrentUserAdmin(context)
            if (verifiedAdmin) {
                isAdmin = true
                isLoading = false
            }
        }
        try { auth?.addAuthStateListener(listener) } catch (_: Exception) {}
        onDispose {
            try { auth?.removeAuthStateListener(listener) } catch (_: Exception) {}
        }
    }

    // Sync current user profile & check admin status
    LaunchedEffect(currentUser) {
        val email = currentUser?.email ?: ""
        val alreadyVerifiedAdmin = FirebaseAuthManager.isCurrentAdmin(context, userProfile) || LicenseManager.isCurrentUserAdmin(context)
        if (email.equals("vuongdhkmhn@gmail.com", ignoreCase = true) ||
            email.equals("vuongdhkmhn@gmal.com", ignoreCase = true) ||
            alreadyVerifiedAdmin
        ) {
            isAdmin = true
            isLoading = false
            if (email.isNotBlank()) {
                LicenseManager.markLocalAdminVerified(context, email)
            }
            if (currentUser != null) {
                coroutineScope.launch {
                    try {
                        val p = FirebaseAuthManager.syncUserProfile(context)
                        userProfile = p
                    } catch (_: Exception) {}
                }
            }
        } else if (currentUser != null) {
            coroutineScope.launch {
                try {
                    val p = FirebaseAuthManager.syncUserProfile(context)
                    userProfile = p
                    isAdmin = FirebaseAuthManager.isCurrentAdmin(context, p) || LicenseManager.isCurrentUserAdmin(context)
                } catch (e: Exception) {
                    errorMessage = "Lỗi tải hồ sơ: ${e.localizedMessage}"
                } finally {
                    isLoading = false
                }
            }
        } else {
            isAdmin = FirebaseAuthManager.isCurrentAdmin(context, null) || LicenseManager.isCurrentUserAdmin(context)
            isLoading = false
        }
    }

    // Observe all users & all devices & payment intents if admin (Dual-Channel: REST + Realtime SDK)
    DisposableEffect(isAdmin) {
        var recoveryReg: com.google.firebase.firestore.ListenerRegistration? = null
        var chatLogsReg: com.google.firebase.firestore.ListenerRegistration? = null
        var adbErrorsReg: com.google.firebase.firestore.ListenerRegistration? = null
        if (isAdmin) {
            try {
                recoveryReg = LicenseManager.observeProRecoveryRequests(context) { list ->
                    if (list.isNotEmpty() || proRecoveryRequestsList.isEmpty()) {
                        proRecoveryRequestsList = list
                    }
                }
            } catch (_: Exception) {}
            try {
                chatLogsReg = LicenseManager.observeAiProChatLogs(context) { list ->
                    if (list.isNotEmpty() || aiProChatLogsList.isEmpty()) {
                        aiProChatLogsList = list
                    }
                }
            } catch (_: Exception) {}
            try {
                adbErrorsReg = LicenseManager.observeAdminAdbErrorLogs(context) { list ->
                    if (list.isNotEmpty() || adminAdbErrorLogsList.isEmpty()) {
                        adminAdbErrorLogsList = list
                    }
                }
            } catch (_: Exception) {}
        }
        onDispose {
            try { recoveryReg?.remove() } catch (_: Exception) {}
            try { chatLogsReg?.remove() } catch (_: Exception) {}
            try { adbErrorsReg?.remove() } catch (_: Exception) {}
        }
    }

    LaunchedEffect(isAdmin) {
        if (isAdmin) {
            // 1. Nạp ngay tức thì qua kênh HTTPS REST (chống treo gRPC / trễ token)
            refreshAllAdminMetricsViaRest(showToastOnDone = false)

            // 2. Mở luồng Realtime SDK song song
            coroutineScope.launch {
                FirebaseAuthManager.observeAllUsers(context).collect { list ->
                    if (list.isNotEmpty() || allUsersList.isEmpty()) {
                        allUsersList = list
                    }
                }
            }
            coroutineScope.launch {
                FirebaseAuthManager.observeAllDevices(context).collect { list ->
                    if (list.isNotEmpty() || allDevicesList.isEmpty()) {
                        allDevicesList = list
                    }
                }
            }
            coroutineScope.launch {
                FirebaseAuthManager.observePaymentIntents(context).collect { list ->
                    if (list.isNotEmpty() || paymentIntentsList.isEmpty()) {
                        paymentIntentsList = list
                    }
                }
            }
            coroutineScope.launch {
                FirebaseAuthManager.observeHonorApps(context).collect { list ->
                    if (list.isNotEmpty() || allStoreApps.isEmpty()) {
                        allStoreApps = list
                    }
                }
            }

            // 3. Tự động đồng bộ dự phòng định kỳ mỗi 25 giây khi đang mở màn hình Quản Trị
            coroutineScope.launch {
                while (true) {
                    kotlinx.coroutines.delay(25_000L)
                    refreshAllAdminMetricsViaRest(showToastOnDone = false)
                }
            }
        }
    }

    // HỆ THỐNG AUTO-ADMIN THÔNG MINH (CHỐNG KÍCH HOẠT KHI CHƯA THANH TOÁN):
    // Chỉ tự động khôi phục Pro cho các thiết bị gửi yêu cầu khôi phục mà thực sự đã có lịch sử Pro trong `devices` hoặc `users` trên Firebase.
    // TUYỆT ĐỐI KHÔNG tự động cấp Pro cho "CLICKED_I_PAID" (bấm nút 'Tôi đã chuyển khoản' suông mà chưa gửi ảnh bill xác thực)!
    LaunchedEffect(isAdmin, autoApproveProEnabled, proRecoveryRequestsList, allDevicesList, allUsersList) {
        if (isAdmin && autoApproveProEnabled) {
            val pendingRecoveries = proRecoveryRequestsList.filter {
                it.status == "PENDING" && it.deviceId.isNotBlank() && !autoProcessedDeviceIds.contains("REC_${it.deviceId}")
            }
            for (req in pendingRecoveries) {
                val normReqId = LicenseManager.normalizeDeviceIdForMatch(req.deviceId)
                val verifiedInDevices = allDevicesList.any { d ->
                    LicenseManager.normalizeDeviceIdForMatch(d.deviceId) == normReqId &&
                        !d.revokedByAdmin &&
                        (d.isPro || d.licenseKey.isNotBlank() || d.proActivatedAt != null)
                }
                val verifiedInUsers = allUsersList.any { u ->
                    u.isPro && (
                        LicenseManager.normalizeDeviceIdForMatch(u.deviceId) == normReqId ||
                            LicenseManager.normalizeDeviceIdForMatch(u.activeDeviceId) == normReqId
                        )
                }
                if (verifiedInDevices || verifiedInUsers) {
                    autoProcessedDeviceIds.add("REC_${req.deviceId}")
                    try {
                        LicenseManager.adminRestoreProForDevice(req.deviceId) { _ -> }
                        LicenseManager.executeVerifiedProGrant(
                            context = context,
                            rawTargetDeviceId = req.deviceId,
                            grantAccountPro = req.note.contains("Tài Khoản", ignoreCase = true) || req.note.contains("TKPRO", ignoreCase = true),
                            reason = "AUTO_ADMIN_VERIFIED_RECOVERY_APPROVED"
                        )
                        autoApprovedCountSession++
                    } catch (_: Exception) {}
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MagicDarkBackground)
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Top Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(onClick = onNavigateBack) {
                    Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Quay lại", tint = Color.White)
                }
                Text(
                    text = "Quản Trị Hệ Thống",
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black
                )
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (isAdmin) MagicPurple.copy(alpha = 0.3f) else MagicRose.copy(alpha = 0.3f))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = if (isAdmin) "👑 ADMIN QUYỀN CAO NHẤT" else "⚠️ CHƯA CÓ QUYỀN ADMIN",
                    color = if (isAdmin) MagicPurpleLight else MagicRoseLight,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        val user = currentUser
        if (user == null) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MagicSurfaceCard),
                border = BorderStroke(1.dp, MagicAmber)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = MagicAmber, modifier = Modifier.size(54.dp))
                    Text(
                        text = "YÊU CẦU ĐĂNG NHẬP ADMIN",
                        color = MagicAmber,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                    Text(
                        text = "Dù đây là Máy Quen của Admin, bạn vẫn cần ĐĂNG NHẬP tài khoản Admin để Firebase cấp token xác thực chuẩn. Khi đó mọi thao tác duyệt máy, xóa máy hay đồng bộ mới được Firebase chấp thuận 100%!",
                        color = Color.White.copy(alpha = 0.9f),
                        fontSize = 13.sp,
                        lineHeight = 18.sp,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Button(
                            onClick = onNavigateBack,
                            colors = ButtonDefaults.buttonColors(containerColor = MagicSurfaceCard),
                            border = BorderStroke(1.dp, MagicBorder)
                        ) {
                            Text("Quay Lại", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                        Button(
                            onClick = {
                                try {
                                    val intent = android.content.Intent(context, com.example.MainActivity::class.java).apply {
                                        flags = android.content.Intent.FLAG_ACTIVITY_SINGLE_TOP or android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP
                                        putExtra("TARGET_TAB", "LOGIN")
                                    }
                                    context.startActivity(intent)
                                } catch (_: Exception) {}
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MagicAmber, contentColor = Color(0xFF020617))
                        ) {
                            Text("Đăng Nhập Ngay", fontWeight = FontWeight.Black)
                        }
                    }
                }
            }
        } else if (!isAdmin) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MagicSurfaceCard),
                border = BorderStroke(1.dp, MagicRose)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(imageVector = Icons.Default.Warning, contentDescription = null, tint = MagicRoseLight, modifier = Modifier.size(48.dp))
                    Text(
                        text = "Tài khoản hiện tại không có quyền Quản trị viên (Admin)!",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }
        } else {
            // ADMIN DASHBOARD WITH SUB-TABS
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Tự động gộp & hợp nhất thiết bị và tài khoản trùng lặp (1 máy / 1 người chỉ tính 1 thẻ chuẩn nhất)
                val globalMergedDevices = remember(allDevicesList) {
                    allDevicesList
                        .groupBy { d: com.example.core.auth.DeviceRecord ->
                            val normId = LicenseManager.normalizeDeviceIdForMatch(d.deviceId)
                            if (normId.isNotBlank()) normId else d.ownerEmail.trim().lowercase().ifBlank { d.deviceId }
                        }
                        .mapNotNull { (_, group) ->
                            group.maxWithOrNull(
                                compareBy<com.example.core.auth.DeviceRecord> { it.isPro && !it.revokedByAdmin }
                                    .thenBy { it.proActivatedAt?.toDate()?.time ?: 0L }
                                    .thenBy { it.lastActive?.toDate()?.time ?: 0L }
                                    .thenBy { it.createdAt?.toDate()?.time ?: 0L }
                            )
                        }
                }

                val globalMergedUsers = remember(allUsersList) {
                    allUsersList
                        .groupBy { u: com.example.core.auth.UserProfile ->
                            val cleanEmail = u.email.trim().lowercase()
                            if (cleanEmail.isNotBlank()) cleanEmail else u.userId.ifBlank { u.deviceId.trim().uppercase() }
                        }
                        .mapNotNull { (_, group) ->
                            group.maxWithOrNull(
                                compareBy<com.example.core.auth.UserProfile> { it.role == "admin" }
                                    .thenBy { it.isPro }
                                    .thenBy { it.displayName.isNotBlank() }
                                    .thenBy { it.lastActive?.toDate()?.time ?: 0L }
                                    .thenBy { it.createdAt?.toDate()?.time ?: 0L }
                            )
                        }
                }

                // THỐNG KÊ THƯƠNG MẠI TOÀN HỆ THỐNG (ĐÃ TỰ ĐỘNG GỘP VÀ LOẠI BỎ CLONE TRÙNG LẶP)
                val activeProDevices = globalMergedDevices.filter { dev ->
                    val cleanId = dev.deviceId.trim().uppercase()
                    val isValidId = cleanId.isNotBlank() && cleanId != "TEST" && cleanId != "MT-HONOR-8888" && cleanId.length >= 4
                    dev.isPro && !dev.revokedByAdmin && isValidId
                }
                val accountProUsersCount = globalMergedUsers.count { it.isPro && (it.isAccountPro || it.proTier == "ACCOUNT_PRO") }
                val accountProDeviceRecordsCount = activeProDevices.count { it.licenseKey.startsWith("TKPR-", ignoreCase = true) || it.licenseKey.contains("ACCOUNT", ignoreCase = true) || it.isAccountPro }
                val totalAccountProCount = maxOf(accountProUsersCount, accountProDeviceRecordsCount)

                // Lọc & gộp các đơn chờ duyệt theo Device ID (mỗi thiết bị chỉ hiện 1 thẻ mới nhất, bỏ qua thiết bị đã có Pro)
                val deduplicatedPaymentIntents = remember(paymentIntentsList, allDevicesList, allUsersList) {
                    paymentIntentsList
                        .filter { intent ->
                            if (intent.isPro) return@filter false
                            val normId = LicenseManager.normalizeDeviceIdForMatch(intent.deviceId)
                            val alreadyProInDevices = normId.isNotBlank() && allDevicesList.any { d ->
                                LicenseManager.normalizeDeviceIdForMatch(d.deviceId) == normId && d.isPro && !d.revokedByAdmin
                            }
                            val alreadyProInUsers = normId.isNotBlank() && allUsersList.any { u ->
                                u.isPro && (
                                    LicenseManager.normalizeDeviceIdForMatch(u.deviceId) == normId ||
                                        LicenseManager.normalizeDeviceIdForMatch(u.activeDeviceId) == normId
                                    )
                            }
                            !alreadyProInDevices && !alreadyProInUsers
                        }
                        .groupBy { intent ->
                            LicenseManager.normalizeDeviceIdForMatch(intent.deviceId).ifBlank {
                                "${intent.ownerEmail.trim().lowercase()}_${intent.model.trim().lowercase()}"
                            }
                        }
                        .mapValues { (_, intents) ->
                            intents.sortedWith(
                                compareByDescending<com.example.core.auth.PaymentIntentRecord> { it.actionType == "CLICKED_I_PAID" }
                                    .thenByDescending { it.timestamp?.toDate()?.time ?: 0L }
                            ).first()
                        }
                        .values
                        .sortedByDescending { it.timestamp?.toDate()?.time ?: 0L }
                }

                val totalPendingCount = deduplicatedPaymentIntents.size

                val blockedFraudOrUnpaidCount = aiProChatLogsList.count {
                    !it.proGranted && (
                        it.eventType == "FAKE_BILL_DETECTED" ||
                            it.eventType == "REUSED_BILL_BLOCKED" ||
                            it.eventType == "BILL_REJECTED" ||
                            it.eventType == "UNPAID_PRO_REQUEST_BLOCKED"
                        )
                }

                // CẢNH BÁO NHẮC ADMIN ĐĂNG NHẬP NẾU ĐANG CHỈ Ở CHẾ ĐỘ MÁY QUEN
                val isGuestAdmin = currentUser == null || currentUser?.email.isNullOrBlank()
                if (isGuestAdmin) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF261C05)),
                        border = BorderStroke(1.2.dp, MagicAmber)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = null,
                                tint = MagicAmber,
                                modifier = Modifier.size(28.dp)
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "⚠️ ADMIN CHƯA ĐĂNG NHẬP GOOGLE",
                                    color = MagicAmber,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Black
                                )
                                Text(
                                    text = "Bạn đang vào với quyền Máy Quen của Admin. Hãy bấm Đăng Nhập để token Google chuẩn được cấp phát, đảm bảo mọi thao tác duyệt/xóa/đồng bộ gửi thẳng vào Firebase 100% không bị chặn quyền!",
                                    color = Color(0xFFFDE68A),
                                    fontSize = 10.5.sp,
                                    lineHeight = 14.sp
                                )
                            }
                            Button(
                                onClick = {
                                    try {
                                        val intent = android.content.Intent(context, com.example.MainActivity::class.java).apply {
                                            flags = android.content.Intent.FLAG_ACTIVITY_SINGLE_TOP or android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP
                                            putExtra("TARGET_TAB", "LOGIN")
                                        }
                                        context.startActivity(intent)
                                    } catch (_: Exception) {}
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = MagicAmber, contentColor = Color(0xFF020617)),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text("Đăng Nhập", fontWeight = FontWeight.Black, fontSize = 11.sp)
                            }
                        }
                    }
                }

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                    border = BorderStroke(1.2.dp, MagicCyan.copy(alpha = 0.7f))
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "📊 TỔNG QUAN VẬN HÀNH HỆ THỐNG",
                                    color = MagicCyanLight,
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.Black
                                )
                                if (lastMetricsSyncTime.isNotBlank()) {
                                    Text(
                                        text = "Đồng bộ Kép (REST + Realtime): $lastMetricsSyncTime",
                                        color = MagicEmeraldLight.copy(alpha = 0.85f),
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MagicCyan.copy(alpha = 0.18f))
                                    .border(1.dp, MagicCyan.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                    .clickable(enabled = !isSyncingMetrics) {
                                        refreshAllAdminMetricsViaRest(showToastOnDone = true)
                                    }
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = if (isSyncingMetrics) "⏳ Đang nạp..." else "🔄 Làm mới",
                                    color = MagicCyanLight,
                                    fontSize = 9.5.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MagicSurfaceCard)
                                    .border(1.dp, MagicEmerald.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                    .clickable {
                                        adminSubTab = 1
                                        deviceFilterTab = "⚡ ĐÃ LÊN PRO"
                                    }
                                    .padding(vertical = 8.dp, horizontal = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("📱 Pro Máy", color = TextSecondary, fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
                                    Text("${activeProDevices.size} máy", color = MagicEmeraldLight, fontSize = 12.sp, fontWeight = FontWeight.Black)
                                }
                            }
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MagicSurfaceCard)
                                    .border(1.dp, MagicAmber.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                                    .clickable {
                                        adminSubTab = 3
                                        selectedFilterChip = "⚡ Pro"
                                    }
                                    .padding(vertical = 8.dp, horizontal = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("👑 Pro TK", color = TextSecondary, fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
                                    Text("$totalAccountProCount TK", color = MagicAmber, fontSize = 12.sp, fontWeight = FontWeight.Black)
                                }
                            }
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MagicSurfaceCard)
                                    .border(1.dp, MagicCyan.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                    .clickable { adminSubTab = 2 }
                                    .padding(vertical = 8.dp, horizontal = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("⏳ Chờ Duyệt", color = TextSecondary, fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
                                    Text("$totalPendingCount đơn", color = MagicCyanLight, fontSize = 12.sp, fontWeight = FontWeight.Black)
                                }
                            }
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MagicSurfaceCard)
                                    .border(1.dp, MagicRose.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                                    .clickable {
                                        adminSubTab = 5
                                        aiLogFilterTab = "🛡️ Chặn Chưa TT"
                                    }
                                    .padding(vertical = 8.dp, horizontal = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("🚨 Đã Chặn", color = TextSecondary, fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
                                    Text("$blockedFraudOrUnpaidCount vụ", color = MagicRoseLight, fontSize = 12.sp, fontWeight = FontWeight.Black)
                                }
                            }
                        }
                    }
                }

                                // CÔNG TẮC BẬT/TẮT TỰ ĐỘNG PHÊ DUYỆT QUA THÔNG BÁO NGÂN HÀNG & SMS
                var notificationPaymentEnabled by remember { mutableStateOf(LicenseManager.isAutoApproveNotificationPaymentEnabled(context)) }
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                    border = BorderStroke(1.2.dp, if (notificationPaymentEnabled) MagicEmerald else MagicRose)
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.NotificationsActive,
                                    contentDescription = null,
                                    tint = if (notificationPaymentEnabled) MagicEmerald else MagicRoseLight,
                                    modifier = Modifier.size(20.dp)
                                )
                                Column {
                                    Text(
                                        text = "🔔 TỰ ĐỘNG DUYỆT PRO QUA THÔNG BÁO NGÂN HÀNG & SMS",
                                        color = if (notificationPaymentEnabled) MagicEmeraldLight else MagicRoseLight,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                    Text(
                                        text = if (notificationPaymentEnabled)
                                            "🟢 ĐANG BẬT • Tự động bắt số dư >= 50k & gán Pro"
                                        else
                                            "🔴 ĐANG TẮT • Đã khóa tự động duyệt qua thông báo",
                                        color = TextSecondary,
                                        fontSize = 9.5.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                            Switch(
                                checked = notificationPaymentEnabled,
                                onCheckedChange = { enabled ->
                                    notificationPaymentEnabled = enabled
                                    LicenseManager.setAutoApproveNotificationPaymentEnabled(context, enabled)
                                    Toast.makeText(
                                        context,
                                        if (enabled) "🔔 Đã BẬT tính năng tự động duyệt Pro qua thông báo ngân hàng!" else "🔴 Đã TẮT tính năng tự động duyệt qua thông báo để chống thất thoát!",
                                        Toast.LENGTH_LONG
                                    ).show()
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = MagicEmerald
                                )
                            )
                        }
                        Text(
                            text = "💡 Khi tắt công tắc này, app sẽ ngừng hoàn toàn việc tự động cấp Pro khi nhận thông báo chuyển khoản ngân hàng/SMS. Admin có thể tạm tắt nếu phát hiện thông báo nhầm lẫn hoặc cần kiểm soát thủ công tuyệt đối 100%.",
                            color = TextSecondary,
                            fontSize = 9.5.sp
                        )


                // TRẢI NGHIỆM CHẾ ĐỘ NGƯỜI DÙNG FREE CHO ADMIN
                var simulateFreeMode by remember { mutableStateOf(LicenseManager.isAdminSimulateFreeMode(context)) }
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                    border = BorderStroke(1.2.dp, if (simulateFreeMode) MagicAmber else MagicCyan)
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Science,
                                    contentDescription = null,
                                    tint = if (simulateFreeMode) MagicAmber else MagicCyan,
                                    modifier = Modifier.size(20.dp)
                                )
                                Column {
                                    Text(
                                        text = "🧪 TRẢI NGHIỆM GIAO DIỆN FREE (TẠM ẨN PRO)",
                                        color = if (simulateFreeMode) MagicAmber else MagicCyanLight,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                    Text(
                                        text = if (simulateFreeMode)
                                            "⚠️ ĐANG GIẢ LẬP KHÁCH THƯỜNG • Bản thân đang thấy giao diện chưa có Pro"
                                        else
                                            "🟢 BÌNH THƯỜNG • Đang có đầy đủ quyền Quản trị & Pro",
                                        color = TextSecondary,
                                        fontSize = 9.5.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                            Switch(
                                checked = simulateFreeMode,
                                onCheckedChange = { enabled ->
                                    simulateFreeMode = enabled
                                    LicenseManager.setAdminSimulateFreeMode(context, enabled)
                                    Toast.makeText(
                                        context,
                                        if (enabled) "🧪 Đã ẩn Pro của bạn để trải nghiệm góc nhìn người dùng Free!" else "👑 Đã khôi phục trạng thái Pro đầy đủ cho Admin!",
                                        Toast.LENGTH_LONG
                                    ).show()
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = MagicAmber
                                )
                            )
                        }
                        Text(
                            text = "💡 Tính năng này giúp Admin tự trải nghiệm xem người dùng chưa có Pro nhìn thấy những gì (Banner nhắc nâng cấp, giới hạn dùng thử, nút Mua Pro...), giúp thấu hiểu khách hàng tốt hơn.",
                            color = TextSecondary,
                            fontSize = 9.5.sp
                        )
                    }
                }

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                    border = BorderStroke(1.2.dp, if (autoApproveProEnabled) MagicEmerald else MagicAmber)
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = null,
                                    tint = if (autoApproveProEnabled) MagicEmerald else MagicAmber,
                                    modifier = Modifier.size(20.dp)
                                )
                                Column {
                                    Text(
                                        text = "🤖 TRỢ LÝ AUTO-ADMIN DUYỆT & GÁN PRO TỰ ĐỘNG",
                                        color = if (autoApproveProEnabled) MagicEmeraldLight else MagicAmber,
                                        fontSize = 11.5.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                    Text(
                                        text = if (autoApproveProEnabled)
                                            "🟢 ĐANG BẬT RẢNH TAY 100% • Đã tự động gán Pro: $autoApprovedCountSession máy"
                                        else
                                            "🟡 ĐANG TẠM TẮT (Duyệt thủ công)",
                                        color = TextSecondary,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                            Switch(
                                checked = autoApproveProEnabled,
                                onCheckedChange = { enabled ->
                                    autoApproveProEnabled = enabled
                                    LicenseManager.setAutoApproveNotificationPaymentEnabled(context, enabled)
                                    Toast.makeText(
                                        context,
                                        if (enabled) "🤖 Đã BẬT chế độ Auto-Admin tự động duyệt & gán Pro rảnh tay!" else "Đã chuyển sang chế độ duyệt thủ công.",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = MagicEmerald
                                )
                            )
                        }

                        Text(
                            text = "Khi bật, Trợ lý Auto-Admin chỉ tự động gán Pro khi: (1) Khách gửi ảnh biên lai chuyển khoản (bill) được AI xác thực hợp lệ, (2) Khách nhập đúng mã Key SHA-256, hoặc (3) Thiết bị quen thuộc đã có trong Danh sách Thiết Bị Pro / Danh sách Tài Khoản Pro trên Firebase. Tuyệt đối chặn khách chưa thanh toán xin lên Pro qua tin nhắn chữ!",
                            color = TextSecondary,
                            fontSize = 10.sp,
                            lineHeight = 14.sp
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { adminSubTab = 5 },
                                colors = ButtonDefaults.buttonColors(containerColor = MagicCyan),
                                modifier = Modifier.weight(1f).height(38.dp),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(imageVector = Icons.Default.History, contentDescription = null, tint = Color(0xFF020617), modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "📜 Lịch Sử AI (${aiProChatLogsList.size})",
                                    color = Color(0xFF020617),
                                    fontWeight = FontWeight.Black,
                                    fontSize = 10.5.sp
                                )
                            }

                            Button(
                                onClick = {
                                    val currentPool = LicenseManager.getGroqApiKeyPool(context)
                                    LicenseManager.syncAllKnowledgeBaseAndKeyListToCloud(context, currentPool) { ok, devCount, keyCount, msg ->
                                        Toast.makeText(context, "🎉 $msg", Toast.LENGTH_LONG).show()
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = MagicPurpleLight, contentColor = Color(0xFF020617)),
                                modifier = Modifier.weight(1.3f).height(38.dp),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(imageVector = Icons.Default.Sync, contentDescription = null, tint = Color(0xFF020617), modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "🔄 Đồng bộ Knowledge Base & Key List",
                                    color = Color(0xFF020617),
                                    fontWeight = FontWeight.Black,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }
                }

                // Sub-tab Bar (2 rows to prevent cramping)
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val row1Tabs = listOf(
                        0 to "⚙️ [Ô 1] Cài Đặt",
                        1 to "📱 [Ô 2] Thiết Bị (${globalMergedDevices.size})",
                        2 to "⏳ [Ô 3] Chờ Duyệt (${deduplicatedPaymentIntents.size})",
                        3 to "👥 [Ô 4] Tài Khoản (${globalMergedUsers.size})"
                    )
                    val row2Tabs = listOf(
                        4 to "🔄 [Ô 5] Khôi Phục (${proRecoveryRequestsList.count { it.status == "PENDING" }})",
                        5 to "📜 [Ô 6] Lịch Sử AI (${aiProChatLogsList.size})",
                        6 to "📦 [Ô 7] Kho App (${allStoreApps.count { it.status == "PENDING" }})",
                        7 to "🚨 [Ô 8] Lỗi ADB (${adminAdbErrorLogsList.size})"
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        row1Tabs.forEach { (tabId, label) ->
                            val selected = adminSubTab == tabId
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (selected) MagicCyan.copy(alpha = 0.25f) else MagicSurfaceDark)
                                    .border(1.dp, if (selected) MagicCyan else MagicBorder, RoundedCornerShape(8.dp))
                                    .clickable {
                                        adminSubTab = tabId
                                        currentPage = 0
                                    }
                                    .padding(vertical = 10.dp, horizontal = 4.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = label,
                                    color = if (selected) MagicCyanLight else TextSecondary,
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        row2Tabs.forEach { (tabId, label) ->
                            val selected = adminSubTab == tabId
                            val isAdbTab = tabId == 7
                            val tabAccent = if (isAdbTab) MagicRose else MagicCyan
                            val tabAccentLight = if (isAdbTab) MagicRoseLight else MagicCyanLight
                            val borderCol = if (selected) tabAccent else if (isAdbTab && adminAdbErrorLogsList.isNotEmpty()) MagicRose.copy(alpha = 0.65f) else MagicBorder
                            val bgCol = if (selected) tabAccent.copy(alpha = 0.25f) else if (isAdbTab && adminAdbErrorLogsList.isNotEmpty()) MagicRose.copy(alpha = 0.12f) else MagicSurfaceDark

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(bgCol)
                                    .border(1.dp, borderCol, RoundedCornerShape(8.dp))
                                    .clickable {
                                        adminSubTab = tabId
                                        currentPage = 0
                                    }
                                    .padding(vertical = 10.dp, horizontal = 4.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = label,
                                    color = if (selected) tabAccentLight else if (isAdbTab && adminAdbErrorLogsList.isNotEmpty()) MagicRoseLight else TextSecondary,
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                            }
                        }
                    }
                }

                when (adminSubTab) {
                    0 -> {
                        // TAB 0: CÀI ĐẶT HỆ THỐNG & TẠO KEY
                        val activeBroadcast by LicenseManager.globalBroadcastFlow.collectAsState()
                        var broadcastTitleInput by remember {
                            mutableStateOf(
                                activeBroadcast?.title?.takeIf { it.isNotBlank() }
                                    ?: "🚀 Đã có phiên bản Magictune_Tool mới!"
                            )
                        }
                        var broadcastMessageInput by remember {
                            mutableStateOf(
                                activeBroadcast?.message?.takeIf { it.isNotBlank() }
                                    ?: "Đã có bản cập nhật mới với nhiều tính năng sửa lỗi và tối ưu mượt hơn! Quý khách vui lòng ấn vào nút 'Bản cập nhật' ở góc trên cùng màn hình (Header) để tải và cài đặt phiên bản mới nhất nhé."
                            )
                        }
                        var broadcastTypeInput by remember {
                            mutableStateOf(activeBroadcast?.type ?: "UPDATE")
                        }
                        var updateLinkInput by remember {
                            mutableStateOf(
                                activeBroadcast?.actionUrl?.takeIf { it.isNotBlank() }
                                    ?: LicenseManager.getUpdateLink(context)
                            )
                        }

                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // PHÁT THÔNG BÁO TOÀN CẦU TỚI MỌI THIẾT BỊ (REAL-TIME)
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                                border = BorderStroke(
                                    1.2.dp,
                                    if (activeBroadcast?.isActive == true) MagicEmerald else MagicCyan
                                )
                            ) {
                                Column(
                                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Campaign,
                                                contentDescription = null,
                                                tint = MagicCyanLight,
                                                modifier = Modifier.size(20.dp)
                                            )
                                            Text(
                                                text = "[Ô 1.1] 📢 PHÁT THÔNG BÁO TOÀN CẦU TỚI MỌI THIẾT BỊ",
                                                color = MagicCyanLight,
                                                fontSize = 11.5.sp,
                                                fontWeight = FontWeight.Black
                                            )
                                        }
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(
                                                    if (activeBroadcast?.isActive == true) MagicEmerald.copy(alpha = 0.2f)
                                                    else MagicBorder.copy(alpha = 0.3f)
                                                )
                                                .border(
                                                    1.dp,
                                                    if (activeBroadcast?.isActive == true) MagicEmerald else MagicBorder,
                                                    RoundedCornerShape(6.dp)
                                                )
                                                .padding(horizontal = 7.dp, vertical = 3.dp)
                                        ) {
                                            Text(
                                                text = if (activeBroadcast?.isActive == true) "🟢 ĐANG PHÁT" else "⚪ ĐANG TẮT",
                                                color = if (activeBroadcast?.isActive == true) MagicEmerald else TextSecondary,
                                                fontSize = 9.5.sp,
                                                fontWeight = FontWeight.Black
                                            )
                                        }
                                    }

                                    Text(
                                        text = "Gửi thông báo trực tiếp tới tất cả điện thoại đang cài app (hiện cả Popup, Thanh thông báo trên Header, thông báo hệ thống Android và làm sáng nút '🔥 Bản cập nhật (MỚI)').",
                                        color = TextSecondary,
                                        fontSize = 10.5.sp,
                                        lineHeight = 15.sp
                                    )

                                    // Mẫu soạn nhanh 1 chạm
                                    Row(
                                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(MagicAmber.copy(alpha = 0.18f))
                                                .border(1.dp, MagicAmber, RoundedCornerShape(6.dp))
                                                .clickable {
                                                    broadcastTypeInput = "UPDATE"
                                                    broadcastTitleInput = "🚀 Đã có phiên bản Magictune_Tool mới!"
                                                    broadcastMessageInput = "Đã có bản cập nhật mới với nhiều tính năng sửa lỗi và tối ưu mượt hơn! Quý khách vui lòng ấn vào nút 'Bản cập nhật' ở góc trên cùng màn hình (Header) để tải và cài đặt phiên bản mới nhất nhé."
                                                }
                                                .padding(horizontal = 8.dp, vertical = 5.dp)
                                        ) {
                                            Text(
                                                text = "🚀 Mẫu: Báo Có Bản Cập Nhật Mới",
                                                color = MagicAmber,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }

                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(MagicCyan.copy(alpha = 0.15f))
                                                .border(1.dp, MagicCyan.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                                                .clickable {
                                                    broadcastTypeInput = "ANNOUNCEMENT"
                                                    broadcastTitleInput = "📢 Thông báo quan trọng từ Admin"
                                                    broadcastMessageInput = "Hệ thống đã cập nhật thêm các tính năng tối ưu mới cho máy Honor nội địa. Chúc quý khách trải nghiệm mượt mà!"
                                                }
                                                .padding(horizontal = 8.dp, vertical = 5.dp)
                                        ) {
                                            Text(
                                                text = "📢 Mẫu: Thông Báo Chung",
                                                color = MagicCyanLight,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }

                                    // Chọn loại thông báo
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        val types = listOf(
                                            "UPDATE" to "🚀 Báo Cập Nhật (Làm sáng nút Header)",
                                            "ANNOUNCEMENT" to "📢 Thông Báo Thường"
                                        )
                                        types.forEach { (typeKey, typeLabel) ->
                                            val isSelected = broadcastTypeInput == typeKey
                                            Box(
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .clip(RoundedCornerShape(8.dp))
                                                    .background(
                                                        if (isSelected) MagicCyan.copy(alpha = 0.22f)
                                                        else MagicSurfaceCard
                                                    )
                                                    .border(
                                                        1.dp,
                                                        if (isSelected) MagicCyan else MagicBorder,
                                                        RoundedCornerShape(8.dp)
                                                    )
                                                    .clickable { broadcastTypeInput = typeKey }
                                                    .padding(vertical = 7.dp, horizontal = 6.dp),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(
                                                    text = typeLabel,
                                                    color = if (isSelected) MagicCyanLight else TextSecondary,
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    textAlign = TextAlign.Center
                                                )
                                            }
                                        }
                                    }

                                    OutlinedTextField(
                                        value = broadcastTitleInput,
                                        onValueChange = { broadcastTitleInput = it },
                                        modifier = Modifier.fillMaxWidth(),
                                        label = { Text("Tiêu đề thông báo", fontSize = 10.5.sp) },
                                        singleLine = true,
                                        shape = RoundedCornerShape(8.dp)
                                    )

                                    OutlinedTextField(
                                        value = broadcastMessageInput,
                                        onValueChange = { broadcastMessageInput = it },
                                        modifier = Modifier.fillMaxWidth(),
                                        label = { Text("Nội dung thông báo gửi tới mọi thiết bị", fontSize = 10.5.sp) },
                                        minLines = 2,
                                        maxLines = 4,
                                        shape = RoundedCornerShape(8.dp)
                                    )

                                    OutlinedTextField(
                                        value = updateLinkInput,
                                        onValueChange = { updateLinkInput = it },
                                        modifier = Modifier.fillMaxWidth(),
                                        label = { Text("Link tải khi khách ấn nút 'Bản cập nhật' trên Header", fontSize = 10.5.sp) },
                                        singleLine = true,
                                        shape = RoundedCornerShape(8.dp)
                                    )

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Button(
                                            onClick = {
                                                if (broadcastTitleInput.isBlank() && broadcastMessageInput.isBlank()) {
                                                    Toast.makeText(context, "Vui lòng nhập tiêu đề hoặc nội dung thông báo!", Toast.LENGTH_SHORT).show()
                                                } else {
                                                    LicenseManager.sendGlobalBroadcast(
                                                        context = context,
                                                        title = broadcastTitleInput,
                                                        message = broadcastMessageInput,
                                                        type = broadcastTypeInput,
                                                        customUpdateUrl = updateLinkInput
                                                    )
                                                    Toast.makeText(context, "📢 Đã phát thông báo toàn cầu tới tất cả thiết bị!", Toast.LENGTH_LONG).show()
                                                }
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = MagicEmerald),
                                            modifier = Modifier.weight(1.3f).height(42.dp),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Icon(imageVector = Icons.AutoMirrored.Filled.Send, contentDescription = null, tint = Color(0xFF020617), modifier = Modifier.size(15.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("Phát Thông Báo Ngay", color = Color(0xFF020617), fontWeight = FontWeight.Black, fontSize = 11.5.sp)
                                        }

                                        if (activeBroadcast?.isActive == true) {
                                            Button(
                                                onClick = {
                                                    LicenseManager.clearGlobalBroadcast(context)
                                                    Toast.makeText(context, "🔕 Đã tắt thông báo toàn cầu!", Toast.LENGTH_SHORT).show()
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = MagicRose),
                                                modifier = Modifier.weight(0.7f).height(42.dp),
                                                shape = RoundedCornerShape(8.dp)
                                            ) {
                                                Text("🔕 Tắt Phát", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                            }
                                        }
                                    }
                                }
                            }

                            // KHO API KEY AI DỰ PHÒNG (FAILOVER POOL) & ĐỒNG BỘ KNOWLEDGE BASE
                            var isSyncingKnowledge by remember { mutableStateOf(false) }

                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                                border = BorderStroke(1.2.dp, MagicPurple)
                            ) {
                                Column(
                                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.VpnKey, contentDescription = null, tint = MagicPurpleLight, modifier = Modifier.size(20.dp))
                                        Text(
                                            text = "[Ô 1.2] 🧠 ĐỒNG BỘ KNOWLEDGE BASE & KHO KEY LIST AI",
                                            color = MagicPurpleLight,
                                            fontSize = 11.5.sp,
                                            fontWeight = FontWeight.Black
                                        )
                                    }
                                    Text(
                                        text = "Nhập danh sách các API Key dự phòng cho Trợ lý hỗ trợ (Key List - cách nhau dấu cách ' '). Bấm nút 'Đồng bộ Knowledge Base & Key List' để nạp và đồng bộ bộ kiến thức cùng kho Key AI lên Cloud Firebase cho 100% thiết bị.",
                                        color = TextSecondary,
                                        fontSize = 10.5.sp,
                                        lineHeight = 15.sp
                                    )
                                    OutlinedTextField(
                                        value = groqApiKeyPoolInput,
                                        onValueChange = { groqApiKeyPoolInput = it },
                                        modifier = Modifier.fillMaxWidth(),
                                        label = { Text("Danh sách khóa kết nối AI dự phòng (Key List)...", fontSize = 10.5.sp) },
                                        minLines = 2,
                                        maxLines = 4,
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Button(
                                            onClick = {
                                                val input = groqApiKeyPoolInput.trim()
                                                LicenseManager.setGroqApiKeyPool(context, input)
                                                val geminiKeys = input.split(Regex("[\\s,;]+")).filter { it.startsWith("AIza") }
                                                if (geminiKeys.isNotEmpty()) {
                                                    val existing = LicenseManager.getGeminiApiKeyPool(context)
                                                    val combined = (geminiKeys + existing.split(Regex("[\\s,;]+"))).filter { it.isNotBlank() }.distinct().joinToString(" ")
                                                    LicenseManager.setGeminiApiKeyPool(context, combined)
                                                }
                                                Toast.makeText(context, "💾 Đã lưu kho API Key AI dự phòng thành công!", Toast.LENGTH_SHORT).show()
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = MagicPurple),
                                            modifier = Modifier.weight(1f).height(42.dp),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Icon(imageVector = Icons.Default.Save, contentDescription = null, tint = Color.White, modifier = Modifier.size(15.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Lưu Kho Key List", color = Color.White, fontWeight = FontWeight.Black, fontSize = 11.sp)
                                        }

                                        Button(
                                            onClick = {
                                                isSyncingKnowledge = true
                                                LicenseManager.syncAllKnowledgeBaseAndKeyListToCloud(context, groqApiKeyPoolInput) { ok, devCount, keyCount, msg ->
                                                    isSyncingKnowledge = false
                                                    Toast.makeText(context, "🎉 $msg", Toast.LENGTH_LONG).show()
                                                }
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = MagicCyan, contentColor = Color(0xFF020617)),
                                            modifier = Modifier.weight(1.3f).height(42.dp),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            if (isSyncingKnowledge) {
                                                CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color(0xFF020617), strokeWidth = 2.dp)
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("ĐANG ĐỒNG BỘ...", fontSize = 10.5.sp, fontWeight = FontWeight.Black)
                                            } else {
                                                Icon(imageVector = Icons.Default.Sync, contentDescription = null, tint = Color(0xFF020617), modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("Đồng bộ Knowledge Base & Key List", color = Color(0xFF020617), fontWeight = FontWeight.Black, fontSize = 10.sp)
                                            }
                                        }
                                    }
                                }
                            }

                            // Tùy chỉnh giá Pro Thiết Bị / Pro Tài Khoản / Phí Nâng Cấp
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                                border = BorderStroke(1.dp, MagicBorder)
                            ) {
                                Column(
                                    modifier = Modifier.fillMaxWidth().padding(10.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(
                                        text = "[Ô 1.3] 💰 CẤU HÌNH BẢNG GIÁ GÓI PRO TOÀN HỆ THỐNG",
                                        color = MagicPurpleLight,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        OutlinedTextField(
                                            value = customPriceInput,
                                            onValueChange = { customPriceInput = it },
                                            modifier = Modifier.weight(1f),
                                            label = { Text("📱 Giá Pro Máy (VD: 50.000đ)", fontSize = 10.5.sp) },
                                            singleLine = true,
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        OutlinedTextField(
                                            value = accountProPriceInput,
                                            onValueChange = { accountProPriceInput = it },
                                            modifier = Modifier.weight(1f),
                                            label = { Text("👑 Giá Pro TK (VD: 100.000đ)", fontSize = 10.5.sp) },
                                            singleLine = true,
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                    }
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        OutlinedTextField(
                                            value = upgradeAccountProPriceInput,
                                            onValueChange = { upgradeAccountProPriceInput = it },
                                            modifier = Modifier.weight(1f),
                                            label = { Text("🚀 Phí nâng Pro Máy -> Pro TK (+50.000đ)", fontSize = 10.5.sp) },
                                            singleLine = true,
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        Button(
                                            onClick = {
                                                LicenseManager.saveAllProPrices(
                                                    context = context,
                                                    proPrice = customPriceInput,
                                                    accountProPrice = accountProPriceInput,
                                                    upgradeAccountProPrice = upgradeAccountProPriceInput
                                                ) { syncedCloud ->
                                                    customPriceInput = LicenseManager.getProPrice(context)
                                                    accountProPriceInput = LicenseManager.getAccountProPrice(context)
                                                    upgradeAccountProPriceInput = LicenseManager.getUpgradeToAccountProPrice(context)
                                                    Toast.makeText(
                                                        context,
                                                        if (syncedCloud) "✅ Đã lưu & đồng bộ bảng giá lên Firebase: Máy $customPriceInput | TK $accountProPriceInput | Nâng cấp +$upgradeAccountProPriceInput"
                                                        else "✅ Đã lưu bảng giá trên máy: Máy $customPriceInput | TK $accountProPriceInput | Nâng cấp +$upgradeAccountProPriceInput",
                                                        Toast.LENGTH_LONG
                                                    ).show()
                                                }
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = MagicPurpleLight),
                                            modifier = Modifier.height(42.dp)
                                        ) {
                                            Text("Lưu Bảng Giá", color = Color(0xFF020617), fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
                                        }
                                    }
                                }
                            }

                            // Thẻ Cấu Hình Cơ Chế Tự Động Miễn Phí (Dead Man Switch khi không có Admin quản lý)
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                                border = BorderStroke(1.dp, Color(0xFF10B981).copy(alpha = 0.8f))
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Text("🎁", fontSize = 18.sp)
                                        Column {
                                            Text(
                                                text = "[Ô 1.4] 🎁 Cơ Chế Tự Động Miễn Phí (Dead Man Switch)",
                                                color = Color.White,
                                                fontSize = 13.5.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                text = "Nếu trong số ngày này không có Admin nào truy cập ứng dụng, toàn bộ app sẽ tự động mở khóa 100% MIỄN PHÍ vĩnh viễn cho tất cả người dùng!",
                                                color = Color(0xFF94A3B8),
                                                fontSize = 10.5.sp
                                            )
                                        }
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        OutlinedTextField(
                                            value = autoFreeDaysInput,
                                            onValueChange = { autoFreeDaysInput = it.filter { ch -> ch.isDigit() } },
                                            modifier = Modifier.weight(1f),
                                            label = { Text("Số ngày không có Admin (Mặc định: 30 ngày)", fontSize = 10.5.sp) },
                                            singleLine = true,
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        Button(
                                            onClick = {
                                                val days = autoFreeDaysInput.toIntOrNull() ?: 30
                                                LicenseManager.setAutoFreeInactivityDays(context, days) { ok ->
                                                    Toast.makeText(
                                                        context,
                                                        if (ok) "✅ Đã lưu: Tự động miễn phí toàn bộ app sau $days ngày nếu không có Admin!"
                                                        else "✅ Đã lưu cấu hình $days ngày trên thiết bị",
                                                        Toast.LENGTH_LONG
                                                    ).show()
                                                }
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669)),
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.height(42.dp)
                                        ) {
                                            Text("Lưu Ngày", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
                                        }
                                    }
                                }
                            }

                            // Cài đặt Tài Khoản Nhận Tiền Chuyển Khoản & VietQR
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                                border = BorderStroke(1.dp, MagicAmber.copy(alpha = 0.8f))
                            ) {
                                Column(
                                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.AccountBalance,
                                            contentDescription = null,
                                            tint = MagicAmber,
                                            modifier = Modifier.size(20.dp)
                                        )
                                        Text(
                                            text = "[Ô 1.5] 💳 CÀI ĐẶT TÀI KHOẢN NHẬN TIỀN & VIETQR",
                                            color = MagicAmber,
                                            fontSize = 11.5.sp,
                                            fontWeight = FontWeight.Black
                                        )
                                    }
                                    Text(
                                        text = "Tài khoản nhận tiền và mã VietQR sẽ tự động đồng bộ thời gian thực tới tất cả máy người dùng.",
                                        color = TextSecondary,
                                        fontSize = 10.5.sp
                                    )

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        OutlinedTextField(
                                            value = bankNameInput,
                                            onValueChange = { bankNameInput = it },
                                            modifier = Modifier.weight(1.2f),
                                            label = { Text("Tên NH/Momo", fontSize = 10.5.sp) },
                                            placeholder = { Text("MBBank") },
                                            singleLine = true,
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        OutlinedTextField(
                                            value = bankCodeInput,
                                            onValueChange = { bankCodeInput = it },
                                            modifier = Modifier.weight(0.8f),
                                            label = { Text("Mã VietQR", fontSize = 10.5.sp) },
                                            placeholder = { Text("MB") },
                                            singleLine = true,
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        OutlinedTextField(
                                            value = accountNumberInput,
                                            onValueChange = { accountNumberInput = it },
                                            modifier = Modifier.weight(1f),
                                            label = { Text("Số TK / SĐT Momo", fontSize = 10.5.sp) },
                                            placeholder = { Text("0393368007") },
                                            singleLine = true,
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        OutlinedTextField(
                                            value = accountHolderInput,
                                            onValueChange = { accountHolderInput = it },
                                            modifier = Modifier.weight(1f),
                                            label = { Text("Chủ Tài Khoản", fontSize = 10.5.sp) },
                                            placeholder = { Text("NGUYEN VAN VUONG") },
                                            singleLine = true,
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Button(
                                            onClick = {
                                                LicenseManager.setPaymentAccount(
                                                    context,
                                                    bankName = bankNameInput,
                                                    bankCode = bankCodeInput,
                                                    accountNumber = accountNumberInput,
                                                    accountHolder = accountHolderInput
                                                )
                                                Toast.makeText(context, "✅ Đã lưu & đồng bộ tài khoản nhận tiền lên hệ thống!", Toast.LENGTH_SHORT).show()
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = MagicAmber),
                                            modifier = Modifier.weight(1.3f).height(40.dp),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Icon(imageVector = Icons.Default.Save, contentDescription = null, tint = Color(0xFF020617), modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("Lưu & Đồng Bộ TK", color = Color(0xFF020617), fontWeight = FontWeight.Black, fontSize = 11.sp)
                                        }

                                        OutlinedButton(
                                            onClick = { showVietQrPreview = !showVietQrPreview },
                                            modifier = Modifier.weight(0.9f).height(40.dp),
                                            shape = RoundedCornerShape(8.dp),
                                            border = BorderStroke(1.dp, MagicCyan)
                                        ) {
                                            Text(
                                                text = if (showVietQrPreview) "🙈 Ẩn QR Mẫu" else "👁️ Xem Thử QR",
                                                color = MagicCyanLight,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 10.5.sp
                                            )
                                        }
                                    }

                                    if (showVietQrPreview) {
                                        val sampleAmount = LicenseManager.getProPrice(context).filter { it.isDigit() }.ifBlank { "50000" }
                                        val sampleMemo = java.net.URLEncoder.encode("PRO ${LicenseManager.getDeviceId(context)}", "UTF-8")
                                        val sampleHolder = java.net.URLEncoder.encode(accountHolderInput.trim(), "UTF-8")
                                        val sampleQrUrl = "https://img.vietqr.io/image/${bankCodeInput.trim()}-${accountNumberInput.trim()}-compact2.png?amount=$sampleAmount&addInfo=$sampleMemo&accountName=$sampleHolder"
                                        Column(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(10.dp))
                                                .background(Color.White)
                                                .padding(10.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            verticalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Text(
                                                text = "MÃ VIETQR HIỂN THỊ CHO KHÁCH HÀNG (KIỂM TRA TRỰC QUAN)",
                                                color = Color(0xFF0F172A),
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Black
                                            )
                                            coil.compose.AsyncImage(
                                                model = sampleQrUrl,
                                                contentDescription = "VietQR Preview",
                                                modifier = Modifier.size(190.dp)
                                            )
                                            Text(
                                                text = "Ngân hàng: $bankNameInput ($bankCodeInput) • STK: $accountNumberInput\nChủ TK: $accountHolderInput • Số tiền mẫu: $customPriceInput",
                                                color = Color(0xFF334155),
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                textAlign = TextAlign.Center
                                            )
                                        }
                                    }
                                }
                            }

                            // CẤU HÌNH LINK HỖ TRỢ KHÁCH HÀNG (FACEBOOK / ZALO) & LINK BẢN CẬP NHẬT CHÍNH THỨC
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                                border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.6f))
                            ) {
                                Column(
                                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.SupportAgent, contentDescription = null, tint = MagicCyanLight, modifier = Modifier.size(20.dp))
                                        Text(
                                            text = "[Ô 1.6] 🔗 CẤU HÌNH LINK HỖ TRỢ & LINK TẢI BẢN CẬP NHẬT",
                                            color = MagicCyanLight,
                                            fontSize = 11.5.sp,
                                            fontWeight = FontWeight.Black
                                        )
                                    }
                                    Text(
                                        text = "Đồng bộ đường dẫn khi khách bấm nút 'Liên hệ Admin' hoặc 'Bản cập nhật' trên toàn bộ thiết bị.",
                                        color = TextSecondary,
                                        fontSize = 10.5.sp
                                    )
                                    OutlinedTextField(
                                        value = supportLinkInput,
                                        onValueChange = { supportLinkInput = it },
                                        modifier = Modifier.fillMaxWidth(),
                                        label = { Text("Link Facebook / Zalo Hỗ Trợ Khách Hàng", fontSize = 10.5.sp) },
                                        singleLine = true,
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                    OutlinedTextField(
                                        value = globalUpdateLinkInput,
                                        onValueChange = { globalUpdateLinkInput = it },
                                        modifier = Modifier.fillMaxWidth(),
                                        label = { Text("Link tải APK / Bản cập nhật mặc định", fontSize = 10.5.sp) },
                                        singleLine = true,
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                    Button(
                                        onClick = {
                                            LicenseManager.setFacebookLink(context, supportLinkInput)
                                            LicenseManager.setUpdateLink(context, globalUpdateLinkInput)
                                            updateLinkInput = globalUpdateLinkInput
                                            Toast.makeText(context, "✅ Đã lưu & đồng bộ Link Hỗ Trợ và Link Cập Nhật!", Toast.LENGTH_SHORT).show()
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = MagicCyan),
                                        modifier = Modifier.fillMaxWidth().height(40.dp),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.Save, contentDescription = null, tint = Color(0xFF020617), modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Lưu Link Hỗ Trợ & Link Cập Nhật", color = Color(0xFF020617), fontWeight = FontWeight.Black, fontSize = 11.5.sp)
                                    }
                                }
                            }

                            // Trạng thái Miễn phí & Dùng thử đồng bộ toàn cầu từ LicenseManager

                            // Tùy chỉnh chế độ Trả phí / Miễn phí 100% & Số lượt dùng thử
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                                border = BorderStroke(1.dp, if (isAppFreeModeState) MagicEmerald else MagicPurple)
                            ) {
                                Column(
                                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = if (isAppFreeModeState) "[Ô 1.7] 🎁 ĐANG BẬT: APP MIỄN PHÍ 100%" else "[Ô 1.7] 💰 ĐANG BẬT: CHẾ ĐỘ THU PHÍ PRO",
                                                color = if (isAppFreeModeState) MagicEmerald else MagicPurpleLight,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Black
                                            )
                                            Text(
                                                text = if (isAppFreeModeState) "Mọi người dùng đều được mở khóa miễn phí (Tắt đi để bắt buộc thu phí)." else "Người dùng phải mua Pro sau khi hết số lượt dùng thử miễn phí.",
                                                color = TextSecondary,
                                                fontSize = 10.sp
                                            )
                                        }
                                        Switch(
                                            checked = isAppFreeModeState,
                                            onCheckedChange = { checked ->
                                                isAppFreeModeState = checked
                                                LicenseManager.setAppFreeMode(context, checked)
                                                Toast.makeText(context, if (checked) "Đã chuyển app thành MIỄN PHÍ cho mọi người!" else "Đã bật chế độ THU PHÍ PRO toàn hệ thống!", Toast.LENGTH_SHORT).show()
                                            }
                                        )
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        OutlinedTextField(
                                            value = freeTrialLimitInput,
                                            onValueChange = { freeTrialLimitInput = it.filter { ch -> ch.isDigit() } },
                                            modifier = Modifier.weight(1f),
                                            label = { Text("Số lượt dùng thử miễn phí (Đặt 0 = Khóa 100%)", fontSize = 10.5.sp) },
                                            singleLine = true,
                                            shape = RoundedCornerShape(8.dp),
                                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                                        )
                                        Button(
                                            onClick = {
                                                val limit = (freeTrialLimitInput.toIntOrNull() ?: 1).coerceAtLeast(0)
                                                freeTrialLimitInput = limit.toString()
                                                LicenseManager.setFreeTrialLimit(context, limit)
                                                Toast.makeText(context, "✅ Đã lưu & đồng bộ Firebase: Số lượt dùng thử là $limit lần", Toast.LENGTH_SHORT).show()
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = MagicCyan),
                                            modifier = Modifier.height(40.dp)
                                        ) {
                                            Text("Lưu Lượt", color = Color(0xFF020617), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        }
                                    }
                                }
                            }

                            // License Key Generator Card
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                                border = BorderStroke(1.dp, MagicCyan)
                            ) {
                                Column(
                                    modifier = Modifier.fillMaxWidth().padding(10.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(
                                        text = "[Ô 1.8] 🔑 TẠO MÃ KÍCH HOẠT PRO THEO DEVICE ID",
                                        color = MagicCyan,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                    OutlinedTextField(
                                        value = genDeviceIdInput,
                                        onValueChange = { genDeviceIdInput = it },
                                        modifier = Modifier.fillMaxWidth(),
                                        label = { Text("Device ID của máy khách", fontSize = 11.sp) },
                                        singleLine = true,
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(
                                            onClick = {
                                                if (genDeviceIdInput.isNotBlank()) {
                                                    val key = LicenseManager.generateLicenseKeyForDevice(genDeviceIdInput)
                                                    generatedKeyOutput = key
                                                    LicenseManager.registerAdminGeneratedKeyToCloud(genDeviceIdInput, key, isAccountPro = false)
                                                    Toast.makeText(context, "Đã tạo mã Key Pro Máy & ghi nhận thiết bị lên Cloud!", Toast.LENGTH_SHORT).show()
                                                } else {
                                                    Toast.makeText(context, "Vui lòng nhập Device ID hợp lệ!", Toast.LENGTH_SHORT).show()
                                                }
                                            },
                                            modifier = Modifier.weight(1f).height(40.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = MagicCyan)
                                        ) {
                                            Text("📱 Key Pro Máy", color = Color(0xFF020617), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                        }
                                        Button(
                                            onClick = {
                                                if (genDeviceIdInput.isNotBlank()) {
                                                    val key = LicenseManager.generateAccountProLicenseKeyForDevice(genDeviceIdInput)
                                                    generatedKeyOutput = key
                                                    LicenseManager.registerAdminGeneratedKeyToCloud(genDeviceIdInput, key, isAccountPro = true)
                                                    Toast.makeText(context, "Đã tạo mã Key Pro Tài Khoản (TKPR) & ghi nhận lên Cloud!", Toast.LENGTH_SHORT).show()
                                                } else {
                                                    Toast.makeText(context, "Vui lòng nhập Device ID hợp lệ!", Toast.LENGTH_SHORT).show()
                                                }
                                            },
                                            modifier = Modifier.weight(1f).height(40.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = MagicAmber)
                                        ) {
                                            Text("👑 Key Pro TK", color = Color(0xFF020617), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                        }
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(
                                            onClick = {
                                                val targetId = genDeviceIdInput.trim().uppercase()
                                                if (targetId.isNotBlank()) {
                                                    LicenseManager.adminGrantTierForUserOrDevice(
                                                        userId = "",
                                                        deviceId = targetId,
                                                        grantAccountPro = false
                                                    ) { ok, msg ->
                                                        Toast.makeText(context, if (ok) "📱 $msg" else "❌ $msg", Toast.LENGTH_LONG).show()
                                                    }
                                                }
                                            },
                                            modifier = Modifier.weight(1f).height(38.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = MagicEmerald)
                                        ) {
                                            Text("⚡ Cấp Pro Máy Từ Xa", color = Color(0xFF020617), fontWeight = FontWeight.Bold, fontSize = 10.5.sp)
                                        }
                                        Button(
                                            onClick = {
                                                val targetId = genDeviceIdInput.trim().uppercase()
                                                if (targetId.isNotBlank()) {
                                                    LicenseManager.adminGrantTierForUserOrDevice(
                                                        userId = "",
                                                        deviceId = targetId,
                                                        grantAccountPro = true
                                                    ) { ok, msg ->
                                                        Toast.makeText(context, if (ok) "👑 $msg" else "❌ $msg", Toast.LENGTH_LONG).show()
                                                    }
                                                }
                                            },
                                            modifier = Modifier.weight(1f).height(38.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = MagicAmber)
                                        ) {
                                            Text("👑 Cấp Pro TK Từ Xa", color = Color(0xFF020617), fontWeight = FontWeight.Bold, fontSize = 10.5.sp)
                                        }
                                    }

                                    if (generatedKeyOutput.isNotBlank()) {
                                        Card(
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(8.dp),
                                            colors = CardDefaults.cardColors(containerColor = MagicSurfaceCard),
                                            border = BorderStroke(1.dp, MagicEmerald)
                                        ) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth().padding(8.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(text = "Mã Pro đã tạo:", color = TextMuted, fontSize = 9.sp)
                                                    Text(text = generatedKeyOutput, color = MagicEmerald, fontSize = 13.sp, fontWeight = FontWeight.Black)
                                                }
                                                IconButton(
                                                    onClick = {
                                                        val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                                        val clip = android.content.ClipData.newPlainText("Pro License Key", generatedKeyOutput)
                                                        clipboard.setPrimaryClip(clip)
                                                        Toast.makeText(context, "Đã sao chép mã Key!", Toast.LENGTH_SHORT).show()
                                                    }
                                                ) {
                                                    Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copy", tint = MagicCyan)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    1 -> {
                        // TAB 1: DANH SÁCH THIẾT BỊ (CHIA RÕ PRO, MIỄN PHÍ VÀ THIẾT BỊ NGHI VẤN)
                        val proDevicesCount = globalMergedDevices.count { it.isPro && !it.revokedByAdmin }
                        val freeDevicesCount = globalMergedDevices.count { !it.isPro || it.revokedByAdmin }
                        val suspiciousDevicesCount = globalMergedDevices.count { dev ->
                            val isEffectivePro = dev.isPro && !dev.revokedByAdmin
                            val isInvalidFormat = dev.deviceId.trim().length < 4
                            val isSuspectPro = isEffectivePro && isInvalidFormat
                            isSuspectPro
                        }

                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // Thanh chuyển Tab nhanh
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                val filterTabs = listOf(
                                    "Tất cả" to "Tất cả (${globalMergedDevices.size})",
                                    "⚡ ĐÃ LÊN PRO" to "PRO ($proDevicesCount)",
                                    "🔓 CHƯA LÊN PRO" to "FREE ($freeDevicesCount)",
                                    "🚨 NGHI VẤN" to "🚨 Nghi vấn ($suspiciousDevicesCount)"
                                )

                                filterTabs.forEach { (tabKey, tabLabel) ->
                                    val isSelected = deviceFilterTab == tabKey
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(
                                                when {
                                                    isSelected && tabKey == "🚨 NGHI VẤN" -> MagicRose.copy(alpha = 0.3f)
                                                    isSelected && tabKey == "⚡ ĐÃ LÊN PRO" -> MagicEmerald.copy(alpha = 0.25f)
                                                    isSelected && tabKey == "🔓 CHƯA LÊN PRO" -> MagicAmber.copy(alpha = 0.25f)
                                                    isSelected -> MagicCyan.copy(alpha = 0.25f)
                                                    else -> MagicSurfaceDark
                                                }
                                            )
                                            .border(
                                                1.dp,
                                                when {
                                                    isSelected && tabKey == "🚨 NGHI VẤN" -> MagicRose
                                                    isSelected && tabKey == "⚡ ĐÃ LÊN PRO" -> MagicEmerald
                                                    isSelected && tabKey == "🔓 CHƯA LÊN PRO" -> MagicAmber
                                                    isSelected -> MagicCyan
                                                    else -> MagicBorder
                                                },
                                                RoundedCornerShape(8.dp)
                                            )
                                            .clickable {
                                                deviceFilterTab = tabKey
                                                deviceCurrentPage = 0
                                            }
                                            .padding(vertical = 8.dp, horizontal = 2.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = tabLabel,
                                            color = when {
                                                isSelected && tabKey == "🚨 NGHI VẤN" -> MagicRoseLight
                                                isSelected && tabKey == "⚡ ĐÃ LÊN PRO" -> MagicEmeraldLight
                                                isSelected && tabKey == "🔓 CHƯA LÊN PRO" -> MagicAmber
                                                isSelected -> MagicCyanLight
                                                else -> TextSecondary
                                            },
                                            fontSize = 9.5.sp,
                                            fontWeight = if (isSelected) FontWeight.Black else FontWeight.Bold,
                                            textAlign = TextAlign.Center,
                                            maxLines = 1
                                        )
                                    }
                                }
                            }

                            // Banner cảnh báo và nút thu hồi hàng loạt nếu đang ở tab Nghi Vấn
                            if (deviceFilterTab == "🚨 NGHI VẤN" && suspiciousDevicesCount > 0) {
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = MagicRose.copy(alpha = 0.15f)),
                                    border = BorderStroke(1.2.dp, MagicRose)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(10.dp),
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            text = "🚨 PHÁT HIỆN $suspiciousDevicesCount THIẾT BỊ NGHI VẤN TỰ PHONG PRO HOẶC MÃ GD ẢO",
                                            color = MagicRoseLight,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.5.sp
                                        )
                                        Text(
                                            text = "Các thiết bị này có mã không bắt đầu bằng MT- (mã tham chiếu giao dịch ngân hàng cũ) hoặc được kích hoạt bởi thông báo tự động mà Admin chưa nhận được tiền.",
                                            color = Color.White.copy(alpha = 0.85f),
                                            fontSize = 10.sp
                                        )
                                        Button(
                                            onClick = {
                                                coroutineScope.launch {
                                                    var count = 0
                                                    allDevicesList.filter { dev ->
                                                        val isEffectivePro = dev.isPro && !dev.revokedByAdmin
                            val isInvalidFormat = dev.deviceId.trim().length < 4
                                                        isEffectivePro && isInvalidFormat
                                                    }.forEach { dev ->
                                                        try {
                                                            FirebaseAuthManager.toggleDeviceProStatus(dev.deviceId, false)
                                                            count++
                                                        } catch (_: Exception) {}
                                                    }
                                                    Toast.makeText(context, "🚫 Đã thu hồi quyền Pro của $count thiết bị nghi vấn thành công!", Toast.LENGTH_LONG).show()
                                                    refreshAllAdminMetricsViaRest(true)
                                                }
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = MagicRose),
                                            modifier = Modifier.fillMaxWidth().height(36.dp),
                                            contentPadding = PaddingValues(0.dp)
                                        ) {
                                            Text("🚫 THU HỒI PRO TẤT CẢ $suspiciousDevicesCount THIẾT BỊ NGHI VẤN NÀY", color = Color.White, fontWeight = FontWeight.Black, fontSize = 11.sp)
                                        }
                                    }
                                }
                            }

                            // Ô tìm kiếm thiết bị
                            OutlinedTextField(
                                value = searchQuery,
                                onValueChange = { searchQuery = it; deviceCurrentPage = 0 },
                                modifier = Modifier.fillMaxWidth(),
                                label = { Text("Tìm theo Device ID, tên máy, email khách...", fontSize = 11.sp) },
                                singleLine = true,
                                shape = RoundedCornerShape(8.dp),
                                leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = MagicCyan, modifier = Modifier.size(18.dp)) },
                                trailingIcon = {
                                    if (searchQuery.isNotBlank()) {
                                        IconButton(onClick = { searchQuery = ""; deviceCurrentPage = 0 }) {
                                            Icon(imageVector = Icons.Default.Clear, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                        }
                                    }
                                }
                            )

                            // Danh sách thiết bị đã được tự động gộp & hợp nhất từ bảng điều khiển tổng
                            val mergedDevices = globalMergedDevices

                            val filteredDevices = mergedDevices.filter { d ->
                                val isEffectivePro = d.isPro && !d.revokedByAdmin
                                val isInvalidFormat = d.deviceId.trim().length < 4
                                val isSuspectPro = isEffectivePro && isInvalidFormat

                                val matchesTab = when (deviceFilterTab) {
                                    "⚡ ĐÃ LÊN PRO" -> isEffectivePro && !isSuspectPro
                                    "🔓 CHƯA LÊN PRO" -> !isEffectivePro
                                    "🚨 NGHI VẤN" -> isSuspectPro
                                    else -> true
                                }
                                val matchesSearch = searchQuery.isBlank() ||
                                    d.deviceId.contains(searchQuery, true) ||
                                    d.model.contains(searchQuery, true) ||
                                    d.ownerEmail.contains(searchQuery, true) ||
                                    d.ownerName.contains(searchQuery, true)

                                matchesTab && matchesSearch
                            }.sortedWith(
                                compareByDescending<com.example.core.auth.DeviceRecord> {
                                    if (deviceFilterTab == "⚡ ĐÃ LÊN PRO") (it.proActivatedAt?.toDate()?.time ?: 0L)
                                    else maxOf(it.proActivatedAt?.toDate()?.time ?: 0L, it.createdAt?.toDate()?.time ?: 0L)
                                }.thenByDescending { it.createdAt?.toDate()?.time ?: 0L }
                                .thenByDescending { it.lastActive?.toDate()?.time ?: 0L }
                            )

                            val totalDevicePages = ((filteredDevices.size - 1) / devicePageSize) + 1
                            val safeDevicePage = deviceCurrentPage.coerceIn(0, (totalDevicePages - 1).coerceAtLeast(0))
                            val paginatedDevices = remember(filteredDevices, safeDevicePage) {
                                val start = safeDevicePage * devicePageSize
                                val end = (start + devicePageSize).coerceAtMost(filteredDevices.size)
                                if (start in 0 until filteredDevices.size) filteredDevices.subList(start, end) else emptyList()
                            }

                            if (filteredDevices.isEmpty()) {
                                Box(modifier = Modifier.fillMaxWidth().height(100.dp), contentAlignment = Alignment.Center) {
                                    Text(
                                        text = if (deviceFilterTab == "🔓 CHƯA LÊN PRO") "Không có thiết bị miễn phí nào đang chờ cấp Pro." else "Chưa có thiết bị nào phù hợp.",
                                        color = TextMuted,
                                        fontSize = 12.sp
                                    )
                                }
                            } else {
                                Column(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    paginatedDevices.forEach { dev ->
                                        val isEffectivePro = dev.isPro && !dev.revokedByAdmin
                                        Card(
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(10.dp),
                                            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                                            border = BorderStroke(
                                                1.dp,
                                                if (isEffectivePro) MagicEmerald.copy(alpha = 0.6f) else MagicAmber.copy(alpha = 0.6f)
                                            )
                                        ) {
                                            Column(
                                                modifier = Modifier.fillMaxWidth().padding(10.dp),
                                                verticalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                // Hàng 1: Device ID + Huy hiệu trạng thái
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Row(
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                        modifier = Modifier.weight(1f)
                                                    ) {
                                                        Text(
                                                            text = "📱 ${dev.deviceId}",
                                                            color = Color.White,
                                                            fontWeight = FontWeight.Black,
                                                            fontSize = 12.5.sp
                                                        )
                                                        IconButton(
                                                            onClick = {
                                                                val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                                                val clip = android.content.ClipData.newPlainText("Device ID", dev.deviceId)
                                                                clipboard.setPrimaryClip(clip)
                                                                Toast.makeText(context, "Đã sao chép: ${dev.deviceId}", Toast.LENGTH_SHORT).show()
                                                            },
                                                            modifier = Modifier.size(24.dp)
                                                        ) {
                                                            Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copy", tint = MagicCyan, modifier = Modifier.size(14.dp))
                                                        }
                                                    }

                                                    Box(
                                                        modifier = Modifier
                                                            .clip(RoundedCornerShape(4.dp))
                                                            .background(
                                                                when {
                                                                    isEffectivePro -> MagicEmerald.copy(alpha = 0.2f)
                                                                    dev.revokedByAdmin -> MagicRose.copy(alpha = 0.2f)
                                                                    else -> MagicAmber.copy(alpha = 0.2f)
                                                                }
                                                            )
                                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                                    ) {
                                                        Text(
                                                            text = when {
                                                                isEffectivePro -> "⚡ PRO VĨNH VIỄN"
                                                                dev.revokedByAdmin -> "🚫 ĐÃ BỊ GỠ PRO"
                                                                else -> "🔓 CHƯA LÊN PRO"
                                                            },
                                                            color = when {
                                                                isEffectivePro -> MagicEmerald
                                                                dev.revokedByAdmin -> MagicRoseLight
                                                                else -> MagicAmber
                                                            },
                                                            fontSize = 9.5.sp,
                                                            fontWeight = FontWeight.Black
                                                        )
                                                    }
                                                }

                                                // Hàng 2: Thời gian online & ngày thêm
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Row(
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                                    ) {
                                                        Icon(imageVector = Icons.Default.AccessTime, contentDescription = null, tint = MagicCyanLight, modifier = Modifier.size(13.dp))
                                                        Text(
                                                            text = dev.getLastActiveFormatted(),
                                                            color = MagicCyanLight,
                                                            fontSize = 10.5.sp,
                                                            fontWeight = FontWeight.SemiBold
                                                        )
                                                    }
                                                    Row(
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                                    ) {
                                                        Icon(imageVector = Icons.Default.CalendarToday, contentDescription = null, tint = TextMuted, modifier = Modifier.size(12.dp))
                                                        Text(
                                                            text = "Thêm: ${dev.getCreatedAtFormatted()}",
                                                            color = TextMuted,
                                                            fontSize = 10.sp
                                                        )
                                                    }
                                                }

                                                // Hàng 3: Tên máy, Chủ sở hữu & Huy hiệu Khách vãng lai
                                                val isGuestDevice = dev.ownerEmail.contains("Khách vãng lai", ignoreCase = true) ||
                                                        dev.ownerEmail.contains("Chưa đăng nhập", ignoreCase = true) ||
                                                        dev.ownerUid.isBlank()

                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                                ) {
                                                    if (isGuestDevice) {
                                                        Box(
                                                            modifier = Modifier
                                                                .clip(RoundedCornerShape(4.dp))
                                                                .background(MagicAmber.copy(alpha = 0.2f))
                                                                .border(1.dp, MagicAmber.copy(alpha = 0.4f), RoundedCornerShape(4.dp))
                                                                .padding(horizontal = 5.dp, vertical = 2.dp)
                                                        ) {
                                                            Text(
                                                                text = "👤 KHÁCH VÃNG LAI",
                                                                color = MagicAmber,
                                                                fontSize = 9.sp,
                                                                fontWeight = FontWeight.Black
                                                            )
                                                        }
                                                    }
                                                    Text(
                                                        text = "Dòng máy: ${dev.model.ifBlank { "Honor Android" }}",
                                                        color = TextSecondary,
                                                        fontSize = 11.sp,
                                                        modifier = Modifier.weight(1f)
                                                    )
                                                }

                                                Text(
                                                    text = "Chủ sở hữu: ${dev.ownerEmail.ifBlank { "👤 Khách vãng lai (Chưa đăng nhập)" }}",
                                                    color = if (isGuestDevice) MagicAmber.copy(alpha = 0.9f) else TextSecondary,
                                                    fontSize = 10.5.sp
                                                )

                                                if (isEffectivePro && dev.proActivatedAt != null) {
                                                    Text(
                                                        text = "⚡ Đã kích hoạt Pro: ${dev.getProActivatedAtFormatted()}",
                                                        color = MagicEmerald,
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                }

                                                Text(
                                                    text = "🎯 Đã dùng thử: ${dev.freeTrialUsed} lượt${if (dev.licenseKey.isNotBlank()) " • Key: ${dev.licenseKey}" else ""}",
                                                    color = TextMuted,
                                                    fontSize = 10.sp
                                                )

                                                // Hàng 4: Các nút hành động Cấp Pro / Gỡ Pro / Tạo Key
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    // Nút tạo Key điền sẵn ID máy
                                                    TextButton(
                                                        onClick = {
                                                            genDeviceIdInput = dev.deviceId
                                                            val key = LicenseManager.generateLicenseKeyForDevice(dev.deviceId)
                                                            generatedKeyOutput = key
                                                            LicenseManager.registerAdminGeneratedKeyToCloud(dev.deviceId, key, isAccountPro = false)
                                                            adminSubTab = 0
                                                            Toast.makeText(context, "Đã tạo mã Key & ghi nhận Pro cho máy ${dev.deviceId}!", Toast.LENGTH_SHORT).show()
                                                        },
                                                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                                                    ) {
                                                        Icon(imageVector = Icons.Default.Key, contentDescription = null, tint = MagicCyan, modifier = Modifier.size(14.dp))
                                                        Spacer(modifier = Modifier.width(4.dp))
                                                        Text("Tạo Key Offline", color = MagicCyan, fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                                                    }

                                                    // Nút Cấp / Gỡ Pro trực tiếp
                                                    Button(
                                                        onClick = { targetDeviceForAction = dev },
                                                        colors = ButtonDefaults.buttonColors(
                                                            containerColor = if (isEffectivePro) MagicRose else MagicEmerald
                                                        ),
                                                        modifier = Modifier.height(34.dp),
                                                        shape = RoundedCornerShape(8.dp),
                                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                                    ) {
                                                        Icon(
                                                            imageVector = if (isEffectivePro) Icons.Default.RemoveCircleOutline else Icons.Default.FlashOn,
                                                            contentDescription = null,
                                                            tint = if (isEffectivePro) Color.White else Color(0xFF020617),
                                                            modifier = Modifier.size(14.dp)
                                                        )
                                                        Spacer(modifier = Modifier.width(4.dp))
                                                        Text(
                                                            text = if (isEffectivePro) "🚫 Gỡ Quyền Pro" else "⚡ CẤP PRO NGAY (NHẬN TIỀN)",
                                                            color = if (isEffectivePro) Color.White else Color(0xFF020617),
                                                            fontSize = 11.sp,
                                                            fontWeight = FontWeight.Black
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    // Phân trang danh sách thiết bị
                                    if (totalDevicePages > 1) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            OutlinedButton(
                                                onClick = { if (safeDevicePage > 0) deviceCurrentPage = safeDevicePage - 1 },
                                                enabled = safeDevicePage > 0,
                                                modifier = Modifier.height(34.dp),
                                                shape = RoundedCornerShape(8.dp)
                                            ) {
                                                Text("Trang trước", fontSize = 10.5.sp)
                                            }
                                            Text(
                                                text = "Trang ${safeDevicePage + 1} / $totalDevicePages",
                                                color = Color.White,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                            OutlinedButton(
                                                onClick = { if (safeDevicePage < totalDevicePages - 1) deviceCurrentPage = safeDevicePage + 1 },
                                                enabled = safeDevicePage < totalDevicePages - 1,
                                                modifier = Modifier.height(34.dp),
                                                shape = RoundedCornerShape(8.dp)
                                            ) {
                                                Text("Trang sau", fontSize = 10.5.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    2 -> {
                        // TAB 2: KHÁCH HÀNG ĐANG THANH TOÁN / HOẠT ĐỘNG GẦN ĐÂY
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = "💳 HÀNH ĐỘNG & GIAO DỊCH THANH TOÁN CỦA KHÁCH HÀNG (REAL-TIME)",
                                color = MagicAmber,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                text = "Admin có thể thấy ngay khi khách bấm 'Tôi đã chuyển khoản' hoặc mở QR thanh toán và bấm Cấp Pro ngay lập tức.",
                                color = TextSecondary,
                                fontSize = 10.5.sp
                            )

                            if (deduplicatedPaymentIntents.isEmpty()) {
                                Box(modifier = Modifier.fillMaxWidth().height(120.dp), contentAlignment = Alignment.Center) {
                                    Text(text = "Chưa có hoạt động thanh toán nào gần đây.", color = TextMuted, fontSize = 12.sp)
                                }
                            } else {
                                Column(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    deduplicatedPaymentIntents.forEach { intent ->
                                        val isPaidAction = intent.actionType == "CLICKED_I_PAID"
                                        Card(
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(10.dp),
                                            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                                            border = BorderStroke(
                                                1.2.dp,
                                                if (isPaidAction) MagicEmerald else MagicAmber.copy(alpha = 0.6f)
                                            )
                                        ) {
                                            Column(
                                                modifier = Modifier.fillMaxWidth().padding(12.dp),
                                                verticalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Text(
                                                        text = "📱 ${intent.deviceId}",
                                                        color = Color.White,
                                                        fontWeight = FontWeight.Black,
                                                        fontSize = 12.5.sp
                                                    )
                                                    Box(
                                                        modifier = Modifier
                                                            .clip(RoundedCornerShape(4.dp))
                                                            .background(
                                                                when (intent.actionType) {
                                                                    "CLICKED_I_PAID" -> MagicEmerald.copy(alpha = 0.25f)
                                                                    "OPENED_VIET_QR" -> MagicCyan.copy(alpha = 0.25f)
                                                                    else -> MagicAmber.copy(alpha = 0.25f)
                                                                }
                                                            )
                                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                                    ) {
                                                        Text(
                                                            text = when (intent.actionType) {
                                                                "CLICKED_I_PAID" -> "🔥 ĐÃ BÁO CHUYỂN KHOẢN"
                                                                "OPENED_VIET_QR" -> "👁️ ĐANG XEM MÃ QR"
                                                                "OPENED_PRO_UPGRADE_DIALOG" -> "⚡ MỞ HỘP THOẠI PRO"
                                                                else -> "📌 ${intent.actionType}"
                                                            },
                                                            color = when (intent.actionType) {
                                                                "CLICKED_I_PAID" -> MagicEmeraldLight
                                                                "OPENED_VIET_QR" -> MagicCyanLight
                                                                else -> MagicAmber
                                                            },
                                                            fontSize = 9.5.sp,
                                                            fontWeight = FontWeight.Black
                                                        )
                                                    }
                                                }

                                                Text(
                                                    text = "🕒 Thời gian: ${intent.getTimestampFormatted()}",
                                                    color = MagicCyanLight,
                                                    fontSize = 10.5.sp,
                                                    fontWeight = FontWeight.SemiBold
                                                )
                                                Text(
                                                    text = "👤 Khách: ${intent.ownerEmail.ifBlank { "Khách vãng lai" }} • Máy: ${intent.model}",
                                                    color = TextSecondary,
                                                    fontSize = 11.sp
                                                )
                                                if (intent.details.isNotBlank()) {
                                                    Text(
                                                        text = "📝 Chi tiết: ${intent.details}",
                                                        color = TextMuted,
                                                        fontSize = 10.sp
                                                    )
                                                }

                                                Row(
                                                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    TextButton(
                                                        onClick = {
                                                            genDeviceIdInput = intent.deviceId
                                                            val key = LicenseManager.generateLicenseKeyForDevice(intent.deviceId)
                                                            generatedKeyOutput = key
                                                            LicenseManager.registerAdminGeneratedKeyToCloud(intent.deviceId, key, isAccountPro = false)
                                                            LicenseManager.deletePaymentIntentsForDevice(intent.deviceId, context)
                                                            paymentIntentsList = paymentIntentsList.filter { it.deviceId != intent.deviceId && LicenseManager.normalizeDeviceIdForMatch(it.deviceId) != LicenseManager.normalizeDeviceIdForMatch(intent.deviceId) }
                                                            refreshAllAdminMetricsViaRest(showToastOnDone = false)
                                                            adminSubTab = 0
                                                            Toast.makeText(context, "Đã tạo mã Key & ghi nhận Pro cho máy ${intent.deviceId}!", Toast.LENGTH_SHORT).show()
                                                        },
                                                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp)
                                                    ) {
                                                        Icon(imageVector = Icons.Default.Key, contentDescription = null, tint = MagicCyan, modifier = Modifier.size(14.dp))
                                                        Spacer(modifier = Modifier.width(3.dp))
                                                        Text("Tạo Key", color = MagicCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                                    }

                                                    Button(
                                                        onClick = {
                                                            LicenseManager.adminGrantTierForUserOrDevice(
                                                                userId = "",
                                                                deviceId = intent.deviceId,
                                                                grantAccountPro = false,
                                                                context = context
                                                            ) { ok, msg ->
                                                                if (ok) {
                                                                    paymentIntentsList = paymentIntentsList.filter { it.deviceId != intent.deviceId && LicenseManager.normalizeDeviceIdForMatch(it.deviceId) != LicenseManager.normalizeDeviceIdForMatch(intent.deviceId) }
                                                                    refreshAllAdminMetricsViaRest(showToastOnDone = false)
                                                                }
                                                                Toast.makeText(context, if (ok) "📱 $msg" else "❌ $msg", Toast.LENGTH_LONG).show()
                                                            }
                                                        },
                                                        colors = ButtonDefaults.buttonColors(containerColor = MagicEmerald),
                                                        modifier = Modifier.weight(1f).height(34.dp),
                                                        shape = RoundedCornerShape(8.dp),
                                                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp)
                                                    ) {
                                                        Text("📱 Duyệt Pro Máy", color = Color(0xFF020617), fontWeight = FontWeight.Black, fontSize = 10.sp)
                                                    }

                                                    Button(
                                                        onClick = {
                                                            LicenseManager.adminGrantTierForUserOrDevice(
                                                                userId = "",
                                                                deviceId = intent.deviceId,
                                                                grantAccountPro = true,
                                                                context = context
                                                            ) { ok, msg ->
                                                                if (ok) {
                                                                    paymentIntentsList = paymentIntentsList.filter { it.deviceId != intent.deviceId && LicenseManager.normalizeDeviceIdForMatch(it.deviceId) != LicenseManager.normalizeDeviceIdForMatch(intent.deviceId) }
                                                                    refreshAllAdminMetricsViaRest(showToastOnDone = false)
                                                                }
                                                                Toast.makeText(context, if (ok) "👑 $msg" else "❌ $msg", Toast.LENGTH_LONG).show()
                                                            }
                                                        },
                                                        colors = ButtonDefaults.buttonColors(containerColor = MagicAmber),
                                                        modifier = Modifier.weight(1f).height(34.dp),
                                                        shape = RoundedCornerShape(8.dp),
                                                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp)
                                                    ) {
                                                        Text("👑 Duyệt Pro TK", color = Color(0xFF020617), fontWeight = FontWeight.Black, fontSize = 10.sp)
                                                    }

                                                    IconButton(
                                                        onClick = {
                                                            LicenseManager.deletePaymentIntentsForDevice(intent.deviceId, context)
                                                            paymentIntentsList = paymentIntentsList.filter { it.deviceId != intent.deviceId && LicenseManager.normalizeDeviceIdForMatch(it.deviceId) != LicenseManager.normalizeDeviceIdForMatch(intent.deviceId) }
                                                            refreshAllAdminMetricsViaRest(showToastOnDone = false)
                                                            Toast.makeText(context, "🗑️ Đã xóa đơn chờ duyệt của ${intent.deviceId}", Toast.LENGTH_SHORT).show()
                                                        },
                                                        modifier = Modifier.size(32.dp)
                                                    ) {
                                                        Icon(imageVector = Icons.Default.DeleteOutline, contentDescription = "Xóa đơn", tint = MagicRoseLight, modifier = Modifier.size(18.dp))
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    3 -> {
                        // TAB 3: QUẢN LÝ TÀI KHOẢN NGƯỜI DÙNG
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedTextField(
                                value = searchQuery,
                                onValueChange = { searchQuery = it; currentPage = 0 },
                                modifier = Modifier.fillMaxWidth(),
                                label = { Text("Tìm kiếm (Tên, Email, Device ID)...", fontSize = 11.sp) },
                                singleLine = true,
                                shape = RoundedCornerShape(8.dp),
                                leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = MagicCyan, modifier = Modifier.size(18.dp)) }
                            )

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                val adminCount = globalMergedUsers.count { it.role == "admin" }
                                val proUsersCount = globalMergedUsers.count { it.isPro }
                                val normalUsersCount = globalMergedUsers.count { !it.isPro && it.role != "admin" }
                                val filterChips = listOf(
                                    "Tất cả" to "Tất cả (${globalMergedUsers.size})",
                                    "👑 Admin" to "Admin ($adminCount)",
                                    "⚡ Pro" to "Pro ($proUsersCount)",
                                    "👤 User" to "User ($normalUsersCount)"
                                )
                                filterChips.forEach { (chipKey, chipLabel) ->
                                    val selected = selectedFilterChip == chipKey
                                    FilterChip(
                                        selected = selected,
                                        onClick = { selectedFilterChip = chipKey; currentPage = 0 },
                                        label = { Text(chipLabel, fontSize = 10.5.sp, fontWeight = FontWeight.Bold) },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = MagicCyan.copy(alpha = 0.3f),
                                            selectedLabelColor = MagicCyanLight,
                                            containerColor = MagicSurfaceDark,
                                            labelColor = TextSecondary
                                        )
                                    )
                                }
                            }

                            // Danh sách tài khoản đã được tự động gộp & hợp nhất từ bảng điều khiển tổng
                            val mergedUsers = globalMergedUsers

                            val filteredUsers = mergedUsers.filter { u ->
                                val matchesSearch = u.displayName.contains(searchQuery, true) ||
                                        u.email.contains(searchQuery, true) ||
                                        u.deviceId.contains(searchQuery, true)

                                val matchesChip = when (selectedFilterChip) {
                                    "👑 Admin" -> u.role == "admin"
                                    "⚡ Pro" -> u.isPro
                                    "👤 User" -> !u.isPro && u.role != "admin"
                                    else -> true
                                }

                                matchesSearch && matchesChip
                            }.sortedWith(
                                compareByDescending<com.example.core.auth.UserProfile> { it.lastActive?.toDate()?.time ?: 0L }
                                    .thenByDescending { it.createdAt?.toDate()?.time ?: 0L }
                            )

                            val totalPages = maxOf(1, (filteredUsers.size + pageSize - 1) / pageSize)
                            val safeCurrentPage = minOf(currentPage, totalPages - 1)
                            val pagedUsers = filteredUsers.drop(safeCurrentPage * pageSize).take(pageSize)

                            if (filteredUsers.isEmpty()) {
                                Box(modifier = Modifier.fillMaxWidth().height(100.dp), contentAlignment = Alignment.Center) {
                                    Text(text = "Không tìm thấy người dùng phù hợp bộ lọc.", color = TextMuted, fontSize = 12.sp)
                                }
                            } else {
                                Column(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    pagedUsers.forEach { u ->
                                        Card(
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(10.dp),
                                            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                                            border = BorderStroke(1.dp, if (u.isPro) MagicEmerald else MagicBorder)
                                        ) {
                                            Column(
                                                modifier = Modifier.fillMaxWidth().padding(10.dp),
                                                verticalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Text(
                                                        text = u.displayName.ifBlank { u.email.ifBlank { "Người dùng" } },
                                                        color = Color.White,
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 12.sp
                                                    )
                                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                        Box(
                                                            modifier = Modifier
                                                                .clip(RoundedCornerShape(4.dp))
                                                                .background(if (u.role == "admin") MagicPurple.copy(alpha = 0.3f) else MagicCyan.copy(alpha = 0.2f))
                                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                                        ) {
                                                            Text(
                                                                text = if (u.role == "admin") "👑 ADMIN" else "USER",
                                                                color = if (u.role == "admin") MagicPurpleLight else MagicCyanLight,
                                                                fontSize = 9.sp,
                                                                fontWeight = FontWeight.Bold
                                                            )
                                                        }
                                                        Box(
                                                            modifier = Modifier
                                                                .clip(RoundedCornerShape(4.dp))
                                                                .background(
                                                                    if (u.isAccountPro || u.proTier == "ACCOUNT_PRO") MagicAmber.copy(alpha = 0.25f)
                                                                    else if (u.isPro) MagicEmerald.copy(alpha = 0.2f)
                                                                    else TextMuted.copy(alpha = 0.2f)
                                                                )
                                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                                        ) {
                                                            Text(
                                                                text = if (u.isAccountPro || u.proTier == "ACCOUNT_PRO") "👑 PRO TÀI KHOẢN"
                                                                else if (u.isPro) "📱 PRO MÁY"
                                                                else "FREE",
                                                                color = if (u.isAccountPro || u.proTier == "ACCOUNT_PRO") MagicAmber
                                                                else if (u.isPro) MagicEmerald
                                                                else TextMuted,
                                                                fontSize = 9.sp,
                                                                fontWeight = FontWeight.Bold
                                                            )
                                                        }
                                                    }
                                                }

                                                // Hàng thời gian: Hoạt động cuối & Ngày tham gia
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Row(
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                                    ) {
                                                        Icon(imageVector = Icons.Default.AccessTime, contentDescription = null, tint = MagicCyanLight, modifier = Modifier.size(13.dp))
                                                        Text(
                                                            text = u.getLastActiveFormatted(),
                                                            color = MagicCyanLight,
                                                            fontSize = 10.5.sp,
                                                            fontWeight = FontWeight.SemiBold
                                                        )
                                                    }
                                                    Row(
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                                    ) {
                                                        Icon(imageVector = Icons.Default.CalendarToday, contentDescription = null, tint = TextMuted, modifier = Modifier.size(12.dp))
                                                        Text(
                                                            text = "Tham gia: ${u.getCreatedAtFormatted()}",
                                                            color = TextMuted,
                                                            fontSize = 10.sp
                                                        )
                                                    }
                                                }

                                                Text(
                                                    text = "Email: ${u.email.ifBlank { "Trống" }}",
                                                    color = TextSecondary,
                                                    fontSize = 11.sp
                                                )
                                                Text(
                                                    text = "Máy đang giữ phiên (1 máy/lần): ${u.activeDeviceId.ifBlank { u.deviceId.ifBlank { "Chưa rõ" } }} ${if (u.activeDeviceModel.isNotBlank()) "(${u.activeDeviceModel})" else ""}",
                                                    color = TextMuted,
                                                    fontSize = 10.sp
                                                )

                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .horizontalScroll(rememberScrollState()),
                                                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    if (u.activeDeviceId.isNotBlank() || u.isAccountPro || u.proTier == "ACCOUNT_PRO") {
                                                        TextButton(
                                                            onClick = {
                                                                LicenseManager.adminResetUserActiveDeviceSession(u.userId) { ok ->
                                                                    Toast.makeText(
                                                                        context,
                                                                        if (ok) "🔓 Đã mở khóa phiên 1 máy cho ${u.displayName.ifBlank { u.email }}!" else "❌ Lỗi khi mở khóa phiên thiết bị!",
                                                                        Toast.LENGTH_LONG
                                                                    ).show()
                                                                }
                                                            }
                                                        ) {
                                                            Text("🔓 Mở Khóa Đổi Máy", color = MagicCyanLight, fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                                                        }
                                                    }

                                                    TextButton(
                                                        onClick = {
                                                            targetUserForAction = u
                                                            pendingActionType = "pro"
                                                        }
                                                    ) {
                                                        Text(
                                                            text = if (u.isPro) "⚙️ Đổi Gói / Gỡ Pro" else "⚡ Cấp Pro (Máy / TK)",
                                                            color = if (u.isPro) MagicAmber else MagicEmerald,
                                                            fontSize = 10.5.sp,
                                                            fontWeight = FontWeight.Bold
                                                        )
                                                    }

                                                    if (u.role != "admin") {
                                                        TextButton(
                                                            onClick = {
                                                                targetUserForAction = u
                                                                pendingActionType = "admin"
                                                            }
                                                        ) {
                                                            Text("👑 Nâng Admin", color = MagicPurpleLight, fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                                if (totalPages > 1) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        OutlinedButton(
                                            onClick = { if (safeCurrentPage > 0) currentPage = safeCurrentPage - 1 },
                                            enabled = safeCurrentPage > 0,
                                            modifier = Modifier.height(36.dp)
                                        ) {
                                            Text("Trang trước", fontSize = 11.sp)
                                        }
                                        Text(
                                            text = "Trang ${safeCurrentPage + 1} / $totalPages",
                                            color = TextSecondary,
                                            fontSize = 11.sp
                                        )
                                        OutlinedButton(
                                            onClick = { if (safeCurrentPage < totalPages - 1) currentPage = safeCurrentPage + 1 },
                                            enabled = safeCurrentPage < totalPages - 1,
                                            modifier = Modifier.height(36.dp)
                                        ) {
                                            Text("Trang sau", fontSize = 11.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                    4 -> {
                        // TAB 4: YÊU CẦU KHÔI PHỤC PRO TỪ THIẾT BỊ
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                                border = BorderStroke(1.dp, MagicAmber.copy(alpha = 0.6f))
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(
                                        text = "🔄 QUẢN LÝ YÊU CẦU KHÔI PHỤC QUYỀN PRO",
                                        color = MagicAmber,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                    Text(
                                        text = "Danh sách thiết bị gửi cảnh báo mất quyền Pro (do cài lại máy / đổi thiết bị). Admin có thể đối soát và bấm 1 chạm 'Cấp lại Pro ngay' để hệ thống tự động kích hoạt lại vĩnh viễn cho thiết bị đó từ xa.",
                                        color = Color(0xFF94A3B8),
                                        fontSize = 11.sp
                                    )
                                }
                            }

                            if (proRecoveryRequestsList.isEmpty()) {
                                Box(
                                    modifier = Modifier.fillMaxWidth().padding(32.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("Chưa có yêu cầu khôi phục Pro nào.", color = TextMuted, fontSize = 12.sp)
                                }
                            } else {
                                proRecoveryRequestsList.forEach { req ->
                                    val isPending = req.status == "PENDING"
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = CardDefaults.cardColors(containerColor = MagicSurfaceCard),
                                        border = BorderStroke(1.dp, if (isPending) MagicAmber else MagicEmerald)
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(14.dp),
                                            verticalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = "📱 ${req.deviceId}",
                                                    color = Color.White,
                                                    fontSize = 12.5.sp,
                                                    fontWeight = FontWeight.Black
                                                )
                                                Box(
                                                    modifier = Modifier
                                                        .clip(RoundedCornerShape(6.dp))
                                                        .background(if (isPending) MagicAmber.copy(alpha = 0.25f) else MagicEmerald.copy(alpha = 0.25f))
                                                        .padding(horizontal = 8.dp, vertical = 3.dp)
                                                ) {
                                                    Text(
                                                        text = if (isPending) "⏳ CHỜ XỬ LÝ" else "✅ ĐÃ CẤP LẠI",
                                                        color = if (isPending) MagicAmber else MagicEmerald,
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                }
                                            }

                                            Text(text = "Thiết bị: ${req.deviceModel}", color = TextSecondary, fontSize = 11.sp)
                                            Text(text = "Người dùng: ${req.ownerName} (${req.ownerEmail})", color = TextSecondary, fontSize = 11.sp)
                                            Text(text = "Nội dung: ${req.note}", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Medium)

                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                Box(
                                                    modifier = Modifier
                                                        .clip(RoundedCornerShape(6.dp))
                                                        .background(MagicEmerald.copy(alpha = 0.2f))
                                                        .padding(horizontal = 8.dp, vertical = 3.dp)
                                                ) {
                                                    Text(text = "🛡️ ĐÃ XÁC THỰC LỊCH SỬ PRO", color = MagicEmerald, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                                }
                                            }

                                            if (isPending) {
                                                Button(
                                                    onClick = {
                                                        LicenseManager.adminRestoreProForDevice(req.deviceId, context) { success ->
                                                            if (success) {
                                                                proRecoveryRequestsList = proRecoveryRequestsList.map {
                                                                    if (LicenseManager.normalizeDeviceIdForMatch(it.deviceId) == LicenseManager.normalizeDeviceIdForMatch(req.deviceId)) {
                                                                        it.copy(status = "RESTORED")
                                                                    } else it
                                                                }
                                                                refreshAllAdminMetricsViaRest(showToastOnDone = false)
                                                                Toast.makeText(context, "Đã cấp lại quyền Pro vĩnh viễn cho thiết bị ${req.deviceId} từ xa thành công!", Toast.LENGTH_LONG).show()
                                                            } else {
                                                                Toast.makeText(context, "Lỗi khi cấp lại Pro!", Toast.LENGTH_SHORT).show()
                                                            }
                                                        }
                                                    },
                                                    colors = ButtonDefaults.buttonColors(containerColor = MagicEmerald),
                                                    shape = RoundedCornerShape(8.dp),
                                                    modifier = Modifier.fillMaxWidth()
                                                ) {
                                                    Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF020617), modifier = Modifier.size(16.dp))
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Text("⚡ Cấp Lại Pro Cho Thiết Bị Này Ngay", color = Color(0xFF020617), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    5 -> {
                        // TAB 5: TRANG LƯU TRỮ LỊCH SỬ TRÒ CHUYỆN CẤP PRO CỦA AI DÀNH CHO ADMIN
                        val grantedCount = aiProChatLogsList.count { it.proGranted }
                        val blockedCount = aiProChatLogsList.count {
                            !it.proGranted && (
                                it.eventType == "FAKE_BILL_DETECTED" ||
                                    it.eventType == "REUSED_BILL_BLOCKED" ||
                                    it.eventType == "BILL_REJECTED" ||
                                    it.eventType == "UNPAID_PRO_REQUEST_BLOCKED"
                                )
                        }
                        val inquiryCount = aiProChatLogsList.count { !it.proGranted && it.eventType == "PRO_INQUIRY" }

                        val filteredAiLogs = aiProChatLogsList.filter { log ->
                            val matchesTab = when (aiLogFilterTab) {
                                "✅ Đã Cấp Pro" -> log.proGranted
                                "🛡️ Chặn Chưa TT" -> !log.proGranted && (
                                    log.eventType == "FAKE_BILL_DETECTED" ||
                                        log.eventType == "REUSED_BILL_BLOCKED" ||
                                        log.eventType == "BILL_REJECTED" ||
                                        log.eventType == "UNPAID_PRO_REQUEST_BLOCKED"
                                    )
                                "💬 Hỏi Đáp" -> !log.proGranted && log.eventType == "PRO_INQUIRY"
                                else -> true
                            }
                            val q = aiLogSearchQuery.trim().lowercase()
                            val matchesSearch = q.isBlank() ||
                                log.deviceId.lowercase().contains(q) ||
                                log.ownerEmail.lowercase().contains(q) ||
                                log.ownerName.lowercase().contains(q) ||
                                log.userMessage.lowercase().contains(q) ||
                                log.aiReply.lowercase().contains(q) ||
                                log.bankTransCode.lowercase().contains(q) ||
                                log.forensicVerdict.lowercase().contains(q)
                            matchesTab && matchesSearch
                        }

                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                                border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.6f))
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(
                                        text = "📜 LỊCH SỬ TRÒ CHUYỆN CẤP PRO CỦA AI (HẬU KIỂM ADMIN)",
                                        color = MagicCyanLight,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                    Text(
                                        text = "Ghi lại toàn bộ các cuộc trò chuyện liên quan đến xét duyệt bill, cấp Pro, khôi phục máy quen thuộc và chặn yêu cầu xin Pro khi chưa thanh toán giữa người dùng và AI. Admin có thể xem lại từng tình huống và Cấp Pro hoặc Thu Hồi Pro ngay bằng 1 chạm.",
                                        color = TextSecondary,
                                        fontSize = 11.sp,
                                        lineHeight = 15.sp
                                    )

                                    // Thanh tìm kiếm lịch sử chat AI
                                    OutlinedTextField(
                                        value = aiLogSearchQuery,
                                        onValueChange = { aiLogSearchQuery = it },
                                        placeholder = { Text("Tìm theo Device ID, Email, nội dung chat...", fontSize = 11.sp, color = TextMuted) },
                                        singleLine = true,
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = MagicCyan,
                                            unfocusedBorderColor = MagicBorder,
                                            focusedTextColor = Color.White,
                                            unfocusedTextColor = Color.White
                                        )
                                    )

                                    // Bộ lọc nhanh theo tình huống
                                    val filterOptions = listOf(
                                        "Tất cả" to "Tất cả (${aiProChatLogsList.size})",
                                        "✅ Đã Cấp Pro" to "✅ Đã Cấp ($grantedCount)",
                                        "🛡️ Chặn Chưa TT" to "🛡️ Đã Chặn ($blockedCount)",
                                        "💬 Hỏi Đáp" to "💬 Hỏi Đáp ($inquiryCount)"
                                    )
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .horizontalScroll(rememberScrollState()),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        filterOptions.forEach { (key, label) ->
                                            val isSel = aiLogFilterTab == key
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(8.dp))
                                                    .background(if (isSel) MagicCyan.copy(alpha = 0.25f) else MagicSurfaceCard)
                                                    .border(1.dp, if (isSel) MagicCyan else MagicBorder, RoundedCornerShape(8.dp))
                                                    .clickable { aiLogFilterTab = key }
                                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                                            ) {
                                                Text(
                                                    text = label,
                                                    color = if (isSel) MagicCyanLight else TextSecondary,
                                                    fontSize = 10.5.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            if (filteredAiLogs.isEmpty()) {
                                Box(
                                    modifier = Modifier.fillMaxWidth().padding(32.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "Chưa có bản ghi trò chuyện cấp Pro nào khớp bộ lọc.",
                                        color = TextMuted,
                                        fontSize = 12.sp
                                    )
                                }
                            } else {
                                filteredAiLogs.forEach { log ->
                                    val badgeText = when {
                                        log.proGranted && log.eventType == "CLOUD_FAMILIAR_RESTORED" -> "🔄 ĐÃ KHÔI PHỤC MÁY QUEN (${log.grantedTier})"
                                        log.proGranted -> "✅ ĐÃ CẤP PRO (${log.grantedTier})"
                                        log.eventType == "FAKE_BILL_DETECTED" -> "🚨 PHÁT HIỆN BILL GIẢ / CHỈNH SỬA"
                                        log.eventType == "REUSED_BILL_BLOCKED" -> "⛔ CHẶN BILL / MÃ GD TRÙNG LẶP"
                                        log.eventType == "BILL_REJECTED" -> "🚫 TỪ CHỐI BILL KHÔNG HỢP LỆ"
                                        log.eventType == "UNPAID_PRO_REQUEST_BLOCKED" -> "🛡️ ĐÃ CHẶN (CHƯA THANH TOÁN)"
                                        else -> "💬 HỎI ĐÁP / TƯ VẤN PRO"
                                    }
                                    val badgeColor = when {
                                        log.proGranted -> MagicEmerald
                                        log.eventType == "FAKE_BILL_DETECTED" ||
                                            log.eventType == "REUSED_BILL_BLOCKED" ||
                                            log.eventType == "BILL_REJECTED" ||
                                            log.eventType == "UNPAID_PRO_REQUEST_BLOCKED" -> MagicRoseLight
                                        else -> MagicAmber
                                    }

                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = CardDefaults.cardColors(containerColor = MagicSurfaceCard),
                                        border = BorderStroke(1.dp, badgeColor.copy(alpha = 0.6f))
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(14.dp),
                                            verticalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(
                                                        text = "📱 ${log.deviceId} (${log.deviceModel})",
                                                        color = Color.White,
                                                        fontSize = 12.sp,
                                                        fontWeight = FontWeight.Black
                                                    )
                                                    Text(
                                                        text = "👤 ${log.ownerName} • ${log.ownerEmail} • 🕒 ${log.getFormattedTime()}",
                                                        color = TextSecondary,
                                                        fontSize = 10.sp
                                                    )
                                                }
                                                Box(
                                                    modifier = Modifier
                                                        .clip(RoundedCornerShape(6.dp))
                                                        .background(badgeColor.copy(alpha = 0.2f))
                                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                                ) {
                                                    Text(
                                                        text = badgeText,
                                                        color = badgeColor,
                                                        fontSize = 9.5.sp,
                                                        fontWeight = FontWeight.Black
                                                    )
                                                }
                                            }

                                            // Nội dung khách nhắn
                                            Box(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clip(RoundedCornerShape(8.dp))
                                                    .background(MagicSurfaceDark)
                                                    .border(0.5.dp, MagicBorder, RoundedCornerShape(8.dp))
                                                    .padding(10.dp)
                                            ) {
                                                Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                                    Text(
                                                        text = "👤 Người dùng nhắn:",
                                                        color = MagicCyanLight,
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                    Text(
                                                        text = log.userMessage,
                                                        color = Color.White,
                                                        fontSize = 11.5.sp,
                                                        lineHeight = 16.sp
                                                    )
                                                }
                                            }

                                            // Nội dung AI trả lời & Kết quả giám định Bill
                                            Box(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clip(RoundedCornerShape(8.dp))
                                                    .background(Color(0xFF0F172A))
                                                    .border(0.5.dp, badgeColor.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                                                    .padding(10.dp)
                                            ) {
                                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                                    Text(
                                                        text = "🤖 Phản hồi & quyết định của AI:",
                                                        color = badgeColor,
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                    Text(
                                                        text = log.aiReply,
                                                        color = Color(0xFFE2E8F0),
                                                        fontSize = 11.sp,
                                                        lineHeight = 15.5.sp
                                                    )
                                                    if (log.forensicVerdict.isNotBlank()) {
                                                        Text(
                                                            text = "🔍 Giám định Bill 5 Lớp: ${log.forensicVerdict}",
                                                            color = if (log.proGranted) MagicCyanLight else MagicAmber,
                                                            fontSize = 10.sp,
                                                            fontWeight = FontWeight.SemiBold
                                                        )
                                                    }
                                                    if (log.bankTransCode.isNotBlank() || log.billImageHash.isNotBlank()) {
                                                        Text(
                                                            text = "🏦 Mã GD: ${log.bankTransCode.ifBlank { "Không có" }} • SHA-256: ${log.billImageHash.take(14).ifBlank { "N/A" }}...",
                                                            color = TextSecondary,
                                                            fontSize = 9.5.sp
                                                        )
                                                    }
                                                    if (log.generatedKey.isNotBlank()) {
                                                        Text(
                                                            text = "🔑 Key đã cấp: ${log.generatedKey}",
                                                            color = MagicEmerald,
                                                            fontSize = 10.5.sp,
                                                            fontWeight = FontWeight.Bold
                                                        )
                                                    }
                                                }
                                            }

                                            // Hàng nút can thiệp 1 chạm cho Admin (Cấp Pro Máy / Cấp Pro TK / Thu hồi Pro / Xóa bản ghi)
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Button(
                                                    onClick = {
                                                        coroutineScope.launch {
                                                            LicenseManager.executeVerifiedProGrant(
                                                                context = context,
                                                                rawTargetDeviceId = log.deviceId,
                                                                grantAccountPro = false,
                                                                reason = "ADMIN_AUDIT_LOG_GRANT_DEVICE_PRO"
                                                            )
                                                            Toast.makeText(context, "⚡ Đã cấp Pro Thiết Bị cho ${log.deviceId}!", Toast.LENGTH_SHORT).show()
                                                        }
                                                    },
                                                    colors = ButtonDefaults.buttonColors(containerColor = MagicEmerald),
                                                    shape = RoundedCornerShape(6.dp),
                                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                                    modifier = Modifier.weight(1f).height(34.dp)
                                                ) {
                                                    Text("⚡ Cấp Pro Máy", color = Color(0xFF020617), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                                }

                                                Button(
                                                    onClick = {
                                                        coroutineScope.launch {
                                                            LicenseManager.executeVerifiedProGrant(
                                                                context = context,
                                                                rawTargetDeviceId = log.deviceId,
                                                                grantAccountPro = true,
                                                                reason = "ADMIN_AUDIT_LOG_GRANT_ACCOUNT_PRO"
                                                            )
                                                            Toast.makeText(context, "👑 Đã cấp Pro Tài Khoản cho ${log.deviceId}!", Toast.LENGTH_SHORT).show()
                                                        }
                                                    },
                                                    colors = ButtonDefaults.buttonColors(containerColor = MagicAmber),
                                                    shape = RoundedCornerShape(6.dp),
                                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                                    modifier = Modifier.weight(1f).height(34.dp)
                                                ) {
                                                    Text("👑 Cấp Pro TK", color = Color(0xFF020617), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                                }

                                                Button(
                                                    onClick = {
                                                        coroutineScope.launch {
                                                            try {
                                                                FirebaseAuthManager.toggleDeviceProStatus(log.deviceId, false)
                                                                Toast.makeText(context, "🚫 Đã THU HỒI quyền Pro của thiết bị ${log.deviceId}!", Toast.LENGTH_LONG).show()
                                                            } catch (e: Exception) {
                                                                Toast.makeText(context, "Lỗi thu hồi: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                                                            }
                                                        }
                                                    },
                                                    colors = ButtonDefaults.buttonColors(containerColor = MagicRose),
                                                    shape = RoundedCornerShape(6.dp),
                                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                                    modifier = Modifier.weight(1f).height(34.dp)
                                                ) {
                                                    Text("🚫 Thu Hồi Pro", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                                }

                                                IconButton(
                                                    onClick = {
                                                        LicenseManager.deleteAiProChatLog(log.id)
                                                        Toast.makeText(context, "Đã xóa bản ghi chat AI.", Toast.LENGTH_SHORT).show()
                                                    },
                                                    modifier = Modifier.size(34.dp)
                                                ) {
                                                    Icon(imageVector = Icons.Default.Delete, contentDescription = "Xóa bản ghi", tint = TextMuted, modifier = Modifier.size(18.dp))
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    6 -> {
                        // TAB 6: QUẢN LÝ KHO APP & DUYỆT ĐÓNG GÓP
                        val pendingApps = allStoreApps.filter { it.status == "PENDING" }
                        val approvedApps = allStoreApps.filter { it.status == "APPROVED" }
                        val rejectedApps = allStoreApps.filter { it.status == "REJECTED" }

                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                                border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.6f))
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(
                                        text = "📦 QUẢN LÝ KHO ỨNG DỤNG & DUYỆT ĐÓNG GÓP",
                                        color = MagicCyanLight,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                    Text(
                                        text = "Nơi Admin xét duyệt các ứng dụng do cộng đồng người dùng đóng góp. Ứng dụng chỉ xuất hiện trong Kho App công khai sau khi được Admin bấm Duyệt.",
                                        color = TextSecondary,
                                        fontSize = 11.sp,
                                        lineHeight = 15.sp
                                    )
                                    
                                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Text("⌛ Chờ duyệt: ${pendingApps.size}", color = MagicAmber, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        Text("✅ Đã duyệt: ${approvedApps.size}", color = MagicEmerald, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        Text("❌ Từ chối: ${rejectedApps.size}", color = MagicRoseLight, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            if (allStoreApps.isEmpty()) {
                                Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                                    Text("Chưa có ứng dụng nào trong kho để quản lý.", color = TextMuted)
                                }
                            } else {
                                allStoreApps.sortedByDescending { it.status == "PENDING" }.forEach { app ->
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = CardDefaults.cardColors(containerColor = MagicSurfaceCard),
                                        border = BorderStroke(1.dp, when(app.status) {
                                            "PENDING" -> MagicAmber.copy(alpha = 0.5f)
                                            "APPROVED" -> MagicEmerald.copy(alpha = 0.3f)
                                            else -> MagicRose.copy(alpha = 0.3f)
                                        })
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(text = app.name, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Black)
                                                    Text(text = "Đóng góp bởi: ${app.contributorEmail.ifBlank { app.author }}", color = TextSecondary, fontSize = 10.sp)
                                                }
                                                Box(
                                                    modifier = Modifier
                                                        .clip(RoundedCornerShape(6.dp))
                                                        .background(when(app.status) {
                                                            "PENDING" -> MagicAmber.copy(alpha = 0.2f)
                                                            "APPROVED" -> MagicEmerald.copy(alpha = 0.2f)
                                                            else -> MagicRose.copy(alpha = 0.2f)
                                                        })
                                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                                ) {
                                                    Text(
                                                        text = when(app.status) {
                                                            "PENDING" -> "CHỜ DUYỆT"
                                                            "APPROVED" -> "ĐÃ DUYỆT"
                                                            else -> "TỪ CHỐI"
                                                        },
                                                        color = when(app.status) {
                                                            "PENDING" -> MagicAmber
                                                            "APPROVED" -> MagicEmerald
                                                            else -> MagicRoseLight
                                                        },
                                                        fontSize = 9.sp,
                                                        fontWeight = FontWeight.Black
                                                    )
                                                }
                                            }
                                            
                                            Text(text = app.description, color = TextSecondary, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                            
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                if (app.status == "PENDING") {
                                                    Button(
                                                        onClick = {
                                                            coroutineScope.launch {
                                                                try {
                                                                    FirebaseAuthManager.updateHonorAppStatus(app.id, "APPROVED")
                                                                    Toast.makeText(context, "✅ Đã duyệt app thành công!", Toast.LENGTH_SHORT).show()
                                                                } catch (e: Exception) {
                                                                    Toast.makeText(context, "Lỗi: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                                                                }
                                                            }
                                                        },
                                                        colors = ButtonDefaults.buttonColors(containerColor = MagicEmerald),
                                                        modifier = Modifier.weight(1f).height(32.dp),
                                                        contentPadding = PaddingValues(0.dp)
                                                    ) {
                                                        Text("Duyệt App", fontSize = 10.sp, color = Color(0xFF020617), fontWeight = FontWeight.Bold)
                                                    }
                                                    
                                                    Button(
                                                        onClick = {
                                                            coroutineScope.launch {
                                                                try {
                                                                    FirebaseAuthManager.updateHonorAppStatus(app.id, "REJECTED")
                                                                    Toast.makeText(context, "❌ Đã từ chối app.", Toast.LENGTH_SHORT).show()
                                                                } catch (e: Exception) {
                                                                    Toast.makeText(context, "Lỗi: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                                                                }
                                                            }
                                                        },
                                                        colors = ButtonDefaults.buttonColors(containerColor = MagicRose),
                                                        modifier = Modifier.weight(1f).height(32.dp),
                                                        contentPadding = PaddingValues(0.dp)
                                                    ) {
                                                        Text("Từ Chối", fontSize = 10.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                                    }
                                                } else if (app.status == "APPROVED") {
                                                    Button(
                                                        onClick = {
                                                            coroutineScope.launch {
                                                                try {
                                                                    FirebaseAuthManager.updateHonorAppStatus(app.id, "REJECTED")
                                                                    Toast.makeText(context, "🚫 Đã thu hồi (từ chối) app.", Toast.LENGTH_SHORT).show()
                                                                } catch (e: Exception) {
                                                                    Toast.makeText(context, "Lỗi: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                                                                }
                                                            }
                                                        },
                                                        colors = ButtonDefaults.buttonColors(containerColor = MagicRose),
                                                        modifier = Modifier.weight(1f).height(32.dp),
                                                        contentPadding = PaddingValues(0.dp)
                                                    ) {
                                                        Text("Thu Hồi App", fontSize = 10.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                                    }
                                                }
                                                
                                                IconButton(
                                                    onClick = {
                                                        coroutineScope.launch {
                                                            try {
                                                                FirebaseAuthManager.deleteHonorApp(app.id)
                                                                Toast.makeText(context, "🗑️ Đã xóa app khỏi kho.", Toast.LENGTH_SHORT).show()
                                                            } catch (e: Exception) {
                                                                Toast.makeText(context, "Lỗi: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                                                            }
                                                        }
                                                    },
                                                    modifier = Modifier.size(32.dp)
                                                ) {
                                                    Icon(imageVector = Icons.Default.Delete, contentDescription = "Xóa", tint = TextMuted, modifier = Modifier.size(16.dp))
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    7 -> {
                        // TAB 7: NHẬT KÝ LỖI LỆNH ADB TỰ ĐỘNG TỪ NGƯỜI DÙNG (ADMIN LOGS)
                        // Cơ chế gom nhóm và khử trùng lặp 100% theo từng Ngày + Lệnh + ExitCode
                        val todayStr = remember { java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date()) }
                        val yesterdayStr = remember {
                            val cal = java.util.Calendar.getInstance()
                            cal.add(java.util.Calendar.DAY_OF_YEAR, -1)
                            java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(cal.time)
                        }

                        // Gom nhóm chống trùng lặp tuyệt đối: Mỗi lệnh lỗi độc nhất chỉ xuất hiện đúng 1 dòng
                        val deduplicatedAdbErrorLogs = remember(adminAdbErrorLogsList) {
                            adminAdbErrorLogsList.groupBy { it.dedupKey }.values.map { group ->
                                val first = group.first()
                                val totalCount = group.sumOf { it.occurrenceCount.coerceAtLeast(1L) }
                                val allDevices = (first.affectedDevices + group.map { it.commercialName.ifBlank { it.deviceModel } })
                                    .filter { it.isNotBlank() }
                                    .distinct()
                                val maxTs = group.maxOf { it.lastSeenTimestamp.coerceAtLeast(it.timestampMs) }
                                val minTs = group.minOf { if (it.firstSeenTimestamp > 0) it.firstSeenTimestamp else it.timestampMs }

                                first.copy(
                                    occurrenceCount = totalCount,
                                    affectedDevices = allDevices,
                                    lastSeenTimestamp = maxTs,
                                    timestampMs = maxTs,
                                    firstSeenTimestamp = minTs
                                )
                            }.sortedByDescending { it.timestampMs }
                        }

                        val availableDates = remember(deduplicatedAdbErrorLogs) {
                            deduplicatedAdbErrorLogs.map { it.displayDate }.filter { it.isNotBlank() && it != "Unknown" }.distinct()
                        }

                        val totalUniqueErrors = deduplicatedAdbErrorLogs.size
                        val totalOccurrencesAll = deduplicatedAdbErrorLogs.sumOf { it.occurrenceCount }
                        val todayUniqueCount = deduplicatedAdbErrorLogs.count { it.displayDate == todayStr }
                        val yesterdayUniqueCount = deduplicatedAdbErrorLogs.count { it.displayDate == yesterdayStr }

                        val shizukuErrCount = deduplicatedAdbErrorLogs.count { it.connectionMode.contains("SHIZUKU", ignoreCase = true) }
                        val wlanErrCount = deduplicatedAdbErrorLogs.count { it.connectionMode.contains("WIRELESS", ignoreCase = true) }
                        val permErrCount = deduplicatedAdbErrorLogs.count {
                            it.errorOutput.contains("Permission", ignoreCase = true) ||
                            it.errorOutput.contains("SecurityException", ignoreCase = true) ||
                            it.errorOutput.contains("not allowed", ignoreCase = true)
                        }

                        // Lọc theo ngày
                        val dateFilteredLogs = when (adbErrorDateFilter) {
                            "TODAY" -> deduplicatedAdbErrorLogs.filter { it.displayDate == todayStr }
                            "YESTERDAY" -> deduplicatedAdbErrorLogs.filter { it.displayDate == yesterdayStr }
                            "ALL" -> deduplicatedAdbErrorLogs
                            else -> deduplicatedAdbErrorLogs.filter { it.displayDate == adbErrorDateFilter }
                        }

                        // Lọc theo phương thức và từ khóa tìm kiếm
                        val filteredErrorLogs = dateFilteredLogs.filter { log ->
                            val matchesTab = when (adbErrorFilterTab) {
                                "Shizuku" -> log.connectionMode.contains("SHIZUKU", ignoreCase = true)
                                "Wireless ADB" -> log.connectionMode.contains("WIRELESS", ignoreCase = true)
                                "Lỗi Quyền" -> log.errorOutput.contains("Permission", ignoreCase = true) ||
                                        log.errorOutput.contains("SecurityException", ignoreCase = true) ||
                                        log.errorOutput.contains("not allowed", ignoreCase = true)
                                else -> true
                            }
                            val matchesSearch = adbErrorSearchQuery.isBlank() ||
                                log.command.contains(adbErrorSearchQuery, ignoreCase = true) ||
                                log.deviceModel.contains(adbErrorSearchQuery, ignoreCase = true) ||
                                log.commercialName.contains(adbErrorSearchQuery, ignoreCase = true) ||
                                log.errorOutput.contains(adbErrorSearchQuery, ignoreCase = true) ||
                                log.deviceId.contains(adbErrorSearchQuery, ignoreCase = true) ||
                                log.affectedDevices.any { it.contains(adbErrorSearchQuery, ignoreCase = true) }

                            matchesTab && matchesSearch
                        }

                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // Header Banner
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                                border = BorderStroke(1.dp, MagicRose.copy(alpha = 0.6f))
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "🚨 NHẬT KÝ LỖI LỆNH ADB TỰ ĐỘNG (KHỬ TRÙNG LẶP)",
                                            color = MagicRoseLight,
                                            fontSize = 12.5.sp,
                                            fontWeight = FontWeight.Black
                                        )
                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            IconButton(
                                                onClick = { refreshAllAdminMetricsViaRest(true) },
                                                modifier = Modifier.size(28.dp)
                                            ) {
                                                Icon(Icons.Default.Refresh, "Làm mới", tint = MagicCyan, modifier = Modifier.size(18.dp))
                                            }
                                            if (adminAdbErrorLogsList.isNotEmpty()) {
                                                IconButton(
                                                    onClick = { showClearAllErrorsDialog = true },
                                                    modifier = Modifier.size(28.dp)
                                                ) {
                                                    Icon(Icons.Default.DeleteSweep, "Xóa tất cả log", tint = MagicRose, modifier = Modifier.size(18.dp))
                                                }
                                            }
                                        }
                                    }
                                    Text(
                                        text = "Hệ thống tự động gom nhóm lỗi theo Ngày & Chữ ký câu lệnh. Dù có hàng triệu người dùng, mỗi lỗi độc nhất chỉ hiển thị 1 thẻ duy nhất kèm số lượt gặp thực tế để Admin dễ dàng xử lý.",
                                        color = TextSecondary,
                                        fontSize = 11.sp,
                                        lineHeight = 15.sp
                                    )
                                    Row(
                                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Text("Độc nhất: $totalUniqueErrors lỗi (${totalOccurrencesAll} lượt)", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        Text("Hôm nay: $todayUniqueCount", color = MagicRoseLight, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        Text("Hôm qua: $yesterdayUniqueCount", color = MagicAmber, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        Text("Shizuku: $shizukuErrCount", color = MagicCyanLight, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        Text("WLAN: $wlanErrCount", color = MagicEmeraldLight, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            // 🤖 THẺ AI PHÂN TÍCH HÀNG LOẠT VÀ TÌM CHỖ CẦN SỬA GẤP
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                                border = BorderStroke(1.2.dp, MagicPurple)
                            ) {
                                Column(
                                    modifier = Modifier.padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Icon(Icons.Default.AutoAwesome, null, tint = MagicCyanLight, modifier = Modifier.size(20.dp))
                                            Text(
                                                text = "🤖 AI PHÂN TÍCH LỖI HÀNG LOẠT & TÌM CHỖ SỬA GẤP",
                                                color = MagicCyanLight,
                                                fontSize = 11.5.sp,
                                                fontWeight = FontWeight.Black
                                            )
                                        }
                                        if (adbAiAnalysisResult != null) {
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(6.dp))
                                                    .background(MagicEmerald.copy(alpha = 0.2f))
                                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                                            ) {
                                                Text(
                                                    text = "ĐÃ CÓ BÁO CÁO",
                                                    color = MagicEmeraldLight,
                                                    fontSize = 9.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        }
                                    }
                                    Text(
                                        text = "AI sẽ quét toàn bộ các lệnh ADB bị lỗi, đối chiếu với kiến trúc MagicOS/Android và lập tức đưa ra danh sách những chỗ cần sửa gấp kèm mã code khắc phục ngay cho Admin.",
                                        color = TextSecondary,
                                        fontSize = 10.5.sp,
                                        lineHeight = 15.sp
                                    )
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Button(
                                            onClick = {
                                                if (deduplicatedAdbErrorLogs.isEmpty()) {
                                                    Toast.makeText(context, "🎉 Không có lỗi ADB nào để phân tích!", Toast.LENGTH_SHORT).show()
                                                } else {
                                                    isAnalyzingAdbErrors = true
                                                    showAdbAiAnalysisDialog = true
                                                    adbAiAnalysisResult = null
                                                    coroutineScope.launch(Dispatchers.IO) {
                                                        val report = LicenseManager.analyzeAdbErrorLogsWithAi(context, deduplicatedAdbErrorLogs)
                                                        withContext(Dispatchers.Main) {
                                                            adbAiAnalysisResult = report
                                                            isAnalyzingAdbErrors = false
                                                        }
                                                    }
                                                }
                                            },
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = MagicPurple,
                                                contentColor = Color.White
                                            ),
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.weight(1f).height(40.dp)
                                        ) {
                                            if (isAnalyzingAdbErrors) {
                                                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("AI Đang phân tích...", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            } else {
                                                Icon(Icons.Default.AutoAwesome, null, tint = MagicCyanLight, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("Bắt đầu AI phân tích (${deduplicatedAdbErrorLogs.size} lỗi)", fontSize = 11.sp, fontWeight = FontWeight.Black)
                                            }
                                        }
                                        if (adbAiAnalysisResult != null) {
                                            Button(
                                                onClick = { showAdbAiAnalysisDialog = true },
                                                colors = ButtonDefaults.buttonColors(
                                                    containerColor = MagicSurfaceCard,
                                                    contentColor = MagicCyanLight
                                                ),
                                                border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.5f)),
                                                shape = RoundedCornerShape(8.dp),
                                                modifier = Modifier.height(40.dp)
                                            ) {
                                                Icon(Icons.Default.Visibility, null, tint = MagicCyanLight, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("Xem lại báo cáo", fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                            }

                            // Bộ Lọc Nhanh Theo Ngày (Date Quick Filters)
                            Row(
                                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                FilterChip(
                                    selected = adbErrorDateFilter == "ALL",
                                    onClick = { adbErrorDateFilter = "ALL" },
                                    label = { Text("📅 Tất cả ngày ($totalUniqueErrors)", fontSize = 11.sp, fontWeight = if (adbErrorDateFilter == "ALL") FontWeight.Bold else FontWeight.Normal) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = MagicCyan.copy(alpha = 0.25f),
                                        selectedLabelColor = MagicCyanLight,
                                        containerColor = MagicSurfaceDark,
                                        labelColor = TextSecondary
                                    ),
                                    border = FilterChipDefaults.filterChipBorder(
                                        enabled = true,
                                        selected = adbErrorDateFilter == "ALL",
                                        borderColor = if (adbErrorDateFilter == "ALL") MagicCyan else MagicBorder,
                                        selectedBorderColor = MagicCyan
                                    )
                                )

                                FilterChip(
                                    selected = adbErrorDateFilter == "TODAY",
                                    onClick = { adbErrorDateFilter = "TODAY" },
                                    label = { Text("⚡ Hôm nay ($todayUniqueCount)", fontSize = 11.sp, fontWeight = if (adbErrorDateFilter == "TODAY") FontWeight.Bold else FontWeight.Normal) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = MagicRose.copy(alpha = 0.25f),
                                        selectedLabelColor = MagicRoseLight,
                                        containerColor = MagicSurfaceDark,
                                        labelColor = TextSecondary
                                    ),
                                    border = FilterChipDefaults.filterChipBorder(
                                        enabled = true,
                                        selected = adbErrorDateFilter == "TODAY",
                                        borderColor = if (adbErrorDateFilter == "TODAY") MagicRose else MagicBorder,
                                        selectedBorderColor = MagicRose
                                    )
                                )

                                FilterChip(
                                    selected = adbErrorDateFilter == "YESTERDAY",
                                    onClick = { adbErrorDateFilter = "YESTERDAY" },
                                    label = { Text("⏳ Hôm qua ($yesterdayUniqueCount)", fontSize = 11.sp, fontWeight = if (adbErrorDateFilter == "YESTERDAY") FontWeight.Bold else FontWeight.Normal) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = MagicAmber.copy(alpha = 0.25f),
                                        selectedLabelColor = MagicAmber,
                                        containerColor = MagicSurfaceDark,
                                        labelColor = TextSecondary
                                    ),
                                    border = FilterChipDefaults.filterChipBorder(
                                        enabled = true,
                                        selected = adbErrorDateFilter == "YESTERDAY",
                                        borderColor = if (adbErrorDateFilter == "YESTERDAY") MagicAmber else MagicBorder,
                                        selectedBorderColor = MagicAmber
                                    )
                                )

                                availableDates.filter { it != todayStr && it != yesterdayStr }.forEach { dateKey ->
                                    val countForDate = deduplicatedAdbErrorLogs.count { it.displayDate == dateKey }
                                    val isSel = adbErrorDateFilter == dateKey
                                    val formattedDate = try {
                                        val parts = dateKey.split("-")
                                        if (parts.size == 3) "${parts[2]}/${parts[1]}" else dateKey
                                    } catch (_: Throwable) { dateKey }

                                    FilterChip(
                                        selected = isSel,
                                        onClick = { adbErrorDateFilter = dateKey },
                                        label = { Text("$formattedDate ($countForDate)", fontSize = 11.sp, fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal) },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = MagicCyan.copy(alpha = 0.25f),
                                            selectedLabelColor = MagicCyanLight,
                                            containerColor = MagicSurfaceDark,
                                            labelColor = TextSecondary
                                        ),
                                        border = FilterChipDefaults.filterChipBorder(
                                            enabled = true,
                                            selected = isSel,
                                            borderColor = if (isSel) MagicCyan else MagicBorder,
                                            selectedBorderColor = MagicCyan
                                        )
                                    )
                                }
                            }

                            // Search Box
                            OutlinedTextField(
                                value = adbErrorSearchQuery,
                                onValueChange = { adbErrorSearchQuery = it },
                                placeholder = { Text("Tìm theo lệnh, mã máy, lỗi hoặc Device ID...", color = TextMuted, fontSize = 11.5.sp) },
                                leadingIcon = { Icon(Icons.Default.Search, null, tint = MagicCyan, modifier = Modifier.size(18.dp)) },
                                trailingIcon = {
                                    if (adbErrorSearchQuery.isNotBlank()) {
                                        IconButton(onClick = { adbErrorSearchQuery = "" }) {
                                            Icon(Icons.Default.Close, null, tint = TextMuted, modifier = Modifier.size(16.dp))
                                        }
                                    }
                                },
                                modifier = Modifier.fillMaxWidth().height(48.dp),
                                shape = RoundedCornerShape(10.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = MagicSurfaceDark,
                                    unfocusedContainerColor = MagicSurfaceDark,
                                    focusedBorderColor = MagicCyan,
                                    unfocusedBorderColor = MagicBorder,
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                ),
                                singleLine = true
                            )

                            // Quick Filter Chips theo Loại kết nối
                            Row(
                                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                listOf(
                                    "Tất cả" to "Tất cả (${dateFilteredLogs.size})",
                                    "Shizuku" to "Shizuku ($shizukuErrCount)",
                                    "Wireless ADB" to "WLAN ($wlanErrCount)",
                                    "Lỗi Quyền" to "Lỗi Quyền ($permErrCount)"
                                ).forEach { (tabKey, label) ->
                                    val isSelected = adbErrorFilterTab == tabKey
                                    FilterChip(
                                        selected = isSelected,
                                        onClick = { adbErrorFilterTab = tabKey },
                                        label = { Text(label, fontSize = 11.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = MagicRose.copy(alpha = 0.25f),
                                            selectedLabelColor = MagicRoseLight,
                                            containerColor = MagicSurfaceDark,
                                            labelColor = TextSecondary
                                        ),
                                        border = FilterChipDefaults.filterChipBorder(
                                            enabled = true,
                                            selected = isSelected,
                                            borderColor = if (isSelected) MagicRose else MagicBorder,
                                            selectedBorderColor = MagicRose
                                        )
                                    )
                                }
                            }

                            // Error Cards List
                            if (filteredErrorLogs.isEmpty()) {
                                Box(
                                    modifier = Modifier.fillMaxWidth().padding(32.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = if (adminAdbErrorLogsList.isEmpty()) "🎉 Hệ thống hoàn hảo: Chưa có lệnh ADB nào bị lỗi đỏ!" else "Không tìm thấy log lỗi nào phù hợp bộ lọc.",
                                        color = if (adminAdbErrorLogsList.isEmpty()) MagicEmeraldLight else TextMuted,
                                        fontSize = 12.sp,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            } else {
                                val clipboardManager = LocalClipboardManager.current
                                val groupedByDate = remember(filteredErrorLogs, adbErrorDateFilter) {
                                    if (adbErrorDateFilter == "ALL") {
                                        filteredErrorLogs.groupBy { it.displayDate }
                                    } else {
                                        mapOf(adbErrorDateFilter to filteredErrorLogs)
                                    }
                                }

                                groupedByDate.forEach { (dateKey, logsInDate) ->
                                    // Header phân tách từng ngày rõ ràng
                                    val dateHeaderTitle = when (dateKey) {
                                        todayStr -> "⚡ HÔM NAY (${formatDateVn(dateKey)})"
                                        yesterdayStr -> "⏳ HÔM QUA (${formatDateVn(dateKey)})"
                                        "TODAY" -> "⚡ HÔM NAY (${formatDateVn(todayStr)})"
                                        "YESTERDAY" -> "⏳ HÔM QUA (${formatDateVn(yesterdayStr)})"
                                        else -> "📅 NGÀY ${formatDateVn(dateKey)}"
                                    }

                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(MagicSurfaceDark)
                                            .border(1.dp, MagicCyan.copy(alpha = 0.25f), RoundedCornerShape(8.dp))
                                            .padding(horizontal = 10.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = dateHeaderTitle,
                                            color = MagicCyanLight,
                                            fontSize = 11.5.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "${logsInDate.size} lỗi độc nhất • ${logsInDate.sumOf { it.occurrenceCount }} lượt",
                                            color = TextMuted,
                                            fontSize = 10.5.sp
                                        )
                                    }

                                    logsInDate.forEach { logItem ->
                                        Card(
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(12.dp),
                                            colors = CardDefaults.cardColors(containerColor = MagicSurfaceCard),
                                            border = BorderStroke(1.dp, MagicRose.copy(alpha = 0.4f))
                                        ) {
                                            Column(
                                                modifier = Modifier.padding(12.dp),
                                                verticalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                // Row 1: Occurrence Badge + Mode badge + Delete button
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    val isHighFreq = logItem.occurrenceCount >= 10
                                                    val countColor = if (isHighFreq) MagicRose else MagicAmber
                                                    Row(
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                                    ) {
                                                        Text(
                                                            text = if (isHighFreq) "🔥 ĐÃ GẶP ${logItem.occurrenceCount} LẦN" else "⚠️ Gặp ${logItem.occurrenceCount} lần",
                                                            color = countColor,
                                                            fontSize = 10.5.sp,
                                                            fontWeight = FontWeight.Black,
                                                            modifier = Modifier
                                                                .clip(RoundedCornerShape(4.dp))
                                                                .background(countColor.copy(alpha = 0.18f))
                                                                .border(1.dp, countColor.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                                                                .padding(horizontal = 7.dp, vertical = 3.dp)
                                                        )

                                                        val modeColor = if (logItem.connectionMode.contains("SHIZUKU", ignoreCase = true)) MagicCyan else MagicEmerald
                                                        Text(
                                                            text = logItem.connectionMode.ifBlank { "ADB" },
                                                            color = modeColor,
                                                            fontSize = 9.5.sp,
                                                            fontWeight = FontWeight.Black,
                                                            modifier = Modifier
                                                                .clip(RoundedCornerShape(4.dp))
                                                                .background(modeColor.copy(alpha = 0.15f))
                                                                .padding(horizontal = 6.dp, vertical = 3.dp)
                                                        )
                                                    }

                                                    IconButton(
                                                        onClick = {
                                                            LicenseManager.deleteAdminAdbErrorLog(logItem.id)
                                                            adminAdbErrorLogsList = adminAdbErrorLogsList.filter { it.dedupKey != logItem.dedupKey }
                                                            Toast.makeText(context, "Đã xóa bản ghi lỗi!", Toast.LENGTH_SHORT).show()
                                                        },
                                                        modifier = Modifier.size(24.dp)
                                                    ) {
                                                        Icon(Icons.Default.Delete, "Xóa", tint = TextMuted, modifier = Modifier.size(16.dp))
                                                    }
                                                }

                                                // Row 2: Device Models & Hardware Information
                                                val devicesStr = if (logItem.affectedDevices.isNotEmpty()) {
                                                    logItem.affectedDevices.joinToString(", ")
                                                } else {
                                                    "${logItem.commercialName.ifBlank { logItem.deviceModel }} (${logItem.deviceModel})"
                                                }

                                                Column(modifier = Modifier.fillMaxWidth()) {
                                                    Text(
                                                        text = "📱 Dòng máy: $devicesStr",
                                                        color = Color.White,
                                                        fontSize = 12.sp,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                    Text(
                                                        text = "Chip: ${logItem.soc.ifBlank { "N/A" }} • ${logItem.magicOsVersion} (Android ${logItem.androidVersion}) • Nguồn: ${logItem.featureSource}",
                                                        color = TextSecondary,
                                                        fontSize = 10.5.sp
                                                    )
                                                }

                                                // Row 3: Timestamps
                                                val lastSeenStr = if (logItem.lastSeenTimestamp > 0) {
                                                    java.text.SimpleDateFormat("HH:mm:ss dd/MM/yyyy", java.util.Locale.getDefault()).format(java.util.Date(logItem.lastSeenTimestamp))
                                                } else if (logItem.timestampMs > 0) {
                                                    java.text.SimpleDateFormat("HH:mm:ss dd/MM/yyyy", java.util.Locale.getDefault()).format(java.util.Date(logItem.timestampMs))
                                                } else "Vừa xong"

                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween
                                                ) {
                                                    Text(
                                                        text = "Gần nhất: $lastSeenStr",
                                                        color = TextMuted,
                                                        fontSize = 10.sp
                                                    )
                                                    if (logItem.userEmail.isNotBlank()) {
                                                        Text(
                                                            text = logItem.userEmail,
                                                            color = MagicCyan.copy(alpha = 0.7f),
                                                            fontSize = 10.sp
                                                        )
                                                    }
                                                }

                                                // Command Terminal Box
                                                Column(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .clip(RoundedCornerShape(8.dp))
                                                        .background(Color(0xFF030712))
                                                        .border(1.dp, MagicCyan.copy(alpha = 0.35f), RoundedCornerShape(8.dp))
                                                        .padding(8.dp),
                                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                                ) {
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Text(
                                                            text = "$ ${logItem.command}",
                                                            color = MagicCyanLight,
                                                            fontSize = 11.sp,
                                                            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                                                            fontWeight = FontWeight.Bold,
                                                            modifier = Modifier.weight(1f)
                                                        )
                                                        IconButton(
                                                            onClick = {
                                                                clipboardManager.setText(androidx.compose.ui.text.AnnotatedString(logItem.command))
                                                                Toast.makeText(context, "Đã copy câu lệnh!", Toast.LENGTH_SHORT).show()
                                                            },
                                                            modifier = Modifier.size(22.dp)
                                                        ) {
                                                            Icon(Icons.Default.ContentCopy, "Copy lệnh", tint = MagicCyan, modifier = Modifier.size(14.dp))
                                                        }
                                                    }
                                                }

                                                // Error Output Box
                                                Column(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .clip(RoundedCornerShape(8.dp))
                                                        .background(Color(0xFF220509))
                                                        .border(1.dp, MagicRose.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                                        .padding(8.dp),
                                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                                ) {
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Text(
                                                            text = "❌ Exit code: ${logItem.exitCode}",
                                                            color = MagicRose,
                                                            fontSize = 10.sp,
                                                            fontWeight = FontWeight.Black
                                                        )
                                                        IconButton(
                                                            onClick = {
                                                                val fullText = """
Lệnh: ${logItem.command}
Lần gặp: ${logItem.occurrenceCount}
Máy bị lỗi: $devicesStr
Chip: ${logItem.soc}
OS: ${logItem.magicOsVersion} (Android ${logItem.androidVersion})
ExitCode: ${logItem.exitCode}
Lỗi: ${logItem.errorOutput}
""".trimIndent()
                                                                clipboardManager.setText(androidx.compose.ui.text.AnnotatedString(fullText))
                                                                Toast.makeText(context, "Đã copy chi tiết lỗi!", Toast.LENGTH_SHORT).show()
                                                            },
                                                            modifier = Modifier.size(22.dp)
                                                        ) {
                                                            Icon(Icons.Default.ContentCopy, "Copy lỗi", tint = MagicRoseLight, modifier = Modifier.size(14.dp))
                                                        }
                                                    }
                                                    Text(
                                                        text = logItem.errorOutput.ifBlank { "Lệnh không phản hồi hoặc trả về mã lỗi." },
                                                        color = MagicRoseLight,
                                                        fontSize = 10.5.sp,
                                                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                                                        lineHeight = 14.sp
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Dialog xác nhận xóa tất cả log lỗi ADB
    if (showClearAllErrorsDialog) {
        AlertDialog(
            onDismissRequest = { showClearAllErrorsDialog = false },
            containerColor = MagicSurfaceDark,
            title = {
                Text("Xóa Toàn Bộ Nhật Ký Lỗi ADB?", color = MagicRoseLight, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            },
            text = {
                Text("Hành động này sẽ xóa vĩnh viễn toàn bộ ${adminAdbErrorLogsList.size} bản ghi lỗi ADB trên trang quản trị đám mây.", color = TextSecondary, fontSize = 12.sp)
            },
            confirmButton = {
                Button(
                    onClick = {
                        LicenseManager.clearAllAdminAdbErrorLogs(context)
                        adminAdbErrorLogsList = emptyList()
                        showClearAllErrorsDialog = false
                        Toast.makeText(context, "Đã xóa sạch toàn bộ log lỗi!", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MagicRose)
                ) {
                    Text("Xóa Tất Cả", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearAllErrorsDialog = false }) {
                    Text("Hủy", color = TextSecondary, fontSize = 12.sp)
                }
            }
        )
    }

    // Dialog Báo Cáo AI Chẩn Đoán Lỗi ADB Hàng Loạt
    if (showAdbAiAnalysisDialog) {
        val clipboardManager = androidx.compose.ui.platform.LocalClipboardManager.current
        AlertDialog(
            onDismissRequest = { if (!isAnalyzingAdbErrors) showAdbAiAnalysisDialog = false },
            containerColor = MagicSurfaceDark,
            shape = RoundedCornerShape(16.dp),
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.AutoAwesome, null, tint = MagicCyan, modifier = Modifier.size(22.dp))
                        Column {
                            Text("BÁO CÁO AI CHẨN ĐOÁN LỖI ADB", color = MagicCyanLight, fontWeight = FontWeight.Black, fontSize = 13.sp)
                            Text("${adminAdbErrorLogsList.size} bản ghi • Đang phân tích", color = TextSecondary, fontSize = 9.5.sp)
                        }
                    }
                    IconButton(
                        onClick = { showAdbAiAnalysisDialog = false },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(Icons.Default.Close, null, tint = TextSecondary, modifier = Modifier.size(18.dp))
                    }
                }
            },
            text = {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 480.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    if (isAnalyzingAdbErrors) {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 36.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            CircularProgressIndicator(color = MagicCyan, modifier = Modifier.size(38.dp), strokeWidth = 3.dp)
                            Text(
                                "AI đang tổng hợp và phân tích toàn diện hàng loạt lỗi ADB...\nĐang bóc tách nguyên nhân và tìm mã lệnh cần sửa gấp.",
                                color = Color.White,
                                fontSize = 11.5.sp,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                lineHeight = 16.sp
                            )
                        }
                    } else {
                        val report = adbAiAnalysisResult ?: "Chưa có nội dung phân tích."
                        Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                text = report,
                                color = Color(0xFFF1F5F9),
                                fontSize = 11.5.sp,
                                lineHeight = 17.sp
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (!isAnalyzingAdbErrors && !adbAiAnalysisResult.isNullOrBlank()) {
                        Button(
                            onClick = {
                                adbAiAnalysisResult?.let {
                                    clipboardManager.setText(androidx.compose.ui.text.AnnotatedString(it))
                                    Toast.makeText(context, "📋 Đã sao chép toàn bộ báo cáo phân tích AI!", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MagicCyan),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.ContentCopy, null, tint = Color(0xFF020617), modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Sao Chép", color = Color(0xFF020617), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }

                        Button(
                            onClick = {
                                isAnalyzingAdbErrors = true
                                adbAiAnalysisResult = null
                                coroutineScope.launch(Dispatchers.IO) {
                                    val res = LicenseManager.analyzeAdbErrorLogsWithAi(context, adminAdbErrorLogsList)
                                    withContext(Dispatchers.Main) {
                                        adbAiAnalysisResult = res
                                        isAnalyzingAdbErrors = false
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MagicSurfaceCard),
                            border = BorderStroke(1.dp, MagicBorder),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Refresh, null, tint = Color.White, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Phân Tích Lại", color = Color.White, fontSize = 11.sp)
                        }
                    }

                    Button(
                        onClick = { showAdbAiAnalysisDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = MagicSurfaceCard),
                        border = BorderStroke(1.dp, MagicBorder),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Đóng", color = Color.White, fontSize = 11.sp)
                    }
                }
            }
        )
    }

    // Confirmation Dialog for Device Pro Toggle / Tier Selection
    targetDeviceForAction?.let { dev ->
        val isEffectivePro = dev.isPro && !dev.revokedByAdmin
        AlertDialog(
            onDismissRequest = { targetDeviceForAction = null },
            containerColor = MagicSurfaceDark,
            title = {
                Text(
                    text = if (isEffectivePro) "Quản lý / Gỡ quyền Pro thiết bị" else "Chọn gói Pro cấp cho thiết bị",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "• Device ID: ${dev.deviceId}\n• Máy: ${dev.model}\n• Chủ sở hữu: ${dev.ownerEmail.ifBlank { "Khách vãng lai" }}",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                    Button(
                        onClick = {
                            LicenseManager.adminGrantTierForUserOrDevice(
                                userId = dev.ownerUid,
                                deviceId = dev.deviceId,
                                grantAccountPro = false
                            ) { ok, msg ->
                                Toast.makeText(context, if (ok) "📱 $msg" else "❌ $msg", Toast.LENGTH_LONG).show()
                                targetDeviceForAction = null
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MagicEmerald),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("📱 Cấp Pro Thiết Bị (Gắn Theo Máy)", color = Color(0xFF020617), fontWeight = FontWeight.Black, fontSize = 11.5.sp)
                    }
                    Button(
                        onClick = {
                            LicenseManager.adminGrantTierForUserOrDevice(
                                userId = dev.ownerUid,
                                deviceId = dev.deviceId,
                                grantAccountPro = true
                            ) { ok, msg ->
                                Toast.makeText(context, if (ok) "👑 $msg" else "❌ $msg", Toast.LENGTH_LONG).show()
                                targetDeviceForAction = null
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MagicAmber),
                        modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 40.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                    ) {
                        Text("👑 Cấp / Nâng Lên Pro Tài Khoản", color = Color(0xFF020617), fontWeight = FontWeight.Black, fontSize = 11.5.sp, textAlign = TextAlign.Center)
                    }
                    if (isEffectivePro) {
                        Button(
                            onClick = {
                                coroutineScope.launch {
                                    try {
                                        FirebaseAuthManager.toggleDeviceProStatus(dev.deviceId, false)
                                        Toast.makeText(context, "🚫 Đã thu hồi quyền Pro của thiết bị ${dev.deviceId}!", Toast.LENGTH_SHORT).show()
                                    } catch (e: Exception) {
                                        Toast.makeText(context, "Lỗi: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                                    } finally {
                                        targetDeviceForAction = null
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MagicRose),
                            modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 40.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                        ) {
                            Text("🚫 Thu Hồi (Gỡ) Quyền Pro", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.5.sp, textAlign = TextAlign.Center)
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { targetDeviceForAction = null }) {
                    Text("Đóng", color = TextSecondary, fontSize = 12.sp)
                }
            }
        )
    }

    // Confirmation Dialog for User Account
    targetUserForAction?.let { u ->
        if (pendingActionType != null) {
            val isProAction = pendingActionType == "pro"
            AlertDialog(
                onDismissRequest = { targetUserForAction = null; pendingActionType = null },
                containerColor = MagicSurfaceDark,
                title = {
                    Text(
                        text = if (isProAction) "Quản lý gói Pro cho Tài khoản" else "Xác nhận nâng cấp lên Admin",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                },
                text = {
                    if (isProAction) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                text = "• Tên: ${u.displayName}\n• Email: ${u.email.ifBlank { "Không có" }}\n• Device ID: ${u.deviceId.ifBlank { "Không rõ" }}",
                                color = TextSecondary,
                                fontSize = 12.sp
                            )
                            Button(
                                onClick = {
                                    LicenseManager.adminGrantTierForUserOrDevice(
                                        userId = u.userId,
                                        deviceId = u.activeDeviceId.ifBlank { u.deviceId },
                                        grantAccountPro = false
                                    ) { ok, msg ->
                                        Toast.makeText(context, if (ok) "📱 $msg" else "❌ $msg", Toast.LENGTH_LONG).show()
                                        targetUserForAction = null
                                        pendingActionType = null
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = MagicEmerald),
                                modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 40.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                            ) {
                                Text("📱 Cấp Pro Thiết Bị", color = Color(0xFF020617), fontWeight = FontWeight.Black, fontSize = 11.5.sp, textAlign = TextAlign.Center)
                            }
                            Button(
                                onClick = {
                                    LicenseManager.adminGrantTierForUserOrDevice(
                                        userId = u.userId,
                                        deviceId = u.activeDeviceId.ifBlank { u.deviceId },
                                        grantAccountPro = true
                                    ) { ok, msg ->
                                        Toast.makeText(context, if (ok) "👑 $msg" else "❌ $msg", Toast.LENGTH_LONG).show()
                                        targetUserForAction = null
                                        pendingActionType = null
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = MagicAmber),
                                modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 40.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                            ) {
                                Text("👑 Cấp / Nâng Lên Pro Tài Khoản (Đổi Máy)", color = Color(0xFF020617), fontWeight = FontWeight.Black, fontSize = 11.5.sp, textAlign = TextAlign.Center)
                            }
                            if (u.isPro) {
                                Button(
                                    onClick = {
                                        coroutineScope.launch {
                                            try {
                                                FirebaseAuthManager.toggleUserProStatus(u.userId, false, u.deviceId)
                                                Toast.makeText(context, "🚫 Đã gỡ trạng thái Pro của tài khoản & thiết bị!", Toast.LENGTH_SHORT).show()
                                            } catch (e: Exception) {
                                                Toast.makeText(context, "Lỗi: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                                            } finally {
                                                targetUserForAction = null
                                                pendingActionType = null
                                            }
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = MagicRose),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("🚫 Gỡ Quyền Pro Tài Khoản Này", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
                                }
                            }
                        }
                    } else {
                        Text(
                            text = "Bạn có chắc chắn muốn nâng cấp tài khoản:\n• Tên: ${u.displayName}\n• Email: ${u.email.ifBlank { "Không có" }}\nlên quyền Quản trị viên (Admin)?",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                },
                confirmButton = {
                    if (!isProAction) {
                        Button(
                            onClick = {
                                coroutineScope.launch {
                                    try {
                                        FirebaseAuthManager.upgradeUserToAdmin(u.userId)
                                        Toast.makeText(context, "Đã nâng cấp ${u.displayName} lên Admin thành công!", Toast.LENGTH_SHORT).show()
                                    } catch (e: Exception) {
                                        Toast.makeText(context, "Lỗi: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                                    } finally {
                                        targetUserForAction = null
                                        pendingActionType = null
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MagicCyan)
                        ) {
                            Text("Xác Nhận Nâng Admin", color = Color(0xFF020617), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                },
                dismissButton = {
                    TextButton(onClick = { targetUserForAction = null; pendingActionType = null }) {
                        Text("Đóng", color = TextSecondary, fontSize = 12.sp)
                    }
                }
            )
        }
    }
  }
}
}

fun formatDateVn(dateStr: String): String {
    return try {
        val parts = dateStr.split("-")
        if (parts.size == 3) "${parts[2]}/${parts[1]}/${parts[0]}" else dateStr
    } catch (_: Throwable) { dateStr }
}
