package com.example.ui.components



import androidx.compose.foundation.background

import androidx.compose.foundation.border

import androidx.compose.foundation.clickable

import androidx.compose.foundation.layout.Arrangement

import androidx.compose.foundation.layout.Box

import androidx.compose.foundation.layout.defaultMinSize

import androidx.compose.foundation.layout.Column

import androidx.compose.foundation.layout.Row

import androidx.compose.foundation.layout.Spacer

import androidx.compose.foundation.layout.fillMaxWidth

import androidx.compose.foundation.layout.height

import androidx.compose.foundation.layout.padding

import androidx.compose.foundation.layout.size

import androidx.compose.foundation.layout.width

import androidx.compose.foundation.shape.RoundedCornerShape

import androidx.compose.material.icons.Icons

import androidx.compose.material.icons.filled.Block

import androidx.compose.material.icons.filled.Check

import androidx.compose.material.icons.filled.DoNotTouch

import androidx.compose.material.icons.filled.GraphicEq

import androidx.compose.material.icons.filled.PlayArrow

import androidx.compose.material.icons.filled.Refresh

import androidx.compose.material.icons.filled.Shield

import androidx.compose.material.icons.filled.Search

import androidx.compose.material.icons.filled.SmartToy

import androidx.compose.material.icons.filled.Visibility

import androidx.compose.material.icons.filled.VisibilityOff

import androidx.compose.material3.Button

import androidx.compose.material3.ButtonDefaults

import androidx.compose.material3.Card

import androidx.compose.material3.Switch

import androidx.compose.material3.SwitchDefaults

import androidx.compose.ui.draw.scale

import androidx.compose.material3.CardDefaults

import androidx.compose.material3.Icon

import androidx.compose.material3.OutlinedButton

import androidx.compose.material3.Text

import androidx.compose.runtime.Composable

import androidx.compose.runtime.getValue

import androidx.compose.runtime.setValue

import androidx.compose.runtime.mutableStateOf

import androidx.compose.runtime.remember

import androidx.compose.ui.Alignment

import androidx.compose.ui.Modifier

import androidx.compose.ui.draw.clip

import androidx.compose.ui.graphics.Brush

import androidx.compose.ui.graphics.Color

import androidx.compose.ui.platform.testTag

import androidx.compose.ui.text.font.FontWeight

import androidx.compose.ui.text.style.TextAlign

import androidx.compose.ui.unit.dp

import androidx.compose.ui.unit.sp

import com.example.data.DeviceInfo

import com.example.data.TuneStatus

import android.content.Context

import android.content.Intent

import android.net.Uri

import android.os.Build

import android.os.PowerManager

import android.provider.Settings

import androidx.compose.material.icons.filled.Assistant

import androidx.compose.material.icons.filled.Mic

import androidx.compose.material.icons.filled.Translate

import androidx.compose.material.icons.automirrored.filled.OpenInNew

import androidx.compose.material.icons.filled.Language

import androidx.compose.material.icons.filled.BatteryChargingFull

import androidx.compose.material.icons.filled.BatteryAlert

import androidx.compose.material.icons.filled.Layers

import androidx.compose.material.icons.filled.FlashOn

import androidx.compose.material.icons.filled.Code

import androidx.compose.material.icons.filled.Speed

import androidx.compose.material.icons.automirrored.filled.VolumeUp

import androidx.compose.material.icons.filled.NotificationsActive

import androidx.compose.material.icons.filled.Settings

import androidx.compose.material.icons.filled.RecordVoiceOver

import androidx.compose.material.icons.filled.Download

import androidx.compose.material.icons.filled.Lock

import android.widget.Toast

import androidx.activity.compose.rememberLauncherForActivityResult

import androidx.activity.result.contract.ActivityResultContracts

import androidx.compose.runtime.rememberCoroutineScope

import kotlinx.coroutines.launch

import com.example.core.installer.WlanFastApkInstaller

import com.example.core.license.LicenseManager

import androidx.compose.ui.platform.LocalContext

import com.example.ui.theme.*



@Composable

fun TuneScreen(

    deviceInfo: DeviceInfo,

    tuneStatus: TuneStatus = TuneStatus(),

    isBusy: Boolean,

    onApplyMaxSettings: () -> Unit,

    onApplySmartBatterySaver: () -> Unit = {},

    onEnhanceGestureSensitivity: () -> Unit = {},

    onSetRefreshRate: (Int) -> Unit,

    onSetAnimationScale: (Float) -> Unit,

    onDisableYoyoWake: () -> Unit = {},

    onRemapNavBarToGoogleAssistant: () -> Unit = {},

    onModCircleToSearch: () -> Unit = {},

    onModGeminiVoice: () -> Unit = {},

    onSetDefaultAssistant: () -> Unit = {},

    onTestTriggerNavAssistant: () -> Unit = {},
    onTestCircleToSearch: () -> Unit = {},

    onRestoreYoyoOriginal: () -> Unit = {},

    onToggleNavigationBarPill: (Boolean) -> Unit = {},

    onHideNavigationBar: () -> Unit,

    onReplaceHonorSearch: (Boolean) -> Unit = {},

    onBlockAppMarketUpdates: () -> Unit = {},

    onUnblockAppMarketUpdates: () -> Unit = {},

    onApplyThermalCooling: () -> Unit = {},

    isAutoCoolingEnabled: Boolean = true,

    onToggleAutoCooling: (Boolean) -> Unit = {},

    onFixAudio: () -> Unit,

    onFixAndroidAuto: () -> Unit = {},

    onFixGps: () -> Unit = {},

    onRefreshSatellites: () -> Unit = {},

    onSetFontLarge: (Boolean) -> Unit,

    onSetDarkModeOled: (Boolean) -> Unit,

    onUnlockScreenshot: () -> Unit,

    onEnableAdBlocker: () -> Unit,

    onDisableAdBlocker: () -> Unit,

    onEnableStealthDevMode: () -> Unit = {},

    onRestoreDevModeVisibility: () -> Unit = {},

    onFixMagicOSSystemUpdate: () -> Unit = {},

    onUnlockRestrictedStorage: () -> Unit = {},

    onExtractAndSyncRestrictedData: () -> Unit = {},

    onCleanRestrictedCaches: () -> Unit = {},

    onToggleDeepPrivacySensor: (String, Boolean) -> Unit = { _, _ -> },

    onRunAutomationMacro: (String) -> Unit = {},

    onOpenAppsManagerTab: () -> Unit = {},

    onOpenPlayStore: (String) -> Unit = {},

    onRequestOverlaySettingIntent: () -> Unit = {},

    onRefreshDeviceInfo: () -> Unit = {},

    onNavigateToUniversalFix: () -> Unit = {}

) {

    val context = LocalContext.current

    val coroutineScope = rememberCoroutineScope()

    var isInstallingApk by remember { mutableStateOf(false) }

    var installStatusText by remember { mutableStateOf("") }



    val apkPickerLauncher = rememberLauncherForActivityResult(

        contract = ActivityResultContracts.GetContent()

    ) { uri: Uri? ->

        if (uri != null) {

            coroutineScope.launch {

                isInstallingApk = true

                installStatusText = "⏳ Đang chuẩn bị tệp APK..."

                val result = WlanFastApkInstaller.installApkFromUri(context, uri) { progress ->

                    installStatusText = progress

                }

                isInstallingApk = false

                when (result) {

                    is WlanFastApkInstaller.InstallResult.Success -> {

                        Toast.makeText(context, "🎉 Cài đặt siêu tốc thành công: ${result.appLabel}!\nỨng dụng đã sẵn sàng trên màn hình chính.", Toast.LENGTH_LONG).show()

                    }

                    is WlanFastApkInstaller.InstallResult.FallbackStandardInstall -> {

                        Toast.makeText(context, "Đã mở trình cài đặt APK chuẩn của hệ thống.", Toast.LENGTH_SHORT).show()

                    }

                    is WlanFastApkInstaller.InstallResult.Error -> {

                        Toast.makeText(context, "❌ Lỗi: ${result.error}", Toast.LENGTH_LONG).show()

                    }

                }

            }

        }

    }


    var isGroup1Expanded by remember { mutableStateOf(true) }
    var isGroup2Expanded by remember { mutableStateOf(true) }
    var isGroup3Expanded by remember { mutableStateOf(false) }
    var isGroup4Expanded by remember { mutableStateOf(false) }

    val powerManager = remember(context) { context.getSystemService(Context.POWER_SERVICE) as? PowerManager }

    val isBatteryOptimized = remember(powerManager, context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && powerManager != null) {
            !powerManager.isIgnoringBatteryOptimizations(context.packageName)
        } else false
    }

    val hasOverlay = remember(context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(context)
        } else true
    }



    Column(

        modifier = Modifier

            .fillMaxWidth()

            .padding(horizontal = 12.dp, vertical = 8.dp),

        verticalArrangement = Arrangement.spacedBy(8.dp)

    ) {

        // Ô #21: THẺ KÍCH HOẠT BẢN PRO VĨNH VIỄN

        ProLicenseCard(cardNumberBadge = "Ô #21")




        // ==========================================
        // NHÓM 1: TRỢ LÝ ẢO AI & PHÍM ĐIỀU HƯỚNG
        // ==========================================
        CollapsibleSectionHeader(
            title = "TRỢ LÝ ẢO AI & PHÍM ĐIỀU HƯỚNG",
            subtitle = "Google Khoanh tròn tìm kiếm, Gemini Live AI & Cử chỉ",
            badgeText = "NHÓM 1 (Ô #22, #29)",
            badgeColor = MagicCyan,
            icon = androidx.compose.material.icons.Icons.Default.SmartToy,
            isExpanded = isGroup1Expanded,
            onToggle = { isGroup1Expanded = !isGroup1Expanded }
        ) {
        // Ô #22: GỌI GOOGLE SEARCH CIRCLE (KHOANH TRÒN TÌM KIẾM) BẰNG PHÍM ĐIỀU HƯỚNG

        Card(

            modifier = Modifier

                .fillMaxWidth()

                .testTag("circle_to_search_dedicated_card"),

            shape = RoundedCornerShape(16.dp),

            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),

            border = androidx.compose.foundation.BorderStroke(

                1.5.dp,

                if (tuneStatus.isCircleToSearchEnabled) MagicEmerald else MagicCyan

            )

        ) {

            Column(

                modifier = Modifier

                    .fillMaxWidth()

                    .padding(12.dp),

                verticalArrangement = Arrangement.spacedBy(8.dp)

            ) {

                Row(

                    modifier = Modifier.fillMaxWidth(),

                    horizontalArrangement = Arrangement.SpaceBetween,

                    verticalAlignment = Alignment.CenterVertically

                ) {

                    Row(

                        verticalAlignment = Alignment.CenterVertically,

                        horizontalArrangement = Arrangement.spacedBy(8.dp),

                        modifier = Modifier.weight(1f)

                    ) {

                        Box(

                            modifier = Modifier

                                .clip(RoundedCornerShape(6.dp))

                                .background(MagicCyan.copy(alpha = 0.22f))

                                .border(1.dp, MagicCyan.copy(alpha = 0.6f), RoundedCornerShape(6.dp))

                                .padding(horizontal = 7.dp, vertical = 2.dp)

                        ) {

                            Text(

                                text = "Ô #22",

                                color = MagicCyanLight,

                                fontSize = 10.5.sp,

                                fontWeight = FontWeight.Black

                            )

                        }

                        Text(

                            text = "⭕ Ép Bật Khoanh Tròn Tìm Kiếm & Giọng Nói Google Trên Honor",

                            modifier = Modifier.weight(1f),

                            color = Color.White,

                            fontSize = 13.5.sp,

                            fontWeight = FontWeight.Black,

                            softWrap = true

                        )

                    }

                    Box(

                        modifier = Modifier

                            .clip(RoundedCornerShape(6.dp))

                            .background(if (tuneStatus.isCircleToSearchEnabled) MagicEmerald.copy(alpha = 0.22f) else MagicCyan.copy(alpha = 0.18f))

                            .padding(horizontal = 7.dp, vertical = 3.dp)

                    ) {

                        Text(

                            text = if (tuneStatus.isCircleToSearchEnabled) "✓ ĐANG BẬT" else "CIRCLE + VOICE",

                            color = if (tuneStatus.isCircleToSearchEnabled) MagicEmeraldLight else MagicCyanLight,

                            fontSize = 9.5.sp,

                            fontWeight = FontWeight.Black

                        )

                    }

                }



                Text(

                    text = "Ép bật tính năng Khoanh Tròn Tìm Kiếm (Circle to Search) vốn bị khóa trên máy Honor: Nhấn giữ thanh điều hướng đáy để đóng băng màn hình ➔ Dùng ngón tay khoanh tròn bất kỳ vật thể/chữ nào để tìm trên Google Lens, hoặc bấm nút Micro để mở thẳng Google Tìm Kiếm Giọng Nói!",

                    color = TextSecondary,

                    fontSize = 11.5.sp,

                    lineHeight = 16.sp

                )



                Row(

                    modifier = Modifier.fillMaxWidth(),

                    horizontalArrangement = Arrangement.spacedBy(8.dp)

                ) {

                    Button(

                        onClick = {

                            if (tuneStatus.isGoogleAppInstalled) {

                                onModCircleToSearch()

                            } else {

                                onOpenPlayStore("com.google.android.googlequicksearchbox")

                            }

                        },

                        modifier = Modifier

                            .weight(1.3f)

                            .defaultMinSize(minHeight = 56.dp)

                            .testTag("enable_circle_to_search_nav_button"),

                        shape = RoundedCornerShape(12.dp),

                        colors = ButtonDefaults.buttonColors(

                            containerColor = if (tuneStatus.isCircleToSearchEnabled) MagicEmerald else MagicCyan,

                            contentColor = Color(0xFF020617)

                        )

                    ) {

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {

                            Text(

                                text = if (tuneStatus.isCircleToSearchEnabled) {

                                    "✓ ĐÃ BẬT ÉP KHOANH TRÒN & VOICE GOOGLE"

                                } else if (tuneStatus.isGoogleAppInstalled) {

                                    "⭕ BẬT ÉP KHOANH TRÒN & VOICE GOOGLE"

                                } else {

                                    "📥 TẢI APP GOOGLE ĐỂ BẬT KHOANH TRÒN"

                                },

                                fontSize = 11.5.sp,

                                fontWeight = FontWeight.Black,

                                textAlign = TextAlign.Center

                            )

                            Text(

                                text = "Nhấn giữ thanh đáy để Khoanh tròn màn hình / Giọng nói",

                                fontSize = 9.5.sp,

                                fontWeight = FontWeight.Bold,

                                color = Color(0xFF020617).copy(alpha = 0.85f),

                                textAlign = TextAlign.Center

                            )

                        }

                    }



                    Button(

                        onClick = onTestCircleToSearch,

                        modifier = Modifier

                            .weight(0.85f)

                            .defaultMinSize(minHeight = 56.dp)

                            .testTag("test_circle_to_search_now_button"),

                        shape = RoundedCornerShape(12.dp),

                        colors = ButtonDefaults.buttonColors(

                            containerColor = MagicSurfaceCard,

                            contentColor = MagicCyanLight

                        ),

                        border = androidx.compose.foundation.BorderStroke(1.dp, MagicCyan.copy(alpha = 0.6f))

                    ) {

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {

                            Text(

                                text = "⚡ KHOANH THỬ",

                                fontSize = 11.sp,

                                fontWeight = FontWeight.Black,

                                textAlign = TextAlign.Center

                            )

                            Text(

                                text = "Khoanh tròn ngay",

                                fontSize = 9.5.sp,

                                color = TextSecondary,

                                textAlign = TextAlign.Center

                            )

                        }

                    }

                }

            }

        }




        Card(

            modifier = Modifier.fillMaxWidth(),

            shape = RoundedCornerShape(16.dp),

            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),

            border = androidx.compose.foundation.BorderStroke(

                1.dp,

                if (tuneStatus.isYoyoWakeDisabled || tuneStatus.isGoogleAssistantWakeEnabled) MagicCyan else MagicBorder

            )

        ) {

            Column(

                modifier = Modifier

                    .fillMaxWidth()

                    .padding(10.dp),

                verticalArrangement = Arrangement.spacedBy(6.dp)

            ) {

                Row(

                    modifier = Modifier.fillMaxWidth(),

                    horizontalArrangement = Arrangement.SpaceBetween,

                    verticalAlignment = Alignment.CenterVertically

                ) {

                    Row(

                        verticalAlignment = Alignment.CenterVertically,

                        horizontalArrangement = Arrangement.spacedBy(6.dp),

                        modifier = Modifier.weight(1f)

                    ) {

                        Box(

                            modifier = Modifier

                                .clip(RoundedCornerShape(6.dp))

                                .background(MagicCyan.copy(alpha = 0.22f))

                                .border(1.dp, MagicCyan.copy(alpha = 0.6f), RoundedCornerShape(6.dp))

                                .padding(horizontal = 7.dp, vertical = 2.dp)

                        ) {

                            Text(

                                text = "Ô #29",

                                color = MagicCyanLight,

                                fontSize = 10.sp,

                                fontWeight = FontWeight.Black

                            )

                        }

                        Icon(

                            imageVector = Icons.Default.SmartToy,

                            contentDescription = null,

                            tint = MagicCyan,

                            modifier = Modifier.size(18.dp)

                        )

                        Text(

                            text = "Mod Phím Điều Hướng Gọi Search Circle / Gemini",

                            modifier = Modifier.weight(1f),

                            color = Color.White,

                            fontSize = 13.5.sp,

                            fontWeight = FontWeight.Bold,

                            softWrap = true

                        )

                    }

                    Box(

                        modifier = Modifier

                            .clip(RoundedCornerShape(6.dp))

                            .background(if (tuneStatus.isGoogleAssistantWakeEnabled) MagicEmerald.copy(alpha = 0.22f) else MagicSurfaceCard)

                            .padding(horizontal = 7.dp, vertical = 3.dp)

                    ) {

                        Text(

                            text = when {

                                tuneStatus.isCircleToSearchEnabled -> "ĐANG BẬT: KHOANH TRÒN TÌM KIẾM"

                                tuneStatus.isGeminiVoiceEnabled -> "ĐANG BẬT: GEMINI VOICE AI"

                                tuneStatus.isGoogleAssistantWakeEnabled -> "GOOGLE / GEMINI"

                                tuneStatus.isYoyoWakeDisabled -> "ĐÃ TẮT YOYO"

                                else -> "ĐANG GỌI YOYO"

                            },

                            color = if (tuneStatus.isGoogleAssistantWakeEnabled || tuneStatus.isCircleToSearchEnabled || tuneStatus.isGeminiVoiceEnabled) MagicCyanLight else if (tuneStatus.isYoyoWakeDisabled) MagicEmerald else MagicAmber,

                            fontSize = 9.sp,

                            fontWeight = FontWeight.Black

                        )

                    }

                }



                Text(

                    text = "🌟 Mod Phím Điều Hướng Gọi YOYO Thành Google Khoanh Tròn Để Tìm Kiếm Hoặc Gọi Gemini Voice Trò Chuyện Với AI: Tự động khóa quyền WRITE_SECURE_SETTINGS & RoleManager hệ thống, đảm bảo KỂ CẢ KHI TẮT GỠ LỖI tính năng Mod điều hướng vẫn hoạt động bền vững 100% và không bao giờ bị quay về YOYO!",

                    color = TextSecondary,

                    fontSize = 11.sp,

                    lineHeight = 16.sp,

                    softWrap = true

                )



                // Bảng Chẩn Đoán Trạng Thái Google App, Gemini App & Cầu Nối Cảm Ứng Đáy

                Card(

                    modifier = Modifier.fillMaxWidth(),

                    shape = RoundedCornerShape(12.dp),

                    colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),

                    border = androidx.compose.foundation.BorderStroke(1.dp, MagicSurfaceCard)

                ) {

                    Column(

                        modifier = Modifier.padding(10.dp),

                        verticalArrangement = Arrangement.spacedBy(6.dp)

                    ) {

                        Text(

                            text = "📊 TRẠNG THÁI ỨNG DỤNG & CẦU NỐI CẢM ỨNG ĐÁY",

                            color = Color.White,

                            fontSize = 11.sp,

                            fontWeight = FontWeight.Black

                        )



                        Row(

                            modifier = Modifier.fillMaxWidth(),

                            horizontalArrangement = Arrangement.SpaceBetween,

                            verticalAlignment = Alignment.CenterVertically

                        ) {

                            Text(text = "1. App Google (Khoanh Tròn/Lens):", color = TextSecondary, fontSize = 11.sp)

                            if (tuneStatus.isGoogleAppInstalled) {

                                Text(text = "✓ Đã cài", color = MagicEmerald, fontSize = 11.sp, fontWeight = FontWeight.Bold)

                            } else {

                                Text(

                                    text = "⚠️ Chưa cài (Bấm tải)",

                                    color = MagicAmber,

                                    fontSize = 11.sp,

                                    fontWeight = FontWeight.Bold,

                                    modifier = Modifier.clickable { onOpenPlayStore("com.google.android.googlequicksearchbox") }

                                )

                            }

                        }



                        Row(

                            modifier = Modifier.fillMaxWidth(),

                            horizontalArrangement = Arrangement.SpaceBetween,

                            verticalAlignment = Alignment.CenterVertically

                        ) {

                            Text(text = "2. App Google Gemini AI:", color = TextSecondary, fontSize = 11.sp)

                            if (tuneStatus.isGeminiAppInstalled) {

                                Text(text = "✓ Đã cài", color = MagicEmerald, fontSize = 11.sp, fontWeight = FontWeight.Bold)

                            } else {

                                Text(

                                    text = "⚠️ Chưa cài (Bấm tải)",

                                    color = MagicAmber,

                                    fontSize = 11.sp,

                                    fontWeight = FontWeight.Bold,

                                    modifier = Modifier.clickable { onOpenPlayStore("com.google.android.apps.bard") }

                                )

                            }

                        }



                        Row(

                            modifier = Modifier.fillMaxWidth(),

                            horizontalArrangement = Arrangement.SpaceBetween,

                            verticalAlignment = Alignment.CenterVertically

                        ) {

                            Text(text = "3. Quyền Cửa Sổ Nổi Cầu Nối Thanh Đáy:", color = TextSecondary, fontSize = 11.sp)

                            if (tuneStatus.isOverlayPermissionGranted) {

                                Text(text = "✓ Đã bật", color = MagicEmerald, fontSize = 11.sp, fontWeight = FontWeight.Bold)

                            } else {

                                Text(

                                    text = "⚠️ Chưa cấp (Bấm cấp quyền)",

                                    color = MagicRoseLight,

                                    fontSize = 11.sp,

                                    fontWeight = FontWeight.Bold,

                                    modifier = Modifier.clickable { onRequestOverlaySettingIntent() }

                                )

                            }

                        }

                    }

                }



                // NÚT 1: MOD PHÍM ĐIỀU HƯỚNG -> GỌI GOOGLE SEARCH CIRCLE (KHOANH TRÒN TÌM KIẾM)

                Button(

                    onClick = onModCircleToSearch,

                    enabled = true,

                    modifier = Modifier

                        .fillMaxWidth()

                        .defaultMinSize(minHeight = 68.dp)

                        .testTag("mod_nav_circle_to_search_button"),

                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 8.dp),

                    shape = RoundedCornerShape(12.dp),

                    colors = ButtonDefaults.buttonColors(

                        containerColor = if (tuneStatus.isCircleToSearchEnabled) MagicEmerald else MagicCyan,

                        contentColor = Color(0xFF020617)

                    )

                ) {

                    Column(

                        horizontalAlignment = Alignment.CenterHorizontally,

                        verticalArrangement = Arrangement.Center

                    ) {

                        Text(

                            text = "⭕ MOD PHÍM ĐIỀU HƯỚNG: ÉP BẬT KHOANH TRÒN TÌM KIẾM & VOICE GOOGLE",

                            fontSize = 12.sp,

                            lineHeight = 15.sp,

                            fontWeight = FontWeight.Black,

                            textAlign = TextAlign.Center

                        )

                        Spacer(modifier = Modifier.height(2.dp))

                        Text(

                            text = if (tuneStatus.isCircleToSearchEnabled) "✓ Đang bật Ép Khoanh Tròn Tìm Kiếm (Google Lens) + Tìm Kiếm Giọng Nói Google" else "Nhấn giữ thanh điều hướng đáy ➔ Khoanh tròn vùng bất kỳ trên màn hình để tìm Google",

                            fontSize = 10.5.sp,

                            color = Color(0xFF020617).copy(alpha = 0.85f),

                            fontWeight = FontWeight.Bold,

                            textAlign = TextAlign.Center

                        )

                    }

                }



                // NÚT 2: MOD PHÍM ĐIỀU HƯỚNG YOYO -> GỌI GEMINI VOICE AI ĐỂ TRÒ CHUYỆN VỚI AI

                // Ẩn nút đối với tài khoản chưa Pro và chưa thêm API Key, hướng dẫn sang Ô #14 thêm key

                val canUseGemini2 = remember(context) { LicenseManager.canAccessGeminiLive(context) }

                if (canUseGemini2) {

                    Button(

                        onClick = onModGeminiVoice,

                        enabled = true,

                        modifier = Modifier

                            .fillMaxWidth()

                            .defaultMinSize(minHeight = 76.dp)

                            .testTag("mod_nav_gemini_voice_button"),

                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 10.dp),

                        shape = RoundedCornerShape(12.dp),

                        colors = ButtonDefaults.buttonColors(

                            containerColor = if (tuneStatus.isGeminiVoiceEnabled) MagicEmerald else MagicPurpleLight,

                            contentColor = Color(0xFF020617)

                        )

                    ) {

                        Row(

                            verticalAlignment = Alignment.CenterVertically,

                            horizontalArrangement = Arrangement.Center

                        ) {

                            Icon(imageVector = Icons.Default.Mic, contentDescription = null, modifier = Modifier.size(24.dp))

                            Spacer(modifier = Modifier.width(10.dp))

                            Column(

                                horizontalAlignment = Alignment.CenterHorizontally,

                                verticalArrangement = Arrangement.Center

                            ) {

                                Text(

                                    text = if (tuneStatus.isGeminiVoiceEnabled)

                                        "🎙️ ĐANG BẬT GEMINI VOICE NỔI (BẤM ĐỂ TẮT & NGẮT MICRO 24/24)"

                                    else

                                        "BẬT MOD PHÍM ĐÁY: GỌI GEMINI VOICE NỔI TRÊN MÀN HÌNH",

                                    fontSize = 13.sp,

                                    lineHeight = 16.sp,

                                    fontWeight = FontWeight.Black,

                                    textAlign = TextAlign.Center

                                )

                                Spacer(modifier = Modifier.height(2.dp))

                                Text(

                                    text = if (tuneStatus.isGeminiVoiceEnabled)

                                        "✓ Đang bật Trò chuyện Gemini nổi ngay trên màn hình & Tự trả quyền Micro cho Gemini. Bấm vào đây nếu muốn TẮT để tiết kiệm pin!"

                                    else

                                        "Nhấn giữ thanh điều hướng đáy ➔ Hiện hộp thoại nói chuyện Gemini nổi ngay trên màn hình (Không chuyển vào trong app)",

                                    fontSize = 11.sp,

                                    color = Color(0xFF020617).copy(alpha = 0.85f),

                                    fontWeight = FontWeight.Bold,

                                    textAlign = TextAlign.Center

                                )

                            }

                        }

                    }

                } else {

                    Card(

                        modifier = Modifier.fillMaxWidth(),

                        shape = RoundedCornerShape(12.dp),

                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1B4B)),

                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF818CF8).copy(alpha = 0.45f))

                    ) {

                        Column(

                            modifier = Modifier.fillMaxWidth().padding(12.dp),

                            verticalArrangement = Arrangement.spacedBy(6.dp)

                        ) {

                            Row(

                                verticalAlignment = Alignment.CenterVertically,

                                horizontalArrangement = Arrangement.spacedBy(8.dp)

                            ) {

                                Icon(imageVector = Icons.Default.Shield, contentDescription = null, tint = Color(0xFFA5B4FC), modifier = Modifier.size(20.dp))

                                Text("MỞ KHÓA GỌI GEMINI VOICE BẰNG API KEY", color = Color(0xFFA5B4FC), fontSize = 12.sp, fontWeight = FontWeight.Black)

                            }

                            Text(

                                "Tính năng Gemini Voice yêu cầu Bản PRO hoặc Gemini API Key cá nhân. Hãy vào tab '1. Thiết Lập' -> Ô #14 dán mã API Key miễn phí của bạn từ aistudio.google.com để nút gọi Gemini tự động mở ra!",

                                color = Color.White.copy(alpha = 0.85f),

                                fontSize = 11.sp,

                                lineHeight = 15.sp

                            )

                        }

                    }

                }



                // Ghi chú giải thích cơ chế gỡ triệt để YOYO Agent & Thanh điều hướng ảo & Tính Vĩnh Viễn

                Box(

                    modifier = Modifier

                        .fillMaxWidth()

                        .clip(RoundedCornerShape(8.dp))

                        .background(MagicEmerald.copy(alpha = 0.12f))

                        .border(1.dp, MagicEmerald.copy(alpha = 0.35f), RoundedCornerShape(8.dp))

                        .padding(horizontal = 10.dp, vertical = 6.dp)

                ) {

                    Text(

                        text = "🛡️ Cơ Chế Gemini Voice Nổi & Tự Ẩn Nút Điều Hướng Ảo v2.7.8:\n• Gọi Gemini Voice ➔ Hiện hộp thoại giọng nói nổi ngay trên màn hình hiện tại (Không chuyển hướng vào bên trong app Gemini).\n• Tự nhường Micro 100% ➔ Giải phóng Micro tức thì (<5ms) ngay khi biểu tượng trò chuyện Gemini xuất hiện; hỗ trợ Bật/Tắt để tiết kiệm pin 24/24.\n• Màn hình Khoanh Tròn ➔ Tự ẩn & thu nhỏ thụt nút điều hướng ảo xuống dưới để không bao giờ ấn nhầm khi bấm hàng chức năng đáy.\n",

                        color = MagicEmeraldLight,

                        fontSize = 10.5.sp,

                        lineHeight = 15.sp,

                        fontWeight = FontWeight.SemiBold

                    )

                }



                // TÙY CHỌN THAO TÁC KÍCH HOẠT THEO SỞ THÍCH (Nhấn giữ thanh điều hướng VS. Vuốt từ cạnh góc dưới màn hình)
                // THANH ĐIỀU HƯỚNG TÁCH ĐÔI THÔNG MINH (2 NÚT RIÊNG BIỆT)
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                    border = androidx.compose.foundation.BorderStroke(1.2.dp, MagicCyan.copy(alpha = 0.6f))
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.GraphicEq,
                                contentDescription = null,
                                tint = MagicCyan,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "PHÍM ĐIỀU HƯỚNG TÁCH ĐÔI (DUAL ASSISTANT NAV PILL)",
                                color = Color.White,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Black
                            )
                        }

                        Text(
                            text = "Đã bỏ hoàn toàn các cảm biến vuốt góc và vuốt cạnh tránh chạm nhầm. Thanh điều hướng đáy nay được tách đôi thành 2 nút độc lập:",
                            color = TextSecondary,
                            fontSize = 10.sp,
                            lineHeight = 14.5.sp
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Nửa trái
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MagicCyan.copy(alpha = 0.18f))
                                    .border(1.dp, MagicCyan.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                    .padding(vertical = 10.dp, horizontal = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = "🔍 Nửa Trái",
                                        color = MagicCyanLight,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Google Khoanh Tròn",
                                        color = Color.White,
                                        fontSize = 9.sp,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }

                            // Nửa phải
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFF8B5CF6).copy(alpha = 0.18f))
                                    .border(1.dp, Color(0xFF8B5CF6).copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                    .padding(vertical = 10.dp, horizontal = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = "🎙️ Nửa Phải",
                                        color = Color(0xFFA78BFA),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Gemini Live Voice AI",
                                        color = Color.White,
                                        fontSize = 9.sp,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }
                    }
                }



                // Nút ĐẶT MAGICTUNE LÀM TRỢ LÝ ẢO MẶC ĐỊNH CHO HONOR (GỌI GEMINI CẢ KHI KHÓA MÀN HÌNH)

                Button(

                    onClick = onSetDefaultAssistant,

                    modifier = Modifier

                        .fillMaxWidth()

                        .defaultMinSize(minHeight = 52.dp)

                        .testTag("set_default_assistant_button"),

                    shape = RoundedCornerShape(12.dp),

                    colors = ButtonDefaults.buttonColors(

                        containerColor = MagicSurfaceCard,

                        contentColor = Color.White

                    ),

                    border = androidx.compose.foundation.BorderStroke(

                        1.5.dp,

                        Brush.horizontalGradient(listOf(MagicPurple, MagicCyan))

                    )

                ) {

                    Row(

                        verticalAlignment = Alignment.CenterVertically,

                        horizontalArrangement = Arrangement.spacedBy(8.dp),

                        modifier = Modifier.fillMaxWidth()

                    ) {

                        Icon(

                            imageVector = Icons.Default.Assistant,

                            contentDescription = null,

                            tint = MagicCyanLight,

                            modifier = Modifier.size(22.dp)

                        )

                        Column {

                            Text(

                                text = "🌟 ĐẶT MAGICTUNE LÀM TRỢ LÝ ẢO MẶC ĐỊNH",

                                fontSize = 11.5.sp,

                                fontWeight = FontWeight.Black

                            )

                            Text(

                                text = "Chạm thông báo màn hình khóa hoặc vuốt phím điều hướng để gọi ngay Gemini Live",

                                fontSize = 9.5.sp,

                                color = MagicEmeraldLight,

                                fontWeight = FontWeight.SemiBold

                            )

                        }

                    }

                }



                // Hàng nút Gọi Thử Khoanh Tròn / Gemini Ngay & Khôi phục YOYO Gốc

                Row(

                    modifier = Modifier.fillMaxWidth(),

                    horizontalArrangement = Arrangement.spacedBy(8.dp)

                ) {

                    Button(

                        onClick = onTestTriggerNavAssistant,

                        modifier = Modifier

                            .weight(1f)

                            .defaultMinSize(minHeight = 68.dp)

                            .testTag("test_trigger_nav_assistant_button"),

                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 8.dp),

                        shape = RoundedCornerShape(10.dp),

                        colors = ButtonDefaults.buttonColors(

                            containerColor = MagicSurfaceCard,

                            contentColor = MagicCyanLight

                        ),

                        border = androidx.compose.foundation.BorderStroke(1.dp, MagicCyan.copy(alpha = 0.55f))

                    ) {

                        Text(

                            text = "⚡ GỌI THỬ KHOANH TRÒN /\nGEMINI NGAY LẬP TỨC",

                            fontSize = 10.5.sp,

                            lineHeight = 14.sp,

                            fontWeight = FontWeight.Black,

                            textAlign = TextAlign.Center

                        )

                    }



                    OutlinedButton(

                        onClick = onRestoreYoyoOriginal,

                        modifier = Modifier

                            .weight(1f)

                            .defaultMinSize(minHeight = 68.dp)

                            .testTag("restore_yoyo_original_button"),

                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 8.dp),

                        shape = RoundedCornerShape(10.dp),

                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MagicAmber),

                        border = androidx.compose.foundation.BorderStroke(1.dp, MagicAmber.copy(alpha = 0.55f))

                    ) {

                        Text(

                            text = "🔄 KHÔI PHỤC LẠI\nYOYO AGENT GỐC",

                            fontSize = 10.5.sp,

                            lineHeight = 14.sp,

                            fontWeight = FontWeight.Black,

                            textAlign = TextAlign.Center

                        )

                    }

                }



                // 2 Nút Trợ lý Phụ Trợ: Mở Cài đặt Trợ lý mặc định của Honor + Tải Gesture Search

                Row(

                    modifier = Modifier.fillMaxWidth(),

                    horizontalArrangement = Arrangement.spacedBy(8.dp)

                ) {

                    // Nút mở cài đặt Trợ lý mặc định của Android/Honor (Double height for comfortable 2-line display)

                    Button(

                        onClick = {

                            try {

                                val intent = Intent(Settings.ACTION_VOICE_INPUT_SETTINGS)

                                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK

                                context.startActivity(intent)

                            } catch (_: Exception) {

                                try {

                                    val intent = Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS)

                                    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK

                                    context.startActivity(intent)

                                } catch (_: Exception) {}

                            }

                        },

                        modifier = Modifier

                            .weight(1f)

                            .defaultMinSize(minHeight = 78.dp),

                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 8.dp),

                        shape = RoundedCornerShape(12.dp),

                        colors = ButtonDefaults.buttonColors(

                            containerColor = MagicSurfaceCard,

                            contentColor = MagicEmeraldLight

                        ),

                        border = androidx.compose.foundation.BorderStroke(1.dp, MagicEmerald.copy(alpha = 0.45f))

                    ) {

                        Column(

                            horizontalAlignment = Alignment.CenterHorizontally,

                            verticalArrangement = Arrangement.Center

                        ) {

                            Icon(imageVector = Icons.Default.Assistant, contentDescription = null, modifier = Modifier.size(18.dp))

                            Spacer(modifier = Modifier.height(3.dp))

                            Text(

                                text = "MỞ CÀI ĐẶT TRỢ LÝ SỐ",

                                fontSize = 11.sp,

                                fontWeight = FontWeight.Black,

                                textAlign = TextAlign.Center,

                                softWrap = true

                            )

                            Spacer(modifier = Modifier.height(2.dp))

                            Text(

                                text = "(Chọn Google / Gemini)",

                                fontSize = 9.5.sp,

                                color = TextSecondary,

                                fontWeight = FontWeight.Medium,

                                textAlign = TextAlign.Center

                            )

                        }

                    }



                    // Nút Tải Gemini trên CH Play

                    Button(

                        onClick = {

                            try {

                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.google.android.apps.bard"))

                                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK

                                context.startActivity(intent)

                            } catch (_: Exception) {}

                        },

                        modifier = Modifier

                            .weight(1f)

                            .defaultMinSize(minHeight = 78.dp),

                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 8.dp),

                        shape = RoundedCornerShape(12.dp),

                        colors = ButtonDefaults.buttonColors(

                            containerColor = MagicSurfaceCard,

                            contentColor = MagicCyanLight

                        ),

                        border = androidx.compose.foundation.BorderStroke(1.dp, MagicCyan.copy(alpha = 0.45f))

                    ) {

                        Column(

                            horizontalAlignment = Alignment.CenterHorizontally,

                            verticalArrangement = Arrangement.Center

                        ) {

                            Icon(imageVector = Icons.Default.SmartToy, contentDescription = null, modifier = Modifier.size(18.dp))

                            Spacer(modifier = Modifier.height(3.dp))

                            Text(

                                text = "TẢI GEMINI TRÊN CH PLAY",

                                fontSize = 11.sp,

                                fontWeight = FontWeight.Black,

                                textAlign = TextAlign.Center,

                                softWrap = true

                            )

                            Spacer(modifier = Modifier.height(2.dp))

                            Text(

                                text = "(Trợ Lý AI Chính Chủ)",

                                fontSize = 9.5.sp,

                                color = TextSecondary,

                                fontWeight = FontWeight.Medium,

                                textAlign = TextAlign.Center

                            )

                        }

                    }

                }







                // Dạy YOYO Nói Tiếng Việt & Việt Hóa YOYO Tự Động (Bản Website magictunehonor.ai.studio)

                Box(

                    modifier = Modifier

                        .fillMaxWidth()

                        .clip(RoundedCornerShape(10.dp))

                        .background(Color(0xFF131F37))

                        .border(1.dp, MagicPurpleLight.copy(alpha = 0.5f), RoundedCornerShape(10.dp))

                        .clickable {

                            try {

                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://magictunehonor.ai.studio/"))

                                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK

                                context.startActivity(intent)

                            } catch (_: Exception) {}

                        }

                        .padding(10.dp)

                ) {

                    Row(

                        modifier = Modifier.fillMaxWidth(),

                        verticalAlignment = Alignment.CenterVertically,

                        horizontalArrangement = Arrangement.SpaceBetween

                    ) {

                        Row(

                            verticalAlignment = Alignment.CenterVertically,

                            horizontalArrangement = Arrangement.spacedBy(8.dp),

                            modifier = Modifier.weight(1f)

                        ) {

                            Icon(imageVector = Icons.Default.Language, contentDescription = null, tint = MagicPurpleLight, modifier = Modifier.size(18.dp))

                            Column {

                                Text(

                                    text = "🌐 Dạy YOYO Tiếng Việt & Việt Hóa Tự Động",

                                    color = Color.White,

                                    fontSize = 11.5.sp,

                                    fontWeight = FontWeight.Bold

                                )

                                Text(

                                    text = "Mời bạn trải nghiệm bản Web AI tại magictunehonor.ai.studio",

                                    color = MagicPurpleLight,

                                    fontSize = 10.sp

                                )

                            }

                        }

                        Icon(imageVector = Icons.AutoMirrored.Filled.OpenInNew, contentDescription = null, tint = MagicPurpleLight, modifier = Modifier.size(16.dp))

                    }

                }



                // Quản Lý Quyền Pin Chạy Nền & Đa Nhiệm (100% Không Cần Shizuku - Siêu Gọn)

                Box(

                    modifier = Modifier

                        .fillMaxWidth()

                        .clip(RoundedCornerShape(8.dp))

                        .background(MagicSurfaceDark)

                        .border(1.dp, if (isBatteryOptimized) MagicAmber.copy(alpha = 0.5f) else MagicEmerald.copy(alpha = 0.35f), RoundedCornerShape(8.dp))

                        .padding(horizontal = 10.dp, vertical = 6.dp)

                ) {

                    Row(

                        modifier = Modifier.fillMaxWidth(),

                        horizontalArrangement = Arrangement.SpaceBetween,

                        verticalAlignment = Alignment.CenterVertically

                    ) {

                        Row(

                            verticalAlignment = Alignment.CenterVertically,

                            horizontalArrangement = Arrangement.spacedBy(6.dp),

                            modifier = Modifier.weight(1f)

                        ) {

                            Icon(

                                imageVector = Icons.Default.BatteryAlert,

                                contentDescription = null,

                                tint = if (isBatteryOptimized) MagicAmber else MagicEmerald,

                                modifier = Modifier.size(16.dp)

                            )

                            Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {

                                Text(

                                    text = if (isBatteryOptimized) "Chưa cấp quyền chạy nền pin" else "Đã cấp quyền chạy nền (Pin)",

                                    color = if (isBatteryOptimized) MagicAmber else MagicEmeraldLight,

                                    fontSize = 11.sp,

                                    fontWeight = FontWeight.Bold

                                )

                                Text(

                                    text = if (isBatteryOptimized) "Bấm để cho phép chạy nền, chống ngắt kết nối" else "Không bị hệ điều hành đóng khi khóa máy",

                                    color = TextSecondary,

                                    fontSize = 9.sp,

                                    maxLines = 1,

                                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis

                                )

                            }

                        }

                        Spacer(modifier = Modifier.width(6.dp))

                        Button(

                            onClick = {

                                try {

                                    val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)

                                    intent.data = Uri.parse("package:${context.packageName}")

                                    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK

                                    context.startActivity(intent)

                                } catch (_: Exception) {

                                    try {

                                        val intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)

                                        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK

                                        context.startActivity(intent)

                                    } catch (_: Exception) {}

                                }

                            },

                            modifier = Modifier.defaultMinSize(minHeight = 34.dp),

                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 2.dp),

                            shape = RoundedCornerShape(6.dp),

                            colors = ButtonDefaults.buttonColors(

                                containerColor = if (isBatteryOptimized) MagicAmber else MagicSurfaceCard,

                                contentColor = if (isBatteryOptimized) Color(0xFF020617) else MagicEmerald

                            ),

                            border = if (!isBatteryOptimized) androidx.compose.foundation.BorderStroke(1.dp, MagicEmerald.copy(alpha = 0.4f)) else null

                        ) {

                            Text(

                                text = if (isBatteryOptimized) "Cấp Quyền" else "✓ Đã Cấp",

                                fontSize = 10.sp,

                                fontWeight = FontWeight.Bold

                            )

                        }

                    }

                }



                Row(

                    modifier = Modifier.fillMaxWidth(),

                    horizontalArrangement = Arrangement.spacedBy(8.dp)

                ) {

                    // Double height for comfortable 2-line display

                    Button(

                        onClick = onDisableYoyoWake,

                        enabled = true,

                        modifier = Modifier

                            .weight(1f)

                            .defaultMinSize(minHeight = 78.dp)

                            .testTag("disable_yoyo_nav_wake_button"),

                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 8.dp),

                        shape = RoundedCornerShape(12.dp),

                        colors = ButtonDefaults.buttonColors(

                            containerColor = MagicSurfaceCard,

                            contentColor = Color.White

                        ),

                        border = androidx.compose.foundation.BorderStroke(1.dp, MagicCyan.copy(alpha = 0.35f))

                    ) {

                        Column(

                            horizontalAlignment = Alignment.CenterHorizontally,

                            verticalArrangement = Arrangement.Center

                        ) {

                            Icon(imageVector = Icons.Default.DoNotTouch, contentDescription = null, modifier = Modifier.size(18.dp))

                            Spacer(modifier = Modifier.height(3.dp))

                            Text(

                                text = "Tắt Đánh Thức YOYO",

                                fontSize = 11.sp,

                                fontWeight = FontWeight.Black,

                                textAlign = TextAlign.Center,

                                softWrap = true

                            )

                            Spacer(modifier = Modifier.height(2.dp))

                            Text(

                                text = "(Khóa Nhảy Giọng Nói)",

                                fontSize = 9.5.sp,

                                color = TextSecondary,

                                textAlign = TextAlign.Center

                            )

                        }

                    }



                    // Double height for comfortable 2-line display

                    Button(

                        onClick = onEnhanceGestureSensitivity,

                        enabled = true,

                        modifier = Modifier

                            .weight(1f)

                            .defaultMinSize(minHeight = 78.dp),

                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 8.dp),

                        shape = RoundedCornerShape(12.dp),

                        colors = ButtonDefaults.buttonColors(

                            containerColor = MagicSurfaceCard,

                            contentColor = MagicEmeraldLight

                        ),

                        border = androidx.compose.foundation.BorderStroke(1.dp, MagicEmerald.copy(alpha = 0.45f))

                    ) {

                        Column(

                            horizontalAlignment = Alignment.CenterHorizontally,

                            verticalArrangement = Arrangement.Center

                        ) {

                            Icon(imageVector = Icons.Default.GraphicEq, contentDescription = null, modifier = Modifier.size(18.dp))

                            Spacer(modifier = Modifier.height(3.dp))

                            Text(

                                text = "Tăng Độ Nhạy Vuốt Đáy",

                                fontSize = 11.sp,

                                fontWeight = FontWeight.Bold,

                                textAlign = TextAlign.Center,

                                softWrap = true

                            )

                            Spacer(modifier = Modifier.height(2.dp))

                            Text(

                                text = "(Fix Kính Cường Lực)",

                                fontSize = 9.5.sp,

                                color = MagicEmerald,

                                textAlign = TextAlign.Center

                            )

                        }

                    }

                }

            }

// Đóng Nhóm 1
        }
        }

        // ==========================================
        // NHÓM 2: HIỆU NĂNG, PIN & MÀN HÌNH MƯỢT
        // ==========================================
        CollapsibleSectionHeader(
            title = "HIỆU NĂNG, PIN & MÀN HÌNH MƯỢT",
            subtitle = "Max Setting, 120Hz/144Hz, Siêu tiết kiệm pin 0s trễ & Làm mát",
            badgeText = "NHÓM 2 (Ô #27, #31, #32...)",
            badgeColor = MagicEmerald,
            icon = androidx.compose.material.icons.Icons.Default.Speed,
            isExpanded = isGroup2Expanded,
            onToggle = { isGroup2Expanded = !isGroup2Expanded }
        ) {
        // Ô #27: Master Hero Card: Max Setting

        Card(

            modifier = Modifier.fillMaxWidth(),

            shape = RoundedCornerShape(16.dp),

            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),

            border = androidx.compose.foundation.BorderStroke(

                1.dp,

                Brush.linearGradient(listOf(MagicPurple, MagicBlue))

            )

        ) {

            Column(

                modifier = Modifier

                    .fillMaxWidth()

                    .padding(horizontal = 10.dp, vertical = 8.dp),

                verticalArrangement = Arrangement.spacedBy(7.dp)

            ) {

                Row(

                    verticalAlignment = Alignment.CenterVertically,

                    horizontalArrangement = Arrangement.spacedBy(6.dp)

                ) {

                    Box(

                        modifier = Modifier

                            .clip(RoundedCornerShape(6.dp))

                            .background(MagicCyan.copy(alpha = 0.22f))

                            .border(1.dp, MagicCyan.copy(alpha = 0.6f), RoundedCornerShape(6.dp))

                            .padding(horizontal = 7.dp, vertical = 2.dp)

                    ) {

                        Text(

                            text = "Ô #27",

                            color = MagicCyanLight,

                            fontSize = 10.sp,

                            fontWeight = FontWeight.Black

                        )

                    }

                    Box(

                        modifier = Modifier

                            .clip(RoundedCornerShape(8.dp))

                            .background(MagicPurple.copy(alpha = 0.2f))

                            .padding(horizontal = 8.dp, vertical = 4.dp)

                    ) {

                        Text(

                            text = "SIÊU TÙY BIẾN MAX SETTING - GIỮ NGUYÊN CẢ KHI TẮT WLAN",

                            color = MagicPurple,

                            fontSize = 10.sp,

                            fontWeight = FontWeight.Black

                        )

                    }

                }



                Text(

                    text = "Kích Hoạt Max Tần Số Quét & Chuyển Cảnh Siêu Tốc",

                    color = Color.White,

                    fontSize = 15.sp,

                    fontWeight = FontWeight.Black

                )



                Text(

                    text = "Tối ưu đồng loạt: Ép màn hình 120Hz/144Hz không bị tụt fps, chỉnh animation 0.5x, giảm độ trễ cảm ứng, tắt gọi YOYO thanh điều hướng và giữ nguyên trạng thái đã Fix ngay cả khi ngắt kết nối gỡ lỗi WLAN.",

                    color = TextSecondary,

                    fontSize = 11.5.sp,

                    lineHeight = 16.sp

                )



                // Double height for comfortable 2-line display

                Button(

                    onClick = onApplyMaxSettings,

                    enabled = true,

                    modifier = Modifier

                        .fillMaxWidth()

                        .defaultMinSize(minHeight = 68.dp)

                        .testTag("apply_max_settings_button"),

                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 8.dp),

                    shape = RoundedCornerShape(14.dp),

                    colors = ButtonDefaults.buttonColors(

                        containerColor = MagicPurple,

                        contentColor = Color.White

                    )

                ) {

                    Row(

                        verticalAlignment = Alignment.CenterVertically,

                        horizontalArrangement = Arrangement.Center,

                        modifier = Modifier.fillMaxWidth()

                    ) {

                        Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(22.dp))

                        Spacer(modifier = Modifier.width(10.dp))

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {

                            Text(

                                text = "BẬT MAX SETTING TOÀN DIỆN (1 CHẠM)",

                                fontWeight = FontWeight.Black,

                                fontSize = 12.5.sp,

                                lineHeight = 16.sp,

                                textAlign = TextAlign.Center

                            )

                            Spacer(modifier = Modifier.height(2.dp))

                            Text(

                                text = "Ép 144Hz Mượt Mà • Animation 0.5x • Tắt YOYO Điều Hướng",

                                fontWeight = FontWeight.Medium,

                                fontSize = 10.5.sp,

                                color = MagicPurpleLight,

                                lineHeight = 14.sp,

                                textAlign = TextAlign.Center

                            )

                        }

                    }

                }

            }

        }




        // Ô #32: Refresh Rate, Animation Speed & Display Mode

        Row(

            verticalAlignment = Alignment.CenterVertically,

            horizontalArrangement = Arrangement.spacedBy(6.dp)

        ) {

            Box(

                modifier = Modifier

                    .clip(RoundedCornerShape(6.dp))

                    .background(MagicCyan.copy(alpha = 0.22f))

                    .border(1.dp, MagicCyan.copy(alpha = 0.6f), RoundedCornerShape(6.dp))

                    .padding(horizontal = 7.dp, vertical = 2.dp)

            ) {

                Text(

                    text = "Ô #32",

                    color = MagicCyanLight,

                    fontSize = 10.sp,

                    fontWeight = FontWeight.Black

                )

            }

            Text(

                text = "TẦN SỐ QUÉT MÀN HÌNH (HIỆN TẠI: ${deviceInfo.refreshRate})",

                color = TextPrimary,

                fontSize = 12.sp,

                fontWeight = FontWeight.Black

            )

        }



        Row(

            modifier = Modifier.fillMaxWidth(),

            horizontalArrangement = Arrangement.spacedBy(8.dp)

        ) {

            listOf(144 to "Ép 120/144Hz", 90 to "90Hz Cân Bằng", 60 to "60Hz Tiết Kiệm").forEach { (rate, title) ->

                val isSelected = tuneStatus.currentRefreshRate == rate || (rate == 144 && tuneStatus.currentRefreshRate >= 120)

                Box(

                    modifier = Modifier

                        .weight(1f)

                        .clip(RoundedCornerShape(12.dp))

                        .background(if (isSelected) MagicCyan.copy(alpha = 0.2f) else MagicSurfaceDark)

                        .border(1.dp, if (isSelected) MagicCyan else MagicBorder, RoundedCornerShape(12.dp))

                        .clickable { onSetRefreshRate(rate) }

                        .padding(vertical = 12.dp),

                    contentAlignment = Alignment.Center

                ) {

                    Text(

                        text = title,

                        color = if (isSelected) MagicCyanLight else TextPrimary,

                        fontSize = 11.sp,

                        fontWeight = FontWeight.Bold

                    )

                }

            }

        }



        // Animation Speed Selector

        Text(

            text = "TỐC ĐỘ CHUYỂN CẢNH (HIỆN TẠI: ${tuneStatus.currentAnimationScale}x)",

            color = TextPrimary,

            fontSize = 12.sp,

            fontWeight = FontWeight.Black

        )



        Row(

            modifier = Modifier.fillMaxWidth(),

            horizontalArrangement = Arrangement.spacedBy(8.dp)

        ) {

            listOf(0.5f to "0.5x (Siêu tốc)", 1.0f to "1.0x (Chuẩn)", 0.0f to "Tắt hẳn (0x)").forEach { (scale, title) ->

                val isSelected = tuneStatus.currentAnimationScale == scale

                Box(

                    modifier = Modifier

                        .weight(1f)

                        .clip(RoundedCornerShape(12.dp))

                        .background(if (isSelected) MagicEmerald.copy(alpha = 0.2f) else MagicSurfaceDark)

                        .border(1.dp, if (isSelected) MagicEmerald else MagicBorder, RoundedCornerShape(12.dp))

                        .clickable { onSetAnimationScale(scale) }

                        .padding(vertical = 12.dp),

                    contentAlignment = Alignment.Center

                ) {

                    Text(

                        text = title,

                        color = if (isSelected) MagicEmeraldLight else TextPrimary,

                        fontSize = 11.sp,

                        fontWeight = FontWeight.Bold

                    )

                }

            }

        }



        // Quick Tweaks Row: Font to đậm, Dark Mode OLED, Chụp ảnh bảo mật

        Text(

            text = "CHẾ ĐỘ HIỂN THỊ & BẢO MẬT",

            color = TextPrimary,

            fontSize = 12.sp,

            fontWeight = FontWeight.Black

        )



        Row(

            modifier = Modifier.fillMaxWidth(),

            horizontalArrangement = Arrangement.spacedBy(8.dp)

        ) {

            Box(

                modifier = Modifier

                    .weight(1f)

                    .clip(RoundedCornerShape(10.dp))

                    .background(if (tuneStatus.isFontBoldLarge) MagicAmber.copy(alpha = 0.15f) else MagicSurfaceDark)

                    .border(

                        1.dp,

                        if (tuneStatus.isFontBoldLarge) MagicAmber else MagicBorder,

                        RoundedCornerShape(10.dp)

                    )

                    .clickable { onSetFontLarge(!tuneStatus.isFontBoldLarge) }

                    .padding(horizontal = 10.dp, vertical = 9.dp)

            ) {

                Row(

                    modifier = Modifier.fillMaxWidth(),

                    verticalAlignment = Alignment.CenterVertically,

                    horizontalArrangement = Arrangement.SpaceBetween

                ) {

                    Column(modifier = Modifier.weight(1f)) {

                        Text(text = "👓 Chữ To & Đậm", color = MagicAmber, fontSize = 11.5.sp, fontWeight = FontWeight.Bold)

                        Text(

                            text = if (tuneStatus.isFontBoldLarge) "Bật (115%)" else "Mặc định",

                            color = if (tuneStatus.isFontBoldLarge) MagicEmeraldLight else TextMuted,

                            fontSize = 9.5.sp

                        )

                    }

                    Switch(

                        checked = tuneStatus.isFontBoldLarge,

                        onCheckedChange = { onSetFontLarge(it) },

                        modifier = Modifier.scale(0.72f),

                        colors = SwitchDefaults.colors(

                            checkedThumbColor = Color(0xFF020617),

                            checkedTrackColor = MagicAmber,

                            uncheckedThumbColor = TextMuted,

                            uncheckedTrackColor = MagicSurfaceCard

                        )

                    )

                }

            }



            Box(

                modifier = Modifier

                    .weight(1f)

                    .clip(RoundedCornerShape(10.dp))

                    .background(if (tuneStatus.isDarkModeOled) MagicPurple.copy(alpha = 0.15f) else MagicSurfaceDark)

                    .border(

                        1.dp,

                        if (tuneStatus.isDarkModeOled) MagicPurple else MagicBorder,

                        RoundedCornerShape(10.dp)

                    )

                    .clickable { onSetDarkModeOled(!tuneStatus.isDarkModeOled) }

                    .padding(horizontal = 10.dp, vertical = 9.dp)

            ) {

                Row(

                    modifier = Modifier.fillMaxWidth(),

                    verticalAlignment = Alignment.CenterVertically,

                    horizontalArrangement = Arrangement.SpaceBetween

                ) {

                    Column(modifier = Modifier.weight(1f)) {

                        Text(text = "🌙 Dark OLED", color = MagicPurple, fontSize = 11.5.sp, fontWeight = FontWeight.Bold)

                        Text(

                            text = if (tuneStatus.isDarkModeOled) "Bật OLED" else "Tắt OLED",

                            color = if (tuneStatus.isDarkModeOled) MagicEmeraldLight else TextMuted,

                            fontSize = 9.5.sp

                        )

                    }

                    Switch(

                        checked = tuneStatus.isDarkModeOled,

                        onCheckedChange = { onSetDarkModeOled(it) },

                        modifier = Modifier.scale(0.72f),

                        colors = SwitchDefaults.colors(

                            checkedThumbColor = Color(0xFF020617),

                            checkedTrackColor = MagicPurple,

                            uncheckedThumbColor = TextMuted,

                            uncheckedTrackColor = MagicSurfaceCard

                        )

                    )

                }

            }



            Box(

                modifier = Modifier

                    .weight(0.9f)

                    .clip(RoundedCornerShape(10.dp))

                    .background(if (tuneStatus.isScreenshotUnlocked) MagicCyan.copy(alpha = 0.15f) else MagicSurfaceDark)

                    .border(

                        1.dp,

                        if (tuneStatus.isScreenshotUnlocked) MagicCyan else MagicBorder,

                        RoundedCornerShape(10.dp)

                    )

                    .clickable { onUnlockScreenshot() }

                    .padding(horizontal = 8.dp, vertical = 9.dp)

            ) {

                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {

                    Text(text = "📸 Chụp Ảnh", color = MagicCyan, fontSize = 11.5.sp, fontWeight = FontWeight.Bold)

                    Text(

                        text = if (tuneStatus.isScreenshotUnlocked) "✅ Đã mở" else "Mở App Bank",

                        color = if (tuneStatus.isScreenshotUnlocked) MagicEmeraldLight else TextMuted,

                        fontSize = 9.5.sp

                    )

                }

            }

        }



        // Sửa âm thanh 48kHz


        Card(

            modifier = Modifier.fillMaxWidth(),

            shape = RoundedCornerShape(10.dp),

            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),

            border = androidx.compose.foundation.BorderStroke(1.dp, MagicEmerald.copy(alpha = 0.4f))

        ) {

            Row(

                modifier = Modifier

                    .fillMaxWidth()

                    .padding(horizontal = 10.dp, vertical = 6.dp),

                verticalAlignment = Alignment.CenterVertically,

                horizontalArrangement = Arrangement.SpaceBetween

            ) {

                Row(

                    verticalAlignment = Alignment.CenterVertically,

                    horizontalArrangement = Arrangement.spacedBy(8.dp),

                    modifier = Modifier.weight(1f)

                ) {

                    Icon(imageVector = Icons.Default.BatteryChargingFull, contentDescription = null, tint = MagicEmerald, modifier = Modifier.size(18.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {

                        Text(

                            text = "Siêu Tiết Kiệm Pin (Zero Delay)",

                            color = Color.White,

                            fontSize = 11.5.sp,

                            fontWeight = FontWeight.Bold

                        )

                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {

                            Box(

                                modifier = Modifier

                                    .clip(RoundedCornerShape(3.dp))

                                    .background(MagicEmerald.copy(alpha = 0.2f))

                                    .padding(horizontal = 4.dp, vertical = 1.dp)

                            ) {

                                Text(text = "OLED + 0s TRỄ", color = MagicEmeraldLight, fontSize = 8.sp, fontWeight = FontWeight.Black)

                            }

                            Text(

                                text = "Whitelist Zalo, FB, Telegram",

                                color = TextSecondary,

                                fontSize = 9.sp,

                                maxLines = 1,

                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis

                            )

                        }

                    }

                }

                Spacer(modifier = Modifier.width(6.dp))

                Button(

                    onClick = onApplySmartBatterySaver,

                    enabled = true,

                    modifier = Modifier.defaultMinSize(minHeight = 34.dp),

                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 2.dp),

                    shape = RoundedCornerShape(6.dp),

                    colors = ButtonDefaults.buttonColors(

                        containerColor = MagicEmerald,

                        contentColor = Color(0xFF020617)

                    )

                ) {

                    Icon(imageVector = Icons.Default.Check, contentDescription = null, modifier = Modifier.size(12.dp))

                    Spacer(modifier = Modifier.width(3.dp))

                    Text(text = "Kích Hoạt", fontSize = 10.sp, fontWeight = FontWeight.Black)

                }

            }

        }



        // Tùy biến Mở Rộng: Tối ưu Cảm Ứng Chơi Game & Mở Rộng Khả Năng Tùy Biến


        Card(

            modifier = Modifier.fillMaxWidth(),

            shape = RoundedCornerShape(14.dp),

            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),

            border = androidx.compose.foundation.BorderStroke(1.dp, MagicPurple.copy(alpha = 0.5f))

        ) {

            Column(

                modifier = Modifier

                    .fillMaxWidth()

                    .padding(10.dp),

                verticalArrangement = Arrangement.spacedBy(6.dp)

            ) {

                Row(

                    modifier = Modifier.fillMaxWidth(),

                    horizontalArrangement = Arrangement.SpaceBetween,

                    verticalAlignment = Alignment.CenterVertically

                ) {

                    Row(

                        verticalAlignment = Alignment.CenterVertically,

                        horizontalArrangement = Arrangement.spacedBy(8.dp)

                    ) {

                        Icon(imageVector = Icons.Default.GraphicEq, contentDescription = null, tint = MagicPurple, modifier = Modifier.size(20.dp))

                        Text(

                            text = "Tối Ưu Phản Hồi Cảm Ứng & Độ Nhạy Game",

                            color = Color.White,

                            fontSize = 13.sp,

                            fontWeight = FontWeight.Bold

                        )

                    }

                }



                Text(

                    text = "Giảm độ trễ cảm ứng màn hình xuống mức thấp nhất (Touch Response = 0ms), nâng cao độ nhạy vuốt chạm khi lướt web, chơi game FPS/MOBA trên màn hình 144Hz của Honor.",

                    color = TextSecondary,

                    fontSize = 11.sp,

                    lineHeight = 16.sp

                )



                Row(

                    modifier = Modifier.fillMaxWidth(),

                    horizontalArrangement = Arrangement.End

                ) {

                    Button(

                        onClick = onApplyMaxSettings,

                        enabled = true,

                        modifier = Modifier.defaultMinSize(minHeight = 42.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 4.dp),

                        shape = RoundedCornerShape(10.dp),

                        colors = ButtonDefaults.buttonColors(

                            containerColor = MagicPurple,

                            contentColor = Color.White

                        )

                    ) {

                        Icon(imageVector = Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))

                        Spacer(modifier = Modifier.width(6.dp))

                        Text(text = "Kích Hoạt Siêu Nhạy Cảm Ứng", fontSize = 11.sp, fontWeight = FontWeight.Black)

                    }

                }

            }

        }



        // =========================================================================

        // TRUNG TÂM 5 QUYỀN NĂNG HỆ THỐNG CHUYÊN SÂU v2.5 (SUPPORT ANDROID 11 -> 17)

        // =========================================================================



        // 1. Vượt Chặn Chế Độ Nhà Phát Triển (Truy Cập Full App Banking / Game)


        Card(

            modifier = Modifier.fillMaxWidth(),

            shape = RoundedCornerShape(16.dp),

            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),

            border = androidx.compose.foundation.BorderStroke(

                1.dp,

                if (isAutoCoolingEnabled) MagicCyan else MagicBorder

            )

        ) {

            Column(

                modifier = Modifier

                    .fillMaxWidth()

                    .padding(10.dp),

                verticalArrangement = Arrangement.spacedBy(6.dp)

            ) {

                Row(

                    modifier = Modifier.fillMaxWidth(),

                    horizontalArrangement = Arrangement.SpaceBetween,

                    verticalAlignment = Alignment.CenterVertically

                ) {

                    Column(modifier = Modifier.weight(1f)) {

                        Row(

                            verticalAlignment = Alignment.CenterVertically,

                            horizontalArrangement = Arrangement.spacedBy(6.dp)

                        ) {

                            Box(

                                modifier = Modifier

                                    .clip(RoundedCornerShape(6.dp))

                                    .background(MagicCyan.copy(alpha = 0.22f))

                                    .border(1.dp, MagicCyan.copy(alpha = 0.6f), RoundedCornerShape(6.dp))

                                    .padding(horizontal = 7.dp, vertical = 2.dp)

                            ) {

                                Text(

                                    text = "Ô #31",

                                    color = MagicCyanLight,

                                    fontSize = 10.sp,

                                    fontWeight = FontWeight.Black

                                )

                            }

                            Text(

                                text = "❄️ Tự Động Làm Mát Khi Vượt Quá 35°C",

                                color = Color.White,

                                fontSize = 13.5.sp,

                                fontWeight = FontWeight.Bold

                            )

                        }

                        Text(

                            text = if (isAutoCoolingEnabled) "ĐANG BẬT BẢO VỆ: Quét liên tục & làm mát tự động" else "ĐÃ TẮT BẢO VỆ NHIỆT",

                            color = if (isAutoCoolingEnabled) MagicCyanLight else TextMuted,

                            fontSize = 11.sp,

                            fontWeight = FontWeight.Medium

                        )

                    }



                    androidx.compose.material3.Switch(

                        checked = isAutoCoolingEnabled,

                        onCheckedChange = { onToggleAutoCooling(it) },

                        colors = androidx.compose.material3.SwitchDefaults.colors(

                            checkedThumbColor = Color.White,

                            checkedTrackColor = MagicCyan,

                            uncheckedThumbColor = TextMuted,

                            uncheckedTrackColor = MagicSurfaceCard

                        )

                    )

                }



                Text(

                    text = "Khi nhiệt độ phần cứng đạt từ 35.0°C trở lên, MagicTune tự động kích hoạt toàn bộ phương án làm mát: Kích hoạt chế độ PowerSaver hệ thống, giới hạn tần số quét màn hình về 60Hz, bật Dark Mode OLED, ngắt sạc cưỡng bức, ép CPU/GPU vào trạng thái nghỉ sâu (force-idle) và xả sạch bộ nhớ đệm để nhiệt độ hạ ngay lập tức.",

                    color = TextSecondary,

                    fontSize = 11.sp,

                    lineHeight = 16.sp

                )



                Row(

                    modifier = Modifier.fillMaxWidth(),

                    horizontalArrangement = Arrangement.End

                ) {

                    Button(

                        onClick = onApplyThermalCooling,

                        enabled = true,

                        modifier = Modifier.defaultMinSize(minHeight = 38.dp),

                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 4.dp),

                        shape = RoundedCornerShape(10.dp),

                        colors = ButtonDefaults.buttonColors(

                            containerColor = MagicCyan,

                            contentColor = Color(0xFF020617)

                        )

                    ) {

                        Icon(imageVector = Icons.Default.FlashOn, contentDescription = null, modifier = Modifier.size(15.dp))

                        Spacer(modifier = Modifier.width(6.dp))

                        Text(

                            text = "KÍCH HOẠT LÀM MÁT NGAY",

                            fontSize = 11.sp,

                            fontWeight = FontWeight.Black

                        )

                    }

                }

            }

        }




        }

        // ==========================================
        // NHÓM 3: TIỆN ÍCH HỆ THỐNG & SỬA LỖI ĐỘC QUYỀN
        // ==========================================
        CollapsibleSectionHeader(
            title = "TIỆN ÍCH HỆ THỐNG & SỬA LỖI ĐỘC QUYỀN",
            subtitle = "Android Auto, Chặn quảng cáo, Khôi phục OTA, GPS, Bluetooth Hi-Fi & Ẩn gỡ lỗi ngân hàng",
            badgeText = "NHÓM 3 (Ô #23 -> #38)",
            badgeColor = MagicPurple,
            icon = androidx.compose.material.icons.Icons.Default.Settings,
            isExpanded = isGroup3Expanded,
            onToggle = { isGroup3Expanded = !isGroup3Expanded }
        ) {
        // Ô #23: BẢNG CHỈNH NHANH DỄ DÙNG (CHỮ TO, RÕ RÀNG CHO MỌI LỨA TUỔI)

        Card(

            modifier = Modifier.fillMaxWidth(),

            shape = RoundedCornerShape(16.dp),

            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),

            border = androidx.compose.foundation.BorderStroke(

                1.5.dp,

                Brush.linearGradient(listOf(MagicCyan, MagicEmerald))

            )

        ) {

            Column(

                modifier = Modifier

                    .fillMaxWidth()

                    .padding(12.dp),

                verticalArrangement = Arrangement.spacedBy(8.dp)

            ) {

                Row(

                    modifier = Modifier.fillMaxWidth(),

                    horizontalArrangement = Arrangement.SpaceBetween,

                    verticalAlignment = Alignment.CenterVertically

                ) {

                    Row(

                        verticalAlignment = Alignment.CenterVertically,

                        horizontalArrangement = Arrangement.spacedBy(8.dp),

                        modifier = Modifier.weight(1f)

                    ) {

                        Box(

                            modifier = Modifier

                                .clip(RoundedCornerShape(6.dp))

                                .background(MagicCyan.copy(alpha = 0.22f))

                                .border(1.dp, MagicCyan.copy(alpha = 0.6f), RoundedCornerShape(6.dp))

                                .padding(horizontal = 7.dp, vertical = 2.dp)

                        ) {

                            Text(

                                text = "Ô #23",

                                color = MagicCyanLight,

                                fontSize = 10.5.sp,

                                fontWeight = FontWeight.Black

                            )

                        }

                        Text(

                            text = "✨ CHỈNH NHANH DỄ DÙNG (1 CHẠM)",

                            modifier = Modifier.weight(1f),

                            color = MagicCyanLight,

                            fontSize = 15.sp,

                            fontWeight = FontWeight.Black

                        )

                    }

                    Box(

                        modifier = Modifier

                            .clip(RoundedCornerShape(8.dp))

                            .background(MagicEmerald.copy(alpha = 0.2f))

                            .padding(horizontal = 8.dp, vertical = 4.dp)

                    ) {

                        Text(

                            text = "An toàn 100%",

                            color = MagicEmerald,

                            fontSize = 10.5.sp,

                            fontWeight = FontWeight.Bold

                        )

                    }

                }



                Text(

                    text = "Chọn tính năng bạn muốn bên dưới để giúp điện thoại chữ to dễ đọc, pin bền, máy mượt và vào ngân hàng bình thường:",

                    color = TextSecondary,

                    fontSize = 12.sp,

                    lineHeight = 17.sp

                )



                // Hàng 1: Chữ To Dễ Đọc & Tiết Kiệm Pin

                Row(

                    modifier = Modifier.fillMaxWidth(),

                    horizontalArrangement = Arrangement.spacedBy(8.dp)

                ) {

                    Button(

                        onClick = { onSetFontLarge(!tuneStatus.isFontBoldLarge) },

                        modifier = Modifier

                            .weight(1f)

                            .defaultMinSize(minHeight = 72.dp),

                        shape = RoundedCornerShape(14.dp),

                        colors = ButtonDefaults.buttonColors(

                            containerColor = if (tuneStatus.isFontBoldLarge) MagicEmerald else MagicAmber,

                            contentColor = Color(0xFF020617)

                        )

                    ) {

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {

                            Text(

                                text = if (tuneStatus.isFontBoldLarge) "✓ Chữ Đang To Rõ" else "🔤 Bật Chữ To Rõ",

                                fontSize = 14.sp,

                                fontWeight = FontWeight.Black,

                                textAlign = TextAlign.Center

                            )

                            Spacer(modifier = Modifier.height(2.dp))

                            Text(

                                text = "Dễ nhìn cho người lớn",

                                fontSize = 11.sp,

                                fontWeight = FontWeight.Bold,

                                color = Color(0xFF020617).copy(alpha = 0.85f),

                                textAlign = TextAlign.Center

                            )

                        }

                    }



                    Button(

                        onClick = onApplySmartBatterySaver,

                        modifier = Modifier

                            .weight(1f)

                            .defaultMinSize(minHeight = 72.dp),

                        shape = RoundedCornerShape(14.dp),

                        colors = ButtonDefaults.buttonColors(

                            containerColor = MagicEmerald,

                            contentColor = Color(0xFF020617)

                        )

                    ) {

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {

                            Text(

                                text = "🔋 Siêu Tiết Kiệm Pin",

                                fontSize = 14.sp,

                                fontWeight = FontWeight.Black,

                                textAlign = TextAlign.Center

                            )

                            Spacer(modifier = Modifier.height(2.dp))

                            Text(

                                text = "Máy mát & lâu hết pin",

                                fontSize = 11.sp,

                                fontWeight = FontWeight.Bold,

                                color = Color(0xFF020617).copy(alpha = 0.85f),

                                textAlign = TextAlign.Center

                            )

                        }

                    }

                }



                // Hàng 2: Làm Máy Siêu Mượt & Mở App Ngân Hàng

                Row(

                    modifier = Modifier.fillMaxWidth(),

                    horizontalArrangement = Arrangement.spacedBy(8.dp)

                ) {

                    Button(

                        onClick = onApplyMaxSettings,

                        modifier = Modifier

                            .weight(1f)

                            .defaultMinSize(minHeight = 72.dp),

                        shape = RoundedCornerShape(14.dp),

                        colors = ButtonDefaults.buttonColors(

                            containerColor = MagicCyan,

                            contentColor = Color(0xFF020617)

                        )

                    ) {

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {

                            Text(

                                text = "🚀 Làm Máy Siêu Mượt",

                                fontSize = 14.sp,

                                fontWeight = FontWeight.Black,

                                textAlign = TextAlign.Center

                            )

                            Spacer(modifier = Modifier.height(2.dp))

                            Text(

                                text = "Mở ứng dụng cực nhanh",

                                fontSize = 11.sp,

                                fontWeight = FontWeight.Bold,

                                color = Color(0xFF020617).copy(alpha = 0.85f),

                                textAlign = TextAlign.Center

                            )

                        }

                    }



                    Button(

                        onClick = onEnableStealthDevMode,

                        modifier = Modifier

                            .weight(1f)

                            .defaultMinSize(minHeight = 72.dp),

                        shape = RoundedCornerShape(14.dp),

                        colors = ButtonDefaults.buttonColors(

                            containerColor = MagicSurfaceCard,

                            contentColor = Color.White

                        ),

                        border = androidx.compose.foundation.BorderStroke(1.dp, MagicCyan.copy(alpha = 0.6f))

                    ) {

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {

                            Text(

                                text = "🏦 Vào Bank & App",

                                fontSize = 14.sp,

                                fontWeight = FontWeight.Black,

                                textAlign = TextAlign.Center

                            )

                            Spacer(modifier = Modifier.height(2.dp))

                            Text(

                                text = "Ẩn báo lỗi Nhà phát triển",

                                fontSize = 11.sp,

                                color = MagicCyanLight,

                                textAlign = TextAlign.Center

                            )

                        }

                    }

                }



                // Hàng 3: Chặn Quảng Cáo & Làm To Loa

                Row(

                    modifier = Modifier.fillMaxWidth(),

                    horizontalArrangement = Arrangement.spacedBy(8.dp)

                ) {

                    Button(

                        onClick = {

                            if (tuneStatus.isAdBlockerEnabled) onDisableAdBlocker() else onEnableAdBlocker()

                        },

                        modifier = Modifier

                            .weight(1f)

                            .defaultMinSize(minHeight = 68.dp),

                        shape = RoundedCornerShape(14.dp),

                        colors = ButtonDefaults.buttonColors(

                            containerColor = MagicSurfaceCard,

                            contentColor = Color.White

                        ),

                        border = androidx.compose.foundation.BorderStroke(

                            1.dp,

                            if (tuneStatus.isAdBlockerEnabled) MagicEmerald else MagicAmber.copy(alpha = 0.6f)

                        )

                    ) {

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {

                            Text(

                                text = if (tuneStatus.isAdBlockerEnabled) "✓ Đang Chặn Quảng Cáo" else "🚫 Chặn Quảng Cáo",

                                fontSize = 13.5.sp,

                                fontWeight = FontWeight.Black,

                                textAlign = TextAlign.Center

                            )

                            Text(

                                text = "Đỡ bấm nhầm quảng cáo",

                                fontSize = 11.sp,

                                color = if (tuneStatus.isAdBlockerEnabled) MagicEmerald else MagicAmber,

                                textAlign = TextAlign.Center

                            )

                        }

                    }



                    Button(

                        onClick = onFixAudio,

                        modifier = Modifier

                            .weight(1f)

                            .defaultMinSize(minHeight = 68.dp),

                        shape = RoundedCornerShape(14.dp),

                        colors = ButtonDefaults.buttonColors(

                            containerColor = MagicSurfaceCard,

                            contentColor = Color.White

                        ),

                        border = androidx.compose.foundation.BorderStroke(1.dp, MagicBlue.copy(alpha = 0.6f))

                    ) {

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {

                            Text(

                                text = "🔊 Làm Loa To Rõ",

                                fontSize = 13.5.sp,

                                fontWeight = FontWeight.Black,

                                textAlign = TextAlign.Center

                            )

                            Text(

                                text = "Nghe gọi & xem phim rõ",

                                fontSize = 11.sp,

                                color = MagicCyanLight,

                                textAlign = TextAlign.Center

                            )

                        }

                    }

                }



                // Hàng 4: Phím gọi Gemini Voice AI Trò Chuyện (Chỉ hiện khi Pro, còn lượt Dùng Thử, hoặc đã thêm Gemini API Key)

                val canUseGemini1 = remember(context) { LicenseManager.canAccessGeminiLive(context) }

                if (canUseGemini1) {

                    Button(

                        onClick = {

                            if (tuneStatus.isGeminiAppInstalled) {

                                onModGeminiVoice()

                            } else {

                                onOpenPlayStore("com.google.android.apps.bard")

                            }

                        },

                        modifier = Modifier

                            .fillMaxWidth()

                            .defaultMinSize(minHeight = 68.dp),

                        shape = RoundedCornerShape(14.dp),

                        colors = ButtonDefaults.buttonColors(

                            containerColor = if (tuneStatus.isGeminiAppInstalled) MagicSurfaceCard else MagicAmber.copy(alpha = 0.2f),

                            contentColor = Color.White

                        ),

                        border = androidx.compose.foundation.BorderStroke(1.dp, if (tuneStatus.isGeminiAppInstalled) MagicPurple.copy(alpha = 0.6f) else MagicAmber.copy(alpha = 0.6f))

                    ) {

                        Row(

                            verticalAlignment = Alignment.CenterVertically,

                            horizontalArrangement = Arrangement.Center

                        ) {

                            Icon(

                                imageVector = if (tuneStatus.isGeminiAppInstalled) Icons.Default.Mic else Icons.AutoMirrored.Filled.OpenInNew,

                                contentDescription = null,

                                tint = if (tuneStatus.isGeminiAppInstalled) MagicPurpleLight else MagicAmberLight,

                                modifier = Modifier.size(24.dp)

                            )

                            Spacer(modifier = Modifier.width(8.dp))

                            Column(horizontalAlignment = Alignment.CenterHorizontally) {

                                Text(

                                    text = when {

                                        !tuneStatus.isGeminiAppInstalled -> "📥 TẢI GOOGLE GEMINI (YÊU CẦU)"

                                        tuneStatus.isGeminiVoiceEnabled -> "🎙️ ĐANG BẬT GEMINI VOICE NỔI (CHẠM ĐỂ TẮT & TIẾT KIỆM PIN)"

                                        else -> "🎙️ BẬT GỌI GEMINI VOICE NỔI TRỰC TIẾP TRÊN MÀN HÌNH"

                                    },

                                    fontSize = 13.5.sp,

                                    fontWeight = FontWeight.Black,

                                    textAlign = TextAlign.Center

                                )

                                Text(

                                    text = when {

                                        !tuneStatus.isGeminiAppInstalled -> "Bạn cần cài đặt Gemini từ CH Play để sử dụng tính năng này"

                                        tuneStatus.isGeminiVoiceEnabled -> "Trò chuyện nổi ngay trên màn hình + Tự nhường Micro cho Gemini • Chạm để TẮT lắng nghe Micro 24/24"

                                        else -> "Trò chuyện bằng giọng nói nổi ngay trên màn hình mà không cần mở app Gemini (Hỗ trợ Bật/Tắt tiết kiệm pin)"

                                    },

                                    fontSize = 11.sp,

                                    color = if (tuneStatus.isGeminiAppInstalled) MagicPurpleLight else MagicAmberLight,

                                    textAlign = TextAlign.Center

                                )

                            }

                        }

                    }

                } else {

                    // Hướng dẫn mở khóa Gemini miễn phí bằng API Key cá nhân

                    Card(

                        modifier = Modifier.fillMaxWidth(),

                        shape = RoundedCornerShape(12.dp),

                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1B4B)),

                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF818CF8).copy(alpha = 0.45f))

                    ) {

                        Column(

                            modifier = Modifier.fillMaxWidth().padding(12.dp),

                            verticalArrangement = Arrangement.spacedBy(6.dp)

                        ) {

                            Row(

                                verticalAlignment = Alignment.CenterVertically,

                                horizontalArrangement = Arrangement.spacedBy(8.dp)

                            ) {

                                Icon(imageVector = Icons.Default.Shield, contentDescription = null, tint = Color(0xFFA5B4FC), modifier = Modifier.size(20.dp))

                                Text("MỞ KHÓA TRỢ LÝ AI GEMINI MIỄN PHÍ", color = Color(0xFFA5B4FC), fontSize = 12.sp, fontWeight = FontWeight.Black)

                            }

                            Text(

                                "Bạn đã hết lượt dùng thử Gemini. Hãy nâng cấp PRO hoặc sang tab '1. Thiết Lập' -> Ô #14 để tự thêm Gemini API Key miễn phí của bạn từ aistudio.google.com để nói chuyện không giới hạn!",

                                color = Color.White.copy(alpha = 0.85f),

                                fontSize = 11.sp,

                                lineHeight = 15.sp

                            )

                        }

                    }

                }





        }




        // Ô #26: BỘ TIỆN ÍCH ĐỘC QUYỀN & KHÔI PHỤC CẬP NHẬT HỆ ĐIỀU HÀNH (100% KHÔNG CẦN SHIZUKU)

        Card(

            modifier = Modifier.fillMaxWidth(),

            shape = RoundedCornerShape(14.dp),

            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),

            border = androidx.compose.foundation.BorderStroke(1.dp, MagicCyan.copy(alpha = 0.4f))

        ) {

            Column(

                modifier = Modifier

                    .fillMaxWidth()

                    .padding(horizontal = 12.dp, vertical = 10.dp),

                verticalArrangement = Arrangement.spacedBy(8.dp)

            ) {

                Column(

                    modifier = Modifier.fillMaxWidth(),

                    verticalArrangement = Arrangement.spacedBy(4.dp)

                ) {

                    Row(

                        modifier = Modifier.fillMaxWidth(),

                        horizontalArrangement = Arrangement.SpaceBetween,

                        verticalAlignment = Alignment.CenterVertically

                    ) {

                        Box(

                            modifier = Modifier

                                .clip(RoundedCornerShape(6.dp))

                                .background(MagicCyan.copy(alpha = 0.22f))

                                .border(1.dp, MagicCyan.copy(alpha = 0.6f), RoundedCornerShape(6.dp))

                                .padding(horizontal = 7.dp, vertical = 2.dp)

                        ) {

                            Text(

                                text = "Ô #26",

                                color = MagicCyanLight,

                                fontSize = 10.sp,

                                fontWeight = FontWeight.Black

                            )

                        }

                        Box(

                            modifier = Modifier

                                .clip(RoundedCornerShape(5.dp))

                                .background(MagicCyan.copy(alpha = 0.2f))

                                .border(1.dp, MagicCyan.copy(alpha = 0.45f), RoundedCornerShape(5.dp))

                                .padding(horizontal = 8.dp, vertical = 2.dp)

                        ) {

                            Text(

                                text = "ĐỘC LẬP • KHÔNG CẦN CÀI APP NGOÀI",

                                color = MagicCyanLight,

                                fontSize = 9.5.sp,

                                fontWeight = FontWeight.Black

                            )

                        }

                    }



                    Row(

                        modifier = Modifier.fillMaxWidth(),

                        verticalAlignment = Alignment.CenterVertically,

                        horizontalArrangement = Arrangement.spacedBy(6.dp)

                    ) {

                        Icon(

                            imageVector = Icons.Default.FlashOn,

                            contentDescription = null,

                            tint = MagicCyan,

                            modifier = Modifier.size(17.dp)

                        )

                        Text(

                            text = "Tiện Ích Hệ Thống & Bật Cập Nhật MagicOS",

                            color = Color.White,

                            fontSize = 13.sp,

                            fontWeight = FontWeight.Bold,

                            modifier = Modifier.fillMaxWidth()

                        )

                    }

                }



                // Hàng 1 (3 Nút chip nhỏ gọn)

                Row(

                    modifier = Modifier.fillMaxWidth(),

                    horizontalArrangement = Arrangement.spacedBy(6.dp)

                ) {

                    // Nút Tùy chọn Dev

                    Box(

                        modifier = Modifier

                            .weight(1f)

                            .clip(RoundedCornerShape(8.dp))

                            .background(MagicSurfaceCard)

                            .border(1.dp, MagicCyan.copy(alpha = 0.35f), RoundedCornerShape(8.dp))

                            .clickable {

                                try {

                                    val intent = Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)

                                    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK

                                    context.startActivity(intent)

                                } catch (_: Exception) {

                                    try {

                                        val intent = Intent(Settings.ACTION_DEVICE_INFO_SETTINGS)

                                        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK

                                        context.startActivity(intent)

                                    } catch (_: Exception) {}

                                }

                            }

                            .padding(horizontal = 4.dp, vertical = 7.dp),

                        contentAlignment = Alignment.Center

                    ) {

                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {

                            Icon(imageVector = Icons.Default.Code, contentDescription = null, tint = MagicCyanLight, modifier = Modifier.size(13.dp))

                            Spacer(modifier = Modifier.width(3.dp))

                            Text(text = "Tùy Chọn Dev", color = MagicCyanLight, fontSize = 9.5.sp, fontWeight = FontWeight.Bold)

                        }

                    }



                    // Nút Đổi Trợ Lý

                    Box(

                        modifier = Modifier

                            .weight(1f)

                            .clip(RoundedCornerShape(8.dp))

                            .background(MagicSurfaceCard)

                            .border(1.dp, MagicEmerald.copy(alpha = 0.35f), RoundedCornerShape(8.dp))

                            .clickable {

                                try {

                                    val intent = Intent(Settings.ACTION_VOICE_INPUT_SETTINGS)

                                    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK

                                    context.startActivity(intent)

                                } catch (_: Exception) {

                                    try {

                                        val intent = Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS)

                                        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK

                                        context.startActivity(intent)

                                    } catch (_: Exception) {}

                                }

                            }

                            .padding(horizontal = 4.dp, vertical = 7.dp),

                        contentAlignment = Alignment.Center

                    ) {

                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {

                            Icon(imageVector = Icons.Default.Assistant, contentDescription = null, tint = MagicEmeraldLight, modifier = Modifier.size(13.dp))

                            Spacer(modifier = Modifier.width(3.dp))

                            Text(text = "Đổi Trợ Lý", color = MagicEmeraldLight, fontSize = 9.5.sp, fontWeight = FontWeight.Bold)

                        }

                    }



                    // Nút Cài Đặt Pin & Tiết Kiệm Pin (Không cần Shizuku)

                    Box(

                        modifier = Modifier

                            .weight(1f)

                            .clip(RoundedCornerShape(8.dp))

                            .background(MagicSurfaceCard)

                            .border(1.dp, MagicEmerald.copy(alpha = 0.35f), RoundedCornerShape(8.dp))

                            .clickable {

                                try {

                                    val intent = Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)

                                    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK

                                    context.startActivity(intent)

                                } catch (_: Exception) {

                                    try {

                                        val intent = Intent(Intent.ACTION_POWER_USAGE_SUMMARY)

                                        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK

                                        context.startActivity(intent)

                                    } catch (_: Exception) {}

                                }

                            }

                            .padding(horizontal = 4.dp, vertical = 7.dp),

                        contentAlignment = Alignment.Center

                    ) {

                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {

                            Icon(imageVector = Icons.Default.BatteryChargingFull, contentDescription = null, tint = MagicEmeraldLight, modifier = Modifier.size(13.dp))

                            Spacer(modifier = Modifier.width(3.dp))

                            Text(text = "Cài Đặt Pin", color = MagicEmeraldLight, fontSize = 9.5.sp, fontWeight = FontWeight.Bold)

                        }

                    }

                }



                // Hàng 2 (3 Nút chip nhỏ gọn)

                Row(

                    modifier = Modifier.fillMaxWidth(),

                    horizontalArrangement = Arrangement.spacedBy(6.dp)

                ) {

                    // Nút Quyền Thông Báo

                    Box(

                        modifier = Modifier

                            .weight(1f)

                            .clip(RoundedCornerShape(8.dp))

                            .background(MagicSurfaceCard)

                            .border(1.dp, MagicAmber.copy(alpha = 0.35f), RoundedCornerShape(8.dp))

                            .clickable {

                                try {

                                    val intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)

                                    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK

                                    context.startActivity(intent)

                                } catch (_: Exception) {

                                    try {

                                        val intent = Intent(Settings.ACTION_ALL_APPS_NOTIFICATION_SETTINGS)

                                        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK

                                        context.startActivity(intent)

                                    } catch (_: Exception) {}

                                }

                            }

                            .padding(horizontal = 4.dp, vertical = 7.dp),

                        contentAlignment = Alignment.Center

                    ) {

                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {

                            Icon(imageVector = Icons.Default.NotificationsActive, contentDescription = null, tint = MagicAmberLight, modifier = Modifier.size(13.dp))

                            Spacer(modifier = Modifier.width(3.dp))

                            Text(text = "Đọc Notif", color = MagicAmberLight, fontSize = 9.5.sp, fontWeight = FontWeight.Bold)

                        }

                    }



                    // Nút Màn Hình Hz

                    Box(

                        modifier = Modifier

                            .weight(1f)

                            .clip(RoundedCornerShape(8.dp))

                            .background(MagicSurfaceCard)

                            .border(1.dp, MagicBorder, RoundedCornerShape(8.dp))

                            .clickable {

                                try {

                                    val intent = Intent(Settings.ACTION_DISPLAY_SETTINGS)

                                    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK

                                    context.startActivity(intent)

                                } catch (_: Exception) {}

                            }

                            .padding(horizontal = 4.dp, vertical = 7.dp),

                        contentAlignment = Alignment.Center

                    ) {

                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {

                            Icon(imageVector = Icons.Default.Speed, contentDescription = null, tint = Color.White, modifier = Modifier.size(13.dp))

                            Spacer(modifier = Modifier.width(3.dp))

                            Text(text = "Màn Hình (Hz)", color = Color.White, fontSize = 9.5.sp, fontWeight = FontWeight.Bold)

                        }

                    }



                    // Nút Âm Lượng & Rung

                    Box(

                        modifier = Modifier

                            .weight(1f)

                            .clip(RoundedCornerShape(8.dp))

                            .background(MagicSurfaceCard)

                            .border(1.dp, MagicBorder, RoundedCornerShape(8.dp))

                            .clickable {

                                try {

                                    val intent = Intent(Settings.ACTION_SOUND_SETTINGS)

                                    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK

                                    context.startActivity(intent)

                                } catch (_: Exception) {}

                            }

                            .padding(horizontal = 4.dp, vertical = 7.dp),

                        contentAlignment = Alignment.Center

                    ) {

                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {

                            Icon(imageVector = Icons.AutoMirrored.Filled.VolumeUp, contentDescription = null, tint = MagicBlueLight, modifier = Modifier.size(13.dp))

                            Spacer(modifier = Modifier.width(3.dp))

                            Text(text = "Âm Lượng", color = MagicBlueLight, fontSize = 9.5.sp, fontWeight = FontWeight.Bold)

                        }

                    }

                }



                // Hàng 3: Khôi phục & mở lại tính năng cập nhật hệ điều hành MagicOS (OUC / HOTA)

                Row(

                    modifier = Modifier.fillMaxWidth(),

                    horizontalArrangement = Arrangement.spacedBy(6.dp)

                ) {

                    Box(

                        modifier = Modifier

                            .fillMaxWidth()

                            .clip(RoundedCornerShape(10.dp))

                            .background(MagicPurple.copy(alpha = 0.15f))

                            .border(1.dp, MagicPurpleLight.copy(alpha = 0.6f), RoundedCornerShape(10.dp))

                            .clickable { onFixMagicOSSystemUpdate() }

                            .padding(horizontal = 10.dp, vertical = 9.dp),

                        contentAlignment = Alignment.Center

                    ) {

                        Column(

                            horizontalAlignment = Alignment.CenterHorizontally,

                            verticalArrangement = Arrangement.spacedBy(2.dp)

                        ) {

                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {

                                Icon(imageVector = Icons.Default.Refresh, contentDescription = null, tint = MagicPurpleLight, modifier = Modifier.size(16.dp))

                                Spacer(modifier = Modifier.width(6.dp))

                                Text(text = "🛠️ KHÔI PHỤC & MỞ CẬP NHẬT HỆ ĐIỀU HÀNH (OUC / HOTA)", color = MagicPurpleLight, fontSize = 11.sp, fontWeight = FontWeight.Black)

                                Spacer(modifier = Modifier.width(6.dp))

                                Box(

                                    modifier = Modifier

                                        .clip(RoundedCornerShape(4.dp))

                                        .background(Color(0xFF10B981))

                                        .padding(horizontal = 4.dp, vertical = 1.dp)

                                ) {

                                    Text(text = "FREE", color = Color.White, fontSize = 8.5.sp, fontWeight = FontWeight.Black)

                                }

                            }

                            Text(text = "Miễn phí 100%: Khôi phục lại ứng dụng cập nhật đã bị mất, gỡ bỏ lệnh chặn OTA và mở trang Cập nhật phần mềm", color = TextSecondary, fontSize = 9.5.sp)

                        }

                    }

                }

            }

        }




        // Ô #28: Chặn Quảng Cáo Toàn Diện (AdBlocker Pro)

        Card(

            modifier = Modifier.fillMaxWidth(),

            shape = RoundedCornerShape(16.dp),

            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),

            border = androidx.compose.foundation.BorderStroke(

                1.dp,

                if (tuneStatus.isAdBlockerEnabled) MagicEmerald else MagicEmerald.copy(alpha = 0.35f)

            )

        ) {

            Column(

                modifier = Modifier

                    .fillMaxWidth()

                    .padding(10.dp),

                verticalArrangement = Arrangement.spacedBy(6.dp)

            ) {

                Row(

                    modifier = Modifier.fillMaxWidth(),

                    horizontalArrangement = Arrangement.SpaceBetween,

                    verticalAlignment = Alignment.CenterVertically

                ) {

                    Row(

                        verticalAlignment = Alignment.CenterVertically,

                        horizontalArrangement = Arrangement.spacedBy(6.dp),

                        modifier = Modifier.weight(1f)

                    ) {

                        Box(

                            modifier = Modifier

                                .clip(RoundedCornerShape(6.dp))

                                .background(MagicCyan.copy(alpha = 0.22f))

                                .border(1.dp, MagicCyan.copy(alpha = 0.6f), RoundedCornerShape(6.dp))

                                .padding(horizontal = 7.dp, vertical = 2.dp)

                        ) {

                            Text(

                                text = "Ô #28",

                                color = MagicCyanLight,

                                fontSize = 10.sp,

                                fontWeight = FontWeight.Black

                            )

                        }

                        Icon(imageVector = Icons.Default.Shield, contentDescription = null, tint = MagicEmerald, modifier = Modifier.size(18.dp))

                        Text(

                            text = "Chặn Quảng Cáo Toàn Diện (AdBlocker Pro)",

                            modifier = Modifier.weight(1f),

                            color = Color.White,

                            fontSize = 13.5.sp,

                            fontWeight = FontWeight.Bold,

                            softWrap = true

                        )

                    }

                    Box(

                        modifier = Modifier

                            .clip(RoundedCornerShape(6.dp))

                            .background(if (tuneStatus.isAdBlockerEnabled) MagicEmerald.copy(alpha = 0.22f) else MagicSurfaceCard)

                            .padding(horizontal = 7.dp, vertical = 3.dp)

                    ) {

                        Text(

                            text = if (tuneStatus.isAdBlockerEnabled) "ĐANG BẬT" else "ĐANG TẮT",

                            color = if (tuneStatus.isAdBlockerEnabled) MagicEmerald else TextMuted,

                            fontSize = 9.sp,

                            fontWeight = FontWeight.Black

                        )

                    }

                }



                Text(

                    text = "Trạng thái DNS hiện tại: ${tuneStatus.activeDnsHost}. Kích hoạt Private DNS AdGuard chặn sạch banner, video pop-up trong ứng dụng và trình duyệt; vô hiệu hóa ID theo dõi quảng cáo.",

                    color = TextSecondary,

                    fontSize = 11.sp,

                    lineHeight = 16.sp,

                    softWrap = true,

                    modifier = Modifier.fillMaxWidth()

                )



                Row(

                    modifier = Modifier.fillMaxWidth(),

                    horizontalArrangement = Arrangement.End,

                    verticalAlignment = Alignment.CenterVertically

                ) {

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {

                        Button(

                            onClick = onEnableAdBlocker,

                            enabled = true,

                            modifier = Modifier

                                .height(38.dp)

                                .testTag("enable_adblocker_button"),

                            shape = RoundedCornerShape(10.dp),

                            colors = ButtonDefaults.buttonColors(

                                containerColor = MagicEmerald,

                                contentColor = Color(0xFF020617)

                            )

                        ) {

                            Icon(imageVector = Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))

                            Spacer(modifier = Modifier.width(6.dp))

                            Text(

                                text = if (tuneStatus.isAdBlockerEnabled) "Đã Bật Chặn Quảng Cáo" else "Bật Chặn Quảng Cáo",

                                fontSize = 11.sp,

                                fontWeight = FontWeight.Black

                            )

                        }



                        OutlinedButton(

                            onClick = onDisableAdBlocker,

                            enabled = true,

                            modifier = Modifier.defaultMinSize(minHeight = 42.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 4.dp),

                            shape = RoundedCornerShape(10.dp),

                            colors = ButtonDefaults.outlinedButtonColors(contentColor = TextMuted),

                            border = androidx.compose.foundation.BorderStroke(1.dp, MagicBorder)

                        ) {

                            Text(text = "Tắt", fontSize = 11.sp, fontWeight = FontWeight.Bold)

                        }

                    }

                }

            }

        }



        // Tắt công tắc nhấn thanh điều hướng đánh thức YOYO (Dedicated Card)


        Card(

            modifier = Modifier.fillMaxWidth(),

            shape = RoundedCornerShape(14.dp),

            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),

            border = androidx.compose.foundation.BorderStroke(

                1.dp,

                if (tuneStatus.isAndroidAutoFixed) MagicEmerald else MagicBorder

            )

        ) {

            Column(

                modifier = Modifier

                    .fillMaxWidth()

                    .padding(10.dp),

                verticalArrangement = Arrangement.spacedBy(6.dp)

            ) {

                Row(

                    modifier = Modifier.fillMaxWidth(),

                    horizontalArrangement = Arrangement.SpaceBetween,

                    verticalAlignment = Alignment.CenterVertically

                ) {

                    Row(

                        verticalAlignment = Alignment.CenterVertically,

                        horizontalArrangement = Arrangement.spacedBy(6.dp),

                        modifier = Modifier.weight(1f)

                    ) {

                        Box(

                            modifier = Modifier

                                .clip(RoundedCornerShape(6.dp))

                                .background(MagicCyan.copy(alpha = 0.22f))

                                .border(1.dp, MagicCyan.copy(alpha = 0.6f), RoundedCornerShape(6.dp))

                                .padding(horizontal = 7.dp, vertical = 2.dp)

                        ) {

                            Text(

                                text = "Ô #33B",

                                color = MagicCyanLight,

                                fontSize = 10.sp,

                                fontWeight = FontWeight.Black

                            )

                        }

                        Icon(imageVector = Icons.Default.Refresh, contentDescription = null, tint = MagicCyan, modifier = Modifier.size(18.dp))

                        Text(

                            text = "Đặc Trị Android Auto (Màn Hình Xe Hơi)",

                            modifier = Modifier.weight(1f),

                            color = Color.White,

                            fontSize = 13.5.sp,

                            fontWeight = FontWeight.Bold,

                            softWrap = true

                        )

                    }

                    Box(

                        modifier = Modifier

                            .clip(RoundedCornerShape(6.dp))

                            .background(if (tuneStatus.isAndroidAutoFixed) MagicEmerald.copy(alpha = 0.22f) else MagicSurfaceCard)

                            .padding(horizontal = 7.dp, vertical = 3.dp)

                    ) {

                        Text(

                            text = if (tuneStatus.isAndroidAutoFixed) "ĐÃ TỐI ƯU" else "CHƯA FIX",

                            color = if (tuneStatus.isAndroidAutoFixed) MagicEmerald else MagicAmber,

                            fontSize = 9.sp,

                            fontWeight = FontWeight.Black

                        )

                    }

                }



                Text(

                    text = "🔒 Yêu cầu Kết Nối ADB: Khắc phục triệt để lỗi không nhận Android Auto, văng kết nối cáp/không dây trên xe hơi. Cấp full quyền chạy nền, quyền định vị GPS độ chính xác cao, quyền chiếu media và bỏ chặn diệt ngầm cho ứng dụng Android Auto (Gearhead).",

                    color = TextSecondary,

                    fontSize = 11.sp,

                    lineHeight = 16.sp,

                    softWrap = true,

                    modifier = Modifier.fillMaxWidth()

                )



                Row(

                    modifier = Modifier.fillMaxWidth(),

                    horizontalArrangement = Arrangement.End

                ) {

                    // Double height for comfortable 2-line display

                    Button(

                        onClick = onFixAndroidAuto,

                        enabled = true,

                        modifier = Modifier

                            .fillMaxWidth()

                            .defaultMinSize(minHeight = 76.dp),

                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 8.dp),

                        shape = RoundedCornerShape(12.dp),

                        colors = ButtonDefaults.buttonColors(

                            containerColor = MagicCyan,

                            contentColor = Color(0xFF020617)

                        )

                    ) {

                        Row(

                            verticalAlignment = Alignment.CenterVertically,

                            horizontalArrangement = Arrangement.Center,

                            modifier = Modifier.fillMaxWidth()

                        ) {

                            Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(20.dp))

                            Spacer(modifier = Modifier.width(8.dp))

                            Column(horizontalAlignment = Alignment.CenterHorizontally) {

                                Text(

                                    text = if (tuneStatus.isAndroidAutoFixed) "✓ ĐÃ TỐI ƯU ANDROID AUTO XE HƠI" else "FIX LỖI ANDROID AUTO XE HƠI",

                                    fontSize = 12.sp,

                                    fontWeight = FontWeight.Black,

                                    textAlign = TextAlign.Center

                                )

                                Spacer(modifier = Modifier.height(2.dp))

                                Text(

                                    text = "Cấp Đủ Quyền Gearhead • Chống Văng Màn Xe Hơi",

                                    fontSize = 10.sp,

                                    color = Color(0xFF020617).copy(alpha = 0.85f),

                                    fontWeight = FontWeight.Medium,

                                    textAlign = TextAlign.Center

                                )

                            }

                        }

                    }

                }

            }

        }



        // Đặc Trị Định Vị GPS & La Bàn Cho Honor Nội Địa


        HonorGpsFixCard(

            isGpsOptimized = tuneStatus.isHonorGpsFixed,

            onFixGps = onFixGps,

            onRefreshSatellites = onRefreshSatellites

        )



        // Chế Độ Siêu Tiết Kiệm Pin Thông Minh (Chữ OLED + 0s TRỄ đứng ở 1 hàng riêng biệt, không bị bóp hẹp)


        Card(

            modifier = Modifier.fillMaxWidth(),

            shape = RoundedCornerShape(14.dp),

            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),

            border = androidx.compose.foundation.BorderStroke(

                1.dp,

                if (tuneStatus.isAudio48kFixed) MagicEmerald else MagicBorder

            )

        ) {

            Column(

                modifier = Modifier

                    .fillMaxWidth()

                    .padding(10.dp),

                verticalArrangement = Arrangement.spacedBy(6.dp)

            ) {

                Row(

                    verticalAlignment = Alignment.CenterVertically,

                    horizontalArrangement = Arrangement.spacedBy(6.dp)

                ) {

                    Box(

                        modifier = Modifier

                            .clip(RoundedCornerShape(6.dp))

                            .background(MagicCyan.copy(alpha = 0.22f))

                            .border(1.dp, MagicCyan.copy(alpha = 0.6f), RoundedCornerShape(6.dp))

                            .padding(horizontal = 7.dp, vertical = 2.dp)

                    ) {

                        Text(

                            text = "Ô #33",

                            color = MagicCyanLight,

                            fontSize = 10.sp,

                            fontWeight = FontWeight.Black

                        )

                    }

                    Text(

                        text = "Sửa Rè Âm Thanh & Méo Tiếng Bluetooth (Hi-Fi 48kHz)",

                        color = Color.White,

                        fontSize = 13.5.sp,

                        fontWeight = FontWeight.Bold,

                        softWrap = true,

                        modifier = Modifier.weight(1f)

                    )

                }

                Text(

                    text = "Tắt Bluetooth Absolute Volume tránh vỡ tiếng khi bật âm lượng to, đồng thời ép Audio Server chuẩn 48kHz Hi-Fi.",

                    color = TextSecondary,

                    fontSize = 11.sp,

                    lineHeight = 16.sp,

                    softWrap = true,

                    modifier = Modifier.fillMaxWidth()

                )

                Row(

                    modifier = Modifier.fillMaxWidth(),

                    horizontalArrangement = Arrangement.End

                ) {

                    Button(

                        onClick = onFixAudio,

                        enabled = true,

                        modifier = Modifier.defaultMinSize(minHeight = 42.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 4.dp),

                        shape = RoundedCornerShape(10.dp),

                        colors = ButtonDefaults.buttonColors(

                            containerColor = MagicEmerald,

                            contentColor = Color(0xFF020617)

                        )

                    ) {

                        Icon(imageVector = Icons.Default.GraphicEq, contentDescription = null, modifier = Modifier.size(16.dp))

                        Spacer(modifier = Modifier.width(6.dp))

                        Text(

                            text = if (tuneStatus.isAudio48kFixed) "Đã Chuẩn Hóa 48kHz" else "Chuẩn Hóa Âm Thanh 48kHz",

                            fontSize = 11.sp,

                            fontWeight = FontWeight.Bold

                        )

                    }

                }

            }

        }



        // Ô #33B: Fix Android Auto (Gearhead) cho Xe Hơi


        Card(

            modifier = Modifier

                .fillMaxWidth()

                .testTag("stealth_dev_mode_bypass_card"),

            shape = RoundedCornerShape(16.dp),

            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),

            border = androidx.compose.foundation.BorderStroke(

                1.2.dp,

                if (tuneStatus.isDevModeStealthActive) MagicEmerald else MagicAmber.copy(alpha = 0.7f)

            )

        ) {

            Column(

                modifier = Modifier

                    .fillMaxWidth()

                    .padding(12.dp),

                verticalArrangement = Arrangement.spacedBy(8.dp)

            ) {

                Row(

                    modifier = Modifier.fillMaxWidth(),

                    horizontalArrangement = Arrangement.SpaceBetween,

                    verticalAlignment = Alignment.CenterVertically

                ) {

                    Row(

                        verticalAlignment = Alignment.CenterVertically,

                        horizontalArrangement = Arrangement.spacedBy(6.dp),

                        modifier = Modifier.weight(1f)

                    ) {

                        Box(

                            modifier = Modifier

                                .clip(RoundedCornerShape(6.dp))

                                .background(MagicCyan.copy(alpha = 0.22f))

                                .border(1.dp, MagicCyan.copy(alpha = 0.6f), RoundedCornerShape(6.dp))

                                .padding(horizontal = 7.dp, vertical = 2.dp)

                        ) {

                            Text(

                                text = "Ô #35",

                                color = MagicCyanLight,

                                fontSize = 10.sp,

                                fontWeight = FontWeight.Black

                            )

                        }

                        Icon(imageVector = Icons.Default.Shield, contentDescription = null, tint = MagicEmerald, modifier = Modifier.size(18.dp))

                        Text(

                            text = "Truy Cập Full App Dù Đang Bật Nhà Phát Triển",

                            modifier = Modifier.weight(1f),

                            color = Color.White,

                            fontSize = 13.5.sp,

                            fontWeight = FontWeight.Black,

                            softWrap = true

                        )

                    }

                    Box(

                        modifier = Modifier

                            .clip(RoundedCornerShape(6.dp))

                            .background(if (tuneStatus.isDevModeStealthActive) MagicEmerald.copy(alpha = 0.2f) else MagicAmber.copy(alpha = 0.2f))

                            .padding(horizontal = 7.dp, vertical = 3.dp)

                    ) {

                        Text(

                            text = if (tuneStatus.isDevModeStealthActive) "ĐANG ẨN AN TOÀN" else "ANDROID 11–17",

                            color = if (tuneStatus.isDevModeStealthActive) MagicEmeraldLight else MagicAmber,

                            fontSize = 9.sp,

                            fontWeight = FontWeight.Black

                        )

                    }

                }



                Text(

                    text = "Cho phép mở và sử dụng bình thường 100% ứng dụng Ngân hàng (VCB, MB, BIDV, Techcombank...), Ví điện tử & Game chống gian lận ngay cả khi máy đang bật Gỡ lỗi / Chế độ nhà phát triển. Tự động ẩn cờ Gỡ lỗi khỏi kiểm tra của ứng dụng nhưng vẫn giữ sống quyền ADB UID 2000!",

                    color = TextSecondary,

                    fontSize = 11.sp,

                    lineHeight = 15.5.sp,

                    softWrap = true

                )



                Row(

                    modifier = Modifier.fillMaxWidth(),

                    horizontalArrangement = Arrangement.spacedBy(8.dp)

                ) {

                    Button(

                        onClick = onEnableStealthDevMode,

                        modifier = Modifier

                            .weight(1f)

                            .defaultMinSize(minHeight = 78.dp)

                            .testTag("enable_stealth_dev_mode_button"),

                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 8.dp),

                        shape = RoundedCornerShape(12.dp),

                        colors = ButtonDefaults.buttonColors(

                            containerColor = MagicEmerald,

                            contentColor = Color(0xFF020617)

                        )

                    ) {

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {

                            Text(

                                text = "🛡️ BẬT CHẾ ĐỘ ẨN DEV MODE\n(VÀO FULL APP BANKING & GAME)",

                                fontSize = 10.5.sp,

                                lineHeight = 14.sp,

                                fontWeight = FontWeight.Black,

                                textAlign = TextAlign.Center,

                                softWrap = true

                            )

                            Spacer(modifier = Modifier.height(2.dp))

                            Text(

                                text = "(Giữ nguyên kết nối ADB)",

                                fontSize = 9.sp,

                                color = Color(0xFF020617).copy(alpha = 0.85f),

                                fontWeight = FontWeight.Bold,

                                textAlign = TextAlign.Center

                            )

                        }

                    }



                    OutlinedButton(

                        onClick = onRestoreDevModeVisibility,

                        modifier = Modifier

                            .weight(1f)

                            .defaultMinSize(minHeight = 78.dp)

                            .testTag("restore_dev_mode_visibility_button"),

                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 8.dp),

                        shape = RoundedCornerShape(12.dp),

                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MagicCyanLight),

                        border = androidx.compose.foundation.BorderStroke(1.dp, MagicCyan.copy(alpha = 0.5f))

                    ) {

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {

                            Text(

                                text = "🔓 HIỆN LẠI MENU\nNHÀ PHÁT TRIỂN",

                                fontSize = 10.5.sp,

                                lineHeight = 14.sp,

                                fontWeight = FontWeight.Black,

                                textAlign = TextAlign.Center,

                                softWrap = true

                            )

                            Spacer(modifier = Modifier.height(2.dp))

                            Text(

                                text = "(Khi cần vào Cài đặt sửa)",

                                fontSize = 9.sp,

                                color = TextSecondary,

                                fontWeight = FontWeight.Medium,

                                textAlign = TextAlign.Center

                            )

                        }

                    }

                }

            }

        }



        // 2. Tương Tác & Chỉnh Sửa Tệp Hệ Thống (Android/data & Android/obb)


        Card(

            modifier = Modifier

                .fillMaxWidth()

                .testTag("restricted_file_system_card"),

            shape = RoundedCornerShape(16.dp),

            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),

            border = androidx.compose.foundation.BorderStroke(1.2.dp, MagicCyan.copy(alpha = 0.6f))

        ) {

            Column(

                modifier = Modifier

                    .fillMaxWidth()

                    .padding(12.dp),

                verticalArrangement = Arrangement.spacedBy(8.dp)

            ) {

                Row(

                    modifier = Modifier.fillMaxWidth(),

                    horizontalArrangement = Arrangement.SpaceBetween,

                    verticalAlignment = Alignment.CenterVertically

                ) {

                    Row(

                        verticalAlignment = Alignment.CenterVertically,

                        horizontalArrangement = Arrangement.spacedBy(6.dp),

                        modifier = Modifier.weight(1f)

                    ) {

                        Box(

                            modifier = Modifier

                                .clip(RoundedCornerShape(6.dp))

                                .background(MagicCyan.copy(alpha = 0.22f))

                                .border(1.dp, MagicCyan.copy(alpha = 0.6f), RoundedCornerShape(6.dp))

                                .padding(horizontal = 7.dp, vertical = 2.dp)

                        ) {

                            Text(

                                text = "Ô #36",

                                color = MagicCyanLight,

                                fontSize = 10.sp,

                                fontWeight = FontWeight.Black

                            )

                        }

                        Icon(imageVector = Icons.Default.Layers, contentDescription = null, tint = MagicCyan, modifier = Modifier.size(18.dp))

                        Text(

                            text = "Tương Tác & Sửa Tệp Hệ Thống (Android/data & obb)",

                            color = Color.White,

                            fontSize = 13.5.sp,

                            fontWeight = FontWeight.Black,

                            softWrap = true

                        )

                    }

                    Box(

                        modifier = Modifier

                            .clip(RoundedCornerShape(6.dp))

                            .background(MagicCyan.copy(alpha = 0.2f))

                            .padding(horizontal = 7.dp, vertical = 3.dp)

                    ) {

                        Text(

                            text = if (tuneStatus.isRestrictedStorageUnlocked) "ĐÃ MỞ KHÓA" else "ADB DIRECT I/O",

                            color = MagicCyanLight,

                            fontSize = 9.sp,

                            fontWeight = FontWeight.Black

                        )

                    }

                }



                Text(

                    text = "Đọc, ghi, giải nén (.zip/.obb) và truy cập trực tiếp vào các thư mục bị hạn chế nghiêm ngặt (/sdcard/Android/data và /sdcard/Android/obb) trên Android 11 – Android 17. Cấp quyền vượt rào Scoped Storage cho trình quản lý tệp.",

                    color = TextSecondary,

                    fontSize = 11.sp,

                    lineHeight = 15.5.sp,

                    softWrap = true

                )



                Box(

                    modifier = Modifier

                        .fillMaxWidth()

                        .clip(RoundedCornerShape(8.dp))

                        .background(MagicSurfaceCard)

                        .border(1.dp, MagicBorder, RoundedCornerShape(8.dp))

                        .padding(horizontal = 10.dp, vertical = 6.dp)

                ) {

                    Text(

                        text = "📂 Trạng thái: ${tuneStatus.restrictedStorageSummary}",

                        color = MagicCyanLight,

                        fontSize = 10.5.sp,

                        fontWeight = FontWeight.Bold,

                        softWrap = true

                    )

                }



                Row(

                    modifier = Modifier.fillMaxWidth(),

                    horizontalArrangement = Arrangement.spacedBy(8.dp)

                ) {

                    Button(

                        onClick = onUnlockRestrictedStorage,

                        modifier = Modifier

                            .weight(1f)

                            .defaultMinSize(minHeight = 78.dp)

                            .testTag("unlock_restricted_storage_button"),

                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 8.dp),

                        shape = RoundedCornerShape(12.dp),

                        colors = ButtonDefaults.buttonColors(

                            containerColor = MagicCyan,

                            contentColor = Color(0xFF020617)

                        )

                    ) {

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {

                            Text(

                                text = "📂 MỞ KHÓA & ĐỌC TRỰC TIẾP\nANDROID/DATA & OBB",

                                fontSize = 10.5.sp,

                                lineHeight = 14.sp,

                                fontWeight = FontWeight.Black,

                                textAlign = TextAlign.Center,

                                softWrap = true

                            )

                            Spacer(modifier = Modifier.height(2.dp))

                            Text(

                                text = "(Cấp quyền đọc/ghi toàn diện)",

                                fontSize = 9.sp,

                                color = Color(0xFF020617).copy(alpha = 0.85f),

                                fontWeight = FontWeight.Bold,

                                textAlign = TextAlign.Center

                            )

                        }

                    }



                    Button(

                        onClick = onExtractAndSyncRestrictedData,

                        modifier = Modifier

                            .weight(1f)

                            .defaultMinSize(minHeight = 78.dp)

                            .testTag("extract_sync_restricted_data_button"),

                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 8.dp),

                        shape = RoundedCornerShape(12.dp),

                        colors = ButtonDefaults.buttonColors(

                            containerColor = MagicSurfaceCard,

                            contentColor = MagicEmeraldLight

                        ),

                        border = androidx.compose.foundation.BorderStroke(1.dp, MagicEmerald.copy(alpha = 0.5f))

                    ) {

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {

                            Text(

                                text = "📦 GIẢI NÉN (.ZIP / .OBB)\n& ĐỒNG BỘ TỆP HỆ THỐNG",

                                fontSize = 10.5.sp,

                                lineHeight = 14.sp,

                                fontWeight = FontWeight.Black,

                                textAlign = TextAlign.Center,

                                softWrap = true

                            )

                            Spacer(modifier = Modifier.height(2.dp))

                            Text(

                                text = "(Trực tiếp qua Shell UID 2000)",

                                fontSize = 9.sp,

                                color = TextSecondary,

                                fontWeight = FontWeight.Medium,

                                textAlign = TextAlign.Center

                            )

                        }

                    }

                }



                Button(

                    onClick = onCleanRestrictedCaches,

                    modifier = Modifier

                        .fillMaxWidth()

                        .defaultMinSize(minHeight = 74.dp)

                        .testTag("clean_restricted_caches_button"),

                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 8.dp),

                    shape = RoundedCornerShape(12.dp),

                    colors = ButtonDefaults.buttonColors(

                        containerColor = MagicSurfaceCard,

                        contentColor = MagicAmber

                    ),

                    border = androidx.compose.foundation.BorderStroke(1.dp, MagicAmber.copy(alpha = 0.45f))

                ) {

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {

                        Text(

                            text = "🧹 DỌN RÁC BỘ ĐỆM SÂU TRONG /SDCARD/ANDROID/DATA/*/CACHE",

                            fontSize = 10.5.sp,

                            lineHeight = 14.sp,

                            fontWeight = FontWeight.Black,

                            textAlign = TextAlign.Center,

                            softWrap = true

                        )

                        Spacer(modifier = Modifier.height(2.dp))

                        Text(

                            text = "(Giải phóng hàng GB bộ nhớ ẩn mà trình dọn thường bị chặn quyền)",

                            fontSize = 9.5.sp,

                            color = TextSecondary,

                            textAlign = TextAlign.Center

                        )

                    }

                }

            }

        }



        // 3. Quản Lý Gói Ứng Dụng (Package Management)


        Card(

            modifier = Modifier

                .fillMaxWidth()

                .testTag("deep_package_management_card"),

            shape = RoundedCornerShape(16.dp),

            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),

            border = androidx.compose.foundation.BorderStroke(1.2.dp, MagicPurple.copy(alpha = 0.6f))

        ) {

            Column(

                modifier = Modifier

                    .fillMaxWidth()

                    .padding(12.dp),

                verticalArrangement = Arrangement.spacedBy(8.dp)

            ) {

                Row(

                    modifier = Modifier.fillMaxWidth(),

                    horizontalArrangement = Arrangement.SpaceBetween,

                    verticalAlignment = Alignment.CenterVertically

                ) {

                    Row(

                        verticalAlignment = Alignment.CenterVertically,

                        horizontalArrangement = Arrangement.spacedBy(6.dp),

                        modifier = Modifier.weight(1f)

                    ) {

                        Box(

                            modifier = Modifier

                                .clip(RoundedCornerShape(6.dp))

                                .background(MagicCyan.copy(alpha = 0.22f))

                                .border(1.dp, MagicCyan.copy(alpha = 0.6f), RoundedCornerShape(6.dp))

                                .padding(horizontal = 7.dp, vertical = 2.dp)

                        ) {

                            Text(

                                text = "Ô #37",

                                color = MagicCyanLight,

                                fontSize = 10.sp,

                                fontWeight = FontWeight.Black

                            )

                        }

                        Icon(imageVector = Icons.Default.Code, contentDescription = null, tint = MagicPurpleLight, modifier = Modifier.size(18.dp))

                        Text(

                            text = "Quản Lý Gói Ứng Dụng Chuyên Sâu (Package Manager)",

                            modifier = Modifier.weight(1f),

                            color = Color.White,

                            fontSize = 13.5.sp,

                            fontWeight = FontWeight.Black,

                            softWrap = true

                        )

                    }

                }



                Text(

                    text = "Gỡ cài đặt (Uninstall --user 0), vô hiệu hóa (Disable), đóng băng (Freeze/Suspend) hoặc cấp/thu hồi quyền hệ thống sâu của bất kỳ ứng dụng người dùng hay hệ thống nào.",

                    color = TextSecondary,

                    fontSize = 11.sp,

                    lineHeight = 15.5.sp,

                    softWrap = true

                )



                Button(

                    onClick = onOpenAppsManagerTab,

                    modifier = Modifier

                        .fillMaxWidth()

                        .defaultMinSize(minHeight = 76.dp)

                        .testTag("open_package_manager_tab_button"),

                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 8.dp),

                    shape = RoundedCornerShape(12.dp),

                    colors = ButtonDefaults.buttonColors(

                        containerColor = MagicPurple,

                        contentColor = Color.White

                    )

                ) {

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {

                        Text(

                            text = "📦 MỞ TRÌNH QUẢN LÝ GÓI ỨNG DỤNG (ĐÓNG BĂNG / GỠ / CẤP & THU HỒI QUYỀN)",

                            fontSize = 10.5.sp,

                            lineHeight = 14.sp,

                            fontWeight = FontWeight.Black,

                            textAlign = TextAlign.Center,

                            softWrap = true

                        )

                        Spacer(modifier = Modifier.height(2.dp))

                        Text(

                            text = "(Hỗ trợ đầy đủ: Freeze, Disable, Uninstall & AppOps trên Android 11 – Android 17)",

                            fontSize = 9.5.sp,

                            color = Color.White.copy(alpha = 0.85f),

                            textAlign = TextAlign.Center

                        )

                    }

                }

            }

        }



        // 4. Kiểm Soát Quyền Riêng Tư Cấp Độ Hệ Thống Sâu (Deep Privacy & Sensor Control)


        Card(

            modifier = Modifier

                .fillMaxWidth()

                .testTag("deep_privacy_sensor_control_card"),

            shape = RoundedCornerShape(16.dp),

            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),

            border = androidx.compose.foundation.BorderStroke(1.2.dp, MagicRose.copy(alpha = 0.6f))

        ) {

            Column(

                modifier = Modifier

                    .fillMaxWidth()

                    .padding(12.dp),

                verticalArrangement = Arrangement.spacedBy(8.dp)

            ) {

                Row(

                    modifier = Modifier.fillMaxWidth(),

                    horizontalArrangement = Arrangement.SpaceBetween,

                    verticalAlignment = Alignment.CenterVertically

                ) {

                    Row(

                        verticalAlignment = Alignment.CenterVertically,

                        horizontalArrangement = Arrangement.spacedBy(6.dp),

                        modifier = Modifier.weight(1f)

                    ) {

                        Box(

                            modifier = Modifier

                                .clip(RoundedCornerShape(6.dp))

                                .background(MagicCyan.copy(alpha = 0.22f))

                                .border(1.dp, MagicCyan.copy(alpha = 0.6f), RoundedCornerShape(6.dp))

                                .padding(horizontal = 7.dp, vertical = 2.dp)

                        ) {

                            Text(

                                text = "Ô #38",

                                color = MagicCyanLight,

                                fontSize = 10.sp,

                                fontWeight = FontWeight.Black

                            )

                        }

                        Icon(imageVector = Icons.Default.VisibilityOff, contentDescription = null, tint = MagicRoseLight, modifier = Modifier.size(18.dp))

                        Text(

                            text = "Kiểm Soát Quyền Riêng Tư & Cảm Biến Hệ Thống Sâu",

                            modifier = Modifier.weight(1f),

                            color = Color.White,

                            fontSize = 13.5.sp,

                            fontWeight = FontWeight.Black,

                            softWrap = true

                        )

                    }

                }



                Text(

                    text = "Tinh chỉnh và giám sát quyền truy cập vào Cảm biến, Vị trí GPS, Camera, Microphone và dữ liệu Bộ nhớ tạm (Clipboard) ở cấp độ hệ thống sâu (cmd sensor_privacy & AppOps).",

                    color = TextSecondary,

                    fontSize = 11.sp,

                    lineHeight = 15.5.sp,

                    softWrap = true

                )



                Row(

                    modifier = Modifier.fillMaxWidth(),

                    horizontalArrangement = Arrangement.spacedBy(8.dp)

                ) {

                    Button(

                        onClick = { onToggleDeepPrivacySensor("CAMERA", !tuneStatus.isCameraPrivacyBlocked) },

                        modifier = Modifier

                            .weight(1f)

                            .defaultMinSize(minHeight = 78.dp)

                            .testTag("toggle_camera_privacy_button"),

                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 8.dp),

                        shape = RoundedCornerShape(12.dp),

                        colors = ButtonDefaults.buttonColors(

                            containerColor = if (tuneStatus.isCameraPrivacyBlocked) MagicRose else MagicSurfaceCard,

                            contentColor = Color.White

                        ),

                        border = androidx.compose.foundation.BorderStroke(1.dp, MagicRose.copy(alpha = 0.5f))

                    ) {

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {

                            Text(

                                text = if (tuneStatus.isCameraPrivacyBlocked) "📷 ĐANG KHÓA CAMERA\n(BẤM ĐỂ MỞ LẠI)" else "📷 KHÓA CẢM BIẾN CAMERA\nTOÀN HỆ THỐNG",

                                fontSize = 10.sp,

                                lineHeight = 13.5.sp,

                                fontWeight = FontWeight.Black,

                                textAlign = TextAlign.Center,

                                softWrap = true

                            )

                            Spacer(modifier = Modifier.height(2.dp))

                            Text(

                                text = if (tuneStatus.isCameraPrivacyBlocked) "✓ Chống quay lén ngầm" else "(Chặn 100% app dùng Cam)",

                                fontSize = 9.sp,

                                color = TextSecondary,

                                textAlign = TextAlign.Center

                            )

                        }

                    }



                    Button(

                        onClick = { onToggleDeepPrivacySensor("MICROPHONE", !tuneStatus.isMicPrivacyBlocked) },

                        modifier = Modifier

                            .weight(1f)

                            .defaultMinSize(minHeight = 78.dp)

                            .testTag("toggle_mic_privacy_button"),

                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 8.dp),

                        shape = RoundedCornerShape(12.dp),

                        colors = ButtonDefaults.buttonColors(

                            containerColor = if (tuneStatus.isMicPrivacyBlocked) MagicRose else MagicSurfaceCard,

                            contentColor = Color.White

                        ),

                        border = androidx.compose.foundation.BorderStroke(1.dp, MagicRose.copy(alpha = 0.5f))

                    ) {

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {

                            Text(

                                text = if (tuneStatus.isMicPrivacyBlocked) "🎙️ ĐANG KHÓA MICRO\n(BẤM ĐỂ MỞ LẠI)" else "🎙️ KHÓA CẢM BIẾN MICRO\nCHỐNG NGHE LÉN",

                                fontSize = 10.sp,

                                lineHeight = 13.5.sp,

                                fontWeight = FontWeight.Black,

                                textAlign = TextAlign.Center,

                                softWrap = true

                            )

                            Spacer(modifier = Modifier.height(2.dp))

                            Text(

                                text = if (tuneStatus.isMicPrivacyBlocked) "✓ Đã ngắt thu âm ngầm" else "(Ngắt phần cứng Micro)",

                                fontSize = 9.sp,

                                color = TextSecondary,

                                textAlign = TextAlign.Center

                            )

                        }

                    }

                }



                Row(

                    modifier = Modifier.fillMaxWidth(),

                    horizontalArrangement = Arrangement.spacedBy(8.dp)

                ) {

                    Button(

                        onClick = { onToggleDeepPrivacySensor("LOCATION", !tuneStatus.isLocationPrivacyBlocked) },

                        modifier = Modifier

                            .weight(1f)

                            .defaultMinSize(minHeight = 78.dp)

                            .testTag("toggle_location_privacy_button"),

                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 8.dp),

                        shape = RoundedCornerShape(12.dp),

                        colors = ButtonDefaults.buttonColors(

                            containerColor = if (tuneStatus.isLocationPrivacyBlocked) MagicAmber else MagicSurfaceCard,

                            contentColor = if (tuneStatus.isLocationPrivacyBlocked) Color(0xFF020617) else MagicAmberLight

                        ),

                        border = androidx.compose.foundation.BorderStroke(1.dp, MagicAmber.copy(alpha = 0.5f))

                    ) {

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {

                            Text(

                                text = if (tuneStatus.isLocationPrivacyBlocked) "📍 ĐANG KHÓA VỊ TRÍ GPS\n(BẤM ĐỂ MỞ LẠI)" else "📍 ĐÓNG BĂNG ĐỊNH VỊ\n& THEO DÕI VỊ TRÍ",

                                fontSize = 10.sp,

                                lineHeight = 13.5.sp,

                                fontWeight = FontWeight.Black,

                                textAlign = TextAlign.Center,

                                softWrap = true

                            )

                            Spacer(modifier = Modifier.height(2.dp))

                            Text(

                                text = "(Bảo vệ lộ trình di chuyển)",

                                fontSize = 9.sp,

                                color = if (tuneStatus.isLocationPrivacyBlocked) Color(0xFF020617) else TextSecondary,

                                textAlign = TextAlign.Center

                            )

                        }

                    }



                    Button(

                        onClick = { onToggleDeepPrivacySensor("CLIPBOARD", !tuneStatus.isClipboardPrivacyActive) },

                        modifier = Modifier

                            .weight(1f)

                            .defaultMinSize(minHeight = 78.dp)

                            .testTag("toggle_clipboard_privacy_button"),

                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 8.dp),

                        shape = RoundedCornerShape(12.dp),

                        colors = ButtonDefaults.buttonColors(

                            containerColor = if (tuneStatus.isClipboardPrivacyActive) MagicEmerald else MagicSurfaceCard,

                            contentColor = if (tuneStatus.isClipboardPrivacyActive) Color(0xFF020617) else MagicEmeraldLight

                        ),

                        border = androidx.compose.foundation.BorderStroke(1.dp, MagicEmerald.copy(alpha = 0.5f))

                    ) {

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {

                            Text(

                                text = if (tuneStatus.isClipboardPrivacyActive) "📋 ĐANG BẢO VỆ CLIPBOARD\n(BẤM ĐỂ TẮT)" else "📋 CHẶN APP ĐỌC TRỘM\nBỘ NHỚ TẠM (CLIPBOARD)",

                                fontSize = 10.sp,

                                lineHeight = 13.5.sp,

                                fontWeight = FontWeight.Black,

                                textAlign = TextAlign.Center,

                                softWrap = true

                            )

                            Spacer(modifier = Modifier.height(2.dp))

                            Text(

                                text = "(Bảo vệ mật khẩu & mã OTP)",

                                fontSize = 9.sp,

                                color = if (tuneStatus.isClipboardPrivacyActive) Color(0xFF020617) else TextSecondary,

                                textAlign = TextAlign.Center

                            )

                        }

                    }

                }

            }

        }



        // 5. Tự Động Hóa & Điều Khiển Hệ Thống (Automation, Input Simulation & Hardware Key Macros)


        Card(

            modifier = Modifier.fillMaxWidth(),

            shape = RoundedCornerShape(16.dp),

            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),

            border = androidx.compose.foundation.BorderStroke(

                1.dp,

                if (tuneStatus.isAppMarketUpdateBlocked) MagicAmber else MagicEmerald.copy(alpha = 0.45f)

            )

        ) {

            Column(

                modifier = Modifier

                    .fillMaxWidth()

                    .padding(10.dp),

                verticalArrangement = Arrangement.spacedBy(6.dp)

            ) {

                Row(

                    modifier = Modifier.fillMaxWidth(),

                    horizontalArrangement = Arrangement.SpaceBetween,

                    verticalAlignment = Alignment.CenterVertically

                ) {

                    Row(

                        verticalAlignment = Alignment.CenterVertically,

                        horizontalArrangement = Arrangement.spacedBy(6.dp),

                        modifier = Modifier.weight(1f)

                    ) {

                        Box(

                            modifier = Modifier

                                .clip(RoundedCornerShape(6.dp))

                                .background(MagicCyan.copy(alpha = 0.22f))

                                .border(1.dp, MagicCyan.copy(alpha = 0.6f), RoundedCornerShape(6.dp))

                                .padding(horizontal = 7.dp, vertical = 2.dp)

                        ) {

                            Text(

                                text = "Ô #30",

                                color = MagicCyanLight,

                                fontSize = 10.sp,

                                fontWeight = FontWeight.Black

                            )

                        }

                        Icon(

                            imageVector = if (tuneStatus.isAppMarketUpdateBlocked) Icons.Default.Block else Icons.Default.Check,

                            contentDescription = null,

                            tint = if (tuneStatus.isAppMarketUpdateBlocked) MagicAmber else MagicEmerald,

                            modifier = Modifier.size(18.dp)

                        )

                        Text(

                            text = "Chợ Ứng Dụng Honor & Play Store",

                            modifier = Modifier.weight(1f),

                            color = Color.White,

                            fontSize = 13.5.sp,

                            fontWeight = FontWeight.Bold

                        )

                    }

                    Box(

                        modifier = Modifier

                            .clip(RoundedCornerShape(6.dp))

                            .background(if (tuneStatus.isAppMarketUpdateBlocked) MagicAmber.copy(alpha = 0.22f) else MagicEmerald.copy(alpha = 0.22f))

                            .padding(horizontal = 7.dp, vertical = 3.dp)

                    ) {

                        Text(

                            text = if (tuneStatus.isAppMarketUpdateBlocked) "ĐANG CHẶN CHỢ APP" else "ĐÃ MỞ CẬP NHẬT",

                            color = if (tuneStatus.isAppMarketUpdateBlocked) MagicAmber else MagicEmerald,

                            fontSize = 9.sp,

                            fontWeight = FontWeight.Black

                        )

                    }

                }



                Text(

                    text = if (tuneStatus.isAppMarketUpdateBlocked)

                        "Đã chặn Chợ Honor tự động cập nhật đè ứng dụng Tiếng Việt. Bạn nên giữ trạng thái này để tránh bị mất ngôn ngữ Việt trên các app cài thêm."

                    else

                        "Cửa hàng ứng dụng có thể tự động cập nhật đè app Tiếng Việt sang bản Trung Quốc. Hãy bấm chặn bên dưới để đảm bảo an toàn.",

                    color = TextSecondary,

                    fontSize = 11.sp,

                    lineHeight = 16.sp

                )



                Row(

                    modifier = Modifier.fillMaxWidth(),

                    horizontalArrangement = Arrangement.SpaceBetween,

                    verticalAlignment = Alignment.CenterVertically

                ) {

                    Button(

                        onClick = {

                            try {

                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://drive.google.com/drive/folders/1WLsS-OlxvKFUWzMPxnkrNn8kmlVIY6-k")).apply {

                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

                                }

                                context.startActivity(intent)

                            } catch (_: Exception) {}

                        },

                        modifier = Modifier.defaultMinSize(minHeight = 40.dp),

                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 4.dp),

                        shape = RoundedCornerShape(10.dp),

                        colors = ButtonDefaults.buttonColors(

                            containerColor = MagicSurfaceCard,

                            contentColor = MagicCyanLight

                        ),

                        border = androidx.compose.foundation.BorderStroke(1.dp, MagicCyan.copy(alpha = 0.5f))

                    ) {

                        Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(15.dp), tint = MagicCyanLight)

                        Spacer(modifier = Modifier.width(5.dp))

                        Text(

                            text = "Kiểm Tra Bản Cập Nhật",

                            fontSize = 11.sp,

                            fontWeight = FontWeight.Bold

                        )

                    }

                    if (tuneStatus.isAppMarketUpdateBlocked) {

                        Button(

                            onClick = onUnblockAppMarketUpdates,

                            enabled = true,

                            modifier = Modifier.defaultMinSize(minHeight = 40.dp),

                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 4.dp),

                            shape = RoundedCornerShape(10.dp),

                            colors = ButtonDefaults.buttonColors(

                                containerColor = MagicEmerald,

                                contentColor = Color(0xFF020617)

                            )

                        ) {

                            Icon(imageVector = Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))

                            Spacer(modifier = Modifier.width(6.dp))

                            Text(

                                text = "MỞ LẠI CẬP NHẬT APP",

                                fontSize = 11.sp,

                                fontWeight = FontWeight.Black

                            )

                        }

                    } else {

                        Button(

                            onClick = onBlockAppMarketUpdates,

                            enabled = true,

                            modifier = Modifier.defaultMinSize(minHeight = 40.dp),

                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 4.dp),

                            shape = RoundedCornerShape(10.dp),

                            colors = ButtonDefaults.buttonColors(

                                containerColor = MagicSurfaceCard,

                                contentColor = MagicAmber

                            ),

                            border = androidx.compose.foundation.BorderStroke(1.dp, MagicAmber.copy(alpha = 0.5f))

                        ) {

                            Icon(imageVector = Icons.Default.Block, contentDescription = null, modifier = Modifier.size(16.dp))

                            Spacer(modifier = Modifier.width(6.dp))

                            Text(

                                text = "Chặn Chợ App Tự Cập Nhật",

                                fontSize = 11.sp,

                                fontWeight = FontWeight.Bold

                            )

                        }

                    }

                }

            }

        }



        // Tự Động Kích Hoạt Mọi Phương Án Làm Mát Khi Vượt 35°C


        // Ô #22B: CÀI ĐẶT APK SIÊU TỐC QUA GỠ LỖI WLAN / SHIZUKU

        Card(

            modifier = Modifier

                .fillMaxWidth()

                .testTag("wlan_fast_apk_installer_card"),

            shape = RoundedCornerShape(16.dp),

            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),

            border = androidx.compose.foundation.BorderStroke(

                1.5.dp,

                Brush.linearGradient(listOf(MagicAmber, MagicCyan))

            )

        ) {

            Column(

                modifier = Modifier

                    .fillMaxWidth()

                    .padding(14.dp)

            ) {

                Row(

                    modifier = Modifier.fillMaxWidth(),

                    verticalAlignment = Alignment.CenterVertically,

                    horizontalArrangement = Arrangement.SpaceBetween

                ) {

                    Row(

                        verticalAlignment = Alignment.CenterVertically,

                        horizontalArrangement = Arrangement.spacedBy(8.dp)

                    ) {

                        Box(

                            modifier = Modifier

                                .size(36.dp)

                                .clip(RoundedCornerShape(10.dp))

                                .background(Brush.linearGradient(listOf(MagicAmber.copy(alpha = 0.2f), MagicCyan.copy(alpha = 0.2f)))),

                            contentAlignment = Alignment.Center

                        ) {

                            Icon(

                                imageVector = Icons.Filled.Download,

                                contentDescription = "Fast APK Installer",

                                tint = MagicAmber,

                                modifier = Modifier.size(20.dp)

                            )

                        }

                        Column {

                            Text(

                                text = "⚡ CÀI APK SIÊU TỐC QUA WLAN",

                                color = Color.White,

                                fontSize = 14.sp,

                                fontWeight = FontWeight.Bold

                            )

                            Text(

                                text = "Cài tự động trong 1 giây & hiện ngay ra màn hình chính",

                                color = TextSecondary,

                                fontSize = 11.5.sp

                            )

                        }

                    }

                    Box(

                        modifier = Modifier

                            .clip(RoundedCornerShape(6.dp))

                            .background(MagicAmber.copy(alpha = 0.15f))

                            .padding(horizontal = 7.dp, vertical = 3.dp)

                    ) {

                        Text(

                            text = "Ô #22B",

                            color = MagicAmber,

                            fontSize = 10.5.sp,

                            fontWeight = FontWeight.Black

                        )

                    }

                }



                Spacer(modifier = Modifier.height(10.dp))



                Text(

                    text = "Ấn chọn file APK để cài đặt trực tiếp siêu tốc thông qua Gỡ lỗi WLAN / ADB trực tiếp, bỏ qua bước bấm xác nhận và ứng dụng tự động hiển thị ra màn hình chính ngay sau khi hoàn thành.",

                    color = Color(0xFFD1D5DB),

                    fontSize = 11.5.sp,

                    lineHeight = 16.sp

                )



                if (installStatusText.isNotEmpty()) {

                    Spacer(modifier = Modifier.height(8.dp))

                    Box(

                        modifier = Modifier

                            .fillMaxWidth()

                            .clip(RoundedCornerShape(8.dp))

                            .background(Color(0xFF1E293B))

                            .padding(horizontal = 10.dp, vertical = 6.dp)

                    ) {

                        Text(

                            text = installStatusText,

                            color = if (isInstallingApk) MagicCyan else MagicAmber,

                            fontSize = 11.sp,

                            fontWeight = FontWeight.Medium

                        )

                    }

                }



                Spacer(modifier = Modifier.height(12.dp))



                Button(

                    onClick = {

                        try {

                            apkPickerLauncher.launch("application/vnd.android.package-archive")

                        } catch (e: Exception) {

                            try {

                                apkPickerLauncher.launch("*/*")

                            } catch (e2: Exception) {

                                Toast.makeText(context, "Không mở được trình chọn tệp: ${e2.message}", Toast.LENGTH_SHORT).show()

                            }

                        }

                    },

                    enabled = !isInstallingApk,

                    modifier = Modifier.fillMaxWidth(),

                    shape = RoundedCornerShape(10.dp),

                    colors = ButtonDefaults.buttonColors(

                        containerColor = MagicAmber,

                        contentColor = Color.Black

                    )

                ) {

                    Icon(

                        imageVector = Icons.Filled.Download,

                        contentDescription = null,

                        modifier = Modifier.size(16.dp),

                        tint = Color.Black

                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    Text(

                        text = if (isInstallingApk) "Đang cài đặt siêu tốc..." else "CHỌN FILE APK & CÀI NGAY",

                        fontWeight = FontWeight.Bold,

                        fontSize = 12.5.sp

                    )

                }

            }

        }




        // Ô #25: THÔNG SỐ PHẦN CỨNG & TRẠNG THÁI TÍNH NĂNG (HIỂN THỊ TRỰC TIẾP 100%)

        HardwareAndFeaturesCard(

            deviceInfo = deviceInfo,

            onRefresh = onRefreshDeviceInfo,

            cardNumberBadge = "Ô #25"

        )

        }
        }

        // ==========================================
        // NHÓM 4: TỰ ĐỘNG HÓA & TÁC VỤ NGẦM
        // ==========================================
        CollapsibleSectionHeader(
            title = "TỰ ĐỘNG HÓA & TÁC VỤ NGẦM",
            subtitle = "Kịch bản Macro, Mô phỏng đa nhiệm & Dọn tác vụ ngầm",
            badgeText = "NHÓM 4 (Ô #39)",
            badgeColor = MagicAmber,
            icon = androidx.compose.material.icons.Icons.Default.FlashOn,
            isExpanded = isGroup4Expanded,
            onToggle = { isGroup4Expanded = !isGroup4Expanded }
        ) {
        Card(

            modifier = Modifier

                .fillMaxWidth()

                .testTag("system_automation_macro_card"),

            shape = RoundedCornerShape(16.dp),

            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),

            border = androidx.compose.foundation.BorderStroke(1.2.dp, MagicAmber.copy(alpha = 0.6f))

        ) {

            Column(

                modifier = Modifier

                    .fillMaxWidth()

                    .padding(12.dp),

                verticalArrangement = Arrangement.spacedBy(8.dp)

            ) {

                Row(

                    modifier = Modifier.fillMaxWidth(),

                    horizontalArrangement = Arrangement.SpaceBetween,

                    verticalAlignment = Alignment.CenterVertically

                ) {

                    Row(

                        verticalAlignment = Alignment.CenterVertically,

                        horizontalArrangement = Arrangement.spacedBy(6.dp),

                        modifier = Modifier.weight(1f)

                    ) {

                        Box(

                            modifier = Modifier

                                .clip(RoundedCornerShape(6.dp))

                                .background(MagicCyan.copy(alpha = 0.22f))

                                .border(1.dp, MagicCyan.copy(alpha = 0.6f), RoundedCornerShape(6.dp))

                                .padding(horizontal = 7.dp, vertical = 2.dp)

                        ) {

                            Text(

                                text = "Ô #39",

                                color = MagicCyanLight,

                                fontSize = 10.sp,

                                fontWeight = FontWeight.Black

                            )

                        }

                        Icon(imageVector = Icons.Default.FlashOn, contentDescription = null, tint = MagicAmber, modifier = Modifier.size(18.dp))

                        Text(

                            text = "Tự Động Hóa & Mô Phỏng Điều Khiển Hệ Thống",

                            modifier = Modifier.weight(1f),

                            color = Color.White,

                            fontSize = 13.5.sp,

                            fontWeight = FontWeight.Black,

                            softWrap = true

                        )

                    }

                }



                Text(

                    text = "Kịch bản hóa các tác vụ hệ thống, mô phỏng thao tác cảm ứng/phím cứng (input keyevent / tap / swipe) và thực thi luồng logic tự động lập trình sẵn.",

                    color = TextSecondary,

                    fontSize = 11.sp,

                    lineHeight = 15.5.sp,

                    softWrap = true

                )



                Box(

                    modifier = Modifier

                        .fillMaxWidth()

                        .clip(RoundedCornerShape(8.dp))

                        .background(MagicSurfaceCard)

                        .padding(horizontal = 10.dp, vertical = 6.dp)

                ) {

                    Text(

                        text = "⚡ Kịch bản gần nhất: ${tuneStatus.activeAutomationMacro}",

                        color = MagicAmberLight,

                        fontSize = 10.5.sp,

                        fontWeight = FontWeight.Bold

                    )

                }



                Row(

                    modifier = Modifier.fillMaxWidth(),

                    horizontalArrangement = Arrangement.spacedBy(8.dp)

                ) {

                    Button(

                        onClick = { onRunAutomationMacro("RAM_PURGE_BOOST") },

                        modifier = Modifier

                            .weight(1f)

                            .defaultMinSize(minHeight = 78.dp)

                            .testTag("macro_ram_purge_button"),

                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 8.dp),

                        shape = RoundedCornerShape(12.dp),

                        colors = ButtonDefaults.buttonColors(

                            containerColor = MagicAmber,

                            contentColor = Color(0xFF020617)

                        )

                    ) {

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {

                            Text(

                                text = "🚀 KỊCH BẢN GIẢI PHÓNG RAM\n& TỐI ƯU ĐA NHIỆM",

                                fontSize = 10.sp,

                                lineHeight = 13.5.sp,

                                fontWeight = FontWeight.Black,

                                textAlign = TextAlign.Center,

                                softWrap = true

                            )

                            Spacer(modifier = Modifier.height(2.dp))

                            Text(

                                text = "(Kill-all ngầm + Trim Cache)",

                                fontSize = 9.sp,

                                color = Color(0xFF020617).copy(alpha = 0.85f),

                                fontWeight = FontWeight.Bold,

                                textAlign = TextAlign.Center

                            )

                        }

                    }



                    Button(

                        onClick = { onRunAutomationMacro("GAME_TURBO_MACRO") },

                        modifier = Modifier

                            .weight(1f)

                            .defaultMinSize(minHeight = 78.dp)

                            .testTag("macro_game_turbo_button"),

                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 8.dp),

                        shape = RoundedCornerShape(12.dp),

                        colors = ButtonDefaults.buttonColors(

                            containerColor = MagicSurfaceCard,

                            contentColor = MagicCyanLight

                        ),

                        border = androidx.compose.foundation.BorderStroke(1.dp, MagicCyan.copy(alpha = 0.5f))

                    ) {

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {

                            Text(

                                text = "🎮 KỊCH BẢN CHIẾN GAME\n120HZ + CHẶN LÀM PHIỀN",

                                fontSize = 10.sp,

                                lineHeight = 13.5.sp,

                                fontWeight = FontWeight.Black,

                                textAlign = TextAlign.Center,

                                softWrap = true

                            )

                            Spacer(modifier = Modifier.height(2.dp))

                            Text(

                                text = "(Khóa 120Hz + DND Priority)",

                                fontSize = 9.sp,

                                color = TextSecondary,

                                textAlign = TextAlign.Center

                            )

                        }

                    }

                }



                Row(

                    modifier = Modifier.fillMaxWidth(),

                    horizontalArrangement = Arrangement.spacedBy(8.dp)

                ) {

                    Button(

                        onClick = { onRunAutomationMacro("SCREENSHOT_QUICK_KEY") },

                        modifier = Modifier

                            .weight(1f)

                            .defaultMinSize(minHeight = 76.dp)

                            .testTag("macro_screenshot_key_button"),

                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 8.dp),

                        shape = RoundedCornerShape(12.dp),

                        colors = ButtonDefaults.buttonColors(

                            containerColor = MagicSurfaceCard,

                            contentColor = MagicEmeraldLight

                        ),

                        border = androidx.compose.foundation.BorderStroke(1.dp, MagicEmerald.copy(alpha = 0.45f))

                    ) {

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {

                            Text(

                                text = "📸 MÔ PHỎNG PHÍM CỨNG\nCHỤP MÀN HÌNH NGAY",

                                fontSize = 10.sp,

                                lineHeight = 13.5.sp,

                                fontWeight = FontWeight.Black,

                                textAlign = TextAlign.Center,

                                softWrap = true

                            )

                            Spacer(modifier = Modifier.height(2.dp))

                            Text(

                                text = "(Keyevent 120 SYSRQ)",

                                fontSize = 9.sp,

                                color = TextSecondary,

                                textAlign = TextAlign.Center

                            )

                        }

                    }



                    Button(

                        onClick = { onRunAutomationMacro("AUTO_SWIPE_CLEAN_RECENTS") },

                        modifier = Modifier

                            .weight(1f)

                            .defaultMinSize(minHeight = 76.dp)

                            .testTag("macro_clean_recents_button"),

                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 8.dp),

                        shape = RoundedCornerShape(12.dp),

                        colors = ButtonDefaults.buttonColors(

                            containerColor = MagicSurfaceCard,

                            contentColor = MagicPurpleLight

                        ),

                        border = androidx.compose.foundation.BorderStroke(1.dp, MagicPurple.copy(alpha = 0.45f))

                    ) {

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {

                            Text(

                                text = "🔄 MÔ PHỎNG ĐA NHIỆM\n& DỌN TÁC VỤ NGẦM",

                                fontSize = 10.sp,

                                lineHeight = 13.5.sp,

                                fontWeight = FontWeight.Black,

                                textAlign = TextAlign.Center,

                                softWrap = true

                            )

                            Spacer(modifier = Modifier.height(2.dp))

                            Text(

                                text = "(Keyevent 187 + Clean)",

                                fontSize = 9.sp,

                                color = TextSecondary,

                                textAlign = TextAlign.Center

                            )

                        }

                    }

                }

            }

        }



        }

        // Dòng ghi chú nhỏ tối ưu cho Honor + Nút điều hướng tới trang chức năng ngầm đa hãng

        HonorOptimizationDisclaimerFooter(

            onNavigateToUniversalFix = onNavigateToUniversalFix

        )

    }
}
