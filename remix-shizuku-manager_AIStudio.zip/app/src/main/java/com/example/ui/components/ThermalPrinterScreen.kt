package com.example.ui.components

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.core.printer.ConnectionType
import com.example.core.printer.EscPosThermalPrinter
import com.example.core.printer.PrinterConfig
import com.example.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@SuppressLint("MissingPermission")
@Composable
fun ThermalPrinterScreen(
    sharedUri: Uri?,
    isPrinting: Boolean,
    statusMessage: String,
    onSetPrinting: (Boolean) -> Unit,
    onSetStatusMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // SharedPreferences lưu cục bộ nhẹ nhàng trên máy (không cần cơ sở dữ liệu cồng kềnh)
    val printerPrefs = remember { context.getSharedPreferences("magictune_printer_config", Context.MODE_PRIVATE) }

    // Loại kết nối (0: Wi-Fi/LAN, 1: Bluetooth)
    var connectionType by remember {
        mutableStateOf(if (printerPrefs.getInt("printer_conn_type", 0) == 1) ConnectionType.BLUETOOTH else ConnectionType.WIFI_LAN)
    }

    // Khổ giấy in (576 dots = K80 80mm; 384 dots = K57/K58 58mm)
    var paperWidthDots by remember {
        mutableStateOf(printerPrefs.getInt("printer_paper_width_dots", 576))
    }

    // Cấu hình Wi-Fi / LAN
    var printerIp by remember { mutableStateOf(printerPrefs.getString("printer_ip", "192.168.1.200") ?: "192.168.1.200") }
    var printerPort by remember { mutableStateOf(printerPrefs.getString("printer_port", "9100") ?: "9100") }

    // Cấu hình Bluetooth
    var selectedBtAddress by remember { mutableStateOf(printerPrefs.getString("printer_bt_address", "") ?: "") }
    var selectedBtName by remember { mutableStateOf(printerPrefs.getString("printer_bt_name", "") ?: "") }
    var pairedDevices by remember { mutableStateOf<List<BluetoothDevice>>(emptyList()) }

    // Tùy chỉnh in (Mặc định chọn mức 2 "⭐ Đậm vừa" chuẩn nhất cho đơn Shopee & TikTok)
    var autoCut by remember { mutableStateOf(printerPrefs.getBoolean("printer_autocut", true)) }
    var densityLevel by remember { mutableStateOf(printerPrefs.getInt("printer_density", 2)) } // 1..5 (2 = Đậm vừa khuyên dùng)
    var boldFontDilation by remember { mutableStateOf(printerPrefs.getBoolean("printer_bold_font_dilation", false)) }
    var feedLines by remember { mutableStateOf(printerPrefs.getInt("printer_feed_lines", 1)) }
    var marginLeft by remember { mutableStateOf(printerPrefs.getInt("printer_margin_left", 0)) }
    var marginRight by remember { mutableStateOf(printerPrefs.getInt("printer_margin_right", 0)) }

    // Hàm lưu ngay lập tức vào bộ nhớ
    fun saveConfig(
        conn: ConnectionType = connectionType,
        paper: Int = paperWidthDots,
        ip: String = printerIp,
        port: String = printerPort,
        btAddr: String = selectedBtAddress,
        btNm: String = selectedBtName,
        cut: Boolean = autoCut,
        density: Int = densityLevel,
        bold: Boolean = boldFontDilation,
        feed: Int = feedLines,
        mLeft: Int = marginLeft,
        mRight: Int = marginRight
    ) {
        printerPrefs.edit()
            .putInt("printer_conn_type", if (conn == ConnectionType.BLUETOOTH) 1 else 0)
            .putInt("printer_paper_width_dots", paper)
            .putString("printer_ip", ip)
            .putString("printer_port", port)
            .putString("printer_bt_address", btAddr)
            .putString("printer_bt_name", btNm)
            .putBoolean("printer_autocut", cut)
            .putInt("printer_density", density)
            .putBoolean("printer_bold_font_dilation", bold)
            .putInt("printer_feed_lines", feed)
            .putInt("printer_margin_left", mLeft)
            .putInt("printer_margin_right", mRight)
            .apply()
    }

    fun refreshPairedBluetoothDevices() {
        try {
            val btAdapter = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                context.getSystemService(android.bluetooth.BluetoothManager::class.java)?.adapter
            } else {
                @Suppress("DEPRECATION")
                BluetoothAdapter.getDefaultAdapter()
            }
            if (btAdapter != null && btAdapter.isEnabled) {
                val devices = btAdapter.bondedDevices?.toList() ?: emptyList()
                pairedDevices = devices
                if (selectedBtAddress.isBlank() && devices.isNotEmpty()) {
                    selectedBtAddress = devices.first().address
                    selectedBtName = devices.first().name ?: "Máy in Bluetooth"
                    saveConfig(btAddr = selectedBtAddress, btNm = selectedBtName)
                }
            }
        } catch (_: Exception) {}
    }

    val btPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        if (permissions.values.any { it }) {
            refreshPairedBluetoothDevices()
        }
    }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val hasPerm = ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
            if (!hasPerm) {
                btPermissionLauncher.launch(arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN))
            } else {
                refreshPairedBluetoothDevices()
            }
        } else {
            refreshPairedBluetoothDevices()
        }
    }

    // Ảnh gốc và Ảnh Preview Render thời gian thực
    var rawOriginalBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var selectedFileDescription by remember { mutableStateOf("Chưa chọn tệp đơn hàng") }

    // Tạo Bitmap Preview tức thì mỗi khi thay đổi khổ giấy, căn lề hoặc bật chế độ in đậm
    val renderedPreviewBitmap: Bitmap? = remember(rawOriginalBitmap, paperWidthDots, marginLeft, marginRight, boldFontDilation, densityLevel) {
        val original = rawOriginalBitmap ?: return@remember null
        EscPosThermalPrinter.createPreviewBitmap(
            sourceBitmap = original,
            paperWidthDots = paperWidthDots,
            marginLeftDots = marginLeft,
            marginRightDots = marginRight,
            boldFontDilation = boldFontDilation,
            densityLevel = densityLevel
        )
    }

    // Launcher chọn ảnh hoặc file PDF
    val filePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                loadUriToBitmap(context, uri) { bmp, desc ->
                    rawOriginalBitmap = bmp
                    selectedFileDescription = desc
                }
            }
        }
    }

    LaunchedEffect(sharedUri) {
        if (sharedUri != null) {
            loadUriToBitmap(context, sharedUri) { bmp, desc ->
                rawOriginalBitmap = bmp
                selectedFileDescription = "Đã nhận từ ứng dụng chia sẻ: $desc"
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Compact Hero Card: Máy In Hóa Đơn & Đơn Hàng Vận Chuyển
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = androidx.compose.foundation.BorderStroke(
                1.dp,
                Brush.linearGradient(listOf(MagicCyan, MagicBlue))
            )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "Máy In Hóa Đơn (K80 / K57)",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = "In Bill Shopee / TikTok / PDF qua Wi-Fi & Bluetooth",
                        color = TextSecondary,
                        fontSize = 10.5.sp
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(MagicEmerald.copy(alpha = 0.18f))
                        .border(1.dp, MagicEmerald.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = if (paperWidthDots == 576) "K80 (80mm)" else "K57 (58mm)",
                        color = MagicEmerald,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }

        // Card 1: Chọn Khổ Giấy (K80 / K57) & Phương thức kết nối (Wi-Fi / Bluetooth)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = androidx.compose.foundation.BorderStroke(1.dp, MagicBorder)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Lựa chọn Khổ giấy
                Text(text = "CHỌN KHỔ GIẤY IN:", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(
                        576 to "Khổ K80 (80mm - Tiêu Chuẩn)",
                        384 to "Khổ K57 / K58 (58mm - Cầm Tay)"
                    ).forEach { (dots, title) ->
                        val isSelected = paperWidthDots == dots
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) MagicCyan.copy(alpha = 0.2f) else MagicSurfaceCard)
                                .border(1.dp, if (isSelected) MagicCyan else MagicBorder, RoundedCornerShape(8.dp))
                                .clickable {
                                    paperWidthDots = dots
                                    saveConfig(paper = dots)
                                }
                                .padding(vertical = 10.dp, horizontal = 4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = title,
                                color = if (isSelected) MagicCyanLight else TextPrimary,
                                fontSize = 10.5.sp,
                                fontWeight = if (isSelected) FontWeight.Black else FontWeight.Normal,
                                maxLines = 1
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(2.dp))

                // Lựa chọn Phương thức kết nối
                Text(text = "KẾT NỐI MÁY IN QUA:", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (connectionType == ConnectionType.WIFI_LAN) MagicCyan.copy(alpha = 0.2f) else MagicSurfaceCard)
                            .border(1.dp, if (connectionType == ConnectionType.WIFI_LAN) MagicCyan else MagicBorder, RoundedCornerShape(8.dp))
                            .clickable {
                                connectionType = ConnectionType.WIFI_LAN
                                saveConfig(conn = ConnectionType.WIFI_LAN)
                            }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Wifi, contentDescription = null, tint = if (connectionType == ConnectionType.WIFI_LAN) MagicCyan else TextMuted, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "Wi-Fi / LAN (Cổng IP)", color = if (connectionType == ConnectionType.WIFI_LAN) MagicCyanLight else TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (connectionType == ConnectionType.BLUETOOTH) MagicBlue.copy(alpha = 0.25f) else MagicSurfaceCard)
                            .border(1.dp, if (connectionType == ConnectionType.BLUETOOTH) MagicBlue else MagicBorder, RoundedCornerShape(8.dp))
                            .clickable {
                                connectionType = ConnectionType.BLUETOOTH
                                saveConfig(conn = ConnectionType.BLUETOOTH)
                                refreshPairedBluetoothDevices()
                            }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Bluetooth, contentDescription = null, tint = if (connectionType == ConnectionType.BLUETOOTH) MagicBlueLight else TextMuted, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "Bluetooth SPP", color = if (connectionType == ConnectionType.BLUETOOTH) MagicBlueLight else TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // Cấu hình cụ thể theo Phương thức kết nối
                if (connectionType == ConnectionType.WIFI_LAN) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // IP Address Input Box (No text cutoff)
                        Column(modifier = Modifier.weight(2.5f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(text = "ĐỊA CHỈ IP MÁY IN:", color = TextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(44.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color.Black)
                                    .border(1.dp, if (printerIp.isNotBlank()) MagicCyan else MagicBorder, RoundedCornerShape(10.dp))
                                    .padding(horizontal = 12.dp),
                                contentAlignment = Alignment.CenterStart
                            ) {
                                if (printerIp.isEmpty()) {
                                    Text("VD: 192.168.1.200", color = TextMuted, fontSize = 12.sp)
                                }
                                androidx.compose.foundation.text.BasicTextField(
                                    value = printerIp,
                                    onValueChange = {
                                        printerIp = it
                                        saveConfig(ip = it)
                                    },
                                    singleLine = true,
                                    cursorBrush = androidx.compose.ui.graphics.SolidColor(MagicCyan),
                                    textStyle = androidx.compose.ui.text.TextStyle(
                                        color = Color.White,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    ),
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }

                        // Port Input Box (No text cutoff)
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(text = "CỔNG:", color = TextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(44.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color.Black)
                                    .border(1.dp, if (printerPort.isNotBlank()) MagicCyan else MagicBorder, RoundedCornerShape(10.dp))
                                    .padding(horizontal = 10.dp),
                                contentAlignment = Alignment.CenterStart
                            ) {
                                if (printerPort.isEmpty()) {
                                    Text("9100", color = TextMuted, fontSize = 12.sp)
                                }
                                androidx.compose.foundation.text.BasicTextField(
                                    value = printerPort,
                                    onValueChange = {
                                        printerPort = it.filter { c -> c.isDigit() }
                                        saveConfig(port = printerPort)
                                    },
                                    singleLine = true,
                                    cursorBrush = androidx.compose.ui.graphics.SolidColor(MagicCyan),
                                    textStyle = androidx.compose.ui.text.TextStyle(
                                        color = Color.White,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    ),
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }

                    // Nút Kiểm tra kết nối Wi-Fi Máy in
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Nút Tự động tìm IP Máy In trong mạng Wi-Fi
                        Button(
                            onClick = {
                                scope.launch {
                                    onSetStatusMessage("Đang quét dải mạng Wi-Fi để tự động tìm máy in (Cổng 9100)...")
                                    val port = printerPort.trim().toIntOrNull() ?: 9100
                                    val discovered = EscPosThermalPrinter.discoverLocalPrinters(port, context)
                                    if (discovered.isNotEmpty()) {
                                        val firstIp = discovered.first()
                                        printerIp = firstIp
                                        saveConfig(ip = firstIp)
                                        onSetStatusMessage("✅ Tìm thấy ${discovered.size} máy in: ${discovered.joinToString(", ")}. Đã tự động chọn: $firstIp")
                                    } else {
                                        onSetStatusMessage("⚠️ Không tự quét thấy máy in cổng $port. Nếu máy in có IP cố định, hãy nhập tay vào ô trên.")
                                    }
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(36.dp),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MagicEmerald.copy(alpha = 0.2f),
                                contentColor = MagicEmerald
                            ),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MagicEmerald.copy(alpha = 0.5f))
                        ) {
                            Icon(imageVector = Icons.Default.Search, contentDescription = null, modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = "Dò Tìm IP Máy In", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }

                        // Nút Kiểm Tra Kết Nối
                        Button(
                            onClick = {
                                scope.launch {
                                    onSetStatusMessage("Đang kiểm tra kết nối tới máy in ${printerIp.trim()}:${printerPort.trim()}...")
                                    val config = PrinterConfig(
                                        connectionType = ConnectionType.WIFI_LAN,
                                        ip = printerIp.trim(),
                                        port = printerPort.trim().toIntOrNull() ?: 9100
                                    )
                                    val res = EscPosThermalPrinter.testConnection(config, context)
                                    if (res.isSuccess) {
                                        onSetStatusMessage("✅ ${res.getOrNull()}")
                                    } else {
                                        onSetStatusMessage("❌ ${res.exceptionOrNull()?.message}")
                                    }
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(36.dp),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MagicCyan.copy(alpha = 0.2f),
                                contentColor = MagicCyanLight
                            ),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MagicCyan.copy(alpha = 0.5f))
                        ) {
                            Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = "Kiểm Tra Kết Nối", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                } else {
                    // Bluetooth Device Selector
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "DANH SÁCH THIẾT BỊ BLUETOOTH ĐÃ GHÉP NỐI:", color = TextSecondary, fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(MagicSurfaceCard)
                                    .clickable { refreshPairedBluetoothDevices() }
                                    .padding(horizontal = 6.dp, vertical = 3.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(imageVector = Icons.Default.Refresh, contentDescription = null, tint = MagicCyan, modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(text = "Làm mới", color = MagicCyan, fontSize = 9.5.sp)
                                }
                            }
                        }

                        if (pairedDevices.isEmpty()) {
                            Text(
                                text = "⚠️ Không tìm thấy máy in Bluetooth nào đã ghép nối. Vui lòng vào Cài đặt Bluetooth của điện thoại và ghép nối với máy in trước.",
                                color = MagicAmber,
                                fontSize = 10.5.sp,
                                lineHeight = 15.sp
                            )
                        } else {
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                pairedDevices.forEach { dev ->
                                    val isCur = dev.address == selectedBtAddress
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(if (isCur) MagicBlue.copy(alpha = 0.25f) else MagicSurfaceCard)
                                            .border(1.dp, if (isCur) MagicBlue else MagicBorder, RoundedCornerShape(8.dp))
                                            .clickable {
                                                selectedBtAddress = dev.address
                                                selectedBtName = dev.name ?: dev.address
                                                saveConfig(btAddr = dev.address, btNm = selectedBtName)
                                            }
                                            .padding(horizontal = 10.dp, vertical = 7.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column {
                                                Text(text = dev.name ?: "Thiết bị không tên", color = if (isCur) MagicBlueLight else TextPrimary, fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                                                Text(text = dev.address, color = TextMuted, fontSize = 9.5.sp)
                                            }
                                            if (isCur) {
                                                Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = MagicBlueLight, modifier = Modifier.size(16.dp))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Card 2: Tùy chỉnh Cắt Giấy, Tiết Kiệm Giấy, Độ Đậm & Căn Lề Trái/Phải (Gọn gàng tối đa)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = androidx.compose.foundation.BorderStroke(1.dp, MagicBorder)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Tự động cắt giấy + Chọn số dòng đẩy giấy gộp chung trên 1 dòng siêu gọn
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .clickable {
                                autoCut = !autoCut
                                saveConfig(cut = autoCut)
                            }
                            .padding(end = 4.dp)
                    ) {
                        Icon(imageVector = Icons.Default.ContentCut, contentDescription = null, tint = MagicAmber, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "Tự cắt giấy:", color = Color.White, fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.width(6.dp))
                        Switch(
                            checked = autoCut,
                            onCheckedChange = {
                                autoCut = it
                                saveConfig(cut = it)
                            },
                            modifier = Modifier.height(24.dp),
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = MagicEmerald
                            )
                        )
                    }

                    // Tùy chọn đẩy giấy
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        listOf(0 to "0 dòng (Sát)", 1 to "1 dòng", 2 to "2 dòng").forEach { (lines, label) ->
                            val isCur = feedLines == lines
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isCur) MagicEmerald.copy(alpha = 0.25f) else MagicSurfaceCard)
                                    .border(1.dp, if (isCur) MagicEmerald else MagicBorder, RoundedCornerShape(6.dp))
                                    .clickable {
                                        feedLines = lines
                                        saveConfig(feed = lines)
                                    }
                                    .padding(horizontal = 6.dp, vertical = 4.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = label,
                                    color = if (isCur) MagicEmerald else TextPrimary,
                                    fontSize = 9.sp,
                                    fontWeight = if (isCur) FontWeight.Black else FontWeight.Normal
                                )
                            }
                        }
                    }
                }

                // Độ đậm nét nhiệt: Hàng 1 (Nhạt, ⭐ Đậm vừa, Đậm) & Hàng 2 (Đậm tăng cường & Siêu đậm)
                Text(
                    text = "ĐỘ ĐẬM NÉT NHIỆT (KHUYÊN DÙNG '⭐ ĐẬM VỪA' CHO ĐƠN SHOPEE & TIKTOK):",
                    color = MagicAmber,
                    fontSize = 10.5.sp,
                    fontWeight = FontWeight.Black,
                    softWrap = true
                )

                // Hàng 1: 3 mức chuẩn (Nổi bật mức 2: ⭐ Đậm vừa)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(
                        1 to "Nhạt",
                        2 to "⭐ Đậm vừa",
                        3 to "Đậm"
                    ).forEach { (lvl, title) ->
                        val isSelected = densityLevel == lvl
                        val isRecommended = lvl == 2
                        val activeBorder = if (isRecommended) MagicEmerald else MagicCyan
                        val activeBg = if (isRecommended) MagicEmerald.copy(alpha = 0.22f) else MagicCyan.copy(alpha = 0.2f)
                        val activeText = if (isRecommended) MagicEmerald else MagicCyanLight
                        Box(
                            modifier = Modifier
                                .weight(if (isRecommended) 1.35f else 1f)
                                .clip(RoundedCornerShape(7.dp))
                                .background(if (isSelected) activeBg else MagicSurfaceCard)
                                .border(1.dp, if (isSelected) activeBorder else MagicBorder, RoundedCornerShape(7.dp))
                                .clickable {
                                    densityLevel = lvl
                                    saveConfig(density = lvl)
                                }
                                .padding(vertical = 8.dp, horizontal = 4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (isRecommended && isSelected) "⭐ Đậm vừa (Chuẩn)" else title,
                                color = if (isSelected) activeText else TextPrimary,
                                fontSize = 10.5.sp,
                                fontWeight = if (isSelected || isRecommended) FontWeight.Black else FontWeight.Normal,
                                softWrap = true
                            )
                        }
                    }
                }

                // Hàng 2: Lựa chọn Ép Đậm Phần Cứng cho Giấy Bắt Nhiệt Kém
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val isLvl4 = densityLevel == 4
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(7.dp))
                            .background(if (isLvl4) MagicAmber.copy(alpha = 0.25f) else MagicSurfaceCard)
                            .border(1.dp, if (isLvl4) MagicAmber else MagicBorder, RoundedCornerShape(7.dp))
                            .clickable {
                                densityLevel = 4
                                saveConfig(density = 4)
                            }
                            .padding(vertical = 7.dp, horizontal = 4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (isLvl4) "⚡ ĐẬM TĂNG CƯỜNG (BẬT)" else "⚡ Đậm Tăng Cường",
                            color = if (isLvl4) MagicAmberLight else TextPrimary,
                            fontSize = 10.sp,
                            fontWeight = if (isLvl4) FontWeight.Black else FontWeight.Bold
                        )
                    }

                    val isLvl5 = densityLevel == 5
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(7.dp))
                            .background(if (isLvl5) Color(0xFFEF4444).copy(alpha = 0.25f) else MagicSurfaceCard)
                            .border(1.dp, if (isLvl5) Color(0xFFEF4444) else MagicBorder, RoundedCornerShape(7.dp))
                            .clickable {
                                densityLevel = 5
                                saveConfig(density = 5)
                            }
                            .padding(vertical = 7.dp, horizontal = 4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (isLvl5) "🔥 SIÊU ĐẬM (GIẤY XẤU)" else "🔥 Siêu Đậm (Giấy Kém)",
                            color = if (isLvl5) Color(0xFFFCA5A5) else TextPrimary,
                            fontSize = 10.sp,
                            fontWeight = if (isLvl5) FontWeight.Black else FontWeight.Bold
                        )
                    }
                }

                // Hộp nhắc nhở quan trọng cho người dùng in hóa đơn Shopee & TikTok
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(
                            if (densityLevel == 2) MagicEmerald.copy(alpha = 0.12f)
                            else MagicAmber.copy(alpha = 0.14f)
                        )
                        .border(
                            1.dp,
                            if (densityLevel == 2) MagicEmerald.copy(alpha = 0.45f)
                            else MagicAmber.copy(alpha = 0.55f),
                            RoundedCornerShape(10.dp)
                        )
                        .clickable {
                            if (densityLevel != 2) {
                                densityLevel = 2
                                saveConfig(density = 2)
                            }
                        }
                        .padding(horizontal = 10.dp, vertical = 8.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        Text(
                            text = if (densityLevel == 2) {
                                "✅ ĐANG CHỌN '⭐ ĐẬM VỪA' — CHUẨN TỐI ƯU NHẤT CHO ĐƠN SHOPEE & TIKTOK"
                            } else {
                                "💡 NHẮC NHỞ IN HÓA ĐƠN SHOPEE & TIKTOK (BẤM ĐỂ CHỌN '⭐ ĐẬM VỪA')"
                            },
                            color = if (densityLevel == 2) MagicEmerald else MagicAmber,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            softWrap = true
                        )
                        Text(
                            text = "Khi in phiếu gửi hàng / hóa đơn Shopee và TikTok Shop, bạn nên chọn chế độ '⭐ Đậm vừa' thay vì chọn 'Đậm' hay 'Siêu đậm'. Chế độ 'Đậm vừa' giữ nét chữ & mã vạch / mã QR thanh thoát, không bị tràn mực nhiệt hay sụt áp làm nhạt nét, giúp súng bắn mã vạch của bưu tá quét nhạy 100%!",
                            color = TextSecondary,
                            fontSize = 10.5.sp,
                            lineHeight = 15.sp,
                            softWrap = true
                        )
                    }
                }

                // Chế độ in đậm nét chữ ảnh / PDF - Chữ BẬT/TẮT đứng ở một hàng riêng biệt, không bị bóp nghẽn
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (boldFontDilation) MagicCyan.copy(alpha = 0.15f) else MagicSurfaceCard)
                        .border(1.dp, if (boldFontDilation) MagicCyan else MagicBorder, RoundedCornerShape(8.dp))
                        .clickable {
                            val newVal = !boldFontDilation
                            boldFontDilation = newVal
                            saveConfig(bold = newVal)
                        }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(1.dp)
                        ) {
                            Text(
                                text = "🔤 In Đậm Nét Chữ Ảnh & PDF (+1 Dot)",
                                color = if (boldFontDilation) MagicCyanLight else TextPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(3.dp))
                                        .background(if (boldFontDilation) MagicCyan else Color.DarkGray)
                                        .padding(horizontal = 4.dp, vertical = 1.dp)
                                ) {
                                    Text(
                                        text = if (boldFontDilation) "ĐANG BẬT" else "ĐANG TẮT",
                                        color = if (boldFontDilation) Color.Black else Color.LightGray,
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                                Text(
                                    text = "Dilation nét chữ Shopee, TikTok, Hóa đơn",
                                    color = TextMuted,
                                    fontSize = 9.sp,
                                    maxLines = 1,
                                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                                )
                            }
                        }
                        Switch(
                            checked = boldFontDilation,
                            onCheckedChange = { newVal ->
                                boldFontDilation = newVal
                                saveConfig(bold = newVal)
                            },
                            modifier = Modifier.scale(0.72f),
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = MagicCyan,
                                uncheckedThumbColor = Color.Gray,
                                uncheckedTrackColor = MagicSurfaceDark
                            )
                        )
                    }
                }

                // Tùy chỉnh Căn lề Trái / Phải (Mặc định 0 px tràn đầy màn hình xem trước)
                Text(text = "CĂN CHỈNH LỀ GIẤY TRÁI / PHẢI (THAY ĐỔI TỨC THÌ):", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(text = "Lề Trái:", color = TextMuted, fontSize = 10.5.sp)
                            Text(text = "$marginLeft px", color = MagicCyan, fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf(0 to "0px (Full)", 16 to "16px", 32 to "32px").forEach { (valMargin, label) ->
                                val isCur = marginLeft == valMargin
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (isCur) MagicCyan.copy(alpha = 0.25f) else MagicSurfaceCard)
                                        .border(1.dp, if (isCur) MagicCyan else MagicBorder, RoundedCornerShape(6.dp))
                                        .clickable {
                                            marginLeft = valMargin
                                            saveConfig(mLeft = valMargin)
                                        }
                                        .padding(vertical = 6.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(text = label, color = if (isCur) MagicCyanLight else TextPrimary, fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(text = "Lề Phải:", color = TextMuted, fontSize = 10.5.sp)
                            Text(text = "$marginRight px", color = MagicCyan, fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf(0 to "0px (Full)", 16 to "16px", 32 to "32px").forEach { (valMargin, label) ->
                                val isCur = marginRight == valMargin
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (isCur) MagicCyan.copy(alpha = 0.25f) else MagicSurfaceCard)
                                        .border(1.dp, if (isCur) MagicCyan else MagicBorder, RoundedCornerShape(6.dp))
                                        .clickable {
                                            marginRight = valMargin
                                            saveConfig(mRight = valMargin)
                                        }
                                        .padding(vertical = 6.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(text = label, color = if (isCur) MagicCyanLight else TextPrimary, fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Card 3: Chọn File & Màn Hình Xem Trước (Phản hồi tức thì)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = androidx.compose.foundation.BorderStroke(1.dp, if (renderedPreviewBitmap != null) MagicEmerald else MagicBorder)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "Màn Hình Xem Trước Bản In", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)

                    Button(
                        onClick = { filePicker.launch("*/*") },
                        modifier = Modifier.height(36.dp),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MagicSurfaceCard,
                            contentColor = MagicCyan
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MagicCyan.copy(alpha = 0.4f))
                    ) {
                        Icon(imageVector = Icons.Default.FileOpen, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "Chọn File / Ảnh", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Text(
                    text = selectedFileDescription,
                    color = if (renderedPreviewBitmap != null) MagicEmeraldLight else TextMuted,
                    fontSize = 11.sp
                )

                // Khung hiển thị Xem trước bản in (Tăng chiều cao linh hoạt, hỗ trợ cuộn dọc trọn vẹn toàn bộ đơn hàng dài)
                val previewScrollState = rememberScrollState()
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 220.dp, max = 380.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color.White)
                        .border(1.dp, MagicBorder, RoundedCornerShape(10.dp))
                        .padding(2.dp)
                        .verticalScroll(previewScrollState),
                    contentAlignment = Alignment.TopCenter
                ) {
                    if (renderedPreviewBitmap != null) {
                        Image(
                            bitmap = renderedPreviewBitmap.asImageBitmap(),
                            contentDescription = "Xem trước bản in",
                            modifier = Modifier.fillMaxWidth(),
                            contentScale = ContentScale.FillWidth // Hiển thị full chiều ngang và cuộn dọc không bị cắt
                        )
                    } else {
                        Column(
                            modifier = Modifier.padding(top = 90.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Print, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(36.dp))
                            Text(text = "Chưa có đơn hàng để in", color = Color.DarkGray, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text(text = "Chia sẻ từ Shopee, TikTok hoặc bấm 'Chọn File / Ảnh' ở trên", color = Color.Gray, fontSize = 10.5.sp)
                        }
                    }
                }

                // Nút Thực Thi In Ngay
                Button(
                    onClick = {
                        val rawBmp = rawOriginalBitmap
                        if (rawBmp != null) {
                            onSetPrinting(true)
                            val targetDesc = if (connectionType == ConnectionType.BLUETOOTH) "Bluetooth: $selectedBtName" else "Wi-Fi: $printerIp:$printerPort"
                            onSetStatusMessage("Đang kết nối tới máy in ($targetDesc)...")
                            scope.launch {
                                val config = PrinterConfig(
                                    connectionType = connectionType,
                                    ip = printerIp.trim(),
                                    port = printerPort.trim().toIntOrNull() ?: 9100,
                                    bluetoothAddress = selectedBtAddress.trim(),
                                    paperWidthDots = paperWidthDots,
                                    autoCut = autoCut,
                                    densityLevel = densityLevel,
                                    boldFontDilation = boldFontDilation,
                                    feedLinesAfterPrint = feedLines,
                                    marginLeftDots = marginLeft,
                                    marginRightDots = marginRight
                                )
                                val res = EscPosThermalPrinter.printBitmapToEscPos(rawBmp, config, context)
                                onSetPrinting(false)
                                if (res.isSuccess) {
                                    onSetStatusMessage("✅ ${res.getOrNull()}")
                                } else {
                                    val errorMsg = res.exceptionOrNull()?.message ?: "Lỗi kết nối máy in"
                                    val hint = if (errorMsg.contains("EHOSTUNREACH") || errorMsg.contains("No route")) {
                                        "\n💡 Gợi ý: Hãy tắt tính năng 'AP Isolation' trên Router Wi-Fi và đảm bảo điện thoại đang bắt đúng băng tần Wi-Fi 2.4GHz giống máy in!"
                                    } else ""
                                    onSetStatusMessage("❌ $errorMsg$hint")
                                }
                            }
                        } else {
                            onSetStatusMessage("⚠️ Hãy chọn một tệp đơn hàng hoặc ảnh trước khi bấm in!")
                        }
                    },
                    enabled = !isPrinting && renderedPreviewBitmap != null,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MagicCyan,
                        contentColor = Color(0xFF020617)
                    )
                ) {
                    if (isPrinting) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color(0xFF020617), strokeWidth = 2.dp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = "ĐANG TRUYỀN DỮ LIỆU ĐẾN MÁY IN...", fontSize = 11.5.sp, fontWeight = FontWeight.Black)
                    } else {
                        Icon(imageVector = Icons.Default.Print, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        val paperLabel = if (paperWidthDots == 576) "K80" else "K57"
                        Text(text = "ẤN ĐỂ IN BILL $paperLabel NGAY", fontSize = 12.sp, fontWeight = FontWeight.Black)
                    }
                }

                if (statusMessage.isNotBlank()) {
                    Text(
                        text = statusMessage,
                        color = if (statusMessage.startsWith("✅")) MagicEmeraldLight else if (statusMessage.startsWith("❌")) MagicRoseLight else TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        softWrap = true
                    )
                }
            }
        }
    }
}

private suspend fun loadUriToBitmap(
    context: Context,
    uri: Uri,
    onLoaded: (Bitmap?, String) -> Unit
) = withContext(Dispatchers.IO) {
    try {
        val type = context.contentResolver.getType(uri) ?: ""
        if (type.contains("pdf", ignoreCase = true) || uri.toString().endsWith(".pdf", ignoreCase = true)) {
            val bmp = EscPosThermalPrinter.renderPdfFirstPageToBitmap(context, uri)
            withContext(Dispatchers.Main) {
                onLoaded(bmp, "Tệp PDF Shopee / TikTok (Trang 1)")
            }
        } else {
            val inputStream = context.contentResolver.openInputStream(uri)
            val bmp = BitmapFactory.decodeStream(inputStream)
            inputStream?.close()
            withContext(Dispatchers.Main) {
                onLoaded(bmp, "Ảnh đơn hàng vận chuyển")
            }
        }
    } catch (e: Exception) {
        withContext(Dispatchers.Main) {
            onLoaded(null, "Lỗi đọc tệp: ${e.message}")
        }
    }
}
