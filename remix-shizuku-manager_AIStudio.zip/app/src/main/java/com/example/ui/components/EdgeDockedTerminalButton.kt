package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.spring
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MagicCyan
import com.example.ui.theme.MagicRose
import kotlin.math.roundToInt

@Composable
fun EdgeDockedTerminalButton(
    isScrolling: Boolean,
    errorCount: Int,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val configuration = LocalConfiguration.current
    val density = LocalDensity.current
    val screenWidthPx = with(density) { configuration.screenWidthDp.dp.toPx() }.coerceAtLeast(300f)
    val screenHeightPx = with(density) { configuration.screenHeightDp.dp.toPx() }.coerceAtLeast(500f)
    val defaultBottomOffsetPx = with(density) { -88.dp.toPx() }
    val minLeftOffsetPx = -(screenWidthPx - with(density) { 56.dp.toPx() }).coerceAtLeast(0f)
    val minTopOffsetPx = -(screenHeightPx - with(density) { 200.dp.toPx() }).coerceAtLeast(0f)

    // Vì nút được đặt với Alignment.BottomEnd trong Box cha,
    // offsetX = 0f là sát mép phải màn hình, offsetY âm là dịch lên trên từ đáy màn hình.
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(defaultBottomOffsetPx) }

    val isOnRight = offsetX > (minLeftOffsetPx / 2f)
    val shape = RoundedCornerShape(
        topStart = if (isOnRight) 16.dp else 0.dp,
        topEnd = if (isOnRight) 0.dp else 16.dp,
        bottomEnd = if (isOnRight) 0.dp else 16.dp,
        bottomStart = if (isOnRight) 16.dp else 0.dp
    )

    Box(
        modifier = modifier
            .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
            .imePadding()
            .pointerInput(minLeftOffsetPx, minTopOffsetPx) {
                detectDragGestures(
                    onDragEnd = {
                        // Tự động hít sát về mép phải (0f) hoặc mép trái (minLeftOffsetPx)
                        offsetX = if (offsetX > (minLeftOffsetPx / 2f)) 0f else minLeftOffsetPx
                    }
                ) { change, dragAmount ->
                    change.consume()
                    offsetX = (offsetX + dragAmount.x).coerceIn(minLeftOffsetPx, 0f)
                    offsetY = (offsetY + dragAmount.y).coerceIn(minTopOffsetPx, 0f)
                }
            }
            .shadow(10.dp, shape)
            .clip(shape)
            .background(Color(0xF20F172A))
            .border(1.5.dp, MagicCyan, shape)
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 8.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(MagicCyan.copy(alpha = 0.25f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Terminal,
                    contentDescription = "Màn hình lệnh ADB",
                    tint = MagicCyan,
                    modifier = Modifier.size(18.dp)
                )
            }

            if (errorCount > 0) {
                Spacer(modifier = Modifier.width(4.dp))
                Box(
                    modifier = Modifier
                        .size(16.dp)
                        .clip(CircleShape)
                        .background(MagicRose),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "$errorCount",
                        color = Color.White,
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }
    }
}
