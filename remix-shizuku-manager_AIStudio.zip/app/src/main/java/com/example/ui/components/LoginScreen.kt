package com.example.ui.components

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.credentials.CredentialManager
import com.example.core.auth.FirebaseAuthManager
import com.example.core.license.LicenseManager
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

@Composable
fun LoginScreen(
    onNavigateBack: () -> Unit,
    onLoginSuccess: () -> Unit,
    onNavigateToAccount: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val credentialManager = remember { CredentialManager.create(context) }
    val scrollState = rememberScrollState()
    val deviceId = remember { LicenseManager.getDeviceId(context) }

    var familiarEmails by remember { mutableStateOf(FirebaseAuthManager.getLocalFamiliarEmails(context)) }
    var isPro by remember { mutableStateOf(LicenseManager.isProActivated(context)) }
    var isAccountPro by remember { mutableStateOf(LicenseManager.isAccountProActivated(context)) }
    var isFamiliarDevice by remember { mutableStateOf(familiarEmails.isNotEmpty() || isPro) }

    var emailInput by remember { mutableStateOf(familiarEmails.firstOrNull() ?: "") }
    var passwordInput by remember { mutableStateOf("") }
    var isPasswordVisible by remember { mutableStateOf(false) }
    var nameInput by remember { mutableStateOf("") }
    var isSignUpMode by remember { mutableStateOf(false) }

    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var successMessage by remember { mutableStateOf<String?>(null) }

    var currentUser by remember { mutableStateOf(FirebaseAuthManager.getCurrentUser()) }

    DisposableEffect(Unit) {
        val receiver = object : android.content.BroadcastReceiver() {
            override fun onReceive(ctx: android.content.Context?, intent: android.content.Intent?) {
                val c = ctx ?: return
                currentUser = FirebaseAuthManager.getCurrentUser()
                isPro = LicenseManager.isProActivated(c)
                isAccountPro = LicenseManager.isAccountProActivated(c)
                if (isPro) isFamiliarDevice = true
            }
        }
        val filter = android.content.IntentFilter().apply {
            addAction(LicenseManager.ACTION_PRO_ACTIVATED)
            addAction(LicenseManager.ACTION_CONFIG_UPDATED)
        }
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            context.registerReceiver(receiver, filter, android.content.Context.RECEIVER_NOT_EXPORTED)
        } else {
            context.registerReceiver(receiver, filter)
        }
        onDispose {
            try { context.unregisterReceiver(receiver) } catch (_: Exception) {}
        }
    }

    // Tự động nhận diện thiết bị quen thuộc (bao gồm cả Máy Pro Vãng Lai & Máy Pro Tài Khoản) ngay cả khi chưa đăng nhập
    LaunchedEffect(Unit) {
        val recognizedCloudPro = LicenseManager.checkDeviceRecognizedProInCloud(context)
        if (recognizedCloudPro) {
            isPro = true
            isAccountPro = LicenseManager.isAccountProActivated(context)
            isFamiliarDevice = true
        }
        val (detectedFamiliar, cloudEmails) = FirebaseAuthManager.fetchFamiliarDeviceEmails(context)
        if (detectedFamiliar) {
            isFamiliarDevice = true
        }
        if (cloudEmails.isNotEmpty()) {
            familiarEmails = cloudEmails
            if (emailInput.isBlank()) {
                emailInput = cloudEmails.first()
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MagicDarkBackground)
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(onClick = onNavigateBack) {
                    Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Quay lại", tint = Color.White)
                }
                Text(
                    text = "Đăng Nhập Tài Khoản",
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black
                )
            }

            Button(
                onClick = onNavigateToAccount,
                colors = ButtonDefaults.buttonColors(containerColor = if (isPro) MagicEmerald else MagicCyan),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(
                    text = if (currentUser != null) "Tài khoản của tôi" else if (isPro) "👑 Máy Đã Lên Pro" else "📱 Bản Quyền Máy",
                    color = Color(0xFF020617),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        val user = currentUser
        if (user != null) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MagicSurfaceCard),
                border = BorderStroke(1.dp, MagicEmerald)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = MagicEmerald, modifier = Modifier.size(48.dp))
                    Text(
                        text = "Bạn đã đăng nhập thành công!",
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Email: ${user.email ?: "Không có"}",
                        color = TextSecondary,
                        fontSize = 13.sp
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = onNavigateToAccount,
                            colors = ButtonDefaults.buttonColors(containerColor = MagicCyan)
                        ) {
                            Text("Xem Cài Đặt Tài Khoản", color = Color(0xFF020617), fontWeight = FontWeight.Bold)
                        }
                        OutlinedButton(
                            onClick = {
                                FirebaseAuthManager.signOut(context, credentialManager, coroutineScope) {
                                    currentUser = null
                                    Toast.makeText(context, "Đã đăng xuất!", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MagicRoseLight)
                        ) {
                            Text("Đăng Xuất")
                        }
                    }
                }
            }
        } else {
            if (isPro) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MagicEmerald.copy(alpha = 0.14f)),
                    border = BorderStroke(1.5.dp, MagicEmerald)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Verified, contentDescription = null, tint = MagicEmerald, modifier = Modifier.size(22.dp))
                            Text(
                                text = if (isAccountPro) "👑 ĐÃ NHẬN DIỆN MÁY QUEN • ĐÃ CẤP LẠI PRO TÀI KHOẢN!" else "👑 ĐÃ NHẬN DIỆN MÁY QUEN ($deviceId) • ĐÃ CẤP LẠI PRO NGAY!",
                                color = MagicEmerald,
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                        Text(
                            text = "Hệ thống đã tự động nhận diện thiết bị $deviceId của bạn từ đám mây (hỗ trợ cả Máy Pro của Tài Khoản Vãng Lai chưa từng đăng nhập lẫn Máy Pro trong danh sách Quản Trị) và mở khóa 100% tính năng Pro ngay lập tức mà KHÔNG bắt buộc phải đăng nhập!",
                            color = Color.White,
                            fontSize = 11.5.sp,
                            lineHeight = 16.sp
                        )
                        Button(
                            onClick = onNavigateToAccount,
                            colors = ButtonDefaults.buttonColors(containerColor = MagicEmerald),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "👑 Xem Chi Tiết Bản Quyền Pro Của Thiết Bị ($deviceId)",
                                color = Color(0xFF020617),
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                }
            }

            // Banner cam kết khôi phục Pro 100% khi đăng nhập
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                border = BorderStroke(1.5.dp, MagicEmerald.copy(alpha = 0.6f))
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Icon(
                        imageVector = Icons.Default.CloudDone,
                        contentDescription = null,
                        tint = MagicEmerald,
                        modifier = Modifier.size(24.dp)
                    )
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = "✨ ĐĂNG NHẬP ĐỂ KHÔI PHỤC 100% BẢN PRO",
                            color = MagicEmerald,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = "Mỗi thiết bị được gắn cố định một Key duy nhất từ Admin/AI. Nếu máy của bạn đã từng được kích hoạt Pro mà lỡ cài lại máy hay không thấy Pro, BẠN CHỈ CẦN ĐĂNG NHẬP TÀI KHOẢN TẠI ĐÂY: Hệ thống đám mây sẽ 100% tự động nhận diện và khôi phục bản Pro ngay lập tức!",
                            color = Color(0xFFE2E8F0),
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )
                    }
                }
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MagicSurfaceCard),
                border = BorderStroke(1.dp, MagicBorder)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isSignUpMode) "Đăng Ký Tài Khoản Mới" else "Đăng Nhập Bằng Email",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        TextButton(
                            onClick = {
                                isSignUpMode = !isSignUpMode
                                errorMessage = null
                                successMessage = null
                            }
                        ) {
                            Text(
                                text = if (isSignUpMode) "Đã có tài khoản? Đăng nhập" else "Chưa có tài khoản? Đăng ký",
                                color = MagicCyanLight,
                                fontSize = 11.sp
                            )
                        }
                    }

                    // Chỉ hiển thị 1 thông báo tại 1 thời điểm (Không bao giờ vừa báo lỗi vừa báo thành công)
                    if (errorMessage != null) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(MagicRose.copy(alpha = 0.15f))
                                .border(1.dp, MagicRose.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                                .padding(10.dp)
                        ) {
                            Text(text = errorMessage!!, color = MagicRoseLight, fontSize = 12.sp)
                        }
                    } else if (successMessage != null) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(MagicEmerald.copy(alpha = 0.15f))
                                .border(1.dp, MagicEmerald.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                                .padding(10.dp)
                        ) {
                            Text(text = successMessage!!, color = MagicEmerald, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Gợi ý Email quen thuộc khi nhận diện được thiết bị quen thuộc
                    if (familiarEmails.isNotEmpty() || isFamiliarDevice) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(MagicCyan.copy(alpha = 0.1f))
                                .border(1.dp, MagicCyan.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                                .padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.VerifiedUser,
                                    contentDescription = null,
                                    tint = MagicEmeraldLight,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = "Thiết bị quen thuộc ($deviceId) • Gợi ý đăng nhập nhanh:",
                                    color = MagicCyanLight,
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            if (familiarEmails.isNotEmpty()) {
                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    familiarEmails.forEach { suggestedEmail ->
                                        val isSelected = emailInput.trim().equals(suggestedEmail, ignoreCase = true)
                                        val isAdminEmail = suggestedEmail.equals("vuongdhkmhn@gmail.com", ignoreCase = true) ||
                                                suggestedEmail.equals("vuongdhkmhn@gmal.com", ignoreCase = true)
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(
                                                    if (isSelected) MagicEmerald.copy(alpha = 0.22f)
                                                    else MagicSurfaceDark
                                                )
                                                .border(
                                                    1.dp,
                                                    if (isSelected) MagicEmerald else MagicCyan.copy(alpha = 0.45f),
                                                    RoundedCornerShape(8.dp)
                                                )
                                                .clickable {
                                                    emailInput = suggestedEmail
                                                    errorMessage = null
                                                }
                                                .padding(horizontal = 10.dp, vertical = 8.dp)
                                                .testTag("familiar_email_chip_$suggestedEmail"),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Email,
                                                    contentDescription = null,
                                                    tint = if (isSelected) MagicEmeraldLight else MagicCyanLight,
                                                    modifier = Modifier.size(15.dp)
                                                )
                                                Text(
                                                    text = suggestedEmail,
                                                    color = Color.White,
                                                    fontSize = 12.5.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(5.dp))
                                                    .background(
                                                        if (isAdminEmail) MagicAmber.copy(alpha = 0.25f)
                                                        else MagicCyan.copy(alpha = 0.2f)
                                                    )
                                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                                            ) {
                                                Text(
                                                    text = if (isAdminEmail) "👑 ADMIN • Chạm chọn" else if (isSelected) "✓ Đã điền" else "Chạm điền nhanh",
                                                    color = if (isAdminEmail) MagicAmberLight else MagicCyanLight,
                                                    fontSize = 9.5.sp,
                                                    fontWeight = FontWeight.Black
                                                )
                                            }
                                        }
                                    }
                                }
                            } else {
                                Text(
                                    text = "Thiết bị này đã từng sử dụng ứng dụng. Sau khi đăng nhập lần đầu, hệ thống sẽ tự động gợi ý Email của bạn tại đây.",
                                    color = TextSecondary,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }

                    if (isLoading) {
                        Box(modifier = Modifier.fillMaxWidth().padding(20.dp), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(color = MagicCyan)
                        }
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            if (isSignUpMode) {
                                OutlinedTextField(
                                    value = nameInput,
                                    onValueChange = { nameInput = it },
                                    modifier = Modifier.fillMaxWidth(),
                                    label = { Text("Họ và Tên") },
                                    singleLine = true,
                                    shape = RoundedCornerShape(8.dp)
                                )
                            }

                            OutlinedTextField(
                                value = emailInput,
                                onValueChange = {
                                    emailInput = it
                                    errorMessage = null
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("login_email_input"),
                                label = { Text("Địa chỉ Email") },
                                trailingIcon = {
                                    if (emailInput.isNotEmpty()) {
                                        IconButton(onClick = { emailInput = "" }) {
                                            Icon(
                                                imageVector = Icons.Default.Clear,
                                                contentDescription = "Xóa email",
                                                tint = TextSecondary
                                            )
                                        }
                                    }
                                },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email, imeAction = ImeAction.Next),
                                shape = RoundedCornerShape(8.dp)
                            )

                            OutlinedTextField(
                                value = passwordInput,
                                onValueChange = {
                                    passwordInput = it
                                    errorMessage = null
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("login_password_input"),
                                label = { Text("Mật khẩu (ít nhất 6 ký tự)") },
                                singleLine = true,
                                visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                trailingIcon = {
                                    IconButton(
                                        onClick = { isPasswordVisible = !isPasswordVisible },
                                        modifier = Modifier.testTag("toggle_password_visibility_button")
                                    ) {
                                        Icon(
                                            imageVector = if (isPasswordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                            contentDescription = if (isPasswordVisible) "Ẩn mật khẩu" else "Hiện mật khẩu đã nhập",
                                            tint = if (isPasswordVisible) MagicEmeraldLight else MagicCyanLight
                                        )
                                    }
                                },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
                                shape = RoundedCornerShape(8.dp)
                            )

                            if (!isSignUpMode) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End
                                ) {
                                    TextButton(
                                        onClick = {
                                            if (emailInput.isBlank()) {
                                                errorMessage = "Vui lòng nhập Email để nhận liên kết khôi phục mật khẩu!"
                                                successMessage = null
                                                return@TextButton
                                            }
                                            isLoading = true
                                            errorMessage = null
                                            successMessage = null
                                            coroutineScope.launch {
                                                try {
                                                    FirebaseAuthManager.getAuth().sendPasswordResetEmail(emailInput.trim()).await()
                                                    successMessage = "Đã gửi email khôi phục mật khẩu tới ${emailInput.trim()}!"
                                                } catch (e: Exception) {
                                                    errorMessage = "Không thể gửi email khôi phục: " + FirebaseAuthManager.translateAuthError(e)
                                                } finally {
                                                    isLoading = false
                                                }
                                            }
                                        }
                                    ) {
                                        Text("Quên mật khẩu?", color = MagicAmber, fontSize = 11.sp)
                                    }
                                }
                            }

                            Button(
                                onClick = {
                                    val cleanEmail = emailInput.trim()
                                    if (cleanEmail.isBlank() || passwordInput.isBlank()) {
                                        errorMessage = "Vui lòng nhập đầy đủ email và mật khẩu!"
                                        successMessage = null
                                        return@Button
                                    }
                                    isLoading = true
                                    errorMessage = null
                                    successMessage = null
                                    coroutineScope.launch {
                                        try {
                                            if (isSignUpMode) {
                                                FirebaseAuthManager.signUpWithEmail(cleanEmail, passwordInput, nameInput)
                                            } else {
                                                FirebaseAuthManager.signInWithEmail(cleanEmail, passwordInput)
                                            }
                                            FirebaseAuthManager.rememberFamiliarEmail(context, cleanEmail)
                                            FirebaseAuthManager.syncUserProfile(context)
                                            LicenseManager.notifyProAndConfigStateChanged(context)
                                            currentUser = FirebaseAuthManager.getCurrentUser()
                                            errorMessage = null
                                            successMessage = if (isSignUpMode) {
                                                "Đăng ký thành công và đã tự động đăng nhập!"
                                            } else {
                                                "Đăng nhập thành công!"
                                            }
                                            Toast.makeText(context, "Đăng nhập thành công!", Toast.LENGTH_SHORT).show()
                                            onLoginSuccess()
                                        } catch (e: Exception) {
                                            successMessage = null
                                            errorMessage = FirebaseAuthManager.translateAuthError(e)
                                        } finally {
                                            isLoading = false
                                        }
                                    }
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("submit_email_login_button"),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MagicCyan)
                            ) {
                                Text(
                                    text = if (isSignUpMode) "Đăng Ký Tài Khoản" else "Đăng Nhập Hệ Thống",
                                    color = Color(0xFF020617),
                                    fontWeight = FontWeight.Black,
                                    fontSize = 14.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
