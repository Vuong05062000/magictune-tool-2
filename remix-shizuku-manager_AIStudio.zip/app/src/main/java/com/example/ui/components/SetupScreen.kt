package com.example.ui.components

import android.content.Intent
import android.provider.Settings
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DeviceInfo
import com.example.data.NewDeviceSetupStatus
import com.example.ui.theme.*

@Composable
fun SetupScreen(
    status: NewDeviceSetupStatus,
    shizukuInfo: com.example.data.ShizukuInfo,
    deviceInfo: DeviceInfo = DeviceInfo(),
    isBusy: Boolean,
    onRunSetupAll: () -> Unit,
    onRunSetupForceFull: () -> Unit = onRunSetupAll,
    onRunSingleSetupItem: (Int) -> Unit,
    onOpenPlayStore: (String) -> Unit,
    onOpenYouTube: () -> Unit = {},
    onRefreshDeviceInfo: () -> Unit = {},
    onOpenPrinter: () -> Unit = {},
    onRestartShizuku: () -> Unit = {},
    onRequestShizukuPermission: () -> Unit = {},
    onOpenShizukuApp: () -> Unit = {},
    onOpenDirectWlanTab: () -> Unit = {},
    onFixMagicOSSystemUpdate: () -> Unit = {},
    onNavigateToUniversalFix: () -> Unit = {}
) {
    val context = LocalContext.current
    var selectedFilter by remember { mutableIntStateOf(0) }

    val items = listOf(
        SetupStepItem(
            1,
            "Ô #03",
            "Tiếng Việt & Giờ Việt Nam 24h",
            "Đổi ngôn ngữ máy sang Tiếng Việt và múi giờ chuẩn GMT+7",
            status.isVietnameseLocale && status.isVietnamTimezone
        ),
        SetupStepItem(
            2,
            "Ô #04",
            "Dịch Vụ Google Play & Đồng Bộ Danh Bạ",
            "Bật CH Play, GMS và tự động đồng bộ danh bạ Google",
            status.gmsEnabled && status.playStoreInstalled
        ),
        SetupStepItem(
            3,
            "Ô #05",
            "Bàn Phím Gõ Tiếng Việt (Laban Key / Gboard)",
            "Kích hoạt bàn phím Tiếng Việt và tắt bàn phím chữ Trung",
            status.labanKeyInstalled || status.gboardInstalled
        ),
        SetupStepItem(
            4,
            "Ô #06",
            "Hiện Tên Người Gọi (+84) & Sửa Chấm Than Wi-Fi",
            "Sửa lỗi gọi đến không hiện tên danh bạ và xóa dấu (!) Wi-Fi",
            status.callerId84Fixed && status.captivePortalGlobal
        ),
        SetupStepItem(
            5,
            "Ô #07",
            "Tắt Sạch Tin Tức & Quảng Cáo Chữ Trung Quốc",
            "Khóa trang HiBoard / tin tức tiếng Trung khi vuốt màn hình",
            status.chineseUiCleaned
        ),
        SetupStepItem(
            6,
            "Ô #08",
            "Đặc Trị Định Vị GPS & Timestamp Camera",
            "Fix chụp ảnh Khu A báo Khu B, cấp đủ 100% quyền & chuyển A-GPS Google",
            status.gpsOptimized
        ),
        SetupStepItem(
            7,
            "Ô #09",
            "Chặn Chợ App Honor Tự Cập Nhật Đè App Việt",
            "Không cho chợ ứng dụng nội địa tự tải đè app Tiếng Việt",
            status.honorMarketUpdateBlocked
        ),
        SetupStepItem(
            8,
            "Ô #10",
            "Mở 100% Chuông Báo Zalo, Messenger, Facebook",
            "Tắt trình diệt ngầm để tin nhắn & cuộc gọi đổ chuông tức thì",
            status.powerGeniusRemoved || status.customAppSoundsEnabled
        )
    )

    val pendingCount = items.count { !it.ok }
    val completedCount = items.count { it.ok }
    val progressFraction = (completedCount / 8f).coerceIn(0f, 1f)

    val sortedItems = remember(items, selectedFilter) {
        when (selectedFilter) {
            1 -> items.filter { !it.ok }
            2 -> items.filter { it.ok }
            else -> items
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Thẻ trạng thái kết nối gọn gàng (Đã khóa Shizuku và chuyển hướng sang Kết Nối Trực Tiếp mã 6 số)
        ShizukuStatusCard(
            shizukuInfo = shizukuInfo,
            onRestart = onRestartShizuku,
            onRequestPermission = onRequestShizukuPermission,
            onOpenApp = onOpenShizukuApp,
            onOpenDirectWlanTab = onOpenDirectWlanTab
        )

        // Ô #01: 1-Chạm Chuẩn Hóa Toàn Bộ Điện Thoại (8-Trong-1)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = androidx.compose.foundation.BorderStroke(
                1.5.dp,
                Brush.linearGradient(listOf(MagicAmber, MagicCyan))
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MagicAmber)
                                .padding(horizontal = 7.dp, vertical = 2.5.dp)
                        ) {
                            Text(
                                text = "Ô #01",
                                color = Color(0xFF020617),
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                        Text(
                            text = "1-CHẠM CHUẨN HÓA TOÀN BỘ MÁY (8-TRONG-1)",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(
                                if (completedCount == 8) MagicEmerald.copy(alpha = 0.2f)
                                else MagicCyan.copy(alpha = 0.2f)
                            )
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "$completedCount/8 mục",
                            color = if (completedCount == 8) MagicEmerald else MagicCyanLight,
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }

                Text(
                    text = "Tự động cài Tiếng Việt, danh bạ +84, xóa rác chữ Trung, fix GPS Timestamp Camera & mở chuông Zalo.",
                    color = TextSecondary,
                    fontSize = 11.5.sp,
                    lineHeight = 16.sp
                )

                LinearProgressIndicator(
                    progress = { progressFraction },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(7.dp)
                        .clip(RoundedCornerShape(99.dp)),
                    color = if (completedCount == 8) MagicEmerald else MagicAmber,
                    trackColor = MagicSurfaceCard
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onRunSetupAll,
                        modifier = Modifier
                            .weight(1.5f)
                            .defaultMinSize(minHeight = 52.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MagicAmber,
                            contentColor = Color(0xFF020617)
                        ),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (pendingCount > 0) "TỰ ĐỘNG CÀI NGAY ($pendingCount MỤC)" else "TỐI ƯU NHANH",
                            fontWeight = FontWeight.Black,
                            fontSize = 12.sp
                        )
                    }

                    OutlinedButton(
                        onClick = onRunSetupForceFull,
                        modifier = Modifier
                            .weight(1f)
                            .defaultMinSize(minHeight = 52.dp),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MagicCyan.copy(alpha = 0.6f)),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MagicCyanLight),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Chạy Lại 8/8",
                            fontWeight = FontWeight.Black,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        // Ô #02: Khôi Phục & Mở Cập Nhật Hệ Điều Hành MagicOS (OUC / HOTA)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = androidx.compose.foundation.BorderStroke(1.2.dp, MagicPurpleLight.copy(alpha = 0.65f))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onFixMagicOSSystemUpdate() }
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MagicPurpleLight)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "Ô #02",
                                color = Color(0xFF020617),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFF10B981))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "FREE",
                                color = Color.White,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                        Text(
                            text = "Khôi Phục & Mở Cập Nhật Hệ Điều Hành MagicOS",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                    Text(
                        text = "Miễn phí 100% cho mọi người dùng: Bật lại gói cập nhật OUC/HOTA bị ẩn hoặc bị tắt trước đó và mở thẳng trang Cập nhật phần mềm MagicOS.",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = onFixMagicOSSystemUpdate,
                    modifier = Modifier.defaultMinSize(minHeight = 40.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MagicPurple,
                        contentColor = Color.White
                    ),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "🔄 Bật & Mở",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }

        // Bộ lọc nhanh cho Ô #03 -> Ô #10 (Hiển thị trực tiếp 100%, không ẩn)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            val filters = listOf(
                0 to "Tất cả 8 ô (#03–#10)",
                1 to "Chưa xong ($pendingCount)",
                2 to "Đã xong ($completedCount)"
            )
            filters.forEach { (id, label) ->
                val active = selectedFilter == id
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (active) MagicCyan.copy(alpha = 0.2f) else MagicSurfaceDark)
                        .border(1.dp, if (active) MagicCyan else MagicBorder, RoundedCornerShape(8.dp))
                        .clickable { selectedFilter = id }
                        .padding(vertical = 7.dp, horizontal = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = label,
                        color = if (active) MagicCyanLight else TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        // Danh sách 8 Ô tính năng cài máy độc lập (Ô #03 -> Ô #10) - Mỗi tính năng 1 ô gọn gàng
        sortedItems.forEach { item ->
            val ok = item.ok
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onRunSingleSetupItem(item.index) },
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (ok) MagicEmerald.copy(alpha = 0.45f) else MagicAmber.copy(alpha = 0.6f)
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(5.dp))
                                    .background(if (ok) MagicEmerald else MagicAmber)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = item.badge,
                                    color = Color(0xFF020617),
                                    fontSize = 9.5.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                            Text(
                                text = item.title,
                                color = if (ok) MagicEmeraldLight else Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = item.subtitle,
                            color = TextSecondary,
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .defaultMinSize(minHeight = 36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (ok) MagicEmerald.copy(alpha = 0.2f) else MagicBlue)
                            .clickable { onRunSingleSetupItem(item.index) }
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (ok) "✓ Chạy lại" else "▶ Cài ngay",
                            color = if (ok) MagicEmerald else Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }
            }
        }

        // Ô #11: Mở Nhanh Cài Đặt Điện Thoại & Máy In Đơn K80
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = androidx.compose.foundation.BorderStroke(1.dp, MagicBorder)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(5.dp))
                            .background(MagicCyan)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "Ô #11",
                            color = Color(0xFF020617),
                            fontSize = 9.5.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                    Text(
                        text = "🛠️ MỞ NHANH CÀI ĐẶT ĐIỆN THOẠI & MÁY IN K80",
                        color = MagicCyanLight,
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.Black
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    QuickSettingShortcutButton(
                        title = "🇻🇳 Tiếng Việt & Vùng",
                        subtitle = "Đổi ngôn ngữ máy",
                        accentColor = MagicCyan,
                        modifier = Modifier.weight(1f),
                        onClick = {
                            try {
                                context.startActivity(
                                    Intent(Settings.ACTION_LOCALE_SETTINGS).apply {
                                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    }
                                )
                            } catch (_: Exception) {}
                        }
                    )
                    QuickSettingShortcutButton(
                        title = "⌨️ Chọn Bàn Phím",
                        subtitle = "Bật gõ Tiếng Việt",
                        accentColor = MagicAmber,
                        modifier = Modifier.weight(1f),
                        onClick = {
                            try {
                                context.startActivity(
                                    Intent(Settings.ACTION_INPUT_METHOD_SETTINGS).apply {
                                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    }
                                )
                            } catch (_: Exception) {}
                        }
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    QuickSettingShortcutButton(
                        title = "👤 Tài Khoản Google",
                        subtitle = "Đồng bộ số danh bạ",
                        accentColor = MagicEmerald,
                        modifier = Modifier.weight(1f),
                        onClick = {
                            try {
                                context.startActivity(
                                    Intent(Settings.ACTION_SYNC_SETTINGS).apply {
                                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    }
                                )
                            } catch (_: Exception) {}
                        }
                    )
                    QuickSettingShortcutButton(
                        title = "🖨️ Máy In Đơn K80",
                        subtitle = "In đơn hàng & hóa đơn",
                        accentColor = MagicBlue,
                        modifier = Modifier.weight(1f),
                        onClick = onOpenPrinter
                    )
                }
            }
        }

        // Ô #12: Tải Nhanh Ứng Dụng Quen Thuộc (1 Chạm)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = androidx.compose.foundation.BorderStroke(1.dp, MagicBorder)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(5.dp))
                            .background(MagicCyan)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "Ô #12",
                            color = Color(0xFF020617),
                            fontSize = 9.5.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                    Text(
                        text = "📲 TẢI ỨNG DỤNG QUEN THUỘC TRÊN CH PLAY (1 CHẠM)",
                        color = MagicCyan,
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.Black
                    )
                }

                val vnApps = listOf(
                    "💬 Zalo" to "com.zing.zalo",
                    "📘 Facebook" to "com.facebook.katana",
                    "⚡ Messenger" to "com.facebook.orca",
                    "▶️ YouTube" to "com.google.android.youtube",
                    "⌨️ Laban Key" to "com.vng.inputmethod.labankey",
                    "🛒 Lazada" to "com.lazada.android",
                    "🗺️ Bản đồ Maps" to "com.google.android.apps.maps",
                    "🌐 Chrome" to "com.android.chrome",
                    "🛒 Shopee" to "com.shopee.vn",
                    "🎵 TikTok" to "com.ss.android.ugc.trill"
                )

                vnApps.chunked(2).forEach { appRow ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        appRow.forEach { (name, pkg) ->
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(MagicSurfaceCard)
                                    .border(1.dp, MagicBorder, RoundedCornerShape(10.dp))
                                    .clickable { onOpenPlayStore(pkg) }
                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                                contentAlignment = Alignment.CenterStart
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = name,
                                        color = TextPrimary,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Tải về",
                                        color = MagicCyanLight,
                                        fontSize = 10.5.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Ô #13: Bảng kiểm tra thông số phần cứng & trạng thái tính năng (Luôn hiển thị đầy đủ)
        HardwareAndFeaturesCard(
            deviceInfo = deviceInfo,
            onRefresh = onRefreshDeviceInfo,
            cardNumberBadge = "Ô #13"
        )

        // Ô #14: Cấu Hình Khóa Gemini API Key Cá Nhân (BYOK - Tiết kiệm chi phí & Không giới hạn)
        GeminiApiKeyCustomConfigCard()

        // Dòng ghi chú nhỏ tối ưu cho Honor + Nút điều hướng tới trang chức năng ngầm đa hãng
        HonorOptimizationDisclaimerFooter(
            onNavigateToUniversalFix = onNavigateToUniversalFix
        )
    }
}

@Composable
private fun QuickSettingShortcutButton(
    title: String,
    subtitle: String,
    accentColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(MagicSurfaceCard)
            .border(1.dp, accentColor.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 8.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(
                text = title,
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Black,
                softWrap = true
            )
            Text(
                text = subtitle,
                color = accentColor,
                fontSize = 10.5.sp,
                lineHeight = 14.sp,
                fontWeight = FontWeight.SemiBold,
                softWrap = true
            )
        }
    }
}

private data class SetupStepItem(
    val index: Int,
    val badge: String,
    val title: String,
    val subtitle: String,
    val ok: Boolean
)

@Composable
fun GeminiApiKeyCustomConfigCard() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var currentKey by remember {
        mutableStateOf(com.example.core.license.LicenseManager.getUserCustomGeminiKey(context))
    }
    var isSaved by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
        border = androidx.compose.foundation.BorderStroke(1.dp, MagicBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(5.dp))
                        .background(Color(0xFF8B5CF6))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "Ô #14",
                        color = Color.White,
                        fontSize = 9.5.sp,
                        fontWeight = FontWeight.Black
                    )
                }
                Text(
                    text = "✨ KHÓA GEMINI API KEY CÁ NHÂN (BYOK)",
                    color = Color(0xFFA78BFA),
                    fontSize = 12.5.sp,
                    fontWeight = FontWeight.Black
                )
            }

            Text(
                text = "Tự nhập Gemini API Key miễn phí từ aistudio.google.com để nói chuyện không giới hạn và giúp giảm tải cho máy chủ Admin.",
                color = TextSecondary,
                fontSize = 11.sp,
                lineHeight = 15.sp
            )

            androidx.compose.material3.OutlinedTextField(
                value = currentKey,
                onValueChange = {
                    currentKey = it
                    isSaved = false
                },
                placeholder = {
                    Text(
                        text = "Dán mã AIzaSy... hoặc để trống dùng key chung",
                        fontSize = 11.5.sp,
                        color = TextSecondary.copy(alpha = 0.6f)
                    )
                },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                textStyle = androidx.compose.ui.text.TextStyle(
                    fontSize = 12.sp,
                    color = Color.White
                ),
                colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFF8B5CF6),
                    unfocusedBorderColor = MagicBorder,
                    focusedContainerColor = MagicSurfaceCard,
                    unfocusedContainerColor = MagicSurfaceCard
                )
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (currentKey.isBlank()) "Đang dùng: Key cân bằng tải Admin" else if (isSaved) "✓ Đã lưu thành công!" else "Chưa lưu thay đổi",
                    color = if (isSaved) MagicEmerald else TextSecondary,
                    fontSize = 10.5.sp,
                    fontWeight = FontWeight.Bold
                )

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (currentKey.isNotBlank()) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF334155))
                                .clickable {
                                    currentKey = ""
                                    com.example.core.license.LicenseManager.setUserCustomGeminiKey(context, "")
                                    isSaved = true
                                }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "Xóa key",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF8B5CF6))
                            .clickable {
                                com.example.core.license.LicenseManager.setUserCustomGeminiKey(context, currentKey.trim())
                                isSaved = true
                            }
                            .padding(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "Lưu Key",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }
            }
        }
    }
}
