package com.example.ui

import android.app.Application
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.permission.AppPermissionChecker
import com.example.core.permission.AppSelfPermissionStatus
import com.example.core.shell.ShellEngine
import com.example.data.DebloatApp
import com.example.data.DeviceInfo
import com.example.data.DiagnosticScanResult
import com.example.data.FloatingMiniWindowState
import com.example.data.LogItem
import com.example.data.LogType
import com.example.data.MagicTuneRepository
import com.example.data.NewDeviceSetupStatus
import com.example.data.ShizukuInfo
import com.example.data.TuneStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class MainTab {
    SETUP,
    NOTIFICATIONS,
    APPS,
    TUNE,
    SHIZUKU,
    SHELL,
    PRINTER,
    LOGIN,
    ADMIN,
    ACCOUNT,
    SHELL_TAB,
    APP_STORE,
    CHAT_SUPPORT,
    UNIVERSAL_TUNE
}

data class UiState(
    val currentTab: MainTab = MainTab.SETUP,
    val isSimpleMode: Boolean = false,
    val isBusy: Boolean = false,
    val busyTitle: String = "",
    val showRevertModal: Boolean = false,
    val showWlanDialog: Boolean = false,
    val showFeaturesModal: Boolean = false,
    val showPushTesterModal: Boolean = false,
    val showTerminalBottomSheet: Boolean = false,
    val searchQuery: String = "",
    val globalSearchQuery: String = "",
    val selectedAppLevelFilter: Int = 0, // 0: All, 4: User Apps, 1: Safe Bloat, 2: System, 3: Frozen
    val sharedPrintUri: Uri? = null,
    val isPrinting: Boolean = false,
    val printStatusMessage: String = "",
    val isAutoWakeupPatrolEnabled: Boolean = true,
    val isChargingNotificationEnabled: Boolean = false,
    val isSearchNotificationEnabled: Boolean = true,
    val isAutoCoolingEnabled: Boolean = true,
    val selfPermissionStatus: AppSelfPermissionStatus = AppSelfPermissionStatus(
        hasNotificationPermission = true,
        isIgnoringBatteryOptimizations = true,
        hasOverlayPermission = true,
        hasUsageStatsPermission = true,
        hasWriteSecureSettings = false,
        isShizukuGranted = false
    ),
    val showPermissionDialog: Boolean = false,
    val showUpgradeProDialog: Boolean = false,
    val upgradeDialogReason: String = ""
)

class MagicTuneViewModel(application: Application) : AndroidViewModel(application) {

    private val shellEngine = ShellEngine.getInstance(application.applicationContext)
    val repository = MagicTuneRepository(application.applicationContext, shellEngine)

    val shellState = shellEngine.state
    val logs: StateFlow<List<LogItem>> = repository.logs
    val deviceInfo: StateFlow<DeviceInfo> = repository.deviceInfo
    val setupStatus: StateFlow<NewDeviceSetupStatus> = repository.setupStatus
    val shizukuInfo: StateFlow<ShizukuInfo> = repository.shizukuInfo
    val appsList: StateFlow<List<DebloatApp>> = repository.appsList
    val diagnosticScan: StateFlow<DiagnosticScanResult> = repository.diagnosticScan
    val floatingWindowState: StateFlow<FloatingMiniWindowState> = repository.floatingWindowState
    val tuneStatus: StateFlow<TuneStatus> = repository.tuneStatus

    private val _uiState = MutableStateFlow(UiState())
    val uiState: StateFlow<UiState> = _uiState

    init {
        try {
            _uiState.value = _uiState.value.copy(
                isAutoWakeupPatrolEnabled = com.example.core.service.AutoWakeupPatrolManager.isAutoWakeupEnabled(application),
                isChargingNotificationEnabled = com.example.core.service.MagicTuneKeepAliveService.isChargingNotificationEnabled(application),
                isSearchNotificationEnabled = com.example.core.service.MagicTuneKeepAliveService.isSearchNotificationEnabled(application),
                isAutoCoolingEnabled = com.example.core.service.MagicTuneKeepAliveService.isAutoCoolingEnabled(application)
            )
            refreshAll()
            startLiveHardwareAndFeatureMonitor()
            observeConnectionState()
            observeNsdAutoConnect()
            checkSelfPermissions()

            viewModelScope.launch(Dispatchers.IO) {
                try {
                    com.example.core.license.LicenseManager.syncDevicePresenceToCloud(application)
                    com.example.core.license.LicenseManager.checkDeviceRecognizedProInCloud(application)
                } catch (_: Throwable) {}
            }
        } catch (_: Throwable) {}
    }

    private val isAutoConnectingWlan = java.util.concurrent.atomic.AtomicBoolean(false)

    private fun tryAutoConnectWlan(port: Int, tag: String) {
        if (port !in 1..65535 || shellState.value.isWirelessAdbConnected) return
        if (!shellEngine.hasPairedBefore()) return
        if (!isAutoConnectingWlan.compareAndSet(false, true)) return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                if (!shellState.value.isWirelessAdbConnected) {
                    val connected = shellEngine.connectWirelessAdb(port)
                    if (connected) {
                        repository.log("🎉 [$tag] Đã tự động kết nối Direct WLAN ADB (Cổng $port • UID 2000)!", LogType.SUCCESS)
                        refreshAll()
                    }
                }
            } catch (_: Throwable) {
            } finally {
                isAutoConnectingWlan.set(false)
            }
        }
    }

    private fun observeNsdAutoConnect() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val scanner = com.example.core.adb.AdbNsdScanner.getInstance(getApplication())
                scanner.startDiscovery()
                scanner.state.collect { nsdState ->
                    val port = nsdState.connectPort ?: scanner.lastKnownConnectPort
                    if (port != null && port in 1..65535 && !shellState.value.isWirelessAdbConnected && shellEngine.hasPairedBefore()) {
                        tryAutoConnectWlan(port, "Auto-Connect NSD")
                    }
                }
            } catch (_: Throwable) {}
        }
    }

    private var hasAutoPromptedPermissionDialog = false

    private fun observeConnectionState() {
        viewModelScope.launch {
            try {
                var previousAdbReady = shellState.value.isAdbReady
                shellState.collect { state ->
                    try {
                        val currentAdbReady = state.isAdbReady
                        repository.refreshShizukuInfo()
                        if (!previousAdbReady && currentAdbReady) {
                            launch(Dispatchers.IO) {
                                try {
                                    shellEngine.autoGrantSelfPermissions()
                                    checkSelfPermissions()
                                } catch (_: Throwable) {}
                            }
                            // Nạp và hiển thị ngay danh sách ứng dụng lập tức trên coroutine ưu tiên độc lập
                            launch(Dispatchers.IO) {
                                try {
                                    repository.refreshAppsList()
                                } catch (_: Throwable) {}
                            }
                            refreshAll()
                        }
                        if (previousAdbReady && !currentAdbReady) {
                            _uiState.update { it.copy(currentTab = MainTab.SETUP) }
                        }
                        previousAdbReady = currentAdbReady
                    } catch (_: Throwable) {}
                }
            } catch (_: Throwable) {}
        }
    }

    private fun startLiveHardwareAndFeatureMonitor() {
        viewModelScope.launch {
            while (isActive) {
                delay(3500)
                try {
                    repository.refreshDeviceInfo()
                } catch (_: Throwable) {}
            }
        }
    }

    fun onAppResumed() {
        try {
            shellEngine.startKeepAliveServiceIfNeeded()
        } catch (_: Throwable) {}
        viewModelScope.launch(Dispatchers.IO) {
            try {
                shellEngine.refreshStatus()
                repository.refreshShizukuInfo()
                repository.refreshDeviceInfo()
                repository.refreshFloatingPermissionsState()
                checkSelfPermissions()

                // Quét làm mới dịch vụ mDNS an toàn
                val scanner = com.example.core.adb.AdbNsdScanner.getInstance(getApplication())
                scanner.refreshConnectDiscovery()

                // Chỉ tự động kết nối lại nếu thiết bị đã từng ghép nối mã PIN thành công trước đó
                if (!shellState.value.isWirelessAdbConnected && shellEngine.hasPairedBefore()) {
                    val immediatePort = scanner.getBestConnectPort()
                    if (immediatePort != null && immediatePort in 1..65535) {
                        tryAutoConnectWlan(immediatePort, "Auto-Connect Resumed")
                    }
                }
            } catch (_: Throwable) {}
        }
    }

    fun checkSelfPermissions(forceShowIfMissing: Boolean = false) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val isShizukuReady = shellState.value.isAdbReady || (shizukuInfo.value.isRunning && shizukuInfo.value.isPermissionGranted)
                var status = AppPermissionChecker.checkSelfPermissions(getApplication(), isShizukuReady)

                // Nếu ADB / Shizuku đang sẵn sàng mà ứng dụng chưa đủ full quyền -> Tự động cấp ngầm 100% ngay lập tức!
                if (isShizukuReady && (!status.isFullyGranted || !status.hasWriteSecureSettings)) {
                    shellEngine.autoGrantSelfPermissions()
                    delay(400)
                    status = AppPermissionChecker.checkSelfPermissions(getApplication(), isShizukuReady)
                }

                val shouldAutoShowDialog = (!status.isFullyGranted) && (!hasAutoPromptedPermissionDialog || forceShowIfMissing)
                if (shouldAutoShowDialog) {
                    hasAutoPromptedPermissionDialog = true
                }

                _uiState.update { current ->
                    current.copy(
                        selfPermissionStatus = status,
                        showPermissionDialog = when {
                            shouldAutoShowDialog -> true
                            status.isFullyGranted && status.hasWriteSecureSettings -> false
                            else -> current.showPermissionDialog
                        }
                    )
                }
            } catch (_: Throwable) {}
        }
    }

    fun setShowPermissionDialog(show: Boolean) {
        _uiState.value = _uiState.value.copy(showPermissionDialog = show)
    }

    fun grantAllSelfPermissionsViaShell() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isBusy = true, busyTitle = "Đang tự động cấp full quyền cho MagicTune...")
            try {
                repository.grantSelfControlAndOverlayPermissions()
                kotlinx.coroutines.delay(1200)
                val isShizukuReady = shellState.value.isAdbReady || (shizukuInfo.value.isRunning && shizukuInfo.value.isPermissionGranted)
                val status = AppPermissionChecker.checkSelfPermissions(getApplication(), isShizukuReady)
                _uiState.value = _uiState.value.copy(
                    selfPermissionStatus = status,
                    showPermissionDialog = !status.isFullyGranted
                )
            } finally {
                _uiState.value = _uiState.value.copy(isBusy = false)
            }
        }
    }

    fun fixMagicOSSystemUpdate() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isBusy = true, busyTitle = "Đang khôi phục & mở trang Cập nhật phần mềm MagicOS...")
            try {
                repository.fixMagicOSSystemUpdate()
            } finally {
                _uiState.value = _uiState.value.copy(isBusy = false)
            }
        }
    }


    override fun onCleared() {
        super.onCleared()
        shellEngine.cleanup()
    }

    fun setTab(tab: MainTab) {
        _uiState.value = _uiState.value.copy(currentTab = tab, globalSearchQuery = "")
        if (tab == MainTab.APPS) {
            viewModelScope.launch(Dispatchers.IO) {
                try {
                    repository.refreshAppsList()
                } catch (_: Throwable) {}
            }
        }
    }

    fun refreshAppsList() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                repository.refreshAppsList()
            } catch (_: Throwable) {}
        }
    }

    fun setSimpleMode(enabled: Boolean) {
        _uiState.value = _uiState.value.copy(isSimpleMode = enabled)
    }

    fun setSearchQuery(query: String) {
        _uiState.value = _uiState.value.copy(searchQuery = query)
    }

    fun setGlobalSearchQuery(query: String) {
        _uiState.value = _uiState.value.copy(globalSearchQuery = query)
    }

    fun setAppLevelFilter(level: Int) {
        _uiState.value = _uiState.value.copy(selectedAppLevelFilter = level)
    }

    fun setShowRevertModal(show: Boolean) {
        _uiState.value = _uiState.value.copy(showRevertModal = show)
    }

    fun setShowWlanDialog(show: Boolean) {
        _uiState.value = _uiState.value.copy(showWlanDialog = show)
    }

    fun setShowFeaturesModal(show: Boolean) {
        _uiState.value = _uiState.value.copy(showFeaturesModal = show)
    }

    fun setShowPushTesterModal(show: Boolean) {
        _uiState.value = _uiState.value.copy(showPushTesterModal = show)
    }

    fun setShowTerminalBottomSheet(show: Boolean) {
        _uiState.value = _uiState.value.copy(showTerminalBottomSheet = show)
    }

    fun setShowUpgradeProDialog(show: Boolean, reason: String = "") {
        _uiState.value = _uiState.value.copy(
            showUpgradeProDialog = show,
            upgradeDialogReason = reason
        )
    }

    fun setFloatingMiniWindowVisible(visible: Boolean) {
        repository.setFloatingMiniWindowVisible(visible)
    }

    fun setFloatingMiniWindowMinimized(minimized: Boolean) {
        repository.setFloatingMiniWindowMinimized(minimized)
    }

    fun clearLogs() {
        repository.clearLogs()
    }

    private val isRefreshingAll = java.util.concurrent.atomic.AtomicBoolean(false)

    fun refreshAll() {
        if (!isRefreshingAll.compareAndSet(false, true)) return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                try { shellEngine.refreshStatus() } catch (_: Throwable) {}
                kotlinx.coroutines.supervisorScope {
                    launch { try { repository.refreshDeviceInfo() } catch (_: Throwable) {} }
                    launch { try { repository.refreshSetupStatus() } catch (_: Throwable) {} }
                    launch { try { repository.refreshShizukuInfo() } catch (_: Throwable) {} }
                    launch { try { repository.refreshAppsList() } catch (_: Throwable) {} }
                }
                try {
                    repository.runDiagnosticScan(skipAppsAndSetupRefresh = true, silentLog = true)
                } catch (_: Throwable) {}
            } catch (_: Throwable) {
            } finally {
                isRefreshingAll.set(false)
            }
        }
    }

    fun requestShizukuPermission() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                shellEngine.requestShizukuPermission()
            } catch (_: Throwable) {}
            try {
                repository.refreshShizukuInfo()
                repository.refreshDeviceInfo()
            } catch (_: Throwable) {}
        }
    }

    fun forceResetShizuku() {
        viewModelScope.launch(Dispatchers.IO) {
            shellEngine.forceResetBinder()
            repository.log("⚡ Đã cưỡng bức làm mới kết nối Shizuku. Nếu vẫn lỗi, hãy khởi động lại app Shizuku.", LogType.INFO)
            try {
                repository.refreshShizukuInfo()
            } catch (_: Throwable) {}
        }
    }

    fun testShizukuDiagnostic(onResult: (Boolean, String) -> Unit = { _, _ -> }) {
        viewModelScope.launch(Dispatchers.IO) {
            _uiState.update {
                it.copy(
                    isBusy = true,
                    busyTitle = "Đang kiểm tra toàn diện Shizuku..."
                )
            }
            try {
                repository.log("🔍 Đang chạy chẩn đoán toàn diện kết nối & quyền Shizuku...", LogType.COMMAND)
                val diagResult = kotlinx.coroutines.withTimeoutOrNull(10000L) {
                    shellEngine.runComprehensiveShizukuDiagnostic()
                }
                val (ok, details) = diagResult ?: Pair(false, "⚠️ Hết thời gian chờ (10s): Shizuku Binder không phản hồi.")
                repository.refreshShizukuInfo()
                repository.log("Kết quả kiểm tra Shizuku:\n$details", if (ok) LogType.SUCCESS else LogType.ERROR)
                withContext(Dispatchers.Main) {
                    onResult(ok, details)
                }
            } catch (t: Throwable) {
                repository.log("❌ Lỗi chẩn đoán: ${t.localizedMessage ?: t.message}", LogType.ERROR)
            } finally {
                _uiState.update { it.copy(isBusy = false, busyTitle = "") }
            }
        }
    }

    fun startNotificationPairingMode() {
        val app = getApplication<Application>()
        com.example.core.adb.AdbPairingNotificationManager.startInteractiveNotificationPairing(app)
        repository.log(
            "🔔 Đã bật chế độ Ghép nối trên Thanh thông báo (NSD _adb-tls-pairing._tcp). Hãy mở 'Ghép nối bằng mã ghép đôi' và nhập 6 số PIN ngay trên thông báo!",
            LogType.INFO
        )
        openDeveloperSettings()
    }

    fun startShizukuServerDirectly() {
        viewModelScope.launch(Dispatchers.IO) {
            _uiState.update {
                it.copy(
                    isBusy = true,
                    busyTitle = "Đang khởi chạy trực tiếp Shizuku Server..."
                )
            }
            try {
                repository.log("🚀 Đang kích hoạt trực tiếp Shizuku Server Daemon từ MagicTune...", LogType.COMMAND)
                val startResult = kotlinx.coroutines.withTimeoutOrNull(15000L) {
                    com.example.core.shell.ShizukuStarterModule.startShizukuServerViaAdb(
                        getApplication(),
                        shellEngine
                    )
                }
                val (ok, msg) = startResult ?: Pair(false, "⚠️ Hết thời gian chờ (15s) khi khởi chạy Shizuku Daemon.")
                repository.refreshShizukuInfo()
                repository.log(msg, if (ok) LogType.SUCCESS else LogType.ERROR)
            } catch (t: Throwable) {
                repository.log("❌ Lỗi khởi chạy: ${t.localizedMessage ?: t.message}", LogType.ERROR)
            } finally {
                _uiState.update { it.copy(isBusy = false, busyTitle = "") }
            }
        }
    }

    fun unlockRestrictedSettingsAllApps() = runAction("Đang mở khóa 'Cài đặt bị hạn chế' (Android 13-15)...") {
        repository.log("🔓 Đang mở khóa ACCESS_RESTRICTED_SETTINGS cho toàn bộ ứng dụng...", LogType.COMMAND)
        val (unlocked, total) = com.example.core.shell.ShizukuStarterModule.unlockRestrictedSettingsAllApps(
            getApplication(),
            shellEngine
        )
        com.example.core.shell.ShizukuStarterModule.keepWirelessDebuggingImmortal(shellEngine)
        repository.log(
            "✅ Đã mở khóa 'Cài đặt bị hạn chế' cho $unlocked/$total ứng dụng & kích hoạt giữ sống Gỡ lỗi Wi-Fi!",
            LogType.SUCCESS
        )
    }

    fun pairWirelessAdb(port: Int, pairingCode: String, onFinished: (Boolean, String) -> Unit = { _, _ -> }) {
        viewModelScope.launch {
            repository.log("🔑 Bắt đầu ghép nối mã PIN $pairingCode tới cổng $port...", LogType.COMMAND)
            val result = withContext(Dispatchers.IO) {
                shellEngine.pairWirelessAdb(port, pairingCode)
            }
            val success = result.isSuccess && result.getOrDefault(false)
            val msg = if (success) {
                "Ghép nối thành công! Đang tự động kết nối..."
            } else {
                result.exceptionOrNull()?.localizedMessage
                    ?: "Ghép nối thất bại. Vui lòng kiểm tra lại 6 số PIN và 5 số cổng (đảm bảo cửa sổ ghép nối vẫn đang mở)."
            }

            // Gọi ngay callback để WirelessAdbDialog cập nhật phản hồi UI lập tức cho người dùng
            onFinished(success, msg)

            if (success) {
                repository.log("✅ WLAN: Ghép nối mã PIN thành công!", LogType.SUCCESS)
                // Chạy tự động tìm kiếm cổng connect và kết nối ngầm không che lấp giao diện
                val scanner = com.example.core.adb.AdbNsdScanner.getInstance(getApplication())
                scanner.refreshConnectDiscovery()
                var targetPort = scanner.getBestConnectPort()
                var connected = false
                val immediatePort = targetPort
                if (immediatePort != null && immediatePort in 1..65535) {
                    repository.log("⚡ Tìm thấy cổng kết nối $immediatePort, đang tự động kết nối...", LogType.INFO)
                    connected = withContext(Dispatchers.IO) { shellEngine.connectWirelessAdb(immediatePort) }
                } else {
                    for (i in 1..10) {
                        kotlinx.coroutines.delay(400)
                        val discovered = scanner.getBestConnectPort()
                        if (discovered != null && discovered in 1..65535) {
                            targetPort = discovered
                            connected = withContext(Dispatchers.IO) { shellEngine.connectWirelessAdb(discovered) }
                            break
                        }
                    }
                }
                if (connected && targetPort != null) {
                    repository.log("🎉 ĐÃ TỰ ĐỘNG KẾT NỐI DIRECT WLAN ADB THÀNH CÔNG! (Cổng: $targetPort • UID 2000)", LogType.SUCCESS)
                    _uiState.update { it.copy(showWlanDialog = false) }
                    refreshAll()
                }
            } else {
                repository.log("❌ WLAN: Lỗi ghép nối - $msg", LogType.ERROR)
            }
        }
    }

    fun connectWirelessAdb(port: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            _uiState.update {
                it.copy(
                    isBusy = true,
                    busyTitle = "Đang kết nối WLAN 127.0.0.1:$port...",
                    showTerminalBottomSheet = true
                )
            }
            val success = shellEngine.connectWirelessAdb(port)
            if (success) {
                repository.log("WLAN: Đang kết nối thành công tại 127.0.0.1:$port! Đã kết nối Direct ADB (UID 2000 Độc Lập).", LogType.SUCCESS)
                _uiState.update { it.copy(showWlanDialog = false) }
                refreshAll()
            } else {
                repository.log("Không thể kết nối 127.0.0.1:$port. Hãy kiểm tra lại cổng gỡ lỗi hoặc ghép đôi nếu chưa ghép nối.", LogType.ERROR)
            }
            _uiState.update { it.copy(isBusy = false) }
        }
    }

    fun disconnectWirelessAdb() {
        viewModelScope.launch(Dispatchers.IO) {
            shellEngine.disconnectWirelessAdb()
            repository.log("Đã ngắt kết nối gỡ lỗi WLAN • Giữ nguyên 100% trạng thái đã Fix trên máy!", LogType.SUCCESS)
            try {
                repository.refreshDeviceInfo()
                repository.refreshSetupStatus()
                repository.refreshTuneStatus()
            } catch (_: Throwable) {}
        }
    }

    fun disconnectSession() {
        viewModelScope.launch(Dispatchers.IO) {
            shellEngine.disconnectSession()
            repository.log("Đã chủ động ngắt phiên kết nối (Shizuku & WLAN) • Các thiết lập đã tối ưu vẫn được bảo toàn nguyên vẹn!", LogType.INFO)
            try {
                repository.refreshDeviceInfo()
                repository.refreshSetupStatus()
                repository.refreshTuneStatus()
                repository.refreshShizukuInfo()
            } catch (_: Throwable) {}
        }
    }

    fun openDeveloperSettings() {
        try {
            val intent = Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            getApplication<Application>().startActivity(intent)
            repository.log("Đã mở Tùy chọn nhà phát triển. Hãy bật 'Gỡ lỗi qua Wi-Fi'.", LogType.INFO)
        } catch (_: Exception) {
            try {
                val intent = Intent(Settings.ACTION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                getApplication<Application>().startActivity(intent)
            } catch (_: Exception) {}
        }
    }

    fun openOverlayPermissionSettings() {
        try {
            val app = getApplication<Application>()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:${app.packageName}")
                ).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                app.startActivity(intent)
                repository.log("Đã mở Cài đặt 'Hiển thị trên ứng dụng khác' cho MagicTune.", LogType.INFO)
            }
        } catch (_: Exception) {}
    }

    fun openSpecialAppAccess() {
        AppPermissionChecker.openSpecialAppAccess(getApplication())
        repository.log("Đã mở trang 'Quyền truy cập đặc biệt'. Hãy tìm MagicTune và cấp quyền 'Truy cập sử dụng' & 'Thay đổi cài đặt hệ thống'.", LogType.INFO)
    }

    fun repairHonorPermissions() = runAction("Đang sửa lỗi quyền Honor/MagicOS chuyên sâu...") {
        repository.log("🛠️ Đang thực thi kịch bản sửa lỗi quyền cho MagicOS...", LogType.COMMAND)
        shellEngine.autoGrantSelfPermissions()
        // Force repair Restricted Settings specifically
        val pkg = getApplication<Application>().packageName
        shellEngine.execute("cmd appops set $pkg ACCESS_RESTRICTED_SETTINGS allow")
        shellEngine.execute("cmd appops set --uid $pkg ACCESS_RESTRICTED_SETTINGS allow")
        repository.log("✅ Đã hoàn tất sửa lỗi quyền Honor! Nếu vẫn chưa thấy MagicTune trong danh sách, hãy bấm 'Quyền đặc biệt' và tìm thủ công.", LogType.SUCCESS)
        checkSelfPermissions()
    }

    fun openAppDetailsSettings(pkg: String) {
        try {
            val app = getApplication<Application>()
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            app.startActivity(intent)
        } catch (_: Exception) {}
    }

    fun openAppNotificationSettings(pkg: String) {
        try {
            val app = getApplication<Application>()
            val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                    putExtra(Settings.EXTRA_APP_PACKAGE, pkg)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            } else {
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            }
            app.startActivity(intent)
        } catch (_: Exception) {}
    }

    fun openShizukuApp() {
        val pm = getApplication<Application>().packageManager
        val intent = pm.getLaunchIntentForPackage("moe.shizuku.privileged.api")
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            getApplication<Application>().startActivity(intent)
        } else {
            openPlayStore("moe.shizuku.privileged.api")
        }
    }

    fun openPlayStore(pkg: String) {
        val playStorePackage = "com.android.vending"
        try {
            // Ép buộc mở thẳng Google Play Store (CH Play) bằng setPackage để tránh Honor Market chặn và cướp liên kết
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$pkg")).apply {
                setPackage(playStorePackage)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            getApplication<Application>().startActivity(intent)
        } catch (_: Exception) {
            try {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$pkg")).apply {
                    setPackage(playStorePackage)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                getApplication<Application>().startActivity(intent)
            } catch (_: Exception) {
                // Fallback nếu máy chưa bật CH Play
                val fallbackIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$pkg")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                getApplication<Application>().startActivity(fallbackIntent)
            }
        }
    }

    fun openYouTubeChannel() {
        try {
            val url = com.example.core.license.LicenseManager.getCustomYouTubeUrl(getApplication())
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            getApplication<Application>().startActivity(intent)
            repository.log("Đang mở liên kết YouTube: $url", LogType.INFO)
        } catch (_: Exception) {}
    }

    private val activeActionCount = java.util.concurrent.atomic.AtomicInteger(0)
    @Volatile
    private var currentPriorityJob: kotlinx.coroutines.Job? = null

    /**
     * Ngắt ngay các lệnh cũ chưa xong và giải phóng tiến trình để ưu tiên lệnh mới nhất.
     */
    fun cancelOldCommandsAndFreeTerminal() {
        currentPriorityJob?.cancel()
        activeActionCount.set(0)
        _uiState.update { it.copy(isBusy = false, busyTitle = "") }
        viewModelScope.launch(Dispatchers.IO) {
            val killed = shellEngine.preemptRunningProcesses()
            if (killed > 0) {
                repository.log("⚡ Đã ngắt $killed tiến trình lệnh cũ đang chạy dở để giải phóng màn hình lệnh ADB ngay lập tức!", LogType.INFO)
            }
        }
    }

    private fun runAction(
        title: String,
        openTerminal: Boolean = true,
        preemptOld: Boolean = true,
        timeoutMs: Long = 25000L,
        requireProOrTrial: Boolean = true,
        block: suspend () -> Unit
    ) {
        val app = getApplication<Application>()
        if (requireProOrTrial) {
            val (allowed, gateMessage) = com.example.core.license.LicenseManager.checkAndConsumeProOrTrial(app, title)
            if (!allowed) {
                repository.log(gateMessage, LogType.ERROR)
                _uiState.value = _uiState.value.copy(
                    showUpgradeProDialog = true,
                    upgradeDialogReason = gateMessage,
                    showTerminalBottomSheet = true
                )
                try {
                    android.widget.Toast.makeText(
                        app,
                        "🔒 Đã hết lượt miễn phí! Vui lòng nâng cấp Bản PRO.",
                        android.widget.Toast.LENGTH_LONG
                    ).show()
                } catch (_: Throwable) {}
                return
            } else {
                repository.log(gateMessage, LogType.SUCCESS)
            }
        }

        val previousJob = currentPriorityJob
        val job = viewModelScope.launch {
            if (preemptOld && (previousJob?.isActive == true || activeActionCount.get() > 0)) {
                previousJob?.cancel()
                withContext(Dispatchers.IO) {
                    val preempted = shellEngine.preemptRunningProcesses()
                    if (preempted > 0) {
                        repository.log("⚡ [Ưu tiên lệnh mới] Đã ngắt $preempted tiến trình cũ chưa xong để ưu tiên chạy ngay: $title", LogType.INFO)
                    }
                }
            }

            if (!shellState.value.isAdbReady && shellEngine.directAdbManager.isConnected) {
                withContext(Dispatchers.IO) {
                    shellEngine.refreshStatus()
                }
            }
            if (!shellState.value.isAdbReady) {
                repository.log("⚠️ CHƯA KẾT NỐI ADB: Vui lòng kết nối Trực tiếp qua Gỡ lỗi Wi-Fi (WLAN ADB) để thực thi lệnh hệ thống!", LogType.INFO)
                return@launch
            }

            activeActionCount.incrementAndGet()
            _uiState.value = _uiState.value.copy(
                isBusy = true,
                busyTitle = title,
                showTerminalBottomSheet = if (openTerminal) true else _uiState.value.showTerminalBottomSheet
            )
            try {
                // Tự động nhận diện lệnh chạy xong trên Dispatchers.IO, không bao giờ treo màn hình lệnh hoặc UI
                kotlinx.coroutines.withTimeout(timeoutMs) {
                    withContext(Dispatchers.IO) {
                        block()
                    }
                }
            } catch (e: kotlinx.coroutines.TimeoutCancellationException) {
                withContext(Dispatchers.IO) {
                    shellEngine.preemptRunningProcesses()
                }
                repository.log("⏱️ Đã hoàn tất hoặc tự ngắt sau ${timeoutMs / 1000}s để chống treo màn hình lệnh.", LogType.INFO)
            } catch (_: kotlinx.coroutines.CancellationException) {
                // Đã nhường quyền ưu tiên cho lệnh mới nhất
            } catch (t: Throwable) {
                repository.log("❌ Tiến trình hoàn tất: ${t.localizedMessage ?: t.message}", LogType.INFO)
            } finally {
                val remaining = activeActionCount.decrementAndGet().coerceAtLeast(0)
                if (remaining == 0) {
                    _uiState.value = _uiState.value.copy(isBusy = false, busyTitle = "")
                }
                refreshAll()
            }
        }
        currentPriorityJob = job
    }

    fun runDiagnosticScan() = runAction("Đang quét kiểm tra thực tế kênh thông báo (dumpsys) & quyền app...", openTerminal = false, timeoutMs = 45000L, requireProOrTrial = false) {
        repository.runDiagnosticScan()
    }

    fun resetAndRescanNotifications() = runAction("Đang xóa bộ đệm cũ & quét lại thực tế toàn bộ ứng dụng...", openTerminal = false, timeoutMs = 45000L, requireProOrTrial = false) {
        repository.resetAndRescanNotifications()
    }

    fun fixSingleAppNotificationAndPerm(pkg: String, appName: String) =
        runAction("Đang mở Cài đặt Thông báo của $appName & tự động gạt công tắc tận mắt...", openTerminal = false, timeoutMs = 60000L) {
            repository.fixSingleAppGentleAndPermissions(pkg, appName)
        }

    fun grantSelfControlAndOverlayPermissions() =
        runAction("Đang cấp quyền điều khiển & hiển thị trên app khác...", requireProOrTrial = false) {
            repository.grantSelfControlAndOverlayPermissions()
        }

    fun stopLiveFloatingAutomation() {
        repository.stopLiveFloatingAutomation()
    }

    fun startLiveFloatingMiniWindowAutomation() {
        val app = getApplication<Application>()
        val (allowed, gateMessage) = com.example.core.license.LicenseManager.checkAndConsumeProOrTrial(
            app,
            "Tự động mở Cài đặt & gạt công tắc tận mắt"
        )
        if (!allowed) {
            repository.log(gateMessage, LogType.ERROR)
            _uiState.update { it.copy(showTerminalBottomSheet = true) }
            try {
                android.widget.Toast.makeText(
                    app,
                    "🔒 Đã hết lượt miễn phí! Vui lòng kích hoạt Bản PRO để sử dụng tính năng này.",
                    android.widget.Toast.LENGTH_LONG
                ).show()
            } catch (_: Throwable) {}
            return
        } else {
            repository.log(gateMessage, LogType.SUCCESS)
        }

        viewModelScope.launch(Dispatchers.IO) {
            if (!shellState.value.isAdbReady && shellEngine.directAdbManager.isConnected) {
                shellEngine.refreshStatus()
            }
            if (!shellState.value.isAdbReady) {
                repository.log("⚠️ CHƯA KẾT NỐI ADB: Vui lòng kết nối Trực tiếp qua Gỡ lỗi Wi-Fi (WLAN ADB) để chạy trình Tự Động Mở Cài Đặt & Gạt Công Tắc Tận Mắt!", LogType.INFO)
                return@launch
            }

            activeActionCount.incrementAndGet()
            _uiState.update { it.copy(isBusy = true, busyTitle = "Đang tự động mở Cài đặt & gạt công tắc tận mắt...") }
            try {
                repository.runLiveFloatingMiniWindowAutomation()
            } catch (t: Throwable) {
                repository.log("❌ Lỗi cửa sổ nổi: ${t.localizedMessage ?: t.message}", LogType.ERROR)
            } finally {
                val remaining = activeActionCount.decrementAndGet().coerceAtLeast(0)
                if (remaining == 0) {
                    _uiState.update { it.copy(isBusy = false, busyTitle = "") }
                }
            }
        }
    }

    fun runOneClickSetup() = runAction("⚡ Đang chạy Siêu Thiết Lập 8-trong-1 Turbo (Chỉ các mục chưa đạt)...", timeoutMs = 90000L) {
        repository.runOneClickSetupMaster(onlyPending = true)
    }

    fun runOneClickSetupForceFull() = runAction("🔄 Đang chạy lại Toàn Diện 8/8 hạng mục Siêu Thiết Lập...", timeoutMs = 90000L) {
        repository.runOneClickSetupMaster(onlyPending = false)
    }

    fun setupVietnameseLanguage() = runAction("Đang cài Tiếng Việt & Giờ GMT+7...") {
        repository.setupVietnameseLanguage()
    }

    fun setupGoogleAndSync() = runAction("Đang bật Google & Đồng bộ danh bạ...") {
        repository.setupGoogleAndSync()
    }

    fun fixCallerIdAndWifi() = runAction("Đang sửa danh bạ +84 & Wi-Fi...") {
        repository.fixCallerIdAndWifi()
    }

    fun cleanChineseUi() = runAction("Đang dọn sạch chữ Trung & tắt YOYO...") {
        repository.cleanChineseUi()
    }

    fun replaceHonorSearch(disable: Boolean) = runAction(if (disable) "Đang thay thế Honor Search..." else "Đang khôi phục Honor Search...") {
        repository.replaceHonorSearch(disable)
    }

    fun blockHonorMarket() = runAction("Đang chặn Chợ App Honor tự cập nhật...") {
        repository.blockHonorMarket()
    }

    fun unblockHonorMarket() = runAction("Đang mở lại Tự động cập nhật App...") {
        repository.unblockHonorMarket()
    }

    fun toggleAppMarketUpdateBlock(currentBlocked: Boolean) {
        if (currentBlocked) {
            unblockHonorMarket()
        } else {
            blockHonorMarket()
        }
    }

    fun applyThermalCooling() = runAction("Đang kích hoạt chế độ Siêu Làm Mát Phần Cứng...") {
        repository.applyThermalCooling()
    }

    fun setupKeyboard() = runAction("Đang cài đặt bàn phím...") {
        repository.setupKeyboard()
    }

    fun setupGpsVietnam() = runAction("Đang cấu hình GPS nhạy...") {
        repository.setupGpsVietnam()
    }

    fun refreshGpsSatellites() = runAction("Đang xóa bộ đệm & nạp lại vệ tinh A-GPS...") {
        repository.refreshGpsSatellites()
    }

    fun fixAllNotifications() = runAction("Đang kiểm tra & chỉ sửa các app gặp lỗi thông báo / quyền...", timeoutMs = 90000L) {
        repository.optimizeAllApps()
    }

    fun batchGrantAllSystemPermissions() = runAction("Đang tự động cấp toàn bộ quyền hệ thống, chạy ngầm & pin hàng loạt (Chạy ngầm)...", timeoutMs = 90000L) {
        repository.optimizeAllApps()
    }

    fun fixFacebook() = runAction("Đang đặc trị khống chế thông báo Gmail & Facebook...") {
        repository.fixGmailAndFacebookNuclear()
    }

    fun fixGmailAndFacebookNuclear() = runAction("Đang đặc trị khống chế thông báo Gmail & Facebook...") {
        repository.fixGmailAndFacebookNuclear()
    }

    fun restoreGmailAndFacebookDefault() = runAction("Đang khôi phục cài đặt mặc định gốc cho Gmail & Facebook...") {
        repository.restoreGmailAndFacebookDefault()
    }

    fun toggleAutoWakeupPatrol(enable: Boolean) {
        com.example.core.service.AutoWakeupPatrolManager.setAutoWakeupEnabled(getApplication(), enable)
        _uiState.value = _uiState.value.copy(isAutoWakeupPatrolEnabled = enable)
        if (enable) {
            com.example.core.service.AutoWakeupPatrolManager.performSilentPulseIfDue(getApplication())
        }
    }

    fun toggleSearchNotification(enable: Boolean) {
        com.example.core.service.MagicTuneKeepAliveService.setSearchNotificationEnabled(getApplication(), enable)
        com.example.core.service.MagicTuneKeepAliveService.startOrUpdate(getApplication(), "MagicTune Pinned Search")
        _uiState.value = _uiState.value.copy(isSearchNotificationEnabled = enable)
    }

    fun toggleChargingNotification(enable: Boolean) {
        com.example.core.service.MagicTuneKeepAliveService.setChargingNotificationEnabled(getApplication(), enable)
        _uiState.value = _uiState.value.copy(isChargingNotificationEnabled = enable)
    }

    fun toggleAutoCooling(enable: Boolean) {
        com.example.core.service.MagicTuneKeepAliveService.setAutoCoolingEnabled(getApplication(), enable)
        _uiState.value = _uiState.value.copy(isAutoCoolingEnabled = enable)
    }

    fun fixNotificationSettingsOnly() = runAction("Đang sửa riêng cài đặt Thông báo Màn hình khóa & Biểu ngữ...") {
        repository.fixNotificationSettingsOnly()
    }

    fun fixAppPermissionsOnly() = runAction("Đang sửa riêng Quyền hạn Chạy ngầm & Đánh thức App...") {
        repository.fixAppPermissionsOnly()
    }

    fun boostGmailAndFacebookBatching() = runAction("Đang phá gom cụm 0s cho Gmail & Facebook...") {
        repository.boostGmailAndFacebookBatching()
    }

    fun prioritizeAppCustomSounds() = runAction("Đang ưu tiên chuông riêng & chống câm...") {
        repository.prioritizeAppCustomSounds()
    }

    fun removePowerGenius() = runAction("Đang tắt diệt ngầm PowerGenius...") {
        repository.removePowerGeniusAndIaware()
    }

    fun testPushNotification(pkg: String = "com.facebook.katana", appName: String = "Facebook") =
        runAction("Đang bắn thử thông báo test...") {
            repository.testPushNotification(pkg, appName)
        }

    fun debloatSafeApps() = runAction("Đang gỡ bỏ app rác cấp 1...") {
        repository.batchDebloatLevel1()
    }

    fun uninstallApp(pkg: String) = runAction("Đang gỡ $pkg...") {
        repository.uninstallApp(pkg)
    }

    fun restoreApp(pkg: String) = runAction("Đang khôi phục $pkg...") {
        repository.restoreApp(pkg)
    }

    fun applySmartBatterySaver() = runAction("Đang kích hoạt Siêu Tiết Kiệm Pin Thông Minh...") {
        repository.applySmartBatterySaver()
    }

    fun enhanceBottomGestureSensitivity() = runAction("Đang tăng độ nhạy vuốt mép đáy & fix kính cường lực...") {
        repository.enhanceBottomGestureSensitivity()
    }

    fun applyMaxSettings() = runAction("Đang kích hoạt Max Setting 120/144Hz...") {
        repository.applyMaxSettings()
    }

    fun setRefreshRate(hz: Int) = runAction("Đang đặt tần số quét ${hz}Hz...") {
        repository.setRefreshRate(hz)
    }

    fun setAnimationScale(scale: Float) = runAction("Đang chỉnh Animation ${scale}x...") {
        repository.setAnimationScale(scale)
    }

    fun disableYoyoNavigationWake() = runAction("Đang tắt công tắc nhấn thanh điều hướng đánh thức YOYO...") {
        repository.disableYoyoNavigationWake()
    }

    fun remapNavBarToGoogleAssistant() = runAction("Đang chuyển đổi thanh điều hướng sang Google/Gemini Voice...") {
        repository.remapNavBarToGoogleAssistant()
    }

    fun modNavBarToCircleToSearch() = runAction("Đang gỡ YOYO Agent & Mod phím điều hướng thành Google Khoanh Tròn Tìm Kiếm...") {
        repository.modNavBarToCircleToSearch()
    }

    fun modNavBarToGeminiVoice() = runAction("Đang gỡ YOYO Agent & Mod phím điều hướng thành Gọi Gemini Voice AI...") {
        repository.modNavBarToGeminiVoice()
    }

    fun toggleGeminiVoice() = runAction("Đang Bật / Tắt tính năng Gọi Gemini Voice & Micro...") {
        val currentMode = repository.shellEngine.getPersistedSetting("secure", "magictune_nav_mod_mode")
        if (tuneStatus.value.isGeminiVoiceEnabled || currentMode == "GEMINI_VOICE") {
            repository.disableGeminiVoiceMod()
        } else {
            repository.modNavBarToGeminiVoice()
        }
    }

    fun setMagicTuneAsDefaultAssistant() = runAction("Đang đặt MagicTune làm Trợ lý ảo mặc định cho điện thoại Honor...") {
        repository.setMagicTuneAsDefaultAssistant()
    }

    fun testTriggerNavAssistantNow() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                repository.testTriggerNavAssistantNow()
            } catch (e: Throwable) {
                android.util.Log.e("MagicTune", "Lỗi gọi thử trợ lý: ${e.message}", e)
            }
        }
    }

    fun testCircleToSearchNow() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                com.example.core.service.SystemFloatingHudOverlay.triggerConfiguredAssistantNow(
                    getApplication(),
                    explicitMode = "CIRCLE_TO_SEARCH"
                )
            } catch (e: Throwable) {
                android.util.Log.e("MagicTune", "Lỗi gọi thử khoanh tròn: ${e.message}", e)
            }
        }
    }

    fun restoreYoyoOriginal() = runAction("Đang khôi phục lại YOYO Agent gốc của Honor...") {
        repository.restoreYoyoOriginal()
    }

    fun toggleNavigationBarPill(hide: Boolean) = runAction(if (hide) "Đang ẩn thanh kim..." else "Đang hiện thanh kim...") {
        repository.toggleNavigationBarPill(hide)
    }

    fun toggleDeviceFeature(featureId: String, currentEnabled: Boolean) = runAction("Đang cập nhật tính năng thiết bị...") {
        repository.toggleDeviceFeature(featureId, currentEnabled)
    }

    fun hideNavigationBar() = runAction("Đang ẩn thanh kim & tắt gọi YOYO...") {
        repository.hideNavigationBarPill()
    }

    fun fixAudio() = runAction("Đang sửa rè âm thanh 48kHz...") {
        repository.fixAudioDistortion()
    }

    fun fixAndroidAuto() = runAction("Đang tối ưu & Cấp full quyền Android Auto...") {
        repository.fixAndroidAuto()
    }

    fun setFontBoldLarge(enabled: Boolean) = runAction("Đang điều chỉnh font chữ...") {
        repository.setFontBoldLarge(enabled)
    }

    fun setDarkModeOled(enabled: Boolean) = runAction("Đang chuyển đổi Dark Mode...") {
        repository.setDarkModeOled(enabled)
    }

    fun unlockSecureScreenshot() = runAction("Đang mở khóa chụp màn hình...") {
        repository.unlockSecureScreenshot()
    }

    fun enableAdBlocker() = runAction("Đang kích hoạt Chặn Quảng Cáo Toàn Diện...") {
        repository.enableAdBlocker()
    }

    fun disableAdBlocker() = runAction("Đang tắt Chặn Quảng Cáo...") {
        repository.disableAdBlocker()
    }

    fun grantAllPermissions() = runAction("Đang kiểm tra & cấp quyền cho các app còn thiếu...", timeoutMs = 90000L) {
        repository.grantAllPermissionsAllApps()
    }

    fun protectShizukuImmortal() = runAction("Đang bật Khiên Bất Tử Shizuku...") {
        repository.protectShizukuImmortal()
    }

    fun authorizeShizukuCompanions() = runAction("Đang cấp quyền hệ sinh thái Shizuku...") {
        repository.authorizeShizukuCompanions()
    }

    fun restoreFactoryDefault() = runAction("Đang khôi phục toàn bộ cài đặt gốc...", timeoutMs = 90000L) {
        repository.restoreAllToFactoryDefault()
        _uiState.value = _uiState.value.copy(showRevertModal = false)
    }

    fun runCustomShellCommand(cmd: String) {
        // Luôn ưu tiên thực thi ngay lập tức lệnh mới nhất do người dùng nhập/bấm trong màn hình lệnh ADB!
        runAction("⚡ Đang chạy ưu tiên lệnh Shell: $cmd", openTerminal = true, preemptOld = true) {
            repository.runShell(cmd, true)
        }
    }

    // -------------------------------------------------------------
    // 5 QUYỀN NĂNG HỆ THỐNG CHUYÊN SÂU v2.5 (ANDROID 11 -> ANDROID 17)
    // -------------------------------------------------------------
    fun enableStealthDeveloperModeBypass() = runAction("🛡️ Đang ẩn Chế độ nhà phát triển để mở full App Banking & Game...") {
        repository.enableStealthDeveloperModeBypass()
    }

    fun restoreDeveloperModeVisibility() = runAction("🔓 Đang hiển thị lại menu Tùy chọn nhà phát triển...") {
        repository.restoreDeveloperModeVisibility()
    }

    fun unlockAndInspectRestrictedStorage() = runAction("📂 Đang mở khóa & đọc trực tiếp Android/data và Android/obb...") {
        repository.unlockAndInspectRestrictedStorage()
    }

    fun extractAndSyncRestrictedObbAndData() = runAction("📦 Đang giải nén & đồng bộ dữ liệu vào Android/data & Android/obb...") {
        repository.extractAndSyncRestrictedObbAndData()
    }

    fun cleanRestrictedAppCaches() = runAction("🧹 Đang dọn sạch bộ nhớ đệm sâu trong Android/data/*/cache...") {
        repository.cleanRestrictedAppCaches()
    }

    fun freezeAppPackage(pkg: String, freeze: Boolean) = runAction(if (freeze) "❄️ Đang đóng băng $pkg..." else "🔥 Đang mở băng $pkg...") {
        repository.freezeAppPackage(pkg, freeze)
    }

    fun revokeSensitivePermissionsFromApp(pkg: String) = runAction("🔒 Đang thu hồi quyền nhạy cảm của $pkg...") {
        repository.revokeSensitivePermissionsFromApp(pkg)
    }

    fun toggleDeepPrivacySensor(sensorType: String, block: Boolean) = runAction("🛡️ Đang cập nhật khóa cảm biến quyền riêng tư ($sensorType)...") {
        repository.toggleDeepPrivacySensor(sensorType, block)
    }

    fun runSystemAutomationMacro(macroType: String) = runAction("🤖 Đang thực thi kịch bản tự động hóa: $macroType...") {
        repository.runSystemAutomationMacro(macroType)
    }

    fun setSharedPrintUri(uri: Uri?) {
        _uiState.value = _uiState.value.copy(
            sharedPrintUri = uri,
            currentTab = if (uri != null) MainTab.PRINTER else _uiState.value.currentTab
        )
    }

    fun setPrintStatusMessage(msg: String) {
        _uiState.value = _uiState.value.copy(printStatusMessage = msg)
    }

    fun setIsPrinting(printing: Boolean) {
        _uiState.value = _uiState.value.copy(isPrinting = printing)
    }

    fun applyUniversalOemNotificationFix() = runAction("🌐 Đang kích hoạt chế độ Fix Trễ Thông Báo Tổng Lực Đa Hãng...") {
        repository.applyUniversalOemNotificationFix()
    }

    fun fixXiaomiMiuiNotificationLag() = runAction("📱 Đang can thiệp MIUI & HyperOS (Tắt Joyose/PowerKeeper)...") {
        repository.fixXiaomiMiuiNotificationLag()
    }

    fun fixOppoRealmeNotificationLag() = runAction("📱 Đang vô hiệu hóa Athena & Deep Sleep trên ColorOS...") {
        repository.fixOppoRealmeNotificationLag()
    }

    fun fixVivoIqooNotificationLag() = runAction("📱 Đang ngắt iManager & Night Idle Sleep trên OriginOS...") {
        repository.fixVivoIqooNotificationLag()
    }

    fun fixHuaweiHarmonyNotificationLag() = runAction("📱 Đang ngắt PowerGenie trên EMUI / HarmonyOS...") {
        repository.fixHuaweiHarmonyNotificationLag()
    }
}
