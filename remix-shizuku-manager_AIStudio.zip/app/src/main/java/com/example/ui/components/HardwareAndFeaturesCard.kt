package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SettingsInputComponent
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DeviceInfo
import com.example.ui.theme.MagicAmber
import com.example.ui.theme.MagicBlue
import com.example.ui.theme.MagicBorder
import com.example.ui.theme.MagicCyan
import com.example.ui.theme.MagicEmerald
import com.example.ui.theme.MagicPurple
import com.example.ui.theme.MagicSurfaceCard
import com.example.ui.theme.MagicSurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun HardwareAndFeaturesCard(
    deviceInfo: DeviceInfo,
    onRefresh: () -> Unit,
    onToggleFeature: (String, Boolean) -> Unit = { _, _ -> },
    cardNumberBadge: String = "Ô #13"
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("hardware_and_features_section"),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Card 1: Compact Real-time Phone Features Status (ON / OFF Detection)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = androidx.compose.foundation.BorderStroke(
                1.dp,
                Brush.linearGradient(listOf(MagicEmerald.copy(alpha = 0.7f), MagicCyan.copy(alpha = 0.7f)))
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MagicEmerald)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = cardNumberBadge,
                                color = Color(0xFF020617),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                        Icon(
                            imageVector = Icons.Default.SettingsInputComponent,
                            contentDescription = null,
                            tint = MagicEmerald,
                            modifier = Modifier.size(16.dp)
                        )
                        Column {
                            Text(
                                text = "TRẠNG THÁI TÍNH NĂNG & PHẦN CỨNG MÁY",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Black,
                                softWrap = true
                            )
                            Text(
                                text = "Chạm vào từng ô để bật/tắt nhanh • Luôn hiện đầy đủ 100%",
                                color = TextSecondary,
                                fontSize = 9.5.sp,
                                softWrap = true
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(MagicCyan.copy(alpha = 0.15f))
                            .border(1.dp, MagicCyan.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                            .clickable { onRefresh() }
                            .padding(horizontal = 8.dp, vertical = 5.dp)
                            .testTag("refresh_hardware_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Làm mới",
                                tint = MagicCyan,
                                modifier = Modifier.size(13.dp)
                            )
                            Text(
                                text = "Làm mới",
                                color = MagicCyan,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // 2-Column Compact Grid of Features
                val features = deviceInfo.features
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    features.chunked(2).forEach { pair ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            pair.forEach { feat ->
                                val badgeColor = if (feat.isEnabled) MagicEmerald else TextMuted
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(MagicSurfaceCard)
                                        .border(
                                            1.dp,
                                            if (feat.isEnabled) MagicEmerald.copy(alpha = 0.4f) else MagicBorder,
                                            RoundedCornerShape(8.dp)
                                        )
                                        .clickable { onToggleFeature(feat.id, feat.isEnabled) }
                                        .padding(horizontal = 8.dp, vertical = 6.dp)
                                ) {
                                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = feat.name,
                                                color = Color.White,
                                                fontSize = 10.5.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.weight(1f),
                                                softWrap = true
                                            )
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(5.dp))
                                                    .background(
                                                        if (feat.isEnabled) MagicEmerald.copy(alpha = 0.2f)
                                                        else MagicAmber.copy(alpha = 0.2f)
                                                    )
                                                    .padding(horizontal = 5.dp, vertical = 1.dp)
                                            ) {
                                                Text(
                                                    text = if (feat.isEnabled) "BẬT" else "TẮT",
                                                    color = if (feat.isEnabled) MagicEmerald else MagicAmber,
                                                    fontSize = 8.sp,
                                                    fontWeight = FontWeight.Black
                                                )
                                            }
                                        }
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Box(
                                                modifier = Modifier
                                                    .size(6.dp)
                                                    .clip(CircleShape)
                                                    .background(badgeColor)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = feat.statusText,
                                                color = if (feat.isEnabled) MagicEmerald else MagicAmber,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                softWrap = true
                                            )
                                        }
                                    }
                                }
                            }
                            if (pair.size == 1) {
                                Spacer(modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }
            }
        }

        // Card 2: Compact Full Hardware Specifications (Always Expanded - No Hidden Toggle)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = androidx.compose.foundation.BorderStroke(
                1.dp,
                Brush.linearGradient(listOf(MagicCyan.copy(alpha = 0.7f), MagicBlue.copy(alpha = 0.7f)))
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Memory,
                            contentDescription = null,
                            tint = MagicCyan,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "THÔNG SỐ PHẦN CỨNG: ${deviceInfo.manufacturer} ${deviceInfo.model} (${deviceInfo.version})",
                            color = Color.White,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Black,
                            softWrap = true
                        )
                    }
                }

                // Side-by-side RAM & ROM Progress Bars
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(MagicSurfaceCard)
                            .padding(7.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(
                                text = "💾 RAM: ${deviceInfo.ram}",
                                color = MagicCyan,
                                fontSize = 9.5.sp,
                                fontWeight = FontWeight.Bold,
                                softWrap = true
                            )
                            LinearProgressIndicator(
                                progress = { (deviceInfo.ramUsedPercent / 100f).coerceIn(0f, 1f) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(4.dp)
                                    .clip(RoundedCornerShape(2.dp)),
                                color = MagicCyan,
                                trackColor = Color(0xFF1E293B)
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(MagicSurfaceCard)
                            .padding(7.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(
                                text = "💿 ROM: ${deviceInfo.storage}",
                                color = MagicPurple,
                                fontSize = 9.5.sp,
                                fontWeight = FontWeight.Bold,
                                softWrap = true
                            )
                            LinearProgressIndicator(
                                progress = { (deviceInfo.storageUsedPercent / 100f).coerceIn(0f, 1f) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(4.dp)
                                    .clip(RoundedCornerShape(2.dp)),
                                color = MagicPurple,
                                trackColor = Color(0xFF1E293B)
                            )
                        }
                    }
                }

                // All Hardware Specs in a compact 2-column grid (Always visible!)
                val allHwItems = listOf(
                    "⚡ Vi xử lý (SoC)" to "${deviceInfo.soc} (${deviceInfo.cpuCores})",
                    "🔋 Pin & Nhiệt độ" to "${deviceInfo.batteryLevel}% (${deviceInfo.temp}) • ${deviceInfo.batteryStatus}",
                    "🖥 Màn hình & Quét" to "${deviceInfo.screen} • ${deviceInfo.refreshRate}",
                    "✨ Bản dựng ROM" to "${deviceInfo.magicOS} (${deviceInfo.securityPatch})",
                    "📱 Mã máy & ABI" to "${deviceInfo.deviceCodename} • ${deviceInfo.abi}",
                    "🎮 Chip đồ họa (GPU)" to deviceInfo.gpu,
                    "🔄 Sức khỏe Pin" to "${deviceInfo.batteryHealth} • Chu kỳ: ${if (deviceInfo.batteryCycleCount != "N/A") deviceInfo.batteryCycleCount else "Tốt"}",
                    "🧭 Cảm biến & Uptime" to "${deviceInfo.sensorCount} cảm biến • Uptime: ${deviceInfo.uptime}"
                )

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    allHwItems.chunked(2).forEach { pair ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            pair.forEach { (label, value) ->
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(7.dp))
                                        .background(MagicSurfaceCard)
                                        .padding(horizontal = 7.dp, vertical = 5.dp)
                                ) {
                                    Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
                                        Text(
                                            text = label,
                                            color = TextMuted,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            softWrap = true
                                        )
                                        Text(
                                            text = value,
                                            color = TextPrimary,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            softWrap = true
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
