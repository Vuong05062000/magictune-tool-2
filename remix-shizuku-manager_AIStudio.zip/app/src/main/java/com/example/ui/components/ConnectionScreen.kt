package com.example.ui.components

import android.content.Intent
import android.provider.Settings
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.shell.ShellEngineState
import com.example.ui.theme.MagicAmber
import com.example.ui.theme.MagicBlue
import com.example.ui.theme.MagicBorder
import com.example.ui.theme.MagicCyan
import com.example.ui.theme.MagicCyanLight
import com.example.ui.theme.MagicEmerald
import com.example.ui.theme.MagicSurfaceCard
import com.example.ui.theme.MagicSurfaceDark
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun ConnectionScreen(
    shellState: ShellEngineState,
    isBusy: Boolean,
    onRequestShizukuPermission: () -> Unit,
    onOpenShizukuApp: () -> Unit,
    onOpenDeveloperSettings: () -> Unit,
    onOpenWlanDialog: () -> Unit = {}
) {
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // PHẦN 1: DÙNG NGAY KHÔNG CẦN KẾT NỐI (Dễ nhất cho người lớn tuổi & trẻ em)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, MagicCyan.copy(alpha = 0.6f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "👆 CHỈNH NHANH (KHÔNG CẦN KẾT NỐI)",
                        color = MagicCyanLight,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier.weight(1f)
                    )
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(MagicEmerald.copy(alpha = 0.2f))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "Dùng được ngay",
                            color = MagicEmerald,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Text(
                    text = "Bấm trực tiếp vào nút bạn cần bên dưới để mở thẳng trang cài đặt của điện thoại:",
                    color = TextSecondary,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )

                val quickRows = listOf(
                    listOf(
                        Triple("🇻🇳 Đổi Tiếng Việt", "Ngôn ngữ & Vùng", Settings.ACTION_LOCALE_SETTINGS),
                        Triple("🔤 Chữ To & Độ Sáng", "Màn hình dễ đọc", Settings.ACTION_DISPLAY_SETTINGS)
                    ),
                    listOf(
                        Triple("🔔 Mở Chuông App", "Bật thông báo Zalo", Settings.ACTION_ALL_APPS_NOTIFICATION_SETTINGS),
                        Triple("⌨️ Đổi Bàn Phím", "Gõ Tiếng Việt", Settings.ACTION_INPUT_METHOD_SETTINGS)
                    ),
                    listOf(
                        Triple("🔋 Giữ App Chạy Ngầm", "Không bị tắt Zalo", Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS),
                        Triple("👤 Tài Khoản Google", "Đồng bộ danh bạ", Settings.ACTION_SYNC_SETTINGS)
                    )
                )

                quickRows.forEach { rowItems ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        rowItems.forEach { (title, subtitle, action) ->
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .defaultMinSize(minHeight = 68.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(MagicSurfaceCard)
                                    .border(1.dp, MagicBorder, RoundedCornerShape(14.dp))
                                    .clickable {
                                        try {
                                            context.startActivity(
                                                Intent(action).apply {
                                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                                }
                                            )
                                        } catch (_: Exception) {
                                            try {
                                                context.startActivity(
                                                    Intent(Settings.ACTION_SETTINGS).apply {
                                                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                                    }
                                                )
                                            } catch (_: Exception) {}
                                        }
                                    }
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                contentAlignment = Alignment.CenterStart
                            ) {
                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text(
                                        text = title,
                                        color = Color.White,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                    Text(
                                        text = subtitle,
                                        color = MagicCyanLight,
                                        fontSize = 11.5.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // PHẦN 2: KẾT NỐI ĐỂ TỰ ĐỘNG SỬA HẾT LỖI (3 BƯỚC ĐƠN GIẢN, CHỮ TO)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = androidx.compose.foundation.BorderStroke(
                1.5.dp,
                Brush.linearGradient(listOf(MagicEmerald, MagicCyan))
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "⚡ TỰ ĐỘNG SỬA TẤT CẢ (CHỈ 3 BƯỚC)",
                        color = MagicEmerald,
                        fontSize = 15.5.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier.weight(1f)
                    )
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(MagicAmber.copy(alpha = 0.2f))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "Chưa kết nối",
                            color = MagicAmber,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }

                Text(
                    text = "Muốn ứng dụng tự động sửa hết mọi lỗi chỉ bằng 1 nút bấm, bạn hãy làm theo 3 bước dễ hiểu dưới đây:",
                    color = TextSecondary,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )

                // 3 Bước to rõ ràng
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFF0F172A))
                        .border(1.dp, MagicEmerald.copy(alpha = 0.4f), RoundedCornerShape(14.dp))
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    EasyStepRow(
                        stepNumber = "1",
                        title = "Bật Gỡ Lỗi Qua Wi-Fi",
                        desc = "Bấm nút 'Mở Cài Đặt Phát Triển' bên dưới ➔ Bật công tắc 'Gỡ lỗi qua Wi-Fi'."
                    )
                    EasyStepRow(
                        stepNumber = "2",
                        title = "Lấy Mã 6 Chữ Số",
                        desc = "Bấm vào dòng chữ 'Gỡ lỗi qua Wi-Fi' ➔ Chọn 'Ghép nối thiết bị bằng mã ghép đôi'."
                    )
                    EasyStepRow(
                        stepNumber = "3",
                        title = "Nhập 6 Số Để Kết Nối",
                        desc = "Gõ 6 chữ số đó vào thông báo ở trên cùng màn hình (hoặc bảng nhập mã) là xong!"
                    )
                }

                // Banner Khuyên Dùng Cách 1 (Kết nối trực tiếp)
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MagicCyan.copy(alpha = 0.12f)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MagicCyan.copy(alpha = 0.6f))
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ThumbUp,
                            contentDescription = null,
                            tint = MagicCyanLight,
                            modifier = Modifier.size(24.dp)
                        )
                        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(
                                text = "👍 KHUYÊN DÙNG: HÃY CHỌN CÁCH 1 (KẾT NỐI TRỰC TIẾP)",
                                color = MagicCyanLight,
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                text = "App của chúng ta hoàn toàn có thể kết nối trực tiếp độc lập mà KHÔNG CẦN Shizuku. Kết nối Shizuku còn không ổn định và không tốt bằng việc kết nối trực tiếp (Shizuku hay bị MagicOS đóng băng hoặc lỗi ngắt kết nối Binder).",
                                color = TextPrimary,
                                fontSize = 11.5.sp,
                                lineHeight = 16.sp
                            )
                        }
                    }
                }

                // Nút 1: Kết nối trực tiếp qua mã PIN (Không cần cài thêm app)
                Button(
                    onClick = onOpenWlanDialog,
                    modifier = Modifier
                        .fillMaxWidth()
                        .defaultMinSize(minHeight = 72.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (shellState.isWirelessAdbConnected) MagicEmerald else MagicCyan,
                        contentColor = Color(0xFF020617)
                    )
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            imageVector = Icons.Default.Wifi,
                            contentDescription = null,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = if (shellState.isWirelessAdbConnected) {
                                    "✓ ĐÃ KẾT NỐI TRỰC TIẾP THÀNH CÔNG"
                                } else {
                                    "👍 CÁCH 1: KẾT NỐI TRỰC TIẾP (KHUYÊN DÙNG • TỐT NHẤT)"
                                },
                                fontSize = 13.5.sp,
                                fontWeight = FontWeight.Black,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Tự động tìm cổng • Không cần Shizuku • Siêu ổn định 100%",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF020617).copy(alpha = 0.85f),
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }

                // Nút 2: Kết nối qua ứng dụng Shizuku
                val isLiveConnected = shellState.isShizukuRunning && shellState.isShizukuPermissionGranted
                Button(
                    onClick = {
                        if (!shellState.isShizukuInstalled || !shellState.isShizukuRunning) {
                            onOpenShizukuApp()
                        } else {
                            onRequestShizukuPermission()
                        }
                    },
                    enabled = !isLiveConnected,
                    modifier = Modifier
                        .fillMaxWidth()
                        .defaultMinSize(minHeight = 68.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = when {
                            isLiveConnected -> MagicEmerald
                            shellState.isShizukuRunning -> MagicAmber
                            else -> MagicSurfaceCard
                        },
                        contentColor = if (isLiveConnected || shellState.isShizukuRunning) Color(0xFF020617) else TextPrimary
                    ),
                    border = if (!isLiveConnected && !shellState.isShizukuRunning) {
                        androidx.compose.foundation.BorderStroke(1.dp, MagicEmerald.copy(alpha = 0.5f))
                    } else null
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = when {
                                    isLiveConnected -> "✓ ĐÃ KẾT NỐI SHIZUKU THÀNH CÔNG"
                                    shellState.isShizukuRunning && !shellState.isShizukuPermissionGranted -> "🛡️ BẤM CHO PHÉP QUYỀN SHIZUKU"
                                    shellState.isShizukuInstalled -> "🛡️ CÁCH 2: DÙNG SHIZUKU (DỰ PHÒNG • KÉM ỔN ĐỊNH HƠN)"
                                    else -> "🛡️ CÁCH 2: DÙNG SHIZUKU (DỰ PHÒNG • KÉM ỔN ĐỊNH HƠN)"
                                },
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Black,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = when {
                                    isLiveConnected -> "Đã sẵn sàng chạy mọi tính năng"
                                    shellState.isShizukuRunning -> "Shizuku đang chạy • Bấm vào đây để cấp quyền"
                                    else -> "Phụ thuộc app bên ngoài • Dễ bị ngắt ngầm • Nên ưu tiên Cách 1"
                                },
                                fontSize = 10.5.sp,
                                color = if (isLiveConnected || shellState.isShizukuRunning) Color(0xFF020617).copy(alpha = 0.85f) else TextSecondary,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }

                // Hàng nút phụ: Mở Cài Đặt Phát Triển & Mở Shizuku
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onOpenDeveloperSettings,
                        modifier = Modifier
                            .weight(1f)
                            .defaultMinSize(minHeight = 50.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MagicSurfaceCard,
                            contentColor = TextPrimary
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MagicBorder)
                    ) {
                        Icon(imageVector = Icons.Default.Settings, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "Mở Cài Đặt Phát Triển", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = onOpenShizukuApp,
                        modifier = Modifier
                            .weight(1f)
                            .defaultMinSize(minHeight = 50.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MagicSurfaceCard,
                            contentColor = MagicEmerald
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MagicEmerald.copy(alpha = 0.5f))
                    ) {
                        Icon(imageVector = Icons.Default.Security, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (shellState.isShizukuInstalled) "Mở App Shizuku" else "Tải Shizuku",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Danh sách 9 tính năng máy tự động làm giúp bạn (Hiển thị trực tiếp 100%)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MagicSurfaceCard)
                        .border(1.dp, MagicCyan.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
                        .padding(12.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        val features = listOf(
                            "🇻🇳 Đổi sang Tiếng Việt & Giờ Việt Nam chuẩn 24h",
                            "📞 Hiện đúng tên người gọi trong danh bạ (sửa lỗi +84)",
                            "📶 Xóa dấu chấm than (!) trên biểu tượng mạng Wi-Fi",
                            "🚀 Mở sóng 5G & gọi thoại rõ nét VoLTE",
                            "🚫 Tắt sạch tin tức và quảng cáo tiếng Trung Quốc",
                            "📍 Bật định vị chính xác cho Bản đồ, Grab, Xanh SM",
                            "🛡️ Chặn chợ ứng dụng Trung Quốc tự tải đè app",
                            "🔔 Mở 100% chuông báo tin nhắn & cuộc gọi Zalo, Messenger",
                            "🖨️ Hỗ trợ in hóa đơn & đơn hàng ra máy in nhiệt K80"
                        )
                        features.forEach { feat ->
                            Text(
                                text = feat,
                                color = TextPrimary,
                                fontSize = 12.5.sp,
                                lineHeight = 18.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EasyStepRow(
    stepNumber: String,
    title: String,
    desc: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Box(
            modifier = Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(MagicEmerald),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = stepNumber,
                color = Color(0xFF020617),
                fontSize = 14.sp,
                fontWeight = FontWeight.Black
            )
        }
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(
                text = title,
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.Black
            )
            Text(
                text = desc,
                color = TextSecondary,
                fontSize = 12.5.sp,
                lineHeight = 17.sp
            )
        }
    }
}
