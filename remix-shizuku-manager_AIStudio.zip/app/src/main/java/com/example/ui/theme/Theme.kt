package com.example.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.Density
import androidx.compose.runtime.CompositionLocalProvider
import androidx.core.view.WindowCompat

private val DarkColorScheme = darkColorScheme(
    primary = MagicCyan,
    onPrimary = Color(0xFF020617),
    primaryContainer = Color(0xFF083344),
    onPrimaryContainer = MagicCyanLight,
    secondary = MagicBlue,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF1E3A8A),
    onSecondaryContainer = MagicBlueLight,
    tertiary = MagicEmerald,
    onTertiary = Color(0xFF020617),
    background = MagicDarkBackground,
    onBackground = TextPrimary,
    surface = MagicSurfaceDark,
    onSurface = TextPrimary,
    surfaceVariant = MagicSurfaceCard,
    onSurfaceVariant = TextSecondary,
    outline = MagicBorder,
    error = MagicRose,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit,
) {
    val colorScheme = DarkColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                @Suppress("DEPRECATION")
                window.statusBarColor = MagicDarkBackground.toArgb()
                @Suppress("DEPRECATION")
                window.navigationBarColor = MagicDarkBackground.toArgb()
                WindowCompat.getInsetsController(window, view).apply {
                    isAppearanceLightStatusBars = false
                    isAppearanceLightNavigationBars = false
                }
            }
        }
    }

    val currentDensity = LocalDensity.current
    val scaledDensity = Density(
        density = currentDensity.density * 0.90f,
        fontScale = currentDensity.fontScale * 0.90f
    )

    CompositionLocalProvider(LocalDensity provides scaledDensity) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}
