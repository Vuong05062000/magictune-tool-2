package com.example.ui.components

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.MagicTuneRepository
import com.example.ui.theme.*

/**
 * HonorGpsFixCard:
 * Đặc trị lỗi lệch vị trí, trôi GPS, mất sóng vệ tinh & mũi tên la bàn chỉ lệch hướng
 * trên tất cả các dòng máy Honor nội địa (MagicOS China).
 */
@Composable
fun HonorGpsFixCard(
    isGpsOptimized: Boolean,
    onFixGps: () -> Unit,
    onRefreshSatellites: () -> Unit,
    modifier: Modifier = Modifier,
    cardNumberBadge: String = "Ô #34"
) {
    val context = LocalContext.current

    var hasLocationPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        )
    }

    val locationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasLocationPermission = granted
        if (granted) {
            Toast.makeText(context, "Đã cấp quyền vị trí chính xác!", Toast.LENGTH_SHORT).show()
        }
    }

    // Trạng thái GPS thực tế
    var currentLatitude by remember { mutableStateOf<Double?>(null) }
    var currentLongitude by remember { mutableStateOf<Double?>(null) }
    var currentAccuracy by remember { mutableStateOf<Float?>(null) }
    var locationProviderName by remember { mutableStateOf("Đang chờ sóng vệ tinh...") }

    // Trạng thái La Bàn (Compass Heading)
    var compassHeading by remember { mutableFloatStateOf(0f) }
    var compassAccuracy by remember { mutableStateOf("Bình thường") }
    var showCalibrationDialog by remember { mutableStateOf(false) }

    // Lắng nghe cảm biến La Bàn (SensorManager)
    DisposableEffect(Unit) {
        val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
        val rotationVectorSensor = sensorManager?.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        @Suppress("DEPRECATION")
        val orientationSensor = if (rotationVectorSensor == null) {
            sensorManager?.getDefaultSensor(Sensor.TYPE_ORIENTATION)
        } else null

        val sensorListener = object : SensorEventListener {
            val rotationMatrix = FloatArray(9)
            val orientationAngles = FloatArray(3)
            var lastHeading = 0f

            override fun onSensorChanged(event: SensorEvent?) {
                if (event == null) return
                var newHeading = lastHeading
                if (event.sensor.type == Sensor.TYPE_ROTATION_VECTOR) {
                    SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)
                    SensorManager.getOrientation(rotationMatrix, orientationAngles)
                    newHeading = (Math.toDegrees(orientationAngles[0].toDouble()) + 360).toFloat() % 360
                } else if (@Suppress("DEPRECATION") (event.sensor.type == Sensor.TYPE_ORIENTATION)) {
                    newHeading = (event.values[0] + 360) % 360
                }
                // Chỉ kích hoạt recomposition khi hướng la bàn đổi >= 2.5 độ, chống spam 60-100 fps gây khựng giật khi cuộn trang
                if (kotlin.math.abs(newHeading - lastHeading) >= 2.5f) {
                    lastHeading = newHeading
                    compassHeading = newHeading
                }
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
                compassAccuracy = when (accuracy) {
                    SensorManager.SENSOR_STATUS_ACCURACY_HIGH -> "Cao (Chuẩn)"
                    SensorManager.SENSOR_STATUS_ACCURACY_MEDIUM -> "Trung bình"
                    SensorManager.SENSOR_STATUS_ACCURACY_LOW -> "Thấp (Cần xoay số 8)"
                    SensorManager.SENSOR_STATUS_UNRELIABLE -> "Rất kém (Cần hiệu chuẩn)"
                    else -> "Bình thường"
                }
            }
        }

        if (rotationVectorSensor != null) {
            sensorManager?.registerListener(sensorListener, rotationVectorSensor, SensorManager.SENSOR_DELAY_NORMAL)
        } else if (orientationSensor != null) {
            sensorManager?.registerListener(sensorListener, orientationSensor, SensorManager.SENSOR_DELAY_NORMAL)
        }

        onDispose {
            sensorManager?.unregisterListener(sensorListener)
        }
    }

    // Lắng nghe tọa độ GPS (LocationManager)
    DisposableEffect(hasLocationPermission) {
        val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
        val locationListener = object : LocationListener {
            override fun onLocationChanged(loc: Location) {
                currentLatitude = loc.latitude
                currentLongitude = loc.longitude
                currentAccuracy = loc.accuracy
                locationProviderName = if (loc.provider == LocationManager.GPS_PROVIDER) "Vệ Tinh GPS Phần Cứng" else "Mạng Google NLP (Wi-Fi/BTS)"
            }

            @Deprecated("Deprecated in Java")
            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}
        }

        if (hasLocationPermission && locationManager != null) {
            try {
                val lastGps = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                val lastNet = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
                val bestLast = lastGps ?: lastNet
                if (bestLast != null) {
                    currentLatitude = bestLast.latitude
                    currentLongitude = bestLast.longitude
                    currentAccuracy = bestLast.accuracy
                    locationProviderName = if (bestLast.provider == LocationManager.GPS_PROVIDER) "Vệ Tinh GPS" else "Mạng Wi-Fi / BTS"
                }

                if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                    locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000L, 1f, locationListener)
                }
                if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                    locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 2000L, 1f, locationListener)
                }
            } catch (_: SecurityException) {}
        }

        onDispose {
            try {
                locationManager?.removeUpdates(locationListener)
            } catch (_: Exception) {}
        }
    }

    // Chuyển độ góc la bàn sang chữ viết
    val headingDirection = remember(compassHeading) {
        when (compassHeading.toInt()) {
            in 338..360, in 0..22 -> "Bắc (N)"
            in 23..67 -> "Đông Bắc (NE)"
            in 68..112 -> "Đông (E)"
            in 113..157 -> "Đông Nam (SE)"
            in 158..202 -> "Nam (S)"
            in 203..247 -> "Tây Nam (SW)"
            in 248..292 -> "Tây (W)"
            else -> "Tây Bắc (NW)"
        }
    }

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isGpsOptimized) MagicEmerald.copy(alpha = 0.6f) else MagicAmber.copy(alpha = 0.5f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Header Card
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(MagicCyan)
                            .padding(horizontal = 6.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = cardNumberBadge,
                            color = Color(0xFF020617),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                    Column {
                        Text(
                            text = "Đặc Trị GPS, La Bàn & Timestamp Camera",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = "Fix chụp ảnh Khu A báo Khu B, lệch vị trí & trôi GPS",
                            color = TextSecondary,
                            fontSize = 10.5.sp
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isGpsOptimized) MagicEmerald.copy(alpha = 0.22f) else MagicAmber.copy(alpha = 0.22f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (isGpsOptimized) "✓ SUPL GOOGLE" else "⚠️ CẦN FIX GPS",
                        color = if (isGpsOptimized) MagicEmerald else MagicAmber,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }

            // Dashboard Đo Tọa Độ Thực Tế & La Bàn Trực Quan
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF090D16))
                    .border(1.dp, MagicBorder, RoundedCornerShape(12.dp))
                    .padding(12.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "📊 GIÁM SÁT ĐỊNH VỊ THỜI GIAN THỰC",
                            color = MagicCyanLight,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black
                        )
                        if (!hasLocationPermission) {
                            TextButton(
                                onClick = { locationPermissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION) },
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Text("Cấp quyền đo GPS", color = MagicAmber, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    // Tọa độ & Sai số
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1.3f)) {
                            Text(
                                text = "📍 Tọa độ hiện tại:",
                                color = TextMuted,
                                fontSize = 10.5.sp
                            )
                            if (currentLatitude != null && currentLongitude != null) {
                                Text(
                                    text = "%.5f, %.5f".format(currentLatitude, currentLongitude),
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Độ chính xác: ±${currentAccuracy?.toInt() ?: 0}m (${locationProviderName})",
                                    color = if ((currentAccuracy ?: 99f) <= 15f) MagicEmerald else MagicAmber,
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            } else {
                                Text(
                                    text = if (hasLocationPermission) "Đang tìm kiếm vệ tinh GPS..." else "Chưa có quyền vị trí",
                                    color = TextSecondary,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        // Mũi tên la bàn trực quan
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.weight(0.9f)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Navigation,
                                    contentDescription = null,
                                    tint = MagicRoseLight,
                                    modifier = Modifier
                                        .size(24.dp)
                                        .rotate(compassHeading)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Column {
                                    Text(
                                        text = "${compassHeading.toInt()}° $headingDirection",
                                        color = Color.White,
                                        fontSize = 11.5.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                    Text(
                                        text = "La bàn: $compassAccuracy",
                                        color = if (compassAccuracy.contains("Cao")) MagicEmerald else MagicAmber,
                                        fontSize = 9.5.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Giải thích nguyên nhân gốc rễ trên máy nội địa (Đặc biệt Honor Magic 6 & Magic 7)
            Text(
                text = "💡 Đặc trị lỗi sai vị trí Timestamp Camera (Đặc biệt trên Honor Magic 6 & Magic 7 - MagicOS 8/9):\n" +
                        "• Xóa dữ liệu & tắt hẳn gói định vị Cao Đức ngầm `com.amap.android.ams` trên Magic 6/7 gây lệch tọa độ Mars (GCJ-02) 500m–2km.\n" +
                        "• Tắt tính năng 'Vị trí gần đúng' (Fuzzy Location) của MagicOS & mở khóa 100% chip vệ tinh băng tần kép L1+L5 (Full GNSS).\n" +
                        "• Cấp quyền quét Wi-Fi/BLE Android 14/15 (`NEARBY_WIFI_DEVICES`) và khóa nóng tọa độ thực WGS-84 ngay lập tức cho Timestamp Camera.",
                color = TextSecondary,
                fontSize = 11.sp,
                lineHeight = 15.sp
            )

            // NÚT CHÍNH: 1-CHẠM FIX TẬN GỐC ĐỊNH VỊ & TIMESTAMP CAMERA
            Button(
                onClick = onFixGps,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MagicCyan, contentColor = Color(0xFF020617))
            ) {
                Icon(imageVector = Icons.Default.GpsFixed, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "📸 ĐẶC TRỊ TIMESTAMP CAMERA & FIX SAI VỊ TRÍ (KHU A ↔ KHU B)",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    maxLines = 1
                )
            }

            // Hàng công cụ phụ
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Nút mở trang ẩn Google Location Accuracy
                OutlinedButton(
                    onClick = {
                        val opened = MagicTuneRepository.openGoogleLocationAccuracySettings(context)
                        if (opened) {
                            Toast.makeText(context, "Hãy gạt BẬT 'Độ chính xác của vị trí bằng Google'!", Toast.LENGTH_LONG).show()
                        } else {
                            Toast.makeText(context, "Không mở được trang Google Location. Đảm bảo máy đã cài Google Play Services!", Toast.LENGTH_LONG).show()
                        }
                    },
                    modifier = Modifier.weight(1f).height(38.dp),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MagicCyanLight),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MagicCyan.copy(alpha = 0.5f))
                ) {
                    Icon(imageVector = Icons.Default.ShareLocation, contentDescription = null, modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Trang ẩn Google Vị Trí", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }

                // Nút mở Quản lý khởi động pin MagicOS
                OutlinedButton(
                    onClick = {
                        val opened = MagicTuneRepository.openHonorAppLaunchSettings(context)
                        if (opened) {
                            Toast.makeText(context, "Tìm Google Maps / Grab -> Chọn 'Quản lý thủ công' -> Bật cả 3 mục!", Toast.LENGTH_LONG).show()
                        } else {
                            Toast.makeText(context, "Không mở được Cài đặt khởi động Honor", Toast.LENGTH_SHORT).show()
                        }
                    },
                    modifier = Modifier.weight(1f).height(38.dp),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MagicEmerald),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MagicEmerald.copy(alpha = 0.5f))
                ) {
                    Icon(imageVector = Icons.Default.BatteryChargingFull, contentDescription = null, modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Khởi Động Pin Maps", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }

            // Hàng công cụ La Bàn & Vệ Tinh
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Nút hướng dẫn cân chỉnh la bàn
                OutlinedButton(
                    onClick = { showCalibrationDialog = true },
                    modifier = Modifier.weight(1f).height(36.dp),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MagicAmber),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MagicAmber.copy(alpha = 0.5f))
                ) {
                    Icon(imageVector = Icons.Default.Explore, contentDescription = null, modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("🧭 Hướng dẫn xoay la bàn", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }

                // Nút làm mới vệ tinh A-GPS
                OutlinedButton(
                    onClick = onRefreshSatellites,
                    modifier = Modifier.weight(1f).height(36.dp),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MagicPurpleLight),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MagicPurpleLight.copy(alpha = 0.5f))
                ) {
                    Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("🔄 Nạp vệ tinh A-GPS", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    // Dialog hướng dẫn cân chỉnh la bàn
    if (showCalibrationDialog) {
        AlertDialog(
            onDismissRequest = { showCalibrationDialog = false },
            containerColor = MagicSurfaceDark,
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Explore, contentDescription = null, tint = MagicAmber, modifier = Modifier.size(22.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Hiệu Chuẩn La Bàn (Khắc Phục Chỉ Lệch Hướng)", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Black)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "📱 Hiện tượng: Khi mở Google Maps dẫn đường, chấm xanh bị quay ngược hoặc mũi tên lệch 90° - 180° so với hướng xe chạy.\n\n" +
                                "👉 CÁCH HIỆU CHUẨN ĐƠN GIẢN:\n" +
                                "1. Cầm điện thoại trên tay và xoay cổ tay theo HÌNH SỐ 8 (∞) khoảng 3 - 5 lần trong không khí.\n" +
                                "2. Tránh xa các ốp lưng có nam châm (MagSafe) hoặc vật liệu kim loại dày làm nhiễu từ trường.\n" +
                                "3. Mở Google Maps -> Bấm vào chấm tròn màu xanh thể hiện vị trí của bạn -> Chọn 'Hiệu chỉnh la bàn' (Calibrate) để Google Maps dùng camera Live View quét góc phố.",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showCalibrationDialog = false
                        MagicTuneRepository.openGoogleMapsCompassCalibration(context)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MagicCyan)
                ) {
                    Text("Mở Google Maps ngay", color = Color(0xFF020617), fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCalibrationDialog = false }) {
                    Text("Đã hiểu", color = TextSecondary)
                }
            }
        )
    }
}
