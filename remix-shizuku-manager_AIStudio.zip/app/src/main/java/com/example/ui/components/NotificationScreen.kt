package com.example.ui.components

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FindInPage
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PictureInPictureAlt
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PowerOff
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DiagnosticScanResult
import com.example.data.FloatingMiniWindowState
import com.example.ui.theme.*

@Composable
fun NotificationScreen(
    isBusy: Boolean,
    diagnosticScan: DiagnosticScanResult = DiagnosticScanResult(),
    floatingState: FloatingMiniWindowState = FloatingMiniWindowState(),
    onFixAllNotifications: () -> Unit,
    onBatchGrantPermissions: () -> Unit = onFixAllNotifications,
    onRunDiagnosticScan: () -> Unit = {},
    onResetAndRescan: () -> Unit = {},
    onFixSingleApp: (String, String) -> Unit = { _, _ -> },
    onOpenAppNotificationSettings: (String) -> Unit = {},
    onOpenAppDetailsSettings: (String) -> Unit = {},
    onGrantSelfControlAndOverlay: () -> Unit = {},
    onRequestOverlaySettingIntent: () -> Unit = {},
    onStartLiveFloatingAutomation: () -> Unit = {},
    onEnterPipMode: () -> Unit = {},
    onFixFacebook: () -> Unit,
    onRestoreGmailAndFacebookDefault: () -> Unit = {},
    onBoostBatching: () -> Unit,
    onPrioritizeCustomSounds: () -> Unit,
    onRemovePowerGenius: () -> Unit,
    onTestNotification: (String, String) -> Unit,
    isAutoWakeupEnabled: Boolean = true,
    onToggleAutoWakeup: (Boolean) -> Unit = {},
    isChargingNotificationEnabled: Boolean = false,
    onToggleChargingNotification: (Boolean) -> Unit = {},
    isSearchNotificationEnabled: Boolean = true,
    onToggleSearchNotification: (Boolean) -> Unit = {},
    onNavigateToUniversalFix: () -> Unit = {}
) {
    var selectedScanSection by remember { mutableIntStateOf(0) }
    val localContext = androidx.compose.ui.platform.LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Ô #14: 1 Chạm Mở Chuông Zalo, Messenger, Facebook
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = androidx.compose.foundation.BorderStroke(
                1.5.dp,
                Brush.linearGradient(listOf(MagicBlue, MagicEmerald))
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(MagicBlue)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "Ô #14",
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                    Text(
                        text = "🔔 MỞ 100% CHUÔNG BÁO ZALO, MESSENGER, FACEBOOK",
                        color = Color.White,
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Black,
                        softWrap = true
                    )
                }

                Text(
                    text = "Giúp điện thoại đổ chuông to, hiện thông báo nổi trên màn hình ngay lập tức khi có người gọi điện hoặc nhắn tin đến.",
                    color = TextSecondary,
                    fontSize = 13.5.sp,
                    lineHeight = 19.sp,
                    softWrap = true
                )

                // ==========================================
                // TÁCH BIỆT 2 NÚT TỰ ĐỘNG RIÊNG BIỆT RÕ RÀNG
                // ==========================================

                // NÚT 1: TỰ ĐỘNG CẤP QUYỀN HÀNG LOẠT (CHẠY NGẦM)
                Button(
                    onClick = onBatchGrantPermissions,
                    enabled = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .defaultMinSize(minHeight = 78.dp)
                        .testTag("batch_grant_permissions_button"),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 14.dp, vertical = 10.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MagicBlue,
                        contentColor = Color.White
                    )
                ) {
                    if (isBusy) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(24.dp),
                            color = Color.White,
                            strokeWidth = 2.5.dp
                        )
                    } else {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(
                                imageVector = Icons.Default.Security,
                                contentDescription = null,
                                modifier = Modifier.size(26.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "⚡ 1. TỰ ĐỘNG CẤP QUYỀN HÀNG LOẠT (CHẠY NGẦM)",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 13.5.sp,
                                    lineHeight = 18.sp,
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "Cấp quyền thông báo, chạy ngầm, bỏ tối ưu pin siêu tốc trong 3s (Không mở màn hình)",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 11.sp,
                                    color = MagicCyanLight,
                                    lineHeight = 15.sp,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                }

                // Hộp giải thích phương thức fix ngầm chuyên sâu
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MagicSurfaceCard)
                        .border(1.dp, MagicCyan.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
                        .padding(10.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = "💡 TỰ ĐỘNG FIX NGẦM CHUYÊN SÂU 100% TOÀN DIỆN!",
                            color = MagicCyanLight,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = "• Hệ thống tự động cấu hình ngầm qua lệnh WLAN ADB: Kích hoạt toàn diện mọi kênh thông báo, bật Biểu ngữ nổi, Mở khóa màn hình, Bật chuông, Vượt chế độ không làm phiền và cấp full quyền chạy ngầm cho tất cả App ngay lập tức mà không cần mở cài đặt thủ công.",
                            color = MagicEmerald,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            lineHeight = 15.sp
                        )
                    }
                }
            }
        }

        // Ô #15: Thẻ Đặc Trị Cứng Đầu Gmail & Facebook Trên Honor
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = androidx.compose.foundation.BorderStroke(
                1.5.dp,
                Brush.linearGradient(listOf(MagicRose, MagicAmber))
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MagicRose)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "Ô #15",
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                        Text(
                            text = "🔥 ĐẶC TRỊ DIỆT NGẦM GMAIL & FACEBOOK HONOR",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(MagicAmber.copy(alpha = 0.2f))
                            .padding(horizontal = 6.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "Ưu Tiên Số 1",
                            color = MagicAmber,
                            fontSize = 9.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Text(
                    text = "Máy Honor nội địa TQ có trình AI PowerGenius bóp nghẹt Gmail & Facebook. Bấm nút dưới đây để ép 100% ứng dụng chạy ngầm, không trễ tin nhắn và đổ chuông tức thì:",
                    color = TextSecondary,
                    fontSize = 11.5.sp,
                    lineHeight = 16.sp,
                    softWrap = true
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onFixFacebook,
                        modifier = Modifier
                            .weight(1.4f)
                            .defaultMinSize(minHeight = 56.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MagicRose,
                            contentColor = Color.White
                        )
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Security, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Column {
                                Text("🔥 BẬT FIX CỨNG ĐẦU GMAIL & FB", fontSize = 11.5.sp, fontWeight = FontWeight.Black)
                                Text("Phá gom cụm 0s • Ép Active ngầm", fontSize = 9.5.sp, color = Color.White.copy(alpha = 0.85f))
                            }
                        }
                    }

                    OutlinedButton(
                        onClick = onRestoreGmailAndFacebookDefault,
                        modifier = Modifier
                            .weight(1f)
                            .defaultMinSize(minHeight = 56.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimary),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MagicBorder)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Refresh, contentDescription = null, tint = TextMuted, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Column {
                                Text("🔄 HOÀN TÁC", fontSize = 11.sp, fontWeight = FontWeight.Black)
                                Text("Về mặc định gốc", fontSize = 9.sp, color = TextMuted)
                            }
                        }
                    }
                }
            }
        }

        // GỢI Ý WEB ADB CHUYÊN SÂU CHO MÁY HONOR
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF131D31)),
            border = androidx.compose.foundation.BorderStroke(1.2.dp, MagicCyan)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.Security, contentDescription = null, tint = MagicCyanLight, modifier = Modifier.size(22.dp))
                    Text(
                        text = "🌐 CẤP QUYỀN & FIX THÔNG BÁO MẠNH HƠN QUA WEB ADB",
                        color = MagicCyanLight,
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Black
                    )
                }
                Text(
                    text = "Lệnh gỡ lỗi qua WLAN có thể bị MagicOS hạn chế một số quyền AppOps bảo mật. Để cấp quyền sâu 100% không bao giờ gặp lỗi từ chối, hãy cắm cáp USB vào máy tính hoặc mở trình duyệt truy cập công cụ hoàn toàn miễn phí:",
                    color = Color.White.copy(alpha = 0.88f),
                    fontSize = 10.5.sp,
                    lineHeight = 15.sp
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "magictunehonor.ai.studio",
                        color = MagicAmberLight,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Black
                    )
                    Button(
                        onClick = {
                            try {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://magictunehonor.ai.studio"))
                                localContext.startActivity(intent)
                            } catch (_: Exception) {}
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MagicCyan, contentColor = Color(0xFF020617)),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text("Mở WebADB", fontSize = 11.sp, fontWeight = FontWeight.Black)
                    }
                }
            }
        }

        // Ô #16: 4 nút bấm riêng biệt: TÁCH BIỆT TÍNH NĂNG FIX THÔNG BÁO VÀ FIX QUYỀN HẠN
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = androidx.compose.foundation.BorderStroke(1.dp, MagicBorder)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(5.dp))
                            .background(MagicCyan)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "Ô #16",
                            color = Color(0xFF020617),
                            fontSize = 9.5.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                    Text(
                        text = "⚡ 4 CÔNG CỤ TÁCH BIỆT: THÔNG BÁO • QUYỀN • CHUÔNG • GIỮ NGẦM",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Black
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Button(
                        onClick = onFixAllNotifications,
                        modifier = Modifier
                            .weight(1f)
                            .defaultMinSize(minHeight = 56.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MagicSurfaceCard,
                            contentColor = Color.White
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MagicRose.copy(alpha = 0.65f))
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "🔔 Fix Riêng Thông Báo",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Black,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = "Bật Biểu ngữ & Màn khóa",
                                fontSize = 9.5.sp,
                                color = MagicRoseLight,
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    Button(
                        onClick = onBatchGrantPermissions,
                        modifier = Modifier
                            .weight(1f)
                            .defaultMinSize(minHeight = 56.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MagicSurfaceCard,
                            contentColor = Color.White
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MagicCyan.copy(alpha = 0.65f))
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "⚡ Fix Riêng Quyền Hạn",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Black,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = "Chạy ngầm & Tự đánh thức",
                                fontSize = 9.5.sp,
                                color = MagicCyanLight,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Button(
                        onClick = onPrioritizeCustomSounds,
                        modifier = Modifier
                            .weight(1f)
                            .defaultMinSize(minHeight = 54.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MagicSurfaceCard,
                            contentColor = Color.White
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MagicAmber.copy(alpha = 0.5f))
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "🔊 Chuông Riêng",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Black,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = "Đúng tiếng Zalo",
                                fontSize = 10.sp,
                                color = MagicAmber,
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    Button(
                        onClick = onRemovePowerGenius,
                        modifier = Modifier
                            .weight(1f)
                            .defaultMinSize(minHeight = 54.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MagicSurfaceCard,
                            contentColor = Color.White
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MagicRose.copy(alpha = 0.5f))
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "🛡️ Giữ Chạy Ngầm",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Black,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = "Không tự tắt app",
                                fontSize = 10.sp,
                                color = MagicRoseLight,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
        }

        // Ô #17: Deep Diagnostic Scanner Card (Luôn hiện trực tiếp - bỏ nút thu gọn)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = androidx.compose.foundation.BorderStroke(
                1.dp,
                if (diagnosticScan.totalRemainingIssues == 0 && diagnosticScan.hasScanned)
                    MagicEmerald.copy(alpha = 0.5f)
                else
                    MagicAmber.copy(alpha = 0.5f)
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(5.dp))
                                .background(MagicAmber)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "Ô #17",
                                color = Color(0xFF020617),
                                fontSize = 9.5.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                        Icon(
                            imageVector = Icons.Default.FindInPage,
                            contentDescription = null,
                            tint = MagicAmber,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "TRÌNH QUÉT CHẨN ĐOÁN THÔNG BÁO & QUYỀN APP",
                            color = Color.White,
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                    Text(
                        text = "Lần quét: ${diagnosticScan.lastScanTime}",
                        color = TextMuted,
                        fontSize = 9.5.sp
                    )
                }

                Text(
                    text = "Quét kiểm tra toàn bộ nguyên nhân gây chậm thông báo chưa xử lý, phát hiện các app còn đang 'Báo nhẹ nhàng' / chưa bật biểu ngữ nổi và các app bị thiếu quyền chạy ngầm:",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    lineHeight = 16.sp
                )

                // Nút Quét Lỗi (Full width)
                Button(
                    onClick = onRunDiagnosticScan,
                    enabled = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .defaultMinSize(minHeight = 64.dp)
                        .testTag("run_diagnostic_scan_button"),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 10.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MagicAmber,
                        contentColor = Color(0xFF020617)
                    )
                ) {
                    Icon(imageVector = Icons.Default.FindInPage, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (diagnosticScan.isScanning) "Đang quét hệ thống..." else "Quét Kiểm Tra Ngay Lập Tức",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black
                    )
                }

                // Nút Xóa Bộ Đệm & Quét Lại Thực Tế (Tránh tình trạng báo 0 app do bộ đệm cũ) + Nút Cấp Quyền Ngầm Nhanh
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onResetAndRescan,
                        modifier = Modifier
                            .weight(1f)
                            .defaultMinSize(minHeight = 64.dp)
                            .testTag("reset_cache_and_rescan_button"),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 8.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MagicCyanLight),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MagicCyan.copy(alpha = 0.5f))
                    ) {
                        Text(
                            text = "🔄 Xóa Đệm & Quét Lại\nToàn Bộ App Thực Tế",
                            fontSize = 10.5.sp,
                            lineHeight = 14.sp,
                            fontWeight = FontWeight.Black,
                            textAlign = TextAlign.Center
                        )
                    }

                    OutlinedButton(
                        onClick = onFixAllNotifications,
                        modifier = Modifier
                            .weight(1f)
                            .defaultMinSize(minHeight = 64.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 8.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MagicEmeraldLight),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MagicEmerald.copy(alpha = 0.5f))
                    ) {
                        Text(
                            text = "⚡ Cấp Nhanh Quyền Ngầm\n(Chạy Nền Không Mở UI)",
                            fontSize = 10.5.sp,
                            lineHeight = 14.sp,
                            fontWeight = FontWeight.Black,
                            textAlign = TextAlign.Center
                        )
                    }
                }

                // 3 Sub-Tabs for Diagnostic Scan Results (Comfortable 2-line height)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(
                        0 to "Nguyên nhân trễ\n(${diagnosticScan.unfixedSystemCausesCount})",
                        1 to "Báo nhẹ nhàng\n(${diagnosticScan.unfixedGentleBannerCount})",
                        2 to "Thiếu quyền\n(${diagnosticScan.unfixedPermissionCount})"
                    ).forEach { (idx, label) ->
                        val selected = selectedScanSection == idx
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .defaultMinSize(minHeight = 52.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (selected) MagicCyan.copy(alpha = 0.22f) else MagicSurfaceCard)
                                .border(1.dp, if (selected) MagicCyan else MagicBorder, RoundedCornerShape(8.dp))
                                .clickable { selectedScanSection = idx }
                                .padding(vertical = 6.dp, horizontal = 4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = label,
                                color = if (selected) MagicCyanLight else TextSecondary,
                                fontSize = 10.5.sp,
                                lineHeight = 14.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }

                // Priority Sorting Banner
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(MagicCyan.copy(alpha = 0.1f))
                        .border(1.dp, MagicCyan.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "⚡ Cơ chế thông minh: Ưu tiên đẩy các ứng dụng & nguyên nhân đang gặp vấn đề lên ĐẦU DANH SÁCH. Khi bấm sửa tự động, hệ thống chỉ sửa các app gặp lỗi (bỏ qua app đã tốt để không tốn thời gian).",
                        color = MagicCyanLight,
                        fontSize = 10.5.sp,
                        lineHeight = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                // Display Selected Scan Section Content
                when (selectedScanSection) {
                    0 -> {
                        val sortedCauses = remember(diagnosticScan.systemDelayCauses) {
                            diagnosticScan.systemDelayCauses.sortedBy { it.isFixed }
                        }
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            sortedCauses.forEach { issue ->
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(MagicSurfaceCard)
                                        .border(
                                            1.dp,
                                            if (issue.isFixed) MagicEmerald.copy(alpha = 0.35f) else MagicRose.copy(alpha = 0.4f),
                                            RoundedCornerShape(10.dp)
                                        )
                                        .padding(10.dp)
                                ) {
                                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(8.dp)
                                                        .clip(CircleShape)
                                                        .background(if (issue.isFixed) MagicEmerald else MagicRose)
                                                )
                                                Text(
                                                    text = issue.title,
                                                    color = Color.White,
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(6.dp))
                                                    .background(
                                                        if (issue.isFixed) MagicEmerald.copy(alpha = 0.2f) else MagicRose.copy(alpha = 0.22f)
                                                    )
                                                    .clickable { onFixAllNotifications() }
                                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                                            ) {
                                                Text(
                                                    text = if (issue.isFixed) "✓ Đã xử lý" else "⚡ Xử lý ngay",
                                                    color = if (issue.isFixed) MagicEmerald else MagicRoseLight,
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Black
                                                )
                                            }
                                        }
                                        Text(
                                            text = issue.description,
                                            color = TextSecondary,
                                            fontSize = 10.sp,
                                            lineHeight = 14.sp
                                        )
                                    }
                                }
                            }
                        }
                    }

                    1 -> {
                        val sortedGentleApps = remember(diagnosticScan.gentleAndBannerApps) {
                            diagnosticScan.gentleAndBannerApps.sortedWith(
                                compareBy<com.example.data.AppNotificationDiagnostic> { !it.hasAnyNotificationIssue }
                                    .thenBy { !it.hasAnyPermissionIssue }
                                    .thenBy { it.appName.lowercase() }
                            )
                        }
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            sortedGentleApps.take(20).forEach { appDiag ->
                                val ok = !appDiag.hasAnyNotificationIssue
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(MagicSurfaceCard)
                                        .border(
                                            1.dp,
                                            if (ok) MagicEmerald.copy(alpha = 0.35f) else MagicAmber.copy(alpha = 0.45f),
                                            RoundedCornerShape(10.dp)
                                        )
                                        .padding(10.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(
                                            modifier = Modifier.weight(1f),
                                            verticalArrangement = Arrangement.spacedBy(2.dp)
                                        ) {
                                            Text(
                                                text = appDiag.appName,
                                                color = Color.White,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                text = if (ok) {
                                                    "✅ Đã tắt Báo nhẹ nhàng • Đã bật Biểu ngữ nổi"
                                                } else {
                                                    "⚠️ Còn Báo nhẹ nhàng & Chưa bật đầy đủ biểu ngữ"
                                                },
                                                color = if (ok) MagicEmeraldLight else MagicAmber,
                                                fontSize = 10.sp
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Row(
                                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            // Nút mở thẳng trang Cài đặt thông báo hệ thống (Đặc trị Android 17 & MagicOS 11)
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(7.dp))
                                                    .background(MagicSurfaceDark)
                                                    .border(1.dp, MagicBorder, RoundedCornerShape(7.dp))
                                                    .clickable { onOpenAppNotificationSettings(appDiag.packageName) }
                                                    .padding(horizontal = 7.dp, vertical = 5.dp)
                                            ) {
                                                Text(
                                                    text = "⚙ Cài Đặt",
                                                    color = MagicCyanLight,
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }


                                        }
                                    }
                                }
                            }
                        }
                    }

                    2 -> {
                        val sortedPermApps = remember(diagnosticScan.missingPermissionApps) {
                            diagnosticScan.missingPermissionApps.sortedWith(
                                compareBy<com.example.data.AppNotificationDiagnostic> { !it.hasAnyPermissionIssue }
                                    .thenBy { !it.hasAnyNotificationIssue }
                                    .thenBy { it.appName.lowercase() }
                            )
                        }
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            sortedPermApps.take(20).forEach { appDiag ->
                                val ok = !appDiag.hasAnyPermissionIssue
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(MagicSurfaceCard)
                                        .border(
                                            1.dp,
                                            if (ok) MagicEmerald.copy(alpha = 0.35f) else MagicRose.copy(alpha = 0.45f),
                                            RoundedCornerShape(10.dp)
                                        )
                                        .padding(10.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(
                                            modifier = Modifier.weight(1f),
                                            verticalArrangement = Arrangement.spacedBy(2.dp)
                                        ) {
                                            Text(
                                                text = appDiag.appName,
                                                color = Color.White,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                text = if (ok) {
                                                    "✅ Đủ quyền Chạy ngầm 24/24, Pin & Cửa sổ nổi"
                                                } else {
                                                    "⚠️ Thiếu quyền Chạy ngầm / Tối ưu Pin / Hiển thị nổi"
                                                },
                                                color = if (ok) MagicEmeraldLight else MagicRoseLight,
                                                fontSize = 10.sp
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Row(
                                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            // Nút mở thẳng trang Quản lý ứng dụng & Quyền hệ thống của Honor
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(7.dp))
                                                    .background(MagicSurfaceDark)
                                                    .border(1.dp, MagicBorder, RoundedCornerShape(7.dp))
                                                    .clickable { onOpenAppDetailsSettings(appDiag.packageName) }
                                                    .padding(horizontal = 7.dp, vertical = 5.dp)
                                            ) {
                                                Text(
                                                    text = "⚙ Quyền",
                                                    color = MagicEmeraldLight,
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }

                                            // Nút Cấp Quyền Tự Động ADB / Shizuku
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(7.dp))
                                                    .background(if (ok) MagicEmerald.copy(alpha = 0.2f) else MagicEmerald)
                                                    .clickable { onFixSingleApp(appDiag.packageName, appDiag.appName) }
                                                    .padding(horizontal = 9.dp, vertical = 5.dp)
                                            ) {
                                                Text(
                                                    text = if (ok) "✓ Đủ quyền" else "Tự Cấp",
                                                    color = if (ok) MagicEmerald else Color(0xFF020617),
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Black
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Ô #18: Live Push Tester Section
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = androidx.compose.foundation.BorderStroke(1.dp, MagicEmerald.copy(alpha = 0.4f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(5.dp))
                                .background(MagicEmerald)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "Ô #18",
                                color = Color(0xFF020617),
                                fontSize = 9.5.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                        Text(
                            text = "🔔 BẮN THỬ THÔNG BÁO TEST CHUÔNG & BIỂU NGỮ NỔI",
                            color = MagicEmerald,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Black,
                            softWrap = true
                        )
                    }
                    Text(
                        text = "Thử ngay",
                        color = TextMuted,
                        fontSize = 10.sp
                    )
                }

                Text(
                    text = "Bấm để kiểm chứng xem điện thoại có nổ chuông và hiện biểu ngữ nổi ngay lập tức hay không:",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    softWrap = true
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(
                        "Facebook" to "com.facebook.katana",
                        "Zalo" to "com.zing.zalo",
                        "Messenger" to "com.facebook.orca"
                    ).forEach { (name, pkg) ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(MagicSurfaceCard)
                                .border(1.dp, MagicBorder, RoundedCornerShape(10.dp))
                                .clickable { onTestNotification(pkg, name) }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Test $name",
                                color = MagicEmerald,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                softWrap = true
                            )
                        }
                    }
                }
            }
        }

        // Ô #19 & Ô #20: Specific Fix Actions Grid
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(5.dp))
                    .background(MagicCyan)
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = "Ô #19 – #20",
                    color = Color(0xFF020617),
                    fontSize = 9.5.sp,
                    fontWeight = FontWeight.Black
                )
            }
            Text(
                text = "CÔNG CỤ ĐẶC TRỊ RIÊNG TỪNG LỖI & GHIM THÔNG BÁO",
                color = TextPrimary,
                fontSize = 12.5.sp,
                fontWeight = FontWeight.Black
            )
        }

        // Facebook Repair
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = androidx.compose.foundation.BorderStroke(1.dp, MagicBorder)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = "Đặc trị riêng Facebook (Kẹt FCM Token)",
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    softWrap = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = "Nếu Zalo/Telegram nổ ngon lành nhưng riêng Facebook im lìm: Xóa kẹt Token FCM, đánh thức Receiver ngầm và bật biểu ngữ nổi.",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    lineHeight = 16.sp,
                    softWrap = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Button(
                        onClick = onFixFacebook,
                        enabled = true,
                        modifier = Modifier.height(38.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MagicCyan,
                            contentColor = Color(0xFF020617)
                        )
                    ) {
                        Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "Kích Hoạt FCM Facebook", fontSize = 11.sp, fontWeight = FontWeight.Black)
                    }
                }
            }
        }

        // Tự Động Đánh Thức Ứng Dụng (Chống Ngủ Đông & Nín Họng Notif)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = androidx.compose.foundation.BorderStroke(
                1.dp,
                if (isAutoWakeupEnabled) MagicEmerald else MagicBorder
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "⚡ Tự Động Đánh Thức App (Chống Nín Họng)",
                                color = Color.White,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = if (isAutoWakeupEnabled) "ĐANG BẢO VỆ: Tuần tra đánh thức ngầm mỗi 3 phút" else "ĐÃ TẮT: App có thể bị MagicOS dìm ngủ đông",
                            color = if (isAutoWakeupEnabled) MagicEmerald else TextMuted,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }

                }

                Text(
                    text = "Cứ mỗi 3 phút, MagicTune sẽ gửi một xung nhịp nhẹ (Silent Pulse) ghim Standby Bucket của Gmail, Google FCM, Facebook, Messenger & Zalo luôn ở mức ACTIVE. Giúp các app không bao giờ bị rơi vào giấc ngủ đông sâu của Honor nội địa, đảm bảo chuông tin nhắn luôn nổ tức thì 0s trễ!",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    lineHeight = 16.sp
                )
            }
        }

        // Pinned Search Bar on Notification Drawer & Lockscreen
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = androidx.compose.foundation.BorderStroke(
                1.dp,
                if (isSearchNotificationEnabled) MagicCyan else MagicBorder
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "🔍 Ghim Tìm Kiếm & 🎙️ Gọi Gemini Màn Hình Khóa",
                                color = Color.White,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = if (isSearchNotificationEnabled) "ĐANG GHIM: Hiện trên cùng thanh thông báo & màn hình khóa (Hỗ trợ Mở khóa Khuôn mặt -> Bật Gemini Voice)" else "ĐÃ TẮT: Không hiện thanh tìm kiếm & nút Gemini màn hình khóa",
                            color = if (isSearchNotificationEnabled) MagicCyanLight else TextMuted,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    androidx.compose.material3.Switch(
                        checked = isSearchNotificationEnabled,
                        onCheckedChange = { onToggleSearchNotification(it) },
                        colors = androidx.compose.material3.SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = MagicCyan,
                            uncheckedThumbColor = TextMuted,
                            uncheckedTrackColor = MagicSurfaceCard
                        )
                    )
                }

                Text(
                    text = "Ghim thanh tìm kiếm ứng dụng kèm nút 🎙️ Gemini cố định trên Màn hình khóa & Trung tâm thông báo. Cực kỳ hữu ích cho máy Honor nội địa không gọi được 'OK Google': Khi màn hình đang khóa, bạn chỉ cần chạm nút 🎙️ Gemini trên thông báo -> Máy sẽ tự động Mở khóa bằng khuôn mặt (Face Unlock) và bật ngay Gemini Voice lên để bạn trò chuyện!",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    lineHeight = 16.sp
                )

                val localCtx = androidx.compose.ui.platform.LocalContext.current
                Button(
                    onClick = {
                        if (!isSearchNotificationEnabled) {
                            onToggleSearchNotification(true)
                        }
                        try {
                            val intent = android.content.Intent(
                                localCtx,
                                com.example.core.widget.GeminiVoiceLockscreenActivity::class.java
                            ).apply {
                                addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP)
                            }
                            localCtx.startActivity(intent)
                        } catch (_: Exception) {}
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(38.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MagicPurple.copy(alpha = 0.25f)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MagicPurpleLight),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "🎙️ Thử Gọi Gemini Voice (Ghim Lên Màn Hình Khóa)",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Tùy chọn Thông Báo Giám Sát Sạc Pin
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = androidx.compose.foundation.BorderStroke(
                1.dp,
                if (isChargingNotificationEnabled) MagicCyan else MagicBorder
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "🔋 Thông Báo Giám Sát Sạc Pin",
                                color = Color.White,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = if (isChargingNotificationEnabled) "ĐANG BẬT: Giám sát công suất sạc trên thanh trạng thái (Không che màn hình)" else "ĐÃ TẮT: Không hiện thông báo sạc pin",
                            color = if (isChargingNotificationEnabled) MagicCyanLight else TextMuted,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    androidx.compose.material3.Switch(
                        checked = isChargingNotificationEnabled,
                        onCheckedChange = { onToggleChargingNotification(it) },
                        colors = androidx.compose.material3.SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = MagicCyan,
                            uncheckedThumbColor = TextMuted,
                            uncheckedTrackColor = MagicSurfaceCard
                        )
                    )
                }

                Text(
                    text = "Khi cắm sạc, ứng dụng hiển thị công suất W và thời gian sạc đầy trên màn hình khóa / thanh thông báo kéo xuống. Đã được cấu hình im lặng (Silent & Low Priority) — hoàn toàn không bung biểu ngữ pop-up che khuất màn hình khi bạn đang chơi game hay lướt web.",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    lineHeight = 16.sp
                )
            }
        }

        // Anti-Batching 0s for Gmail & Facebook
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = androidx.compose.foundation.BorderStroke(1.dp, MagicBorder)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = "Phá gom cụm 0s (Gmail & Facebook)",
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    softWrap = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = "Khắc phục triệt để cơ chế TARE & JobScheduler gom cụm 15-30 phút mới nhả thông báo 1 lần trên ROM Honor.",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    lineHeight = 16.sp,
                    softWrap = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Button(
                        onClick = onBoostBatching,
                        enabled = true,
                        modifier = Modifier.height(38.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MagicAmber,
                            contentColor = Color(0xFF020617)
                        )
                    ) {
                        Icon(imageVector = Icons.Default.Speed, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "Phá Bỏ Gom Cụm 0s", fontSize = 11.sp, fontWeight = FontWeight.Black)
                    }
                }
            }
        }

        // Prioritize Custom App Sounds & Anti-Mute
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = androidx.compose.foundation.BorderStroke(1.dp, MagicBorder)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = "Ưu tiên chuông riêng & Chống câm chuông",
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    softWrap = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = "Chống lại việc MagicOS tự động hạ âm lượng về 0 hoặc gộp tất cả thông báo về 1 tiếng chuông câm chung.",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    lineHeight = 16.sp,
                    softWrap = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Button(
                        onClick = onPrioritizeCustomSounds,
                        enabled = true,
                        modifier = Modifier.height(38.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MagicEmerald,
                            contentColor = Color(0xFF020617)
                        )
                    ) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.VolumeUp, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "Ưu Tiên Chuông Riêng", fontSize = 11.sp, fontWeight = FontWeight.Black)
                    }
                }
            }
        }

        // Tắt diệt ngầm PowerGenius
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = androidx.compose.foundation.BorderStroke(1.dp, MagicBorder)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = "Tắt diệt ngầm PowerGenius & iAware",
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    softWrap = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = "Vô hiệu hóa 2 trình AI sát thủ diệt ứng dụng ngầm của Honor, chặn SystemManager theo dõi kill app sau 3 phút tắt màn hình.",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    lineHeight = 16.sp,
                    softWrap = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Button(
                        onClick = onRemovePowerGenius,
                        enabled = true,
                        modifier = Modifier.height(38.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MagicRose,
                            contentColor = Color.White
                        )
                    ) {
                        Icon(imageVector = Icons.Default.PowerOff, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "Vô Hiệu Hóa PowerGenius", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Dòng ghi chú nhỏ tối ưu cho Honor + Nút điều hướng tới trang chức năng ngầm đa hãng
        HonorOptimizationDisclaimerFooter(
            onNavigateToUniversalFix = onNavigateToUniversalFix
        )
    }
}





