package com.example.ui.components

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.filled.Login
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.credentials.CredentialManager
import com.example.core.auth.FirebaseAuthManager
import com.example.core.license.LicenseManager
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import coil.compose.AsyncImage

@Composable
fun AccountSettingsScreen(
    onNavigateBack: () -> Unit,
    onNavigateToLogin: () -> Unit,
    onNavigateToChatSupport: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val credentialManager = remember { CredentialManager.create(context) }
    val scrollState = rememberScrollState()

    var currentUser by remember { mutableStateOf(FirebaseAuthManager.getCurrentUser()) }
    var isPro by remember { mutableStateOf(LicenseManager.isProActivated(context)) }
    var isAccountPro by remember { mutableStateOf(LicenseManager.isAccountProActivated(context)) }
    var deviceId by remember { mutableStateOf(LicenseManager.getDeviceId(context)) }
    var inputKey by remember { mutableStateOf("") }
    var proPrice by remember { mutableStateOf(LicenseManager.getProPrice(context)) }
    var accountProPrice by remember { mutableStateOf(LicenseManager.getAccountProPrice(context)) }
    var upgradeAccountProPrice by remember { mutableStateOf(LicenseManager.getUpgradeToAccountProPrice(context)) }
    var selectedQrPackage by remember { mutableStateOf(if (LicenseManager.isDeviceProOnly(context)) 2 else 0) } // 0 = Pro Máy, 1 = Pro Tài Khoản, 2 = Nâng cấp từ Pro Máy lên Pro Tài Khoản
    var isCheckingCloud by remember { mutableStateOf(false) }
    var showQrDialog by remember { mutableStateOf(false) }

    var newDisplayName by remember { mutableStateOf(currentUser?.displayName ?: "") }
    var newEmail by remember { mutableStateOf(currentUser?.email ?: "") }
    var currentPasswordInput by remember { mutableStateOf("") }
    var newPasswordInput by remember { mutableStateOf("") }
    var isCurrentPasswordVisible by remember { mutableStateOf(false) }
    var isNewPasswordVisible by remember { mutableStateOf(false) }

    DisposableEffect(Unit) {
        val receiver = object : android.content.BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                val c = ctx ?: return
                currentUser = FirebaseAuthManager.getCurrentUser()
                isPro = LicenseManager.isProActivated(c)
                isAccountPro = LicenseManager.isAccountProActivated(c)
                proPrice = LicenseManager.getProPrice(c)
                accountProPrice = LicenseManager.getAccountProPrice(c)
                upgradeAccountProPrice = LicenseManager.getUpgradeToAccountProPrice(c)
                if (LicenseManager.isDeviceProOnly(c)) {
                    selectedQrPackage = 2
                }
            }
        }
        val filter = android.content.IntentFilter().apply {
            addAction(LicenseManager.ACTION_PRO_ACTIVATED)
            addAction(LicenseManager.ACTION_CONFIG_UPDATED)
            addAction(FirebaseAuthManager.ACTION_SINGLE_DEVICE_KICKED)
        }
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            context.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            context.registerReceiver(receiver, filter)
        }
        onDispose {
            try { context.unregisterReceiver(receiver) } catch (_: Exception) {}
        }
    }

    // Kiểm tra thiết bị quen thuộc trên cloud khi mở màn hình tài khoản
    LaunchedEffect(Unit) {
        try {
            LicenseManager.logCustomerPaymentIntent(context, "OPENED_ACCOUNT_SETTINGS", "User opened account & pro upgrade screen")
        } catch (_: Exception) {}
        coroutineScope.launch {
            isCheckingCloud = true
            val cloudPro = LicenseManager.checkDeviceRecognizedProInCloud(context)
            isPro = cloudPro
            isAccountPro = LicenseManager.isAccountProActivated(context)
            if (LicenseManager.isDeviceProOnly(context)) {
                selectedQrPackage = 2
            }
            isCheckingCloud = false
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MagicDarkBackground)
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(onClick = onNavigateBack) {
                    Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Quay lại", tint = Color.White)
                }
                Text(
                    text = "Cài Đặt Tài Khoản",
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black
                )
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(
                        when {
                            isAccountPro -> MagicAmber.copy(alpha = 0.25f)
                            isPro -> MagicEmerald.copy(alpha = 0.25f)
                            else -> MagicRose.copy(alpha = 0.2f)
                        }
                    )
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Text(
                    text = when {
                        isAccountPro -> "👑 PRO TÀI KHOẢN"
                        isPro -> "📱 PRO THIẾT BỊ"
                        else -> "🔓 BẢN MIỄN PHÍ"
                    },
                    color = when {
                        isAccountPro -> MagicAmber
                        isPro -> MagicEmerald
                        else -> MagicRoseLight
                    },
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Card Cảnh báo / Gửi yêu cầu khôi phục Pro nhanh nếu mất quyền sau khi cài lại máy
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceCard),
            border = BorderStroke(1.dp, MagicAmber.copy(alpha = 0.5f))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.Warning, contentDescription = null, tint = MagicAmber, modifier = Modifier.size(20.dp))
                    Text(
                        text = "🔄 Mất quyền Pro sau khi cài lại máy?",
                        color = MagicAmber,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black
                    )
                }
                Text(
                    text = "Nếu bạn từng mua Pro nhưng vô tình mất quyền khi cài lại máy hoặc đổi thiết bị, hãy bấm nút dưới đây để gửi cảnh báo nhanh kèm Device ID ($deviceId) cho Admin. Admin sẽ đối soát danh sách và 1 chạm cấp lại quyền Pro ngay cho bạn!",
                    color = Color(0xFF94A3B8),
                    fontSize = 11.5.sp,
                    lineHeight = 16.sp
                )
                Button(
                    onClick = {
                        LicenseManager.sendProRecoveryRequest(context, "Khôi phục Pro cho thiết bị $deviceId", { _, msg ->
                            Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                        })
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MagicAmber),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(imageVector = Icons.AutoMirrored.Filled.Send, contentDescription = null, tint = Color(0xFF020617), modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Gửi Yêu Cầu Khôi Phục Pro Tới Admin", color = Color(0xFF020617), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(2.dp))

                Button(
                    onClick = onNavigateToChatSupport,
                    colors = ButtonDefaults.buttonColors(containerColor = MagicCyan),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(imageVector = Icons.AutoMirrored.Filled.Chat, contentDescription = null, tint = Color(0xFF020617), modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("💬 Mở Hỗ Trợ Trực Tuyến (Chat Support & AI)", color = Color(0xFF020617), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Card Thông Tin Tài Khoản & Đăng Nhập (Kèm cơ chế 1 máy / 1 tài khoản)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceCard),
            border = BorderStroke(1.dp, if (isAccountPro) MagicAmber else MagicBorder)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "👤 THÔNG TIN TÀI KHOẢN & ĐỒNG BỘ ĐỔI MÁY (1 MÁY / TÀI KHOẢN)",
                    color = if (isAccountPro) MagicAmber else MagicCyan,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Black
                )

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF0F172A))
                        .border(1.dp, MagicBorder, RoundedCornerShape(10.dp))
                        .padding(10.dp)
                ) {
                    Text(
                        text = if (isAccountPro) {
                            "👑 Tài khoản của bạn đang có GÓI PRO TÀI KHOẢN: Bạn có thể đăng nhập tài khoản này trên thiết bị khác để sử dụng toàn bộ chức năng Pro.\n⚠️ Quy định bảo mật: Mỗi tài khoản chỉ đăng nhập được trên 1 máy tại 1 thời điểm (khi đăng nhập trên máy mới, máy cũ sẽ tự động đăng xuất)."
                        } else if (isPro) {
                            "📱 Bạn đang dùng GÓI PRO THIẾT BỊ (gắn cố định theo ID máy $deviceId).\n💡 Nếu muốn đăng nhập sang máy khác mà vẫn dùng được Pro (1 máy hoạt động/lần, đăng nhập máy mới tự xuất máy cũ), hãy nâng cấp từ Pro Máy lên Pro Tài Khoản (+$upgradeAccountProPrice) ở mục bên dưới!"
                        } else {
                            "🔓 Bạn đang dùng Bản Miễn Phí. Bạn có thể chọn nâng cấp Pro Thiết Bị ($proPrice - cố định 1 máy) hoặc Pro Tài Khoản ($accountProPrice - đăng nhập đổi máy tự do, 1 máy/lần)."
                        },
                        color = TextSecondary,
                        fontSize = 11.sp,
                        lineHeight = 15.5.sp
                    )
                }

                val user = currentUser
                if (user != null) {
                    Text(
                        text = "UID: ${user.uid} • Máy đang kích hoạt: $deviceId (${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL})",
                        color = MagicEmerald,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )

                    OutlinedTextField(
                        value = newDisplayName,
                        onValueChange = { newDisplayName = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Tên hiển thị") },
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp)
                    )

                    OutlinedTextField(
                        value = newEmail,
                        onValueChange = { newEmail = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Email tài khoản") },
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp)
                    )

                    if (newPasswordInput.isNotBlank() || (newEmail.isNotBlank() && newEmail != user.email)) {
                        OutlinedTextField(
                            value = currentPasswordInput,
                            onValueChange = { currentPasswordInput = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Mật khẩu hiện tại (Cần thiết khi đổi MK/Email)") },
                            singleLine = true,
                            visualTransformation = if (isCurrentPasswordVisible) androidx.compose.ui.text.input.VisualTransformation.None else androidx.compose.ui.text.input.PasswordVisualTransformation(),
                            trailingIcon = {
                                IconButton(onClick = { isCurrentPasswordVisible = !isCurrentPasswordVisible }) {
                                    Icon(
                                        imageVector = if (isCurrentPasswordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                        contentDescription = if (isCurrentPasswordVisible) "Ẩn mật khẩu" else "Hiện mật khẩu",
                                        tint = if (isCurrentPasswordVisible) MagicEmeraldLight else MagicCyanLight
                                    )
                                }
                            },
                            shape = RoundedCornerShape(8.dp)
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            TextButton(
                                onClick = {
                                    val emailToSend = user.email ?: newEmail.trim()
                                    if (emailToSend.isBlank()) {
                                        Toast.makeText(context, "Không tìm thấy địa chỉ email tài khoản!", Toast.LENGTH_SHORT).show()
                                        return@TextButton
                                    }
                                    coroutineScope.launch {
                                        try {
                                            FirebaseAuthManager.getAuth().sendPasswordResetEmail(emailToSend).await()
                                            Toast.makeText(context, "Đã gửi liên kết đặt lại mật khẩu tới email: $emailToSend. Vui lòng kiểm tra hộp thư (cả thư rác/spam)!", Toast.LENGTH_LONG).show()
                                        } catch (e: Exception) {
                                            Toast.makeText(context, "Không thể gửi email: " + FirebaseAuthManager.translateAuthError(e), Toast.LENGTH_LONG).show()
                                        }
                                    }
                                }
                            ) {
                                Text("Quên mật khẩu cũ? Gửi email khôi phục", color = MagicAmber, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }

                    OutlinedTextField(
                        value = newPasswordInput,
                        onValueChange = { newPasswordInput = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Mật khẩu mới (Tùy chọn - ít nhất 6 ký tự)") },
                        singleLine = true,
                        visualTransformation = if (isNewPasswordVisible) androidx.compose.ui.text.input.VisualTransformation.None else androidx.compose.ui.text.input.PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { isNewPasswordVisible = !isNewPasswordVisible }) {
                                Icon(
                                    imageVector = if (isNewPasswordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = if (isNewPasswordVisible) "Ẩn mật khẩu" else "Hiện mật khẩu",
                                    tint = if (isNewPasswordVisible) MagicEmeraldLight else MagicCyanLight
                                )
                            }
                        },
                        shape = RoundedCornerShape(8.dp)
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(top = 6.dp)) {
                        Button(
                            onClick = {
                                coroutineScope.launch {
                                    try {
                                        val u = FirebaseAuthManager.getCurrentUser()
                                        if (u != null) {
                                            // Nếu có đổi mật khẩu hoặc đổi email thì tự động tái xác thực bằng mật khẩu hiện tại trước
                                            val needReauth = newPasswordInput.isNotBlank() || (newEmail.isNotBlank() && newEmail != u.email)
                                            if (needReauth) {
                                                if (currentPasswordInput.isBlank()) {
                                                    Toast.makeText(context, "Vui lòng nhập Mật khẩu hiện tại để xác thực trước khi đổi mật khẩu mới!", Toast.LENGTH_LONG).show()
                                                    return@launch
                                                }
                                                val cred = com.google.firebase.auth.EmailAuthProvider.getCredential(u.email ?: "", currentPasswordInput.trim())
                                                u.reauthenticate(cred).await()
                                            }

                                            if (newDisplayName.isNotBlank() && newDisplayName != u.displayName) {
                                                val profileUpdates = com.google.firebase.auth.UserProfileChangeRequest.Builder()
                                                    .setDisplayName(newDisplayName.trim())
                                                    .build()
                                                u.updateProfile(profileUpdates).await()
                                            }
                                            if (newEmail.isNotBlank() && newEmail != u.email) {
                                                u.verifyBeforeUpdateEmail(newEmail.trim()).await()
                                                Toast.makeText(context, "Đã gửi email xác thực thay đổi tới $newEmail", Toast.LENGTH_LONG).show()
                                            }
                                            if (newPasswordInput.isNotBlank()) {
                                                if (newPasswordInput.length < 6) {
                                                    Toast.makeText(context, "Mật khẩu mới phải có ít nhất 6 ký tự!", Toast.LENGTH_LONG).show()
                                                    return@launch
                                                }
                                                u.updatePassword(newPasswordInput).await()
                                                Toast.makeText(context, "Đổi mật khẩu mới thành công!", Toast.LENGTH_SHORT).show()
                                                newPasswordInput = ""
                                                currentPasswordInput = ""
                                            }
                                            Toast.makeText(context, "Cập nhật thông tin thành công!", Toast.LENGTH_SHORT).show()
                                            currentUser = FirebaseAuthManager.getCurrentUser()
                                        }
                                    } catch (e: Exception) {
                                        Toast.makeText(context, "Lỗi cập nhật: " + FirebaseAuthManager.translateAuthError(e), Toast.LENGTH_LONG).show()
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MagicCyan)
                        ) {
                            Text("Lưu Thông Tin", color = Color(0xFF020617), fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                FirebaseAuthManager.signOut(context, credentialManager, coroutineScope) {
                                    currentUser = null
                                    isPro = LicenseManager.isProActivated(context)
                                    isAccountPro = LicenseManager.isAccountProActivated(context)
                                    Toast.makeText(context, "Đã đăng xuất! Bạn có thể đăng nhập tài khoản trên thiết bị mới.", Toast.LENGTH_LONG).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MagicRoseLight)
                        ) {
                            Text("Đăng Xuất", color = Color(0xFF020617), fontWeight = FontWeight.Bold)
                        }
                    }
                } else {
                    Text(text = "Bạn chưa đăng nhập tài khoản. Hãy đăng nhập để đồng bộ quyền Pro Tài Khoản hoặc chuyển sang thiết bị khác (1 máy hoạt động/lần).", color = TextSecondary, fontSize = 12.sp)
                    Button(
                        onClick = onNavigateToLogin,
                        colors = ButtonDefaults.buttonColors(containerColor = MagicCyan)
                    ) {
                        Text("Đi Đến Trang Đăng Nhập / Đăng Ký", color = Color(0xFF020617), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Card Nhận Diện Thiết Bị & Khôi Phục Pro Khi Cài Lại App
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceCard),
            border = BorderStroke(1.dp, if (isPro) MagicEmerald else MagicBorder)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "📱 ĐỊNH DANH THIẾT BỊ & CẤP BẬC BẢN QUYỀN",
                    color = if (isPro) MagicEmerald else MagicCyan,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Black
                )
                Text(
                    text = "Mã thiết bị (Device ID): $deviceId\nCấp bậc hiện tại: ${LicenseManager.getProTierLabel(context)}",
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    lineHeight = 17.sp
                )

                if (isPro) {
                    val deviceFixedKey = remember(deviceId, isAccountPro) {
                        if (isAccountPro) LicenseManager.generateAccountProLicenseKeyForDevice(deviceId)
                        else LicenseManager.generateLicenseKeyForDevice(deviceId)
                    }

                    // Hiển thị Key cố định của thiết bị kèm nút Sao Chép (CHỈ HIỂN THỊ KHI ĐÃ LÊN PRO)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF0F172A))
                            .border(1.dp, MagicCyan.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                            .padding(horizontal = 10.dp, vertical = 8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "🔑 KEY KÍCH HOẠT CỐ ĐỊNH CỦA THIẾT BỊ NÀY:",
                                    color = MagicCyanLight,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = deviceFixedKey,
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                            Button(
                                onClick = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clipboard.setPrimaryClip(ClipData.newPlainText("ProKey", deviceFixedKey))
                                    Toast.makeText(context, "📋 Đã sao chép Key: $deviceFixedKey", Toast.LENGTH_SHORT).show()
                                },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                shape = RoundedCornerShape(6.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MagicCyan)
                            ) {
                                Icon(imageVector = Icons.Default.ContentCopy, contentDescription = null, tint = Color(0xFF020617), modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Sao Chép", color = Color(0xFF020617), fontSize = 10.5.sp, fontWeight = FontWeight.Black)
                            }
                        }
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF0F172A))
                            .border(1.dp, MagicBorder, RoundedCornerShape(10.dp))
                            .padding(horizontal = 10.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = "🔒 Mã Key kích hoạt cố định của thiết bị sẽ được cấp và hiển thị tại đây ngay sau khi thiết bị hoàn tất thanh toán nâng cấp Pro.",
                            color = TextSecondary,
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )
                    }
                }

                // Hộp lưu ý bảo lưu Pro vĩnh viễn & Khôi phục 100% khi đăng nhập
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(MagicAmber.copy(alpha = 0.12f))
                        .border(1.dp, MagicAmber.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                        .padding(10.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Bookmark, contentDescription = null, tint = MagicAmber, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "LƯU Ý LƯU GIỮ KEY & ĐĂNG NHẬP ĐỂ KHÔI PHỤC 100% PRO:",
                                color = MagicAmber,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                        Text(
                            text = "• Mỗi thiết bị được hệ thống cấp cố định MỘT KEY DUY NHẤT. Bạn hãy sao chép lưu giữ Key này để dùng về sau nếu lỡ cài lại máy hoặc vô tình mất bản Pro.\n• HOẶC ĐĂNG NHẬP TÀI KHOẢN: Khi bạn đăng nhập, thiết bị Pro sẽ được tự động ghi nhớ vĩnh viễn vào tài khoản của bạn trên đám mây. Về sau nếu lỡ lỗi không thấy Pro, CHỈ CẦN ĐĂNG NHẬP TÀI KHOẢN LÀ THIẾT BỊ 100% ĐƯỢC TỰ ĐỘNG KHÔI PHỤC BẢN PRO!",
                            color = Color(0xFFE2E8F0),
                            fontSize = 10.5.sp,
                            lineHeight = 15.sp
                        )
                    }
                }

                Text(
                    text = "• Với Pro Thiết Bị: Gắn cố định theo mã phần cứng của máy $deviceId (gỡ app cài lại trên cùng máy tự khôi phục).\n• Với Pro Tài Khoản: Cho phép đăng nhập tài khoản sang thiết bị khác vẫn dùng được Pro (mỗi tài khoản chỉ đăng nhập 1 máy cùng lúc, đăng nhập máy mới tự xuất máy cũ).",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                )

                if (isCheckingCloud) {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = MagicCyan)
                }
            }
        }

        // Card Mua / Nâng Cấp Bản Pro Thiết Bị & Pro Tài Khoản
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceCard),
            border = BorderStroke(1.dp, if (isAccountPro) MagicAmber else if (isPro) MagicEmerald else MagicPurpleLight)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = if (isPro && !isAccountPro) {
                        "🚀 NÂNG CẤP TỪ PRO THIẾT BỊ LÊN PRO TÀI KHOẢN"
                    } else {
                        "⚡ ĐĂNG KÝ / NÂNG CẤP BẢN QUYỀN PRO"
                    },
                    color = if (isPro && !isAccountPro) MagicAmber else MagicPurpleLight,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Black
                )

                // Bộ chọn gói nâng cấp
                if (isPro && !isAccountPro) {
                    // Đã có Pro Thiết Bị -> Hiển thị gói nâng cấp lên Pro Tài Khoản (trả thêm tiền chênh lệch)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(MagicAmber.copy(alpha = 0.14f))
                            .border(1.dp, MagicAmber.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                            .padding(12.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = "👑 GÓI NÂNG CẤP TỪ PRO MÁY LÊN PRO TÀI KHOẢN: +$upgradeAccountProPrice",
                                color = MagicAmber,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                text = "Máy của bạn đã có Pro Thiết Bị ($proPrice). Chỉ cần trả thêm phần chênh lệch +$upgradeAccountProPrice để nâng cấp lên Pro Tài Khoản (cho phép đăng nhập sang máy khác dùng Pro, tối đa 1 máy đăng nhập cùng lúc).",
                                color = TextSecondary,
                                fontSize = 11.sp,
                                lineHeight = 15.sp
                            )
                        }
                    }
                } else if (!isPro) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val isPkg0 = selectedQrPackage == 0
                        Surface(
                            onClick = { selectedQrPackage = 0 },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            color = if (isPkg0) MagicEmerald.copy(alpha = 0.16f) else Color(0xFF0F172A),
                            border = BorderStroke(if (isPkg0) 1.5.dp else 1.dp, if (isPkg0) MagicEmerald else MagicBorder)
                        ) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text("📱 PRO THIẾT BỊ", color = if (isPkg0) MagicEmerald else Color.White, fontSize = 11.5.sp, fontWeight = FontWeight.Black)
                                Text(proPrice, color = MagicCyanLight, fontSize = 13.5.sp, fontWeight = FontWeight.Black)
                                Text("Cố định theo ID máy $deviceId", color = TextSecondary, fontSize = 9.5.sp)
                            }
                        }

                        val isPkg1 = selectedQrPackage == 1
                        Surface(
                            onClick = { selectedQrPackage = 1 },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            color = if (isPkg1) MagicAmber.copy(alpha = 0.16f) else Color(0xFF0F172A),
                            border = BorderStroke(if (isPkg1) 1.5.dp else 1.dp, if (isPkg1) MagicAmber else MagicBorder)
                        ) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text("👑 PRO TÀI KHOẢN", color = if (isPkg1) MagicAmber else Color.White, fontSize = 11.5.sp, fontWeight = FontWeight.Black)
                                Text(accountProPrice, color = MagicAmber, fontSize = 13.5.sp, fontWeight = FontWeight.Black)
                                Text("Đổi máy tự do (1 máy hoạt động/lần)", color = TextSecondary, fontSize = 9.5.sp)
                            }
                        }
                    }
                }

                val requiresLoginForAccountProQr = ((isPro && !isAccountPro) || (!isPro && selectedQrPackage == 1)) && currentUser == null

                if (requiresLoginForAccountProQr) {
                    // BẮT BUỘC ĐĂNG NHẬP TRƯỚC KHI HIỆN MÃ QR CHO TRƯỜNG HỢP MÁY PRO MUỐN LÊN TÀI KHOẢN PRO (HOẶC MUA PRO TÀI KHOẢN)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(MagicRose.copy(alpha = 0.14f))
                            .border(1.2.dp, MagicRose.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
                            .padding(14.dp)
                    ) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = null,
                                    tint = MagicRoseLight,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = "🔒 CẦN ĐĂNG NHẬP ĐỂ HIỆN MÃ QR LÊN TÀI KHOẢN PRO",
                                    color = MagicRoseLight,
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                            Text(
                                text = if (isPro && !isAccountPro) {
                                    "Máy của bạn đang là Pro Thiết Bị. Để nâng cấp lên Pro Tài Khoản (+$upgradeAccountProPrice), hệ thống chỉ hiển thị mã QR chuyển khoản sau khi bạn đã Đăng Nhập tài khoản — nhằm tránh trường hợp bạn chuyển khoản xong nhưng chưa có tài khoản thật để hệ thống cấp quyền Pro Tài Khoản!"
                                } else {
                                    "Gói Pro Tài Khoản ($accountProPrice) gắn liền với Email/Tài khoản của bạn để đăng nhập đổi máy tự do. Vui lòng Đăng Nhập tài khoản trước để mở mã QR chuyển khoản!"
                                },
                                color = Color(0xFFE2E8F0),
                                fontSize = 11.sp,
                                lineHeight = 15.5.sp,
                                textAlign = TextAlign.Center
                            )
                            Button(
                                onClick = {
                                    showQrDialog = false
                                    onNavigateToLogin()
                                },
                                modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 44.dp),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MagicAmber)
                            ) {
                                Icon(imageVector = Icons.AutoMirrored.Filled.Login, contentDescription = null, tint = Color(0xFF020617), modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "🔐 Đăng Nhập / Đăng Ký Ngay Để Hiện Mã QR",
                                    color = Color(0xFF020617),
                                    fontWeight = FontWeight.Black,
                                    fontSize = 11.5.sp,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                } else {
                    // VietQR Button (Chỉ hiện khi đã đăng nhập đối với nâng cấp Pro Tài Khoản, hoặc khi mua Pro Thiết Bị)
                    Button(
                        onClick = {
                            if (isPro && !isAccountPro) {
                                selectedQrPackage = 2
                            }
                            try {
                                LicenseManager.logCustomerPaymentIntent(
                                    context,
                                    "OPENED_VIET_QR",
                                    "Customer viewed VietQR code (Package=$selectedQrPackage)"
                                )
                            } catch (_: Exception) {}
                            showQrDialog = true
                        },
                        modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 48.dp),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isPro && !isAccountPro || selectedQrPackage == 1) MagicAmber else MagicEmerald
                        )
                    ) {
                        Icon(imageVector = Icons.Default.QrCode, contentDescription = null, tint = Color(0xFF020617))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = when {
                                isPro && !isAccountPro -> "Hiện Mã QR Nâng Cấp Lên Pro Tài Khoản (+$upgradeAccountProPrice)"
                                selectedQrPackage == 1 -> "Hiện Mã QR Mua Pro Tài Khoản ($accountProPrice)"
                                else -> "Hiện Mã QR Mua Pro Thiết Bị ($proPrice)"
                            },
                            color = Color(0xFF020617),
                            fontWeight = FontWeight.Black,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center
                        )
                    }

                    // Nút báo đã chuyển khoản để Admin duyệt ngay
                    Button(
                        onClick = {
                            coroutineScope.launch {
                                val detailMsg = when {
                                    isPro && !isAccountPro -> "Khách báo đã chuyển thêm $upgradeAccountProPrice để nâng cấp từ Pro Máy lên Pro Tài Khoản"
                                    selectedQrPackage == 1 -> "Khách báo đã chuyển $accountProPrice mua Pro Tài Khoản"
                                    else -> "Khách báo đã chuyển $proPrice mua Pro Thiết Bị"
                                }
                                LicenseManager.logCustomerPaymentIntent(context, "CLICKED_I_PAID", detailMsg)
                                Toast.makeText(context, "✅ Đã báo cáo chuyển khoản tới Admin! Admin sẽ kiểm tra và cấp quyền ngay lập tức.", Toast.LENGTH_LONG).show()
                            }
                        },
                        modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 44.dp),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF59E0B))
                    ) {
                        Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF020617), modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("⚡ Tôi Đã Chuyển Khoản (Báo Admin Duyệt Ngay)", color = Color(0xFF020617), fontWeight = FontWeight.Black, fontSize = 11.5.sp, textAlign = TextAlign.Center)
                    }
                }

                // Nhập key kích hoạt
                OutlinedTextField(
                    value = inputKey,
                    onValueChange = { inputKey = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Nhập Key Pro Máy (XXXX-...) hoặc Key Pro Tài Khoản (TKPR-...)") },
                    singleLine = true,
                    shape = RoundedCornerShape(8.dp)
                )

                Button(
                    onClick = {
                        val trimmedKey = inputKey.trim().uppercase()
                        if (trimmedKey.startsWith("TKPR") && currentUser == null) {
                            Toast.makeText(
                                context,
                                "🔒 Key Pro Tài Khoản (TKPR-...) yêu cầu bạn Đăng Nhập tài khoản trước để gắn quyền Pro vào tài khoản thật!",
                                Toast.LENGTH_LONG
                            ).show()
                            onNavigateToLogin()
                            return@Button
                        }
                        if (LicenseManager.verifyLicenseKey(context, inputKey)) {
                            isPro = LicenseManager.isProActivated(context)
                            isAccountPro = LicenseManager.isAccountProActivated(context)
                            val msg = if (isAccountPro) {
                                "👑 Đã kích hoạt PRO TÀI KHOẢN thành công! Bạn có thể đăng nhập sử dụng trên thiết bị khác (1 máy/lần)."
                            } else {
                                "🎉 Đã kích hoạt PRO THIẾT BỊ thành công!"
                            }
                            Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                        } else {
                            Toast.makeText(context, "❌ Mã kích hoạt không chính xác cho thiết bị $deviceId!", Toast.LENGTH_SHORT).show()
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(42.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MagicCyan)
                ) {
                    Text("Xác Nhận Kích Hoạt Key", color = Color(0xFF020617), fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    val isAccountQrBlocked = ((isPro && !isAccountPro) || selectedQrPackage == 1 || selectedQrPackage == 2) && currentUser == null
    if (showQrDialog && !isAccountQrBlocked) {
        val bankName = LicenseManager.getPaymentBankName(context)
        val bankCode = LicenseManager.getPaymentBankCode(context)
        val accountNumber = LicenseManager.getPaymentAccountNumber(context)
        val accountHolder = LicenseManager.getPaymentAccountHolder(context)
        val activePriceStr = when (selectedQrPackage) {
            2 -> upgradeAccountProPrice
            1 -> accountProPrice
            else -> proPrice
        }
        val activeTransferContent = when (selectedQrPackage) {
            2 -> "UPPRO $deviceId"
            1 -> "TKPRO $deviceId"
            else -> deviceId
        }
        val activeTitle = when (selectedQrPackage) {
            2 -> "VietQR Nâng Cấp Lên Pro Tài Khoản"
            1 -> "VietQR Đăng Ký Pro Tài Khoản"
            else -> "VietQR Đăng Ký Pro Thiết Bị"
        }
        val numericAmount = activePriceStr.replace(Regex("[^0-9]"), "").ifBlank { "50000" }
        val encodedHolder = try {
            java.net.URLEncoder.encode(accountHolder, "UTF-8")
        } catch (_: Exception) {
            accountHolder
        }
        val encodedAddInfo = try {
            java.net.URLEncoder.encode(activeTransferContent, "UTF-8")
        } catch (_: Exception) {
            activeTransferContent
        }
        val qrUrl = "https://img.vietqr.io/image/$bankCode-$accountNumber-compact2.png?amount=$numericAmount&addInfo=$encodedAddInfo&accountName=$encodedHolder"
        AlertDialog(
            onDismissRequest = { showQrDialog = false },
            containerColor = MagicSurfaceDark,
            title = {
                Text(text = activeTitle, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(240.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.White)
                            .padding(8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        AsyncImage(
                            model = qrUrl,
                            contentDescription = "VietQR",
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    Text(
                        text = "Ngân hàng: $bankName\nChủ tài khoản: $accountHolder\nSTK: $accountNumber\nSố tiền: $activePriceStr\nNội dung CK: $activeTransferContent",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                        val clip = android.content.ClipData.newPlainText("Transfer Content", activeTransferContent)
                        clipboard.setPrimaryClip(clip)
                        Toast.makeText(context, "Đã sao chép nội dung: $activeTransferContent", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MagicCyan)
                ) {
                    Text("Sao chép nội dung", color = Color(0xFF020617), fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showQrDialog = false }) {
                    Text("Đóng", color = TextSecondary)
                }
            }
        )
    }
}
