package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.core.adb.AdbNsdScanner
import com.example.core.adb.AdbPairingNotificationManager
import com.example.ui.theme.MagicAmber
import com.example.ui.theme.MagicBorder
import com.example.ui.theme.MagicCyan
import com.example.ui.theme.MagicCyanLight
import com.example.ui.theme.MagicEmerald
import com.example.ui.theme.MagicSurfaceCard
import com.example.ui.theme.MagicSurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.launch

@Composable
fun WirelessAdbDialog(
    currentPort: Int,
    isConnected: Boolean,
    onDismiss: () -> Unit,
    onPair: (port: Int, code: String, onFinished: (Boolean, String) -> Unit) -> Unit = { _, _, _ -> },
    onConnect: (Int) -> Unit,
    onDisconnect: () -> Unit,
    onOpenDeveloperSettings: () -> Unit,
    onStartNotificationPairing: () -> Unit = {}
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val nsdScanner = remember { AdbNsdScanner.getInstance(context) }
    val nsdState by nsdScanner.state.collectAsState()

    var selectedTab by remember { mutableIntStateOf(if (isConnected) 1 else 0) }
    var pairPortText by remember { mutableStateOf("") }
    var pairCodeText by remember { mutableStateOf("") }
    var showManualPortInput by remember { mutableStateOf(false) }
    var connectPortText by remember {
        mutableStateOf(if (isConnected && currentPort > 1024) currentPort.toString() else "")
    }

    var isPairingInProgress by remember { mutableStateOf(false) }
    var pairStatusMessage by remember { mutableStateOf<String?>(null) }
    var pairIsSuccess by remember { mutableStateOf<Boolean?>(null) }

    val handlePairAction: (Int, String) -> Unit = { port, code ->
        if (!isPairingInProgress && port in 1..65535 && code.length == 6) {
            isPairingInProgress = true
            pairStatusMessage = "⏳ Đang ghép nối mã PIN $code tới cổng $port..."
            pairIsSuccess = null
            onPair(port, code) { success, message ->
                isPairingInProgress = false
                pairIsSuccess = success
                pairStatusMessage = if (success) "🟢 Ghép nối thành công! Đang tự động kết nối..." else "❌ $message"
                if (success) {
                    coroutineScope.launch {
                        kotlinx.coroutines.delay(650)
                        val bestPort = nsdScanner.getBestConnectPort()
                        if (bestPort != null && bestPort in 1..65535) {
                            connectPortText = bestPort.toString()
                        }
                        selectedTab = 1
                    }
                }
            }
        }
    }

    DisposableEffect(Unit) {
        nsdScanner.startDiscovery()
        onDispose {
            if (!AdbPairingNotificationManager.isNotificationPairingActive) {
                nsdScanner.stopDiscovery()
            }
        }
    }

    LaunchedEffect(nsdState.pairingPort) {
        val discoveredPairingPort = nsdState.pairingPort
        if (discoveredPairingPort != null && discoveredPairingPort in 1..65535) {
            pairPortText = discoveredPairingPort.toString()
        }
    }

    LaunchedEffect(nsdState.connectPort) {
        val discoveredConnectPort = nsdState.connectPort
        if (discoveredConnectPort != null && discoveredConnectPort in 1..65535) {
            connectPortText = discoveredConnectPort.toString()
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnBackPress = true,
            dismissOnClickOutside = true
        )
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.96f)
                .padding(vertical = 10.dp),
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, MagicCyan.copy(alpha = 0.6f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Đầu trang to rõ + Nút Đóng X lớn dễ bấm
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Wifi,
                            contentDescription = null,
                            tint = MagicCyan,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "KẾT NỐI BẰNG MÃ 6 SỐ",
                                color = Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black,
                                softWrap = true
                            )
                            Text(
                                text = "👍 Kết nối trực tiếp độc lập • Siêu mượt & ổn định 100%",
                                color = MagicCyanLight,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.SemiBold,
                                softWrap = true
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(MagicSurfaceCard)
                            .border(1.dp, MagicBorder, RoundedCornerShape(10.dp))
                            .clickable { onDismiss() }
                            .testTag("close_wireless_adb_dialog_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Đóng hộp thoại",
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }

                // Chuyển đổi 2 mục: 1. Nhập 6 Số PIN | 2. Kết nối lại
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MagicSurfaceCard)
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .defaultMinSize(minHeight = 44.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (selectedTab == 0) MagicCyan else Color.Transparent)
                            .clickable { selectedTab = 0 }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "1. Nhập Mã 6 Số",
                            color = if (selectedTab == 0) Color(0xFF020617) else TextSecondary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black
                        )
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .defaultMinSize(minHeight = 44.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (selectedTab == 1) MagicCyan else Color.Transparent)
                            .clickable { selectedTab = 1 }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "2. Kết Nối Nhanh",
                            color = if (selectedTab == 1) Color(0xFF020617) else TextSecondary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }

                if (selectedTab == 0) {
                    val detectedPort = nsdState.pairingPort ?: pairPortText.toIntOrNull()

                    // Trạng thái tự động tìm cổng
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (detectedPort != null) MagicEmerald.copy(alpha = 0.15f)
                                else Color(0xFF0F172A)
                            )
                            .border(
                                1.dp,
                                if (detectedPort != null) MagicEmerald else MagicCyan.copy(alpha = 0.45f),
                                RoundedCornerShape(12.dp)
                            )
                            .padding(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(if (detectedPort != null) MagicEmerald else MagicAmber)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = if (detectedPort != null) {
                                            "🟢 ĐÃ TỰ ĐỘNG TÌM THẤY CỔNG ($detectedPort)"
                                        } else {
                                            "⏳ Đang chờ bạn mở bảng Mã ghép đôi..."
                                        },
                                        color = if (detectedPort != null) MagicEmerald else MagicCyanLight,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Black,
                                        softWrap = true
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = if (detectedPort != null) {
                                            "Chỉ cần nhập 6 chữ số bên dưới là kết nối ngay!"
                                        } else {
                                            "Hãy bấm nút màu xanh lớn bên dưới để mở cài đặt lấy 6 số."
                                        },
                                        color = TextSecondary,
                                        fontSize = 12.sp,
                                        lineHeight = 16.sp,
                                        softWrap = true
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MagicSurfaceCard)
                                    .clickable { nsdScanner.refreshDiscovery() },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "Tìm lại cổng",
                                    tint = MagicCyan,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }

                    // Nút BƯỚC 1: Bật thông báo nhập mã & Mở cài đặt
                    Button(
                        onClick = {
                            AdbPairingNotificationManager.startInteractiveNotificationPairing(context)
                            onStartNotificationPairing()
                            onOpenDeveloperSettings()
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .defaultMinSize(minHeight = 76.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MagicCyan,
                            contentColor = Color(0xFF020617)
                        )
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(
                                imageVector = Icons.Default.NotificationsActive,
                                contentDescription = null,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "BƯỚC 1: BẤM ĐỂ MỞ CÀI ĐẶT LẤY MÃ 6 SỐ",
                                    fontSize = 13.5.sp,
                                    fontWeight = FontWeight.Black,
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "Vào 'Gỡ lỗi qua Wi-Fi' ➔ 'Ghép nối bằng mã ghép đôi' ➔ Nhập 6 số trên thông báo",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF020617).copy(alpha = 0.85f),
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }

                    // Ô nhập mã 6 chữ số to rõ
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "BƯỚC 2: GÕ 6 CHỮ SỐ VÀO Ô DƯỚI ĐÂY:",
                            color = MagicEmerald,
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Black,
                            modifier = Modifier.weight(1f, fill = false),
                            softWrap = true
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(MagicCyan.copy(alpha = 0.15f))
                                .clickable { showManualPortInput = !showManualPortInput }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = if (showManualPortInput) "Ẩn cổng ▲" else "Cổng: ${pairPortText.ifBlank { "Tự động" }} ▼",
                                color = MagicCyanLight,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.Black)
                            .border(
                                2.dp,
                                if (pairCodeText.length == 6) MagicEmerald else MagicCyan.copy(alpha = 0.6f),
                                RoundedCornerShape(12.dp)
                            )
                            .padding(horizontal = 14.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        if (pairCodeText.isEmpty()) {
                            Text(
                                text = "Gõ 6 số vào đây (Ví dụ: 123456)",
                                color = TextMuted.copy(alpha = 0.7f),
                                fontSize = 15.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                        BasicTextField(
                            value = pairCodeText,
                            onValueChange = { newPin ->
                                if (!isPairingInProgress) {
                                    val filtered = newPin.filter { char -> char.isDigit() }.take(6)
                                    pairCodeText = filtered
                                    val autoPort = pairPortText.toIntOrNull() ?: nsdState.pairingPort ?: 0
                                    if (filtered.length == 6 && autoPort in 1..65535) {
                                        handlePairAction(autoPort, filtered)
                                    }
                                }
                            },
                            singleLine = true,
                            enabled = !isPairingInProgress,
                            cursorBrush = SolidColor(MagicEmerald),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            textStyle = TextStyle(
                                color = MagicEmerald,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 5.sp,
                                textAlign = TextAlign.Center
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    if (pairStatusMessage != null) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(
                                    when (pairIsSuccess) {
                                        true -> MagicEmerald.copy(alpha = 0.2f)
                                        false -> Color(0xFFEF4444).copy(alpha = 0.2f)
                                        else -> MagicCyan.copy(alpha = 0.15f)
                                    }
                                )
                                .border(
                                    1.dp,
                                    when (pairIsSuccess) {
                                        true -> MagicEmerald
                                        false -> Color(0xFFEF4444)
                                        else -> MagicCyan
                                    },
                                    RoundedCornerShape(10.dp)
                                )
                                .padding(10.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                if (isPairingInProgress) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(16.dp),
                                        color = MagicCyan,
                                        strokeWidth = 2.dp
                                    )
                                }
                                Text(
                                    text = pairStatusMessage ?: "",
                                    color = when (pairIsSuccess) {
                                        true -> MagicEmerald
                                        false -> Color(0xFFFF6B6B)
                                        else -> MagicCyanLight
                                    },
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    if (showManualPortInput) {
                        Text(
                            text = "CỔNG GHÉP NỐI (NẾU MUỐN NHẬP TAY 5 SỐ CUỐI):",
                            color = TextSecondary,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color.Black)
                                .border(
                                    1.dp,
                                    if (pairPortText.isNotBlank()) MagicCyan else MagicBorder,
                                    RoundedCornerShape(10.dp)
                                )
                                .padding(horizontal = 12.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            if (pairPortText.isEmpty()) {
                                Text(
                                    text = "Tự động điền hoặc gõ 5 số cổng (VD: 38475)",
                                    color = TextMuted.copy(alpha = 0.7f),
                                    fontSize = 13.sp
                                )
                            }
                            BasicTextField(
                                value = pairPortText,
                                onValueChange = { pairPortText = it.filter { char -> char.isDigit() }.take(5) },
                                singleLine = true,
                                enabled = !isPairingInProgress,
                                cursorBrush = SolidColor(MagicCyan),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                textStyle = TextStyle(color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }

                    val effectivePort = pairPortText.toIntOrNull() ?: nsdState.pairingPort ?: 0
                    Button(
                        onClick = {
                            if (effectivePort in 1..65535 && pairCodeText.length == 6) {
                                handlePairAction(effectivePort, pairCodeText)
                            } else if (effectivePort !in 1..65535) {
                                showManualPortInput = true
                            }
                        },
                        enabled = pairCodeText.length == 6 && !isPairingInProgress,
                        modifier = Modifier
                            .fillMaxWidth()
                            .defaultMinSize(minHeight = 68.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isPairingInProgress) MagicCyan.copy(alpha = 0.6f) else MagicEmerald,
                            contentColor = Color(0xFF020617)
                        )
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            if (isPairingInProgress) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(22.dp),
                                    color = Color(0xFF020617),
                                    strokeWidth = 2.5.dp
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = "ĐANG GHÉP NỐI XÁC THỰC...",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Black,
                                    textAlign = TextAlign.Center
                                )
                            } else {
                                Icon(imageVector = Icons.Default.Key, contentDescription = null, modifier = Modifier.size(22.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "BẤM KẾT NỐI NGAY",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Black,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                } else {
                    // TAB 1: KẾT NỐI LẠI NHANH
                    val detectedConnectPort = nsdState.connectPort ?: connectPortText.toIntOrNull()

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (detectedConnectPort != null) MagicEmerald.copy(alpha = 0.15f)
                                else Color(0xFF0F172A)
                            )
                            .border(
                                1.dp,
                                if (detectedConnectPort != null) MagicEmerald else MagicBorder,
                                RoundedCornerShape(12.dp)
                            )
                            .padding(12.dp)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = if (detectedConnectPort != null) {
                                    "🟢 ĐÃ TỰ ĐỘNG TÌM THẤY CỔNG KẾT NỐI ($detectedConnectPort)"
                                } else {
                                    "📡 Đang tự động tìm cổng kết nối Wi-Fi..."
                                },
                                color = if (detectedConnectPort != null) MagicEmerald else MagicCyanLight,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black,
                                softWrap = true
                            )
                            Text(
                                text = "Sau khi đã nhập 6 số lần đầu, những lần sau máy sẽ tự động nhận diện mà không cần nhập lại mã.",
                                color = TextSecondary,
                                fontSize = 12.sp,
                                lineHeight = 17.sp,
                                softWrap = true
                            )
                        }
                    }

                    Button(
                        onClick = onOpenDeveloperSettings,
                        modifier = Modifier
                            .fillMaxWidth()
                            .defaultMinSize(minHeight = 48.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF0F172A),
                            contentColor = MagicCyanLight
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MagicCyan.copy(alpha = 0.4f))
                    ) {
                        Icon(imageVector = Icons.Default.Settings, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = "Mở Cài Đặt Gỡ Lỗi Wi-Fi", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.Black)
                            .border(
                                1.dp,
                                if (connectPortText.isNotBlank()) MagicCyan else MagicBorder,
                                RoundedCornerShape(12.dp)
                            )
                            .padding(horizontal = 14.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        if (connectPortText.isEmpty()) {
                            Text(
                                text = "Cổng tự động điền khi bật Gỡ lỗi Wi-Fi",
                                color = TextMuted.copy(alpha = 0.7f),
                                fontSize = 13.5.sp
                            )
                        }
                        BasicTextField(
                            value = connectPortText,
                            onValueChange = { connectPortText = it.filter { char -> char.isDigit() }.take(5) },
                            singleLine = true,
                            cursorBrush = SolidColor(MagicCyan),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            textStyle = TextStyle(color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                val port = connectPortText.toIntOrNull() ?: nsdState.connectPort ?: 5555
                                onConnect(port)
                            },
                            enabled = connectPortText.isNotBlank() || nsdState.connectPort != null,
                            modifier = Modifier
                                .fillMaxWidth()
                                .defaultMinSize(minHeight = 72.dp),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MagicCyan,
                                contentColor = Color(0xFF020617)
                            )
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(imageVector = Icons.Default.Wifi, contentDescription = null, modifier = Modifier.size(22.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = "BẤM KẾT NỐI NGAY",
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Black,
                                        textAlign = TextAlign.Center
                                    )
                                    Text(
                                        text = "Cổng tự động: ${connectPortText.ifBlank { nsdState.connectPort?.toString() ?: "Tự động" }}",
                                        fontSize = 11.5.sp,
                                        color = Color(0xFF020617).copy(alpha = 0.85f),
                                        fontWeight = FontWeight.Bold,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }

                        if (isConnected) {
                            Button(
                                onClick = onDisconnect,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .defaultMinSize(minHeight = 48.dp),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFFEF4444),
                                    contentColor = Color.White
                                )
                            ) {
                                Text(text = "Ngắt Kết Nối", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}
