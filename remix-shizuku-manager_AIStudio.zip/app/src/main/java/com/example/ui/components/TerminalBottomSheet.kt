package com.example.ui.components

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.LogItem
import com.example.data.LogType
import com.example.ui.theme.*

@Composable
fun TerminalBottomSheet(
    logs: List<LogItem>,
    onDismiss: () -> Unit,
    onClearLogs: () -> Unit,
    onRunCommand: (String) -> Unit,
    onCancelOldCommands: () -> Unit = {}
) {
    var inputCmd by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf<LogType?>(null) }
    var searchLog by remember { mutableStateOf("") }
    val clipboardManager = LocalClipboardManager.current
    val context = LocalContext.current
    val listState = rememberLazyListState()

    val quickCommands = listOf(
        "⚡ Ẩn Dev Mode" to "settings put global development_settings_enabled 0; settings put global adb_enabled 0",
        "📂 Android/data" to "ls -1 /sdcard/Android/data",
        "📦 Android/obb" to "ls -1 /sdcard/Android/obb",
        "📦 Gói App 3rd" to "pm list packages -3",
        "🔋 Pin & Nhiệt" to "dumpsys battery",
        "🛡️ Whitelist Pin" to "dumpsys deviceidle whitelist",
        "📺 Màn hình" to "wm size && wm density",
        "🔮 Trạng Thái ADB" to "getprop service.adb.tcp.port; whoami",
        "🔔 Test TB" to "cmd notification post -S bigtext -t 'MagicTune' 'test_tag' 'ADB Shell v2.5 hoạt động hoàn hảo!'"
    )

    val filteredLogs = logs.filter { item ->
        val matchesType = selectedFilter == null || item.type == selectedFilter
        val matchesSearch = searchLog.isBlank() || item.message.contains(searchLog, ignoreCase = true)
        matchesType && matchesSearch
    }

    LaunchedEffect(logs.size) {
        if (filteredLogs.isNotEmpty()) {
            listState.animateScrollToItem(filteredLogs.size - 1)
        }
    }

    val okTotal = logs.count { it.type == LogType.SUCCESS }
    val errTotal = logs.count { it.type == LogType.ERROR }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnBackPress = true,
            dismissOnClickOutside = true
        )
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.84f)
                .padding(vertical = 8.dp),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF030712)),
            border = androidx.compose.foundation.BorderStroke(1.2.dp, MagicCyan.copy(alpha = 0.45f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight()
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Row 1: Ultra-Compact Header Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Terminal,
                            contentDescription = null,
                            tint = MagicCyan,
                            modifier = Modifier.size(14.dp)
                        )

                        Text(
                            text = "ADB v2.5",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Black,
                            maxLines = 1
                        )

                        // Status Pill (OK / Lỗi)
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(MagicSurfaceCard)
                                .padding(horizontal = 5.dp, vertical = 1.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(3.dp)
                        ) {
                            Text(
                                text = "✓$okTotal",
                                color = MagicEmeraldLight,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "✕$errTotal",
                                color = if (errTotal > 0) MagicRoseLight else TextMuted,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        // Quick Clear logs icon
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Clear",
                            tint = MagicAmber,
                            modifier = Modifier
                                .size(24.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .clickable { onClearLogs() }
                                .padding(4.dp)
                        )
                        
                        // Close icon
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = MagicRoseLight,
                            modifier = Modifier
                                .size(24.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .clickable { onDismiss() }
                                .padding(4.dp)
                        )
                    }
                }

                // Row 2: Merged Filter Pills + Copy Error Pill + Compact Search Box
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        listOf(
                            null to "Tất cả (${logs.size})",
                            LogType.COMMAND to "Lệnh",
                            LogType.SUCCESS to "OK ($okTotal)",
                            LogType.ERROR to "Lỗi ($errTotal)"
                        ).forEach { (type, label) ->
                            val isSelected = selectedFilter == type
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(
                                        if (isSelected) MagicBlue.copy(alpha = 0.35f)
                                        else if (type == LogType.ERROR && errTotal > 0) MagicRose.copy(alpha = 0.15f)
                                        else MagicSurfaceDark
                                    )
                                    .border(
                                        1.dp,
                                        if (isSelected) MagicBlue
                                        else if (type == LogType.ERROR && errTotal > 0) MagicRose.copy(alpha = 0.6f)
                                        else MagicBorder,
                                        RoundedCornerShape(6.dp)
                                    )
                                    .clickable { selectedFilter = type }
                                    .padding(horizontal = 7.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = label,
                                    color = when {
                                        isSelected -> MagicCyan
                                        type == LogType.ERROR && errTotal > 0 -> MagicRoseLight
                                        else -> TextMuted
                                    },
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1
                                )
                            }
                        }

                        if (errTotal > 0) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(MagicRose)
                                    .clickable {
                                        val errorLogs = logs.filter { it.type == LogType.ERROR }
                                        val errReport = buildString {
                                            appendLine("=== BÁO CÁO LỖI SHELL MAGICTUNE v2.5 ===")
                                            appendLine("Tổng số lệnh lỗi: ${errorLogs.size}")
                                            errorLogs.forEachIndexed { index, err ->
                                                appendLine("[LỖI #${index + 1}] [${err.timestamp}] ${err.message}")
                                            }
                                        }
                                        clipboardManager.setText(AnnotatedString(errReport))
                                        Toast.makeText(
                                            context,
                                            "📋 Đã copy $errTotal lỗi vào bộ nhớ tạm!",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    }
                                    .padding(horizontal = 7.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "📋 Copy Lỗi",
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Black,
                                    maxLines = 1
                                )
                            }
                        }
                    }

                    // Compact Search Input
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(26.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(MagicSurfaceDark)
                            .border(
                                1.dp,
                                if (searchLog.isNotBlank()) MagicCyan else MagicBorder,
                                RoundedCornerShape(6.dp)
                            )
                            .padding(horizontal = 6.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = null,
                                tint = TextMuted,
                                modifier = Modifier.size(12.dp)
                            )
                            Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                                if (searchLog.isEmpty()) {
                                    Text("Lọc chữ...", color = TextMuted, fontSize = 10.sp, maxLines = 1)
                                }
                                BasicTextField(
                                    value = searchLog,
                                    onValueChange = { searchLog = it },
                                    singleLine = true,
                                    cursorBrush = SolidColor(MagicCyan),
                                    textStyle = TextStyle(
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Medium
                                    ),
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                            if (searchLog.isNotEmpty()) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Xóa tìm kiếm",
                                    tint = TextMuted,
                                    modifier = Modifier
                                        .size(12.dp)
                                        .clickable { searchLog = "" }
                                )
                            }
                        }
                    }
                }

                // Row 3: Slim Quick Command Chips
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    items(quickCommands) { (label, cmd) ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MagicSurfaceCard)
                                .border(1.dp, MagicBorder, RoundedCornerShape(6.dp))
                                .clickable { onRunCommand(cmd) }
                                .padding(horizontal = 7.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = label,
                                color = MagicCyanLight,
                                fontSize = 9.5.sp,
                                fontFamily = FontFamily.Monospace,
                                maxLines = 1
                            )
                        }
                    }
                }

                // Terminal Log View (Maximized Vertical Area)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color.Black)
                        .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(10.dp))
                        .padding(8.dp)
                ) {
                    if (filteredLogs.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(100.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (selectedFilter == LogType.ERROR) "🎉 Hệ thống sạch: Không có lệnh nào bị lỗi."
                                else "Sẵn sàng thực thi lệnh ADB v2.5 (Ưu tiên lệnh mới nhất)...",
                                color = if (selectedFilter == LogType.ERROR) MagicEmeraldLight else TextMuted,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                softWrap = true
                            )
                        }
                    } else {
                        LazyColumn(
                            state = listState,
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            items(filteredLogs) { log ->
                                val color = when (log.type) {
                                    LogType.COMMAND -> MagicBlueLight
                                    LogType.SUCCESS -> MagicEmeraldLight
                                    LogType.ERROR -> MagicRoseLight
                                    else -> TextSecondary
                                }
                                Text(
                                    text = "[${log.timestamp}] ${log.message}",
                                    color = color,
                                    fontSize = 11.sp,
                                    lineHeight = 15.sp,
                                    fontFamily = FontFamily.Monospace,
                                    softWrap = true,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                }

                // Interactive Shell Input Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color.Black)
                            .border(
                                1.dp,
                                if (inputCmd.isNotBlank()) MagicCyan else MagicBorder,
                                RoundedCornerShape(10.dp)
                            )
                            .padding(horizontal = 12.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        if (inputCmd.isEmpty()) {
                            Text(
                                "Nhập lệnh shell (VD: pm list, dumpsys, settings...)",
                                color = TextMuted,
                                fontSize = 11.5.sp,
                                maxLines = 1
                            )
                        }
                        BasicTextField(
                            value = inputCmd,
                            onValueChange = { inputCmd = it },
                            singleLine = true,
                            cursorBrush = SolidColor(MagicCyan),
                            textStyle = TextStyle(
                                color = Color.White,
                                fontSize = 12.5.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(MagicCyan)
                            .clickable {
                                if (inputCmd.isNotBlank()) {
                                    onRunCommand(inputCmd)
                                    inputCmd = ""
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = "Chạy lệnh",
                            tint = Color(0xFF020617),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}
