package com.example.ui.components

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.LogItem
import com.example.data.LogType
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun ShellRunnerScreen(
    logs: List<LogItem>,
    isBusy: Boolean,
    onRunCommand: (String) -> Unit,
    onClearLogs: () -> Unit,
    onCancelOldCommands: () -> Unit
) {
    var inputCmd by remember { mutableStateOf("") }
    var showDangerousWarning by remember { mutableStateOf(false) }
    var commandToConfirm by remember { mutableStateOf("") }
    
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()

    val dangerousKeywords = listOf("rm ", "reboot", "factory-reset", "format", "dd ", "stop ", "kill ")

    val quickCommands = listOf(
        "🔮 Trạng Thái ADB" to "getprop service.adb.tcp.port; whoami",
        "🔋 Thông Tin Pin" to "dumpsys battery",
        "📦 Danh Sách Gói Ứng Dụng" to "pm list packages -3",
        "📱 Thông Số Màn Hình" to "wm size; wm density",
        "🌡️ Nhiệt Độ Thiết Bị" to "dumpsys thermalservice",
        "🚀 Ứng Dụng Đang Chạy" to "dumpsys activity top | grep PACKAGE",
        "🛡️ AppOps Settings" to "appops query-op --user 0 ACCESS_RESTRICTED_SETTINGS allow"
    )

    LaunchedEffect(logs.size) {
        if (logs.isNotEmpty()) {
            listState.animateScrollToItem(logs.size - 1)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Hero Card Header
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = androidx.compose.foundation.BorderStroke(1.dp, MagicCyan.copy(alpha = 0.5f))
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(MagicCyan.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Terminal, null, tint = MagicCyan, modifier = Modifier.size(24.dp))
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text("ADB Shell Runner Pro", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Black)
                    Text("UID 2000 / Quyền Hệ Thống Trực Tiếp (WLAN ADB)", color = MagicCyanLight, fontSize = 11.sp)
                }
                IconButton(onClick = onClearLogs) {
                    Icon(Icons.Default.DeleteSweep, null, tint = MagicRose)
                }
            }
        }

        // Quick Commands Row
        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(quickCommands) { (label, cmd) ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(MagicSurfaceCard)
                        .border(1.dp, MagicBorder, RoundedCornerShape(8.dp))
                        .clickable { inputCmd = cmd }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(label, color = MagicCyanLight, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Terminal Output Area
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .clip(RoundedCornerShape(12.dp))
                .background(Color.Black)
                .border(1.dp, MagicBorder, RoundedCornerShape(12.dp))
                .padding(8.dp)
        ) {
            if (logs.isEmpty()) {
                Column(
                    modifier = Modifier.align(Alignment.Center),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Default.Code, null, tint = TextMuted, modifier = Modifier.size(32.dp))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Cửa Sổ Lệnh Đã Sẵn Sàng", color = TextMuted, fontSize = 12.sp)
                    Text("Nhập câu lệnh bên dưới để bắt đầu...", color = TextMuted.copy(alpha = 0.7f), fontSize = 10.sp)
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(logs) { log ->
                        val color = when (log.type) {
                            LogType.COMMAND -> MagicBlueLight
                            LogType.SUCCESS -> MagicEmerald
                            LogType.ERROR -> MagicRose
                            else -> TextSecondary
                        }
                        
                        Row(modifier = Modifier.padding(vertical = 2.dp)) {
                            Text(
                                text = if (log.type == LogType.COMMAND) "$ " else "",
                                color = TextMuted,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = log.message,
                                color = color,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                lineHeight = 15.sp,
                                modifier = Modifier.clickable {
                                    clipboardManager.setText(AnnotatedString(log.message))
                                    Toast.makeText(context, "Copied to clipboard", Toast.LENGTH_SHORT).show()
                                }
                            )
                        }
                    }
                }
            }
        }

        // Input Area
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (isBusy) {
                LinearProgressIndicator(
                    modifier = Modifier.fillMaxWidth().height(2.dp).clip(RoundedCornerShape(1.dp)),
                    color = MagicCyan,
                    trackColor = MagicSurfaceCard
                )
            }
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(MagicSurfaceDark)
                        .border(1.dp, if (inputCmd.isNotEmpty()) MagicCyan else MagicBorder, RoundedCornerShape(12.dp))
                        .padding(horizontal = 12.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    if (inputCmd.isEmpty()) {
                        Text("Nhập lệnh hệ thống...", color = TextMuted, fontSize = 13.sp)
                    }
                    BasicTextField(
                        value = inputCmd,
                        onValueChange = { inputCmd = it },
                        singleLine = true,
                        cursorBrush = SolidColor(MagicCyan),
                        textStyle = TextStyle(
                            color = Color.White,
                            fontSize = 14.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("shell_input_field")
                    )
                }

                IconButton(
                    onClick = {
                        if (inputCmd.isNotBlank()) {
                            val lower = inputCmd.lowercase()
                            if (dangerousKeywords.any { lower.contains(it) }) {
                                commandToConfirm = inputCmd
                                showDangerousWarning = true
                            } else {
                                onRunCommand(inputCmd)
                                inputCmd = ""
                            }
                        }
                    },
                    modifier = Modifier
                        .size(50.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (inputCmd.isNotEmpty()) MagicCyan else MagicSurfaceCard)
                ) {
                    Icon(
                        Icons.AutoMirrored.Filled.Send,
                        null,
                        tint = if (inputCmd.isNotEmpty()) Color.Black else TextMuted
                    )
                }
            }
            
            if (isBusy) {
                Button(
                    onClick = onCancelOldCommands,
                    modifier = Modifier.fillMaxWidth().height(36.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MagicRose.copy(alpha = 0.2f), contentColor = MagicRose),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.Stop, null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("DỪNG TÁC VỤ HIỆN TẠI", fontSize = 11.sp, fontWeight = FontWeight.Black)
                }
            }
        }
    }

    if (showDangerousWarning) {
        AlertDialog(
            onDismissRequest = { showDangerousWarning = false },
            title = { Text("⚠️ Cảnh Báo Lệnh Hệ Thống Nguy Hiểm") },
            text = { Text("Bạn sắp thực thi một lệnh có thể ảnh hưởng đến an toàn hệ thống:\n\n\"$commandToConfirm\"\n\nBạn có chắc chắn muốn tiếp tục thực thi không?") },
            confirmButton = {
                Button(
                    onClick = {
                        onRunCommand(commandToConfirm)
                        inputCmd = ""
                        showDangerousWarning = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MagicRose)
                ) {
                    Text("VẪN THỰC THI")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDangerousWarning = false }) {
                    Text("HỦY BỎ")
                }
            },
            containerColor = MagicSurfaceDark,
            titleContentColor = MagicRose,
            textContentColor = TextPrimary
        )
    }
}
