package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.shell.ShellEngineState
import com.example.data.LogItem
import com.example.data.ShizukuInfo
import com.example.ui.theme.MagicAmber
import com.example.ui.theme.MagicBorder
import com.example.ui.theme.MagicCyan
import com.example.ui.theme.MagicCyanLight
import com.example.ui.theme.MagicEmerald
import com.example.ui.theme.MagicRose
import com.example.ui.theme.MagicSurfaceCard
import com.example.ui.theme.MagicSurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun ShizukuWlanScreen(
    shizukuInfo: ShizukuInfo,
    shellState: ShellEngineState,
    logs: List<LogItem>,
    isBusy: Boolean,
    onRequestShizukuPermission: () -> Unit,
    onOpenShizukuApp: () -> Unit,
    onOpenDeveloperSettings: () -> Unit,
    onOpenWlanDialog: () -> Unit,
    onProtectShizuku: () -> Unit,
    onAuthorizeCompanions: () -> Unit,
    onTestShizukuDiagnostic: () -> Unit = {},
    onStartNotificationPairing: () -> Unit = {},
    onStartShizukuDirectly: () -> Unit = {},
    onUnlockRestrictedSettings: () -> Unit = {},
    onConnectWlanPort: (Int) -> Unit = {},
    onRunShellCommand: (String) -> Unit = {},
    onForceResetShizuku: () -> Unit = {}
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val nsdScanner = remember { com.example.core.adb.AdbNsdScanner.getInstance(context) }
    val nsdState by nsdScanner.state.collectAsState()

    DisposableEffect(Unit) {
        nsdScanner.startDiscovery()
        onDispose {
            if (!com.example.core.adb.AdbPairingNotificationManager.isNotificationPairingActive) {
                nsdScanner.stopDiscovery()
            }
        }
    }

    val isShizukuLive = shizukuInfo.isRunning && shizukuInfo.isPermissionGranted
    val isDirectWlanLive = shellState.isWirelessAdbConnected
    val isLiveReady = isShizukuLive || isDirectWlanLive
    var showBackupMethods by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Thẻ Trạng Thái Lớn Rõ Ràng
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = androidx.compose.foundation.BorderStroke(
                1.5.dp,
                if (isLiveReady) Brush.linearGradient(listOf(MagicEmerald, MagicCyan))
                else Brush.linearGradient(listOf(MagicAmber, MagicCyan))
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                val pillBg = when {
                    isLiveReady -> MagicEmerald.copy(alpha = 0.2f)
                    shizukuInfo.isRunning -> MagicCyan.copy(alpha = 0.2f)
                    else -> MagicAmber.copy(alpha = 0.2f)
                }
                val pillColor = when {
                    isLiveReady -> MagicEmerald
                    shizukuInfo.isRunning -> MagicCyan
                    else -> MagicAmber
                }
                val pillText = when {
                    isLiveReady -> "🟢 ĐÃ KẾT NỐI THÀNH CÔNG • SẴN SÀNG SỬ DỤNG"
                    shizukuInfo.isRunning && !shizukuInfo.isPermissionGranted -> "🟡 CHỈ CẦN BẤM CHO PHÉP QUYỀN BÊN DƯỚI"
                    else -> "🔴 CHƯA KẾT NỐI • HÃY KẾT NỐI TRỰC TIẾP QUA GỠ LỖI WI-FI"
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(pillBg)
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = pillText,
                        color = pillColor,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Black
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(MagicCyan.copy(alpha = 0.22f))
                            .border(1.dp, MagicCyan.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 7.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "Ô #40",
                            color = MagicCyanLight,
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                    Text(
                        text = "🔌 Kết Nối Điện Thoại (Không Cần Máy Tính)",
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black
                    )
                }

                Text(
                    text = "Bạn chỉ cần chọn 1 trong 2 cách đơn giản dưới đây để mở khóa toàn bộ tính năng tự động sửa lỗi:",
                    color = TextSecondary,
                    fontSize = 13.5.sp,
                    lineHeight = 19.sp
                )

                // Cảnh báo Shizuku không ổn định đã được Admin loại bỏ
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MagicRose.copy(alpha = 0.15f)),
                    border = androidx.compose.foundation.BorderStroke(1.2.dp, MagicRose.copy(alpha = 0.7f))
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            tint = MagicRose,
                            modifier = Modifier.size(24.dp)
                        )
                        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(
                                text = "⚠️ CẢNH BÁO: KẾT NỐI QUA SHIZUKU ĐÃ BỊ ADMIN LOẠI BỎ",
                                color = MagicRose,
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                text = "Do Shizuku hoạt động rất chập chờn, thường xuyên bị hệ thống MagicOS tự ngắt và đóng băng tiến trình, Admin đã khóa và loại bỏ hoàn toàn phương thức này. Xin mời bạn sử dụng Kết Nối Trực Tiếp (WLAN ADB) bên dưới để đạt độ ổn định 100%!",
                                color = TextPrimary,
                                fontSize = 11.5.sp,
                                lineHeight = 16.sp
                            )
                        }
                    }
                }

                // Card Ghi Chú Khuyên Dùng Cách 1 (Kết nối trực tiếp)
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MagicCyan.copy(alpha = 0.12f)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MagicCyan.copy(alpha = 0.6f))
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ThumbUp,
                            contentDescription = null,
                            tint = MagicCyanLight,
                            modifier = Modifier.size(24.dp)
                        )
                        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(
                                text = "👍 HÃY SỬ DỤNG KẾT NỐI TRỰC TIẾP (MÃ 6 SỐ / WLAN ADB)",
                                color = MagicCyanLight,
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                text = "App hoàn toàn kết nối trực tiếp độc lập siêu mượt mà không cần qua bất kỳ ứng dụng trung gian nào. Kết nối trực tiếp qua Gỡ lỗi Wi-Fi chạy độc lập, siêu ổn định và không lo bị đóng băng tiến trình hay đứt liên kết ngầm.",
                                color = TextPrimary,
                                fontSize = 11.5.sp,
                                lineHeight = 16.sp
                            )
                        }
                    }
                }

                // CÁCH 1: KẾT NỐI TRỰC TIẾP BẰNG MÃ 6 SỐ
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFF0F172A))
                        .border(1.dp, MagicCyan.copy(alpha = 0.6f), RoundedCornerShape(14.dp))
                        .padding(12.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "👍 Ô #41 • CÁCH 1: NHẬP MÃ 6 SỐ TRỰC TIẾP (KHUYÊN DÙNG • TỐT NHẤT)",
                            color = MagicCyanLight,
                            fontSize = 13.5.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = "Kết nối trực tiếp độc lập siêu nhanh! Siêu ổn định, mượt mà và không lo bị hệ thống ngắt kết nối.",
                            color = TextSecondary,
                            fontSize = 12.5.sp,
                            lineHeight = 17.sp
                        )

                        if (nsdState.connectPort != null && !shellState.isWirelessAdbConnected) {
                            Button(
                                onClick = { onConnectWlanPort(nsdState.connectPort!!) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .defaultMinSize(minHeight = 56.dp),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MagicEmerald,
                                    contentColor = Color(0xFF020617)
                                )
                            ) {
                                Text(
                                    text = "⚡ BẤM KẾT NỐI NGAY (ĐÃ TỰ TÌM THẤY CỔNG ${nsdState.connectPort})",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Black,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }

                        Button(
                            onClick = onOpenWlanDialog,
                            modifier = Modifier
                                .fillMaxWidth()
                                .defaultMinSize(minHeight = 68.dp),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (shellState.isWirelessAdbConnected) MagicEmerald else MagicCyan,
                                contentColor = Color(0xFF020617)
                            )
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(imageVector = Icons.Default.Wifi, contentDescription = null, modifier = Modifier.size(24.dp))
                                Spacer(modifier = Modifier.width(10.dp))
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = if (shellState.isWirelessAdbConnected) {
                                            "✓ ĐÃ KẾT NỐI TRỰC TIẾP THÀNH CÔNG"
                                        } else {
                                            "🔑 MỞ BẢNG NHẬP MÃ 6 SỐ ĐỂ KẾT NỐI"
                                        },
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Black,
                                        textAlign = TextAlign.Center
                                    )
                                    Text(
                                        text = "Tự động tìm cổng • Kết nối trực tiếp độc lập • Siêu ổn định",
                                        fontSize = 11.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF020617).copy(alpha = 0.85f),
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // NÚT THÒ THỤT ĐÃ BỊ KHÓA ĐỂ NGĂN NGƯỜI DÙNG CHỌN KẾT NỐI SHIZUKU
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable {
                    android.widget.Toast.makeText(
                        context,
                        "Phương thức Shizuku không ổn định đã bị Admin khóa vĩnh viễn. Vui lòng dùng Kết Nối Trực Tiếp bằng mã 6 số!",
                        android.widget.Toast.LENGTH_LONG
                    ).show()
                },
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = androidx.compose.foundation.BorderStroke(1.dp, MagicRose.copy(alpha = 0.5f))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = null,
                        tint = MagicRose,
                        modifier = Modifier.size(20.dp)
                    )
                    Column {
                        Text(
                            text = "🔒 Phương Án Shizuku Đã Bị Khóa (Không Khả Dụng)",
                            color = MagicRose,
                            fontSize = 13.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Admin đã khóa tính năng này do thiếu ổn định • Hãy dùng Kết Nối Trực Tiếp ở trên!",
                            color = TextMuted,
                            fontSize = 11.5.sp
                        )
                    }
                }
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = null,
                    tint = MagicRose.copy(alpha = 0.6f)
                )
            }
        }

        AnimatedVisibility(visible = showBackupMethods) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                // CÁCH 2: PHƯƠNG ÁN KẾT NỐI PHỤ (Ô #42)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFF0F172A))
                        .border(1.dp, MagicEmerald.copy(alpha = 0.35f), RoundedCornerShape(14.dp))
                        .padding(12.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "🛡️ Ô #42 • CÁCH 2: PHƯƠNG ÁN KẾT NỐI PHỤ (DỰ PHÒNG)",
                            color = MagicAmber,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = "Lưu ý: Phương án phụ qua dịch vụ trung gian có thể bị MagicOS ngắt ngầm. Bạn nên ưu tiên dùng Cách 1 ở trên!",
                            color = TextSecondary,
                            fontSize = 11.5.sp,
                            lineHeight = 16.sp
                        )

                        ShizukuStatusCard(
                            shizukuInfo = shizukuInfo,
                            onRestart = onStartShizukuDirectly,
                            onRequestPermission = onRequestShizukuPermission,
                            onOpenApp = onOpenShizukuApp
                        )

                        Button(
                            onClick = onOpenDeveloperSettings,
                            modifier = Modifier
                                .fillMaxWidth()
                                .defaultMinSize(minHeight = 52.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MagicSurfaceCard,
                                contentColor = TextPrimary
                            ),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MagicBorder)
                        ) {
                            Icon(imageVector = Icons.Default.Settings, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Bước 1: Mở Cài Đặt Phát Triển (Bật Gỡ Lỗi Wi-Fi)",
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Button(
                            onClick = onOpenShizukuApp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .defaultMinSize(minHeight = 52.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MagicSurfaceCard,
                                contentColor = MagicEmerald
                            ),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MagicEmerald.copy(alpha = 0.5f))
                        ) {
                            Icon(imageVector = Icons.Default.Security, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Bước 2: Mở Quản Lý Dịch Vụ Phụ (Bấm Bắt Đầu)",
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Button(
                            onClick = onRequestShizukuPermission,
                            enabled = !isShizukuLive,
                            modifier = Modifier
                                .fillMaxWidth()
                                .defaultMinSize(minHeight = 56.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = when {
                                    isShizukuLive -> MagicEmerald
                                    shizukuInfo.isRunning -> MagicCyan
                                    else -> MagicSurfaceCard
                                },
                                contentColor = if (isShizukuLive || shizukuInfo.isRunning) Color(0xFF020617) else TextPrimary
                            ),
                            border = if (!isShizukuLive && !shizukuInfo.isRunning) {
                                androidx.compose.foundation.BorderStroke(1.dp, MagicBorder)
                            } else null
                        ) {
                            Icon(imageVector = Icons.Default.Security, contentDescription = null, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = when {
                                    isShizukuLive -> "✓ ĐÃ CẤP QUYỀN HỆ THỐNG THÀNH CÔNG"
                                    shizukuInfo.isRunning -> "Bước 3: BẤM CHO PHÉP QUYỀN TRỰC TIẾP NGAY"
                                    else -> "Bước 3: Cần bấm Bắt Đầu dịch vụ trước"
                                },
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                }

                // Ô #43: Công cụ bảo vệ & chẩn đoán kết nối nâng cao
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MagicCyan.copy(alpha = 0.22f))
                                .border(1.dp, MagicCyan.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                                .padding(horizontal = 7.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "Ô #43",
                                color = MagicCyanLight,
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                        Text(
                            text = "🛡️ Công Cụ Bảo Vệ & Sửa Lỗi Kết Nối Nâng Cao",
                            color = MagicCyanLight,
                            fontSize = 13.5.sp,
                            fontWeight = FontWeight.Black
                        )
                    }

                    if (!shizukuInfo.isRunning && shizukuInfo.isInstalled) {
                        Button(
                            onClick = onStartShizukuDirectly,
                            modifier = Modifier
                                .fillMaxWidth()
                                .defaultMinSize(minHeight = 64.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MagicEmerald.copy(alpha = 0.15f),
                                contentColor = MagicEmerald
                            ),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MagicEmerald)
                        ) {
                            Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "🚀 KÍCH HOẠT KẾT NỐI HỆ THỐNG TRỰC TIẾP",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onTestShizukuDiagnostic,
                            modifier = Modifier
                                .weight(1f)
                                .defaultMinSize(minHeight = 52.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MagicSurfaceCard,
                                contentColor = MagicCyan
                            ),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MagicCyan.copy(alpha = 0.5f))
                        ) {
                            Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "Kiểm Tra Kết Nối", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = onForceResetShizuku,
                            modifier = Modifier
                                .weight(1f)
                                .defaultMinSize(minHeight = 52.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF450a0a),
                                contentColor = MagicRose
                            ),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MagicRose.copy(alpha = 0.5f))
                        ) {
                            Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "Làm Mới Kết Nối", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(MagicSurfaceDark)
                                .border(1.dp, MagicBorder, RoundedCornerShape(12.dp))
                                .clickable { onProtectShizuku() }
                                .padding(12.dp)
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    text = "🛡️ Giữ Kết Nối Không Bị Tắt",
                                    color = MagicCyan,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Chống tự ngắt kết nối khi rút cáp hoặc tắt màn hình.",
                                    color = TextMuted,
                                    fontSize = 11.5.sp,
                                    lineHeight = 16.sp
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(MagicSurfaceDark)
                                .border(1.dp, MagicBorder, RoundedCornerShape(12.dp))
                                .clickable { onAuthorizeCompanions() }
                                .padding(12.dp)
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    text = "🔑 Cấp Quyền Ứng Dụng Khác",
                                    color = MagicEmerald,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Tự động cấp quyền cho các công cụ hỗ trợ trong máy.",
                                    color = TextMuted,
                                    fontSize = 11.5.sp,
                                    lineHeight = 16.sp
                                )
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(MagicSurfaceDark)
                                .border(1.dp, MagicCyan.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                                .clickable { onStartShizukuDirectly() }
                                .padding(12.dp)
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    text = "🚀 Bật Lại Kết Nối Nhanh",
                                    color = MagicCyan,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Khởi chạy lại kết nối không cần ghép nối lại.",
                                    color = TextMuted,
                                    fontSize = 11.5.sp,
                                    lineHeight = 16.sp
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(MagicSurfaceDark)
                                .border(1.dp, MagicEmerald.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                                .clickable { onUnlockRestrictedSettings() }
                                .padding(12.dp)
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    text = "🔓 Mở Khóa Cài Đặt Bị Mờ",
                                    color = MagicEmerald,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Cho phép bật Trợ năng & Thông báo trên Android 13–17.",
                                    color = TextMuted,
                                    fontSize = 11.5.sp,
                                    lineHeight = 16.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
