package com.example.ui.components

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material.icons.filled.ThumbUp
import com.example.core.license.LicenseManager
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.shell.ShellEngineState
import com.example.core.shell.ShellMode
import com.example.data.APP_VERSION_NAME
import com.example.data.DeviceInfo
import com.example.ui.MainTab
import com.example.ui.theme.MagicAmber
import com.example.ui.theme.MagicBlue
import com.example.ui.theme.MagicBorder
import com.example.ui.theme.MagicCyan
import com.example.ui.theme.MagicCyanLight
import com.example.ui.theme.MagicDarkBackground
import com.example.ui.theme.MagicEmerald
import com.example.ui.theme.MagicRose
import com.example.ui.theme.MagicRoseLight
import com.example.ui.theme.MagicSurfaceCard
import com.example.ui.theme.MagicSurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

import com.example.core.auth.FirebaseAuthManager

import androidx.compose.runtime.collectAsState
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.TextButton
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Close

@Composable
fun HeaderSection(
    deviceInfo: DeviceInfo,
    shellState: ShellEngineState,
    currentTab: MainTab,
    onTabSelected: (MainTab) -> Unit,
    onOpenRevertModal: () -> Unit,
    onOpenWlanDialog: () -> Unit,
    onDisconnectWlan: () -> Unit = {},
    onRequestShizukuPermission: () -> Unit,
    onOpenShizukuTab: () -> Unit = {},
    onOpenYouTube: () -> Unit = {},
    onOpenPermissionDialog: () -> Unit = {},
    isPermissionFullyGranted: Boolean = true,
    globalSearchQuery: String = "",
    onGlobalSearchChange: (String) -> Unit = {},
    onOpenChatSupport: () -> Unit = {}
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    val proStateVersion by LicenseManager.proStateVersionFlow.collectAsState()
    var currentUser by remember { mutableStateOf(FirebaseAuthManager.getCurrentUser()) }
    var isAdmin by remember {
        mutableStateOf(
            FirebaseAuthManager.isCurrentAdmin(context, null) || LicenseManager.isCurrentUserAdmin(context)
        )
    }
    var isPro by remember { mutableStateOf(LicenseManager.isProActivated(context)) }
    var isAccountPro by remember { mutableStateOf(LicenseManager.isAccountProActivated(context)) }
    val globalBroadcast by LicenseManager.globalBroadcastFlow.collectAsState()

    androidx.compose.runtime.LaunchedEffect(proStateVersion) {
        currentUser = FirebaseAuthManager.getCurrentUser()
        isAdmin = FirebaseAuthManager.isCurrentAdmin(context, null) || LicenseManager.isCurrentUserAdmin(context)
        isPro = LicenseManager.isProActivated(context)
        isAccountPro = LicenseManager.isAccountProActivated(context)
    }

    androidx.compose.runtime.DisposableEffect(Unit) {
        val authListener = com.google.firebase.auth.FirebaseAuth.AuthStateListener { firebaseAuth ->
            currentUser = firebaseAuth.currentUser
            isAdmin = FirebaseAuthManager.isCurrentAdmin(context, null) || LicenseManager.isCurrentUserAdmin(context)
            isPro = LicenseManager.isProActivated(context)
            isAccountPro = LicenseManager.isAccountProActivated(context)
        }
        try {
            FirebaseAuthManager.getAuth().addAuthStateListener(authListener)
        } catch (_: Exception) {}

        val receiver = object : android.content.BroadcastReceiver() {
            override fun onReceive(ctx: android.content.Context?, intent: Intent?) {
                val c = ctx ?: return
                currentUser = FirebaseAuthManager.getCurrentUser()
                isAdmin = FirebaseAuthManager.isCurrentAdmin(c, null) || LicenseManager.isCurrentUserAdmin(c)
                isPro = LicenseManager.isProActivated(c)
                isAccountPro = LicenseManager.isAccountProActivated(c)
            }
        }
        val filter = android.content.IntentFilter().apply {
            addAction(LicenseManager.ACTION_PRO_ACTIVATED)
            addAction(LicenseManager.ACTION_CONFIG_UPDATED)
        }
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            context.registerReceiver(receiver, filter, android.content.Context.RECEIVER_NOT_EXPORTED)
        } else {
            context.registerReceiver(receiver, filter)
        }
        onDispose {
            try { FirebaseAuthManager.getAuth().removeAuthStateListener(authListener) } catch (_: Exception) {}
            try { context.unregisterReceiver(receiver) } catch (_: Exception) {}
        }
    }

    var isBannerDismissed by remember(globalBroadcast?.id) {
        mutableStateOf(
            globalBroadcast?.id?.let { id ->
                LicenseManager.isBroadcastDismissed(context, id)
            } ?: false
        )
    }
    var dismissedBroadcastId by remember(globalBroadcast?.id) {
        mutableStateOf(
            globalBroadcast?.id?.let { id ->
                if (LicenseManager.isBroadcastDismissed(context, id)) id else ""
            } ?: ""
        )
    }
    var forceShowBroadcastModal by remember { mutableStateOf(false) }

    val activeBroadcast = globalBroadcast?.takeIf { it.isActive && (it.title.isNotBlank() || it.message.isNotBlank()) }
    val hasUpdateBroadcast = activeBroadcast?.type == "UPDATE"
    val shouldShowBroadcastModal = forceShowBroadcastModal || (activeBroadcast != null && dismissedBroadcastId != activeBroadcast.id)

    if (shouldShowBroadcastModal && activeBroadcast != null) {
        AlertDialog(
            onDismissRequest = {
                LicenseManager.markBroadcastDismissed(context, activeBroadcast.id)
                dismissedBroadcastId = activeBroadcast.id
                isBannerDismissed = true
                forceShowBroadcastModal = false
            },
            containerColor = MagicSurfaceCard,
            title = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (activeBroadcast.type == "UPDATE") MagicAmber.copy(alpha = 0.2f) else MagicCyan.copy(alpha = 0.2f))
                            .border(1.dp, if (activeBroadcast.type == "UPDATE") MagicAmber else MagicCyan, RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = if (activeBroadcast.type == "UPDATE") "🚀 THÔNG BÁO CẬP NHẬT TOÀN CẦU" else "📢 THÔNG BÁO TOÀN CẦU TỪ ADMIN",
                            color = if (activeBroadcast.type == "UPDATE") MagicAmber else MagicCyanLight,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                    Text(
                        text = activeBroadcast.title.ifBlank { "Thông báo từ Quản trị viên" },
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = activeBroadcast.message,
                        color = TextPrimary,
                        fontSize = 13.sp,
                        lineHeight = 19.sp
                    )
                    if (activeBroadcast.type == "UPDATE") {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(MagicEmerald.copy(alpha = 0.14f))
                                .border(1.dp, MagicEmerald.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                .padding(10.dp)
                        ) {
                            Text(
                                text = "💡 Mẹo: Bạn có thể bấm nút tải ngay bên dưới hoặc ấn vào nút 'Bản cập nhật' ở góc trái trên cùng màn hình (Header) bất cứ lúc nào!",
                                color = MagicEmerald,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            },
            confirmButton = {
                if (activeBroadcast.type == "UPDATE") {
                    Button(
                        onClick = {
                            LicenseManager.markBroadcastDismissed(context, activeBroadcast.id)
                            dismissedBroadcastId = activeBroadcast.id
                            isBannerDismissed = true
                            forceShowBroadcastModal = false
                            try {
                                val targetUrl = activeBroadcast.actionUrl.ifBlank { LicenseManager.getUpdateLink(context) }
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(targetUrl)).apply {
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                context.startActivity(intent)
                            } catch (_: Exception) {}
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MagicEmerald),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.SystemUpdate, contentDescription = null, tint = Color(0xFF020617), modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Tải Bản Cập Nhật Mới", color = Color(0xFF020617), fontWeight = FontWeight.Black, fontSize = 12.sp)
                    }
                } else {
                    Button(
                        onClick = {
                            LicenseManager.markBroadcastDismissed(context, activeBroadcast.id)
                            dismissedBroadcastId = activeBroadcast.id
                            isBannerDismissed = true
                            forceShowBroadcastModal = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MagicCyan),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Đã Hiểu", color = Color(0xFF020617), fontWeight = FontWeight.Black, fontSize = 12.sp)
                    }
                }
            },
            dismissButton = {
                if (activeBroadcast.type == "UPDATE") {
                    TextButton(
                        onClick = {
                            LicenseManager.markBroadcastDismissed(context, activeBroadcast.id)
                            dismissedBroadcastId = activeBroadcast.id
                            isBannerDismissed = true
                            forceShowBroadcastModal = false
                        }
                    ) {
                        Text("Để sau", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(MagicDarkBackground)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        // Banner Thông Báo Toàn Cầu (Hiển thị nổi bật ngay trên Header khi Admin phát thông báo, có nút X để người dùng đóng lại cho gọn)
        if (activeBroadcast != null && !isBannerDismissed) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(
                        if (hasUpdateBroadcast) MagicAmber.copy(alpha = 0.16f)
                        else MagicCyan.copy(alpha = 0.14f)
                    )
                    .border(
                        1.dp,
                        if (hasUpdateBroadcast) MagicAmber else MagicCyan,
                        RoundedCornerShape(8.dp)
                    )
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = if (hasUpdateBroadcast) Icons.Default.SystemUpdate else Icons.Default.Campaign,
                    contentDescription = "Thông báo toàn cầu",
                    tint = if (hasUpdateBroadcast) MagicAmber else MagicCyanLight,
                    modifier = Modifier.size(18.dp)
                )
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { forceShowBroadcastModal = true }
                ) {
                    Text(
                        text = activeBroadcast.title.ifBlank { "📢 Thông báo từ Quản trị viên" },
                        color = if (hasUpdateBroadcast) MagicAmber else MagicCyanLight,
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Black,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (activeBroadcast.message.isNotBlank()) {
                        Text(
                            text = activeBroadcast.message,
                            color = Color.White,
                            fontSize = 10.5.sp,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                if (hasUpdateBroadcast) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(MagicEmerald)
                            .clickable {
                                try {
                                    val targetUrl = activeBroadcast.actionUrl.ifBlank { LicenseManager.getUpdateLink(context) }
                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(targetUrl)).apply {
                                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    }
                                    context.startActivity(intent)
                                } catch (_: Exception) {}
                            }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "📥 Tải Ngay",
                            color = Color(0xFF020617),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }
                // Nút X để người dùng ẩn thông báo cho gọn
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.15f))
                        .clickable {
                            LicenseManager.markBroadcastDismissed(context, activeBroadcast.id)
                            isBannerDismissed = true
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Ẩn thông báo",
                        tint = Color.White,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }

        // Hàng 1: Tên ứng dụng + Nút Bản cập nhật | Trạng thái + YouTube + Revert
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Trái: Tên ứng dụng (Không logo) + Nút Bản cập nhật (Thay slogan)
            Column(modifier = Modifier.weight(1f, fill = false)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "MagicTune Tool",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        maxLines = 1
                    )
                    Text(
                        text = APP_VERSION_NAME,
                        color = MagicCyanLight,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(3.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    // Nút Bản cập nhật (Drive link) - Tự động nổi bật khi Admin báo có Bản cập nhật mới
                    Box(
                        modifier = Modifier
                            .testTag("header_update_button")
                            .clip(RoundedCornerShape(6.dp))
                            .background(
                                if (hasUpdateBroadcast) MagicAmber.copy(alpha = 0.25f)
                                else MagicCyan.copy(alpha = 0.15f)
                            )
                            .border(
                                1.dp,
                                if (hasUpdateBroadcast) MagicAmber else MagicCyan.copy(alpha = 0.4f),
                                RoundedCornerShape(6.dp)
                            )
                            .clickable {
                                try {
                                    val updateLink = activeBroadcast?.actionUrl?.takeIf { it.isNotBlank() }
                                        ?: LicenseManager.getUpdateLink(context)
                                    val intent = Intent(
                                        Intent.ACTION_VIEW,
                                        Uri.parse(updateLink)
                                    ).apply {
                                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    }
                                    context.startActivity(intent)
                                } catch (_: Exception) {}
                            }
                            .padding(horizontal = 6.dp, vertical = 3.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Icon(
                                imageVector = Icons.Default.SystemUpdate,
                                contentDescription = null,
                                tint = if (hasUpdateBroadcast) MagicAmber else MagicCyan,
                                modifier = Modifier.size(12.dp)
                            )
                            Text(
                                text = if (hasUpdateBroadcast) "🔥 Bản cập nhật (MỚI)" else "Bản cập nhật",
                                color = if (hasUpdateBroadcast) MagicAmber else MagicCyanLight,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }

                    // Nút Facebook
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(MagicBlue.copy(alpha = 0.15f))
                            .border(1.dp, MagicBlue.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                            .clickable {
                                try {
                                    val fbLink = LicenseManager.getFacebookLink(context)
                                    val intent = Intent(
                                        Intent.ACTION_VIEW,
                                        Uri.parse(fbLink)
                                    ).apply {
                                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    }
                                    context.startActivity(intent)
                                } catch (_: Exception) {}
                            }
                            .padding(horizontal = 6.dp, vertical = 3.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Icon(
                                imageVector = Icons.Default.ThumbUp,
                                contentDescription = "Facebook",
                                tint = MagicBlue,
                                modifier = Modifier.size(12.dp)
                            )
                            Text(
                                text = "Facebook",
                                color = MagicBlue,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Phải: Cột chứa [Hàng 1: Trạng thái kết nối + YouTube + Hoàn tác] và [Hàng 2 ngay dưới: Nút Đủ Quyền]
            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                // Hàng 1
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val isShizukuLive = shellState.isShizukuRunning && shellState.isShizukuPermissionGranted
                    val isDirectWlanLive = shellState.isWirelessAdbConnected
                    val isRootLive = shellState.mode == ShellMode.ROOT && shellState.isRootAvailable
                    val isConnected = isShizukuLive || isDirectWlanLive || isRootLive

                    val badgeText = when {
                        isConnected -> "✓ Đã kết nối"
                        shellState.isShizukuRunning && !shellState.isShizukuPermissionGranted -> "Cấp quyền"
                        else -> "Kết nối"
                    }

                    Box(
                        modifier = Modifier
                            .defaultMinSize(minHeight = 32.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                if (isConnected) MagicEmerald.copy(alpha = 0.18f) 
                                else MagicAmber.copy(alpha = 0.18f)
                            )
                            .border(
                                1.dp, 
                                if (isConnected) MagicEmerald else MagicAmber, 
                                RoundedCornerShape(8.dp)
                            )
                            .clickable {
                                if (shellState.isShizukuInstalled && shellState.isShizukuRunning && !shellState.isShizukuPermissionGranted) {
                                    onRequestShizukuPermission()
                                } else {
                                    onOpenShizukuTab()
                                }
                            }
                            .padding(horizontal = 8.dp, vertical = 5.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = badgeText,
                            color = if (isConnected) MagicEmerald else MagicAmber,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black
                        )
                    }

                    // YouTube Icon
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(MagicRose.copy(alpha = 0.12f))
                            .border(1.dp, MagicRose.copy(alpha = 0.35f), RoundedCornerShape(8.dp))
                            .clickable { onOpenYouTube() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "YouTube",
                            tint = MagicRose,
                            modifier = Modifier.size(17.dp)
                        )
                    }

                    // Revert (Hoàn tác) Icon
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(MagicSurfaceCard)
                            .border(1.dp, MagicBorder, RoundedCornerShape(8.dp))
                            .clickable { onOpenRevertModal() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Hoàn tác",
                            tint = MagicRoseLight,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                // Hàng 2: Nút Chat Support & Nút Quyền App nằm ngay ở hàng dưới nút YouTube & Hoàn tác
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(MagicCyan.copy(alpha = 0.2f))
                            .border(1.dp, MagicCyan, RoundedCornerShape(6.dp))
                            .clickable { onOpenChatSupport() }
                            .padding(horizontal = 6.dp, vertical = 3.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                            Icon(imageVector = Icons.AutoMirrored.Filled.Chat, contentDescription = "Hỗ trợ trực tuyến", tint = MagicCyan, modifier = Modifier.size(11.dp))
                            Text("💬 Hỗ trợ", color = MagicCyanLight, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(
                                if (isPermissionFullyGranted) MagicEmerald.copy(alpha = 0.15f)
                                else MagicAmber.copy(alpha = 0.22f)
                            )
                            .border(
                                1.dp,
                                if (isPermissionFullyGranted) MagicEmerald.copy(alpha = 0.5f)
                                else MagicAmber,
                                RoundedCornerShape(6.dp)
                            )
                            .clickable { onOpenPermissionDialog() }
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = if (isPermissionFullyGranted) "🛡️ Đủ quyền" else "⚠️ Cấp quyền",
                            color = if (isPermissionFullyGranted) MagicEmerald else MagicAmber,
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Hàng 2: Thanh tìm kiếm (Giữ nguyên cho dễ gõ)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(42.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(MagicSurfaceDark)
                .border(
                    1.dp,
                    if (globalSearchQuery.isNotBlank()) MagicCyan else MagicBorder,
                    RoundedCornerShape(10.dp)
                )
                .padding(horizontal = 10.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Tìm kiếm",
                    tint = if (globalSearchQuery.isNotBlank()) MagicCyan else TextSecondary,
                    modifier = Modifier.size(18.dp)
                )
                Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                    if (globalSearchQuery.isEmpty()) {
                        Text(
                            text = "Tìm kiếm nhanh...",
                            color = TextSecondary,
                            fontSize = 12.sp,
                            maxLines = 1
                        )
                    }
                    BasicTextField(
                        value = globalSearchQuery,
                        onValueChange = onGlobalSearchChange,
                        singleLine = true,
                        cursorBrush = SolidColor(MagicCyan),
                        textStyle = TextStyle(color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                if (globalSearchQuery.isNotBlank()) {
                    Icon(
                        imageVector = Icons.Default.Clear,
                        contentDescription = "Xóa",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp).clickable { onGlobalSearchChange("") }
                    )
                }
            }
        }

        // Hàng 3: Các Nút Tab mỏng, nhỏ gọn, tiết kiệm không gian
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(scrollState),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            val tabs = mutableListOf<Pair<MainTab, String>>()
            tabs.add(MainTab.SETUP to "1. ⚙️ Thiết Lập")
            tabs.add(MainTab.TUNE to "2. 🚀 Tối Ưu & AI")
            tabs.add(MainTab.NOTIFICATIONS to "3. 🔔 Thông Báo")
            tabs.add(MainTab.SHIZUKU to "4. 🔌 Kết Nối Trực Tiếp")
            tabs.add(MainTab.APPS to "5. 🗑️ Dọn Ứng Dụng")
            // TAB TERMINAL SHELL: Chỉ hiển thị cho Admin đã đăng nhập để bảo vệ bản quyền các câu lệnh hệ thống độc quyền
            if (isAdmin && currentUser != null) {
                tabs.add(MainTab.SHELL_TAB to "6. 💻 Terminal Shell")
            }
            tabs.add(MainTab.APP_STORE to "7. 📦 Kho App")

            if (currentUser == null) {
                if (isPro) {
                    tabs.add(MainTab.ACCOUNT to (if (isAccountPro) "👑 Pro TK (Máy Quen)" else "👑 Máy Đã Pro"))
                }
                tabs.add(MainTab.LOGIN to "🔐 Đăng Nhập")
            } else {
                tabs.add(MainTab.ACCOUNT to (if (isAccountPro) "👑 Tài Khoản (Pro)" else if (isPro) "📱 Tài Khoản (Pro)" else "👤 Tài Khoản"))
            }

            // CHỈ HIỂN THỊ TAB QUẢN TRỊ KHI ADMIN ĐÃ ĐĂNG NHẬP TÀI KHOẢN THỰC SỰ
            // Nếu chưa đăng nhập (dù là Máy Quen), không hiển thị để tránh thao tác duyệt ảo bị Firebase Security Rules chặn
            if (isAdmin && currentUser != null) {
                tabs.add(MainTab.ADMIN to "👑 Quản Trị")
            }

            tabs.forEach { (tab, title) ->
                CompactTabButton(
                    title = title,
                    isSelected = currentTab == tab,
                    onClick = { onTabSelected(tab) }
                )
            }
        }
    }
}

@Composable
private fun CompactTabButton(
    title: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val bgModifier = if (isSelected) {
        Modifier.background(Brush.horizontalGradient(listOf(MagicBlue, MagicCyan)))
    } else {
        Modifier.background(MagicSurfaceCard)
    }

    Box(
        modifier = Modifier
            .defaultMinSize(minHeight = 28.dp)
            .clip(RoundedCornerShape(7.dp))
            .then(bgModifier)
            .border(
                width = 1.dp,
                color = if (isSelected) MagicCyanLight else MagicBorder,
                shape = RoundedCornerShape(7.dp)
            )
            .clickable { onClick() }
            .padding(horizontal = 9.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = title,
            color = if (isSelected) Color.White else TextPrimary,
            fontSize = 11.5.sp,
            fontWeight = if (isSelected) FontWeight.Black else FontWeight.Bold,
            maxLines = 1
        )
    }
}
