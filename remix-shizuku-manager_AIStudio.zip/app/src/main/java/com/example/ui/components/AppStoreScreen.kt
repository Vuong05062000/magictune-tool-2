package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.auth.FirebaseAuthManager
import com.example.core.license.LicenseManager
import com.example.data.HonorAppItem
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun AppStoreScreen(
    onNavigateBack: () -> Unit = {}
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val scrollState = rememberScrollState()

    val currentUser = FirebaseAuthManager.getCurrentUser()
    val isAdmin = FirebaseAuthManager.isCurrentAdmin(context, null)
    val isProUser = LicenseManager.isProActivated(context) || isAdmin

    // Dữ liệu ứng dụng từ Firestore
    var cloudApps by remember { mutableStateOf<List<HonorAppItem>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    // Tìm kiếm, Bộ lọc & Phân trang
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Tất cả") }
    var selectedProFilter by remember { mutableStateOf("Tất cả") } // "Tất cả", "⚡ Bản PRO", "Miễn phí"
    var currentPage by remember { mutableIntStateOf(0) }
    val pageSize = 6

    // Dialog Thêm / Sửa App (Dành cho Admin)
    var showAppEditDialog by remember { mutableStateOf(false) }
    var appToEdit by remember { mutableStateOf<HonorAppItem?>(null) }
    var inputAppName by remember { mutableStateOf("") }
    var inputAppUrl by remember { mutableStateOf("") }
    var inputAppDesc by remember { mutableStateOf("") }
    var inputAppCategory by remember { mutableStateOf("Tiện Ích") }
    var inputAppVersion by remember { mutableStateOf("1.0") }
    var inputAppProOnly by remember { mutableStateOf(false) }

    // Dialog xác nhận xóa app
    var appToDelete by remember { mutableStateOf<HonorAppItem?>(null) }

    // Dialog Đóng góp App (Dành cho Người Dùng)
    var showContributeDialog by remember { mutableStateOf(false) }
    var contributeAppName by remember { mutableStateOf("") }
    var contributeAppUrl by remember { mutableStateOf("") }
    var contributeAppDesc by remember { mutableStateOf("") }
    var contributeAppCategory by remember { mutableStateOf("Tiện Ích") }
    var contributeAppVersion by remember { mutableStateOf("1.0") }
    var contributeAppAuthor by remember { mutableStateOf(currentUser?.displayName ?: "") }
    var isSubmittingContribute by remember { mutableStateOf(false) }

    // Danh sách ứng dụng mặc định chất lượng cao cho Honor
    val defaultPresetApps = remember {
        listOf(
            HonorAppItem(
                id = "preset_gemini",
                name = "Google Gemini AI",
                description = "Trợ lý trí tuệ nhân tạo chính thức từ Google, trò chuyện giọng nói tự nhiên và xử lý hình ảnh thông minh.",
                downloadUrl = "https://play.google.com/store/apps/details?id=com.google.android.apps.bard",
                category = "Trợ Lý / AI",
                version = "Mới nhất",
                author = "Google LLC",
                isProOnly = false,
                iconName = "smart_toy"
            ),
            HonorAppItem(
                id = "preset_shizuku",
                name = "Shizuku",
                description = "Công cụ cầu nối quyền hệ thống ADB không cần Root, bắt buộc phải có để tối ưu sâu và đóng băng app Honor.",
                downloadUrl = "https://play.google.com/store/apps/details?id=moe.shizuku.privileged.api",
                category = "Tối Ưu / Mod",
                version = "v13.5",
                author = "Rikka",
                isProOnly = false,
                iconName = "security"
            ),
            HonorAppItem(
                id = "preset_gbox",
                name = "Gbox",
                description = "Giải pháp môi trường chạy Google Services hoàn hảo và ổn định nhất cho các máy Honor xách tay nội địa.",
                downloadUrl = "https://gboxlab.com/",
                category = "Google Services",
                version = "Mới nhất",
                author = "Gbox Lab",
                isProOnly = false,
                iconName = "cloud"
            ),
            HonorAppItem(
                id = "preset_microg",
                name = "MicroG Companion",
                description = "Dịch vụ Google Play mã nguồn mở gọn nhẹ, giúp nhận thông báo tức thì và đăng nhập tài khoản Google.",
                downloadUrl = "https://microg.org/download.html",
                category = "Google Services",
                version = "v0.3.x",
                author = "MicroG Project",
                isProOnly = false,
                iconName = "cloud"
            ),
            HonorAppItem(
                id = "preset_google_search",
                name = "Google App & Circle Search",
                description = "Ứng dụng tìm kiếm Google hỗ trợ khoanh tròn tìm kiếm (Circle to Search) trên thanh điều hướng Honor.",
                downloadUrl = "https://play.google.com/store/apps/details?id=com.google.android.googlequicksearchbox",
                category = "Tiện Ích",
                version = "Official",
                author = "Google LLC",
                isProOnly = false,
                iconName = "search"
            ),
            HonorAppItem(
                id = "preset_theme_studio",
                name = "Bộ Font & Theme Honor Việt Hóa",
                description = "Bộ sưu tập font chữ tiếng Việt không lỗi font và giao diện MagicOS tối ưu cho màn hình OLED.",
                downloadUrl = "https://drive.google.com/drive/folders/1WLsS-OlxvKFUWzMPxnkrNn8kmlVIY6-k?usp=sharing",
                category = "Giao Diện",
                version = "2026",
                author = "Admin VXM",
                isProOnly = false,
                iconName = "style"
            )
        )
    }

    // Lắng nghe Firestore
    LaunchedEffect(Unit) {
        coroutineScope.launch {
            try {
                FirebaseAuthManager.observeHonorApps().collect { list ->
                    cloudApps = list
                    isLoading = false
                }
            } catch (_: Exception) {
                isLoading = false
            }
        }
    }

    // Hợp nhất danh sách app: Cloud Apps ưu tiên, bổ sung preset nếu chưa có
    val allStoreApps = remember(cloudApps, isAdmin, currentUser) {
        // Chỉ hiển thị app đã được duyệt cho người dùng bình thường
        // Người dùng cũng có thể thấy app mình đã đóng góp đang chờ duyệt
        val visibleCloudApps = if (isAdmin) {
            cloudApps
        } else {
            cloudApps.filter { it.status == "APPROVED" || (it.contributorEmail.isNotBlank() && it.contributorEmail == currentUser?.email) }
        }

        if (visibleCloudApps.isEmpty() && cloudApps.isEmpty()) {
            defaultPresetApps
        } else {
            val existingIds = visibleCloudApps.map { it.id }.toSet()
            val existingNames = visibleCloudApps.map { it.name.trim().lowercase() }.toSet()
            val missingPresets = defaultPresetApps.filter {
                it.id !in existingIds && it.name.trim().lowercase() !in existingNames
            }
            visibleCloudApps + missingPresets
        }
    }

    // Lọc theo Tìm kiếm & Danh mục & Pro
    val filteredApps = remember(allStoreApps, searchQuery, selectedCategory, selectedProFilter) {
        allStoreApps.filter { app ->
            val matchCategory = selectedCategory == "Tất cả" || app.category.equals(selectedCategory, ignoreCase = true)
            val matchPro = when (selectedProFilter) {
                "⚡ Bản PRO" -> app.isProOnly
                "Miễn phí" -> !app.isProOnly
                else -> true
            }
            val matchQuery = searchQuery.isBlank() ||
                app.name.contains(searchQuery, ignoreCase = true) ||
                app.description.contains(searchQuery, ignoreCase = true) ||
                app.category.contains(searchQuery, ignoreCase = true) ||
                app.author.contains(searchQuery, ignoreCase = true)

            matchCategory && matchPro && matchQuery
        }
    }

    val totalPages = ((filteredApps.size - 1) / pageSize) + 1
    val safeCurrentPage = currentPage.coerceIn(0, (totalPages - 1).coerceAtLeast(0))
    val paginatedApps = remember(filteredApps, safeCurrentPage) {
        val start = safeCurrentPage * pageSize
        val end = (start + pageSize).coerceAtMost(filteredApps.size)
        if (start in 0 until filteredApps.size) filteredApps.subList(start, end) else emptyList()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MagicDarkBackground)
            .verticalScroll(scrollState)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Top Header
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
            border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.5f))
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Storefront,
                            contentDescription = null,
                            tint = MagicCyan,
                            modifier = Modifier.size(24.dp)
                        )
                        Text(
                            text = "KHO ỨNG DỤNG HONOR",
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Black
                        )
                    }

                    if (isAdmin) {
                        Button(
                            onClick = {
                                appToEdit = null
                                inputAppName = ""
                                inputAppUrl = ""
                                inputAppDesc = ""
                                inputAppCategory = "Tiện Ích"
                                inputAppVersion = "1.0"
                                inputAppProOnly = false
                                showAppEditDialog = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MagicEmerald),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier.height(34.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color(0xFF020617))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Thêm App Mới", color = Color(0xFF020617), fontSize = 11.sp, fontWeight = FontWeight.Black)
                        }
                    } else if (currentUser != null) {
                        // Nút đóng góp cho người dùng
                        Button(
                            onClick = {
                                contributeAppName = ""
                                contributeAppUrl = ""
                                contributeAppDesc = ""
                                contributeAppCategory = "Tiện Ích"
                                contributeAppVersion = "1.0"
                                contributeAppAuthor = currentUser.displayName ?: ""
                                showContributeDialog = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MagicCyan),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier.height(34.dp)
                        ) {
                            Icon(imageVector = Icons.Default.FileUpload, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color(0xFF020617))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Đóng Góp App", color = Color(0xFF020617), fontSize = 11.sp, fontWeight = FontWeight.Black)
                        }
                    }
                }

                Text(
                    text = "Khám phá và cài đặt các ứng dụng, công cụ mod và tiện ích tối ưu tốt nhất dành riêng cho điện thoại Honor MagicOS.",
                    color = TextSecondary,
                    fontSize = 11.5.sp,
                    lineHeight = 16.sp
                )
            }
        }

        // Thanh Tìm Kiếm
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it; currentPage = 0 },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("app_store_search_input"),
            label = { Text("Tìm tên app, tính năng, tiện ích...", fontSize = 11.5.sp) },
            singleLine = true,
            shape = RoundedCornerShape(10.dp),
            leadingIcon = {
                Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = MagicCyan, modifier = Modifier.size(18.dp))
            },
            trailingIcon = {
                if (searchQuery.isNotBlank()) {
                    IconButton(onClick = { searchQuery = ""; currentPage = 0 }) {
                        Icon(imageVector = Icons.Default.Clear, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                    }
                }
            }
        )

        // Bộ lọc Danh mục
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                val categories = listOf("Tất cả", "Trợ Lý / AI", "Tiện Ích", "Tối Ưu / Mod", "Google Services", "Giao Diện")
                categories.forEach { cat ->
                    val isSelected = selectedCategory == cat
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedCategory = cat; currentPage = 0 },
                        label = { Text(cat, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MagicCyan.copy(alpha = 0.25f),
                            selectedLabelColor = MagicCyanLight,
                            containerColor = MagicSurfaceDark,
                            labelColor = TextSecondary
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = isSelected,
                            borderColor = if (isSelected) MagicCyan else MagicBorder
                        )
                    )
                }
            }

            // Bộ lọc Pro / Miễn Phí
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                val proFilters = listOf("Tất cả", "⚡ Bản PRO", "Miễn phí")
                proFilters.forEach { filter ->
                    val isSelected = selectedProFilter == filter
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedProFilter = filter; currentPage = 0 },
                        label = { Text(filter, fontSize = 10.5.sp, fontWeight = FontWeight.Bold) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = if (filter == "⚡ Bản PRO") MagicEmerald.copy(alpha = 0.25f) else MagicPurple.copy(alpha = 0.25f),
                            selectedLabelColor = if (filter == "⚡ Bản PRO") MagicEmeraldLight else MagicPurpleLight,
                            containerColor = MagicSurfaceDark,
                            labelColor = TextMuted
                        )
                    )
                }
            }
        }

        // Danh sách App
        if (paginatedApps.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(MagicSurfaceDark),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(imageVector = Icons.Default.SearchOff, contentDescription = null, tint = TextMuted, modifier = Modifier.size(32.dp))
                    Text(
                        text = "Không tìm thấy ứng dụng nào phù hợp.",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        } else {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                paginatedApps.forEach { app ->
                    val isAppProRestricted = app.isProOnly

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                        border = BorderStroke(
                            1.dp,
                            if (isAppProRestricted) MagicEmerald.copy(alpha = 0.6f) else MagicBorder
                        )
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Tiêu đề & Nhãn
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    val iconVector = when (app.iconName) {
                                        "mic" -> Icons.Default.Mic
                                        "smart_toy" -> Icons.Default.SmartToy
                                        "security" -> Icons.Default.Security
                                        "cloud" -> Icons.Default.CloudDownload
                                        "style" -> Icons.Default.Palette
                                        else -> Icons.Default.Apps
                                    }
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(if (isAppProRestricted) MagicEmerald.copy(alpha = 0.2f) else MagicCyan.copy(alpha = 0.15f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = iconVector,
                                            contentDescription = null,
                                            tint = if (isAppProRestricted) MagicEmeraldLight else MagicCyanLight,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }

                                    Column {
                                        Text(
                                            text = app.name,
                                            color = Color.White,
                                            fontSize = 13.5.sp,
                                            fontWeight = FontWeight.Black,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Text(text = app.category, color = MagicCyanLight, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                            Text(text = "•", color = TextMuted, fontSize = 10.sp)
                                            Text(text = app.version, color = TextSecondary, fontSize = 10.sp)
                                        }
                                    }
                                }

                                if (isAppProRestricted) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(MagicEmerald.copy(alpha = 0.2f))
                                            .border(1.dp, MagicEmerald.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = "⚡ ĐỘC QUYỀN PRO",
                                            color = MagicEmeraldLight,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Black
                                        )
                                    }
                                } else if (app.status == "PENDING") {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(MagicAmber.copy(alpha = 0.2f))
                                            .border(1.dp, MagicAmber.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = "⌛ CHỜ DUYỆT",
                                            color = MagicAmber,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Black
                                        )
                                    }
                                } else if (app.status == "REJECTED") {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(MagicRose.copy(alpha = 0.2f))
                                            .border(1.dp, MagicRose.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = "❌ BỊ TỪ CHỐI",
                                            color = MagicRoseLight,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Black
                                        )
                                    }
                                }
                            }

                            // Mô tả app
                            Text(
                                text = app.description,
                                color = TextSecondary,
                                fontSize = 11.5.sp,
                                lineHeight = 16.sp
                            )

                            // Hàng nút bấm hành động
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Tác giả
                                Text(
                                    text = "Đăng bởi: ${app.author}",
                                    color = TextMuted,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Medium
                                )

                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    // Nút Copy Link
                                    IconButton(
                                        onClick = {
                                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                            val clip = ClipData.newPlainText("App Link", app.downloadUrl)
                                            clipboard.setPrimaryClip(clip)
                                            Toast.makeText(context, "Đã sao chép liên kết tải ${app.name}!", Toast.LENGTH_SHORT).show()
                                        },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copy Link", tint = TextSecondary, modifier = Modifier.size(15.dp))
                                    }

                                    // Nếu là Admin: nút Duyệt, Từ chối, Sửa & Xóa
                                    if (isAdmin) {
                                        if (app.status == "PENDING") {
                                            IconButton(
                                                onClick = {
                                                    coroutineScope.launch {
                                                        try {
                                                            FirebaseAuthManager.updateHonorAppStatus(app.id, "APPROVED")
                                                            Toast.makeText(context, "✅ Đã duyệt ứng dụng: ${app.name}", Toast.LENGTH_SHORT).show()
                                                        } catch (e: Exception) {
                                                            Toast.makeText(context, "Lỗi duyệt: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                                                        }
                                                    }
                                                },
                                                modifier = Modifier.size(32.dp)
                                            ) {
                                                Icon(imageVector = Icons.Default.CheckCircle, contentDescription = "Duyệt", tint = MagicEmeraldLight, modifier = Modifier.size(18.dp))
                                            }

                                            IconButton(
                                                onClick = {
                                                    coroutineScope.launch {
                                                        try {
                                                            FirebaseAuthManager.updateHonorAppStatus(app.id, "REJECTED")
                                                            Toast.makeText(context, "❌ Đã từ chối ứng dụng: ${app.name}", Toast.LENGTH_SHORT).show()
                                                        } catch (e: Exception) {
                                                            Toast.makeText(context, "Lỗi từ chối: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                                                        }
                                                    }
                                                },
                                                modifier = Modifier.size(32.dp)
                                            ) {
                                                Icon(imageVector = Icons.Default.Cancel, contentDescription = "Từ chối", tint = MagicRoseLight, modifier = Modifier.size(18.dp))
                                            }
                                        }

                                        IconButton(
                                            onClick = {
                                                appToEdit = app
                                                inputAppName = app.name
                                                inputAppUrl = app.downloadUrl
                                                inputAppDesc = app.description
                                                inputAppCategory = app.category
                                                inputAppVersion = app.version
                                                inputAppProOnly = app.isProOnly
                                                showAppEditDialog = true
                                            },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(imageVector = Icons.Default.Edit, contentDescription = "Sửa", tint = MagicCyan, modifier = Modifier.size(15.dp))
                                        }

                                        IconButton(
                                            onClick = { appToDelete = app },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(imageVector = Icons.Default.Delete, contentDescription = "Xóa", tint = MagicRoseLight, modifier = Modifier.size(15.dp))
                                        }
                                    }

                                    // Nút Tải Ngay
                                    Button(
                                        onClick = {
                                            if (isAppProRestricted && !isProUser) {
                                                Toast.makeText(
                                                    context,
                                                    "🔒 TÍNH NĂNG ĐỘC QUYỀN BẢN PRO!\nChỉ các tài khoản PRO mới có quyền tải ${app.name}. Vui lòng nâng cấp bản PRO để tiếp tục.",
                                                    Toast.LENGTH_LONG
                                                ).show()
                                            } else {
                                                try {
                                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(app.downloadUrl)).apply {
                                                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                                    }
                                                    context.startActivity(intent)
                                                    Toast.makeText(context, "🚀 Đang mở tải ${app.name}...", Toast.LENGTH_SHORT).show()
                                                } catch (e: Exception) {
                                                    Toast.makeText(context, "Không thể mở liên kết: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                                                }
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (isAppProRestricted && !isProUser) MagicSurfaceCard else MagicCyan,
                                            contentColor = if (isAppProRestricted && !isProUser) MagicAmber else Color(0xFF020617)
                                        ),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.height(34.dp),
                                        border = if (isAppProRestricted && !isProUser) BorderStroke(1.dp, MagicAmber.copy(alpha = 0.6f)) else null
                                    ) {
                                        Icon(
                                            imageVector = if (isAppProRestricted && !isProUser) Icons.Default.Lock else Icons.Default.Download,
                                            contentDescription = null,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = if (isAppProRestricted && !isProUser) "Cần Bản Pro" else "Tải Về",
                                            fontWeight = FontWeight.Black,
                                            fontSize = 11.5.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Thanh Phân Trang
            if (totalPages > 1) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = { if (safeCurrentPage > 0) currentPage = safeCurrentPage - 1 },
                        enabled = safeCurrentPage > 0,
                        modifier = Modifier.height(36.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Trang trước", fontSize = 11.sp)
                    }

                    Text(
                        text = "Trang ${safeCurrentPage + 1} / $totalPages",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )

                    OutlinedButton(
                        onClick = { if (safeCurrentPage < totalPages - 1) currentPage = safeCurrentPage + 1 },
                        enabled = safeCurrentPage < totalPages - 1,
                        modifier = Modifier.height(36.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Trang sau", fontSize = 11.sp)
                    }
                }
            }
        }
    }

    // Dialog Thêm / Sửa App (Admin Only)
    if (showAppEditDialog) {
        val isEditing = appToEdit != null
        AlertDialog(
            onDismissRequest = { showAppEditDialog = false },
            containerColor = MagicSurfaceDark,
            title = {
                Text(
                    text = if (isEditing) "Sửa Ứng Dụng Trong Kho" else "Thêm Ứng Dụng Mới Vào Kho",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = inputAppName,
                        onValueChange = { inputAppName = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Tên ứng dụng (Bắt buộc)", fontSize = 11.sp) },
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp)
                    )

                    OutlinedTextField(
                        value = inputAppUrl,
                        onValueChange = { inputAppUrl = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Đường dẫn tải / URL APK (Bắt buộc)", fontSize = 11.sp) },
                        placeholder = { Text("https://...") },
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp)
                    )

                    OutlinedTextField(
                        value = inputAppDesc,
                        onValueChange = { inputAppDesc = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Mô tả tính năng ngắn gọn", fontSize = 11.sp) },
                        maxLines = 3,
                        shape = RoundedCornerShape(8.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = inputAppCategory,
                            onValueChange = { inputAppCategory = it },
                            modifier = Modifier.weight(1.2f),
                            label = { Text("Danh mục", fontSize = 11.sp) },
                            placeholder = { Text("Tiện Ích") },
                            singleLine = true,
                            shape = RoundedCornerShape(8.dp)
                        )

                        OutlinedTextField(
                            value = inputAppVersion,
                            onValueChange = { inputAppVersion = it },
                            modifier = Modifier.weight(0.8f),
                            label = { Text("Phiên bản", fontSize = 11.sp) },
                            placeholder = { Text("v1.0") },
                            singleLine = true,
                            shape = RoundedCornerShape(8.dp)
                        )
                    }

                    // Tùy chọn chỉ dành cho bản Pro
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(MagicSurfaceCard)
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Chỉ mở cho tài khoản PRO tải",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Switch(
                            checked = inputAppProOnly,
                            onCheckedChange = { inputAppProOnly = it }
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (inputAppName.isBlank() || inputAppUrl.isBlank()) {
                            Toast.makeText(context, "Vui lòng nhập Tên và Đường dẫn tải!", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        coroutineScope.launch {
                            try {
                                val newApp = HonorAppItem(
                                    id = appToEdit?.id ?: "",
                                    name = inputAppName.trim(),
                                    description = inputAppDesc.trim(),
                                    downloadUrl = inputAppUrl.trim(),
                                    category = inputAppCategory.trim().ifBlank { "Tiện Ích" },
                                    version = inputAppVersion.trim().ifBlank { "v1.0" },
                                    author = currentUser?.displayName ?: "Admin VXM",
                                    isProOnly = inputAppProOnly,
                                    createdAt = appToEdit?.createdAt ?: System.currentTimeMillis()
                                )
                                FirebaseAuthManager.saveHonorApp(newApp)
                                Toast.makeText(context, "✅ Đã lưu ứng dụng vào Kho thành công!", Toast.LENGTH_SHORT).show()
                                showAppEditDialog = false
                            } catch (e: Exception) {
                                Toast.makeText(context, "Lỗi: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MagicCyan)
                ) {
                    Text("Lưu Vào Kho", color = Color(0xFF020617), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAppEditDialog = false }) {
                    Text("Hủy", color = TextSecondary, fontSize = 12.sp)
                }
            }
        )
    }

    // Dialog xác nhận xóa App (Admin Only)
    appToDelete?.let { app ->
        AlertDialog(
            onDismissRequest = { appToDelete = null },
            containerColor = MagicSurfaceDark,
            title = {
                Text("Xác nhận xóa ứng dụng", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            },
            text = {
                Text(
                    text = "Bạn có chắc chắn muốn xóa ứng dụng '${app.name}' khỏi Kho Ứng Dụng Honor không?",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        coroutineScope.launch {
                            try {
                                FirebaseAuthManager.deleteHonorApp(app.id)
                                Toast.makeText(context, "Đã xóa ứng dụng khỏi Kho!", Toast.LENGTH_SHORT).show()
                            } catch (e: Exception) {
                                Toast.makeText(context, "Lỗi: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                            } finally {
                                appToDelete = null
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MagicRose)
                ) {
                    Text("Xóa Ngay", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            },
            dismissButton = {
                TextButton(onClick = { appToDelete = null }) {
                    Text("Hủy", color = TextSecondary, fontSize = 12.sp)
                }
            }
        )
    }

    // Dialog Đóng góp App (Người Dùng)
    if (showContributeDialog) {
        AlertDialog(
            onDismissRequest = { if (!isSubmittingContribute) showContributeDialog = false },
            containerColor = MagicSurfaceDark,
            title = {
                Text(
                    text = "Đóng Góp Ứng Dụng",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Vui lòng nhập thông tin ứng dụng bạn muốn chia sẻ. Sau khi gửi, Admin sẽ kiểm duyệt trước khi hiển thị công khai.",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )

                    OutlinedTextField(
                        value = contributeAppName,
                        onValueChange = { contributeAppName = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Tên ứng dụng", fontSize = 11.sp) },
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp)
                    )

                    OutlinedTextField(
                        value = contributeAppUrl,
                        onValueChange = { contributeAppUrl = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Link tải APK / Play Store", fontSize = 11.sp) },
                        placeholder = { Text("https://...") },
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp)
                    )

                    OutlinedTextField(
                        value = contributeAppDesc,
                        onValueChange = { contributeAppDesc = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Mô tả ngắn gọn", fontSize = 11.sp) },
                        maxLines = 3,
                        shape = RoundedCornerShape(8.dp)
                    )

                    OutlinedTextField(
                        value = contributeAppAuthor,
                        onValueChange = { contributeAppAuthor = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Tác giả / Người đóng góp", fontSize = 11.sp) },
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp)
                    )
                    
                    if (isSubmittingContribute) {
                        LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = MagicCyan)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (contributeAppName.isBlank() || contributeAppUrl.isBlank()) {
                            Toast.makeText(context, "Vui lòng nhập Tên và Link tải!", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        isSubmittingContribute = true
                        coroutineScope.launch {
                            try {
                                val newApp = HonorAppItem(
                                    name = contributeAppName.trim(),
                                    description = contributeAppDesc.trim(),
                                    downloadUrl = contributeAppUrl.trim(),
                                    category = contributeAppCategory,
                                    version = contributeAppVersion,
                                    author = contributeAppAuthor.trim().ifBlank { currentUser?.displayName ?: "Người dùng ẩn danh" },
                                    status = "PENDING",
                                    contributorEmail = currentUser?.email ?: ""
                                )
                                FirebaseAuthManager.contributeHonorApp(newApp)
                                Toast.makeText(context, "🚀 Gửi đóng góp thành công! Đang chờ Admin duyệt.", Toast.LENGTH_LONG).show()
                                showContributeDialog = false
                            } catch (e: Exception) {
                                Toast.makeText(context, "Lỗi: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                            } finally {
                                isSubmittingContribute = false
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MagicCyan),
                    enabled = !isSubmittingContribute
                ) {
                    Text("Gửi Đóng Góp", color = Color(0xFF020617), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            },
            dismissButton = {
                TextButton(onClick = { showContributeDialog = false }, enabled = !isSubmittingContribute) {
                    Text("Hủy", color = TextSecondary, fontSize = 12.sp)
                }
            }
        )
    }
}
