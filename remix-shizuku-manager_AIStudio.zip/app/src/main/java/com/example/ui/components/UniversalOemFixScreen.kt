package com.example.ui.components

import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MagicAmber
import com.example.ui.theme.MagicAmberLight
import com.example.ui.theme.MagicBorder
import com.example.ui.theme.MagicCyan
import com.example.ui.theme.MagicCyanLight
import com.example.ui.theme.MagicDarkBackground
import com.example.ui.theme.MagicEmerald
import com.example.ui.theme.MagicRose
import com.example.ui.theme.MagicSurfaceCard
import com.example.ui.theme.MagicSurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary

@Composable
fun UniversalOemFixScreen(
    isBusy: Boolean,
    onBack: () -> Unit,
    onFixUniversalAll: () -> Unit,
    onFixXiaomi: () -> Unit,
    onFixOppo: () -> Unit,
    onFixVivo: () -> Unit,
    onFixHuawei: () -> Unit
) {
    BackHandler(onBack = onBack)

    val scrollState = rememberScrollState()
    val manufacturer = Build.MANUFACTURER.uppercase()
    val model = Build.MODEL
    val androidVersion = Build.VERSION.RELEASE

    val isXiaomi = manufacturer.contains("XIAOMI") || manufacturer.contains("REDMI") || manufacturer.contains("POCO")
    val isOppo = manufacturer.contains("OPPO") || manufacturer.contains("REALME") || manufacturer.contains("ONEPLUS")
    val isVivo = manufacturer.contains("VIVO") || manufacturer.contains("IQOO")
    val isHuawei = manufacturer.contains("HUAWEI")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MagicDarkBackground)
    ) {
        // Top App Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(MagicSurfaceDark)
                .padding(horizontal = 8.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier.testTag("universal_fix_back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Quay lại",
                    tint = MagicCyan
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "TRANG CHỨC NĂNG NGẦM",
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black
                )
                Text(
                    text = "Đặc trị trễ thông báo đa hãng: Xiaomi, Oppo, Vivo, Huawei...",
                    color = MagicCyanLight,
                    fontSize = 11.sp
                )
            }
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(MagicCyan.copy(alpha = 0.18f))
                    .border(1.dp, MagicCyan.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "OEM FIX PRO",
                    color = MagicCyan,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Black
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Banner Thiết bị nhận diện
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                border = BorderStroke(1.dp, MagicBorder)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.PhoneAndroid,
                                contentDescription = null,
                                tint = MagicCyan,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "THIẾT BỊ HIỆN TẠI",
                                color = MagicCyanLight,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MagicEmerald.copy(alpha = 0.2f))
                                .padding(horizontal = 6.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = "Android $androidVersion",
                                color = MagicEmerald,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "$manufacturer $model",
                                color = Color.White,
                                fontSize = 14.5.sp,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                text = when {
                                    isXiaomi -> "Phát hiện máy Xiaomi / Redmi / POCO • Cần tối ưu HyperOS/MIUI"
                                    isOppo -> "Phát hiện máy Oppo / Realme / OnePlus • Cần tắt Athena ColorOS"
                                    isVivo -> "Phát hiện máy Vivo / iQOO • Cần dỡ bỏ Night Sleep OriginOS"
                                    isHuawei -> "Phát hiện máy Huawei • Cần tắt PowerGenie EMUI/HarmonyOS"
                                    else -> "Khuyên dùng tính năng Fix Tổng Lực Đa Hãng bên dưới"
                                },
                                color = if (isXiaomi || isOppo || isVivo || isHuawei) MagicAmberLight else TextMuted,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }

            // NÚT 1-CHẠM FIX TỔNG LỰC CHO MỌI HÃNG
            Button(
                onClick = onFixUniversalAll,
                enabled = !isBusy,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("fix_universal_all_button"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MagicCyan,
                    contentColor = Color(0xFF020617)
                ),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 14.dp)
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(imageVector = Icons.Default.Bolt, contentDescription = null, modifier = Modifier.size(22.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "⚡ 1-CHẠM FIX CHẬM THÔNG BÁO TỔNG LỰC",
                            fontSize = 13.5.sp,
                            fontWeight = FontWeight.Black,
                            textAlign = TextAlign.Center
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Áp dụng toàn diện: Doze Whitelist + AppOps Chạy Ngầm + TARE 0s + Bỏ Phantom Killer",
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        color = Color(0xFF0F172A)
                    )
                }
            }

            Text(
                text = "CÁC MODULE ĐẶC TRỊ RIÊNG TỪNG HÃNG",
                color = MagicCyan,
                fontSize = 12.sp,
                fontWeight = FontWeight.Black,
                modifier = Modifier.padding(top = 4.dp)
            )

            // Module Xiaomi / HyperOS
            BrandFixCard(
                brandName = "Xiaomi / Redmi / POCO (MIUI & HyperOS)",
                desc = "Vô hiệu hóa tiến trình diệt ngầm Joyose & PowerKeeper, dỡ bỏ cơ chế ép sleep cực đoan của MIUI/HyperOS, cấp quyền Autostart tự khởi chạy cho Zalo, Messenger, Telegram...",
                isHighlighted = isXiaomi,
                buttonText = "FIX TRỄ THÔNG BÁO XIAOMI / HYPEROS",
                onClick = onFixXiaomi,
                isBusy = isBusy
            )

            // Module Oppo / Realme / OnePlus
            BrandFixCard(
                brandName = "Oppo / Realme / OnePlus (ColorOS / OxygenOS)",
                desc = "Vô hiệu hóa Athena Battery Manager trên ColorOS, tắt chế độ Deep Sleep làm ngắt kết nối FCM ban đêm, cho phép ứng dụng nhắn tin chạy nền 24/7.",
                isHighlighted = isOppo,
                buttonText = "FIX TRỄ THÔNG BÁO OPPO / REALME / ONEPLUS",
                onClick = onFixOppo,
                isBusy = isBusy
            )

            // Module Vivo / iQOO
            BrandFixCard(
                brandName = "Vivo / iQOO (OriginOS & FuntouchOS)",
                desc = "Tắt chế độ Night Idle Sleep ngắt Wi-Fi/4G khi khóa máy, gỡ bỏ hạn chế đóng băng socket ngầm của iManager, giữ kết nối đẩy Google Push 24/24.",
                isHighlighted = isVivo,
                buttonText = "FIX TRỄ THÔNG BÁO VIVO / IQOO",
                onClick = onFixVivo,
                isBusy = isBusy
            )

            // Module Huawei
            BrandFixCard(
                brandName = "Huawei (EMUI & HarmonyOS)",
                desc = "Đóng băng bộ máy ngắt ngầm PowerGenie và Smart Power Saving, tắt các rào cản thông báo nhẹ nhàng để nổ chuông và hiện biểu ngữ nổi tức thì.",
                isHighlighted = isHuawei,
                buttonText = "FIX TRỄ THÔNG BÁO HUAWEI / HARMONYOS",
                onClick = onFixHuawei,
                isBusy = isBusy
            )

            // Lưu ý thêm cho người dùng
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                border = BorderStroke(1.dp, MagicBorder)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Info, contentDescription = null, tint = MagicCyanLight, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "HƯỚNG DẪN THỦ CÔNG BỔ TRỢ TRÊN CÁC DÒNG MÁY NỘI ĐỊA",
                            color = MagicCyanLight,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                    Text(
                        text = "1. Vào Cài đặt máy > Ứng dụng > Quản lý ứng dụng > Chọn Zalo / Messenger > Bật 'Tự khởi chạy' (Autostart).\n" +
                               "2. Vào Đa nhiệm gần đây > Nhấn giữ hoặc vuốt xuống app Zalo/Messenger > Chọn biểu tượng 'Ổ Khóa' để ghim app.\n" +
                               "3. Cài đặt Pin > Tiết kiệm pin ứng dụng > Chọn 'Không giới hạn / Không hạn chế' (No restrictions).",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        lineHeight = 16.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
private fun BrandFixCard(
    brandName: String,
    desc: String,
    isHighlighted: Boolean,
    buttonText: String,
    onClick: () -> Unit,
    isBusy: Boolean
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isHighlighted) Color(0xFF131D33) else MagicSurfaceDark
        ),
        border = BorderStroke(
            1.dp,
            if (isHighlighted) MagicCyan.copy(alpha = 0.7f) else MagicBorder
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = brandName,
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.weight(1f)
                )
                if (isHighlighted) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(MagicCyan.copy(alpha = 0.25f))
                            .border(1.dp, MagicCyan.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "Máy bạn ★",
                            color = MagicCyanLight,
                            fontSize = 9.5.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }
            }

            Text(
                text = desc,
                color = TextSecondary,
                fontSize = 11.sp,
                lineHeight = 15.sp
            )

            Button(
                onClick = onClick,
                enabled = !isBusy,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("fix_brand_button_${brandName.take(5).lowercase()}"),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isHighlighted) MagicCyan else MagicSurfaceCard,
                    contentColor = if (isHighlighted) Color(0xFF020617) else MagicCyanLight
                ),
                border = if (isHighlighted) null else BorderStroke(1.dp, MagicBorder),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(imageVector = Icons.Default.Speed, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = buttonText,
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }
    }
}
