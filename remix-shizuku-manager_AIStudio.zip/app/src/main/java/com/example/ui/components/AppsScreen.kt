package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DebloatApp
import com.example.ui.theme.MagicAmber
import com.example.ui.theme.MagicAmberLight
import com.example.ui.theme.MagicBlue
import com.example.ui.theme.MagicBorder
import com.example.ui.theme.MagicCyan
import com.example.ui.theme.MagicCyanLight
import com.example.ui.theme.MagicEmerald
import com.example.ui.theme.MagicEmeraldLight
import com.example.ui.theme.MagicRose
import com.example.ui.theme.MagicSurfaceCard
import com.example.ui.theme.MagicSurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun AppsScreen(
    apps: List<DebloatApp>,
    searchQuery: String,
    selectedFilter: Int,
    isBusy: Boolean,
    onSearchChange: (String) -> Unit,
    onFilterChange: (Int) -> Unit,
    onDebloatSafeApps: () -> Unit,
    onGrantAllPermissions: () -> Unit,
    onBlockAppMarketUpdates: () -> Unit = {},
    onFixSingleAppNotificationAndPerm: (String, String) -> Unit = { _, _ -> },
    onFreezeApp: (String, Boolean) -> Unit = { _, _ -> },
    onRevokeSensitivePermissions: (String) -> Unit = {},
    onUninstallApp: (String) -> Unit,
    onRestoreApp: (String) -> Unit,
    onNavigateToUniversalFix: () -> Unit = {},
    onRefreshApps: () -> Unit = {}
) {
    var pendingLevel3Action by remember { mutableStateOf<Pair<DebloatApp, String>?>(null) }
    var pendingUninstallApp by remember { mutableStateOf<DebloatApp?>(null) }
    var showConfirmBatchDebloat by remember { mutableStateOf(false) }

    data class AppCounts(
        val userApps: Int,
        val level1: Int,
        val level2: Int,
        val level3: Int,
        val system: Int,
        val frozen: Int
    )

    val counts = remember(apps) {
        var uCount = 0
        var l1Count = 0
        var l2Count = 0
        var l3Count = 0
        var sCount = 0
        var fCount = 0
        for (a in apps) {
            if (a.isUserApp) {
                uCount++
            } else {
                sCount++
                when (a.level) {
                    1 -> l1Count++
                    2 -> l2Count++
                    3 -> l3Count++
                }
            }
            if (a.isFrozen || !a.isInstalled) {
                fCount++
            }
        }
        AppCounts(uCount, l1Count, l2Count, l3Count, sCount, fCount)
    }
    val userAppsCount = counts.userApps
    val level1Count = counts.level1
    val level2Count = counts.level2
    val level3Count = counts.level3
    val systemCount = counts.system
    val frozenCount = counts.frozen

    val filteredApps = remember(apps, searchQuery, selectedFilter) {
        apps.filter { app ->
            val matchesSearch = searchQuery.isBlank() ||
                app.name.contains(searchQuery, ignoreCase = true) ||
                app.packageName.contains(searchQuery, ignoreCase = true) ||
                app.desc.contains(searchQuery, ignoreCase = true)

            val matchesFilter = when (selectedFilter) {
                4 -> app.isUserApp // App Người Dùng
                1 -> !app.isUserApp && app.level == 1 // Rác An Toàn (Cấp 1)
                2 -> !app.isUserApp && app.level == 2 // Cân Nhắc (Cấp 2)
                5 -> !app.isUserApp && app.level == 3 // Cảnh Báo Nguy Hiểm (Cấp 3)
                3 -> app.isFrozen || !app.isInstalled // Đã gỡ / Đóng băng
                else -> true // Tất cả (Cả App Người dùng & App Hệ thống)
            }
            matchesSearch && matchesFilter
        }.sortedWith(
            compareBy<DebloatApp> { app ->
                // Ưu tiên đẩy các app người dùng đang thiếu quyền / chưa fix thông báo lên đầu danh sách
                when {
                    app.isUserApp && app.isInstalled && !app.isFrozen && (!app.isFullNotificationFixed || !app.isFullPermissionGranted) -> 0
                    !app.isUserApp && app.isInstalled && !app.isFrozen && app.level == 1 -> 1
                    app.isUserApp && app.isInstalled && !app.isFrozen -> 2
                    !app.isUserApp && app.isInstalled && !app.isFrozen && app.level == 2 -> 3
                    !app.isUserApp && app.isInstalled && !app.isFrozen && app.level == 3 -> 4
                    else -> 5
                }
            }.thenBy { it.name.lowercase() }
        )
    }

    val scrollState = rememberScrollState()
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(scrollState)
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        // Top Quick Action Buttons (Double height for comfortable 2-line display)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = { showConfirmBatchDebloat = true },
                enabled = true,
                modifier = Modifier
                    .weight(1f)
                    .defaultMinSize(minHeight = 76.dp)
                    .testTag("debloat_safe_apps_button"),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 8.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MagicRose,
                    contentColor = Color.White
                )
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(imageVector = Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = "Gỡ App Rác Cấp 1 (${level1Count})",
                        fontSize = 11.5.sp,
                        lineHeight = 15.sp,
                        fontWeight = FontWeight.Black,
                        textAlign = TextAlign.Center,
                        softWrap = true
                    )
                }
            }

            Button(
                onClick = onGrantAllPermissions,
                enabled = true,
                modifier = Modifier
                    .weight(1f)
                    .defaultMinSize(minHeight = 76.dp)
                    .testTag("grant_all_permissions_button"),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 8.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MagicEmerald,
                    contentColor = Color(0xFF020617)
                )
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(imageVector = Icons.Default.Security, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = "Cấp Full Quyền 100%",
                        fontSize = 11.5.sp,
                        lineHeight = 15.sp,
                        fontWeight = FontWeight.Black,
                        textAlign = TextAlign.Center,
                        softWrap = true
                    )
                }
            }
        }

        // Secondary Quick Action: Block App Market Updates - Double height for comfortable 2-line display
        Button(
            onClick = onBlockAppMarketUpdates,
            enabled = true,
            modifier = Modifier
                .fillMaxWidth()
                .defaultMinSize(minHeight = 76.dp)
                .testTag("block_appmarket_updates_button"),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 8.dp),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = MagicSurfaceCard,
                contentColor = MagicAmber
            ),
            border = androidx.compose.foundation.BorderStroke(1.dp, MagicAmber.copy(alpha = 0.45f))
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(imageVector = Icons.Default.Block, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "CHẶN CHỢ APP TỰ ĐỘNG CẬP NHẬT",
                        fontSize = 11.5.sp,
                        lineHeight = 15.sp,
                        fontWeight = FontWeight.Black,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "NGĂN CHỢ HONOR CÀI ĐÈ APP TIẾNG VIỆT",
                        fontSize = 10.sp,
                        color = MagicAmberLight,
                        lineHeight = 14.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        // Search bar (Không bị khoảng đệm che khuất thân chữ)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(46.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(MagicSurfaceDark)
                .border(1.dp, if (searchQuery.isNotBlank()) MagicCyan else MagicBorder, RoundedCornerShape(12.dp))
                .padding(horizontal = 12.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = null,
                    tint = if (searchQuery.isNotBlank()) MagicCyan else TextMuted,
                    modifier = Modifier.size(18.dp)
                )
                Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                    if (searchQuery.isEmpty()) {
                        Text(
                            text = "Tìm app người dùng hoặc hệ thống (VD: Zalo, Facebook, yoyo)...",
                            color = TextMuted,
                            fontSize = 12.sp,
                            maxLines = 1
                        )
                    }
                    androidx.compose.foundation.text.BasicTextField(
                        value = searchQuery,
                        onValueChange = onSearchChange,
                        singleLine = true,
                        cursorBrush = androidx.compose.ui.graphics.SolidColor(MagicCyan),
                        textStyle = androidx.compose.ui.text.TextStyle(
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                if (searchQuery.isNotBlank()) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Clear",
                        tint = TextMuted,
                        modifier = Modifier
                            .size(16.dp)
                            .clickable { onSearchChange("") }
                    )
                }
            }
        }

        // Filter Chips (Clearly separating User Apps vs Bloatware vs System Apps)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf(
                0 to "Tất cả (${apps.size})",
                4 to "👤 App Người dùng ($userAppsCount)",
                1 to "🗑 Rác An Toàn Cấp 1 ($level1Count)",
                2 to "⚠️ Cân Nhắc Cấp 2 ($level2Count)",
                5 to "🚨 Cảnh Báo Cấp 3 ($level3Count)",
                3 to "❄️ Đã gỡ / Tắt ($frozenCount)"
            ).forEach { (level, title) ->
                val isSelected = selectedFilter == level
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) MagicCyan.copy(alpha = 0.22f) else MagicSurfaceDark)
                        .border(1.dp, if (isSelected) MagicCyan else MagicBorder, RoundedCornerShape(8.dp))
                        .clickable { onFilterChange(level) }
                        .padding(horizontal = 10.dp, vertical = 7.dp)
                ) {
                    Text(
                        text = title,
                        color = if (isSelected) MagicCyanLight else TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Pagination Logic
        var currentPage by remember(searchQuery, selectedFilter) { mutableStateOf(1) }
        val itemsPerPage = 10
        val totalPages = maxOf(1, (filteredApps.size + itemsPerPage - 1) / itemsPerPage)
        if (currentPage > totalPages) {
            currentPage = 1
        }
        val pagedApps = remember(filteredApps, currentPage) {
            filteredApps.drop((currentPage - 1) * itemsPerPage).take(itemsPerPage)
        }

        // Apps List Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = "DANH SÁCH ỨNG DỤNG (${filteredApps.size} APP)",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
                IconButton(
                    onClick = onRefreshApps,
                    modifier = Modifier.size(22.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Quét lại danh sách app",
                        tint = MagicCyan,
                        modifier = Modifier.size(15.dp)
                    )
                }
            }
            Text(
                text = "Cấp 1: $level1Count • Cấp 2: $level2Count • Cấp 3: $level3Count • Trang $currentPage/$totalPages",
                color = MagicCyan,
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold
            )
        }

        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            pagedApps.forEach { app ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        when {
                            app.isFrozen || !app.isInstalled -> MagicRose.copy(alpha = 0.35f)
                            app.isUserApp && app.isFullNotificationFixed -> MagicEmerald.copy(alpha = 0.4f)
                            app.isUserApp -> MagicCyan.copy(alpha = 0.35f)
                            else -> MagicBorder
                        }
                    )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = app.name,
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                softWrap = true,
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(modifier = Modifier.width(8.dp))

                            val badgeBg = when {
                                app.isUserApp -> MagicCyan.copy(alpha = 0.2f)
                                app.level == 1 -> MagicEmerald.copy(alpha = 0.2f)
                                app.level == 2 -> MagicAmber.copy(alpha = 0.2f)
                                app.causesNotificationDelay -> MagicAmber.copy(alpha = 0.25f)
                                else -> Color(0xFF334155).copy(alpha = 0.5f)
                            }
                            val badgeText = when {
                                app.isUserApp -> "👤 App Người Dùng"
                                app.level == 1 -> "🗑 Cấp 1: Rác An Toàn"
                                app.level == 2 -> "⚠️ Cấp 2: Cân Nhắc"
                                app.causesNotificationDelay -> "⚡ Cấp 3: Gây trễ thông báo"
                                else -> "🔒 Cấp 3: Khóa cứng"
                            }
                            val badgeColor = when {
                                app.isUserApp -> MagicCyanLight
                                app.level == 1 -> MagicEmerald
                                app.level == 2 -> MagicAmber
                                app.causesNotificationDelay -> MagicAmber
                                else -> Color(0xFF94A3B8)
                            }

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(badgeBg)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = badgeText,
                                    color = badgeColor,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }

                        Text(
                            text = app.packageName,
                            color = TextMuted,
                            fontSize = 10.sp
                        )

                        Text(
                            text = app.desc,
                            color = TextSecondary,
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )

                        if (app.isUserApp && app.isInstalled && !app.isFrozen) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = if (app.isFullNotificationFixed) MagicEmerald else MagicAmber,
                                    modifier = Modifier.size(12.dp)
                                )
                                Text(
                                    text = if (app.isFullNotificationFixed) {
                                        "Đã gỡ báo nhẹ nhàng • Đủ Biểu ngữ & Full Quyền"
                                    } else {
                                        "Chưa tối ưu biểu ngữ / quyền chạy ngầm"
                                    },
                                    color = if (app.isFullNotificationFixed) MagicEmeraldLight else MagicAmber,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (app.isUserApp && app.isInstalled && !app.isFrozen) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(MagicBlue.copy(alpha = 0.22f))
                                        .border(1.dp, MagicCyan.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                                        .clickable { onFixSingleAppNotificationAndPerm(app.packageName, app.name) }
                                        .padding(horizontal = 9.dp, vertical = 5.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.NotificationsActive,
                                            contentDescription = null,
                                            tint = MagicCyanLight,
                                            modifier = Modifier.size(12.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "Cấp Full Quyền",
                                            color = MagicCyanLight,
                                            fontSize = 10.5.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }

                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(MagicAmber.copy(alpha = 0.18f))
                                        .border(1.dp, MagicAmber.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                                        .clickable { onRevokeSensitivePermissions(app.packageName) }
                                        .padding(horizontal = 9.dp, vertical = 5.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.Security,
                                            contentDescription = null,
                                            tint = MagicAmberLight,
                                            modifier = Modifier.size(12.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "Thu hồi quyền",
                                            color = MagicAmberLight,
                                            fontSize = 10.5.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }

                            // Xử lý Cấp 3 khóa cứng: Nếu là app Cấp 3 và KHÔNG gây trễ thông báo -> Khóa cứng chống gỡ
                            if (app.level == 3 && !app.causesNotificationDelay && app.isInstalled && !app.isFrozen) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color(0xFF334155).copy(alpha = 0.4f))
                                        .border(1.dp, Color(0xFF64748B).copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                        .padding(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.Lock,
                                            contentDescription = null,
                                            tint = Color(0xFF94A3B8),
                                            modifier = Modifier.size(12.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "🔒 Khóa cứng (Không gây trễ thông báo)",
                                            color = Color(0xFFCBD5E1),
                                            fontSize = 10.5.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            } else {
                                if (app.isInstalled && !app.isFrozen) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(if (app.level == 3) MagicAmber.copy(alpha = 0.15f) else MagicSurfaceCard)
                                            .border(1.dp, if (app.level == 3) MagicAmber.copy(alpha = 0.5f) else MagicBorder, RoundedCornerShape(8.dp))
                                            .clickable {
                                                if (app.level == 3) {
                                                    pendingLevel3Action = app to "FREEZE"
                                                } else {
                                                    onFreezeApp(app.packageName, true)
                                                }
                                            }
                                            .padding(horizontal = 9.dp, vertical = 5.dp)
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = Icons.Default.Block,
                                                contentDescription = null,
                                                tint = if (app.level == 3) MagicAmberLight else MagicCyanLight,
                                                modifier = Modifier.size(12.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = "❄️ Đóng băng",
                                                color = if (app.level == 3) MagicAmberLight else MagicCyanLight,
                                                fontSize = 10.5.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }

                                if (app.isFrozen || !app.isInstalled) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(MagicEmerald.copy(alpha = 0.2f))
                                            .clickable { onRestoreApp(app.packageName) }
                                            .padding(horizontal = 10.dp, vertical = 5.dp)
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = Icons.Default.Refresh,
                                                contentDescription = null,
                                                tint = MagicEmerald,
                                                modifier = Modifier.size(12.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = "Mở băng / Khôi phục",
                                                color = MagicEmerald,
                                                fontSize = 10.5.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(MagicRose.copy(alpha = if (app.level == 3) 0.28f else 0.2f))
                                            .border(1.dp, if (app.level == 3) MagicRose.copy(alpha = 0.5f) else Color.Transparent, RoundedCornerShape(8.dp))
                                            .clickable {
                                                if (app.level == 3) {
                                                    pendingLevel3Action = app to "UNINSTALL"
                                                } else {
                                                    pendingUninstallApp = app
                                                }
                                            }
                                            .padding(horizontal = 10.dp, vertical = 5.dp)
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = Icons.Default.Delete,
                                                contentDescription = null,
                                                tint = MagicRose,
                                                modifier = Modifier.size(12.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = if (app.level == 3) "🚨 Gỡ Cấp 3 (Gây trễ FCM)" else if (app.isUserApp) "Gỡ cài đặt" else "Vô hiệu hóa / Gỡ",
                                                color = MagicRose,
                                                fontSize = 10.5.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Pagination Controls
        if (totalPages > 1) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = { if (currentPage > 1) currentPage-- },
                    enabled = currentPage > 1,
                    modifier = Modifier.height(38.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MagicSurfaceDark,
                        contentColor = MagicCyanLight
                    ),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MagicBorder)
                ) {
                    Text(text = "← Trang trước", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Text(
                    text = "$currentPage / $totalPages",
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Black
                )

                Button(
                    onClick = { if (currentPage < totalPages) currentPage++ },
                    enabled = currentPage < totalPages,
                    modifier = Modifier.height(38.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MagicSurfaceDark,
                        contentColor = MagicCyanLight
                    ),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MagicBorder)
                ) {
                    Text(text = "Trang sau →", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Dòng ghi chú nhỏ tối ưu cho Honor + Nút điều hướng tới trang chức năng ngầm đa hãng
        HonorOptimizationDisclaimerFooter(
            onNavigateToUniversalFix = onNavigateToUniversalFix
        )
    }

    // Modal Cảnh Báo Nguy Hiểm Cấp 3 (Cho phép gỡ / đóng băng an toàn bằng Direct ADB nhưng bắt buộc cảnh báo)
    if (pendingLevel3Action != null) {
        val (targetApp, actionType) = pendingLevel3Action!!
        val isFreeze = actionType == "FREEZE"
        AlertDialog(
            onDismissRequest = { pendingLevel3Action = null },
            shape = RoundedCornerShape(16.dp),
            containerColor = MagicSurfaceDark,
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = null,
                        tint = MagicRose,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "CẢNH BÁO NGUY HIỂM CẤP 3",
                        color = MagicRose,
                        fontSize = 14.5.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Gói ứng dụng: ${targetApp.name} (${targetApp.packageName})",
                        color = Color.White,
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Chi tiết: ${targetApp.desc}",
                        color = TextSecondary,
                        fontSize = 11.5.sp
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(MagicAmber.copy(alpha = 0.18f))
                            .border(1.dp, MagicAmber.copy(alpha = 0.45f), RoundedCornerShape(8.dp))
                            .padding(8.dp)
                    ) {
                        Text(
                            text = "⚡ ĐẶC QUYỀN GỠ CẤP 3: Ứng dụng hệ thống này có ảnh hưởng và gây chậm/trễ thông báo (chạy ngầm can thiệp tiến trình, quản lý pin hoặc mạng FCM). Bạn có thể gỡ hoặc đóng băng an toàn để nhận thông báo tức thì.",
                            color = MagicAmberLight,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(MagicEmerald.copy(alpha = 0.15f))
                            .border(1.dp, MagicEmerald.copy(alpha = 0.35f), RoundedCornerShape(8.dp))
                            .padding(8.dp)
                    ) {
                        Text(
                            text = "✅ ĐẢM BẢO AN TOÀN: Thao tác này qua Direct ADB KHÔNG làm hỏng ROM máy, KHÔNG gây treo logo (Bootloop).",
                            color = MagicEmeraldLight,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(MagicRose.copy(alpha = 0.15f))
                            .border(1.dp, MagicRose.copy(alpha = 0.35f), RoundedCornerShape(8.dp))
                            .padding(8.dp)
                    ) {
                        Text(
                            text = "⚠️ LƯU Ý RỦI RO: Đây là dịch vụ hệ thống chuyên sâu. Khi ${if (isFreeze) "đóng băng" else "gỡ bỏ"}, các tính năng liên quan có thể ngừng hoạt động cho đến khi bạn bấm 'Mở băng / Khôi phục'. Thao tác này được thực hiện tức thì qua Direct ADB.",
                            color = MagicRose,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val pkg = targetApp.packageName
                        pendingLevel3Action = null
                        if (isFreeze) {
                            onFreezeApp(pkg, true)
                        } else {
                            onUninstallApp(pkg)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MagicRose),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = if (isFreeze) "Tôi hiểu rủi ro, Vẫn Đóng băng" else "Tôi hiểu rủi ro, Vẫn Gỡ bỏ",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { pendingLevel3Action = null },
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(text = "Hủy bỏ", color = TextSecondary, fontSize = 11.5.sp)
                }
            }
        )
    }

    if (showConfirmBatchDebloat) {
        AlertDialog(
            onDismissRequest = { showConfirmBatchDebloat = false },
            containerColor = MagicSurfaceDark,
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Delete, contentDescription = null, tint = MagicRose)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = "Xác nhận dọn rác Cấp 1", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Bạn có chắc chắn muốn gỡ sạch $level1Count ứng dụng rác Cấp 1?",
                        color = Color.White,
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "• Toàn bộ app Cấp 1 đã được kiểm định an toàn 100%, không ảnh hưởng bất kỳ chức năng hay tính ổn định nào của ROM.",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                    Text(
                        text = "• Sau khi gỡ, bạn có thể dễ dàng khôi phục lại bất kỳ app nào trong tab 'Đã gỡ / Đóng băng'.",
                        color = MagicEmeraldLight,
                        fontSize = 11.sp
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showConfirmBatchDebloat = false
                        onDebloatSafeApps()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MagicRose),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(text = "Đồng ý Gỡ ($level1Count app)", color = Color.White, fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { showConfirmBatchDebloat = false },
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(text = "Hủy bỏ", color = TextSecondary, fontSize = 11.5.sp)
                }
            }
        )
    }

    pendingUninstallApp?.let { targetApp ->
        AlertDialog(
            onDismissRequest = { pendingUninstallApp = null },
            containerColor = MagicSurfaceDark,
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Warning, contentDescription = null, tint = MagicAmber)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (targetApp.isUserApp) "Xác nhận gỡ ứng dụng" else "Xác nhận gỡ app hệ thống",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = targetApp.name,
                        color = Color.White,
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = targetApp.packageName,
                        color = MagicCyanLight,
                        fontSize = 10.5.sp
                    )
                    Text(
                        text = when {
                            targetApp.isUserApp -> "Đây là ứng dụng bạn đã cài đặt vào máy. Bạn có chắc chắn muốn gỡ cài đặt ứng dụng này không?"
                            targetApp.level == 1 -> "Ứng dụng rác Cấp 1 (An toàn tuyệt đối). Gỡ bỏ sẽ giúp máy nhẹ hơn, giải phóng RAM và tiết kiệm pin."
                            targetApp.level == 2 -> "Ứng dụng hệ thống Cấp 2 (Cân nhắc). Bạn có thể khôi phục lại bất kỳ lúc nào nếu có nhu cầu sử dụng."
                            else -> targetApp.desc
                        },
                        color = TextSecondary,
                        fontSize = 11.5.sp
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val pkg = targetApp.packageName
                        pendingUninstallApp = null
                        onUninstallApp(pkg)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MagicRose),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(text = "Đồng ý Gỡ", color = Color.White, fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { pendingUninstallApp = null },
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(text = "Hủy bỏ", color = TextSecondary, fontSize = 11.5.sp)
                }
            }
        )
    }
}
