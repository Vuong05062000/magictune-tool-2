package com.example.ui.components



import android.content.Context

import android.net.Uri

import android.util.Base64

import androidx.activity.compose.rememberLauncherForActivityResult

import androidx.activity.result.PickVisualMediaRequest

import androidx.activity.result.contract.ActivityResultContracts

import androidx.compose.foundation.BorderStroke

import androidx.compose.foundation.background

import androidx.compose.foundation.border

import androidx.compose.foundation.clickable

import androidx.compose.foundation.horizontalScroll

import androidx.compose.foundation.layout.*

import androidx.compose.foundation.lazy.LazyColumn

import androidx.compose.foundation.lazy.items

import androidx.compose.foundation.lazy.rememberLazyListState

import androidx.compose.foundation.rememberScrollState

import androidx.compose.foundation.shape.CircleShape

import androidx.compose.foundation.shape.RoundedCornerShape

import androidx.compose.material.icons.Icons

import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.HorizontalDivider

import androidx.compose.material3.*

import androidx.compose.runtime.*

import androidx.compose.ui.Alignment

import androidx.compose.ui.Modifier

import androidx.compose.ui.draw.clip

import androidx.compose.ui.graphics.Brush

import androidx.compose.ui.graphics.Color

import androidx.compose.ui.platform.LocalContext

import androidx.compose.ui.text.font.FontWeight

import androidx.compose.ui.unit.dp

import androidx.compose.ui.unit.sp

import com.example.core.license.LicenseManager

import com.example.ui.theme.*

import kotlinx.coroutines.Dispatchers

import kotlinx.coroutines.launch

import kotlinx.coroutines.withContext

import java.net.HttpURLConnection

import java.net.URL



data class ChatMessage(

    val id: String = System.currentTimeMillis().toString() + "_" + (100..999).random(),

    val sender: String, // "user" hoặc "support"

    val text: String,

    val timestamp: Long = System.currentTimeMillis(),

    val translatedText: String? = null,

    val isTranslating: Boolean = false

)



/**

 * Kiểm tra xem tin nhắn có phải là Tiếng Việt hay không.

 * - Nếu là Tiếng Việt (có dấu Tiếng Việt hoặc các từ khóa Tiếng Việt phổ biến, không chứa chữ tượng hình ngoại quốc): trả về true -> ẩn nút Dịch.

 * - Nếu là ngoại ngữ (Tiếng Trung, Anh, Hàn, Nhật, Nga...): trả về false -> hiện nút "🌐 Dịch sang Tiếng Việt".

 */

private fun isVietnameseMessage(text: String): Boolean {

    val trimmed = text.trim()

    if (trimmed.isBlank()) return true

    if (trimmed.startsWith("[Đã gửi hình ảnh")) return true



    // Nếu chứa chữ Trung / Nhật / Hàn / Thái / Nga thì chắc chắn cần hiện nút dịch

    val foreignScriptRegex = Regex("[\\u4E00-\\u9FFF\\u3040-\\u30FF\\uAC00-\\uD7AF\\u0400-\\u04FF\\u0E00-\\u0E7F]")

    if (foreignScriptRegex.containsMatchIn(trimmed)) {

        return false

    }



    // Kiểm tra các ký tự nguyên âm có dấu đặc trưng của Tiếng Việt

    val vnDiacriticsRegex = Regex("[àáảãạăằắẳẵặâầấẩẫậèéẻẽẹêềếểễệìíỉĩịòóỏõọôồốổỗộơờớởỡợùúủũụưừứửữựỳýỷỹỵđÀÁẢÃẠĂẰẮẲẴẶÂẦẤẨẪẬÈÉẺẼẸÊỀẾỂỄỆÌÍỈĨỊÒÓỎÕỌÔỒỐỔỖỘƠỜỚỞỠỢÙÚỦŨỤƯỪỨỬỮỰỲÝỶỸỴĐ]")

    if (vnDiacriticsRegex.containsMatchIn(trimmed)) {

        return true

    }



    // Trường hợp người dùng gõ Tiếng Việt không dấu

    val lower = " ${trimmed.lowercase()} "

    val vnUnaccentedKeywords = listOf(

        " xin chao ", " chao ", " cam on ", " huong dan ", " ung dung ", " thiet bi ",

        " tai khoan ", " chuyen khoan ", " cai dat ", " thong bao ", " man hinh ",

        " khoanh tron ", " dich ", " may in ", " ngan hang ", " lam sao ", " cach dung ",

        " giup minh ", " nang cap ", " kich hoat ", " khong duoc ", " bi loi ", " cua minh ",

        " cho hoi ", " bao nhieu ", " tien ", " quyen ", " ket noi ", " ma 6 so "

    )

    if (vnUnaccentedKeywords.any { lower.contains(it) }) {

        return true

    }



    return false

}



@Composable

fun ChatSupportScreen(

    onNavigateBack: () -> Unit

) {

    val context = LocalContext.current

    val coroutineScope = rememberCoroutineScope()

    val listState = rememberLazyListState()



    var inputMessage by remember { mutableStateOf("") }

    val messagesList = remember {

        mutableStateListOf(

            ChatMessage(

                sender = "support",

                text = "Xin chào! Tôi là Trợ lý hỗ trợ trực tuyến của ứng dụng MagicTune.\n\n" +

                    "• Bạn có thể hỏi tôi cách sử dụng bất kỳ tính năng nào trong ứng dụng (Khoanh tròn tìm kiếm, Cuộn & Dịch màn hình Taobao/1688, Sửa lỗi trễ thông báo Zalo/Facebook, Ẩn nhà phát triển cho app Ngân hàng, Kết nối mã 6 số, Máy in K80, hoặc quy định Gói Pro Thiết Bị & Pro Tài Khoản).\n" +

                    "• Nhấn biểu tượng hình ảnh 🖼️ bên dưới để gửi ảnh chụp biên lai (bill) chuyển khoản — hệ thống sẽ tự động kiểm duyệt và kích hoạt quyền Pro cho bạn ngay lập tức!\n" +

                    "• 📌 **LƯU Ý BẢO LƯU PRO VĨNH VIỄN 100%:** Mỗi thiết bị được gắn cố định một Key duy nhất từ Admin/AI. Bạn hãy sao chép lưu giữ Key này hoặc ĐĂNG NHẬP TÀI KHOẢN để được tự động bảo lưu vĩnh viễn trên đám mây. Về sau nếu lỡ cài lại máy hay không thấy Pro, bạn chỉ cần đăng nhập tài khoản là 100% được tự động khôi phục bản Pro!"

            )

        )

    }

    var isAiGenerating by remember { mutableStateOf(false) }



    val imagePickerLauncher = rememberLauncherForActivityResult(

        contract = ActivityResultContracts.PickVisualMedia()

    ) { uri: Uri? ->

        if (uri != null) {

            messagesList.add(ChatMessage(sender = "user", text = "[Đã gửi hình ảnh biên lai / bill chuyển khoản]"))

            isAiGenerating = true

            coroutineScope.launch {

                val analysisResult = analyzeBillAutomatically(context, uri)

                isAiGenerating = false

                messagesList.add(ChatMessage(sender = "support", text = analysisResult))

            }

        }

    }



    // Tự động cuộn xuống tin nhắn mới nhất

    LaunchedEffect(messagesList.size) {

        if (messagesList.isNotEmpty()) {

            listState.animateScrollToItem(messagesList.size - 1)

        }

    }



    Column(

        modifier = Modifier

            .fillMaxSize()

            .background(MagicDarkBackground)

    ) {

        // Top Bar

        Row(

            modifier = Modifier

                .fillMaxWidth()

                .background(MagicSurfaceCard)

                .border(BorderStroke(1.dp, MagicBorder))

                .padding(horizontal = 16.dp, vertical = 12.dp),

            horizontalArrangement = Arrangement.SpaceBetween,

            verticalAlignment = Alignment.CenterVertically

        ) {

            Row(

                verticalAlignment = Alignment.CenterVertically,

                horizontalArrangement = Arrangement.spacedBy(10.dp)

            ) {

                IconButton(onClick = onNavigateBack) {

                    Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Quay lại", tint = Color.White)

                }

                Column {

                    Row(

                        verticalAlignment = Alignment.CenterVertically,

                        horizontalArrangement = Arrangement.spacedBy(6.dp)

                    ) {

                        Text(

                            text = "💬 Trợ Lý Hỗ Trợ & Duyệt Pro",

                            color = Color.White,

                            fontSize = 14.sp,

                            fontWeight = FontWeight.Black

                        )

                        Box(

                            modifier = Modifier

                                .size(8.dp)

                                .clip(CircleShape)

                                .background(MagicEmerald)

                        )

                    }

                    Text(

                        text = "Hướng dẫn tính năng 24/7 & Tự động duyệt bill nâng cấp Pro",

                        color = MagicCyanLight,

                        fontSize = 10.sp

                    )

                }

            }



            // Nút xóa lịch sử chat

            IconButton(onClick = {

                messagesList.clear()

                messagesList.add(

                    ChatMessage(

                        sender = "support",

                        text = "Đã làm mới cuộc hội thoại. Bạn cần hướng dẫn tính năng nào trong ứng dụng hoặc gửi ảnh bill chuyển khoản để kích hoạt Pro không?"

                    )

                )

            }) {

                Icon(imageVector = Icons.Default.Refresh, contentDescription = "Làm mới", tint = Color(0xFF94A3B8))

            }

        }



        // Thanh gợi ý câu hỏi nhanh giúp người dùng bấm 1 chạm để hỏi đúng trọng tâm

        val quickQuestions = remember {

            listOf(

                "🔑 Cách lưu Key & khôi phục Pro 100% khi cài lại máy?",

                "🌐 Cách dùng Cuộn & Dịch Taobao/1688?",

                "👑 Khác nhau giữa Pro Máy & Pro Tài Khoản?",

                "🏦 Sửa lỗi MB Bank báo ứng dụng rủi ro?",

                "🔔 Sửa lỗi trễ thông báo Zalo & Facebook?",

                "🔗 Cách kết nối Gỡ lỗi không dây Mã 6 số?"

            )

        }

        Row(

            modifier = Modifier

                .fillMaxWidth()

                .background(MagicSurfaceDark)

                .horizontalScroll(rememberScrollState())

                .padding(horizontal = 12.dp, vertical = 8.dp),

            horizontalArrangement = Arrangement.spacedBy(8.dp)

        ) {

            quickQuestions.forEach { q ->

                Surface(

                    modifier = Modifier

                        .clip(RoundedCornerShape(16.dp))

                        .clickable(enabled = !isAiGenerating) {

                            messagesList.add(ChatMessage(sender = "user", text = q))

                            isAiGenerating = true

                            coroutineScope.launch {

                                val reply = fetchSupportResponse(context, q, messagesList.toList())

                                isAiGenerating = false

                                messagesList.add(ChatMessage(sender = "support", text = reply))

                            }

                        },

                    color = MagicSurfaceCard,

                    border = BorderStroke(1.dp, MagicCyan.copy(alpha = 0.35f)),

                    shape = RoundedCornerShape(16.dp)

                ) {

                    Text(

                        text = q,

                        color = MagicCyanLight,

                        fontSize = 10.5.sp,

                        fontWeight = FontWeight.SemiBold,

                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)

                    )

                }

            }

        }



        // Danh sách tin nhắn

        LazyColumn(

            state = listState,

            modifier = Modifier

                .weight(1f)

                .fillMaxWidth()

                .padding(horizontal = 16.dp),

            verticalArrangement = Arrangement.spacedBy(12.dp),

            contentPadding = PaddingValues(vertical = 16.dp)

        ) {

            items(messagesList, key = { it.id }) { msg ->

                ChatBubbleItem(

                    message = msg,

                    onTranslateMessage = {

                        coroutineScope.launch {

                            translateForeignMessageToVietnamese(context, msg, messagesList)

                        }

                    }

                )

            }



            if (isAiGenerating) {

                item {

                    Row(

                        modifier = Modifier.fillMaxWidth(),

                        horizontalArrangement = Arrangement.Start,

                        verticalAlignment = Alignment.CenterVertically

                    ) {

                        Box(

                            modifier = Modifier

                                .clip(RoundedCornerShape(12.dp))

                                .background(MagicSurfaceCard)

                                .border(1.dp, MagicBorder, RoundedCornerShape(12.dp))

                                .padding(12.dp)

                        ) {

                            Row(

                                verticalAlignment = Alignment.CenterVertically,

                                horizontalArrangement = Arrangement.spacedBy(8.dp)

                            ) {

                                CircularProgressIndicator(

                                    color = MagicCyan,

                                    strokeWidth = 2.dp,

                                    modifier = Modifier.size(16.dp)

                                )

                                Text(

                                    text = "Đang xử lý yêu cầu & kiểm tra thông tin...",

                                    color = Color(0xFF94A3B8),

                                    fontSize = 11.5.sp

                                )

                            }

                        }

                    }

                }

            }

        }



        // Input Bar & Gửi tin nhắn / Gửi ảnh bill

        Row(

            modifier = Modifier

                .fillMaxWidth()

                .background(MagicSurfaceCard)

                .border(BorderStroke(1.dp, MagicBorder))

                .padding(12.dp),

            verticalAlignment = Alignment.CenterVertically,

            horizontalArrangement = Arrangement.spacedBy(8.dp)

        ) {

            // Nút đính kèm ảnh bill chuyển khoản

            IconButton(

                onClick = {

                    imagePickerLauncher.launch(

                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)

                    )

                },

                modifier = Modifier.size(42.dp)

            ) {

                Icon(

                    imageVector = Icons.Default.Image,

                    contentDescription = "Gửi bill chuyển khoản",

                    tint = MagicCyan

                )

            }



            OutlinedTextField(

                value = inputMessage,

                onValueChange = { inputMessage = it },

                placeholder = { Text("Hỏi cách dùng tính năng hoặc gửi ảnh bill...", color = TextMuted, fontSize = 12.sp) },

                modifier = Modifier

                    .weight(1f)

                    .heightIn(min = 48.dp, max = 120.dp),

                shape = RoundedCornerShape(24.dp),

                colors = OutlinedTextFieldDefaults.colors(

                    focusedBorderColor = MagicCyan,

                    unfocusedBorderColor = MagicBorder,

                    focusedTextColor = Color.White,

                    unfocusedTextColor = Color.White

                )

            )



            Button(

                onClick = {

                    val textToSend = inputMessage.trim()

                    if (textToSend.isNotBlank() && !isAiGenerating) {

                        inputMessage = ""

                        messagesList.add(ChatMessage(sender = "user", text = textToSend))



                        isAiGenerating = true

                        coroutineScope.launch {

                            val aiReply = fetchSupportResponse(context, textToSend, messagesList.toList())

                            isAiGenerating = false

                            messagesList.add(ChatMessage(sender = "support", text = aiReply))

                        }

                    }

                },

                modifier = Modifier.size(48.dp),

                shape = CircleShape,

                colors = ButtonDefaults.buttonColors(containerColor = MagicCyan),

                contentPadding = PaddingValues(0.dp)

            ) {

                Icon(

                    imageVector = Icons.AutoMirrored.Filled.Send,

                    contentDescription = "Gửi",

                    tint = Color(0xFF020617),

                    modifier = Modifier.size(20.dp)

                )

            }

        }

    }

}



@Composable

fun ChatBubbleItem(

    message: ChatMessage,

    onTranslateMessage: () -> Unit

) {

    val isUser = message.sender == "user"

    val showTranslateButton = remember(message.text) {

        !isVietnameseMessage(message.text)

    }



    Column(

        modifier = Modifier.fillMaxWidth(),

        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start

    ) {

        Row(

            horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start,

            verticalAlignment = Alignment.Bottom,

            modifier = Modifier.fillMaxWidth()

        ) {

            if (!isUser) {

                Box(

                    modifier = Modifier

                        .size(32.dp)

                        .clip(CircleShape)

                        .background(Brush.linearGradient(listOf(MagicPurple, MagicCyan))),

                    contentAlignment = Alignment.Center

                ) {

                    Icon(imageVector = Icons.Default.SmartToy, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))

                }

                Spacer(modifier = Modifier.width(8.dp))

            }



            Box(

                modifier = Modifier

                    .widthIn(max = 290.dp)

                    .clip(

                        RoundedCornerShape(

                            topStart = 16.dp,

                            topEnd = 16.dp,

                            bottomStart = if (isUser) 16.dp else 4.dp,

                            bottomEnd = if (isUser) 4.dp else 16.dp

                        )

                    )

                    .background(if (isUser) MagicCyan.copy(alpha = 0.2f) else MagicSurfaceCard)

                    .border(

                        1.dp,

                        if (isUser) MagicCyan.copy(alpha = 0.5f) else MagicBorder,

                        RoundedCornerShape(

                            topStart = 16.dp,

                            topEnd = 16.dp,

                            bottomStart = if (isUser) 16.dp else 4.dp,

                            bottomEnd = if (isUser) 4.dp else 16.dp

                        )

                    )

                    .padding(12.dp)

            ) {

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {

                    Text(

                        text = message.text,

                        color = Color.White,

                        fontSize = 13.sp,

                        lineHeight = 18.sp

                    )



                    // Hiển thị kết quả dịch (nếu có)

                    if (!message.translatedText.isNullOrBlank()) {

                        HorizontalDivider(color = MagicBorder, thickness = 0.5.dp)

                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {

                            Row(

                                verticalAlignment = Alignment.CenterVertically,

                                horizontalArrangement = Arrangement.spacedBy(4.dp)

                            ) {

                                Icon(

                                    imageVector = Icons.Default.Translate,

                                    contentDescription = null,

                                    tint = MagicEmerald,

                                    modifier = Modifier.size(12.dp)

                                )

                                Text(

                                    text = "Bản dịch Tiếng Việt:",

                                    color = MagicEmerald,

                                    fontSize = 10.sp,

                                    fontWeight = FontWeight.Bold

                                )

                            }

                            Text(

                                text = message.translatedText,

                                color = Color(0xFFA7F3D0),

                                fontSize = 12.sp,

                                lineHeight = 16.sp

                            )

                        }

                    }



                    // Chỉ hiện nút Dịch đối với tin nhắn KHÔNG phải Tiếng Việt

                    if (showTranslateButton) {

                        Row(

                            modifier = Modifier

                                .fillMaxWidth()

                                .padding(top = 4.dp),

                            horizontalArrangement = Arrangement.End,

                            verticalAlignment = Alignment.CenterVertically

                        ) {

                            Surface(

                                modifier = Modifier

                                    .clip(RoundedCornerShape(8.dp))

                                    .clickable(enabled = !message.isTranslating, onClick = onTranslateMessage),

                                color = Color(0xFF1E293B),

                                border = BorderStroke(0.5.dp, MagicPurple.copy(alpha = 0.5f))

                            ) {

                                Row(

                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),

                                    verticalAlignment = Alignment.CenterVertically,

                                    horizontalArrangement = Arrangement.spacedBy(4.dp)

                                ) {

                                    Text(

                                        text = if (message.isTranslating) "⏳ Đang dịch..." else "🌐 Dịch sang Tiếng Việt",

                                        color = MagicPurpleLight,

                                        fontSize = 10.sp,

                                        fontWeight = FontWeight.Bold

                                    )

                                }

                            }

                        }

                    }

                }

            }

        }

    }

}



/**

 * Phân tích ảnh bill chuyển khoản nghiêm ngặt 5 lớp (Chống Bill Giả Cầy / Photoshop / Chỉnh sửa ফরensic + Chống dùng lại Bill cũ SHA-256 + Kiểm tra Đăng nhập cho Pro Tài Khoản)

 * và tự động cấp Pro thật sự thay cho Admin (kèm ghi nhật ký kiểm toán chi tiết cho Admin).

 */

private suspend fun analyzeBillAutomatically(context: Context, imageUri: Uri): String {

    return withContext(Dispatchers.IO) {

        val deviceId = LicenseManager.getDeviceId(context).uppercase()

        val cleanShortDeviceId = LicenseManager.normalizeDeviceIdForMatch(deviceId)

        try {

            val inputStream = context.contentResolver.openInputStream(imageUri)

            val bytes = inputStream?.readBytes() ?: return@withContext "Không thể đọc tệp ảnh biên lai."

            val billImageSha256 = LicenseManager.computeByteArraySha256(bytes)

            val base64 = Base64.encodeToString(bytes, Base64.NO_WRAP)



            val isAlreadyDevicePro = LicenseManager.isDeviceProOnly(context)

            val currentUser = com.example.core.auth.FirebaseAuthManager.getCurrentUser()

            val isLoggedIn = currentUser != null && !currentUser.uid.isBlank()



            // LỚP 1: NẾU MÁY ĐANG LÀ PRO THIẾT BỊ MUỐN NÂNG LÊN PRO TÀI KHOẢN MÀ CHƯA ĐĂNG NHẬP TÀI KHOẢN THẬT -> CHẶN ĐỂ TRÁNH CẤP PRO TÀI KHOẢN MỒ CÔI

            if (isAlreadyDevicePro && !isLoggedIn) {

                val loginReqMsg = "🔒 CẦN ĐĂNG NHẬP TÀI KHOẢN TRƯỚC KHI NÂNG CẤP LÊN PRO TÀI KHOẢN!\n\n" +

                    "• Hệ thống nhận thấy máy của bạn ($deviceId) đang ở gói **Pro Thiết Bị** và bạn vừa gửi biên lai để nâng cấp lên **Pro Tài Khoản**.\n" +

                    "• Tuy nhiên, bạn **chưa đăng nhập tài khoản** trên ứng dụng. Để tránh trường hợp kích hoạt xong nhưng không có tài khoản Email thật để gắn quyền Pro Tài Khoản, bạn vui lòng:\n" +

                    "  1. Quay lại bấm vào tab **🔐 Đăng Nhập** trên thanh công cụ để đăng nhập (hoặc đăng ký) tài khoản.\n" +

                    "  2. Sau khi đăng nhập xong, quay lại khung chat này và gửi lại ảnh biên lai — hệ thống sẽ tự động gắn quyền **👑 PRO TÀI KHOẢN** vào đúng tài khoản của bạn ngay lập tức!"

                LicenseManager.logAiProChatInteraction(

                    context = context,

                    userMessage = "🖼️ [Gửi bill nâng cấp Pro TK khi chưa đăng nhập] Thiết bị: $deviceId",

                    aiReply = loginReqMsg,

                    eventType = "BILL_REJECTED",

                    proGranted = false,

                    grantedTier = "NONE",

                    targetDeviceId = deviceId,

                    billImageHash = billImageSha256,

                    forensicVerdict = "Yêu cầu đăng nhập tài khoản thật trước khi nâng cấp từ Pro Máy lên Pro Tài Khoản"

                )

                return@withContext loginReqMsg

            }



            // LỚP 2: KIỂM TRA SƠ BỘ CHỮ KÝ ẢNH SHA-256 TRÊN FIREBASE (CHỐNG REPLAY / GỬI LẠI ẢNH BILL CŨ HOẶC BILL CỦA MÁY KHÁC)

            val (isDuplicateHashEarly, duplicateReasonEarly) = LicenseManager.checkBillReplayOrDuplicateInCloud(

                billSha256 = billImageSha256,

                bankTransCode = "",

                currentDeviceId = deviceId,

                isRequestingAccountUpgrade = isAlreadyDevicePro

            )

            if (isDuplicateHashEarly) {

                val replayMsg = "🚨 CẢNH BÁO CHỐNG GIAN LẬN (PHÁT HIỆN BIÊN LAI ĐÃ QUA SỬ DỤNG):\n\n" +

                    "• $duplicateReasonEarly\n" +

                    "• Mã băm ảnh (SHA-256): `${billImageSha256.take(16)}...`\n" +

                    "🔒 Trạng thái: TỪ CHỐI KÍCH HOẠT PRO & ĐÃ GHI NHẬT KÝ BÁO CÁO ADMIN."

                LicenseManager.logAiProChatInteraction(

                    context = context,

                    userMessage = "🖼️ [Cảnh báo: Gửi lại ảnh bill cũ / trùng SHA-256] Thiết bị: $deviceId",

                    aiReply = replayMsg,

                    eventType = "REUSED_BILL_BLOCKED",

                    proGranted = false,

                    grantedTier = "NONE",

                    targetDeviceId = deviceId,

                    billImageHash = billImageSha256,

                    forensicVerdict = "Trùng chữ ký tệp ảnh SHA-256: $duplicateReasonEarly"

                )

                return@withContext replayMsg

            }



            val bankName = LicenseManager.getPaymentBankName(context)

            val bankAccount = LicenseManager.getPaymentAccountNumber(context)

            val bankHolder = LicenseManager.getPaymentAccountHolder(context)

            val tailDigits = if (bankAccount.length >= 4) bankAccount.takeLast(4) else bankAccount



            val apiKey = LicenseManager.getLoadBalancedGroqApiKey(context).ifBlank {

                try { com.example.BuildConfig.GROQ_API_KEY } catch (_: Throwable) { "" }

            }

            if (apiKey.isBlank() || apiKey == "GROQ_API_KEY_DEFAULT_VALUE") {

                return@withContext "Hệ thống kiểm duyệt tự động đang bảo trì khóa kết nối. Bạn vui lòng chờ Admin kiểm tra hoặc thử lại sau giây lát nhé!"

            }



            val url = URL("https://api.groq.com/openai/v1/chat/completions")

            val conn = (url.openConnection() as HttpURLConnection).apply {

                requestMethod = "POST"

                doOutput = true

                doInput = true

                connectTimeout = 15_000

                readTimeout = 25_000

                setRequestProperty("Authorization", "Bearer $apiKey")

                setRequestProperty("Content-Type", "application/json; charset=UTF-8")

            }



            val prompt = """

                Bạn là Hệ Thống Giám Định Hóa Đơn Ngân Hàng & Chống Bill Giả (Forensic Receipt Inspector) của ứng dụng MagicTune.

                Tuyệt đối KHÔNG nhắc đến tên bất kỳ mô hình AI nào trong câu trả lời.

                Thông tin tài khoản nhận tiền chuẩn của Admin:

                - Ngân hàng nhận: $bankName

                - Số tài khoản nhận: $bankAccount (4 số cuối: $tailDigits)

                - Chủ tài khoản nhận: $bankHolder

                - Mã thiết bị bắt buộc trong nội dung CK: $deviceId (hoặc chứa chuỗi định danh: $cleanShortDeviceId)



                NHIỆM VỤ BẮT BUỘC — KIỂM TRA 4 LỚP CHỐNG BILL GIẢ CẦY / ĐÃ CHỈNH SỬA PHOTOSHOP / WEB TẠO BILL ẢO:

                LỚP 1 — GIÁM ĐỊNH KỸ THUẬT SỐ PHÁT HIỆN BILL GIẢ / CHỈNH SỬA (FORENSIC TAMPERING CHECK):

                - Quan sát thật kỹ Phông chữ (Font family), Độ đậm nhạt (Font weight), Khoảng cách ký tự (Kerning), và Đường căn dòng (Baseline alignment) tại 4 vị trí nhạy cảm: [Số tiền], [Số tài khoản nhận], [Tên người nhận], và [Nội dung chuyển khoản].

                - Nếu phát hiện bất kỳ dấu hiệu chỉnh sửa nào sau đây:

                  + Phông chữ của số tiền, STK hoặc nội dung CK lệch lạc, khác kiểu chữ/màu chữ so với các dòng chữ chuẩn của app ngân hàng.

                  + Vùng nền (background) xung quanh con số tiền hoặc nội dung CK bị mờ nhòe, có vệt xóa/đè màu (clone stamp/patch), độ nét pixel không đồng nhất với phần còn lại của bức ảnh.

                  + Giao diện biên lai nhìn giả tạo (từ web/tool tạo bill giả), có watermark lạ, sai lệch bố cục chuẩn của ngân hàng Việt Nam (MBBank, Vietcombank, Techcombank, BIDV, VietinBank, ACB, Agribank, VPBank, TPBank, MoMo...), hoặc không có Mã giao dịch / Thời gian giao dịch hợp lý.

                  -> BẮT BUỘC mở đầu câu trả lời bằng đúng từ khóa: `FAKE_BILL_DETECTED:` kèm chỉ rõ chi tiết vị trí nghi vấn bị chỉnh sửa/làm giả!



                LỚP 2 — KIỂM TRA TRẠNG THÁI GIAO DỊCH HOÀN TẤT:

                - Đây PHẢI là biên lai báo GIAO DỊCH THÀNH CÔNG (Chuyển tiền thành công / Thanh toán thành công).

                - Nếu chỉ là màn hình "Xác nhận giao dịch", "Nhập mã OTP", "Đang chờ xử lý", hoặc ảnh chụp màn hình mã QR chưa thanh toán -> Từ chối ngay (`INVALID:`).



                LỚP 3 — ĐỐI CHIẾU CHÍNH XÁC NGƯỜI NHẬN & NỘI DUNG MÃ MÁY (ĐIỀU KIỆN VÀ - AND):

                - Người nhận trên biên lai PHẢI khớp với tài khoản Admin: Có số tài khoản `$bankAccount` (hoặc 4 số đuôi `$tailDigits`) VÀ tên người nhận khớp `$bankHolder` (có chữ `VUONG`).

                - Nội dung chuyển khoản (Lời nhắn) trên biên lai PHẢI chứa mã thiết bị `$deviceId` hoặc `$cleanShortDeviceId` (hoặc mã `MT-...` hợp lệ). Nếu nội dung chuyển khoản trống hoặc không có mã thiết bị -> Từ chối (`INVALID: Biên lai thiếu nội dung mã thiết bị $deviceId`).



                LỚP 4 — ĐỐI CHIẾU SỐ TIỀN & TRÍCH XUẤT MÃ GIAO DỊCH NGÂN HÀNG (`TRANS_ID`):

                - Số tiền chuyển khoản PHẢI từ 50.000đ (50,000 VND) trở lên.

                - Hãy đọc Mã giao dịch / Mã tham chiếu ngân hàng trên biên lai (ví dụ: `FT26...`, `99...`, mã số giao dịch).

                - Nếu vượt qua toàn bộ 4 lớp kiểm tra (Ảnh thật 100% không chỉnh sửa + Giao dịch thành công + Đúng STK Admin + Đúng nội dung mã máy + Đủ số tiền):

                  + Trường hợp 1 (Lên Pro Tài Khoản): Số tiền >= 100.000đ HOẶC nội dung có chữ `TKPRO` / `UPPRO` HOẶC máy đã là Pro Thiết Bị (`isAlreadyDevicePro=$isAlreadyDevicePro`) chuyển thêm >= 50.000đ:

                    BẮT BUỘC mở đầu câu trả lời theo đúng định dạng:

                    `SUCCESS_ACCOUNT_PRO | TRANS_ID: <mã_giao_dịch_trên_bill> | FORENSIC: Bản gốc hợp lệ, phông chữ và nền pixel đồng nhất`

                  + Trường hợp 2 (Lên Pro Thiết Bị): Số tiền >= 50.000đ:

                    BẮT BUỘC mở đầu câu trả lời theo đúng định dạng:

                    `SUCCESS_DEVICE_PRO | TRANS_ID: <mã_giao_dịch_trên_bill> | FORENSIC: Bản gốc hợp lệ, phông chữ và nền pixel đồng nhất`

                - Nếu vi phạm bất kỳ điều kiện nào ở Lớp 2, 3, 4 (chưa thành công, sai STK nhận, thiếu mã máy trong nội dung CK, hoặc số tiền < 50.000đ):

                  BẮT BUỘC mở đầu câu trả lời bằng đúng từ khóa: `INVALID:` kèm lý do cụ thể bằng Tiếng Việt.

            """.trimIndent()



            val payload = org.json.JSONObject().apply {

                put("model", "qwen/qwen3.8-27b")

                put("temperature", 0.02)

                val messages = org.json.JSONArray()

                val userMsg = org.json.JSONObject().apply {

                    put("role", "user")

                    val contentArr = org.json.JSONArray()

                    contentArr.put(org.json.JSONObject().put("type", "text").put("text", prompt))

                    contentArr.put(org.json.JSONObject().put("type", "image_url").put("image_url", org.json.JSONObject().put("url", "data:image/jpeg;base64,$base64")))

                    put("content", contentArr)

                }

                messages.put(userMsg)

                put("messages", messages)

            }



            conn.outputStream.use { os ->

                os.write(payload.toString().toByteArray(Charsets.UTF_8))

                os.flush()

            }



            if (conn.responseCode in 200..299) {

                val body = conn.inputStream.bufferedReader().use { it.readText() }

                val root = org.json.JSONObject(body)

                val rawReply = root.optJSONArray("choices")

                    ?.optJSONObject(0)

                    ?.optJSONObject("message")

                    ?.optString("content", "")

                    ?.trim()

                    .orEmpty()

                val reply = rawReply.replace(Regex("<think>[\\s\\S]*?</think>"), "").trim()



                val isFakeDetected = reply.startsWith("FAKE_BILL_DETECTED", ignoreCase = true) ||

                    reply.contains("FAKE_BILL_DETECTED", ignoreCase = true) ||

                    reply.contains("chỉnh sửa", ignoreCase = true) && reply.contains("INVALID", ignoreCase = true) ||

                    reply.contains("bill giả", ignoreCase = true) ||

                    reply.contains("làm giả", ignoreCase = true) ||

                    reply.contains("cắt ghép", ignoreCase = true)



                val isExplicitInvalid = isFakeDetected ||

                    reply.startsWith("INVALID", ignoreCase = true) ||

                    reply.contains("không phải biên lai", ignoreCase = true) ||

                    reply.contains("không hợp lệ", ignoreCase = true) ||

                    reply.contains("chưa thanh toán", ignoreCase = true)



                val startsWithSuccessAccount = reply.startsWith("SUCCESS_ACCOUNT_PRO", ignoreCase = true) ||

                    reply.contains("SUCCESS_ACCOUNT_PRO", ignoreCase = true)

                val startsWithSuccessDevice = reply.startsWith("SUCCESS_DEVICE_PRO", ignoreCase = true) ||

                    reply.contains("SUCCESS_DEVICE_PRO", ignoreCase = true)



                val extractedTransId = Regex("""TRANS_ID:\s*([A-Za-z0-9\-_]+)""", RegexOption.IGNORE_CASE)

                    .find(reply)?.groupValues?.getOrNull(1)?.trim().orEmpty()

                val extractedForensic = Regex("""FORENSIC:\s*([^\n|]+)""", RegexOption.IGNORE_CASE)

                    .find(reply)?.groupValues?.getOrNull(1)?.trim()

                    ?: if (isFakeDetected) "Phát hiện dấu hiệu chỉnh sửa ảnh / phông chữ / nền pixel bất thường" else "Đã kiểm tra"



                val isApproved = !isExplicitInvalid && (startsWithSuccessAccount || startsWithSuccessDevice)



                if (isFakeDetected) {

                    val cleanedFakeReason = reply

                        .replace("FAKE_BILL_DETECTED:", "", ignoreCase = true)

                        .replace("FAKE_BILL_DETECTED", "", ignoreCase = true)

                        .trim()

                        .removePrefix(":")

                        .trim()

                    val fakeAlertMsg = "🚨 CẢNH BÁO AN NINH — PHÁT HIỆN DẤU HIỆU BIÊN LAI CHỈNH SỬA / KHÔNG ĐỒNG NHẤT:\n\n" +

                        "• Kết quả giám định hình ảnh: $cleanedFakeReason\n" +

                        "• Mã băm ảnh (SHA-256): `${billImageSha256.take(16)}...`\n" +

                        "🔒 Trạng thái thực tế: **TỪ CHỐI CẤP PRO**.\n" +

                        "⚠️ Hệ thống giám định tự động kiểm tra độ đồng nhất của phông chữ, nền pixel quanh số tiền/STK, mã tham chiếu ngân hàng và chữ ký tệp ảnh. Sự việc đã được ghi vào Nhật ký Kiểm toán Admin. Nếu bạn đã chuyển khoản thật, vui lòng chụp màn hình biên lai gốc trực tiếp từ ứng dụng Ngân hàng (không cắt ghép hay chỉnh sửa)!"

                    LicenseManager.logAiProChatInteraction(

                        context = context,

                        userMessage = "🚨 [CẢNH BÁO BILL GIẢ / CHỈNH SỬA] Thiết bị: $deviceId",

                        aiReply = fakeAlertMsg,

                        eventType = "FAKE_BILL_DETECTED",

                        proGranted = false,

                        grantedTier = "NONE",

                        targetDeviceId = deviceId,

                        billImageHash = billImageSha256,

                        bankTransCode = extractedTransId,

                        forensicVerdict = "PHÁT HIỆN CHỈNH SỬA / GIẢ MẠO: $cleanedFakeReason"

                    )

                    return@withContext fakeAlertMsg

                }



                if (isApproved) {

                    val isAccountTier = startsWithSuccessAccount || isAlreadyDevicePro

                    val extractedId = Regex("""MT-[A-Z0-9]{6,24}""", RegexOption.IGNORE_CASE)

                        .find(reply)?.value?.uppercase() ?: deviceId



                    // KIỂM TRA ĐĂNG NHẬP BẮT BUỘC NẾU LÀ BILL PRO TÀI KHOẢN / NÂNG CẤP PRO TÀI KHOẢN

                    if (isAccountTier && !isLoggedIn) {

                        val mustLoginMsg = "🔒 BIÊN LAI HỢP LỆ NHƯNG BẠN CHƯA ĐĂNG NHẬP TÀI KHOẢN!\n\n" +

                            "• Hệ thống đã xác nhận biên lai chuyển khoản gói **👑 PRO TÀI KHOẢN** của bạn là hợp lệ.\n" +

                            "• Tuy nhiên, để tránh cấp quyền Pro Tài Khoản khi chưa có tài khoản thật, bạn vui lòng mở tab **🔐 Đăng Nhập** trên thanh công cụ để đăng nhập Email trước, sau đó gửi lại ảnh biên lai này để hệ thống kích hoạt và gắn vĩnh viễn vào tài khoản của bạn ngay lập tức!"

                        LicenseManager.logAiProChatInteraction(

                            context = context,

                            userMessage = "🖼️ [Bill Pro TK hợp lệ nhưng khách chưa đăng nhập] Thiết bị: $extractedId",

                            aiReply = mustLoginMsg,

                            eventType = "BILL_REJECTED",

                            proGranted = false,

                            grantedTier = "NONE",

                            targetDeviceId = extractedId,

                            billImageHash = billImageSha256,

                            bankTransCode = extractedTransId,

                            forensicVerdict = "Bill hợp lệ nhưng yêu cầu khách đăng nhập tài khoản trước khi gắn ACCOUNT_PRO"

                        )

                        return@withContext mustLoginMsg

                    }



                    // KIỂM TRA CHỐNG DÙNG LẠI MÃ GIAO DỊCH NGÂN HÀNG (TRANS_ID) HOẶC HASH ẢNH TRÊN CLOUD

                    val (isReplay, replayReason) = LicenseManager.checkBillReplayOrDuplicateInCloud(

                        billSha256 = billImageSha256,

                        bankTransCode = extractedTransId,

                        currentDeviceId = extractedId,

                        isRequestingAccountUpgrade = isAlreadyDevicePro

                    )

                    if (isReplay) {

                        val replayRejectMsg = "🚨 TỪ CHỐI KÍCH HOẠT — PHÁT HIỆN DÙNG LẠI BIÊN LAI CŨ:\n\n" +

                            "• $replayReason\n" +

                            "• Mã GD Ngân hàng: `${extractedTransId.ifBlank { "Trùng ảnh" }}`\n" +

                            "🔒 Trạng thái: CHƯA CẤP PRO."

                        LicenseManager.logAiProChatInteraction(

                            context = context,

                            userMessage = "🖼️ [Chặn dùng lại Mã GD / Bill cũ: $extractedTransId] Thiết bị: $extractedId",

                            aiReply = replayRejectMsg,

                            eventType = "REUSED_BILL_BLOCKED",

                            proGranted = false,

                            grantedTier = "NONE",

                            targetDeviceId = extractedId,

                            billImageHash = billImageSha256,

                            bankTransCode = extractedTransId,

                            forensicVerdict = "Chặn dùng lại biên lai cũ: $replayReason"

                        )

                        return@withContext replayRejectMsg

                    }



                    val targetTierName = if (isAccountTier) "👑 PRO TÀI KHOẢN (100.000đ)" else "📱 PRO THIẾT BỊ (50.000đ)"

                    val isAutoApproveEnabled = LicenseManager.isAutoApproveNotificationPaymentEnabled(context)



                    if (isAutoApproveEnabled) {

                        // TỰ ĐỘNG CẤP PRO 100% NGAY LẬP TỨC CHO KHÁCH HÀNG — ADMIN KHÔNG CẦN VÀO APP

                        val grantResult = LicenseManager.executeVerifiedProGrant(

                            context = context,

                            rawTargetDeviceId = extractedId,

                            grantAccountPro = isAccountTier,

                            reason = "AI_AUTO_BILL_VERIFIED_GRANT"

                        )



                        // Xóa đơn chờ duyệt khỏi danh sách vì đã được duyệt tự động thành công

                        LicenseManager.deletePaymentIntentsForDevice(extractedId, context)



                        val finalMsg = "🎉 XÁC THỰC BIÊN LAI THÀNH CÔNG 100%!\n\n" +

                            "• Thiết bị: `$extractedId`\n" +

                            "• Hạng bản quyền: $targetTierName\n" +

                            "• Mã GD Ngân hàng: `${extractedTransId.ifBlank { "ĐÃ ĐỐI SOÁT HỢP LỆ" }}`\n\n" +

                            "⚡ HỆ THỐNG ĐÃ TỰ ĐỘNG KÍCH HOẠT QUYỀN PRO CHO BẠN NGAY LẬP TỨC:\n" +

                            "${grantResult.summaryMessage}\n\n" +

                            "🔑 Mã Key của bạn: `${grantResult.generatedKey}`\n" +

                            "💡 Bạn có thể sử dụng toàn bộ tính năng cao cấp không giới hạn ngay bây giờ!"



                        LicenseManager.logCustomerPaymentIntent(

                            context = context,

                            actionType = "AI_AUTO_APPROVED_PRO",

                            details = "Mã GD: ${extractedTransId.ifBlank { "N/A" }} • $targetTierName • Key: ${grantResult.generatedKey} • Thiết bị: $extractedId"

                        )



                        LicenseManager.logAiProChatInteraction(

                            context = context,

                            userMessage = "🖼️ [Bill hợp lệ - Kích hoạt tự động] Thiết bị: $extractedId • Mã GD: ${extractedTransId.ifBlank { "N/A" }}",

                            aiReply = "$finalMsg\n(Chi tiết giám định: $reply)",

                            eventType = "AI_AUTO_BILL_APPROVED",

                            proGranted = true,

                            grantedTier = if (grantResult.isAccountPro) "ACCOUNT_PRO" else "DEVICE_PRO",

                            generatedKey = grantResult.generatedKey,

                            targetDeviceId = extractedId,

                            billImageHash = billImageSha256,

                            bankTransCode = extractedTransId,

                            forensicVerdict = extractedForensic

                        )

                        finalMsg

                    } else {

                        // NẾU ADMIN TẮT TỰ ĐỘNG DUYỆT THÌ MỚI ĐƯA VÀO DANH SÁCH CHỜ DUYỆT THỦ CÔNG

                        LicenseManager.logCustomerPaymentIntent(

                            context = context,

                            actionType = "BILL_SUBMITTED_FOR_REVIEW",

                            details = "Mã GD: ${extractedTransId.ifBlank { "N/A" }} • $targetTierName • Thiết bị: $extractedId"

                        )



                        val finalMsg = "📋 ĐÃ TIẾP NHẬN ẢNH BIÊN LAI CHUYỂN KHOẢN!\n\n" +

                            "• Thiết bị yêu cầu: `$extractedId`\n" +

                            "• Gói yêu cầu: $targetTierName\n" +

                            "• Mã GD Ngân hàng: `${extractedTransId.ifBlank { "Đang kiểm tra" }}`\n\n" +

                            "⏳ TRẠNG THÁI: CHỜ ADMIN ĐỐI SOÁT TÀI KHOẢN NGÂN HÀNG\n" +

                            "Hệ thống đã gửi biên lai này đến Trang Quản Trị của Admin. Để đảm bảo an toàn doanh thu và tránh nhầm lẫn, Admin sẽ kiểm tra số dư thực tế trong tài khoản ngân hàng và bấm duyệt cấp Pro cho bạn trong 1 - 3 phút!\n\n" +

                            "💡 Ngay khi Admin bấm duyệt trên trang quản trị, máy bạn sẽ tự động mở khóa bản Pro vĩnh viễn mà không cần thao tác thêm."



                        LicenseManager.logAiProChatInteraction(

                            context = context,

                            userMessage = "🖼️ [Gửi ảnh biên lai chuyển khoản] Thiết bị: $extractedId • Mã GD: ${extractedTransId.ifBlank { "N/A" }}",

                            aiReply = "$finalMsg\n(Chi tiết giám định bill: $reply)",

                            eventType = "BILL_PENDING_ADMIN_APPROVAL",

                            proGranted = false,

                            grantedTier = "NONE",

                            targetDeviceId = extractedId,

                            billImageHash = billImageSha256,

                            bankTransCode = extractedTransId,

                            forensicVerdict = extractedForensic

                        )

                        finalMsg

                    }

                } else {

                    val cleaned = reply.replace("INVALID:", "", ignoreCase = true)

                        .replace("INVALID", "", ignoreCase = true)

                        .trim()

                        .removePrefix(":")

                        .trim()

                    val rejectMsg = "⚠️ Kết quả kiểm tra biên lai: $cleaned\n🔒 Trạng thái thực tế: CHƯA LÊN PRO. Vui lòng gửi đúng ảnh chụp màn hình biên lai chuyển khoản thành công tới STK $bankAccount ($bankHolder) kèm nội dung chứa mã máy `$deviceId` để hệ thống kích hoạt Pro!"

                    LicenseManager.logAiProChatInteraction(

                        context = context,

                        userMessage = "🖼️ [Gửi ảnh biên lai không hợp lệ / bị từ chối] Thiết bị: $deviceId",

                        aiReply = rejectMsg,

                        eventType = "BILL_REJECTED",

                        proGranted = false,

                        grantedTier = "NONE",

                        targetDeviceId = deviceId,

                        billImageHash = billImageSha256,

                        bankTransCode = extractedTransId,

                        forensicVerdict = cleaned

                    )

                    rejectMsg

                }

            } else {

                "Không thể kết nối máy chủ kiểm duyệt hóa đơn lúc này. Vui lòng thử lại sau giây lát."

            }

        } catch (e: Throwable) {

            "Lỗi phân tích ảnh biên lai: ${e.message}"

        }

    }

}



/**

 * Dịch tin nhắn ngoại ngữ sang Tiếng Việt (ẩn hoàn toàn tên công cụ AI dưới nền)

 */

private suspend fun translateForeignMessageToVietnamese(

    context: Context,

    msg: ChatMessage,

    messagesList: MutableList<ChatMessage>

) {

    val idx = messagesList.indexOfFirst { it.id == msg.id }

    if (idx == -1) return



    messagesList[idx] = messagesList[idx].copy(isTranslating = true)



    val translated = withContext(Dispatchers.IO) {

        try {

            val apiKey = LicenseManager.getLoadBalancedGroqApiKey(context).ifBlank {

                try { com.example.BuildConfig.GROQ_API_KEY } catch (_: Throwable) { "" }

            }

            if (apiKey.isBlank() || apiKey == "GROQ_API_KEY_DEFAULT_VALUE") {

                return@withContext "Chưa thể dịch tự động lúc này."

            }



            val url = URL("https://api.groq.com/openai/v1/chat/completions")

            val conn = (url.openConnection() as HttpURLConnection).apply {

                requestMethod = "POST"

                doOutput = true

                doInput = true

                connectTimeout = 10_000

                readTimeout = 15_000

                setRequestProperty("Authorization", "Bearer $apiKey")

                setRequestProperty("Content-Type", "application/json; charset=UTF-8")

            }



            val payload = org.json.JSONObject().apply {

                put("model", "qwen/qwen3.8-27b")

                put("temperature", 0.2)

                val messages = org.json.JSONArray()

                messages.put(

                    org.json.JSONObject().apply {

                        put("role", "system")

                        put("content", "Bạn là trình biên dịch chuyên nghiệp. Hãy dịch chính xác và tự nhiên văn bản sau sang Tiếng Việt. Chỉ trả về đúng nội dung bản dịch Tiếng Việt, không giải thích thêm.")

                    }

                )

                messages.put(

                    org.json.JSONObject().apply {

                        put("role", "user")

                        put("content", msg.text)

                    }

                )

                put("messages", messages)

            }



            conn.outputStream.use { os ->

                os.write(payload.toString().toByteArray(Charsets.UTF_8))

                os.flush()

            }



            if (conn.responseCode in 200..299) {

                val body = conn.inputStream.bufferedReader().use { it.readText() }

                val root = org.json.JSONObject(body)

                root.optJSONArray("choices")

                    ?.optJSONObject(0)

                    ?.optJSONObject("message")

                    ?.optString("content", "")

                    ?.trim()

                    .orEmpty()

            } else {

                "Không thể dịch tin nhắn lúc này (Mã ${conn.responseCode})."

            }

        } catch (e: Throwable) {

            "Lỗi khi dịch tin nhắn: ${e.message}"

        }

    }



    messagesList[idx] = messagesList[idx].copy(

        translatedText = translated,

        isTranslating = false

    )

}



/**

 * Xây dựng bộ kiến thức đầy đủ, chuẩn xác 100% về mọi tính năng của ứng dụng MagicTune

 * VÀ quy tắc thực thi lệnh cấp Pro có kiểm chứng (Anti-Hallucination Action Tags).

 */

private fun buildMagicTuneKnowledgePrompt(context: Context): String {

    val deviceId = LicenseManager.getDeviceId(context)

    val proTierLabel = LicenseManager.getProTierLabel(context)

    val isCurrentlyPro = LicenseManager.isProActivated(context)

    val deviceProPrice = LicenseManager.getProPrice(context)

    val accountProPrice = LicenseManager.getAccountProPrice(context)

    val upgradePrice = LicenseManager.getUpgradeToAccountProPrice(context)

    val freeTrialLimit = LicenseManager.getFreeTrialLimit(context)

    val bankName = LicenseManager.getPaymentBankName(context)

    val bankAccount = LicenseManager.getPaymentAccountNumber(context)

    val bankHolder = LicenseManager.getPaymentAccountHolder(context)



    return """

        Bạn là Trợ lý Hỗ trợ & Auto-Admin Phê Duyệt Pro Tự Động chính thức của ứng dụng **MagicTune (Tối ưu hệ thống Honor MagicOS & Android)**.

        QUY TẮC BẮT BUỘC:

        1. TUYỆT ĐỐI KHÔNG BAO GIỜ nhắc đến tên bất kỳ mô hình AI hay nhà cung cấp AI nào (không nhắc Groq, Grock, Qwen, OpenAI, GPT, LLaMA...). Nếu người dùng hỏi bạn là ai, chỉ trả lời: "Tôi là Trợ lý hỗ trợ & quản trị tự động của ứng dụng MagicTune".

        2. KHÔNG BAO GIỜ trả lời bịa đặt ("trả lời phứa") những tính năng không có trong ứng dụng. Chỉ trả lời chính xác dựa trên SỔ TAY KIẾN THỨC ỨNG DỤNG dưới đây.

        3. QUY TẮC KIỂM CHỨNG BẢN QUYỀN PRO NGHIÊM NGẶT (TUYỆT ĐỐI CHẶN KHÁCH CHƯA THANH TOÁN XIN LÊN PRO QUA TIN NHẮN CHỮ):

           - Trạng thái Pro thực tế của máy hiện tại (`$deviceId`) đang là: **$proTierLabel** (Đã lên Pro = `$isCurrentlyPro`).

           - **NGUYÊN TẮC BẤT DI BẤT DỊCH**:

             * TUYỆT ĐỐI KHÔNG BAO GIỜ cấp Pro chỉ vì người dùng nhắn tin văn bản nói rằng "mình đã chuyển khoản rồi", "cấp pro cho mình", "duyệt pro giúp mình" mà KHÔNG đính kèm ảnh chụp biên lai chuyển khoản hoặc mã Key hợp lệ!

             * Nếu máy hiện tại CHƯA có Pro (`$isCurrentlyPro == false`), bạn TUYỆT ĐỐI KHÔNG ĐƯỢC nói câu "Đã nâng cấp Pro thành công" hay "Đã kích hoạt Pro cho bạn"!

             * Khi người dùng nói đã chuyển khoản nhưng chỉ nhắn chữ, hãy yêu cầu họ bấm vào biểu tượng **Hình ảnh 🖼️** ở góc trái thanh chat để **tải ảnh chụp màn hình biên lai chuyển khoản (bill)** lên cho hệ thống kiểm tra tự động, hoặc nhập Mã Key bản quyền.



        === THÔNG TIN MÁY HIỆN TẠI CỦA NGƯỜI DÙNG ===
        - Mã Thiết Bị (Device ID): $deviceId
        - Trạng thái bản quyền hiện tại: $proTierLabel
        - Số lượt dùng thử miễn phí ban đầu cho các tính năng nâng cao: $freeTrialLimit lượt (Admin có thể thay đổi số lượt này toàn cầu bất cứ lúc nào).

        === QUẢNG CÁO & GIỚI THIỆU CÁC TÍNH NĂNG ĐƯỢC MIỄN PHÍ MÃI MÃI (100% FREE TRỌN ĐỜI) ===
        Khi người dùng hỏi về các tính năng miễn phí, giá cả, hoặc thắc mắc người dùng chưa lên Pro thì dùng được gì, bạn HÃY NHIỆT TÌNH QUẢNG CÁO RÕ RÀNG danh sách các tính năng được DÙNG MIỄN PHÍ TRỌN ĐỜI sau đây:
        1. 🌐 GOOGLE KHOANH TRÒN TÌM KIẾM (Circle to Search) - MIỄN PHÍ MÃI MÃI:
           - Thay thế hoàn toàn trợ lý tiếng Trung YOYO của Honor.
           - Chỉ cần nhấn giữ thanh điều hướng dưới đáy màn hình là có thể khoanh tròn hình ảnh, tra cứu sản phẩm, tìm kiếm thông tin ngay tức thì.
        2. 🇨🇳 TỰ ĐỘNG DỊCH CUỘN MÀN HÌNH XUYÊN THẤU & QUY ĐỔI GIÁ VNĐ (Taobao, 1688, Pinduoduo, Douyin, JD) - MIỄN PHÍ MÃI MÃI:
           - Vừa lướt vuốt mua sắm, ứng dụng tự động dịch toàn bộ chữ tiếng Trung sang tiếng Việt siêu tốc.
           - Tự động nhận diện giá tiền Tệ (¥, RMB) và tính toán đổi sang tiền Việt Nam (VNĐ) hiển thị ngay cạnh sản phẩm.
        3. 🤖 SỬ DỤNG TRỢ LÝ GEMINI AI BẰNG KHÓA CÁ NHÂN (BYOK - Bring Your Own Key) - MIỄN PHÍ MÃI MÃI:
           - Người dùng tự lấy Gemini API Key miễn phí tại Google AI Studio (aistudio.google.com) và nhập vào mục Cài đặt -> Chat thoải mái với Gemini Live tiếng Việt mà KHÔNG CẦN NÂNG CẤP BẢN PRO!
        4. 🔍 QUÉT CHẨN ĐOÁN LỖI THÔNG BÁO & LỖI HỆ THỐNG (Diagnostic Scan) - MIỄN PHÍ MÃI MÃI:
           - Quét tìm tất cả ứng dụng bị trễ thông báo, ứng dụng bị ngắt quyền chạy ngầm, pin PowerGenius/iAware làm ẩn chuông.
        5. 📱 MỞ CẬP NHẬT HỆ ĐIỀU HÀNH MAGICOS (OUC / HOTA) - MIỄN PHÍ MÃI MÃI:
           - Giúp các máy Honor xách tay bị ẩn mục Cập nhật hệ thống mở lại trang Update chính hãng hoàn toàn miễn phí.
        6. 📦 KHO ỨNG DỤNG HONOR (App Store) & WIDGETS TIỆN ÍCH - MIỄN PHÍ MÃI MÃI:
           - Tải các ứng dụng mod, bộ gõ Laban Key, CH Play.
           - Toàn bộ Widget Pin thông minh (đo W sạc, đếm giây sạc, nhiệt độ pin), Widget RAM/ROM, Widget Thanh tìm kiếm màn hình chính.
        7. 🎁 TẶNG THÊM $freeTrialLimit LƯỢT DÙNG THỬ MIỄN PHÍ:
           - Tặng sẵn $freeTrialLimit lượt dùng thử miễn phí cho các tác vụ nâng cao độc quyền (như gạt công tắc tự động siêu tốc, fix thông báo chuyên sâu đa hãng).



        === CẤU TRÚC CÁC TAB & TÍNH NĂNG TOÀN DIỆN TRONG ỨNG DỤNG MAGICTUNE v2.9.5 ===

        1. Thanh Header & Thanh Điều Hướng Trên Cùng:

           - Hiển thị tên app kèm phiên bản: `MagicTune v3.0`.

           - Hiển thị tên model thiết bị Honor/Android, phiên bản Android & MagicOS (Android 7 đến MagicOS 11+), tình trạng kết nối ADB / Shizuku (`🟢 Đã kết nối` hoặc `🔴 Chưa kết nối`).

           - Ô tìm kiếm nhanh toàn cục ("Tìm nhanh tính năng..."): Gõ từ khóa bất kỳ (như Gemini, Live, 120Hz, GPS, Ngân hàng, Thông báo, Khoanh tròn, Taobao, Pin, Máy in...) để nhảy thẳng tới ô tính năng tương ứng.

           - Nút `💬 Hỗ trợ`: Mở màn hình Trợ lý hỗ trợ CSKH thông minh & kiểm tra duyệt Pro tự động này.

           - Nút `🛡️ Đủ quyền` / `⚠️ Cấp quyền`: Kiểm tra nhanh các quyền hệ thống (Shizuku, Quyền Trợ năng Accessibility, Vẽ trên ứng dụng khác Overlay, Bộ nhớ...).

           - Nút `Hoàn tác`: Khôi phục cài đặt mặc định gốc của máy nếu muốn hủy các thiết lập đã áp dụng.



        2. Tab `1. Cài Máy` (Thiết lập máy mới, Việt hóa & Tiện ích cốt lõi):

           - `[Ô #01] 1-Chạm Thiết Lập Toàn Diện 8-trong-1`: Cài đặt Tiếng Việt 100%, tự động kích hoạt dịch vụ Google Play (GMS), cài đặt bàn phím gõ Tiếng Việt Laban Key, chuẩn hóa múi giờ và GPS Việt Nam cho máy Honor xách tay nội địa mới mua hoặc vừa khôi phục cài đặt gốc.

           - `[Ô #02] Khôi Phục & Mở Cập Nhật Hệ Điều Hành MagicOS (OUC / HOTA) HOÀN TOÀN MIỄN PHÍ`:

             + Dành riêng cho các máy Honor xách tay bị ẩn hoặc bị khóa mục Cập nhật phần mềm hệ thống (OUC / HOTA).

             + Tính năng này là **HOÀN TOÀN MIỄN PHÍ (FREE)**, mọi người dùng đều bấm mở được ngay mà không yêu cầu gói Pro.

           - `[Ô #08] Đặc Trị Timestamp Camera & Định Vị GPS Honor`: Sửa triệt để lỗi chụp ảnh Timestamp Camera bị nhảy sai vị trí (chụp quận này báo quận khác), tắt hoàn toàn dịch vụ định vị mạng nội địa Trung Quốc (Baidu/AMap) và chuyển sang A-GPS Google độ nhạy cao chuẩn Việt Nam.

           - `[Ô #09] Chặn Chợ App Honor Tự Cập Nhật`: Chặn chợ ứng dụng Honor AppMarket ngầm tự động cập nhật đè các ứng dụng quốc tế (Zalo, Facebook, Messenger...) sang phiên bản tiếng Trung.

           - `[Ô #11] Cài Đặt Hệ Thống & Máy In`: Lối tắt mở nhanh cài đặt máy và thiết lập máy in.

           - `[Ô #12] Tải Ứng Dụng CH Play Trực Tiếp`: Hỗ trợ tải file APK chính gốc từ Google Play nhanh chóng.

           - `[Ô #13] Kiểm Tra Thông Số Phần Cứng`: Xem chi tiết cấu hình máy, chip SoC, RAM, pin, màn hình.

           - `[Ô #14] Cài Đặt Khóa Gemini API Key Cá Nhân (BYOK - Bring Your Own Key)`:

             + Cho phép người dùng nhập khóa Google Gemini API Key của riêng mình (lấy miễn phí tại Google AI Studio: aistudio.google.com).

             + Khi có API Key cá nhân, người dùng được ưu tiên sử dụng hạn mức riêng siêu tốc, không phụ thuộc vào máy chủ chung, tối ưu chi phí duy trì trọn đời cho hệ thống.



        3. Tab `2. Chuông` (Đặc trị 100% Lỗi Thông Báo Zalo, Messenger, Facebook, Gmail, Telegram trên MagicOS):

           - Cơ chế hoạt động: Tắt triệt để tính năng diệt ngầm PowerGenius, vô hiệu hóa thông báo nhẹ nhàng (Gentle Notification), mở khóa thông báo nổi (Banner/Heads-up) và chuông báo rung tức thì.

           - `[Ô #10 & #14] Mở 100% Thông Báo & Phá Thông Báo Nhẹ Nhàng (Gentle Notification)`: Tắt tính năng tự ý giấu thông báo vào ngăn kéo im lặng của MagicOS. Bật rung, chuông, âm thanh nổi cho mọi ứng dụng nhắn tin quan trọng.

           - `[Ô #16] Cấp Lại Token FCM Facebook Không Nổ Chuông`: Sửa triệt để lỗi Facebook Messenger bị câm chuông, chỉ nhận thông báo khi bấm mở app. Cấp lại kênh đồng bộ FCM nền liên tục.

           - `[Ô #17] Phá Gom Cụm 0 Giây (Doze Mode 0s) Gmail & Facebook`: Tắt hoàn toàn chế độ ngủ sâu tích điện của hệ thống, đưa danh sách app vào Whitelist Doze Mode, đảm bảo nhận email đơn hàng, tin nhắn ngân hàng, thông báo tức thì 0 giây trễ ngay cả khi tắt màn hình cả đêm.



        4. Tab `3. Làm Mượt` (Hiệu năng cực đỉnh, Trợ lý ảo AI & Công cụ thông minh):

           - `✨ BẢNG TRỢ LÝ GEMINI LIVE NỔI RẢNH TAY TOÀN DIỆN (ĐẶC QUYỀN MỚI TRÊN v2.9)`:

             + Bảng điều khiển tròn hoặc thanh nổi AI hiện diện xuyên suốt trên mọi màn hình.

             + **Trạng thái mặc định**: Công tắc `🔄 Liên tục` được **BẬT MẶC ĐỊNH**, sẵn sàng đàm thoại giọng nói 2 chiều rảnh tay liên tục không cần chạm nút nhiều lần.

             + **Tối ưu hóa hoàn toàn cho MagicOS 11 & Android 7 đến 15+**: Tuyệt đối không giật, không lag, không đơ bảng nổi nhờ cơ chế giải phóng bộ nhớ và tối ưu luồng âm thanh đa nhiệm.

             + **Sửa triệt để lỗi "Nhận diện giọng nói không thành công"**: Tích hợp VAD động thông minh và bộ lọc nhiễu tự nhiên trên micro Honor.

             + **Tốc độ phản hồi thần tốc (< 0.1s)**: Các câu giao tiếp chào hỏi, cảm ơn phản hồi tức thì bằng giọng đọc tiếng Việt ngọt ngào mượt mà.

             + **Làm mọi việc thay thế YOYO mặc định**:

               * Mở ứng dụng bất kỳ ("mở Zalo", "mở Youtube", "mở Facebook"...).

               * Điều khiển hệ thống rảnh tay: bật/tắt Wi-Fi, Bluetooth, chỉnh âm lượng, độ sáng màn hình, khóa màn hình, chụp ảnh màn hình, tự động bấm nút cảm ứng (Accessibility Click/Scroll).

               * Tra cứu thời tiết chính xác theo vị trí định vị GPS thực tế của máy.

               * Đàm thoại, dịch thuật, giải toán, viết văn bản, sáng tạo nội dung thông minh.

             + **Kiến trúc Zero-Cost Scale**: Tự động cân bằng giữa Pollinations AI siêu tốc miễn phí và Gemini BYOK (Ô #14), đảm bảo phục vụ hàng triệu người dùng cùng lúc mà Admin không lo chi phí duy trì máy chủ!

           - `[Ô #22] Khoanh Tròn Tìm Kiếm (Circle to Search) & Dịch Trực Tiếp Cuộn & Dịch (Taobao / 1688 / Tmall)`:

             + **Cách kích hoạt**: Nhấn giữ vạch điều hướng cử chỉ dưới đáy màn hình, hoặc bấm ô "Khoanh Tròn Tìm Kiếm" trên thanh Cài đặt nhanh Quick Settings, hoặc chạm nút nổi ✨ Gemini.

             + **Chế độ 🔍 Tìm Google Lens**: Khoanh tròn bất kỳ vùng nào trên màn hình (đồ vật, quần áo, cây cỏ, mã vạch, văn bản...) để tra cứu Google Lens tức thì hoặc tìm kiếm bằng giọng nói.

             + **Chế độ 🌐 Cuộn & Dịch Trực Tiếp (Scroll & Translate) Xuyên Thấu Cảm Ứng 100%**:

               * Thiết kế chuyên dụng cho việc săn hàng trên **Taobao, 1688, Tmall, Pinduoduo, JD, Douyin**.

               * Vừa lướt vuốt cuộn chọn sản phẩm, ứng dụng tự động dịch trực tiếp toàn bộ chữ tiếng Trung sang Tiếng Việt chuẩn xác 0 độ trễ theo thời gian thực.

               * **Tự động quy đổi tỷ giá tiền tệ trực tiếp sang VNĐ**: Nhận diện ký hiệu tiền tệ tệ (¥, RMB, Yuan, USD, ₩, 円...) và tự động tính toán, hiển thị giá tiền Việt Nam (VNĐ) nhỏ gọn bên cạnh, không làm đè chữ hay che mất ảnh sản phẩm.

               * Bảng điều khiển thông minh tự động thu gọn/ẩn khi bàn phím ảo (Laban Key, Gboard) bật lên để không vướng thao tác gõ.

           - `[Ô #23] Siêu Tiết Kiệm Pin (Zero Delay OLED)`: Tối ưu xung nhịp CPU khi tắt màn hình, tiết kiệm pin tối đa cho màn hình AMOLED/OLED mà không trễ tin nhắn.

           - `[Ô #24 & #29] Mod Phím Điều Hướng Gọi Trợ Lý Voice AI / OK Google`.

           - `[Ô #28] Chặn Quảng Cáo Toàn Hệ Thống (AdBlocker Pro)`: Chặn sạch quảng cáo rác trong web, app, game bằng giao thức Private DNS mã hóa an toàn.

           - `[Ô #29] Tăng Độ Nhạy Vuốt Đáy Cảm Ứng`: Khắc phục triệt để hiện tượng vuốt khó nhận khi dán kính cường lực dày.

           - `[Ô #32] Ép Màn Hình 120Hz / 144Hz & Tốc Độ Hiệu Ứng 0.5x`: Khóa tần số quét cao nhất liên tục trong mọi ứng dụng và game, hiệu ứng mượt như iPhone Pro Max.

           - `[Ô #33B] Đặc Trị Lỗi Android Auto`: Kết nối màn hình ô tô mượt mà, không bao giờ bị văng kết nối giữa chừng.

           - `[Ô #35] Ẩn Nhà Phát Triển Mở Full Ngân Hàng, VNeID & Game`:

             + Vượt qua kiểm tra bảo mật của toàn bộ các ngân hàng (MB Bank, Vietcombank, BIDV, Agribank, Techcombank, VPBank, Cake, VNeID, Momo...).

             + **Khắc phục cảnh báo MB Bank "Ứng dụng giả mạo hoặc có rủi ro bảo mật"** (ví dụ gói `org.thunderdog.challegram` của Telegram X hoặc các quyền Trợ năng Accessibility): Hướng dẫn khách an tâm, đây là cơ chế quét của MB Bank với quyền trợ năng/app bên ngoài, chỉ cần tạm đóng băng app hoặc tắt quyền trợ năng khi vào MB Bank, và bật `[Ô #35]` là vào chuyển tiền bình thường.

           - `[Ô #36] Mở Khóa Truy Cập Thư Mục Android/data & Android/obb` trên Android 11 đến Android 15+.

           - `[Ô #38] Quản Lý Quyền Riêng Tư Cảm Biến Cấp Sâu` (Camera, Micro, GPS, Clipboard).

           - `[Ô #39] Macro Tự Động Hóa & Gán Phím Cứng Hệ Thống`.



        5. Tab `4. Gỡ App` (Gỡ Bỏ & Đóng Băng App Rác Nội Địa Trung Quốc):

           - Quét và đóng băng/gỡ an toàn các dịch vụ ngầm rác như HiBoard, Trợ lý YOYO tiếng Trung, Chợ AppMarket Trung Quốc, Game Center nội địa... Giúp giải phóng 3-5GB RAM, máy mát lạnh và thời lượng pin tăng thêm 25-40%. Có thể khôi phục lại bất kỳ lúc nào chỉ bằng 1 nút bấm.



        6. Tab `5. Lệnh` (ADB Shell Runner Tiện Ích):

           - Chạy trực tiếp các câu lệnh shell, kiểm tra logcat, thiết lập thông số hệ thống nâng cao ngay trên điện thoại mà không cần cắm cáp vào máy tính PC.



        7. Tab `6. Máy In` (`[Ô #11]` In Nhiệt K80 Qua Mạng Wi-Fi / LAN):

           - In trực tiếp đơn hàng Shopee, TikTok Shop, hóa đơn bán lẻ, file PDF, ảnh hóa đơn tới máy in nhiệt khổ K80 (80mm) qua Wi-Fi / IP LAN trong tích tắc, hỗ trợ lệnh tự động cắt giấy chuẩn mực.



        8. Tab `7. Kết Nối` (`[Ô #40–#43]` Kết Nối Không Dây Mã 6 Số & Shizuku):

           - Kết nối cực nhanh bằng mã ghép nối 6 số (Wireless Debugging): Vào Cài đặt -> Tùy chọn nhà phát triển -> Bật Gỡ lỗi không dây -> Ghép nối thiết bị bằng mã ghép nối -> Nhập 6 số vào thanh thông báo nổi của MagicTune.

           - Hoạt động mượt mà với Shizuku. Đặc biệt: Sau khi kích hoạt cấp quyền hệ thống xong, bạn có thể tắt Gỡ lỗi không dây, mọi tính năng vẫn chạy Offline vĩnh viễn không cần kết nối lại!



        9. Tab `Kho App` & Tab `Tài Khoản` (Quản lý Bản quyền Pro & Đổi máy):

           - Bảng giá & Sự khác nhau giữa các gói Pro:

             + **📱 Gói Pro Thiết Bị ($deviceProPrice)**: Gắn cố định theo mã phần cứng (`Device ID: $deviceId`) của 1 máy. Chỉ dùng trên máy đó, cài lại ROM/App vẫn giữ nguyên Pro nhưng không mang sang máy khác được.

             + **👑 Gói Pro Tài Khoản ($accountProPrice)**: Gắn với tài khoản đăng nhập. Cho phép **đăng nhập tài khoản lên thiết bị khác và thiết bị mới vẫn sử dụng được đầy đủ toàn bộ chức năng Pro**.

               * **Quy định 1 máy duy nhất**: Mỗi tài khoản chỉ được đăng nhập trên **1 thiết bị tại một thời điểm**. Khi bạn đăng nhập tài khoản trên máy mới, **máy cũ sẽ tự động đăng xuất ngay lập tức**.

             + **🚀 Nâng cấp từ Pro Máy lên Pro Tài Khoản (+$upgradePrice)**: Nếu máy bạn đã mua Pro Thiết Bị rồi và muốn nâng cấp lên Pro Tài Khoản để đổi máy tự do, bạn chỉ cần trả thêm phí chênh lệch **+$upgradePrice** (nội dung chuyển khoản: `UPPRO $deviceId` hoặc nhập mã Key dạng `TKPR-XXXX-XXXX-XXXX` tại mục Tài Khoản).

           - QUY TẮC BẢO LƯU PRO VĨNH VIỄN 100% (RẤT QUAN TRỌNG):

             + **Mỗi thiết bị được cấp cố định MỘT KEY DUY NHẤT**: Dù cài lại máy hay xóa app thì Key kích hoạt của thiết bị đó vẫn không đổi. Luôn nhắc nhở người dùng sao chép lưu giữ Key (hoặc chụp ảnh màn hình lưu vào tin nhắn/ghi chú) do Admin hoặc AI cấp để dùng về sau nếu vô tình mất Pro.

             + **HOẶC ĐĂNG NHẬP TÀI KHOẢN**: Thiết bị Pro được ghi nhớ vĩnh viễn vào tài khoản trên đám mây. Về sau nếu lỡ lỗi không thấy Pro, CHỈ CẦN ĐĂNG NHẬP THIẾT BỊ 100% ĐƯỢC TỰ ĐỘNG KHÔI PHỤC PRO nếu đã từng kích hoạt!

           - Thông tin chuyển khoản nhận tiền tự động:

             + Ngân hàng: **$bankName**

             + Số tài khoản: **$bankAccount**

             + Chủ tài khoản: **$bankHolder**

             + Sau khi chuyển khoản, người dùng có thể bấm nút hình ảnh 🖼️ ngay trong khung chat này để gửi ảnh chụp bill chuyển khoản — hệ thống sẽ tự động đọc bill và kích hoạt Pro ngay lập tức!

              + Quy định bắt buộc đăng nhập trước khi hiện mã QR nâng cấp: Đối với máy đang là Pro Thiết Bị muốn nâng cấp lên Pro Tài Khoản (hoặc khách chọn mua gói Pro Tài Khoản), ứng dụng chỉ hiển thị mã QR chuyển khoản khi người dùng đã đăng nhập tài khoản thật để tránh chuyển khoản xong mà chưa có tài khoản nhận Pro.

              + Cơ chế phân biệt ảnh Bill Giả / Bill Chỉnh Sửa (5 lớp bảo mật): Hệ thống kiểm tra tự động bằng 5 lớp: (1) Bắt buộc đã đăng nhập nếu nâng cấp lên Pro Tài Khoản; (2) Chống dùng lại ảnh bill cũ bằng mã băm SHA-256; (3) Soi giám định phông chữ, độ thẳng hàng dòng chữ, vết cắt ghép/làm mờ nền quanh con số và dấu vết web tạo bill giả; (4) Đối chiếu chính xác đồng thời STK nhận ($bankAccount - $bankHolder), số tiền và nội dung chuyển khoản chứa mã máy `$deviceId`; (5) Đối chiếu mã giao dịch ngân hàng (FT/Mã GD) chống nạp trùng.

    """.trimIndent()

}



/**

 * Phản hồi hướng dẫn sử dụng ứng dụng VÀ kiểm soát cấp Pro nghiêm ngặt:

 * 1. KHÔNG BAO GIỜ cấp Pro chỉ qua lời nói văn bản nếu khách chưa thanh toán (chưa có ảnh bill hợp lệ / chưa có Key SHA-256 / chưa có trong danh sách Pro trên Firebase).

 * 2. Tự động kiểm tra Firebase (`devices` & `users`) nếu khách báo cài lại app / mất Pro -> Nếu đúng là thiết bị quen thuộc đã đăng ký Pro trên Firebase thì khôi phục ngay!

 * 3. Ghi nhận mọi cuộc trò chuyện liên quan đến Pro vào bảng `ai_pro_chat_logs` để Admin kiểm tra và hậu kiểm bất cứ lúc nào.

 */

private suspend fun fetchSupportResponse(

    context: Context,

    userQuery: String,

    conversationHistory: List<ChatMessage>

): String {

    return withContext(Dispatchers.IO) {

        val currentDeviceId = LicenseManager.getDeviceId(context)

        val trimmedQuery = userQuery.trim()

        val lowerQuery = trimmedQuery.lowercase()



        val isProRelatedQuery = lowerQuery.contains("pro") ||

            lowerQuery.contains("chuyển khoản") ||

            lowerQuery.contains("chuyen khoan") ||

            lowerQuery.contains("thanh toán") ||

            lowerQuery.contains("thanh toan") ||

            lowerQuery.contains("nâng cấp") ||

            lowerQuery.contains("nang cap") ||

            lowerQuery.contains("bản quyền") ||

            lowerQuery.contains("ban quyen") ||

            lowerQuery.contains("khôi phục") ||

            lowerQuery.contains("khoi phuc") ||

            lowerQuery.contains("cài lại") ||

            lowerQuery.contains("cai lai") ||

            lowerQuery.contains("xóa app") ||

            lowerQuery.contains("mất pro") ||

            lowerQuery.contains("bill") ||

            lowerQuery.contains("hóa đơn") ||

            lowerQuery.contains("key") ||

            lowerQuery.contains("mã kích hoạt") ||

            lowerQuery.contains("50k") ||

            lowerQuery.contains("100k") ||

            lowerQuery.contains("50.000") ||

            lowerQuery.contains("100.000") ||

            lowerQuery.contains("đổi máy") ||

            lowerQuery.contains("tài khoản")



        // 1. KIỂM TRA TRỰC TIẾP NẾU NGƯỜI DÙNG DÁN MÃ KEY BẢN QUYỀN HỢP LỆ (SHA-256) VÀO KHUNG CHAT

        val keyRegex = Regex("""\b(TKPR-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}|[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4})\b""", RegexOption.IGNORE_CASE)

        val keyMatch = keyRegex.find(trimmedQuery)

        if (keyMatch != null) {

            val candidateKey = keyMatch.value.uppercase()

            if (LicenseManager.verifyLicenseKey(context, candidateKey)) {

                val isAccKey = candidateKey.startsWith("TKPR") || LicenseManager.isAccountProActivated(context)

                val grantResult = LicenseManager.executeVerifiedProGrant(

                    context = context,

                    rawTargetDeviceId = currentDeviceId,

                    grantAccountPro = isAccKey,

                    reason = "CHAT_LICENSE_KEY_VERIFIED"

                )

                val replyMsg = "🎉 Mã khóa bản quyền hợp lệ! Hệ thống đã trực tiếp kích hoạt quyền Pro cho bạn:\n\n${grantResult.summaryMessage}"

                LicenseManager.logAiProChatInteraction(

                    context = context,

                    userMessage = trimmedQuery,

                    aiReply = replyMsg,

                    eventType = "KEY_VERIFIED_PRO",

                    proGranted = grantResult.success,

                    grantedTier = if (grantResult.isAccountPro) "ACCOUNT_PRO" else "DEVICE_PRO",

                    generatedKey = grantResult.generatedKey,

                    targetDeviceId = currentDeviceId

                )

                return@withContext replyMsg

            }

        }



        // 2. NẾU NGƯỜI DÙNG HỎI VỀ PRO / CÀI LẠI APP / CHUYỂN KHOẢN:

        // Tự động đối chiếu trực tiếp trên Firebase (`devices` & `users` - Danh sách tài khoản Pro trong trang Quản Trị)

        // xem thiết bị này đã từng được đăng ký Pro trên Firebase hay chưa!

        val wasProBeforeCheck = LicenseManager.isProActivated(context)

        val isRecognizedOnFirebase = if (isProRelatedQuery || !wasProBeforeCheck) {

            LicenseManager.checkDeviceRecognizedProInCloud(context)

        } else {

            wasProBeforeCheck

        }



        if (!wasProBeforeCheck && isRecognizedOnFirebase) {

            val tierName = if (LicenseManager.isAccountProActivated(context)) "👑 PRO TÀI KHOẢN" else "📱 PRO THIẾT BỊ"

            val permanentKey = LicenseManager.generateLicenseKeyForDevice(currentDeviceId)

            val restoredMsg = "✅ **Hệ thống đã nhận diện thiết bị quen thuộc của bạn trên cơ sở dữ liệu Firebase!**\n\n" +

                "• Mã thiết bị: **$currentDeviceId**\n" +

                "• Gói bản quyền: **$tierName**\n" +

                "• Trạng thái: **ĐÃ TỰ ĐỘNG KHÔI PHỤC & KÍCH HOẠT LẠI 100% QUYỀN PRO!**\n\n" +

                "🔑 **KEY KÍCH HOẠT CỐ ĐỊNH CỦA MÁY:**\n`$permanentKey`\n\n" +

                "💡 **LƯU Ý QUAN TRỌNG:**\n" +

                "1. Mỗi thiết bị chỉ được gắn **MỘT KEY DUY NHẤT**. Hãy sao chép hoặc chụp ảnh lưu giữ Key này vào ghi chú để dùng về sau nếu lỡ cài lại app/mất Pro.\n" +

                "2. Hoặc **ĐĂNG NHẬP TÀI KHOẢN** để thiết bị Pro được ghi nhớ vĩnh viễn vào tài khoản của bạn. Về sau chỉ cần đăng nhập là máy **100% tự động khôi phục Pro** nếu đã từng kích hoạt!"

            LicenseManager.logAiProChatInteraction(

                context = context,

                userMessage = trimmedQuery,

                aiReply = restoredMsg,

                eventType = "CLOUD_FAMILIAR_RESTORED",

                proGranted = true,

                grantedTier = if (LicenseManager.isAccountProActivated(context)) "ACCOUNT_PRO" else "DEVICE_PRO",

                targetDeviceId = currentDeviceId

            )

            return@withContext restoredMsg

        }



        // 3. GIẢI ĐÁP & HƯỚNG DẪN CÁCH LƯU KEY VÀ KHÔI PHỤC PRO 100% KHI CÀI LẠI MÁY

        val isAskingKeyRetentionOrRestore = (

            lowerQuery.contains("lưu key") ||

                lowerQuery.contains("giữ key") ||

                lowerQuery.contains("mất pro") ||

                lowerQuery.contains("khôi phục pro") ||

                lowerQuery.contains("khoi phuc pro") ||

                lowerQuery.contains("cài lại máy") ||

                lowerQuery.contains("cai lai may") ||

                lowerQuery.contains("cách lưu")

        )

        if (isAskingKeyRetentionOrRestore) {

            val isPro = LicenseManager.isProActivated(context)

            val isAccPro = LicenseManager.isAccountProActivated(context)

            val currentTier = if (isAccPro) "👑 PRO TÀI KHOẢN" else if (isPro) "📱 PRO THIẾT BỊ" else "Bản Miễn Phí (Chưa kích hoạt Pro)"

            val keyDisplayLine = if (isPro) {

                val permanentKey = if (isAccPro) {

                    LicenseManager.generateAccountProLicenseKeyForDevice(currentDeviceId)

                } else {

                    LicenseManager.generateLicenseKeyForDevice(currentDeviceId)

                }

                "• **KEY KÍCH HOẠT CỐ ĐỊNH CỦA MÁY:**\n`$permanentKey`\n\n"

            } else {

                "• **KEY KÍCH HOẠT CỐ ĐỊNH CỦA MÁY:** 🔒 *Chưa được cấp (Key sẽ được hệ thống cấp tự động ngay sau khi thiết bị hoàn tất thanh toán nâng cấp Pro)*\n\n"

            }

            val retentionGuide = "🛡️ **HƯỚNG DẪN BẢO LƯU & KHÔI PHỤC PRO 100% VĨNH VIỄN:**\n\n" +

                "• Mã thiết bị: **$currentDeviceId**\n" +

                "• Trạng thái hiện tại: **$currentTier**\n" +

                keyDisplayLine +

                "📌 **2 CÁCH ĐẢM BẢO KHÔNG BAO GIỜ MẤT BẢN QUYỀN PRO (SAU KHI ĐÃ MUA PRO):**\n\n" +

                "1️⃣ **LƯU GIỮ KEY CỐ ĐỊNH CỦA MÁY:**\n" +

                "Mỗi thiết bị đã mua Pro được hệ thống cấp cố định **DUY NHẤT 1 KEY** (không bao giờ thay đổi kể cả khi bạn cài lại ROM hay xóa app). Sau khi nâng cấp Pro, bạn hãy sao chép mã Key hoặc chụp ảnh màn hình lưu vào ứng dụng Ghi chú / Tin nhắn để nhập lại bất cứ lúc nào.\n\n" +

                "2️⃣ **HOẶC BẤM NÚT KHÔI PHỤC 1 CHẠM / ĐĂNG NHẬP TÀI KHOẢN:**\n" +

                "Khi thiết bị đã được kích hoạt Pro trên hệ thống đám mây Firebase, về sau nếu xóa app cài lại bạn chỉ cần bấm nút **☁️ Khôi Phục Pro Tự Động Bằng ID Máy (1 Chạm)** hoặc **Đăng nhập tài khoản** là máy sẽ tự động khôi phục bản Pro!"



            LicenseManager.logAiProChatInteraction(

                context = context,

                userMessage = trimmedQuery,

                aiReply = retentionGuide,

                eventType = "PRO_RETENTION_INQUIRY",

                proGranted = false,

                grantedTier = if (isAccPro) "ACCOUNT_PRO" else if (isPro) "DEVICE_PRO" else "NONE",

                targetDeviceId = currentDeviceId

            )

            return@withContext retentionGuide

        }



        // 4. PHÁT HIỆN NẾU KHÁCH CHƯA THANH TOÁN MÀ NHẮN TIN ĐÒI CẤP PRO / BÁO ĐÃ CHUYỂN KHOẢN BẰNG CHỮ (KHÔNG CÓ ẢNH BILL)

        val claimsPaidOrWantsProGrant = (

            lowerQuery.contains("đã chuyển khoản") ||

                lowerQuery.contains("da chuyen khoan") ||

                lowerQuery.contains("chuyển khoản rồi") ||

                lowerQuery.contains("chuyển tiền rồi") ||

                lowerQuery.contains("mình chuyển rồi") ||

                lowerQuery.contains("em chuyển rồi") ||

                lowerQuery.contains("duyệt pro") ||

                lowerQuery.contains("cấp pro") ||

                lowerQuery.contains("kích hoạt pro giúp") ||

                lowerQuery.contains("lên pro cho mình") ||

                lowerQuery.contains("mở khóa pro")

            )



        if (claimsPaidOrWantsProGrant && !LicenseManager.isProActivated(context)) {

            val bankName = LicenseManager.getPaymentBankName(context)

            val bankAcc = LicenseManager.getPaymentAccountNumber(context)

            val bankHolder = LicenseManager.getPaymentAccountHolder(context)

            val strictReply = "🛡️ **Kiểm tra bảo mật thanh toán trên thiết bị `$currentDeviceId`:**\n\n" +

                "Hệ thống đã tra cứu trực tiếp trên cơ sở dữ liệu Firebase (bao gồm cả **Danh sách Thiết Bị Pro** và **Danh sách Tài Khoản Pro** trong trang Quản Trị), hiện tại thiết bị `$currentDeviceId` **chưa có biên lai thanh toán hoặc bản quyền Pro được xác nhận**.\n\n" +

                "⚠️ **Quy định chống kích hoạt khi chưa thanh toán:** Trợ lý AI **không tự động cấp Pro qua tin nhắn văn bản** nếu chưa có ảnh biên lai chuyển khoản hợp lệ.\n\n" +

                "📌 **Nếu bạn đã chuyển khoản:**\n" +

                "• Hãy bấm vào nút **Hình ảnh 🖼️** ở góc trái khung chat bên dưới và **chọn ảnh chụp màn hình biên lai chuyển khoản (bill)** tới **$bankName — STK: $bankAcc ($bankHolder)**.\n" +

                "• Ngay khi xác thực đúng ảnh biên lai chuyển khoản thành công, hệ thống Auto-Admin sẽ mở khóa Pro tức thì cho bạn!"



            LicenseManager.logAiProChatInteraction(

                context = context,

                userMessage = trimmedQuery,

                aiReply = strictReply,

                eventType = "UNPAID_PRO_REQUEST_BLOCKED",

                proGranted = false,

                grantedTier = "NONE",

                targetDeviceId = currentDeviceId

            )

            return@withContext strictReply

        }



        try {

            val apiKey = LicenseManager.getLoadBalancedGroqApiKey(context).ifBlank {

                try { com.example.BuildConfig.GROQ_API_KEY } catch (_: Throwable) { "" }

            }

            if (apiKey.isBlank() || apiKey == "GROQ_API_KEY_DEFAULT_VALUE") {

                return@withContext "Hệ thống hỗ trợ trực tuyến đang bảo trì kết nối. Bạn vui lòng thử lại sau ít phút hoặc gửi yêu cầu trong mục Tài Khoản nhé!"

            }



            val url = URL("https://api.groq.com/openai/v1/chat/completions")

            val conn = (url.openConnection() as HttpURLConnection).apply {

                requestMethod = "POST"

                doOutput = true

                doInput = true

                connectTimeout = 12_000

                readTimeout = 20_000

                setRequestProperty("Authorization", "Bearer $apiKey")

                setRequestProperty("Content-Type", "application/json; charset=UTF-8")

            }



            val payload = org.json.JSONObject().apply {

                put("model", "qwen/qwen3.8-27b")

                put("temperature", 0.15)

                val messages = org.json.JSONArray()

                messages.put(

                    org.json.JSONObject().apply {

                        put("role", "system")

                        put("content", buildMagicTuneKnowledgePrompt(context))

                    }

                )

                val recentHistory = conversationHistory.dropLast(1).takeLast(6)

                for (item in recentHistory) {

                    messages.put(

                        org.json.JSONObject().apply {

                            put("role", if (item.sender == "user") "user" else "assistant")

                            put("content", item.text)

                        }

                    )

                }

                messages.put(

                    org.json.JSONObject().apply {

                        put("role", "user")

                        put("content", userQuery)

                    }

                )

                put("messages", messages)

            }



            conn.outputStream.use { os ->

                os.write(payload.toString().toByteArray(Charsets.UTF_8))

                os.flush()

            }



            if (conn.responseCode in 200..299) {

                val body = conn.inputStream.bufferedReader().use { it.readText() }

                val root = org.json.JSONObject(body)

                val rawContent = root.optJSONArray("choices")

                    ?.optJSONObject(0)

                    ?.optJSONObject("message")

                    ?.optString("content", "")

                    ?.trim()

                    .orEmpty()



                val grantTagRegex = Regex("""\[\[(GRANT_ACCOUNT_PRO|GRANT_DEVICE_PRO)(?::([A-Z0-9\-]+))?\]\]""", RegexOption.IGNORE_CASE)

                var cleanedReply = rawContent

                    .replace(Regex("<think>[\\s\\S]*?</think>"), "")

                    .replace(grantTagRegex, "")

                    .trim()



                // 4. CHỐT CHẶN CHỐNG BÁO ẢO & CHỐNG CẤP PRO KHI CHƯA THANH TOÁN:

                // Nếu AI lỡ nhắn câu "đã nâng cấp Pro thành công / đã kích hoạt Pro cho bạn"

                // MÀ máy thực tế chưa có Pro -> Chặn ngay câu trả lời ảo và yêu cầu gửi ảnh bill!

                val aiClaimedProGranted = Regex(

                    """(đã\s+(kích\s+hoạt|nâng\s+cấp|cấp|mở\s+khóa|bật)\s+(gói\s+|quyền\s+|bản\s+)?pro|chúc\s+mừng\s+bạn\s+đã\s+lên\s+pro|pro\s+đã\s+được\s+kích\s+hoạt)""",

                    RegexOption.IGNORE_CASE

                ).containsMatchIn(cleanedReply)



                if (aiClaimedProGranted && !LicenseManager.isProActivated(context)) {

                    val bankName = LicenseManager.getPaymentBankName(context)

                    val bankAcc = LicenseManager.getPaymentAccountNumber(context)

                    val bankHolder = LicenseManager.getPaymentAccountHolder(context)

                    cleanedReply = "🔒 **Trạng thái kiểm chứng thực tế trên thiết bị `$currentDeviceId`: CHƯA KÍCH HOẠT PRO.**\n\n" +

                        "Hệ thống chỉ tự động gán và mở khóa quyền Pro khi nhận được **ảnh chụp biên lai chuyển khoản (bill) hợp lệ** hoặc **mã Key bản quyền**.\n\n" +

                        "📌 **Cách kích hoạt Pro tự động:**\n" +

                        "• **Bước 1:** Chuyển khoản tới **$bankName** — STK: **$bankAcc** ($bankHolder):\n" +

                        "  - Gói **Pro Thiết Bị (${LicenseManager.getProPrice(context)})**: Nội dung `$currentDeviceId`\n" +

                        "  - Gói **Pro Tài Khoản (${LicenseManager.getAccountProPrice(context)})**: Nội dung `TKPRO $currentDeviceId`\n" +

                        "• **Bước 2:** Nhấn vào biểu tượng **Hình ảnh 🖼️** ở góc trái khung chat này và gửi ảnh biên lai vừa chuyển khoản để hệ thống kiểm duyệt và kích hoạt Pro ngay!"

                }



                // 5. GHI NHẬT KÝ TRÒ CHUYỆN CẤP PRO ĐỂ ADMIN XEM LẠI VÀ HẬU KIỂM

                if (isProRelatedQuery || aiClaimedProGranted) {

                    LicenseManager.logAiProChatInteraction(

                        context = context,

                        userMessage = trimmedQuery,

                        aiReply = cleanedReply,

                        eventType = if (aiClaimedProGranted && !LicenseManager.isProActivated(context)) "UNPAID_PRO_REQUEST_BLOCKED" else "PRO_INQUIRY",

                        proGranted = false,

                        grantedTier = "NONE",

                        targetDeviceId = currentDeviceId

                    )

                }



                cleanedReply

            } else {

                "Cảm ơn câu hỏi của bạn. Bạn có thể chọn các câu hỏi gợi ý phía trên hoặc gửi ảnh bill chuyển khoản để hệ thống tự động kích hoạt Pro!"

            }

        } catch (_: Throwable) {

            "Cảm ơn bạn đã liên hệ hỗ trợ. Yêu cầu của bạn đã được ghi nhận!"

        }

    }

}

