package com.example.ui.components

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ShizukuInfo
import com.example.ui.theme.MagicBorder
import com.example.ui.theme.MagicCyan
import com.example.ui.theme.MagicEmerald
import com.example.ui.theme.MagicEmeraldLight
import com.example.ui.theme.MagicRose
import com.example.ui.theme.MagicSurfaceCard
import com.example.ui.theme.MagicSurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun ShizukuStatusCard(
    shizukuInfo: ShizukuInfo,
    onRestart: () -> Unit,
    onRequestPermission: () -> Unit,
    onOpenApp: () -> Unit,
    onOpenDirectWlanTab: () -> Unit = onOpenApp,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isShizukuReady = shizukuInfo.isRunning && shizukuInfo.isPermissionGranted
    val isDirectWlanReady = shizukuInfo.serverPid.contains("WLAN", ignoreCase = true)
    val isReady = isShizukuReady || isDirectWlanReady

    val borderColor = when {
        isReady -> MagicEmerald
        shizukuInfo.isRunning -> MagicCyan
        else -> MagicRose.copy(alpha = 0.5f)
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("shizuku_status_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isReady) Brush.linearGradient(listOf(MagicEmerald, MagicCyan))
            else Brush.linearGradient(listOf(borderColor, borderColor.copy(alpha = 0.3f)))
        )
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    StatusIndicator(
                        isRunning = shizukuInfo.isRunning || isDirectWlanReady,
                        isReady = isReady
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = if (isReady) "🟢 Điện Thoại Đã Kết Nối Sẵn Sàng" else "🔴 Trạng Thái Kết Nối Máy",
                            color = TextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = when {
                                isReady -> "Mọi tính năng tự động sửa lỗi đã sẵn sàng sử dụng!"
                                shizukuInfo.isRunning -> "Chỉ cần bấm nút 'Cho Phép Quyền' bên dưới là xong"
                                else -> "Admin đã loại bỏ Shizuku • Vui lòng kết nối trực tiếp mã 6 số"
                            },
                            color = if (isReady) MagicEmeraldLight else TextSecondary,
                            fontSize = 12.5.sp,
                            fontWeight = if (isReady) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }

                IconButton(
                    onClick = {
                        Toast.makeText(
                            context,
                            "🔒 Phương thức Shizuku không ổn định đã bị Admin khóa loại bỏ. Mời bạn dùng Kết Nối Trực Tiếp mã 6 số!",
                            Toast.LENGTH_LONG
                        ).show()
                        onOpenDirectWlanTab()
                    },
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(MagicRose.copy(alpha = 0.15f))
                        .border(1.dp, MagicRose.copy(alpha = 0.6f), CircleShape)
                        .testTag("open_shizuku_app_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Shizuku đã bị khóa",
                        tint = MagicRose,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            AnimatedVisibility(
                visible = !isReady,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    HorizontalDivider(color = MagicBorder.copy(alpha = 0.3f), thickness = 1.dp)

                    // Card cảnh báo đỏ khóa Shizuku
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = MagicRose.copy(alpha = 0.15f)),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MagicRose.copy(alpha = 0.6f))
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = null,
                                tint = MagicRose,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "Kết nối Shizuku không ổn định đã được Admin loại bỏ. Mời bạn sử dụng Kết Nối Trực Tiếp ngay bây giờ!",
                                color = MagicRose,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold,
                                lineHeight = 16.sp
                            )
                        }
                    }

                    if (!shizukuInfo.isRunning) {
                        Button(
                            onClick = onOpenDirectWlanTab,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("quick_restart_shizuku_btn"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MagicRose.copy(alpha = 0.22f),
                                contentColor = MagicRose
                            ),
                            border = androidx.compose.foundation.BorderStroke(1.2.dp, MagicRose)
                        ) {
                            Icon(Icons.Default.Lock, null, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "🔒 SHIZUKU ĐÃ KHÓA • BẤM KẾT NỐI TRỰC TIẾP",
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Black
                            )
                        }

                        Text(
                            text = "Bấm để mở tab Kết Nối Trực Tiếp WLAN ADB (ghép nối mã 6 số siêu ổn định).",
                            color = TextMuted,
                            fontSize = 11.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    } else if (!shizukuInfo.isPermissionGranted) {
                        Button(
                            onClick = onRequestPermission,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("grant_shizuku_perm_btn"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MagicCyan.copy(alpha = 0.2f),
                                contentColor = MagicCyan
                            ),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MagicCyan.copy(alpha = 0.6f))
                        ) {
                            Icon(Icons.Default.Security, null, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "🔑 BẤM CHO PHÉP QUYỀN NGAY",
                                fontSize = 13.5.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatusIndicator(isRunning: Boolean, isReady: Boolean) {
    val color = when {
        isReady -> MagicEmerald
        isRunning -> MagicCyan
        else -> MagicRose
    }

    Box(contentAlignment = Alignment.Center) {
        if (isReady) {
            Box(
                modifier = Modifier
                    .size(20.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.2f))
            )
        }

        Box(
            modifier = Modifier
                .size(12.dp)
                .clip(CircleShape)
                .background(color)
                .border(1.5.dp, Color.White.copy(alpha = 0.25f), CircleShape)
        )
    }
}
