package com.example.core.assistant

import android.content.Intent
import android.speech.RecognitionService

/**
 * Dịch vụ Nhận diện Giọng nói Hệ thống (RecognitionService).
 * Đăng ký MagicTune vào danh sách Đầu vào Giọng nói mặc định của Android / Honor.
 */
class MagicTuneRecognitionService : RecognitionService() {

    override fun onStartListening(recognizerIntent: Intent?, listener: Callback?) {
        // Cho phép hệ thống và ứng dụng gọi nhận diện giọng nói qua MagicTune
    }

    override fun onCancel(listener: Callback?) {}

    override fun onStopListening(listener: Callback?) {}
}
