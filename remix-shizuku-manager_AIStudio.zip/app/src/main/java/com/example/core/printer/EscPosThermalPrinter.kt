package com.example.core.printer

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.Build
import android.os.ParcelFileDescriptor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.net.InetAddress
import java.net.NetworkInterface
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import java.util.UUID
import kotlin.math.roundToInt

enum class ConnectionType {
    WIFI_LAN,
    BLUETOOTH
}

data class PrinterConfig(
    val connectionType: ConnectionType = ConnectionType.WIFI_LAN,
    val ip: String = "192.168.1.200",
    val port: Int = 9100,
    val bluetoothAddress: String = "",
    val paperWidthDots: Int = 576, // 576 dots (K80 - 80mm) hoặc 384 dots (K57 / K58 - 58mm)
    val autoCut: Boolean = true,
    val densityLevel: Int = 3, // 1: Nhạt, 2: Vừa, 3: Đậm nét (mặc định), 4: Rất đậm
    val boldFontDilation: Boolean = false, // Bật làm dày nét ảnh/chữ PDF (+1 dot) như Ctrl+B
    val feedLinesAfterPrint: Int = 1,
    val marginLeftDots: Int = 0,
    val marginRightDots: Int = 0
)

object EscPosThermalPrinter {

    // Standard SPP UUID for Bluetooth Serial Printers
    private val SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    private fun getBluetoothAdapter(context: Context? = null): BluetoothAdapter? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && context != null) {
            val bm = context.getSystemService(android.bluetooth.BluetoothManager::class.java)
            bm?.adapter
        } else {
            @Suppress("DEPRECATION")
            BluetoothAdapter.getDefaultAdapter()
        }
    }


    /**
     * Tạo hóa đơn mẫu để test ngay lập tức mà không cần phải tìm ảnh bên ngoài
     */
    fun createSampleReceiptBitmap(paperWidthDots: Int): Bitmap {
        val width = paperWidthDots
        val height = 480
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        canvas.drawColor(Color.WHITE)

        val paint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
        }

        paint.textSize = 28f
        paint.isFakeBoldText = true
        canvas.drawText("=== MAGICTUNE RECEIPT ===", 20f, 50f, paint)

        paint.textSize = 20f
        paint.isFakeBoldText = false
        canvas.drawText("Thiết bị: Honor GT Pro (MagicOS 11)", 20f, 90f, paint)
        canvas.drawText("Khổ giấy: ${if (paperWidthDots == 576) "K80 (80mm)" else "K57 (58mm)"}", 20f, 125f, paint)
        canvas.drawText("Ngày giờ: 2026-10-24 19:50", 20f, 160f, paint)

        paint.strokeWidth = 2f
        canvas.drawLine(20f, 180f, (width - 20).toFloat(), 180f, paint)

        paint.textSize = 22f
        paint.isFakeBoldText = true
        canvas.drawText("1. Tinh Chỉnh Honor GT Pro       x1", 20f, 220f, paint)
        canvas.drawText("2. Mở Full Thông Báo Zalo/FB    x1", 20f, 260f, paint)
        canvas.drawText("3. Ép 144Hz & Touch Boost        x1", 20f, 300f, paint)

        canvas.drawLine(20f, 320f, (width - 20).toFloat(), 320f, paint)
        paint.textSize = 26f
        paint.isFakeBoldText = true
        canvas.drawText("TỔNG CỘNG: 0 VND (HOÀN TẤT)", 20f, 360f, paint)

        paint.textSize = 18f
        paint.isFakeBoldText = false
        canvas.drawText("Cảm ơn bạn đã sử dụng MagicTune Tool!", 20f, 410f, paint)
        canvas.drawText("----------------------------------------", 20f, 440f, paint)

        return bmp
    }

    /**
     * Kiểm tra ping / kết nối thử tới máy in trước khi in
     */

    /**
     * Tạo Socket kết nối trực tiếp qua giao diện mạng Wi-Fi thực (Hardware Wi-Fi Interface).
     * Giải quyết triệt để vấn đề:
     * 1. Điện thoại bật dữ liệu di động (4G/5G) làm hệ thống ưu tiên định tuyến qua mạng di động, gây lỗi No route to host tới IP Wi-Fi nội bộ.
     * 2. Bộ định tuyến Router/Access Point hoặc Wi-Fi 2.4GHz / 5GHz gặp cơ chế lọc hoặc cô lập client (Client/AP Isolation bypass).
     * 3. Bỏ qua VPN / WARP nếu đang bật.
     */
    fun openRobustSocket(ip: String, port: Int, timeoutMs: Int = 4500, context: Context? = null): Socket {
        val cleanIp = ip.trim()
        val targetAddress = InetSocketAddress(cleanIp, port)

        // Cách 1: Nếu có context, trói buộc socket trực tiếp vào Network Wi-Fi của Android (Network.bindSocket)
        if (context != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
                if (cm != null) {
                    @Suppress("DEPRECATION")
                    val allNetworks = cm.allNetworks
                    for (network in allNetworks) {
                        val caps = cm.getNetworkCapabilities(network)
                        if (caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                            // Tạo socket trực tiếp từ đối tượng Network Wi-Fi hoặc bindSocket
                            val socket = network.socketFactory.createSocket()
                            socket.tcpNoDelay = true
                            socket.keepAlive = true
                            socket.connect(targetAddress, timeoutMs)
                            return socket
                        }
                    }
                }
            } catch (_: Exception) {}
        }

        // Cách 2: Tìm địa chỉ IP cục bộ thuộc mạng Wi-Fi và Bind Socket vào địa chỉ này (Source IP Binding)
        try {
            var localWifiAddress: InetAddress? = null
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val iface = interfaces.nextElement()
                if (iface.isUp && !iface.isLoopback && (iface.name.contains("wlan", true) || iface.name.contains("eth", true))) {
                    val addrs = iface.inetAddresses
                    while (addrs.hasMoreElements()) {
                        val a = addrs.nextElement()
                        if (a is java.net.Inet4Address && !a.isLoopbackAddress) {
                            localWifiAddress = a
                            break
                        }
                    }
                }
                if (localWifiAddress != null) break
            }

            val socket = Socket()
            socket.tcpNoDelay = true
            socket.keepAlive = true
            if (localWifiAddress != null) {
                try {
                    socket.bind(InetSocketAddress(localWifiAddress, 0))
                } catch (_: Exception) {}
            }
            socket.connect(targetAddress, timeoutMs)
            return socket
        } catch (e: Exception) {
            // Cách 3: Fallback socket tiêu chuẩn với timeout dài hơn
            val fallbackSocket = Socket()
            fallbackSocket.tcpNoDelay = true
            fallbackSocket.connect(targetAddress, timeoutMs)
            return fallbackSocket
        }
    }

    suspend fun testConnection(config: PrinterConfig, context: Context? = null): Result<String> = withContext(Dispatchers.IO) {
        if (config.connectionType == ConnectionType.BLUETOOTH) {
            if (config.bluetoothAddress.isBlank()) {
                return@withContext Result.failure(Exception("Chưa chọn máy in Bluetooth nào."))
            }
            try {
                val btAdapter = getBluetoothAdapter(context)
                    ?: return@withContext Result.failure(Exception("Điện thoại không có Bluetooth"))
                val dev = btAdapter.getRemoteDevice(config.bluetoothAddress)
                val socket = dev.createRfcommSocketToServiceRecord(SPP_UUID)
                socket.connect()
                socket.close()
                Result.success("Kết nối Bluetooth tới [${dev.name ?: dev.address}] THÀNH CÔNG!")
            } catch (e: Exception) {
                Result.failure(Exception("Không thể kết nối Bluetooth tới máy in: ${e.localizedMessage ?: e.message}"))
            }
        } else {
            val ip = config.ip.trim()
            val port = config.port
            if (ip.isBlank()) {
                return@withContext Result.failure(Exception("Địa chỉ IP máy in không được để trống."))
            }
            try {
                val socket = openRobustSocket(ip, port, 4500, context)
                socket.close()
                Result.success("Kết nối Wi-Fi/LAN tới [$ip:$port] THÀNH CÔNG!")
            } catch (e: Exception) {
                // Thử thêm cổng phụ (9100, 9101, 80) nếu cổng hiện tại không bắt được
                val altPorts = listOf(9100, 9101, 80).filter { it != port }
                var altFoundPort: Int? = null
                for (altP in altPorts) {
                    try {
                        val testSock = openRobustSocket(ip, altP, 1500, context)
                        testSock.close()
                        altFoundPort = altP
                        break
                    } catch (_: Exception) {}
                }

                if (altFoundPort != null) {
                    Result.success("ĐÃ TÌM THẤY MÁY IN! Máy in tại IP $ip đang mở ở CỔNG $altFoundPort (thay vì $port). Vui lòng đổi cổng sang $altFoundPort!")
                } else {
                    val msg = e.localizedMessage ?: e.message.orEmpty()
                    val hint = when {
                        msg.contains("EHOSTUNREACH", true) || msg.contains("No route to host", true) ->
                            "Lỗi EHOSTUNREACH: Điện thoại không tìm thấy máy in tại $ip! Hãy kiểm tra: 1. Điện thoại có đang kết nối cùng mạng Wi-Fi với máy in không? 2. Bộ phát Wi-Fi có đang bật 'Cách ly AP / Client Isolation' không?"
                        msg.contains("ECONNREFUSED", true) || msg.contains("Connection refused", true) ->
                            "Lỗi ECONNREFUSED: IP $ip phản hồi nhưng Cổng $port bị đóng. Vui lòng kiểm tra cổng máy in (mặc định K80 là 9100)."
                        msg.contains("timeout", true) ->
                            "Hết thời gian chờ kết nối (Timeout) tới $ip:$port. Hãy bật nguồn máy in hoặc bấm nút in bản in tự kiểm tra (Self-test) trên máy in để xem đúng IP."
                        else -> "Lỗi kết nối Wi-Fi [$ip:$port]: $msg"
                    }
                    Result.failure(Exception(hint))
                }
            }
        }
    }

    /**
     * Tự động quét dải mạng Wi-Fi nội bộ (Subnet Discovery) để tìm IP máy in cổng 9100 đang mở
     */
    suspend fun discoverLocalPrinters(defaultPort: Int = 9100, context: Context? = null): List<String> = withContext(Dispatchers.IO) {
        val foundIps = mutableListOf<String>()
        try {
            var localSubnetPrefix: String? = null
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val iface = interfaces.nextElement()
                if (iface.isUp && !iface.isLoopback && (iface.name.contains("wlan", true) || iface.name.contains("eth", true))) {
                    val addrs = iface.inetAddresses
                    while (addrs.hasMoreElements()) {
                        val addr = addrs.nextElement()
                        val host = addr.hostAddress.orEmpty()
                        if (host.matches(Regex("^192\\.168\\.\\d+\\.\\d+$")) || host.matches(Regex("^10\\.\\d+\\.\\d+\\.\\d+$"))) {
                            val lastDot = host.lastIndexOf('.')
                            if (lastDot > 0) {
                                localSubnetPrefix = host.substring(0, lastDot + 1)
                                break
                            }
                        }
                    }
                }
                if (localSubnetPrefix != null) break
            }

            val prefix = localSubnetPrefix ?: "192.168.1."
            // Quét nhanh các IP phổ biến nhất của máy in bill: .200, .199, .100, .88, .250, .150, .50, .2 -> .30
            val candidateHosts = listOf(
                "${prefix}200", "${prefix}199", "${prefix}100", "${prefix}88",
                "${prefix}250", "${prefix}150", "${prefix}50", "${prefix}2"
            ) + (3..25).map { "${prefix}$it" }

            val jobs = candidateHosts.map { host ->
                async {
                    try {
                        val socket = openRobustSocket(host, defaultPort, 450, context)
                        socket.close()
                        host
                    } catch (_: Exception) {
                        null
                    }
                }
            }
            val results = jobs.awaitAll().filterNotNull()
            foundIps.addAll(results)
        } catch (_: Exception) {}
        return@withContext foundIps
    }

    /**
     * Tạo Bitmap hiển thị xem trước theo đúng khổ giấy (K80 / K57) và căn lề tức thì
     */
    /**
     * Tự động cắt bỏ phần khoảng trắng thừa dưới đáy hóa đơn/vận đơn (Auto Trim Bottom White Margin)
     * Tránh in dư giấy dài vô ích khi file ảnh hoặc PDF có khoảng trắng lớn phía dưới.
     */
    fun trimBottomWhiteMargin(bitmap: Bitmap, thresholdLuminance: Int = 245): Bitmap {
        val width = bitmap.width
        val height = bitmap.height
        val rowPixels = IntArray(width)
        var lastContentY = height - 1

        for (y in height - 1 downTo 0) {
            bitmap.getPixels(rowPixels, 0, width, 0, y, width, 1)
            var hasDarkPixel = false
            for (x in 0 until width) {
                val pixel = rowPixels[x]
                val r = (pixel shr 16) and 0xFF
                val g = (pixel shr 8) and 0xFF
                val b = pixel and 0xFF
                val lum = (r * 0.299 + g * 0.587 + b * 0.114).toInt()
                if (lum < thresholdLuminance) {
                    hasDarkPixel = true
                    break
                }
            }
            if (hasDarkPixel) {
                // Thêm 8px lề an toàn dưới cùng
                lastContentY = (y + 8).coerceAtMost(height)
                break
            }
        }

        return if (lastContentY < height && lastContentY > 20) {
            Bitmap.createBitmap(bitmap, 0, 0, width, lastContentY)
        } else {
            bitmap
        }
    }

    fun createPreviewBitmap(
        sourceBitmap: Bitmap,
        paperWidthDots: Int,
        marginLeftDots: Int,
        marginRightDots: Int,
        boldFontDilation: Boolean = false,
        densityLevel: Int = 3
    ): Bitmap {
        val totalWidth = paperWidthDots
        val leftMargin = marginLeftDots.coerceIn(0, totalWidth / 3)
        val rightMargin = marginRightDots.coerceIn(0, totalWidth / 3)
        val printableWidth = (totalWidth - leftMargin - rightMargin).coerceAtLeast(60)

        val scaleFactor = printableWidth.toFloat() / sourceBitmap.width.toFloat()
        val targetHeight = (sourceBitmap.height * scaleFactor).roundToInt().coerceAtLeast(1)
        val scaledContent = Bitmap.createScaledBitmap(sourceBitmap, printableWidth, targetHeight, true)

        val fullPageBitmap = Bitmap.createBitmap(totalWidth, targetHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(fullPageBitmap)
        canvas.drawColor(Color.WHITE)
        canvas.drawBitmap(scaledContent, leftMargin.toFloat(), 0f, Paint(Paint.FILTER_BITMAP_FLAG))
        scaledContent.recycle()
        // Cắt sạch khoảng trắng thừa dưới đáy
        val trimmed = trimBottomWhiteMargin(fullPageBitmap)

        if (!boldFontDilation) {
            return trimmed
        }

        // Mô phỏng hiệu ứng in đậm Dilation trên màn hình xem trước
        return try {
            val w = trimmed.width
            val h = trimmed.height
            val pixels = IntArray(w * h)
            trimmed.getPixels(pixels, 0, w, 0, 0, w, h)
            val threshold = when (densityLevel) {
                1 -> 115
                2 -> 132
                3 -> 148
                4 -> 162
                5 -> 175
                else -> 148
            }
            val blackMatrix = BooleanArray(w * h)
            for (y in 0 until h) {
                val offset = y * w
                for (x in 0 until w) {
                    val p = pixels[offset + x]
                    val r = (p shr 16) and 0xFF
                    val g = (p shr 8) and 0xFF
                    val b = p and 0xFF
                    val lum = (r * 0.299 + g * 0.587 + b * 0.114).toInt()
                    if (lum < threshold) {
                        blackMatrix[offset + x] = true
                    }
                }
            }
            val boldPixels = IntArray(w * h)
            for (y in 0 until h) {
                val offset = y * w
                for (x in 0 until w) {
                    var isBlack = blackMatrix[offset + x]
                    if (!isBlack && x > 0) {
                        val prevIsBlack = blackMatrix[offset + (x - 1)]
                        val nextIsWhite1 = (x + 1 < w) && !blackMatrix[offset + (x + 1)]
                        val nextIsWhite2 = (x + 2 < w) && !blackMatrix[offset + (x + 2)]
                        if (prevIsBlack && nextIsWhite1 && nextIsWhite2) {
                            isBlack = true
                        }
                    }
                    boldPixels[offset + x] = if (isBlack) Color.BLACK else Color.WHITE
                }
            }
            val dilatedBmp = Bitmap.createBitmap(boldPixels, w, h, Bitmap.Config.ARGB_8888)
            if (trimmed != fullPageBitmap) trimmed.recycle()
            dilatedBmp
        } catch (_: Exception) {
            trimmed
        }
    }

    /**
     * Chuyển đổi Bitmap ảnh hoặc trang PDF sang lệnh in nhiệt ESC/POS (Raster Bit Image GS v 0)
     * Hỗ trợ cả Wi-Fi/LAN Socket và Bluetooth SPP Socket.
     * Có chia khối (Chunking) để không tràn bộ nhớ máy in và in ra ký tự lạ.
     */
    suspend fun printBitmapToEscPos(
        bitmap: Bitmap,
        config: PrinterConfig,
        context: Context? = null
    ): Result<String> = withContext(Dispatchers.IO) {
        var socket: Socket? = null
        var btSocket: BluetoothSocket? = null
        var outputStream: OutputStream? = null

        try {
            if (config.connectionType == ConnectionType.BLUETOOTH) {
                if (config.bluetoothAddress.isBlank()) {
                    return@withContext Result.failure(Exception("Chưa chọn thiết bị máy in Bluetooth"))
                }
                val btAdapter = getBluetoothAdapter(context)
                    ?: return@withContext Result.failure(Exception("Điện thoại không hỗ trợ Bluetooth"))
                val device: BluetoothDevice = btAdapter.getRemoteDevice(config.bluetoothAddress)
                btSocket = device.createRfcommSocketToServiceRecord(SPP_UUID)
                btSocket.connect()
                outputStream = btSocket.outputStream
            } else {
                socket = openRobustSocket(config.ip, config.port, 5500, context)
                outputStream = socket.getOutputStream()
            }

            val out = outputStream ?: return@withContext Result.failure(Exception("Không thể mở luồng dữ liệu tới máy in"))

            // 1. Khởi tạo máy in (ESC @) để xóa sạch dữ liệu đệm cũ
            out.write(byteArrayOf(0x1B, 0x40))
            out.flush()
            delay(30)

            // Thiết lập thông số đốt nóng phần cứng an toàn theo chuẩn ESC/POS (Hardware Heating Duration)
            // n1 = max heating dots (7: 64 dots chuẩn)
            // n2 = heating time (60..127 x 10us). Dưới 128 để không bị tràn số âm byte trong Java/Kotlin!
            // n3 = heating interval (2 x 10us = 20us). Bắt buộc phải nhỏ (2..5) để đầu in GIỮ NHIỆT LIÊN TỤC, không bị nguội giữa các dòng in!
            try {
                val heatDots: Byte = 7 // 8 * (7 + 1) = 64 dots chuẩn
                val heatTime: Byte = when (config.densityLevel) {
                    1 -> 60.toByte()  // 600 µs (Nhạt / Tiết kiệm)
                    2 -> 80.toByte()  // 800 µs (Vừa)
                    3 -> 100.toByte() // 1000 µs (Đậm nét - Chuẩn)
                    4 -> 118.toByte() // 1180 µs (Đậm tăng cường)
                    else -> 127.toByte() // 1270 µs (Đậm tối đa an toàn, không tràn số)
                }
                val heatInterval: Byte = 2.toByte() // 20 µs: Không ngắt quãng, giữ nhiệt liên tục cho giấy nhiệt lên màu đen tuyền
                out.write(byteArrayOf(0x1B, 0x37, heatDots, heatTime, heatInterval))
                out.flush()
            } catch (_: Exception) {}

            // 2. Xử lý căn lề (Margin) và Scale ảnh vừa khít khổ giấy (K80 576 dots / K57 384 dots)
            // LƯU Ý: Tuyệt đối không gửi lệnh Density GS ( K vì nhiều máy in mini hiểu nhầm thành chữ in rác
            val totalWidth = config.paperWidthDots
            val fullPageBitmap = createPreviewBitmap(
                sourceBitmap = bitmap,
                paperWidthDots = totalWidth,
                marginLeftDots = config.marginLeftDots,
                marginRightDots = config.marginRightDots
            )
            val targetHeight = fullPageBitmap.height

            // 3. In theo từng dải nhỏ (Chunked Raster GS v 0) kèm pacing delay để không làm tràn bộ đệm máy in
            val maxChunkHeight = if (config.connectionType == ConnectionType.BLUETOOTH) 80 else 160
            val chunkDelayMs = if (config.connectionType == ConnectionType.BLUETOOTH) 25L else 12L
            var currentY = 0
            while (currentY < targetHeight) {
                val chunkH = (targetHeight - currentY).coerceAtMost(maxChunkHeight)
                val chunkBitmap = Bitmap.createBitmap(fullPageBitmap, 0, currentY, totalWidth, chunkH)
                val rasterChunk = convertBitmapToRasterEscPos(chunkBitmap, config.densityLevel, config.boldFontDilation)
                chunkBitmap.recycle() // Thu hồi RAM tức thì chống tràn bộ nhớ heap OOM
                out.write(rasterChunk)
                out.flush()
                delay(chunkDelayMs) // Chống tràn buffer máy in tuyệt đối
                currentY += chunkH
            }
            if (!fullPageBitmap.isRecycled && fullPageBitmap != bitmap) {
                fullPageBitmap.recycle()
            }

            // 4. Cuộn giấy ra tối thiểu để tiết kiệm giấy, cắt ngay sau khi hết nội dung in (ESC d n)
            val feedLines = config.feedLinesAfterPrint.coerceIn(0, 10).toByte()
            if (feedLines > 0) {
                out.write(byteArrayOf(0x1B, 0x64, feedLines))
            }

            // 5. Cắt giấy tự động nếu được bật (GS V 66 0: Partial Cut / Full Cut)
            if (config.autoCut) {
                // Lệnh cắt ngay tức thì, không lãng phí giấy
                out.write(byteArrayOf(0x1D, 0x56, 0x42, 0x00))
            }

            out.flush()
            val destName = if (config.connectionType == ConnectionType.BLUETOOTH) "Bluetooth [${config.bluetoothAddress}]" else "Wi-Fi [${config.ip}:${config.port}]"
            Result.success("Đã in xong ra máy in $destName")
        } catch (e: Exception) {
            Result.failure(Exception("Lỗi in (${e.localizedMessage ?: e.message})"))
        } finally {
            try { socket?.close() } catch (_: Exception) {}
            try { btSocket?.close() } catch (_: Exception) {}
        }
    }

    /**
     * Đọc trang đầu tiên của file PDF sang Bitmap độ phân giải cao để in
     */
    fun renderPdfFirstPageToBitmap(context: Context, pdfUri: Uri, targetWidth: Int = 576): Bitmap? {
        return try {
            val pfd: ParcelFileDescriptor? = context.contentResolver.openFileDescriptor(pdfUri, "r")
            pfd?.use { descriptor ->
                val renderer = PdfRenderer(descriptor)
                if (renderer.pageCount > 0) {
                    val page = renderer.openPage(0)
                    val aspectRatio = page.height.toFloat() / page.width.toFloat()
                    val targetHeight = (targetWidth * aspectRatio).roundToInt()
                    val bitmap = Bitmap.createBitmap(targetWidth, targetHeight, Bitmap.Config.ARGB_8888)
                    // Vẽ nền trắng tinh trước khi render PDF
                    val canvas = Canvas(bitmap)
                    canvas.drawColor(Color.WHITE)
                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT)
                    page.close()
                    renderer.close()
                    bitmap
                } else {
                    renderer.close()
                    null
                }
            }
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Thuật toán biến đổi Bitmap ảnh sang dữ liệu Raster ESC/POS Monochrome chuẩn K80
     * Có ngưỡng Dithering để đơn hàng Shopee / TikTok in ra rõ từng mã vạch (Barcode), mã QR và chữ nhỏ
     * - densityLevel 1..4: Điều chỉnh độ đậm quang độ (Luminance Threshold).
     * - boldDilation: Làm dày chữ thông minh. BẢO VỆ MÃ VẠCH & QR: chỉ nở pixel nếu khoảng trắng giữa các vạch đủ rộng,
     *   tuyệt đối không nở vào các kẽ hở hẹp (tránh dính nét barcode/QR code làm máy quét không đọc được).
     */
    private fun convertBitmapToRasterEscPos(bitmap: Bitmap, densityLevel: Int, boldDilation: Boolean = false): ByteArray {
        val width = bitmap.width
        val height = bitmap.height
        val widthBytes = (width + 7) / 8

        val out = ByteArrayOutputStream()

        // Lệnh GS v 0 m xL xH yL yH
        val m: Byte = 0
        val xL = (widthBytes and 0xFF).toByte()
        val xH = ((widthBytes shr 8) and 0xFF).toByte()
        val yL = (height and 0xFF).toByte()
        val yH = ((height shr 8) and 0xFF).toByte()

        out.write(byteArrayOf(0x1D, 0x76, 0x30, m, xL, xH, yL, yH))

        // Tinh chỉnh ngưỡng quang độ (Luminance Threshold) chuẩn quốc tế cho máy in nhiệt:
        // Đảm bảo nét đen sâu, mực nhiệt cháy đều và bảo vệ 100% khoảng trắng của mã QR/Barcode
        val threshold = when (densityLevel) {
            1 -> 115 // Nhạt / Tiết kiệm nhiệt
            2 -> 132 // Vừa (Cân bằng trung tính)
            3 -> 148 // Đậm chuẩn nét hóa đơn & QR (Mặc định tối ưu nhất)
            4 -> 162 // Đậm tăng cường cho giấy nhiệt mờ
            5 -> 175 // Đậm tối đa an toàn (Không bao giờ đẩy lên 200+ gây đen kịt kẽ hở QR)
            else -> 148
        }

        val pixels = IntArray(width * height)
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)

        val blackMatrix = BooleanArray(width * height)
        for (y in 0 until height) {
            val rowOffset = y * width
            for (x in 0 until width) {
                val pixel = pixels[rowOffset + x]
                val r = (pixel shr 16) and 0xFF
                val g = (pixel shr 8) and 0xFF
                val b = pixel and 0xFF
                val luminance = (r * 0.299 + g * 0.587 + b * 0.114).toInt()
                if (luminance < threshold) {
                    blackMatrix[rowOffset + x] = true
                }
            }
        }

        for (y in 0 until height) {
            val rowOffset = y * width
            for (xByte in 0 until widthBytes) {
                var byteVal = 0
                for (bit in 0 until 8) {
                    val x = xByte * 8 + bit
                    if (x < width) {
                        var isBlack = blackMatrix[rowOffset + x]
                        if (!isBlack && boldDilation && x > 0) {
                            val prevIsBlack = blackMatrix[rowOffset + (x - 1)]
                            // BẢO VỆ MÃ QR VÀ MÃ VẠCH TUYỆT ĐỐI:
                            // Kiểm tra trong phạm vi 6 pixel xung quanh: Nếu có các vạch đen trắng xen kẽ liên tục (mẫu hình của QR code hoặc barcode),
                            // TUYỆT ĐỐI KHÔNG làm dày nét để bảo toàn 100% tỷ lệ quét cho camera/máy quét!
                            val isBarcodeOrQrArea = (x + 4 < width) && (
                                (blackMatrix[rowOffset + x + 1] && !blackMatrix[rowOffset + x + 2]) ||
                                (blackMatrix[rowOffset + x + 2] && !blackMatrix[rowOffset + x + 3])
                            )
                            val nextIsWhite1 = (x + 1 < width) && !blackMatrix[rowOffset + (x + 1)]
                            val nextIsWhite2 = (x + 2 < width) && !blackMatrix[rowOffset + (x + 2)]
                            val nextIsWhite3 = (x + 3 < width) && !blackMatrix[rowOffset + (x + 3)]
                            
                            // Chỉ làm nở nét chữ văn bản khi có khoảng trắng đủ rộng (ít nhất 3 pixel liên tiếp) và không phải là vùng mã vạch/QR
                            if (prevIsBlack && !isBarcodeOrQrArea && nextIsWhite1 && nextIsWhite2 && nextIsWhite3) {
                                isBlack = true
                            }
                        }
                        if (isBlack) {
                            // Điểm đen (in nhiệt đốt nóng)
                            byteVal = byteVal or (0x80 shr bit)
                        }
                    }
                }
                out.write(byteVal)
            }
        }

        return out.toByteArray()
    }
}
