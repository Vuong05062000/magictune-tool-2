package com.example.core.service

import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import androidx.annotation.RequiresApi
import com.example.MainActivity
import com.example.core.adb.AdbNsdScanner
import com.example.core.adb.DirectAdbManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import rikka.shizuku.Shizuku

/**
 * Quick Settings Tile (Ô cài đặt nhanh trên thanh trạng thái) cho MagicTune:
 * - Hiển thị trạng thái thực tế của Shizuku / Direct WLAN ADB (UID 2000).
 * - Khi chạm vào: Nếu đã phát hiện cổng `_adb-tls-connect._tcp` qua NsdManager, tự động kết nối
 *   ngay lập tức hoặc mở ứng dụng MagicTune tới thẳng tab Shizuku & WLAN ADB.
 */
@RequiresApi(Build.VERSION_CODES.N)
class MagicTuneTileService : TileService() {

    private val tileScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    override fun onStartListening() {
        super.onStartListening()
        // Khởi chạy quét ngầm NSD khi người dùng kéo thanh thông báo xuống
        val scanner = AdbNsdScanner.getInstance(applicationContext)
        scanner.startDiscovery()
        updateTileState()
    }

    override fun onStopListening() {
        super.onStopListening()
        if (!com.example.core.adb.AdbPairingNotificationManager.isNotificationPairingActive) {
            AdbNsdScanner.getInstance(applicationContext).stopDiscovery()
        }
    }

    override fun onClick() {
        super.onClick()
        val scanner = AdbNsdScanner.getInstance(applicationContext)
        val nsdState = scanner.state.value
        val shellEngine = com.example.core.shell.ShellEngine.getInstance(applicationContext)
        val shellState = shellEngine.state.value

        val shizukuReady = try {
            Shizuku.pingBinder() && Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED
        } catch (_: Throwable) {
            false
        }

        if (!shizukuReady && !shellState.isWirelessAdbConnected && nsdState.connectPort != null) {
            // Tự động kết nối 1-chạm vào cổng NSD vừa tìm thấy qua ShellEngine Singleton
            val port = nsdState.connectPort
            tileScope.launch {
                val connected = shellEngine.connectWirelessAdb(port)
                kotlinx.coroutines.withContext(Dispatchers.Main) {
                    updateTileState()
                    if (!connected) {
                        openMagicTuneShizukuTab()
                    }
                }
            }
            return
        }

        openMagicTuneShizukuTab()
    }

    private fun openMagicTuneShizukuTab() {
        try {
            val intent = Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                putExtra("TARGET_TAB", "SHIZUKU")
            }
            if (Build.VERSION.SDK_INT >= 34) {
                val pendingIntent = android.app.PendingIntent.getActivity(
                    this,
                    0,
                    intent,
                    android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
                )
                startActivityAndCollapse(pendingIntent)
            } else {
                @Suppress("DEPRECATION")
                startActivityAndCollapse(intent)
            }
        } catch (_: Exception) {}
    }

    private fun updateTileState() {
        val tile = qsTile ?: return
        val shellEngine = com.example.core.shell.ShellEngine.getInstance(applicationContext)
        val shizukuReady = try {
            Shizuku.pingBinder() && Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED
        } catch (_: Throwable) {
            false
        }
        val wlanConnected = shellEngine.state.value.isWirelessAdbConnected ||
            DirectAdbManager.getInstance(applicationContext).isConnected
        val nsdConnectPort = AdbNsdScanner.getInstance(applicationContext).state.value.connectPort

        when {
            shizukuReady -> {
                tile.state = Tile.STATE_ACTIVE
                tile.label = "MagicTune: Shizuku OK"
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    tile.subtitle = "UID 2000 Sẵn sàng"
                }
            }
            wlanConnected -> {
                tile.state = Tile.STATE_ACTIVE
                tile.label = "MagicTune: WLAN OK"
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    tile.subtitle = "Direct ADB UID 2000"
                }
            }
            nsdConnectPort != null -> {
                tile.state = Tile.STATE_INACTIVE
                tile.label = "MagicTune: Kết nối $nsdConnectPort"
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    tile.subtitle = "Chạm để kết nối NSD"
                }
            }
            else -> {
                tile.state = Tile.STATE_INACTIVE
                tile.label = "MagicTune ADB"
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    tile.subtitle = "Chạm để mở kết nối"
                }
            }
        }
        tile.updateTile()
    }
}
