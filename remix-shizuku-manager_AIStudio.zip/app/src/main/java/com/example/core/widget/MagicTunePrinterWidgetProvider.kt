package com.example.core.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.example.MainActivity
import com.example.R

class MagicTunePrinterWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        for (appWidgetId in appWidgetIds) {
            updateWidget(context, appWidgetManager, appWidgetId)
        }
    }

    companion object {
        fun updateWidget(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int) {
            val views = RemoteViews(context.packageName, R.layout.widget_printer_quick)

            // 1. Chạm vào thân widget hoặc icon -> Mở nhanh bảng điều khiển máy in K80
            val openIntent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra("TARGET_TAB", "PRINTER")
            }
            val pendingIntent = PendingIntent.getActivity(
                context,
                1002,
                openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_printer_container, pendingIntent)
            views.setOnClickPendingIntent(R.id.widget_printer_open_tab, pendingIntent)
            views.setOnClickPendingIntent(R.id.widget_printer_text_area, pendingIntent)

            // 2. Nút nhỏ "Chọn tệp" -> Mở ngay trình duyệt tệp tin hệ thống để in tức thì
            val pickFileIntent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra("TARGET_TAB", "PRINTER")
                putExtra("ACTION_PICK_FILE", true)
            }
            val pickFilePendingIntent = PendingIntent.getActivity(
                context,
                1005,
                pickFileIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_printer_pick_file, pickFilePendingIntent)

            appWidgetManager.updateAppWidget(appWidgetId, views)
        }
    }
}
