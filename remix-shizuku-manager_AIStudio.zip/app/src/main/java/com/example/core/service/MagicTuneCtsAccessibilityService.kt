﻿package com.example.core.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.accessibilityservice.GestureDescription
import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.provider.Settings
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.example.core.shell.ShellEngine
import java.text.Normalizer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Dịch vụ Trợ năng Chụp Màn Hình Ngầm & Đọc Tọa Độ Văn Bản Tức Thì (MagicTuneCtsAccessibilityService).
 *
 * Hỗ trợ 2 chế độ:
 * 1. Khoanh Tròn Tìm Kiếm & Dịch Tức Thì:
 *    - Tự động bật qua `WRITE_SECURE_SETTINGS`, đọc toàn bộ tọa độ văn bản trên màn hình trong ~8ms,
 *      chụp màn hình qua `takeScreenshot` trong ~80ms, rồi tự động tắt ngay khi đóng màn hình Khoanh Tròn
 *      để các ứng dụng Ngân hàng (MB Bank, Vietcombank, Techcombank, BIDV...) không bao giờ cảnh báo.
 * 2. Chế Độ "Cuộn Đến Đâu Dịch Đến Đó" (Live Scroll Google Translate cho Taobao, 1688, App Ngoại Ngữ):
 *    - Lắng nghe sự kiện cuộn trang (`TYPE_VIEW_SCROLLED` / `TYPE_WINDOW_CONTENT_CHANGED`) theo thời gian thực,
 *      trích xuất tọa độ văn bản + giá tiền (`¥`, `￥`, `元`, `$`, `₩`, `円`) ngay khi người dùng vừa cuộn màn hình
 *      để lớp phủ Google Dịch xuyên thấu hiển thị bản dịch Tiếng Việt + quy đổi tiền VNĐ tức thì mà vẫn cho phép người dùng
 *      chạm, vuốt, cuộn trang, mua hàng trực tiếp trên Taobao / 1688.
 *    - Tự động tắt ngay lập tức nếu phát hiện người dùng mở ứng dụng Ngân hàng.
 */
class MagicTuneCtsAccessibilityService : AccessibilityService() {

    data class ScreenTextNode(
        val text: String,
        val boundsInScreen: Rect
    )

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        try {
            val info = serviceInfo ?: AccessibilityServiceInfo()
            info.eventTypes = AccessibilityEvent.TYPE_VIEW_SCROLLED or
                AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED or
                AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
            info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            info.notificationTimeout = 0L
            info.flags = info.flags or
                AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS or
                AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS
            serviceInfo = info
        } catch (_: Throwable) {}
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString().orEmpty()

        // Bảo vệ tuyệt đối cho các App Ngân Hàng: nếu phát hiện mở app ngân hàng khi đang bật dịch cuộn, tắt ngay lập tức!
        if (pkg.isNotEmpty() && isSensitiveBankingPackage(pkg)) {
            onBankingAppDetectedCallback?.invoke()
            forceDisableServiceNow(applicationContext)
            return
        }

        if (!isLiveScrollTranslateActive) return
        if (pkg == applicationContext.packageName) return

        val type = event.eventType
        if (type == AccessibilityEvent.TYPE_VIEW_SCROLLED ||
            type == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED ||
            type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
        ) {
            onLiveScrollEventCallback?.invoke(type == AccessibilityEvent.TYPE_VIEW_SCROLLED)
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        if (instance === this) {
            instance = null
        }
        super.onDestroy()
    }

    companion object {
        private val helperScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

        @Volatile
        private var instance: MagicTuneCtsAccessibilityService? = null

        @Volatile
        var isLiveScrollTranslateActive: Boolean = false

        @Volatile
        var onLiveScrollEventCallback: ((isScrolling: Boolean) -> Unit)? = null

        @Volatile
        var onBankingAppDetectedCallback: (() -> Unit)? = null

        @Volatile
        var lastCapturedScreenNodes: List<ScreenTextNode> = emptyList()
            private set

        private val bankingPackages = setOf(
            "com.mbmobile",
            "com.VCB",
            "vn.com.techcombank.bb.app",
            "com.vnpay.bidv",
            "com.vietinbank.ipay",
            "com.agribank.agribankplus",
            "com.vpbank.vpbankonline",
            "mobile.acb.com.vn",
            "com.acb.mobile",
            "com.tpb.mb.gprsandroid",
            "vn.shb.mbanking",
            "com.sacombank.ewallet",
            "com.hdbank.mobilebanking",
            "com.ocb.omniextra",
            "vn.com.MSB.smartbanking",
            "vn.com.seabank.mb1",
            "com.vnpay.Eximbank",
            "com.lpbank.lienviet24h",
            "vn.vss.app",
            "gov.vneid",
            "com.dancuquocgia.vneid",
            "vn.gov.canhan.etaxmobile",
            "vn.gov.gdt.etaxmobile",
            "vn.gov.dichvucong",
            "com.vnpt.dvc"
        )

        fun isSensitiveBankingPackage(pkg: String): Boolean {
            val lower = pkg.lowercase()
            return bankingPackages.any { it.trim().equals(lower, ignoreCase = true) } ||
                lower.contains("mbmobile") ||
                lower.contains("techcombank") ||
                lower.contains("vietcombank") ||
                lower.contains("vietinbank") ||
                lower.contains("agribank") ||
                lower.contains("bidv") ||
                lower.contains("vneid") ||
                lower.contains("vssid") ||
                lower.contains("etaxmobile") ||
                lower.contains(".gov.") ||
                lower.contains("dichvucong") ||
                lower.contains("banking")
        }

        fun getActiveForegroundPackage(): String? {
            val svc = instance ?: return null
            try {
                val winList = svc.windows
                if (!winList.isNullOrEmpty()) {
                    for (win in winList) {
                        if (win.isActive || win.isFocused) {
                            val p = win.root?.packageName?.toString()
                            if (!p.isNullOrBlank()) return p
                        }
                    }
                }
            } catch (_: Throwable) {}
            return svc.rootInActiveWindow?.packageName?.toString()
        }

        fun isServiceConnected(): Boolean = instance != null

        /**
         * Tự động kích hoạt `MagicTuneCtsAccessibilityService` bằng quyền `WRITE_SECURE_SETTINGS`
         * (kèm dự phòng qua ShellEngine nếu chưa cấp WRITE_SECURE_SETTINGS).
         */
        fun ensureServiceEnabledViaSecureSettings(context: Context): Boolean {
            if (instance != null) return true
            val component = ComponentName(context.packageName, MagicTuneCtsAccessibilityService::class.java.name)
            val flatName = component.flattenToString()
            val shortName = component.flattenToShortString()

            val enabledDirectly = try {
                val cr = context.contentResolver
                val current = Settings.Secure.getString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
                val parts = current.split(":")
                    .map { it.trim() }
                    .filter { it.isNotEmpty() }
                    .toMutableList()

                if (!parts.contains(flatName) && !parts.contains(shortName)) {
                    parts.add(flatName)
                    val updated = parts.joinToString(":")
                    Settings.Secure.putString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, updated)
                }
                Settings.Secure.putInt(cr, Settings.Secure.ACCESSIBILITY_ENABLED, 1)
                true
            } catch (_: Throwable) {
                false
            }

            if (!enabledDirectly) {
                val shell = ShellEngine.getInstance(context.applicationContext)
                if (shell.state.value.isAdbReady) {
                    helperScope.launch {
                        try {
                            val pkg = context.packageName
                            shell.execute(
                                "pm grant $pkg android.permission.WRITE_SECURE_SETTINGS >/dev/null 2>&1; " +
                                    "cmd appops set $pkg ACCESS_RESTRICTED_SETTINGS allow >/dev/null 2>&1; " +
                                    "cmd appops set $pkg SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1; " +
                                    "settings put secure enabled_accessibility_services '$flatName' >/dev/null 2>&1; " +
                                    "settings put secure accessibility_enabled 1 >/dev/null 2>&1"
                            )
                        } catch (_: Throwable) {}
                    }
                }
            }
            return enabledDirectly
        }

        /**
         * Tự động vô hiệu hóa `MagicTuneCtsAccessibilityService` trong hệ thống (`ENABLED_ACCESSIBILITY_SERVICES`)
         * và gọi `disableSelf()` ngay khi không dùng đến để các ứng dụng Ngân hàng hoạt động 100% bình thường.
         */
        fun disableServiceViaSecureSettings(context: Context) {
            if (isLiveScrollTranslateActive) return
            forceDisableServiceNow(context)
        }

        fun forceDisableServiceNow(context: Context) {
            isLiveScrollTranslateActive = false
            try {
                val cr = context.contentResolver
                val component = ComponentName(context.packageName, MagicTuneCtsAccessibilityService::class.java.name)
                val flatName = component.flattenToString()
                val shortName = component.flattenToShortString()

                val current = Settings.Secure.getString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
                val parts = current.split(":")
                    .map { it.trim() }
                    .filter {
                        it.isNotEmpty() &&
                            it != flatName &&
                            it != shortName &&
                            !it.contains(MagicTuneCtsAccessibilityService::class.java.simpleName)
                    }
                    .toMutableList()

                val updated = parts.joinToString(":")
                Settings.Secure.putString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, updated)
                if (parts.isEmpty()) {
                    Settings.Secure.putInt(cr, Settings.Secure.ACCESSIBILITY_ENABLED, 0)
                }
            } catch (_: Throwable) {}
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    instance?.disableSelf()
                }
                instance = null
            } catch (_: Throwable) {}
        }

        /**
         * Trích xuất toàn bộ văn bản & giá tiền đang hiển thị trên màn hình cùng tọa độ Pixel chính xác
         * trong < 6ms. Tự động ghép nối các node ký hiệu tiền tệ (`¥`, `￥`, `$`, `券后`) và con số nằm cạnh nhau
         * trên Taobao / 1688 (kể cả khi chữ `¥`, phần nguyên `128`, phần thập phân `.50` có kích cỡ font khác nhau).
         */
        fun extractVisibleScreenNodesNow(context: Context): List<ScreenTextNode> {
            val svc = instance ?: return emptyList()
            val dm = context.resources.displayMetrics
            val screenW = dm.widthPixels.coerceAtLeast(1)
            val screenH = dm.heightPixels.coerceAtLeast(1)
            val ownPkg = context.packageName

            val rawNodes = mutableListOf<ScreenTextNode>()
            val visitedRects = HashSet<String>()

            try {
                val roots = mutableListOf<AccessibilityNodeInfo>()
                try {
                    val winList = svc.windows
                    if (!winList.isNullOrEmpty()) {
                        for (win in winList) {
                            val r = win.root ?: continue
                            val pkg = r.packageName?.toString().orEmpty()
                            if (pkg == ownPkg || pkg == "com.android.systemui") continue
                            roots.add(r)
                        }
                    }
                } catch (_: Throwable) {}

                if (roots.isEmpty()) {
                    svc.rootInActiveWindow?.let { r ->
                        val pkg = r.packageName?.toString().orEmpty()
                        if (pkg != ownPkg && pkg != "com.android.systemui") {
                            roots.add(r)
                        }
                    }
                }

                fun traverse(node: AccessibilityNodeInfo?, depth: Int) {
                    if (node == null || depth > 50) return
                    try {
                        if (!node.isVisibleToUser) return

                        val rect = Rect()
                        node.getBoundsInScreen(rect)
                        val validBounds = rect.width() >= 6 &&
                            rect.height() >= 8 &&
                            rect.bottom > 45 &&
                            rect.top < screenH - 30 &&
                            rect.right > 2 &&
                            rect.left < screenW - 2

                        val count = node.childCount
                        var childHasText = false
                        if (count in 1..5) {
                            for (i in 0 until count) {
                                val c = try { node.getChild(i) } catch (_: Throwable) { null } ?: continue
                                val ct = c.text?.toString()?.trim().orEmpty()
                                val cd = c.contentDescription?.toString()?.trim().orEmpty()
                                if (ct.isNotEmpty() || cd.isNotEmpty()) {
                                    childHasText = true
                                    break
                                }
                            }
                        }

                        if (validBounds) {
                            val directText = node.text?.toString()?.trim().orEmpty()
                            val contentDesc = node.contentDescription?.toString()?.trim().orEmpty()
                            val hintText = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                node.hintText?.toString()?.trim().orEmpty()
                            } else ""

                            val chosen = when {
                                directText.isNotEmpty() -> directText
                                contentDesc.isNotEmpty() && (count == 0 || !childHasText) -> contentDesc
                                hintText.isNotEmpty() && count == 0 -> hintText
                                else -> ""
                            }

                            if (chosen.isNotEmpty() && chosen.length <= 260) {
                                val clipped = Rect(
                                    rect.left.coerceIn(0, screenW),
                                    rect.top.coerceIn(0, screenH),
                                    rect.right.coerceIn(0, screenW),
                                    rect.bottom.coerceIn(0, screenH)
                                )
                                if (clipped.width() >= 6 && clipped.height() >= 8 && clipped.height() < (screenH * 0.45f).toInt()) {
                                    val key = "${chosen}_${clipped.left / 5}_${clipped.top / 5}"
                                    if (visitedRects.add(key)) {
                                        rawNodes.add(ScreenTextNode(chosen, clipped))
                                    }
                                }
                            }
                        }

                        for (i in 0 until count) {
                            traverse(node.getChild(i), depth + 1)
                        }
                    } catch (_: Throwable) {}
                }

                for (root in roots) {
                    traverse(root, 0)
                }
            } catch (_: Throwable) {}

            val merged = mergeAdjacentCurrencyAndPriceNodes(rawNodes)
            if (merged.isNotEmpty()) {
                lastCapturedScreenNodes = merged
            }
            return merged
        }

        /**
         * Trên 1688 / Taobao / Pinduoduo, giá chính thường được thiết kế với 3-4 TextView có cỡ chữ khác nhau
         * căn theo chân chữ (bottom baseline):
         *   ["¥" (10sp, thấp)] + ["128" (24sp, cao)] + [".50" (11sp, thấp)] + ["起" / "/件"].
         * Vì phần đỉnh (top) của chữ "128" cao hơn chữ "¥" tới 20-35px, ta gom dòng dựa theo độ giao nhau trục dọc
         * hoặc chân chữ (`bottom` / `centerY`), sau đó sắp xếp trái qua phải để ghép chính xác 100% giá chính trên 1688!
         */
        private fun mergeAdjacentCurrencyAndPriceNodes(nodes: List<ScreenTextNode>): List<ScreenTextNode> {
            if (nodes.size <= 1) return nodes

            // Gom các node nằm trên cùng một dòng ngang (dựa theo giao nhau trục Y hoặc cùng baseline bottom)
            val sortedByCenterY = nodes.sortedWith(compareBy<ScreenTextNode> { it.boundsInScreen.centerY() }.thenBy { it.boundsInScreen.left })
            val rowGroups = mutableListOf<MutableList<ScreenTextNode>>()

            for (node in sortedByCenterY) {
                val r = node.boundsInScreen
                val matchingRow = rowGroups.lastOrNull { group ->
                    val ref = group.first().boundsInScreen
                    val maxH = max(ref.height(), r.height())
                    val verticalOverlap = min(ref.bottom, r.bottom) - max(ref.top, r.top)
                    val sameBaseline = abs(ref.bottom - r.bottom) <= 26
                    val closeCenterY = abs(ref.centerY() - r.centerY()) <= maxH * 0.85f
                    verticalOverlap >= 4 || sameBaseline || closeCenterY
                }
                if (matchingRow != null) {
                    matchingRow.add(node)
                } else {
                    rowGroups.add(mutableListOf(node))
                }
            }

            val currencyPrefixRegex = Regex(
                """^(¥|￥|\$|US\$|₩|€|£|฿|NT\$|RMB|CNY|USD|KRW|JPY|券后|券后价|到手|到手价|折后|折后价|活动价|批发价|起批|原价|一口价|单价|[¥￥\$]\s*\d+([.,]\d+)?)$""",
                RegexOption.IGNORE_CASE
            )
            val numberOrPricePartRegex = Regex(
                """^(\d+([.,]\d+)?(\s*[-~～]\s*[¥￥\$]?\s*\d+([.,]\d+)?)?|\.\d+|,\d+|元|円|원|块|起|起批|/件|/个|/双|/套|/箱|/包|/斤|万|万\+|件起批|[¥￥]\s*\d+.*)$"""
            )

            val merged = mutableListOf<ScreenTextNode>()
            for (row in rowGroups) {
                row.sortBy { it.boundsInScreen.left }
                var i = 0
                while (i < row.size) {
                    var current = row[i]
                    var j = i + 1
                    while (j < row.size) {
                        val next = row[j]
                        val gapX = next.boundsInScreen.left - current.boundsInScreen.right
                        val closeHorizontally = gapX in -24..68

                        val curTrim = current.text.trim()
                        val nextTrim = next.text.trim()

                        val curHasCurrency = curTrim.any { it in "¥￥$₩€£฿元" } || currencyPrefixRegex.matches(curTrim)
                        val curIsNumber = curTrim.matches(Regex("""^[¥￥\$]?\s*\d+([.,]\d+)?$"""))
                        val nextIsPricePart = numberOrPricePartRegex.matches(nextTrim)

                        val shouldMerge = closeHorizontally && (
                            (curHasCurrency && nextIsPricePart) ||
                                (currencyPrefixRegex.matches(curTrim) && (nextIsPricePart || nextTrim.any { it in "¥￥$₩€£฿" })) ||
                                (curIsNumber && (nextTrim.startsWith(".") || nextTrim.matches(Regex("""^(元|円|원|块|起|起批|/件|/个|/双|/套|万)$"""))))
                            )

                        if (shouldMerge) {
                            val noSpace = nextTrim.startsWith(".") ||
                                curTrim.endsWith("¥") ||
                                curTrim.endsWith("￥") ||
                                curTrim.endsWith("$")
                            val joiner = if (noSpace) "" else " "
                            val combinedText = (curTrim + joiner + nextTrim)
                                .replace(Regex("""([¥￥\$₩€£฿])\s+(\d)"""), "$1$2")
                                .replace(Regex("""(\d)\s+\.(\d)"""), "$1.$2")
                            val combinedRect = Rect(
                                min(current.boundsInScreen.left, next.boundsInScreen.left),
                                min(current.boundsInScreen.top, next.boundsInScreen.top),
                                max(current.boundsInScreen.right, next.boundsInScreen.right),
                                max(current.boundsInScreen.bottom, next.boundsInScreen.bottom)
                            )
                            current = ScreenTextNode(combinedText, combinedRect)
                            j++
                        } else {
                            break
                        }
                    }
                    merged.add(current)
                    i = j
                }
            }
            return merged
        }

        /**
         * Chụp màn hình hiện tại + Đọc tức thì toàn bộ tọa độ chữ trên màn hình (<100ms).
         * Giữ dịch vụ trợ năng sẵn sàng trong suốt phiên Khoanh Tròn hoặc Dịch Cuộn Trực Tiếp,
         * và chỉ tự động tắt khi đóng cửa sổ để bảo vệ các App Ngân hàng.
         */
        suspend fun captureScreenOffline(context: Context): Bitmap? = withContext(Dispatchers.IO) {
            return@withContext try {
                if (instance == null) {
                    ensureServiceEnabledViaSecureSettings(context)
                    var waited = 0
                    while (instance == null && waited < 650) {
                        delay(25L)
                        waited += 25
                    }
                }

                val svc = instance ?: return@withContext null

                // Trích xuất toàn bộ tọa độ văn bản trên màn hình ứng dụng phía dưới ngay trước khi chụp (chạy an toàn trên IO)!
                try {
                    val nodes = extractVisibleScreenNodesNow(context)
                    if (nodes.isNotEmpty()) {
                        lastCapturedScreenNodes = nodes
                    }
                } catch (_: Throwable) {}

                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return@withContext null

                withTimeoutOrNull(2500L) {
                    suspendCancellableCoroutine { cont ->
                        try {
                            svc.takeScreenshot(
                                Display.DEFAULT_DISPLAY,
                                svc.mainExecutor,
                                object : TakeScreenshotCallback {
                                    override fun onSuccess(screenshot: ScreenshotResult) {
                                        try {
                                            val hwBuffer = screenshot.hardwareBuffer
                                            val colorSpace = screenshot.colorSpace
                                            val hwBitmap = Bitmap.wrapHardwareBuffer(hwBuffer, colorSpace)
                                            val softwareBitmap = hwBitmap?.copy(Bitmap.Config.ARGB_8888, false)
                                            hwBitmap?.recycle()
                                            hwBuffer.close()
                                            if (cont.isActive) {
                                                cont.resume(softwareBitmap)
                                            }
                                        } catch (_: Throwable) {
                                            if (cont.isActive) cont.resume(null)
                                        }
                                    }

                                    override fun onFailure(errorCode: Int) {
                                        if (cont.isActive) {
                                            cont.resume(null)
                                        }
                                    }
                                }
                            )
                        } catch (_: Throwable) {
                            if (cont.isActive) cont.resume(null)
                        }
                    }
                }
            } catch (_: Throwable) {
                null
            }
        }

        private fun normalizeVi(input: String): String {
            val decomposed = Normalizer.normalize(input.lowercase().trim(), Normalizer.Form.NFD)
            return decomposed
                .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
                .replace('đ', 'd')
                .replace(Regex("[^a-z0-9\\s]"), " ")
                .replace(Regex("\\s+"), " ")
                .trim()
        }

        private suspend fun ensureConnectedInstance(context: Context): MagicTuneCtsAccessibilityService? {
            instance?.let { return it }
            ensureServiceEnabledViaSecureSettings(context)
            var waited = 0
            while (instance == null && waited < 600) {
                delay(25L)
                waited += 25
            }
            return instance
        }

        /**
         * Thực thi thao tác hệ thống toàn cục bằng giọng nói (Back, Home, Recents, Notifications, Quick Settings, Screenshot, Lock Screen)
         * kết hợp dự phòng qua ShellEngine nếu có.
         */
        suspend fun performVoiceGlobalAction(context: Context, globalAction: Int): Boolean {
            val svc = ensureConnectedInstance(context)
            if (svc != null) {
                val ok = try {
                    svc.performGlobalAction(globalAction)
                } catch (_: Throwable) {
                    false
                }
                if (ok) return true
            }

            val shell = ShellEngine.getInstance(context.applicationContext)
            if (shell.state.value.isAdbReady) {
                val cmd = when (globalAction) {
                    GLOBAL_ACTION_BACK -> "input keyevent 4"
                    GLOBAL_ACTION_HOME -> "input keyevent 3"
                    GLOBAL_ACTION_RECENTS -> "input keyevent 187"
                    GLOBAL_ACTION_NOTIFICATIONS -> "cmd statusbar expand-notifications"
                    GLOBAL_ACTION_QUICK_SETTINGS -> "cmd statusbar expand-settings"
                    GLOBAL_ACTION_LOCK_SCREEN -> "input keyevent 26"
                    GLOBAL_ACTION_TAKE_SCREENSHOT -> "input keyevent 120"
                    else -> null
                }
                if (cmd != null) {
                    return try {
                        shell.execute(cmd)
                        true
                    } catch (_: Throwable) {
                        false
                    }
                }
            }
            return false
        }

        /**
         * Thực thi thao tác Cuộn / Vuốt màn hình bằng giọng nói ("DOWN" = xem nội dung bên dưới, "UP" = cuộn lên trên, "LEFT", "RIGHT").
         */
        suspend fun performVoiceScrollOrSwipe(context: Context, direction: String): Boolean {
            val dm = context.resources.displayMetrics
            val w = dm.widthPixels.coerceAtLeast(360)
            val h = dm.heightPixels.coerceAtLeast(640)

            val (startX, startY, endX, endY) = when (direction.uppercase()) {
                "DOWN" -> listOf((w * 0.5f), (h * 0.72f), (w * 0.5f), (h * 0.25f)) // Vuốt từ dưới lên để cuộn xuống
                "UP" -> listOf((w * 0.5f), (h * 0.28f), (w * 0.5f), (h * 0.75f))   // Vuốt từ trên xuống để cuộn lên
                "LEFT" -> listOf((w * 0.82f), (h * 0.5f), (w * 0.18f), (h * 0.5f))
                "RIGHT" -> listOf((w * 0.18f), (h * 0.5f), (w * 0.82f), (h * 0.5f))
                else -> listOf((w * 0.5f), (h * 0.72f), (w * 0.5f), (h * 0.25f))
            }

            val svc = ensureConnectedInstance(context)
            if (svc != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                val dispatched = try {
                    val path = Path().apply {
                        moveTo(startX, startY)
                        lineTo(endX, endY)
                    }
                    val gesture = GestureDescription.Builder()
                        .addStroke(GestureDescription.StrokeDescription(path, 0L, 260L))
                        .build()
                    svc.dispatchGesture(gesture, null, null)
                } catch (_: Throwable) {
                    false
                }
                if (dispatched) return true
            }

            val shell = ShellEngine.getInstance(context.applicationContext)
            if (shell.state.value.isAdbReady) {
                return try {
                    shell.execute(
                        "input swipe ${startX.toInt()} ${startY.toInt()} ${endX.toInt()} ${endY.toInt()} 260"
                    )
                    true
                } catch (_: Throwable) {
                    false
                }
            }
            return false
        }

/**
         * Tìm và bật/tắt công tắc (Switch / CheckBox) của một mục Cài Đặt trên màn hình
         * (ví dụ: Bluetooth, Wi-Fi, Điểm phát sóng, Chế độ máy bay, NFC...).
         * Nếu enable == null -> Đảo ngược trạng thái hiện tại.
         * Nếu enable == true -> Chỉ bấm nếu đang tắt (hoặc chưa bật).
         * Nếu enable == false -> Chỉ bấm nếu đang bật.
         */
        suspend fun toggleSettingSwitchByTitle(context: Context, settingTitle: String, enable: Boolean? = null): Boolean {
            val cleanTitle = settingTitle.trim()
            if (cleanTitle.isEmpty()) return false
            val normTitle = normalizeVi(cleanTitle)

            val svc = ensureConnectedInstance(context) ?: return false
            val ownPkg = context.packageName

            // BẢO VỆ AN TOÀN TUYỆT ĐỐI CHO NGƯỜI DÙNG:
            // Không bao giờ tự động can thiệp chạm/bấm vào các ứng dụng Ngân hàng, Ví điện tử hoặc Cổng Dịch vụ công/VNeID của Nhà Nước!
            val fgPkg = getActiveForegroundPackage().orEmpty()
            if (fgPkg.isNotEmpty() && isSensitiveBankingPackage(fgPkg)) {
                return false
            }

            try {
                val roots = mutableListOf<AccessibilityNodeInfo>()
                try {
                    val winList = svc.windows
                    if (!winList.isNullOrEmpty()) {
                        for (win in winList) {
                            val r = win.root ?: continue
                            if (r.packageName?.toString() != ownPkg) roots.add(r)
                        }
                    }
                } catch (_: Throwable) {}
                if (roots.isEmpty()) {
                    svc.rootInActiveWindow?.let { r ->
                        if (r.packageName?.toString() != ownPkg) roots.add(r)
                    }
                }

                var matchedTitleNode: AccessibilityNodeInfo? = null
                var matchedTitleRect: Rect? = null
                var bestScore = 0

                fun findTitle(node: AccessibilityNodeInfo?, depth: Int) {
                    if (node == null || depth > 45) return
                    try {
                        if (!node.isVisibleToUser) return
                        val rawText = node.text?.toString()?.trim().orEmpty()
                        val rawDesc = node.contentDescription?.toString()?.trim().orEmpty()
                        val cand = if (rawText.isNotEmpty()) rawText else rawDesc
                        if (cand.isNotEmpty()) {
                            val normCand = normalizeVi(cand)
                            val score = when {
                                normCand == normTitle -> 100
                                normCand.contains(normTitle) -> 80
                                normTitle.contains(normCand) && normCand.length >= 3 -> 65
                                else -> 0
                            }
                            if (score > bestScore) {
                                val r = Rect()
                                node.getBoundsInScreen(r)
                                if (r.width() > 4 && r.height() > 4) {
                                    bestScore = score
                                    matchedTitleNode = node
                                    matchedTitleRect = r
                                }
                            }
                        }
                        for (i in 0 until node.childCount) {
                            findTitle(node.getChild(i), depth + 1)
                        }
                    } catch (_: Throwable) {}
                }

                for (root in roots) {
                    findTitle(root, 0)
                }

                val titleNode = matchedTitleNode ?: return false
                val titleRect = matchedTitleRect ?: return false

                // Tìm công tắc Switch nằm cùng một hàng ngang hoặc là con của hàng chứa tiêu đề
                var rowCursor: AccessibilityNodeInfo? = titleNode
                var targetSwitch: AccessibilityNodeInfo? = null
                var hops = 0
                while (rowCursor != null && hops < 5 && targetSwitch == null) {
                    fun findSwitch(n: AccessibilityNodeInfo?, d: Int) {
                        if (n == null || d > 10 || targetSwitch != null) return
                        try {
                            val className = n.className?.toString().orEmpty()
                            val isSwitchLike = n.isCheckable ||
                                className.contains("Switch", ignoreCase = true) ||
                                className.contains("CheckBox", ignoreCase = true) ||
                                className.contains("ToggleButton", ignoreCase = true)
                            if (isSwitchLike) {
                                targetSwitch = n
                                return
                            }
                            for (i in 0 until n.childCount) {
                                findSwitch(n.getChild(i), d + 1)
                            }
                        } catch (_: Throwable) {}
                    }
                    findSwitch(rowCursor, 0)
                    rowCursor = rowCursor.parent
                    hops++
                }

                // Nếu không tìm thấy trong cây cha-con, tìm node switch có cùng dải tọa độ trục Y
                if (targetSwitch == null) {
                    fun findSwitchNearbyY(n: AccessibilityNodeInfo?, d: Int) {
                        if (n == null || d > 35 || targetSwitch != null) return
                        try {
                            if (!n.isVisibleToUser) return
                            val className = n.className?.toString().orEmpty()
                            val isSwitchLike = n.isCheckable ||
                                className.contains("Switch", ignoreCase = true) ||
                                className.contains("CheckBox", ignoreCase = true)
                            if (isSwitchLike) {
                                val sr = Rect()
                                n.getBoundsInScreen(sr)
                                val verticalOverlap = min(titleRect.bottom, sr.bottom) - max(titleRect.top, sr.top)
                                val centerYDiff = abs(titleRect.centerY() - sr.centerY())
                                if (verticalOverlap >= 4 || centerYDiff <= titleRect.height() * 0.85f) {
                                    targetSwitch = n
                                    return
                                }
                            }
                            for (i in 0 until n.childCount) {
                                findSwitchNearbyY(n.getChild(i), d + 1)
                            }
                        } catch (_: Throwable) {}
                    }
                    for (root in roots) {
                        findSwitchNearbyY(root, 0)
                    }
                }

                val switchNode = targetSwitch
                if (switchNode != null) {
                    @Suppress("DEPRECATION") val isChecked = switchNode.isChecked
                    if (enable != null && isChecked == enable) {
                        return true // Đã đúng trạng thái mong muốn
                    }
                    var clickTarget: AccessibilityNodeInfo? = switchNode
                    var cHop = 0
                    while (clickTarget != null && cHop < 4) {
                        if (clickTarget.isClickable) {
                            if (clickTarget.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                                return true
                            }
                        }
                        clickTarget = clickTarget.parent
                        cHop++
                    }
                    if (switchNode.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                        return true
                    }
                }

                // Nếu không bấm được trực tiếp switch, bấm vào chính dòng tiêu đề
                var clickLine: AccessibilityNodeInfo? = titleNode
                var lHop = 0
                while (clickLine != null && lHop < 4) {
                    if (clickLine.isClickable) {
                        if (clickLine.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                            return true
                        }
                    }
                    clickLine = clickLine.parent
                    lHop++
                }
                return titleNode.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            } catch (_: Throwable) {
                return false
            }
        }

        /**
         * Tìm và chạm vào nút / thành phần giao diện trên màn hình có tên khớp với câu lệnh giọng nói
         * (ví dụ: "Bấm vào Tìm kiếm", "Nhấn vào Mua ngay", "Chọn Đăng nhập").
         */
        suspend fun clickScreenElementByVoiceText(context: Context, targetQuery: String): Boolean {
            val cleanQuery = targetQuery.trim()
            if (cleanQuery.isEmpty()) return false
            val normQuery = normalizeVi(cleanQuery)
            if (normQuery.isEmpty()) return false

            val svc = ensureConnectedInstance(context) ?: return false
            val ownPkg = context.packageName

            // BẢO VỆ AN TOÀN TUYỆT ĐỐI CHO NGƯỜI DÙNG:
            // Không bao giờ tự động can thiệp chạm/bấm vào các ứng dụng Ngân hàng, Ví điện tử hoặc Cổng Dịch vụ công/VNeID của Nhà Nước!
            val fgPkg = getActiveForegroundPackage().orEmpty()
            if (fgPkg.isNotEmpty() && isSensitiveBankingPackage(fgPkg)) {
                return false
            }

            var bestNode: AccessibilityNodeInfo? = null
            var bestRect: Rect? = null
            var bestScore = 0

            try {
                val roots = mutableListOf<AccessibilityNodeInfo>()
                try {
                    val winList = svc.windows
                    if (!winList.isNullOrEmpty()) {
                        for (win in winList) {
                            val r = win.root ?: continue
                            val pkg = r.packageName?.toString().orEmpty()
                            if (pkg == ownPkg) continue
                            roots.add(r)
                        }
                    }
                } catch (_: Throwable) {}
                if (roots.isEmpty()) {
                    svc.rootInActiveWindow?.let { r ->
                        if (r.packageName?.toString() != ownPkg) roots.add(r)
                    }
                }

                fun searchNodes(node: AccessibilityNodeInfo?, depth: Int) {
                    if (node == null || depth > 45) return
                    try {
                        if (!node.isVisibleToUser) return
                        val rawText = node.text?.toString()?.trim().orEmpty()
                        val rawDesc = node.contentDescription?.toString()?.trim().orEmpty()
                        val rawHint = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) node.hintText?.toString()?.trim().orEmpty() else ""
                        val candidates = listOf(rawText, rawDesc, rawHint).filter { it.isNotBlank() }
                        for (candidate in candidates) {
                            val normCand = normalizeVi(candidate)
                            val candWords = normCand.split(" ").filter { it.isNotBlank() }
                            val queryWords = normQuery.split(" ").filter { it.isNotBlank() }
                            val matchedWordsCount = queryWords.count { qw -> candWords.any { cw -> cw == qw || cw.startsWith(qw) } }

                            val score = when {
                                normCand == normQuery -> 100
                                normCand.startsWith(normQuery) -> 90
                                normCand.contains(normQuery) -> 80
                                normQuery.contains(normCand) && normCand.length >= 2 -> 70
                                matchedWordsCount > 0 && queryWords.isNotEmpty() -> (matchedWordsCount * 60) / queryWords.size
                                else -> 0
                            }
                            if (score > bestScore) {
                                val r = Rect()
                                node.getBoundsInScreen(r)
                                if (r.width() > 4 && r.height() > 4) {
                                    bestScore = score
                                    bestNode = node
                                    bestRect = r
                                }
                            }
                        }
                        for (i in 0 until node.childCount) {
                            searchNodes(node.getChild(i), depth + 1)
                        }
                    } catch (_: Throwable) {}
                }

                for (root in roots) {
                    searchNodes(root, 0)
                }

                val targetNode = bestNode
                val targetRect = bestRect
                if (targetNode != null) {
                    var clickableCursor: AccessibilityNodeInfo? = targetNode
                    var hops = 0
                    while (clickableCursor != null && hops < 6) {
                        if (clickableCursor.isClickable) {
                            if (clickableCursor.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                                return true
                            }
                        }
                        clickableCursor = clickableCursor.parent
                        hops++
                    }
                    if (targetNode.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                        return true
                    }
                }

                if (targetRect != null) {
                    val cx = targetRect.centerX().toFloat()
                    val cy = targetRect.centerY().toFloat()
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        val tapped = try {
                            val path = Path().apply { moveTo(cx, cy) }
                            val gesture = GestureDescription.Builder()
                                .addStroke(GestureDescription.StrokeDescription(path, 0L, 65L))
                                .build()
                            svc.dispatchGesture(gesture, null, null)
                        } catch (_: Throwable) {
                            false
                        }
                        if (tapped) return true
                    }
                    val shell = ShellEngine.getInstance(context.applicationContext)
                    if (shell.state.value.isAdbReady) {
                        shell.execute("input tap ${cx.toInt()} ${cy.toInt()}")
                        return true
                    }
                }
            } catch (_: Throwable) {}
            return false
        }

        /**
         * Tự động bấm vào video/kết quả đầu tiên trên màn hình (đặc biệt hữu ích khi vừa mở YouTube hoặc danh sách kết quả tìm kiếm).
         * Tìm các container có thể nhấp chuột hoặc có hình thu nhỏ / tiêu đề video và thực hiện click mượt mà.
         */
        suspend fun clickFirstVideoOrContentCard(context: Context): Boolean {
            val svc = ensureConnectedInstance(context) ?: return false
            val ownPkg = context.packageName
            val fgPkg = getActiveForegroundPackage().orEmpty()
            if (fgPkg.isNotEmpty() && isSensitiveBankingPackage(fgPkg)) return false

            val dm = context.resources.displayMetrics
            val screenW = dm.widthPixels.coerceAtLeast(1)
            val screenH = dm.heightPixels.coerceAtLeast(1)

            try {
                val roots = mutableListOf<AccessibilityNodeInfo>()
                try {
                    val winList = svc.windows
                    if (!winList.isNullOrEmpty()) {
                        for (win in winList) {
                            val r = win.root ?: continue
                            if (r.packageName?.toString() != ownPkg && r.packageName?.toString() != "com.android.systemui") {
                                roots.add(r)
                            }
                        }
                    }
                } catch (_: Throwable) {}
                if (roots.isEmpty()) {
                    svc.rootInActiveWindow?.let { r ->
                        if (r.packageName?.toString() != ownPkg && r.packageName?.toString() != "com.android.systemui") {
                            roots.add(r)
                        }
                    }
                }

                var candidateClickable: AccessibilityNodeInfo? = null
                var candidateRect: Rect? = null
                var bestY = Int.MAX_VALUE

                fun findFirstCard(node: AccessibilityNodeInfo?, depth: Int) {
                    if (node == null || depth > 35) return
                    try {
                        if (!node.isVisibleToUser) return
                        val r = Rect()
                        node.getBoundsInScreen(r)

                        // Bỏ qua thanh tìm kiếm / thanh trạng thái phía trên đỉnh (ví dụ < 180px)
                        val isBelowTopBar = r.top >= (screenH * 0.12f).toInt()
                        val isInsideScreen = r.bottom <= screenH && r.left >= 0 && r.right <= screenW
                        val isGoodSize = r.width() >= (screenW * 0.45f).toInt() && r.height() >= 120

                        val viewId = node.viewIdResourceName?.lowercase(java.util.Locale.ROOT).orEmpty()
                        val className = node.className?.toString().orEmpty()
                        val isVideoLikeId = viewId.contains("thumbnail") || viewId.contains("video") || viewId.contains("content") || viewId.contains("player") || viewId.contains("card") || viewId.contains("item")

                        if (isBelowTopBar && isInsideScreen && (node.isClickable || isVideoLikeId || isGoodSize)) {
                            if (r.top < bestY && r.top > 100) {
                                bestY = r.top
                                candidateClickable = node
                                candidateRect = r
                            }
                        }

                        for (i in 0 until node.childCount) {
                            findFirstCard(node.getChild(i), depth + 1)
                        }
                    } catch (_: Throwable) {}
                }

                for (root in roots) {
                    findFirstCard(root, 0)
                }

                if (candidateClickable != null) {
                    var cursor: AccessibilityNodeInfo? = candidateClickable
                    var hops = 0
                    while (cursor != null && hops < 5) {
                        if (cursor.isClickable && cursor.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                            return true
                        }
                        cursor = cursor.parent
                        hops++
                    }
                }

                if (candidateRect != null) {
                    val cx = candidateRect.centerX().toFloat()
                    val cy = candidateRect.centerY().toFloat()
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        val path = Path().apply { moveTo(cx, cy) }
                        val gesture = GestureDescription.Builder()
                            .addStroke(GestureDescription.StrokeDescription(path, 0L, 65L))
                            .build()
                        val dispatched = svc.dispatchGesture(gesture, null, null)
                        if (dispatched) return true
                    }
                    val shell = ShellEngine.getInstance(context.applicationContext)
                    if (shell.state.value.isAdbReady) {
                        shell.execute("input tap ${cx.toInt()} ${cy.toInt()}")
                        return true
                    }
                }
            } catch (_: Throwable) {}
            return false
        }
    }
}
