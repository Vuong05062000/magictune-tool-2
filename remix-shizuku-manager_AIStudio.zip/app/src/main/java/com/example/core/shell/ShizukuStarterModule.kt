package com.example.core.shell

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import com.example.core.adb.AdbNsdScanner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.File

/**
 * Module quan trọng bổ sung cho hệ sinh thái Shizuku & ADB trên MagicTune:
 * 1. Khởi chạy trực tiếp Shizuku Server Daemon (libshizuku.so / start.sh) ngay từ kết nối
 *    Direct WLAN ADB hoặc Root của MagicTune mà không cần mở app Shizuku để ghép nối lại.
 * 2. Mở khóa "Cài đặt bị hạn chế" (ACCESS_RESTRICTED_SETTINGS) của Android 13 / 14 / 15+
 *    cho toàn bộ ứng dụng người dùng để bật Trợ năng (Accessibility) & Đọc thông báo không bị làm mờ.
 * 3. Giữ kết nối Gỡ lỗi qua Wi-Fi luôn sống (chống tự tắt sau 7 ngày hoặc khi khóa màn hình trên MagicOS).
 */
object ShizukuStarterModule {

    private const val SHIZUKU_PKG = "moe.shizuku.privileged.api"

    /**
     * Khởi chạy trực tiếp Shizuku Server bằng quyền UID 2000 (Direct WLAN ADB) hoặc UID 0 (Root).
     */
    suspend fun startShizukuServerViaAdb(
        context: Context,
        shellEngine: ShellEngine
    ): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        // Kiểm tra nếu Shizuku đã chạy sẵn
        val alreadyRunning = try {
            Shizuku.pingBinder()
        } catch (_: Throwable) {
            false
        }
        if (alreadyRunning) {
            shellEngine.refreshStatus()
            return@withContext true to "Shizuku Server đã hoạt động sẵn (Binder Alive - UID ${try { Shizuku.getUid() } catch (_: Throwable) { 2000 }})."
        }

        // Nếu chưa kết nối Direct WLAN ADB mà NSD đã phát hiện cổng _adb-tls-connect._tcp thì tự động kết nối trước
        if (!shellEngine.state.value.isAdbReady) {
            val nsdPort = AdbNsdScanner.getInstance(context).state.value.connectPort
            if (nsdPort != null && nsdPort > 0) {
                shellEngine.connectWirelessAdb(nsdPort)
                delay(400)
            }
        }

        if (!shellEngine.state.value.isAdbReady) {
            return@withContext false to "Cần kết nối Direct WLAN ADB (Bản 2) hoặc Root trước để kích hoạt chéo Shizuku Server!"
        }

        // Tìm đường dẫn thực thi của Shizuku trên thiết bị
        val starterCommand = resolveShizukuStarterCommand(context)
            ?: return@withContext false to "Không tìm thấy ứng dụng Shizuku ($SHIZUKU_PKG). Vui lòng cài đặt ứng dụng Shizuku trước!"

        val res = shellEngine.execute(starterCommand)
        // Đợi binder của Shizuku khởi chạy và đăng ký với ServiceManager
        repeat(8) {
            delay(350)
            val alive = try {
                Shizuku.pingBinder()
            } catch (_: Throwable) {
                false
            }
            if (alive) {
                shellEngine.refreshStatus()
                return@withContext true to "🚀 Đã kích hoạt thành công Shizuku Server trực tiếp từ MagicTune! (Binder Alive)"
            }
        }

        shellEngine.refreshStatus()
        val detail = res.combinedOutput.ifBlank { "Exit code ${res.exitCode}" }
        return@withContext if (res.isSuccess) {
            true to "Đã gửi lệnh khởi chạy Shizuku Server: $detail"
        } else {
            false to "Không thể khởi chạy Shizuku Server: ${res.errorReason}"
        }
    }

    /**
     * Dò tìm đường dẫn `libshizuku.so` trong thư mục nativeLibraryDir của Shizuku
     * hoặc file `start.sh` tiêu chuẩn của Shizuku.
     */
    private fun resolveShizukuStarterCommand(context: Context): String? {
        try {
            val appInfo = context.packageManager.getApplicationInfo(SHIZUKU_PKG, 0)
            val nativeDir = appInfo.nativeLibraryDir
            if (!nativeDir.isNullOrBlank()) {
                val libSo = File(nativeDir, "libshizuku.so")
                if (libSo.exists()) {
                    return "${libSo.absolutePath} >/dev/null 2>&1 &"
                }
                return "$nativeDir/libshizuku.so >/dev/null 2>&1 &"
            }
        } catch (_: PackageManager.NameNotFoundException) {
            return null
        } catch (_: Throwable) {}

        // Fallback: Tìm bằng lệnh pm path qua shell và gọi libshizuku.so hoặc start.sh
        return "sh /data/local/tmp/start.sh >/dev/null 2>&1 || " +
            "sh /sdcard/Android/data/$SHIZUKU_PKG/start.sh >/dev/null 2>&1 || " +
            "sh /storage/emulated/0/Android/data/$SHIZUKU_PKG/start.sh >/dev/null 2>&1"
    }

    /**
     * Mở khóa "Cài đặt bị hạn chế" (ACCESS_RESTRICTED_SETTINGS) trên Android 13 / 14 / 15+
     * cho toàn bộ ứng dụng người dùng, giúp bật Trợ năng (Accessibility) và Đọc thông báo ngay lập tức.
     */
    suspend fun unlockRestrictedSettingsAllApps(
        context: Context,
        shellEngine: ShellEngine
    ): Pair<Int, Int> = withContext(Dispatchers.IO) {
        val pm = context.packageManager
        val installed = try {
            pm.getInstalledApplications(PackageManager.GET_META_DATA)
        } catch (_: Exception) {
            emptyList()
        }

        val userPackages = installed
            .filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 || it.packageName == context.packageName }
            .map { it.packageName }
            .distinct()

        var successCount = 0
        val batchCmds = mutableListOf<String>()

        // Luôn ưu tiên mở khóa cho chính MagicTune và các công cụ hệ sinh thái
        val priorityPackages = (listOf(
            context.packageName,
            SHIZUKU_PKG,
            "io.github.samolego.canta",
            "com.aistra.hail",
            "rikka.appops"
        ) + userPackages).distinct()

        for (pkg in priorityPackages) {
            batchCmds.add("appops set $pkg ACCESS_RESTRICTED_SETTINGS allow")
            batchCmds.add("appops set $pkg SYSTEM_ALERT_WINDOW allow")
        }

        // Chạy theo cụm để tối ưu tốc độ
        for (chunk in batchCmds.chunked(12)) {
            val joined = chunk.joinToString(" ; ")
            val res = shellEngine.execute(joined)
            if (res.exitCode == 0) {
                successCount += chunk.size / 2
            }
        }

        return@withContext successCount to priorityPackages.size
    }

    /**
     * Giữ kết nối Gỡ lỗi Wi-Fi và ADB không bị tự động ngắt khi tắt màn hình hoặc quá hạn 7 ngày.
     */
    suspend fun keepWirelessDebuggingImmortal(shellEngine: ShellEngine): Boolean = withContext(Dispatchers.IO) {
        val cmds = listOf(
            "settings put global adb_allowed_connection_time 0",
            "settings put global adb_wifi_enabled 1",
            "settings put global adb_enabled 1",
            "settings put secure adb_charging_only 0",
            "settings put global stay_on_while_plugged_in 7"
        )
        val res = shellEngine.execute(cmds.joinToString(" ; "))
        res.isSuccess
    }
}
