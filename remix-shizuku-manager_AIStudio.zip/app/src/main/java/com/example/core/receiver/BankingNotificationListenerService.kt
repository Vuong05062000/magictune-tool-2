package com.example.core.receiver

import android.content.Context
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * BankingNotificationListenerService:
 * Unused stub service after removal of automatic bank balance reading features for user privacy.
 */
class BankingNotificationListenerService : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        // Disabled for user privacy
    }

    companion object {
        fun isNotificationAccessGranted(context: Context): Boolean {
            return false
        }

        suspend fun tryAutoGrantOrOpenSettings(context: Context): Boolean {
            return false
        }

        fun openNotificationAccessSettings(context: Context) {}

        fun isVerifiedBankingPackage(packageName: String): Boolean = false

        fun isBankingAppOrTransaction(packageName: String, text: String): Boolean = false
    }
}
