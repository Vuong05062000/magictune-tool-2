﻿package com.example.core.license

import android.content.Context
import android.os.Build
import android.provider.Settings
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import android.media.MediaDrm
import android.util.Base64
import java.util.UUID
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

/**
 * LicenseManager: Quản lý kích hoạt bản PRO bảo mật cao (SHA-256 + Cloud Firestore Sync + Real-time Admin Revocation)
 * Đảm bảo không thể giả mạo SMS hay dùng chùa vượt quá số lượt dùng thử do Admin quy định.
 */
object LicenseManager {

    private const val PREF_NAME = "magictune_pro_prefs"
    private const val KEY_PRO_ACTIVATED = "is_pro_activated"
    private const val KEY_ACCOUNT_PRO_ACTIVATED = "is_account_pro_activated"
    private const val KEY_UPGRADED_TO_ACCOUNT_PRO = "is_upgraded_to_account_pro"
    private const val KEY_PENDING_ACCOUNT_PRO_BIND = "pending_account_pro_bind"
    const val KEY_ACTIVE_SESSION_TOKEN = "active_account_session_token"
    private const val KEY_ACTIVATED_LICENSE = "activated_license_key"
    private const val KEY_REVOKED_BY_ADMIN = "is_revoked_by_admin"
    private const val KEY_AUTO_APPROVE_NOTIFICATION_PAYMENT = "is_auto_approve_notification_payment_enabled"

    fun isAutoApproveNotificationPaymentEnabled(context: Context): Boolean {
        val prefs = context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(KEY_AUTO_APPROVE_NOTIFICATION_PAYMENT, true)
    }

    fun setAutoApproveNotificationPaymentEnabled(context: Context, enabled: Boolean) {
        val appCtx = context.applicationContext
        val prefs = appCtx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putBoolean(KEY_AUTO_APPROVE_NOTIFICATION_PAYMENT, enabled).apply()
        putSecureConfigString(appCtx, KEY_AUTO_APPROVE_NOTIFICATION_PAYMENT, enabled.toString())
        syncCloudGlobalConfigMap(appCtx, mapOf(KEY_AUTO_APPROVE_NOTIFICATION_PAYMENT to enabled))
        notifyProAndConfigStateChanged(appCtx)
    }

    private const val KEY_ADMIN_SIMULATE_FREE_MODE = "admin_simulate_free_mode"

    fun isAdminSimulateFreeMode(context: Context): Boolean {
        val prefs = context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(KEY_ADMIN_SIMULATE_FREE_MODE, false)
    }

    fun setAdminSimulateFreeMode(context: Context, simulateFree: Boolean) {
        val appCtx = context.applicationContext
        val prefs = appCtx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putBoolean(KEY_ADMIN_SIMULATE_FREE_MODE, simulateFree).apply()
        notifyProAndConfigStateChanged(appCtx)
    }

    // Secret Salt bảo mật chống giải ngược (Chỉ Admin mới tạo được Key hợp lệ)
    private val SECRET_SALT: String
        get() = runCatching { com.example.BuildConfig.PRO_SECRET_SALT }.getOrNull()?.ifBlank { null } ?: "MagicTunePro_SecretSalt_2026_VVuong_0393368007"
    private val ACCOUNT_PRO_SALT: String
        get() = runCatching { com.example.BuildConfig.PRO_ACCOUNT_SALT }.getOrNull()?.ifBlank { null } ?: "MagicTuneAccountPro_Salt_2026_VVuong_0393368007"

    // Endpoint Kill-Switch công khai
    private const val KILL_SWITCH_URL = "https://raw.githubusercontent.com/vuongdhkmhn/magictune/main/killswitch.txt"
    private const val PAID_DEVICES_URL = "https://raw.githubusercontent.com/vuongdhkmhn/magictune/main/paid_devices.txt"

    const val ACTION_PRO_ACTIVATED = "com.example.core.license.ACTION_PRO_ACTIVATED"
    const val ACTION_CONFIG_UPDATED = "com.example.core.license.ACTION_CONFIG_UPDATED"
    const val ACTION_GLOBAL_BROADCAST = "com.example.core.license.ACTION_GLOBAL_BROADCAST"

    const val KEY_PAYMENT_BANK_NAME = "payment_bank_name"
    const val KEY_PAYMENT_BANK_CODE = "payment_bank_code"
    const val KEY_PAYMENT_ACCOUNT_NUMBER = "payment_account_number"
    const val KEY_PAYMENT_ACCOUNT_HOLDER = "payment_account_holder"
    private const val KEY_GROQ_API_KEY_POOL = "groq_api_key_pool"
    private const val KEY_GEMINI_API_KEY_POOL = "gemini_api_key_pool"
    private const val KEY_USER_CUSTOM_GEMINI_KEY = "user_custom_gemini_key"

    fun getUserCustomGeminiKey(context: Context): String {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_USER_CUSTOM_GEMINI_KEY, "")?.trim().orEmpty()
    }

    fun setUserCustomGeminiKey(context: Context, key: String) {
        val cleanKey = key.trim()
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_USER_CUSTOM_GEMINI_KEY, cleanKey).apply()
    }

    fun getGeminiApiKeyPool(context: Context): String {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val local = prefs.getString(KEY_GEMINI_API_KEY_POOL, null)
        if (!local.isNullOrBlank()) return local
        val sec = getSecureConfigString(context, KEY_GEMINI_API_KEY_POOL)
        if (!sec.isNullOrBlank()) {
            prefs.edit().putString(KEY_GEMINI_API_KEY_POOL, sec).apply()
            return sec
        }
        return ""
    }

    fun setGeminiApiKeyPool(context: Context, pool: String) {
        val cleanPool = pool.trim()
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_GEMINI_API_KEY_POOL, cleanPool).commit()
        putSecureConfigString(context, KEY_GEMINI_API_KEY_POOL, cleanPool)
        syncCloudGlobalConfigMap(context, mapOf(KEY_GEMINI_API_KEY_POOL to cleanPool))
        notifyProAndConfigStateChanged(context)
    }

    fun getAllGeminiApiKeys(context: Context): List<String> {
        val combined = mutableListOf<String>()
        val userKey = getUserCustomGeminiKey(context)
        if (userKey.isNotBlank()) {
            if (userKey.startsWith("AIza") || !userKey.startsWith("gsk_")) {
                combined.add(userKey)
            }
        }
        val poolStr = getGeminiApiKeyPool(context)
        if (poolStr.isNotBlank()) {
            poolStr.split(Regex("[\\s,;]+"))
                .map { it.trim() }
                .filter { it.isNotBlank() && it != "null" && (it.startsWith("AIza") || !it.startsWith("gsk_")) }
                .forEach { if (!combined.contains(it)) combined.add(it) }
        }
        val groqPool = getGroqApiKeyPool(context)
        if (groqPool.isNotBlank()) {
            groqPool.split(Regex("[\\s,;]+"))
                .map { it.trim() }
                .filter { it.isNotBlank() && it.startsWith("AIza") }
                .forEach { if (!combined.contains(it)) combined.add(it) }
        }
        val buildKey = try {
            val field = com.example.BuildConfig::class.java.getField("GEMINI_API_KEY")
            field.get(null)?.toString()?.trim().orEmpty()
        } catch (_: Throwable) { "" }
        if (buildKey.isNotBlank() && buildKey != "MY_GEMINI_API_KEY" && buildKey != "null") {
            if (!combined.contains(buildKey)) combined.add(buildKey)
        }
        return combined
    }

    private var currentGeminiKeyIndex = 0
    private val geminiKeyCooldownMap = mutableMapOf<String, Long>()

    fun getLoadBalancedGeminiApiKey(context: Context): String {
        val keys = getAllGeminiApiKeys(context)
        if (keys.isEmpty()) return ""
        val now = System.currentTimeMillis()
        val available = keys.filter { k -> (geminiKeyCooldownMap[k] ?: 0L) < now }
        if (available.isNotEmpty()) {
            return available.shuffled().first()
        }
        return keys.shuffled().first()
    }

    fun markGeminiApiKeyCooldown(key: String, cooldownMs: Long = 120_000L) {
        if (key.isNotBlank()) {
            geminiKeyCooldownMap[key] = System.currentTimeMillis() + cooldownMs
        }
    }

    private fun putSecureConfigString(context: Context, key: String, value: String) {
        try {
            Settings.Secure.putString(context.contentResolver, "magictune_cfg_$key", value)
        } catch (_: Throwable) {}
    }

    private fun getSecureConfigString(context: Context, key: String): String? {
        return try {
            Settings.Secure.getString(context.contentResolver, "magictune_cfg_$key")?.takeIf { it.isNotBlank() }
        } catch (_: Throwable) {
            null
        }
    }

    fun getGroqApiKeyPool(context: Context): String {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val local = prefs.getString(KEY_GROQ_API_KEY_POOL, null)
        if (!local.isNullOrBlank()) return local
        val sec = getSecureConfigString(context, KEY_GROQ_API_KEY_POOL)
        if (!sec.isNullOrBlank()) {
            prefs.edit().putString(KEY_GROQ_API_KEY_POOL, sec).apply()
            return sec
        }
        return ""
    }

    fun setGroqApiKeyPool(context: Context, pool: String) {
        val cleanPool = pool.trim()
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_GROQ_API_KEY_POOL, cleanPool).commit()
        putSecureConfigString(context, KEY_GROQ_API_KEY_POOL, cleanPool)
        syncCloudGlobalConfigMap(context, mapOf(KEY_GROQ_API_KEY_POOL to cleanPool))
        notifyProAndConfigStateChanged(context)
    }

    private var currentApiKeyIndex = 0
    private val keyCooldownMap = mutableMapOf<String, Long>()

    fun getAllGroqApiKeys(context: Context): List<String> {
        val combined = mutableListOf<String>()
        val poolStr = getGroqApiKeyPool(context)
        if (poolStr.isNotBlank()) {
            poolStr.split(Regex("[\\s,;]+"))
                .map { it.trim() }
                .filter { it.isNotBlank() && it != "GROQ_API_KEY_DEFAULT_VALUE" && it != "null" && !it.startsWith("AIza") }
                .forEach { if (!combined.contains(it)) combined.add(it) }
        }
        val geminiPoolStr = getGeminiApiKeyPool(context)
        if (geminiPoolStr.isNotBlank()) {
            geminiPoolStr.split(Regex("[\\s,;]+"))
                .map { it.trim() }
                .filter { it.isNotBlank() && it.startsWith("gsk_") }
                .forEach { if (!combined.contains(it)) combined.add(it) }
        }
        val userKey = getUserCustomGeminiKey(context)
        if (userKey.isNotBlank() && userKey.startsWith("gsk_") && !combined.contains(userKey)) {
            combined.add(userKey)
        }
        val buildKey = try { com.example.BuildConfig.GROQ_API_KEY.trim() } catch (_: Throwable) { "" }
        if (buildKey.isNotBlank() && buildKey != "GROQ_API_KEY_DEFAULT_VALUE" && !combined.contains(buildKey)) {
            combined.add(buildKey)
        }
        return combined
    }

    fun getCombinedAiApiKeyPool(context: Context): String {
        val groq = getGroqApiKeyPool(context)
        val gemini = getGeminiApiKeyPool(context)
        val custom = getUserCustomGeminiKey(context)
        val all = (groq.split(Regex("[\\s,;]+")) + gemini.split(Regex("[\\s,;]+")) + listOf(custom))
            .map { it.trim() }
            .filter { it.isNotBlank() && it != "GROQ_API_KEY_DEFAULT_VALUE" && it != "null" }
            .distinct()
        return all.joinToString(" ")
    }

    fun getActiveGroqApiKey(context: Context): String {
        val keys = getAllGroqApiKeys(context)
        if (keys.isNotEmpty()) {
            val idx = (currentApiKeyIndex.coerceAtLeast(0)) % keys.size
            return keys[idx]
        }
        return ""
    }

    fun getLoadBalancedGroqApiKey(context: Context): String {
        val keys = getAllGroqApiKeys(context)
        if (keys.isEmpty()) return ""
        val now = System.currentTimeMillis()
        val available = keys.filter { k -> (keyCooldownMap[k] ?: 0L) < now }
        if (available.isNotEmpty()) {
            return available.shuffled().first()
        }
        return keys.shuffled().first()
    }

    fun markGroqApiKeyCooldown(key: String) {
        if (key.isNotBlank()) {
            keyCooldownMap[key] = System.currentTimeMillis() + 60_000L // 60s cooldown on 429
        }
    }

    fun rotateGroqApiKey(context: Context) {
        val keys = getAllGroqApiKeys(context)
        if (keys.size > 1) {
            currentApiKeyIndex = (currentApiKeyIndex + 1) % keys.size
        }
    }

    data class ProRecoveryRecord(
        val id: String = "",
        val deviceId: String = "",
        val deviceModel: String = "",
        val ownerEmail: String = "",
        val ownerName: String = "",
        val note: String = "",
        val createdAt: Any? = null,
        val status: String = "PENDING", // "PENDING" | "RESTORED"
        val previousProVerified: Boolean = true
    )

    @Volatile
    var lastCloudLookupDiag: String = ""

    fun sendProRecoveryRequest(context: Context, note: String, onComplete: (Boolean, String) -> Unit) {
        val appCtx = context.applicationContext
        try {
            val deviceId = getDeviceId(appCtx).uppercase()
            val user = try { Firebase.auth.currentUser } catch (_: Exception) { null }
            val db = FirebaseFirestore.getInstance()
            val recordId = "recovery_${deviceId}"
            val record = mapOf(
                "id" to recordId,
                "deviceId" to deviceId,
                "deviceModel" to "${Build.MANUFACTURER} ${Build.MODEL}",
                "ownerEmail" to (user?.email ?: "Khách vãng lai"),
                "ownerName" to (user?.displayName ?: "Người dùng"),
                "note" to note.ifBlank { "Khôi phục quyền Pro cho thiết bị $deviceId" },
                "createdAt" to FieldValue.serverTimestamp(),
                "status" to "PENDING",
                "previousProVerified" to true
            )
            if (user == null) {
                kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
                    val ok = FirestoreRestTokenBridge.patchDocViaRest(appCtx, "pro_recovery_requests", recordId, record)
                    withContext(Dispatchers.Main) {
                        if (ok) {
                            onComplete(true, "Đã gửi yêu cầu khôi phục Pro thành công tới Admin! Admin sẽ kiểm tra và cấp lại ngay.")
                        } else {
                            onComplete(false, "Không thể kết nối máy chủ đám mây, vui lòng kiểm tra mạng Internet.")
                        }
                    }
                }
                return
            }
            db.collection("pro_recovery_requests").document(recordId).set(record, SetOptions.merge())
                .addOnSuccessListener {
                    onComplete(true, "Đã gửi yêu cầu khôi phục Pro thành công tới Admin! Admin sẽ kiểm tra và cấp lại ngay.")
                }
                .addOnFailureListener { e ->
                    kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
                        val ok = FirestoreRestTokenBridge.patchDocViaRest(appCtx, "pro_recovery_requests", recordId, record)
                        withContext(Dispatchers.Main) {
                            if (ok) {
                                onComplete(true, "Đã gửi yêu cầu khôi phục Pro thành công tới Admin! Admin sẽ kiểm tra và cấp lại ngay.")
                            } else {
                                onComplete(false, "Không thể gửi yêu cầu: ${e.localizedMessage}")
                            }
                        }
                    }
                }
        } catch (e: Exception) {
            onComplete(false, "Lỗi: ${e.localizedMessage}")
        }
    }

    fun extractTimestampMillis(raw: Any?): Long {
        return when (raw) {
            is com.google.firebase.Timestamp -> raw.toDate().time
            is Number -> {
                val v = raw.toLong()
                if (v in 1..9_999_999_999L) v * 1000L else v
            }
            is java.util.Date -> raw.time
            is String -> raw.trim().toLongOrNull() ?: 0L
            else -> 0L
        }
    }

    suspend fun refreshProStatus(context: Context): Boolean {
        val stopped = checkKillSwitchRemote()
        if (stopped) return false

        val isKnownDevicePro = checkDeviceRecognizedProInCloud(context)
        if (isKnownDevicePro) return true
        
        val isPaidOnline = checkOnlinePaymentStatusRemote(context)
        return isPaidOnline
    }

    fun adminRestoreProForDevice(deviceId: String, context: Context? = null, onComplete: (Boolean) -> Unit) {
        try {
            val cleanId = deviceId.trim().uppercase()
            val normId = normalizeDeviceIdForMatch(cleanId)
            val db = FirebaseFirestore.getInstance()
            val licenseKey = generateLicenseKeyForDevice(cleanId)

            val updates = mapOf<String, Any>(
                "deviceId" to cleanId,
                "isPro" to true,
                "revokedByAdmin" to false,
                "licenseKey" to licenseKey,
                "proActivatedAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )

            if (context != null) {
                val appCtx = context.applicationContext
                FirestoreRestTokenBridge.patchDocAsync(appCtx, "devices", cleanId, updates)
                if (normId.isNotBlank() && normId != cleanId) {
                    FirestoreRestTokenBridge.patchDocAsync(appCtx, "devices", normId, updates + ("deviceId" to normId))
                }
            }

            db.collection("devices").document(cleanId).set(updates, SetOptions.merge())
                .addOnSuccessListener {
                    if (normId.isNotBlank() && normId != cleanId) {
                        db.collection("devices").document(normId).set(updates, SetOptions.merge())
                    }
                    // Quét không cần chỉ mục (Zero-Index) trên pro_recovery_requests và lọc trong bộ nhớ
                    db.collection("pro_recovery_requests")
                        .get()
                        .addOnSuccessListener { snap ->
                            val batch = db.batch()
                            for (doc in snap.documents) {
                                val docDevId = doc.getString("deviceId") ?: doc.id
                                if (normalizeDeviceIdForMatch(docDevId) == normId) {
                                    batch.update(doc.reference, "status", "RESTORED", "restoredAt", FieldValue.serverTimestamp())
                                    if (context != null) {
                                        FirestoreRestTokenBridge.patchDocAsync(
                                            context.applicationContext,
                                            "pro_recovery_requests",
                                            doc.id,
                                            mapOf("status" to "RESTORED")
                                        )
                                    }
                                }
                            }
                            batch.commit().addOnCompleteListener {
                                onComplete(true)
                            }
                        }
                        .addOnFailureListener {
                            onComplete(true)
                        }
                }
                .addOnFailureListener {
                    // Fallback REST nếu SDK lỗi
                    if (context != null) {
                        val appCtx = context.applicationContext
                        FirestoreRestTokenBridge.patchDocAsync(appCtx, "devices", cleanId, updates)
                        FirestoreRestTokenBridge.patchDocAsync(
                            appCtx,
                            "pro_recovery_requests",
                            cleanId,
                            mapOf("status" to "RESTORED")
                        )
                    }
                    onComplete(true)
                }
        } catch (_: Exception) {
            onComplete(false)
        }
    }

    fun fetchAdminCollectionMapsViaRest(
        context: Context,
        collection: String,
        pageSize: Int = 400
    ): List<Map<String, Any>> {
        return try {
            FirestoreRestTokenBridge.fetchCollectionMapsViaRest(context.applicationContext, collection, pageSize)
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun fetchProRecoveryRequestsViaRest(context: Context): List<ProRecoveryRecord> {
        return try {
            val rawList = fetchAdminCollectionMapsViaRest(context, "pro_recovery_requests", 300)
            rawList.mapNotNull { m ->
                try {
                    val docId = (m["__id"] as? String).orEmpty()
                    val createdRaw = m["createdAt"] ?: m["resolvedAt"] ?: m["restoredAt"]
                    ProRecoveryRecord(
                        id = (m["id"] as? String)?.takeIf { it.isNotBlank() } ?: docId,
                        deviceId = (m["deviceId"] as? String)?.takeIf { it.isNotBlank() }
                            ?: docId.removePrefix("recovery_").substringBefore("_"),
                        deviceModel = (m["deviceModel"] as? String)?.takeIf { it.isNotBlank() } ?: "Thiết bị Android",
                        ownerEmail = (m["ownerEmail"] as? String)?.takeIf { it.isNotBlank() } ?: "Khách vãng lai",
                        ownerName = (m["ownerName"] as? String)?.takeIf { it.isNotBlank() } ?: "Người dùng",
                        note = (m["note"] as? String)?.takeIf { it.isNotBlank() } ?: "Khôi phục quyền Pro theo ID máy",
                        createdAt = createdRaw,
                        status = (m["status"] as? String)?.takeIf { it.isNotBlank() } ?: "PENDING",
                        previousProVerified = (m["previousProVerified"] as? Boolean) ?: true
                    )
                } catch (_: Exception) {
                    null
                }
            }.sortedByDescending { extractTimestampMillis(it.createdAt) }
                .groupBy { normalizeDeviceIdForMatch(it.deviceId).ifBlank { it.id } }
                .mapValues { (_, items) -> items.first() }
                .values
                .toList()
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun observeProRecoveryRequests(
        context: Context? = null,
        onUpdate: (List<ProRecoveryRecord>) -> Unit
    ): com.google.firebase.firestore.ListenerRegistration? {
        if (context != null) {
            val appCtx = context.applicationContext
            kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
                val restList = fetchProRecoveryRequestsViaRest(appCtx)
                if (restList.isNotEmpty()) {
                    withContext(Dispatchers.Main) {
                        onUpdate(restList)
                    }
                }
            }
        }
        return try {
            val db = FirebaseFirestore.getInstance()
            // Không dùng .orderBy("createdAt") trên Firestore để tránh đòi chỉ mục và tránh làm ẩn các bản ghi thiếu createdAt
            db.collection("pro_recovery_requests")
                .addSnapshotListener { snap, error ->
                    if (error != null && context != null) {
                        val appCtx = context.applicationContext
                        kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
                            val restList = fetchProRecoveryRequestsViaRest(appCtx)
                            withContext(Dispatchers.Main) {
                                onUpdate(restList)
                            }
                        }
                        return@addSnapshotListener
                    }
                    if (snap != null) {
                        val list = snap.documents.mapNotNull { doc ->
                            try {
                                val createdRaw = doc.get("createdAt") ?: doc.get("resolvedAt") ?: doc.get("restoredAt")
                                ProRecoveryRecord(
                                    id = doc.getString("id") ?: doc.id,
                                    deviceId = doc.getString("deviceId") ?: doc.id.removePrefix("recovery_").substringBefore("_"),
                                    deviceModel = doc.getString("deviceModel") ?: "Thiết bị Android",
                                    ownerEmail = doc.getString("ownerEmail") ?: "Khách vãng lai",
                                    ownerName = doc.getString("ownerName") ?: "Người dùng",
                                    note = doc.getString("note") ?: "Khôi phục quyền Pro theo ID máy",
                                    createdAt = createdRaw,
                                    status = doc.getString("status") ?: "PENDING",
                                    previousProVerified = doc.getBoolean("previousProVerified") ?: true
                                )
                            } catch (_: Exception) {
                                null
                            }
                        }.sortedByDescending { extractTimestampMillis(it.createdAt) }
                            .groupBy { normalizeDeviceIdForMatch(it.deviceId).ifBlank { it.id } }
                            .mapValues { (_, items) -> items.first() }
                            .values
                            .toList()
                        onUpdate(list)
                    }
                }
        } catch (_: Exception) {
            null
        }
    }

    private const val KEY_BROADCAST_ID = "global_broadcast_id"
    private const val KEY_BROADCAST_TITLE = "global_broadcast_title"
    private const val KEY_BROADCAST_MESSAGE = "global_broadcast_message"
    private const val KEY_BROADCAST_TYPE = "global_broadcast_type" // "UPDATE" or "ANNOUNCEMENT"
    private const val KEY_BROADCAST_ACTIVE = "global_broadcast_active"
    private const val KEY_BROADCAST_URL = "global_broadcast_url"
    private const val KEY_BROADCAST_SENT_AT = "global_broadcast_sent_at"
    private const val KEY_DISMISSED_BROADCAST_ID = "dismissed_broadcast_id"
    private const val KEY_NOTIFIED_BROADCAST_ID = "notified_system_broadcast_id"

    data class GlobalBroadcastMessage(
        val id: String = "",
        val title: String = "",
        val message: String = "",
        val type: String = "UPDATE", // "UPDATE" | "ANNOUNCEMENT"
        val isActive: Boolean = false,
        val actionUrl: String = "",
        val sentAtMs: Long = 0L
    )

    private val _globalBroadcastFlow = kotlinx.coroutines.flow.MutableStateFlow<GlobalBroadcastMessage?>(null)
    val globalBroadcastFlow: kotlinx.coroutines.flow.StateFlow<GlobalBroadcastMessage?> = _globalBroadcastFlow

    private val _proStateVersionFlow = kotlinx.coroutines.flow.MutableStateFlow(0L)
    val proStateVersionFlow: kotlinx.coroutines.flow.StateFlow<Long> = _proStateVersionFlow

    fun notifyProAndConfigStateChanged(context: Context) {
        _proStateVersionFlow.value = System.currentTimeMillis()
        try {
            val pkg = context.packageName
            context.sendBroadcast(android.content.Intent(ACTION_PRO_ACTIVATED).setPackage(pkg))
            context.sendBroadcast(android.content.Intent(ACTION_CONFIG_UPDATED).setPackage(pkg))
            context.sendBroadcast(android.content.Intent(ACTION_PRO_ACTIVATED))
            context.sendBroadcast(android.content.Intent(ACTION_CONFIG_UPDATED))
        } catch (_: Exception) {}
    }



    // Chống trừ 2 lần liên tiếp trong cùng 1 thao tác (ViewModel -> Repository)
    @Volatile
    private var lastTrialConsumedTimestampMs: Long = 0L

    data class AiProChatLogRecord(
        val id: String = "",
        val deviceId: String = "",
        val deviceModel: String = "",
        val ownerEmail: String = "",
        val ownerName: String = "",
        val userMessage: String = "",
        val aiReply: String = "",
        val eventType: String = "PRO_INQUIRY", // "BILL_VERIFIED_PRO" | "BILL_REJECTED" | "FAKE_BILL_DETECTED" | "REUSED_BILL_BLOCKED" | "KEY_VERIFIED_PRO" | "CLOUD_FAMILIAR_RESTORED" | "UNPAID_PRO_REQUEST_BLOCKED" | "PRO_INQUIRY"
        val proGranted: Boolean = false,
        val grantedTier: String = "NONE", // "ACCOUNT_PRO" | "DEVICE_PRO" | "NONE"
        val generatedKey: String = "",
        val billImageHash: String = "",
        val bankTransCode: String = "",
        val forensicVerdict: String = "",
        val timestampMs: Long = 0L,
        val createdAt: Any? = null
    ) {
        fun getFormattedTime(): String {
            val ms = if (timestampMs > 0L) {
                timestampMs
            } else {
                (createdAt as? com.google.firebase.Timestamp)?.toDate()?.time ?: 0L
            }
            if (ms <= 0L) return "Vừa xong"
            return try {
                java.text.SimpleDateFormat("dd/MM/yyyy HH:mm:ss", java.util.Locale.getDefault())
                    .format(java.util.Date(ms))
            } catch (_: Exception) {
                "Vừa xong"
            }
        }
    }

    fun computeByteArraySha256(bytes: ByteArray): String {
        return try {
            val digest = MessageDigest.getInstance("SHA-256")
            val hashBytes = digest.digest(bytes)
            val sb = StringBuilder()
            for (b in hashBytes) {
                val hex = Integer.toHexString(0xff and b.toInt())
                if (hex.length == 1) sb.append('0')
                sb.append(hex)
            }
            sb.toString().uppercase()
        } catch (_: Exception) {
            ""
        }
    }

    /**
     * Kiểm tra Chống Gian Lận Dùng Lại Bill Cũ / Bill Trùng Lặp (Anti-Replay Attack):
     * Đọc trực tiếp bảng `ai_pro_chat_logs` không cần chỉ mục (Zero-Index) và lọc trong bộ nhớ.
     */
    suspend fun checkBillReplayOrDuplicateInCloud(
        billSha256: String,
        bankTransCode: String,
        currentDeviceId: String,
        isRequestingAccountUpgrade: Boolean
    ): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        try {
            val db = FirebaseFirestore.getInstance()
            val normCurrentId = normalizeDeviceIdForMatch(currentDeviceId)
            val cleanTrans = bankTransCode.trim().uppercase()
                .replace(" ", "")
                .takeIf { it.length >= 6 && it != "NONE" && it != "UNKNOWN" && it != "KHONGCO" }
                .orEmpty()

            val snap = db.collection("ai_pro_chat_logs")
                .get()
                .await()

            for (doc in snap.documents) {
                if (doc.getBoolean("proGranted") != true) continue
                val existingHash = (doc.getString("billImageHash") ?: "").trim().uppercase()
                val existingTrans = (doc.getString("bankTransCode") ?: "").trim().uppercase()
                val existingDevId = (doc.getString("deviceId") ?: "").trim().uppercase()
                val existingTier = (doc.getString("grantedTier") ?: "").trim().uppercase()
                val normExistingDev = normalizeDeviceIdForMatch(existingDevId)

                // 1. Trùng khớp 100% chữ ký ảnh SHA-256
                if (billSha256.isNotBlank() && existingHash.isNotBlank() && billSha256 == existingHash) {
                    if (normExistingDev != normCurrentId) {
                        return@withContext true to "Ảnh biên lai này đã từng được sử dụng để kích hoạt cho một thiết bị khác ($existingDevId). Hệ thống chống gian lận nghiêm cấm dùng 1 ảnh bill cho nhiều máy!"
                    }
                    if (isRequestingAccountUpgrade && existingTier == "DEVICE_PRO") {
                        return@withContext true to "Ảnh biên lai này là hóa đơn cũ khi bạn mua gói Pro Thiết Bị trước đây. Để nâng cấp từ Pro Thiết Bị lên Pro Tài Khoản, bạn cần quét mã QR chuyển khoản khoản phí nâng cấp mới!"
                    }
                }

                // 2. Trùng khớp Mã giao dịch ngân hàng (FT / Mã tham chiếu)
                if (cleanTrans.isNotBlank() && existingTrans.isNotBlank() && cleanTrans == existingTrans) {
                    if (normExistingDev != normCurrentId) {
                        return@withContext true to "Mã giao dịch ngân hàng ($cleanTrans) trên biên lai này đã được sử dụng cho thiết bị $existingDevId trước đó. Không thể dùng lại biên lai cũ!"
                    }
                    if (isRequestingAccountUpgrade && existingTier == "DEVICE_PRO") {
                        return@withContext true to "Mã giao dịch ($cleanTrans) này thuộc lần kích hoạt Pro Thiết Bị trước đây. Vui lòng thực hiện giao dịch mới để nâng cấp lên Pro Tài Khoản!"
                    }
                }
            }
            false to ""
        } catch (_: Exception) {
            false to ""
        }
    }

    fun logAiProChatInteraction(
        context: Context,
        userMessage: String,
        aiReply: String,
        eventType: String,
        proGranted: Boolean,
        grantedTier: String = "NONE",
        generatedKey: String = "",
        targetDeviceId: String = "",
        billImageHash: String = "",
        bankTransCode: String = "",
        forensicVerdict: String = ""
    ) {
        try {
            val deviceId = targetDeviceId.trim().uppercase().ifBlank { getDeviceId(context).uppercase() }
            val user = try { Firebase.auth.currentUser } catch (_: Exception) { null }
            val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            val savedEmail = prefs.getString("current_user_email", "")?.trim().orEmpty()
            val familiarEmail = prefs.getString("last_familiar_email", "")?.trim().orEmpty()
            val effectiveEmail = when {
                !user?.email.isNullOrBlank() -> user?.email ?: ""
                savedEmail.isNotBlank() -> savedEmail
                familiarEmail.isNotBlank() -> "$familiarEmail (Máy quen)"
                else -> "👤 Khách vãng lai (Chưa đăng nhập)"
            }
            val effectiveName = when {
                !user?.displayName.isNullOrBlank() -> user?.displayName ?: ""
                effectiveEmail.contains("@") -> effectiveEmail.substringBefore("@")
                else -> "Khách vãng lai"
            }

            val now = System.currentTimeMillis()
            val logId = "ailog_${deviceId}_$now"
            val db = FirebaseFirestore.getInstance()
            val data = mapOf(
                "id" to logId,
                "deviceId" to deviceId,
                "deviceModel" to "${Build.MANUFACTURER} ${Build.MODEL}",
                "ownerEmail" to effectiveEmail,
                "ownerName" to effectiveName,
                "userMessage" to userMessage.take(1500),
                "aiReply" to aiReply.take(2500),
                "eventType" to eventType,
                "proGranted" to proGranted,
                "grantedTier" to grantedTier,
                "generatedKey" to generatedKey,
                "billImageHash" to billImageHash,
                "bankTransCode" to bankTransCode,
                "forensicVerdict" to forensicVerdict.take(500),
                "timestampMs" to now,
                "createdAt" to FieldValue.serverTimestamp()
            )
            db.collection("ai_pro_chat_logs").document(logId).set(data, SetOptions.merge())
            if (user == null) {
                FirestoreRestTokenBridge.patchDocAsync(context.applicationContext, "ai_pro_chat_logs", logId, data)
            }
        } catch (_: Exception) {}
    }

    fun fetchAiProChatLogsViaRest(context: Context): List<AiProChatLogRecord> {
        return try {
            val rawList = fetchAdminCollectionMapsViaRest(context, "ai_pro_chat_logs", 300)
            rawList.mapNotNull { m ->
                try {
                    val docId = (m["__id"] as? String).orEmpty()
                    val tsMs = (m["timestampMs"] as? Number)?.toLong()
                        ?: extractTimestampMillis(m["createdAt"])
                    AiProChatLogRecord(
                        id = (m["id"] as? String)?.takeIf { it.isNotBlank() } ?: docId,
                        deviceId = (m["deviceId"] as? String).orEmpty(),
                        deviceModel = (m["deviceModel"] as? String).orEmpty(),
                        ownerEmail = (m["ownerEmail"] as? String).orEmpty(),
                        ownerName = (m["ownerName"] as? String).orEmpty(),
                        userMessage = (m["userMessage"] as? String).orEmpty(),
                        aiReply = (m["aiReply"] as? String).orEmpty(),
                        eventType = (m["eventType"] as? String)?.takeIf { it.isNotBlank() } ?: "PRO_INQUIRY",
                        proGranted = (m["proGranted"] as? Boolean) ?: false,
                        grantedTier = (m["grantedTier"] as? String)?.takeIf { it.isNotBlank() } ?: "NONE",
                        generatedKey = (m["generatedKey"] as? String).orEmpty(),
                        billImageHash = (m["billImageHash"] as? String).orEmpty(),
                        bankTransCode = (m["bankTransCode"] as? String).orEmpty(),
                        forensicVerdict = (m["forensicVerdict"] as? String).orEmpty(),
                        timestampMs = tsMs,
                        createdAt = m["createdAt"]
                    )
                } catch (_: Exception) {
                    null
                }
            }.sortedByDescending { it.timestampMs }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun observeAiProChatLogs(
        context: Context? = null,
        onUpdate: (List<AiProChatLogRecord>) -> Unit
    ): com.google.firebase.firestore.ListenerRegistration? {
        if (context != null) {
            val appCtx = context.applicationContext
            kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
                val restList = fetchAiProChatLogsViaRest(appCtx)
                if (restList.isNotEmpty()) {
                    withContext(Dispatchers.Main) {
                        onUpdate(restList)
                    }
                }
            }
        }
        return try {
            val db = FirebaseFirestore.getInstance()
            db.collection("ai_pro_chat_logs")
                .addSnapshotListener { snap, error ->
                    if (error != null && context != null) {
                        val appCtx = context.applicationContext
                        kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
                            val restList = fetchAiProChatLogsViaRest(appCtx)
                            withContext(Dispatchers.Main) {
                                onUpdate(restList)
                            }
                        }
                        return@addSnapshotListener
                    }
                    if (snap != null) {
                        val list = snap.documents.mapNotNull { doc ->
                            try {
                                val tsMs = (doc.get("timestampMs") as? Number)?.toLong()
                                    ?: (doc.get("createdAt") as? com.google.firebase.Timestamp)?.toDate()?.time
                                    ?: 0L
                                AiProChatLogRecord(
                                    id = doc.getString("id") ?: doc.id,
                                    deviceId = doc.getString("deviceId") ?: "",
                                    deviceModel = doc.getString("deviceModel") ?: "",
                                    ownerEmail = doc.getString("ownerEmail") ?: "",
                                    ownerName = doc.getString("ownerName") ?: "",
                                    userMessage = doc.getString("userMessage") ?: "",
                                    aiReply = doc.getString("aiReply") ?: "",
                                    eventType = doc.getString("eventType") ?: "PRO_INQUIRY",
                                    proGranted = doc.getBoolean("proGranted") ?: false,
                                    grantedTier = doc.getString("grantedTier") ?: "NONE",
                                    generatedKey = doc.getString("generatedKey") ?: "",
                                    billImageHash = doc.getString("billImageHash") ?: "",
                                    bankTransCode = doc.getString("bankTransCode") ?: "",
                                    forensicVerdict = doc.getString("forensicVerdict") ?: "",
                                    timestampMs = tsMs,
                                    createdAt = doc.get("createdAt")
                                )
                            } catch (_: Exception) {
                                null
                            }
                        }.sortedByDescending { it.timestampMs }
                        onUpdate(list)
                    }
                }
        } catch (_: Exception) {
            null
        }
    }

    fun deleteAiProChatLog(logId: String) {
        if (logId.isBlank()) return
        try {
            FirebaseFirestore.getInstance().collection("ai_pro_chat_logs").document(logId).delete()
        } catch (_: Exception) {}
    }

    data class AdminAdbErrorLogRecord(
        val id: String = "",
        val date: String = "", // Định dạng yyyy-MM-dd, ví dụ "2026-11-01"
        val deviceId: String = "",
        val deviceModel: String = "",
        val commercialName: String = "",
        val manufacturer: String = "",
        val soc: String = "",
        val androidVersion: String = "",
        val magicOsVersion: String = "",
        val command: String = "",
        val exitCode: Int = 1,
        val errorOutput: String = "",
        val occurrenceCount: Long = 1L,
        val affectedDevices: List<String> = emptyList(),
        val connectionMode: String = "",
        val userEmail: String = "",
        val userName: String = "",
        val featureSource: String = "ADB_COMMAND",
        val firstSeenTimestamp: Long = 0L,
        val lastSeenTimestamp: Long = 0L,
        val timestampMs: Long = 0L,
        val createdAt: Any? = null
    ) {
        val displayDate: String
            get() = if (date.isNotBlank()) date else {
                if (timestampMs > 0) {
                    java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date(timestampMs))
                } else "Unknown"
            }

        val dedupKey: String
            get() = "${displayDate}|${command.trim()}|$exitCode"
    }

    private val recentErrorSignatures = java.util.concurrent.ConcurrentHashMap<String, Long>()

    private fun md5Hash(input: String): String {
        return try {
            val md = java.security.MessageDigest.getInstance("MD5")
            val digest = md.digest(input.toByteArray(Charsets.UTF_8))
            digest.joinToString("") { "%02x".format(it) }.take(12)
        } catch (_: Throwable) {
            input.hashCode().toString().replace("-", "n")
        }
    }

    fun saveAdminAdbErrorLog(
        context: Context,
        command: String,
        exitCode: Int,
        errorOutput: String,
        connectionMode: String,
        featureSource: String
    ) {
        val cleanCmd = command.trim()
        if (cleanCmd.isBlank()) return

        val deviceId = getDeviceId(context).trim().uppercase()
        val now = System.currentTimeMillis()
        val dayFormatted = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date(now))
        val errorSignature = "${cleanCmd}|${exitCode}|${errorOutput.take(60)}"
        val errorHash = md5Hash(errorSignature)

        // 1. Chống spam trên cùng 1 máy: Mỗi máy chỉ gửi báo cáo cho cùng 1 lỗi tối đa 1 lần mỗi 24 giờ
        val deviceDayKey = "$deviceId|$dayFormatted|$errorHash"
        val lastTime = recentErrorSignatures[deviceDayKey] ?: 0L
        if (now - lastTime < 86_400_000L) { // 24 giờ
            return
        }
        recentErrorSignatures[deviceDayKey] = now

        val appCtx = context.applicationContext
        kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
            try {
                // Định danh duy nhất theo ngày và mã băm của lỗi:
                // Tất cả người dùng gặp cùng lỗi này trong cùng 1 ngày sẽ ghi vào đúng 1 document duy nhất!
                val logId = "adb_err_${dayFormatted.replace("-", "")}_${errorHash}"

                val commercialName = try {
                    com.example.core.widget.GeminiVoiceActionExecutor.getCommercialDeviceName(appCtx)
                } catch (_: Throwable) { Build.MODEL }
                val soc = try {
                    com.example.core.widget.GeminiVoiceActionExecutor.getSocMarketingName()
                } catch (_: Throwable) { Build.HARDWARE }
                val magicOs = try {
                    com.example.core.widget.GeminiVoiceActionExecutor.getMagicOsVersion()
                } catch (_: Throwable) { "MagicOS" }
                val user = try { com.google.firebase.auth.FirebaseAuth.getInstance().currentUser } catch (_: Throwable) { null }
                val userEmail = user?.email.orEmpty()
                val userName = try {
                    com.example.core.widget.GeminiVoiceActionExecutor.getUserDisplayName(appCtx)
                } catch (_: Throwable) { "Khách" }

                val data = hashMapOf<String, Any>(
                    "id" to logId,
                    "date" to dayFormatted,
                    "command" to cleanCmd,
                    "exitCode" to exitCode,
                    "errorOutput" to errorOutput.take(2500),
                    "occurrenceCount" to com.google.firebase.firestore.FieldValue.increment(1),
                    "affectedDevices" to com.google.firebase.firestore.FieldValue.arrayUnion(commercialName),
                    "deviceId" to deviceId,
                    "deviceModel" to Build.MODEL,
                    "commercialName" to commercialName,
                    "manufacturer" to Build.MANUFACTURER,
                    "soc" to soc,
                    "androidVersion" to Build.VERSION.RELEASE,
                    "magicOsVersion" to magicOs,
                    "connectionMode" to connectionMode,
                    "userEmail" to userEmail,
                    "userName" to userName,
                    "featureSource" to featureSource,
                    "lastSeenTimestamp" to now,
                    "timestampMs" to now,
                    "createdAt" to com.google.firebase.firestore.FieldValue.serverTimestamp()
                )

                try {
                    FirebaseFirestore.getInstance().collection("admin_logs").document(logId)
                        .set(data, com.google.firebase.firestore.SetOptions.merge())
                } catch (_: Throwable) {}

                try {
                    FirestoreRestTokenBridge.patchDocAsync(appCtx, "admin_logs", logId, data)
                } catch (_: Throwable) {}
            } catch (_: Throwable) {}
        }
    }

    fun fetchAdminAdbErrorLogsViaRest(context: Context): List<AdminAdbErrorLogRecord> {
        return try {
            val rawList = fetchAdminCollectionMapsViaRest(context, "admin_logs", 300)
            rawList.mapNotNull { m ->
                try {
                    val docId = (m["__id"] as? String).orEmpty()
                    val tsMs = (m["timestampMs"] as? Number)?.toLong()
                        ?: extractTimestampMillis(m["createdAt"])
                    val cmd = (m["command"] as? String).orEmpty()
                    if (cmd.isBlank()) return@mapNotNull null
                    AdminAdbErrorLogRecord(
                        id = (m["id"] as? String)?.takeIf { it.isNotBlank() } ?: docId,
                        date = (m["date"] as? String).orEmpty(),
                        deviceId = (m["deviceId"] as? String).orEmpty(),
                        deviceModel = (m["deviceModel"] as? String).orEmpty(),
                        commercialName = (m["commercialName"] as? String).orEmpty(),
                        manufacturer = (m["manufacturer"] as? String).orEmpty(),
                        soc = (m["soc"] as? String).orEmpty(),
                        androidVersion = (m["androidVersion"] as? String).orEmpty(),
                        magicOsVersion = (m["magicOsVersion"] as? String).orEmpty(),
                        command = cmd,
                        exitCode = (m["exitCode"] as? Number)?.toInt() ?: 1,
                        errorOutput = (m["errorOutput"] as? String).orEmpty(),
                        occurrenceCount = (m["occurrenceCount"] as? Number)?.toLong() ?: 1L,
                        affectedDevices = (m["affectedDevices"] as? List<*>)?.filterIsInstance<String>() ?: emptyList(),
                        connectionMode = (m["connectionMode"] as? String).orEmpty(),
                        userEmail = (m["userEmail"] as? String).orEmpty(),
                        userName = (m["userName"] as? String).orEmpty(),
                        featureSource = (m["featureSource"] as? String)?.takeIf { it.isNotBlank() } ?: "ADB_COMMAND",
                        firstSeenTimestamp = (m["firstSeenTimestamp"] as? Number)?.toLong() ?: 0L,
                        lastSeenTimestamp = (m["lastSeenTimestamp"] as? Number)?.toLong() ?: 0L,
                        timestampMs = tsMs,
                        createdAt = m["createdAt"]
                    )
                } catch (_: Exception) {
                    null
                }
            }.sortedByDescending { it.timestampMs }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun observeAdminAdbErrorLogs(
        context: Context? = null,
        onUpdate: (List<AdminAdbErrorLogRecord>) -> Unit
    ): com.google.firebase.firestore.ListenerRegistration? {
        if (context != null) {
            val appCtx = context.applicationContext
            kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
                val restList = fetchAdminAdbErrorLogsViaRest(appCtx)
                if (restList.isNotEmpty()) {
                    withContext(Dispatchers.Main) {
                        onUpdate(restList)
                    }
                }
            }
        }
        return try {
            val db = FirebaseFirestore.getInstance()
            db.collection("admin_logs")
                .limit(300)
                .addSnapshotListener { snap, error ->
                    if (error != null && context != null) {
                        val appCtx = context.applicationContext
                        kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
                            val restList = fetchAdminAdbErrorLogsViaRest(appCtx)
                            withContext(Dispatchers.Main) {
                                onUpdate(restList)
                            }
                        }
                        return@addSnapshotListener
                    }
                    if (snap != null) {
                        val list = snap.documents.mapNotNull { doc ->
                            try {
                                val cmd = (doc.getString("command") ?: "").trim()
                                if (cmd.isBlank()) return@mapNotNull null
                                AdminAdbErrorLogRecord(
                                    id = doc.id,
                                    date = (doc.getString("date") ?: "").trim(),
                                    deviceId = (doc.getString("deviceId") ?: "").trim(),
                                    deviceModel = (doc.getString("deviceModel") ?: "").trim(),
                                    commercialName = (doc.getString("commercialName") ?: "").trim(),
                                    manufacturer = (doc.getString("manufacturer") ?: "").trim(),
                                    soc = (doc.getString("soc") ?: "").trim(),
                                    androidVersion = (doc.getString("androidVersion") ?: "").trim(),
                                    magicOsVersion = (doc.getString("magicOsVersion") ?: "").trim(),
                                    command = cmd,
                                    exitCode = doc.getLong("exitCode")?.toInt() ?: 1,
                                    errorOutput = (doc.getString("errorOutput") ?: "").trim(),
                                    occurrenceCount = doc.getLong("occurrenceCount") ?: 1L,
                                    affectedDevices = (doc.get("affectedDevices") as? List<*>)?.filterIsInstance<String>() ?: emptyList(),
                                    connectionMode = (doc.getString("connectionMode") ?: "").trim(),
                                    userEmail = (doc.getString("userEmail") ?: "").trim(),
                                    userName = (doc.getString("userName") ?: "").trim(),
                                    featureSource = (doc.getString("featureSource") ?: "ADB_COMMAND").trim(),
                                    firstSeenTimestamp = doc.getLong("firstSeenTimestamp") ?: 0L,
                                    lastSeenTimestamp = doc.getLong("lastSeenTimestamp") ?: 0L,
                                    timestampMs = doc.getLong("timestampMs") ?: doc.getTimestamp("createdAt")?.toDate()?.time ?: 0L,
                                    createdAt = doc.get("createdAt")
                                )
                            } catch (_: Exception) {
                                null
                            }
                        }.sortedByDescending { it.timestampMs }
                        onUpdate(list)
                    }
                }
        } catch (_: Exception) {
            null
        }
    }

    fun deleteAdminAdbErrorLog(logId: String) {
        if (logId.isBlank()) return
        try {
            FirebaseFirestore.getInstance().collection("admin_logs").document(logId).delete()
        } catch (_: Exception) {}
    }

    fun clearAllAdminAdbErrorLogs(context: Context) {
        kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
            try {
                val db = FirebaseFirestore.getInstance()
                val snap = db.collection("admin_logs").get().await()
                val batch = db.batch()
                for (d in snap.documents) {
                    batch.delete(d.reference)
                }
                batch.commit().await()
            } catch (_: Throwable) {}
        }
    }

    /**
     * Tự động ghi nhận ngay Device ID + Mã Key lên bảng `devices` của Firebase khi Admin bấm nút Tạo Key
     * để đảm bảo kể cả máy khách vãng lai (chưa đăng nhập) khi xóa app cài lại vẫn được Cloud nhận diện là máy Pro quen thuộc 100%.
     */
    fun registerAdminGeneratedKeyToCloud(
        rawDeviceId: String,
        generatedKey: String,
        isAccountPro: Boolean
    ) {
        val cleanDevId = rawDeviceId.trim().uppercase()
        if (cleanDevId.isBlank()) return
        val normDevId = normalizeDeviceIdForMatch(cleanDevId)
        val hwId = getHardwareId()
        val tier = if (isAccountPro) "ACCOUNT_PRO" else "DEVICE_PRO"
        try {
            val db = FirebaseFirestore.getInstance()
            val devUpdates = mapOf(
                "deviceId" to cleanDevId,
                "hardwareId" to hwId,
                "isPro" to true,
                "isAccountPro" to isAccountPro,
                "upgradedToAccountPro" to isAccountPro,
                "proTier" to tier,
                "licenseKey" to generatedKey,
                "revokedByAdmin" to false,
                "approvedByAiReason" to "ADMIN_KEY_GENERATED_$tier",
                "proActivatedAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            db.collection("devices").document(cleanDevId).set(devUpdates, SetOptions.merge())
            if (normDevId.isNotBlank() && normDevId != cleanDevId) {
                db.collection("devices").document(normDevId).set(
                    devUpdates + ("deviceId" to normDevId),
                    SetOptions.merge()
                )
            }
        } catch (_: Exception) {}
    }

    /**
     * Dành cho Admin trên trang Quản Trị: Cấp hoặc nâng cấp chính xác hạng Pro (`DEVICE_PRO` hoặc `ACCOUNT_PRO`)
     * cho bất kỳ tài khoản hoặc thiết bị nào từ xa (Không cần chỉ mục Firestore phức tạp).
     */
    fun adminGrantTierForUserOrDevice(
        userId: String = "",
        deviceId: String = "",
        grantAccountPro: Boolean,
        context: Context? = null,
        onComplete: (Boolean, String) -> Unit
    ) {
        try {
            val db = FirebaseFirestore.getInstance()
            val cleanDevId = deviceId.trim().uppercase()
            val normDevId = normalizeDeviceIdForMatch(cleanDevId)
            val tier = if (grantAccountPro) "ACCOUNT_PRO" else "DEVICE_PRO"
            val key = if (cleanDevId.isNotBlank()) {
                if (grantAccountPro) generateAccountProLicenseKeyForDevice(cleanDevId)
                else generateLicenseKeyForDevice(cleanDevId)
            } else {
                if (grantAccountPro) "TKPR-ADMIN-GRANTED" else "PRO-ADMIN-GRANTED"
            }

            if (cleanDevId.isNotBlank()) {
                val devUpdates = mapOf<String, Any>(
                    "deviceId" to cleanDevId,
                    "appId" to "magictune",
                    "product" to "MAGICTUNE_PRO",
                    "magictunePro" to true,
                    "isPro" to true,
                    "isAccountPro" to grantAccountPro,
                    "upgradedToAccountPro" to grantAccountPro,
                    "proTier" to tier,
                    "licenseKey" to key,
                    "revokedByAdmin" to false,
                    "approvedByAiReason" to "ADMIN_MANUAL_GRANT_$tier",
                    "proActivatedAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )

                if (context != null) {
                    val appCtx = context.applicationContext
                    FirestoreRestTokenBridge.patchDocAsync(appCtx, "devices", cleanDevId, devUpdates)
                    if (normDevId.isNotBlank() && normDevId != cleanDevId) {
                        FirestoreRestTokenBridge.patchDocAsync(appCtx, "devices", normDevId, devUpdates + ("deviceId" to normDevId))
                    }
                }

                db.collection("devices").document(cleanDevId).set(devUpdates, SetOptions.merge())
                if (normDevId.isNotBlank() && normDevId != cleanDevId) {
                    db.collection("devices").document(normDevId).set(
                        devUpdates + ("deviceId" to normDevId),
                        SetOptions.merge()
                    )
                }
                deletePaymentIntentsForDevice(cleanDevId, context)
            }

            if (userId.isNotBlank()) {
                val userUpdates = mutableMapOf<String, Any>(
                    "appId" to "magictune",
                    "product" to "MAGICTUNE_PRO",
                    "magictunePro" to true,
                    "magictuneTier" to tier,
                    "isPro" to true,
                    "isAccountPro" to grantAccountPro,
                    "proTier" to tier,
                    "revokedByAdmin" to false,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                if (cleanDevId.isNotBlank()) {
                    userUpdates["deviceId"] = cleanDevId
                    userUpdates["activeDeviceId"] = cleanDevId
                }
                if (context != null) {
                    FirestoreRestTokenBridge.patchDocAsync(context.applicationContext, "users", userId, userUpdates)
                }
                db.collection("users").document(userId).set(userUpdates, SetOptions.merge())
            } else if (normDevId.isNotBlank()) {
                // Quét bảng users không cần chỉ mục và lọc chuẩn hóa trong bộ nhớ
                db.collection("users")
                    .get()
                    .addOnSuccessListener { snap ->
                        for (doc in snap.documents) {
                            val uDev = normalizeDeviceIdForMatch(doc.getString("deviceId") ?: "")
                            val uAct = normalizeDeviceIdForMatch(doc.getString("activeDeviceId") ?: "")
                            if (uDev == normDevId || uAct == normDevId) {
                                val patch = mapOf<String, Any>(
                                    "isPro" to true,
                                    "isAccountPro" to grantAccountPro,
                                    "proTier" to tier,
                                    "revokedByAdmin" to false,
                                    "updatedAt" to FieldValue.serverTimestamp()
                                )
                                doc.reference.set(patch, SetOptions.merge())
                                if (context != null) {
                                    FirestoreRestTokenBridge.patchDocAsync(context.applicationContext, "users", doc.id, patch)
                                }
                            }
                        }
                    }
            }
            val tierLabel = if (grantAccountPro) "👑 PRO TÀI KHOẢN" else "📱 PRO THIẾT BỊ"
            onComplete(true, "Đã cấp $tierLabel thành công!")
        } catch (e: Exception) {
            onComplete(false, "Lỗi khi cấp Pro: ${e.localizedMessage}")
        }
    }

    /**
     * Dành cho Admin: Mở khóa phiên thiết bị (Reset 1-device session lock) khi khách dùng Pro Tài Khoản bị hỏng/mất máy cũ
     * và muốn đăng nhập sang máy mới ngay lập tức.
     */
    fun adminResetUserActiveDeviceSession(userId: String, onComplete: (Boolean) -> Unit) {
        if (userId.isBlank()) {
            onComplete(false)
            return
        }
        try {
            val db = FirebaseFirestore.getInstance()
            db.collection("users").document(userId).set(
                mapOf(
                    "activeDeviceId" to "",
                    "activeDeviceModel" to "",
                    "activeSessionToken" to "",
                    "updatedAt" to FieldValue.serverTimestamp()
                ),
                SetOptions.merge()
            ).addOnSuccessListener {
                onComplete(true)
            }.addOnFailureListener {
                onComplete(false)
            }
        } catch (_: Exception) {
            onComplete(false)
        }
    }

    fun normalizeDeviceIdForMatch(raw: String): String {
        return raw.trim().uppercase()
            .removePrefix("MT-")
            .replace("-", "")
            .replace(" ", "")
            .replace(Regex("[^A-Z0-9]"), "")
            .trim()
    }

    /**
     * Chuẩn hóa chống nhầm lẫn ký tự đồng hình (Homoglyphs) thường gặp khi khách hoặc OCR nhập mã Hex Android ID:
     * Chữ `O` -> Số `0`, Chữ `I` / `L` -> Số `1`.
     */
    fun normalizeHexHomoglyphs(raw: String): String {
        return normalizeDeviceIdForMatch(raw)
            .replace('O', '0')
            .replace('I', '1')
            .replace('L', '1')
    }

    private const val SECURE_KEY_PERSISTENT_DEVICE_ID = "magictune_persistent_device_id"

    /**
     * 1. Lấy định danh thiết bị (Device ID - Android ID) cố định xuyên suốt kể cả khi xóa hẳn app cài lại.
     * Tích hợp thêm MediaDrm Hardware ID để nhận diện máy vĩnh viễn siêu bền.
     */
    fun getHardwareId(): String {
        return try {
            val widevineUuid = UUID(-0x12107456885b53baL, -0x5c37d048e1d2c14fL)
            val wvDrm = MediaDrm(widevineUuid)
            val widevineId = wvDrm.getPropertyByteArray(MediaDrm.PROPERTY_DEVICE_UNIQUE_ID)
            Base64.encodeToString(widevineId, Base64.NO_WRAP).trim()
                .replace("/", "_").replace("+", "-").replace("=", "").take(32)
        } catch (_: Exception) {
            ""
        }
    }

    fun getDeviceId(context: Context): String {
        return try {
            val savedPersistentId = try {
                Settings.Secure.getString(context.contentResolver, SECURE_KEY_PERSISTENT_DEVICE_ID)?.trim()?.uppercase()
            } catch (_: Exception) { null }
            if (!savedPersistentId.isNullOrBlank() && savedPersistentId != "9774D56D682E549C") {
                return savedPersistentId
            }

            val rawId = Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
            val hwId = getHardwareId()

            val resolved = when {
                !rawId.isNullOrBlank() && rawId.lowercase() != "9774d56d682e549c" -> rawId.uppercase()
                hwId.isNotBlank() -> "HW-${hwId.take(16).uppercase()}"
                else -> "MT-HONOR-8888"
            }

            try {
                Settings.Secure.putString(context.contentResolver, SECURE_KEY_PERSISTENT_DEVICE_ID, resolved)
            } catch (_: Exception) {}
            resolved
        } catch (_: Exception) {
            "MT-HONOR-8888"
        }
    }

    /**
     * Tập hợp toàn bộ các biến thể định danh hợp lệ của thiết bị hiện tại (Multi-Format Candidate IDs):
     * - Bao gồm ID hiện tại, ID có tiền tố `MT-`, ID chuẩn hóa không dấu gạch, `ANDROID_ID` gốc (16 ký tự),
     *   biến thể rút gọn 8 ký tự / 12 ký tự đầu & cuối (tương thích ngược 100% với các bản ghi `MT-XXXXXXXX` đời cũ),
     *   biến thể nhầm số `0` thành chữ `O` (do OCR hoặc nhập tay), và mã phần cứng `MediaDrm` (`HW-...`).
     */
    fun getAllCandidateDeviceIds(context: Context): List<String> {
        val result = linkedSetOf<String>()
        try {
            val primaryId = getDeviceId(context).trim().uppercase()
            val normPrimary = normalizeDeviceIdForMatch(primaryId)
            val hexPrimary = normalizeHexHomoglyphs(primaryId)
            val rawAndroid = try {
                Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)?.trim().orEmpty()
            } catch (_: Exception) { "" }
            val cleanAndroid = if (rawAndroid.isNotBlank() && !rawAndroid.equals("9774d56d682e549c", ignoreCase = true)) {
                rawAndroid.uppercase()
            } else ""
            val normAndroid = normalizeDeviceIdForMatch(cleanAndroid)
            val hwId = getHardwareId().trim()
            val normHw = normalizeDeviceIdForMatch(hwId)

            fun addIdVariants(baseNorm: String, rawOriginal: String = "") {
                if (rawOriginal.isNotBlank()) {
                    result.add(rawOriginal)
                    result.add(rawOriginal.uppercase())
                    result.add(rawOriginal.lowercase())
                }
                if (baseNorm.isNotBlank() && baseNorm != "HONOR8888") {
                    result.add(baseNorm)
                    result.add("MT-$baseNorm")
                    result.add(baseNorm.lowercase())
                    result.add("mt-${baseNorm.lowercase()}")
                    if (baseNorm.contains('0')) {
                        val oVariant = baseNorm.replace('0', 'O')
                        result.add(oVariant)
                        result.add("MT-$oVariant")
                    }
                    if (baseNorm.length >= 8) {
                        val head8 = baseNorm.take(8)
                        val tail8 = baseNorm.takeLast(8)
                        result.add("MT-$head8")
                        result.add(head8)
                        result.add("MT-$tail8")
                        result.add(tail8)
                    }
                    if (baseNorm.length >= 12) {
                        val head12 = baseNorm.take(12)
                        result.add("MT-$head12")
                        result.add(head12)
                    }
                }
            }

            addIdVariants(normPrimary, primaryId)
            if (hexPrimary.isNotBlank() && hexPrimary != normPrimary) {
                addIdVariants(hexPrimary)
            }
            if (normAndroid.isNotBlank() && normAndroid != normPrimary) {
                addIdVariants(normAndroid, cleanAndroid)
            }
            if (hwId.isNotBlank()) {
                val hw16 = hwId.take(16).uppercase()
                result.add(hwId)
                result.add("HW-$hw16")
                result.add(hw16)
                if (normHw.length >= 8) {
                    result.add("MT-${normHw.take(8)}")
                    result.add(normHw.take(8))
                }
            }
        } catch (_: Exception) {}
        return result.filter { it.isNotBlank() && it.length >= 4 }.toList()
    }

    /**
     * Sinh toàn bộ các mã License Key SHA-256 (cả gói Pro Thiết Bị và Pro Tài Khoản) tương ứng với mọi biến thể ID của máy.
     * Map trả về: `Key -> isAccountPro` (`true` nếu là `TKPR-...`, `false` nếu là Key Thiết Bị).
     */
    fun getAllCandidateLicenseKeys(context: Context): Map<String, Boolean> {
        val keyMap = linkedMapOf<String, Boolean>()
        val candidateIds = getAllCandidateDeviceIds(context)
        for (candId in candidateIds) {
            val upper = candId.trim().uppercase()
            if (upper.length < 4) continue
            val devKey = generateLicenseKeyForDevice(upper).uppercase()
            val accKey = generateAccountProLicenseKeyForDevice(upper).uppercase()
            if (devKey.isNotBlank() && devKey != "PRO8-8888-9999-0000") {
                keyMap[devKey] = false
            }
            if (accKey.isNotBlank() && accKey != "TKPR-9999-8888-7777") {
                keyMap[accKey] = true
            }
        }
        return keyMap
    }

    /**
     * Đối chiếu thông minh xem một chuỗi định danh thiết bị (`otherRawId`) trên Cloud có thuộc về máy hiện tại hay không.
     * Hỗ trợ khớp chính xác, khớp chuẩn hóa bỏ `MT-`, khớp chống nhầm số `0` <-> chữ `O` (Homoglyphs),
     * và khớp tiền tố/hậu tố 8+ ký tự (giữa `ANDROID_ID` 16 ký tự và `MT-XXXXXXXX` 8 ký tự).
     */
    fun isDeviceIdMatchingCurrentDevice(context: Context, otherRawId: String?): Boolean {
        if (otherRawId.isNullOrBlank()) return false
        val otherNorm = normalizeDeviceIdForMatch(otherRawId)
        val otherHex = normalizeHexHomoglyphs(otherRawId)
        if (otherNorm.length < 6 || otherNorm == "HONOR8888") return false

        val primaryNorm = normalizeDeviceIdForMatch(getDeviceId(context))
        val primaryHex = normalizeHexHomoglyphs(primaryNorm)
        val rawAndroid = try {
            Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)?.trim().orEmpty()
        } catch (_: Exception) { "" }
        val androidNorm = if (!rawAndroid.equals("9774d56d682e549c", ignoreCase = true)) {
            normalizeDeviceIdForMatch(rawAndroid)
        } else ""
        val androidHex = normalizeHexHomoglyphs(androidNorm)
        val hwNorm = normalizeDeviceIdForMatch(getHardwareId())

        val coreNorms = listOf(primaryNorm, primaryHex, androidNorm, androidHex, hwNorm, hwNorm.take(16))
            .filter { it.length >= 6 && it != "HONOR8888" }
            .distinct()

        for (core in coreNorms) {
            if (otherNorm == core || otherHex == core) return true
            if (otherNorm.length >= 8 && core.length >= 8) {
                if (core.startsWith(otherNorm) || core.endsWith(otherNorm) ||
                    otherNorm.startsWith(core) || otherNorm.endsWith(core) ||
                    core.startsWith(otherHex) || core.endsWith(otherHex) ||
                    otherHex.startsWith(core) || otherHex.endsWith(core)
                ) {
                    return true
                }
            }
        }
        return false
    }

    /**
     * 2. Thuật toán sinh Mã Kích Hoạt (License Key) chuẩn SHA-256 từ Device ID + Secret Salt
     * Kết quả dạng: XXXX-XXXX-XXXX-XXXX (Dành cho Pro Thiết Bị cố định theo ID máy)
     */
    fun generateLicenseKeyForDevice(deviceId: String): String {
        val cleanDeviceId = deviceId.trim().uppercase()
        val combinedInput = "$cleanDeviceId:$SECRET_SALT"

        return try {
            val digest = MessageDigest.getInstance("SHA-256")
            val hashBytes = digest.digest(combinedInput.toByteArray(Charsets.UTF_8))

            val hexString = StringBuilder()
            for (b in hashBytes) {
                val hex = Integer.toHexString(0xff and b.toInt())
                if (hex.length == 1) hexString.append('0')
                hexString.append(hex)
            }

            val rawHash = hexString.toString().uppercase()
            val sub = rawHash.take(16)
            "${sub.substring(0, 4)}-${sub.substring(4, 8)}-${sub.substring(8, 12)}-${sub.substring(12, 16)}"
        } catch (_: Exception) {
            "PRO8-8888-9999-0000"
        }
    }

    /**
     * 2B. Thuật toán sinh Mã Kích Hoạt PRO TÀI KHOẢN (Account Pro Key) chuẩn SHA-256
     * Kết quả dạng: TKPR-XXXX-XXXX-XXXX (Dành cho nâng cấp từ Pro Thiết Bị lên Pro Tài Khoản hoặc mua Pro Tài Khoản)
     */
    fun generateAccountProLicenseKeyForDevice(deviceId: String): String {
        val cleanDeviceId = deviceId.trim().uppercase()
        val combinedInput = "$cleanDeviceId:$ACCOUNT_PRO_SALT"

        return try {
            val digest = MessageDigest.getInstance("SHA-256")
            val hashBytes = digest.digest(combinedInput.toByteArray(Charsets.UTF_8))

            val hexString = StringBuilder()
            for (b in hashBytes) {
                val hex = Integer.toHexString(0xff and b.toInt())
                if (hex.length == 1) hexString.append('0')
                hexString.append(hex)
            }

            val rawHash = hexString.toString().uppercase()
            val sub = rawHash.take(12)
            "TKPR-${sub.substring(0, 4)}-${sub.substring(4, 8)}-${sub.substring(8, 12)}"
        } catch (_: Exception) {
            "TKPR-9999-8888-7777"
        }
    }

    /**
     * 3. Kiểm tra Mã kích hoạt người dùng nhập vào (Nhận diện tự động cả Key Pro Thiết Bị và Key Pro Tài Khoản TKPR-...
     * trên mọi biến thể ID hợp lệ của thiết bị hiện tại)
     */
    fun verifyLicenseKey(context: Context, inputKey: String): Boolean {
        val cleanInput = inputKey.replace("-", "").replace(" ", "").trim().uppercase()
        if (cleanInput.length < 8) return false

        val candidateKeys = getAllCandidateLicenseKeys(context)
        for ((expectedKey, isAccountTier) in candidateKeys) {
            val cleanExpected = expectedKey.replace("-", "").replace(" ", "").trim().uppercase()
            if (cleanExpected.isNotBlank() && cleanInput == cleanExpected) {
                val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                prefs.edit().putBoolean(KEY_REVOKED_BY_ADMIN, false).apply()
                if (isAccountTier) {
                    activateAccountPro(context, expectedKey, syncToCloud = true)
                } else {
                    setProActivated(context, true, expectedKey, syncToCloud = true)
                }
                return true
            }
        }
        return false
    }

    /**
     * Kiểm tra trạng thái đã kích hoạt PRO chưa (Tính cả quyền Admin hoặc Chế độ Free toàn cục)
     */
    private const val SECURE_KEY_PRO_HW_SIG = "magictune_pro_hw_sig"

    /**
     * Kiểm tra xem người dùng đang có gói PRO TÀI KHOẢN (Account Pro - Đổi máy tự do, tối đa 1 máy đăng nhập cùng lúc) hay không
     */
    fun isAccountProActivated(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        if (prefs.getBoolean(KEY_REVOKED_BY_ADMIN, false)) return false
        return prefs.getBoolean(KEY_ACCOUNT_PRO_ACTIVATED, false)
    }

    /**
     * Kiểm tra xem máy này đã từng nâng cấp từ Pro Thiết Bị lên Pro Tài Khoản chưa.
     * Khi đã chuyển đổi từ Pro Thiết Bị lên Pro Tài Khoản, quyền Pro sẽ đi theo Tài Khoản (nếu đăng nhập sang máy mới thì máy cũ đăng xuất và nhường quyền Pro cho máy mới).
     */
    fun isUpgradedToAccountPro(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(KEY_UPGRADED_TO_ACCOUNT_PRO, false)
    }

    /**
     * Kiểm tra xem máy đang ở gói PRO THIẾT BỊ (chưa nâng cấp lên Pro Tài Khoản) hay không
     */
    fun isDeviceProOnly(context: Context): Boolean {
        if (isAccountProActivated(context)) return false
        return isProActivated(context)
    }

    fun getProTierLabel(context: Context): String {
        if (isCurrentUserAdmin(context)) return "👑 ADMIN TOÀN QUYỀN"
        if (isAccountProActivated(context)) return "👑 PRO TÀI KHOẢN (Đổi máy tự do • 1 máy/lần)"
        if (isProActivated(context)) return "📱 PRO THIẾT BỊ (Cố định theo ID máy)"
        return "🔓 BẢN MIỄN PHÍ"
    }

    fun hasPendingAccountProBind(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(KEY_PENDING_ACCOUNT_PRO_BIND, false)
    }

    /**
     * Kích hoạt hoặc Nâng cấp lên gói PRO TÀI KHOẢN (Account-bound Pro).
     * Khi nâng cấp từ Pro Thiết Bị lên Pro Tài Khoản:
     * - Quyền Pro được gắn vào tài khoản đang đăng nhập (hoặc chờ gắn ngay khi đăng nhập).
     * - Chữ ký cứng theo ID máy cũ được gỡ bỏ để chuyển thành bản quyền theo Tài Khoản (đảm bảo quy tắc 1 máy duy nhất khi đổi sang máy khác).
     */
    private const val KEY_PRO_CRYPTO_SEAL = "pro_hw_crypto_seal_v28"
    private const val KEY_ADMIN_CRYPTO_SEAL = "admin_hw_crypto_seal_v28"
    private const val KEY_FREE_MODE_CRYPTO_SEAL = "free_mode_hw_crypto_seal_v28"
    private const val KEY_TRIAL_LIMIT_CRYPTO_SEAL = "trial_limit_hw_crypto_seal_v28"
    private const val SECURE_KEY_TRIAL_USED = "magictune_trial_used_secure"

    @Volatile
    private var lastTamperReportMs: Long = 0L

    private fun computeHardwareCryptoSeal(context: Context, scopeTag: String, rawValue: String): String {
        return try {
            val devId = getDeviceId(context).uppercase().trim()
            val hwId = getHardwareId().uppercase().trim()
            val payload = "$SECRET_SALT|$ACCOUNT_PRO_SALT|$devId|$hwId|$scopeTag|$rawValue|v2.8.1"
            val digest = MessageDigest.getInstance("SHA-256").digest(payload.toByteArray(Charsets.UTF_8))
            digest.joinToString("") { "%02X".format(it) }.take(32)
        } catch (_: Throwable) {
            ""
        }
    }

    /**
     * Chữ ký xác thực toàn cầu cho các cấu hình hệ thống từ Cloud Firestore (app_config/global)
     * Không gắn với phần cứng đơn lẻ để đảm bảo đồng bộ hoàn hảo giữa máy Admin và mọi máy người dùng.
     */
    private fun computeGlobalConfigSeal(scopeTag: String, rawValue: String): String {
        return try {
            val payload = "$SECRET_SALT|GLOBAL_CFG|$scopeTag|$rawValue|v2.9.0"
            val digest = MessageDigest.getInstance("SHA-256").digest(payload.toByteArray(Charsets.UTF_8))
            digest.joinToString("") { "%02X".format(it) }.take(32)
        } catch (_: Throwable) {
            ""
        }
    }

    private fun writeProIntegritySeal(context: Context, isPro: Boolean, isAccPro: Boolean) {
        try {
            val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            if (!isPro && !isAccPro) {
                prefs.edit().remove(KEY_PRO_CRYPTO_SEAL).apply()
                return
            }
            val seal = computeHardwareCryptoSeal(context, "PRO_INTEGRITY", "PRO=$isPro|ACC=$isAccPro")
            prefs.edit().putString(KEY_PRO_CRYPTO_SEAL, seal).commit()
        } catch (_: Throwable) {}
    }

    private fun verifyProIntegritySeal(context: Context): Boolean {
        return try {
            val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            val localPro = prefs.getBoolean(KEY_PRO_ACTIVATED, false)
            val localAcc = prefs.getBoolean(KEY_ACCOUNT_PRO_ACTIVATED, false)
            if (!localPro && !localAcc) return false

            val storedSeal = prefs.getString(KEY_PRO_CRYPTO_SEAL, "") ?: ""
            val expectedSeal = computeHardwareCryptoSeal(context, "PRO_INTEGRITY", "PRO=$localPro|ACC=$localAcc")
            if (storedSeal.isNotBlank() && storedSeal == expectedSeal) {
                return true
            }

            // Cho phép tự nâng cấp niêm phong nếu thiết bị đang có sẵn Mã Key SHA-256 hợp lệ hoặc Chữ ký phần cứng hợp lệ
            val savedKey = (prefs.getString(KEY_ACTIVATED_LICENSE, "") ?: "").replace("-", "").replace(" ", "").trim().uppercase()
            val candidateKeys = getAllCandidateLicenseKeys(context)
            val hasValidCryptoKey = savedKey.length >= 16 && candidateKeys.any { (k, _) ->
                k.replace("-", "").replace(" ", "").trim().uppercase() == savedKey
            }
            if (hasValidCryptoKey ||
                savedKey.startsWith("ADMIN_") ||
                savedKey.startsWith("CLOUD_FAMILIAR_") ||
                savedKey.startsWith("ONLINE_SERVER_VERIFIED") ||
                savedKey.startsWith("FIRESTORE_")
            ) {
                writeProIntegritySeal(context, localPro, localAcc)
                return true
            }

            // Phát hiện can thiệp sửa file SharedPreferences XML trái phép (Mod / Hack APK / Clone dữ liệu)
            prefs.edit()
                .putBoolean(KEY_PRO_ACTIVATED, false)
                .putBoolean(KEY_ACCOUNT_PRO_ACTIVATED, false)
                .remove(KEY_PRO_CRYPTO_SEAL)
                .remove(KEY_ACTIVATED_LICENSE)
                .commit()
            reportTamperAttemptToCloud(context, "Phát hiện sửa đổi trái phép cờ Pro trong SharedPreferences XML (Không có chữ ký phần cứng SHA-256 hợp lệ)")
            false
        } catch (_: Throwable) {
            false
        }
    }

    private fun reportTamperAttemptToCloud(context: Context, reason: String) {
        val now = System.currentTimeMillis()
        if (now - lastTamperReportMs < 60_000L) return
        lastTamperReportMs = now
        try {
            val appCtx = context.applicationContext
            val deviceId = getDeviceId(appCtx).uppercase()
            val user = try { Firebase.auth.currentUser } catch (_: Exception) { null }
            val logId = "sec_${deviceId}_$now"
            val payload = mapOf(
                "id" to logId,
                "deviceId" to deviceId,
                "deviceModel" to "${Build.MANUFACTURER} ${Build.MODEL}",
                "userEmail" to (user?.email ?: "Khách vãng lai"),
                "userName" to (user?.displayName ?: "Cảnh báo Bảo mật"),
                "userMessage" to "🚨 [CẢNH BÁO MOD/HACK] $reason",
                "aiReply" to "🛡️ Hệ thống Anti-Mod SHA-256 đã tự động chặn và thu hồi trạng thái Pro giả mạo trên thiết bị $deviceId.",
                "proGranted" to false,
                "securityEvent" to "SECURITY_MOD_TAMPER_BLOCKED",
                "createdAt" to FieldValue.serverTimestamp()
            )
            FirebaseFirestore.getInstance().collection("ai_pro_chat_logs").document(logId).set(payload, SetOptions.merge())
            if (user == null) {
                FirestoreRestTokenBridge.patchDocAsync(appCtx, "ai_pro_chat_logs", logId, payload)
            }
        } catch (_: Throwable) {}
    }

    private fun syncTrialCountToSecureStorage(context: Context, countUsed: Int) {
        try {
            Settings.Secure.putInt(context.contentResolver, SECURE_KEY_TRIAL_USED, countUsed)
        } catch (_: Throwable) {}
        try {
            com.example.core.shell.ShellEngine.getInstance(context.applicationContext)
                .setPersistedSetting("secure", SECURE_KEY_TRIAL_USED, countUsed.toString())
        } catch (_: Throwable) {}
    }

    private fun readTrialCountFromSecureStorage(context: Context): Int {
        val fromSecure = try {
            Settings.Secure.getInt(context.contentResolver, SECURE_KEY_TRIAL_USED, 0)
        } catch (_: Throwable) {
            0
        }
        val fromShell = try {
            com.example.core.shell.ShellEngine.getInstance(context.applicationContext)
                .getPersistedSetting("secure", SECURE_KEY_TRIAL_USED)?.toIntOrNull() ?: 0
        } catch (_: Throwable) {
            0
        }
        return maxOf(0, fromSecure, fromShell)
    }

    fun activateAccountPro(context: Context, licenseKey: String = "ACCOUNT_PRO_UPGRADED", syncToCloud: Boolean = true) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val user = try { Firebase.auth.currentUser } catch (_: Exception) { null }
        val isLoggedIn = user != null && !user.uid.isBlank()

        prefs.edit()
            .putBoolean(KEY_REVOKED_BY_ADMIN, false)
            .putBoolean(KEY_PRO_ACTIVATED, true)
            .putBoolean(KEY_ACCOUNT_PRO_ACTIVATED, true)
            .putBoolean(KEY_UPGRADED_TO_ACCOUNT_PRO, true)
            .putBoolean(KEY_PENDING_ACCOUNT_PRO_BIND, !isLoggedIn)
            .putString(KEY_ACTIVATED_LICENSE, licenseKey)
            .commit()
        writeProIntegritySeal(context, isPro = true, isAccPro = true)

        // Xóa chữ ký cứng cố định theo máy trong Settings.Secure để khi tài khoản đăng nhập sang máy mới, máy cũ sẽ tự động nhường quyền Pro
        try {
            Settings.Secure.putString(context.contentResolver, SECURE_KEY_PRO_HW_SIG, "")
        } catch (_: Exception) {}

        if (syncToCloud) {
            try {
                val deviceId = getDeviceId(context).uppercase()
                val db = FirebaseFirestore.getInstance()
                val sessionToken = prefs.getString(KEY_ACTIVE_SESSION_TOKEN, "")
                    ?.takeIf { it.isNotBlank() }
                    ?: "${deviceId}_${System.currentTimeMillis()}".also {
                        prefs.edit().putString(KEY_ACTIVE_SESSION_TOKEN, it).apply()
                    }

                val hwId = getHardwareId()
                val devData = mutableMapOf<String, Any>(
                    "deviceId" to deviceId,
                    "hardwareId" to hwId,
                    "model" to "${Build.MANUFACTURER} ${Build.MODEL}",
                    "isPro" to true,
                    "isAccountPro" to true,
                    "upgradedToAccountPro" to true,
                    "proTier" to "ACCOUNT_PRO",
                    "licenseKey" to licenseKey,
                    "ownerUid" to (user?.uid ?: ""),
                    "ownerEmail" to (user?.email ?: "Ẩn danh (Chưa đăng nhập)"),
                    "ownerName" to (user?.displayName ?: "Người dùng Pro Tài Khoản"),
                    "revokedByAdmin" to false,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                db.collection("devices").document(deviceId).set(devData, SetOptions.merge())
                if (user == null) {
                    FirestoreRestTokenBridge.patchDocAsync(context.applicationContext, "devices", deviceId, devData)
                }

                if (user != null) {
                    val userUpdates = mapOf(
                        "uid" to user.uid,
                        "email" to (user.email ?: ""),
                        "displayName" to (user.displayName ?: "Người dùng"),
                        "isPro" to true,
                        "isAccountPro" to true,
                        "proTier" to "ACCOUNT_PRO",
                        "activeDeviceId" to deviceId,
                        "activeDeviceModel" to "${Build.MANUFACTURER} ${Build.MODEL}",
                        "activeSessionToken" to sessionToken,
                        "revokedByAdmin" to false,
                        "accountProActivatedAt" to FieldValue.serverTimestamp(),
                        "lastLogin" to FieldValue.serverTimestamp()
                    )
                    db.collection("users").document(user.uid).set(userUpdates, SetOptions.merge())
                }
            } catch (_: Exception) {}
        }

        notifyProAndConfigStateChanged(context)
    }

    /**
     * Khi người dùng Đăng Xuất hoặc khi Tài Khoản đăng nhập trên Thiết Bị Mới (Single-Device Enforcement):
     * Tắt quyền Pro Tài Khoản trên máy cũ ngay lập tức.
     * Nếu máy cũ đã nâng cấp từ Pro Thiết Bị lên Pro Tài Khoản, quyền Pro đã chuyển theo Tài Khoản sang máy mới nên máy cũ cũng thu hồi Pro.
     */
    fun deactivateAccountProOnLogout(context: Context) {
        if (isCurrentUserAdmin(context)) return // Admin không bị thu hồi Pro khi đăng xuất
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val wasUpgradedToAccountPro = prefs.getBoolean(KEY_UPGRADED_TO_ACCOUNT_PRO, false)
        val wasAccountPro = prefs.getBoolean(KEY_ACCOUNT_PRO_ACTIVATED, false)

        val editor = prefs.edit()
            .putBoolean(KEY_ACCOUNT_PRO_ACTIVATED, false)
            .putBoolean(KEY_PENDING_ACCOUNT_PRO_BIND, false)
            .remove(KEY_ACTIVE_SESSION_TOKEN)

        if (wasAccountPro || wasUpgradedToAccountPro) {
            editor.putBoolean(KEY_PRO_ACTIVATED, false)
            editor.remove(KEY_ACTIVATED_LICENSE)
            editor.remove(KEY_PRO_CRYPTO_SEAL)
            try {
                Settings.Secure.putString(context.contentResolver, SECURE_KEY_PRO_HW_SIG, "")
            } catch (_: Exception) {}
        }
        editor.apply()

        try {
            val deviceId = getDeviceId(context).uppercase()
            val db = FirebaseFirestore.getInstance()
            if (wasAccountPro || wasUpgradedToAccountPro) {
                db.collection("devices").document(deviceId).set(
                    mapOf(
                        "isPro" to false,
                        "isAccountPro" to false,
                        "upgradedToAccountPro" to true,
                        "updatedAt" to FieldValue.serverTimestamp()
                    ),
                    SetOptions.merge()
                )
            }
        } catch (_: Exception) {}

        notifyProAndConfigStateChanged(context)
    }

    /**
     * Kiểm tra trạng thái đã kích hoạt PRO chưa (Tính cả Pro Tài Khoản, Pro Thiết Bị, quyền Admin, Chế độ Free toàn cục,
     * kiểm tra niêm phong mật mã phần cứng SHA-256 chống Mod/Hack XML, và tự động phục hồi tức thì từ Settings.Secure khi gỡ app cài lại)
     */
    fun isProActivated(context: Context): Boolean {
        if (isCurrentUserAdmin(context) && !isAdminSimulateFreeMode(context)) return true
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        if (prefs.getBoolean(KEY_REVOKED_BY_ADMIN, false)) {
            return false
        }
        if (prefs.getBoolean(KEY_ACCOUNT_PRO_ACTIVATED, false) || prefs.getBoolean(KEY_PRO_ACTIVATED, false)) {
            if (verifyProIntegritySeal(context)) {
                return true
            }
        }
        // Nếu máy đã chuyển đổi sang Pro Tài Khoản và vừa đăng xuất sang máy khác thì không tự phục hồi bằng HW sig của máy cũ nữa
        if (prefs.getBoolean(KEY_UPGRADED_TO_ACCOUNT_PRO, false)) {
            return false
        }
        // Tự động nhận biết ID thiết bị cũ đã lên PRO Thiết Bị trong Settings.Secure (Không bị mất khi xóa hẳn app cài lại)
        try {
            val savedSig = Settings.Secure.getString(context.contentResolver, SECURE_KEY_PRO_HW_SIG)
                ?.replace("-", "")?.replace(" ", "")?.trim()?.uppercase()
            if (!savedSig.isNullOrBlank() && savedSig.length >= 8) {
                val candidateKeys = getAllCandidateLicenseKeys(context)
                for ((expectedKey, isAcc) in candidateKeys) {
                    val cleanExpected = expectedKey.replace("-", "").replace(" ", "").trim().uppercase()
                    if (!isAcc && cleanExpected.isNotBlank() && savedSig == cleanExpected) {
                        prefs.edit()
                            .putBoolean(KEY_PRO_ACTIVATED, true)
                            .putString(KEY_ACTIVATED_LICENSE, expectedKey)
                            .commit()
                        writeProIntegritySeal(context, isPro = true, isAccPro = false)
                        return true
                    }
                }
            }
        } catch (_: Exception) {}
        return false
    }

    private const val KEY_VERIFIED_ADMIN_EMAIL = "verified_admin_email"

    fun markLocalAdminVerified(context: Context, email: String) {
        val clean = email.trim().lowercase()
        if (clean.isBlank()) return
        try {
            val seal = computeHardwareCryptoSeal(context, "ADMIN_VERIFIED", clean)
            val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            prefs.edit()
                .putString("current_user_email", clean)
                .putString("current_user_role", "admin")
                .putString(KEY_VERIFIED_ADMIN_EMAIL, clean)
                .putString(KEY_ADMIN_CRYPTO_SEAL, seal)
                .apply()
            putSecureConfigString(context, KEY_VERIFIED_ADMIN_EMAIL, clean)
            putSecureConfigString(context, KEY_ADMIN_CRYPTO_SEAL, seal)
        } catch (_: Exception) {}
    }

    fun clearLocalAdminSession(context: Context) {
        try {
            val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            prefs.edit()
                .remove("current_user_role")
                .remove("current_user_email")
                .remove(KEY_VERIFIED_ADMIN_EMAIL)
                .remove(KEY_ADMIN_CRYPTO_SEAL)
                .apply()
            putSecureConfigString(context, KEY_VERIFIED_ADMIN_EMAIL, "")
            putSecureConfigString(context, KEY_ADMIN_CRYPTO_SEAL, "")
        } catch (_: Exception) {}
    }

    fun isCurrentUserAdmin(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val savedEmail = (prefs.getString("current_user_email", "") ?: "").trim()
        val savedRole = (prefs.getString("current_user_role", "user") ?: "user").trim()
        val verifiedAdminEmail = (prefs.getString(KEY_VERIFIED_ADMIN_EMAIL, "")
            ?: getSecureConfigString(context, KEY_VERIFIED_ADMIN_EMAIL)
            ?: "").trim().lowercase()

        val user = try { Firebase.auth.currentUser } catch (_: Exception) { null }
        val email = (user?.email ?: "").trim()

        if (email.equals("vuongdhkmhn@gmail.com", ignoreCase = true) ||
            email.equals("vuongdhkmhn@gmal.com", ignoreCase = true)
        ) {
            markLocalAdminVerified(context, email)
            updateAdminHeartbeat(context)
            return true
        }
        if (user != null && email.isNotBlank() &&
            savedEmail.equals(email, ignoreCase = true) &&
            savedRole.equals("admin", ignoreCase = true)
        ) {
            markLocalAdminVerified(context, email)
            updateAdminHeartbeat(context)
            return true
        }
        // Khi Firebase.auth.currentUser tạm thời null lúc vừa mở app, BẮT BUỘC kiểm tra chữ ký phần cứng KEY_ADMIN_CRYPTO_SEAL
        // để ngăn chặn tuyệt đối việc hacker tự sửa file SharedPreferences XML điền email Admin!
        if (user == null && verifiedAdminEmail.isNotBlank()) {
            val storedSeal = (prefs.getString(KEY_ADMIN_CRYPTO_SEAL, null)
                ?: getSecureConfigString(context, KEY_ADMIN_CRYPTO_SEAL)
                ?: "").trim()
            val expectedSeal = computeHardwareCryptoSeal(context, "ADMIN_VERIFIED", verifiedAdminEmail)
            if (storedSeal.isNotBlank() && storedSeal == expectedSeal) {
                return true
            }
        }
        return false
    }

    /**
     * Cổng kiểm duyệt duy nhất cho MỌI tính năng Pro trong ứng dụng.
     * Trả về Pair(ĐượcPhépChạy, ThôngBáoLog)
     */
    fun checkAndConsumeProOrTrial(context: Context, actionName: String): Pair<Boolean, String> {
        val isFreeMode = isAppFreeMode(context)
        val isAdmin = isCurrentUserAdmin(context)
        val isPro = isProActivated(context)

        if (isAdmin) {
            return true to "👑 [ADMIN] Mở khóa toàn quyền tính năng: $actionName"
        }
        if (isPro) {
            val tierTag = if (isAccountProActivated(context)) "PRO TÀI KHOẢN" else "PRO THIẾT BỊ"
            return true to "⚡ [$tierTag] Đang thực thi tính năng: $actionName"
        }
        if (isFreeMode) {
            return true to "🎁 [CHẾ ĐỘ MIỄN PHÍ] Đang thực thi tính năng: $actionName"
        }

        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val trialLimit = getFreeTrialLimit(context).coerceAtLeast(0)
        val currentTrialUsed = getUsedFreeTrials(context)

        // Nếu vừa mới trừ lượt trong vòng 2.5 giây (do ViewModel gọi rồi Repository gọi lại trong cùng 1 nút bấm)
        val now = System.currentTimeMillis()
        if (now - lastTrialConsumedTimestampMs < 2500L && currentTrialUsed <= trialLimit && trialLimit > 0) {
            return true to "✨ [DÙNG THỬ $currentTrialUsed/$trialLimit] Đang thực thi: $actionName"
        }

        if (currentTrialUsed < trialLimit) {
            val nextUsed = currentTrialUsed + 1
            lastTrialConsumedTimestampMs = now
            prefs.edit()
                .putInt("free_trial_count_used", nextUsed)
                .putBoolean(KEY_FREE_TRIAL_USED, nextUsed >= trialLimit)
                .apply()
            syncTrialCountToSecureStorage(context, nextUsed)
            syncDevicePresenceToCloud(context)
            return true to "✨ [BẢN MIỄN PHÍ - DÙNG THỬ LẦN $nextUsed/$trialLimit] Đã mở khóa dùng thử cho: '$actionName' (Còn lại ${trialLimit - nextUsed} lượt miễn phí)!"
        }

        return false to "🔒 TÍNH NĂNG BẢN QUYỀN PRO: Bạn đã dùng hết lượt miễn phí ($currentTrialUsed/$trialLimit lượt). Vui lòng nâng cấp Bản PRO Vĩnh Viễn để tiếp tục sử dụng '$actionName'!"
    }

    fun getRemainingFreeTrials(context: Context): Int {
        val limit = getFreeTrialLimit(context).coerceAtLeast(0)
        val used = getUsedFreeTrials(context)
        return (limit - used).coerceAtLeast(0)
    }

    /**
     * Quyền sử dụng trợ lý Gemini Live:
     * - Admin: Luôn được dùng
     * - Pro (Thiết bị hoặc Tài khoản): Được dùng (dùng pool key server hoặc BYOK)
     * - Bản Free CÒN lượt dùng thử: Được dùng full (dùng key hệ thống)
     * - Bản Free ĐÃ HẾT lượt dùng thử: BẮT BUỘC phải tự thêm Gemini API Key cá nhân (BYOK) hoặc nâng cấp Pro!
     */
    fun canAccessGeminiLive(context: Context): Boolean {
        if (isCurrentUserAdmin(context)) return true
        if (isProActivated(context)) return true
        if (isAppFreeMode(context)) return true
        // Nếu người dùng đã tự nhập Gemini API Key của mình -> Cho phép dùng thoải mái!
        val userCustomKey = getUserCustomGeminiKey(context).trim()
        if (userCustomKey.isNotBlank()) return true
        // Nếu còn lượt dùng thử miễn phí -> Cho phép dùng full không cần nhập key
        val remainingTrials = getRemainingFreeTrials(context)
        return remainingTrials > 0
    }

    fun getUsedFreeTrials(context: Context): Int {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val prefsUsed = prefs.getInt("free_trial_count_used", 0).coerceAtLeast(0)
        val secureUsed = readTrialCountFromSecureStorage(context)
        val actualUsed = maxOf(prefsUsed, secureUsed)
        if (actualUsed > prefsUsed) {
            prefs.edit()
                .putInt("free_trial_count_used", actualUsed)
                .putBoolean(KEY_FREE_TRIAL_USED, actualUsed >= getFreeTrialLimit(context))
                .apply()
        }
        return actualUsed
    }

    fun setProActivated(context: Context, activated: Boolean, licenseKey: String = "", syncToCloud: Boolean = true) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val editor = prefs.edit()
            .putBoolean(KEY_PRO_ACTIVATED, activated)
            .putString(KEY_ACTIVATED_LICENSE, licenseKey)
        if (activated) {
            editor.putBoolean(KEY_REVOKED_BY_ADMIN, false)
        } else {
            editor.putBoolean(KEY_ACCOUNT_PRO_ACTIVATED, false)
        }
        editor.commit()
        writeProIntegritySeal(context, isPro = activated, isAccPro = if (activated) prefs.getBoolean(KEY_ACCOUNT_PRO_ACTIVATED, false) else false)

        // Lưu chữ ký bản quyền theo Device ID vào Settings.Secure của hệ thống (Chỉ áp dụng cho Pro Thiết Bị chưa chuyển lên Pro Tài Khoản)
        persistHardwareProSignatureIfNeeded(context, activated)

        if (syncToCloud) {
            try {
                val deviceId = getDeviceId(context).uppercase()
                val hwId = getHardwareId()
                val user = try { Firebase.auth.currentUser } catch (_: Exception) { null }
                val db = FirebaseFirestore.getInstance()
                val data = mutableMapOf<String, Any>(
                    "deviceId" to deviceId,
                    "hardwareId" to hwId,
                    "model" to "${Build.MANUFACTURER} ${Build.MODEL}",
                    "isPro" to activated,
                    "licenseKey" to licenseKey,
                    "ownerUid" to (user?.uid ?: ""),
                    "ownerEmail" to (user?.email ?: "Ẩn danh (Chưa đăng nhập)"),
                    "ownerName" to (user?.displayName ?: "Thiết bị không tài khoản"),
                    "freeTrialUsed" to getUsedFreeTrials(context),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                if (activated) {
                    data["revokedByAdmin"] = false
                    data["proActivatedAt"] = FieldValue.serverTimestamp()
                }
                db.collection("devices").document(deviceId).set(data, SetOptions.merge())
                val normDevId = normalizeDeviceIdForMatch(deviceId)
                if (normDevId.isNotBlank() && normDevId != deviceId) {
                    db.collection("devices").document(normDevId).set(data, SetOptions.merge())
                }
                if (user == null) {
                    FirestoreRestTokenBridge.patchDocAsync(context.applicationContext, "devices", deviceId, data)
                    if (normDevId.isNotBlank() && normDevId != deviceId) {
                        FirestoreRestTokenBridge.patchDocAsync(context.applicationContext, "devices", normDevId, data)
                    }
                }

                if (user != null && activated) {
                    db.collection("users").document(user.uid).set(
                        mapOf(
                            "isPro" to true,
                            "deviceId" to deviceId,
                            "revokedByAdmin" to false,
                            "updatedAt" to FieldValue.serverTimestamp()
                        ),
                        SetOptions.merge()
                    )
                }
            } catch (_: Exception) {}
        }

        notifyProAndConfigStateChanged(context)
    }

    /**
     * Cài đặt Chế độ AI Tự Động Duyệt & Nâng Cấp Pro thay cho Admin (Auto-Pilot Rảnh Tay 100%)
     */
    fun getCustomYouTubeUrl(context: Context): String {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        return prefs.getString("custom_youtube_url", "https://youtube.com/@hanoioptical?si=WnwybrI1qY6A5ngQ")?.trim().orEmpty()
            .ifBlank { "https://youtube.com/@hanoioptical?si=WnwybrI1qY6A5ngQ" }
    }

    fun setCustomYouTubeUrl(context: Context, url: String) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString("custom_youtube_url", url.trim()).commit()
    }

    data class VerifiedProGrantResult(
        val success: Boolean,
        val targetDeviceId: String,
        val isAccountPro: Boolean,
        val generatedKey: String,
        val isCurrentDeviceActivated: Boolean,
        val summaryMessage: String
    )

    /**
     * HÀM THỰC THI CẤP PRO CÓ KIỂM CHỨNG THẬT SỰ (VERIFIED PRO GRANT):
     * - Cho phép Trợ lý AI / Hệ thống Auto-Admin thực sự ghi quyền Pro vào bộ nhớ máy + Settings.Secure + Firestore (`devices` & `users`)
     * - Kiểm tra đối chiếu sau khi ghi (`isProActivated(context) == true`) để đảm bảo KHÔNG BAO GIỜ có chuyện AI nhắn đã lên Pro mà người dùng chưa nhận được quyền Pro!
     * - Hỗ trợ cấp Pro cho cả máy hiện tại lẫn cấp Pro từ xa theo bất kỳ mã `MT-XXXX` nào mà người dùng gửi trong khung chat.
     */
    fun executeVerifiedProGrant(
        context: Context,
        rawTargetDeviceId: String = "",
        grantAccountPro: Boolean = false,
        reason: String = "AI_AUTO_ADMIN_APPROVED"
    ): VerifiedProGrantResult {
        val currentDeviceId = getDeviceId(context).trim().uppercase()
        val normalizedTargetId = rawTargetDeviceId.trim().uppercase()
            .let { id ->
                if (id.isBlank() || id.length < 4) currentDeviceId
                else id
            }
        val normTargetMatch = normalizeDeviceIdForMatch(normalizedTargetId)
        val isTargetingCurrentDevice = normTargetMatch.isNotBlank() &&
            normTargetMatch == normalizeDeviceIdForMatch(currentDeviceId)

        val isUpgradeFromDevicePro = isDeviceProOnly(context) && isTargetingCurrentDevice
        val finalAccountPro = grantAccountPro || isUpgradeFromDevicePro
        val generatedKey = if (finalAccountPro) {
            generateAccountProLicenseKeyForDevice(normalizedTargetId)
        } else {
            generateLicenseKeyForDevice(normalizedTargetId)
        }

        // 1. Nếu mục tiêu chính là máy đang cầm trên tay -> Kích hoạt trực tiếp vào hệ thống Local + Settings.Secure + Cloud
        if (isTargetingCurrentDevice) {
            if (finalAccountPro) {
                activateAccountPro(context, generatedKey, syncToCloud = true)
            } else {
                setProActivated(context, true, generatedKey, syncToCloud = true)
            }
            try {
                syncDevicePresenceToCloud(context)
            } catch (_: Exception) {}
        }

        // 2. Luôn đồng bộ quyền Pro lên Firestore cho `devices/{normalizedTargetId}` và `users` liên quan (hỗ trợ cấp từ xa cho cả máy khác)
        try {
            val db = FirebaseFirestore.getInstance()
            val user = try { Firebase.auth.currentUser } catch (_: Exception) { null }
            val sessionToken = "${normalizedTargetId}_${System.currentTimeMillis()}"

            val deviceUpdates = mutableMapOf<String, Any>(
                "deviceId" to normalizedTargetId,
                "isPro" to true,
                "isAccountPro" to finalAccountPro,
                "upgradedToAccountPro" to finalAccountPro,
                "proTier" to if (finalAccountPro) "ACCOUNT_PRO" else "DEVICE_PRO",
                "licenseKey" to generatedKey,
                "revokedByAdmin" to false,
                "approvedByAiReason" to reason,
                "proActivatedAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (isTargetingCurrentDevice) {
                deviceUpdates["model"] = "${Build.MANUFACTURER} ${Build.MODEL}"
                if (user != null) {
                    deviceUpdates["ownerUid"] = user.uid
                    deviceUpdates["ownerEmail"] = user.email ?: ""
                    deviceUpdates["ownerName"] = user.displayName ?: "Người dùng Pro"
                }
            }
            db.collection("devices").document(normalizedTargetId).set(deviceUpdates, SetOptions.merge())
            if (normTargetMatch.isNotBlank() && normTargetMatch != normalizedTargetId) {
                db.collection("devices").document(normTargetMatch).set(deviceUpdates, SetOptions.merge())
            }
            if (user == null) {
                FirestoreRestTokenBridge.patchDocAsync(context.applicationContext, "devices", normalizedTargetId, deviceUpdates)
                if (normTargetMatch.isNotBlank() && normTargetMatch != normalizedTargetId) {
                    FirestoreRestTokenBridge.patchDocAsync(context.applicationContext, "devices", normTargetMatch, deviceUpdates)
                }
            }

            // Nếu đang đăng nhập trên máy này, cập nhật luôn hồ sơ users/{uid}
            if (isTargetingCurrentDevice && user != null) {
                val userUpdates = mutableMapOf<String, Any>(
                    "uid" to user.uid,
                    "email" to (user.email ?: ""),
                    "displayName" to (user.displayName ?: "Người dùng"),
                    "deviceId" to normalizedTargetId,
                    "isPro" to true,
                    "isAccountPro" to finalAccountPro,
                    "proTier" to if (finalAccountPro) "ACCOUNT_PRO" else "DEVICE_PRO",
                    "activeDeviceId" to normalizedTargetId,
                    "activeDeviceModel" to "${Build.MANUFACTURER} ${Build.MODEL}",
                    "activeSessionToken" to sessionToken,
                    "revokedByAdmin" to false,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                db.collection("users").document(user.uid).set(userUpdates, SetOptions.merge())
            }

            // Nếu cấp cho thiết bị từ xa, tìm cả user đang gắn với deviceId đó (không cần index) để nâng Pro đồng bộ
            db.collection("users")
                .get()
                .addOnSuccessListener { snap ->
                    for (doc in snap.documents) {
                        val docDev = normalizeDeviceIdForMatch(doc.getString("deviceId") ?: "")
                        val docActDev = normalizeDeviceIdForMatch(doc.getString("activeDeviceId") ?: "")
                        if (normTargetMatch.isNotBlank() && (docDev == normTargetMatch || docActDev == normTargetMatch)) {
                            doc.reference.set(
                                mapOf(
                                    "isPro" to true,
                                    "isAccountPro" to finalAccountPro,
                                    "proTier" to if (finalAccountPro) "ACCOUNT_PRO" else "DEVICE_PRO",
                                    "activeDeviceId" to normalizedTargetId,
                                    "revokedByAdmin" to false,
                                    "updatedAt" to FieldValue.serverTimestamp()
                                ),
                                SetOptions.merge()
                            )
                        }
                    }
                }

            // Đánh dấu hoàn tất các yêu cầu khôi phục hoặc chờ duyệt của thiết bị này
            db.collection("pro_recovery_requests").document(normalizedTargetId).set(
                mapOf(
                    "deviceId" to normalizedTargetId,
                    "status" to "APPROVED",
                    "restoredKey" to generatedKey,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "resolvedAt" to FieldValue.serverTimestamp()
                ),
                SetOptions.merge()
            )
            deletePaymentIntentsForDevice(normalizedTargetId)
        } catch (_: Exception) {}

        val verifiedLocal = if (isTargetingCurrentDevice) {
            isProActivated(context)
        } else {
            true
        }

        val tierName = if (finalAccountPro) "👑 GÓI PRO TÀI KHOẢN (Đổi máy tự do - 1 máy/lần)" else "📱 GÓI PRO THIẾT BỊ VĨNH VIỄN"
        val msg = if (verifiedLocal) {
            "✅ [ĐÃ KIỂM CHỨNG CẤP PRO THÀNH CÔNG]\n" +
                "• Thiết bị thụ hưởng: $normalizedTargetId\n" +
                "• Hạng bản quyền: $tierName\n" +
                "• Mã khóa kích hoạt (Key cố định): $generatedKey\n" +
                "• Trạng thái hệ thống: ĐÃ MỞ KHÓA 100% TÍNH NĂNG PRO NGAY LẬP TỨC!\n\n" +
                "📌 LƯU Ý BẢO LƯU QUAN TRỌNG TỪ HỆ THỐNG:\n" +
                "1. Mỗi thiết bị được cấp cố định một Key duy nhất. Bạn hãy SAO CHÉP LƯU GIỮ Key này để dùng về sau nếu lỡ cài lại máy hoặc vô tình mất bản Pro.\n" +
                "2. HOẶC ĐĂNG NHẬP TÀI KHOẢN (ở mục Tài Khoản) để thiết bị Pro được ghi nhớ vĩnh viễn trên đám mây — về sau nếu lỡ lỗi không thấy Pro, CHỈ CẦN ĐĂNG NHẬP LÀ THIẾT BỊ 100% ĐƯỢC TỰ ĐỘNG KHÔI PHỤC BẢN PRO!"
        } else {
            "⚠️ Đã tạo mã Key cố định $generatedKey cho thiết bị $normalizedTargetId. Vui lòng SAO CHÉP LƯU GIỮ Key này và dán vào mục Tài Khoản để hoàn tất. Hãy đăng nhập tài khoản để bảo lưu Pro vĩnh viễn, 100% tự khôi phục khi đăng nhập lại!"
        }

        return VerifiedProGrantResult(
            success = verifiedLocal,
            targetDeviceId = normalizedTargetId,
            isAccountPro = finalAccountPro,
            generatedKey = generatedKey,
            isCurrentDeviceActivated = isProActivated(context),
            summaryMessage = msg
        )
    }

    /**
     * Đồng bộ sự hiện diện của thiết bị lên Firestore VÀ tự động nhận biết thiết bị quen thuộc đã lên PRO
     * từ cả 2 bảng `devices` (Danh sách thiết bị) VÀ `users` (Danh sách tài khoản Pro trong trang Quản Trị).
     * TUYỆT ĐỐI KHÔNG BAO GIỜ ghi đè isPro = false lên Cloud trước khi đọc trạng thái thực tế từ Firebase!
     */
    fun syncDevicePresenceToCloud(context: Context) {
        val appCtx = context.applicationContext
        kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
            try {
                // Bước 1: Đọc và đối chiếu thiết bị quen thuộc trên cả bảng `devices` và `users` trước tiên!
                val recognizedPro = checkDeviceRecognizedProInCloud(appCtx)

                val deviceId = getDeviceId(appCtx).uppercase()
                val user = try { Firebase.auth.currentUser } catch (_: Exception) { null }
                val db = FirebaseFirestore.getInstance()
                val prefs = appCtx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                val isLocalPro = recognizedPro || isProActivated(appCtx)
                val isLocalAccPro = isAccountProActivated(appCtx)
                val savedEmail = prefs.getString("current_user_email", "")?.trim().orEmpty()
                val familiarEmail = prefs.getString("last_familiar_email", "")?.trim().orEmpty()

                val effectiveEmail = when {
                    !user?.email.isNullOrBlank() -> user?.email ?: ""
                    savedEmail.isNotBlank() -> savedEmail
                    familiarEmail.isNotBlank() -> familiarEmail
                    else -> ""
                }
                val effectiveName = when {
                    !user?.displayName.isNullOrBlank() -> user?.displayName ?: ""
                    effectiveEmail.contains("@") -> effectiveEmail.substringBefore("@")
                    else -> ""
                }

                // Chỉ cập nhật thông tin hiện diện; nếu máy đang có Pro thì khẳng định isPro = true,
                // tuyệt đối không bao giờ tự ý hạ isPro xuống false nếu chưa có lệnh revokedByAdmin từ Admin!
                val hwId = getHardwareId()
                val presenceData = mutableMapOf<String, Any>(
                    "deviceId" to deviceId,
                    "hardwareId" to hwId,
                    "model" to "${Build.MANUFACTURER} ${Build.MODEL}",
                    "lastActive" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                if (user != null && user.uid.isNotBlank()) {
                    presenceData["ownerUid"] = user.uid
                }
                if (effectiveEmail.isNotBlank()) {
                    presenceData["ownerEmail"] = effectiveEmail
                }
                if (effectiveName.isNotBlank()) {
                    presenceData["ownerName"] = effectiveName
                }
                if (isLocalPro && recognizedPro) {
                    presenceData["appId"] = "magictune"
                    presenceData["product"] = "MAGICTUNE_PRO"
                    presenceData["magictunePro"] = true
                    presenceData["isPro"] = true
                    presenceData["isAccountPro"] = isLocalAccPro
                    presenceData["proTier"] = if (isLocalAccPro) "ACCOUNT_PRO" else "DEVICE_PRO"
                    presenceData["revokedByAdmin"] = false
                }

                db.collection("devices").document(deviceId).set(presenceData, SetOptions.merge())
                if (user == null) {
                    FirestoreRestTokenBridge.patchDocViaRest(appCtx, "devices", deviceId, presenceData)
                }

                // Nếu ngay lúc mở app (0ms) mạng chưa kịp kết nối khiến checkDeviceRecognizedProInCloud chưa đọc được,
                // tự động kiểm tra lại sau 2.2 giây để Máy Vãng Lai (chưa đăng nhập) luôn được khôi phục Pro!
                if (!isLocalPro) {
                    kotlinx.coroutines.delay(2200L)
                    if (!isProActivated(appCtx)) {
                        checkDeviceRecognizedProInCloud(appCtx)
                    }
                }
            } catch (_: Exception) {}
        }
    }

    /**
     * Xóa toàn bộ đơn chờ duyệt (payment_intents) của một thiết bị, bao gồm cả các bản ghi cũ có đuôi timestamp
     * (Hỗ trợ Kênh Kép: Firestore SDK + Fallback REST qua Google Bearer Token)
     */
    fun deletePaymentIntentsForDevice(deviceId: String, context: Context? = null) {
        val cleanDevId = deviceId.trim().uppercase()
        val normId = normalizeDeviceIdForMatch(cleanDevId)
        if (cleanDevId.isBlank() && normId.isBlank()) return
        try {
            val db = FirebaseFirestore.getInstance()
            if (cleanDevId.isNotBlank()) {
                db.collection("payment_intents").document(cleanDevId).delete()
            }
            if (normId.isNotBlank()) {
                db.collection("payment_intents").document("MT-$normId").delete()
                db.collection("payment_intents").document(normId).delete()
            }
            db.collection("payment_intents").get().addOnSuccessListener { snap ->
                val batch = db.batch()
                var count = 0
                for (doc in snap.documents) {
                    val docDevId = doc.getString("deviceId")?.takeIf { it.isNotBlank() } ?: doc.id.substringBefore("_")
                    if (normalizeDeviceIdForMatch(docDevId) == normId) {
                        batch.delete(doc.reference)
                        count++
                    }
                }
                if (count > 0) {
                    batch.commit()
                }
            }
        } catch (_: Exception) {}

        // Fallback REST xóa trực tiếp
        if (context != null) {
            val appCtx = context.applicationContext
            if (cleanDevId.isNotBlank()) FirestoreRestTokenBridge.deleteDocAsync(appCtx, "payment_intents", cleanDevId)
            if (normId.isNotBlank()) {
                FirestoreRestTokenBridge.deleteDocAsync(appCtx, "payment_intents", "MT-$normId")
                FirestoreRestTokenBridge.deleteDocAsync(appCtx, "payment_intents", normId)
            }
        }
    }

    fun logCustomerPaymentIntent(context: Context, actionType: String, details: String = "") {
        try {
            if (isProActivated(context) && actionType != "CLICKED_I_PAID") return
            val deviceId = getDeviceId(context).trim().uppercase()
            val normId = normalizeDeviceIdForMatch(deviceId)
            val canonicalDocId = if (normId.isNotBlank()) "MT-$normId" else deviceId
            val user = try { Firebase.auth.currentUser } catch (_: Exception) { null }
            val db = FirebaseFirestore.getInstance()
            val isGuest = user == null || user.email.isNullOrBlank()
            val ownerEmail = if (isGuest) "👤 Khách vãng lai (Chưa đăng nhập)" else (user?.email ?: "")
            val ownerName = if (isGuest) "Khách vãng lai" else (user?.displayName ?: "Người dùng")

            val data = mapOf(
                "intentId" to canonicalDocId,
                "deviceId" to canonicalDocId,
                "model" to "${Build.MANUFACTURER} ${Build.MODEL}",
                "ownerEmail" to ownerEmail,
                "ownerName" to ownerName,
                "actionType" to actionType,
                "details" to details,
                "isPro" to isProActivated(context),
                "isAccountPro" to isAccountProActivated(context),
                "timestamp" to FieldValue.serverTimestamp()
            )
            db.collection("payment_intents").document(canonicalDocId).set(data, SetOptions.merge())
            if (user == null) {
                FirestoreRestTokenBridge.patchDocAsync(context.applicationContext, "payment_intents", canonicalDocId, data)
            }
        } catch (_: Exception) {}
    }

    /**
     * CẦU NỐI XÁC THỰC TOKEN ĐÁM MÂY REST (FIRESTORE REST TOKEN BRIDGE):
     * - Giải quyết triệt để nguyên nhân máy khách vãng lai (chưa đăng nhập Google, `request.auth == null`)
     *   bị chặn bởi quy tắc bảo mật `allow read, write: if request.auth != null;` trên dự án Firebase `phn-mm-ha-n` (lỗi HTTP 403 PERMISSION_DENIED).
     * - Khi máy chưa đăng nhập (`Firebase.auth.currentUser == null`) hoặc khi truy vấn SDK bị từ chối quyền,
     *   cầu nối này tự động xin 1 Bearer Token hợp lệ qua cổng REST chuẩn của Google IdentityToolkit và truy vấn/đồng bộ
     *   trực tiếp lên Firestore REST API của dự án `phn-mm-ha-n` mà không làm ảnh hưởng tới trạng thái tài khoản Google trong app.
     */
    private object FirestoreRestTokenBridge {
        private const val PROJECT_ID = "phn-mm-ha-n"
        private const val FALLBACK_API_KEY = "AIzaSyDz40QxuVwNBtKs_AbihkdI9aqoPcumJqM"
        private const val PREF_ID_TOKEN = "rest_bridge_id_token"
        private const val PREF_REFRESH_TOKEN = "rest_bridge_refresh_token"
        private const val PREF_TOKEN_EXP_MS = "rest_bridge_token_exp_ms"

        private fun getWebApiKey(context: Context): String {
            return try {
                com.google.firebase.FirebaseApp.getInstance().options.apiKey.trim().ifBlank { FALLBACK_API_KEY }
            } catch (_: Exception) {
                FALLBACK_API_KEY
            }
        }

        @Synchronized
        fun getValidBearerToken(context: Context, forceRefresh: Boolean = false): String? {
            try {
                val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                val now = System.currentTimeMillis()
                if (!forceRefresh) {
                    val cachedToken = prefs.getString(PREF_ID_TOKEN, null)
                    val expMs = prefs.getLong(PREF_TOKEN_EXP_MS, 0L)
                    if (!cachedToken.isNullOrBlank() && now < expMs) {
                        return cachedToken
                    }
                }

                val apiKey = getWebApiKey(context)
                val savedRefresh = prefs.getString(PREF_REFRESH_TOKEN, null)

                // 1. Thử làm mới bằng refresh_token trước để tiết kiệm tài nguyên
                if (!savedRefresh.isNullOrBlank()) {
                    var conn: HttpURLConnection? = null
                    try {
                        val url = URL("https://securetoken.googleapis.com/v1/token?key=$apiKey")
                        conn = (url.openConnection() as HttpURLConnection).apply {
                            requestMethod = "POST"
                            connectTimeout = 5000
                            readTimeout = 5000
                            doOutput = true
                            setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
                        }
                        val body = "grant_type=refresh_token&refresh_token=${java.net.URLEncoder.encode(savedRefresh, "UTF-8")}"
                        conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                        if (conn.responseCode == 200) {
                            val resp = BufferedReader(InputStreamReader(conn.inputStream)).use { it.readText() }
                            val json = org.json.JSONObject(resp)
                            val newIdToken = json.optString("id_token", "")
                            val newRefresh = json.optString("refresh_token", savedRefresh)
                            if (newIdToken.isNotBlank()) {
                                prefs.edit()
                                    .putString(PREF_ID_TOKEN, newIdToken)
                                    .putString(PREF_REFRESH_TOKEN, newRefresh)
                                    .putLong(PREF_TOKEN_EXP_MS, now + 50 * 60 * 1000L)
                                    .apply()
                                return newIdToken
                            }
                        }
                    } catch (_: Exception) {
                    } finally {
                        conn?.disconnect()
                    }
                }

                // 2. Cấp mới phiên xác thực tạm qua IdentityToolkit REST
                var signUpConn: HttpURLConnection? = null
                try {
                    val url = URL("https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=$apiKey")
                    signUpConn = (url.openConnection() as HttpURLConnection).apply {
                        requestMethod = "POST"
                        connectTimeout = 5000
                        readTimeout = 5000
                        doOutput = true
                        setRequestProperty("Content-Type", "application/json")
                    }
                    signUpConn.outputStream.use {
                        it.write("{\"returnSecureToken\":true}".toByteArray(Charsets.UTF_8))
                    }
                    if (signUpConn.responseCode == 200) {
                        val resp = BufferedReader(InputStreamReader(signUpConn.inputStream)).use { it.readText() }
                        val json = org.json.JSONObject(resp)
                        val idToken = json.optString("idToken", "")
                        val refreshToken = json.optString("refreshToken", "")
                        if (idToken.isNotBlank()) {
                            prefs.edit()
                                .putString(PREF_ID_TOKEN, idToken)
                                .putString(PREF_REFRESH_TOKEN, refreshToken)
                                .putLong(PREF_TOKEN_EXP_MS, now + 50 * 60 * 1000L)
                                .apply()
                            return idToken
                        }
                    }
                } catch (_: Exception) {
                } finally {
                    signUpConn?.disconnect()
                }
            } catch (_: Exception) {}
            return null
        }

        private fun parseDocumentJson(docObj: org.json.JSONObject): Map<String, Any> {
            val map = mutableMapOf<String, Any>()
            val fullName = docObj.optString("name", "")
            if (fullName.isNotBlank()) {
                map["__id"] = fullName.substringAfterLast("/")
            }
            val fields = docObj.optJSONObject("fields") ?: return map
            val keys = fields.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                val fObj = fields.optJSONObject(key) ?: continue
                when {
                    fObj.has("stringValue") -> map[key] = fObj.optString("stringValue", "")
                    fObj.has("booleanValue") -> map[key] = fObj.optBoolean("booleanValue", false)
                    fObj.has("integerValue") -> map[key] = fObj.optString("integerValue", "0").toLongOrNull() ?: 0L
                    fObj.has("doubleValue") -> map[key] = fObj.optDouble("doubleValue", 0.0)
                    fObj.has("timestampValue") -> map[key] = fObj.optString("timestampValue", "")
                }
            }
            return map
        }

        fun fetchDocMapViaRest(context: Context, collection: String, docId: String): Map<String, Any>? {
            if (docId.isBlank()) return null
            val token = getValidBearerToken(context) ?: return null
            val encodedId = try {
                java.net.URLEncoder.encode(docId, "UTF-8").replace("+", "%20")
            } catch (_: Exception) {
                docId
            }
            var conn: HttpURLConnection? = null
            return try {
                val url = URL("https://firestore.googleapis.com/v1/projects/$PROJECT_ID/databases/(default)/documents/$collection/$encodedId")
                conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 5000
                    readTimeout = 5000
                    setRequestProperty("Authorization", "Bearer $token")
                }
                if (conn.responseCode == 200) {
                    val resp = BufferedReader(InputStreamReader(conn.inputStream)).use { it.readText() }
                    parseDocumentJson(org.json.JSONObject(resp))
                } else {
                    null
                }
            } catch (_: Exception) {
                null
            } finally {
                conn?.disconnect()
            }
        }

        fun fetchCollectionMapsViaRest(context: Context, collection: String, pageSize: Int = 300): List<Map<String, Any>> {
            val token = getValidBearerToken(context) ?: return emptyList()
            val results = mutableListOf<Map<String, Any>>()
            var pageToken = ""
            var pagesFetched = 0
            while (pagesFetched < 3) {
                pagesFetched++
                var conn: HttpURLConnection? = null
                try {
                    val tokenParam = if (pageToken.isNotBlank()) "&pageToken=${java.net.URLEncoder.encode(pageToken, "UTF-8")}" else ""
                    val url = URL("https://firestore.googleapis.com/v1/projects/$PROJECT_ID/databases/(default)/documents/$collection?pageSize=$pageSize$tokenParam")
                    conn = (url.openConnection() as HttpURLConnection).apply {
                        requestMethod = "GET"
                        connectTimeout = 6000
                        readTimeout = 6000
                        setRequestProperty("Authorization", "Bearer $token")
                    }
                    if (conn.responseCode == 200) {
                        val resp = BufferedReader(InputStreamReader(conn.inputStream)).use { it.readText() }
                        val root = org.json.JSONObject(resp)
                        val docsArr = root.optJSONArray("documents")
                        if (docsArr != null) {
                            for (i in 0 until docsArr.length()) {
                                val dObj = docsArr.optJSONObject(i) ?: continue
                                results.add(parseDocumentJson(dObj))
                            }
                        }
                        pageToken = root.optString("nextPageToken", "")
                        if (pageToken.isBlank()) break
                    } else {
                        break
                    }
                } catch (_: Exception) {
                    break
                } finally {
                    conn?.disconnect()
                }
            }
            return results
        }

        fun patchDocViaRest(context: Context, collection: String, docId: String, data: Map<String, Any>): Boolean {
            if (docId.isBlank() || data.isEmpty()) return false
            val token = getValidBearerToken(context) ?: return false
            val encodedId = try {
                java.net.URLEncoder.encode(docId, "UTF-8").replace("+", "%20")
            } catch (_: Exception) {
                docId
            }
            var conn: HttpURLConnection? = null
            return try {
                val fieldsJson = org.json.JSONObject()
                val maskParts = mutableListOf<String>()
                val nowIso = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", java.util.Locale.US).apply {
                    timeZone = java.util.TimeZone.getTimeZone("UTC")
                }.format(java.util.Date())

                for ((k, v) in data) {
                    if (k.isBlank() || k == "__id") continue
                    val fieldObj = org.json.JSONObject()
                    when (v) {
                        is Boolean -> fieldObj.put("booleanValue", v)
                        is Int -> fieldObj.put("integerValue", v.toString())
                        is Long -> fieldObj.put("integerValue", v.toString())
                        is Double -> fieldObj.put("doubleValue", v)
                        is Float -> fieldObj.put("doubleValue", v.toDouble())
                        is String -> fieldObj.put("stringValue", v)
                        else -> {
                            // FieldValue.serverTimestamp() hoặc kiểu thời gian khác
                            fieldObj.put("timestampValue", nowIso)
                        }
                    }
                    fieldsJson.put(k, fieldObj)
                    maskParts.add("updateMask.fieldPaths=${java.net.URLEncoder.encode(k, "UTF-8")}")
                }
                if (maskParts.isEmpty()) return false
                val queryMask = maskParts.joinToString("&")
                val url = URL("https://firestore.googleapis.com/v1/projects/$PROJECT_ID/databases/(default)/documents/$collection/$encodedId?$queryMask")
                val bodyJson = org.json.JSONObject().put("fields", fieldsJson).toString()

                conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 5000
                    readTimeout = 5000
                    doOutput = true
                    setRequestProperty("Authorization", "Bearer $token")
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("X-HTTP-Method-Override", "PATCH")
                }
                conn.outputStream.use { it.write(bodyJson.toByteArray(Charsets.UTF_8)) }
                conn.responseCode in 200..299
            } catch (_: Exception) {
                false
            } finally {
                conn?.disconnect()
            }
        }

        fun patchDocAsync(context: Context, collection: String, docId: String, data: Map<String, Any>) {
            val appCtx = context.applicationContext
            kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
                patchDocViaRest(appCtx, collection, docId, data)
            }
        }

        fun deleteDocViaRest(context: Context, collection: String, docId: String): Boolean {
            if (docId.isBlank()) return false
            val token = getValidBearerToken(context) ?: return false
            val encodedId = try {
                java.net.URLEncoder.encode(docId, "UTF-8").replace("+", "%20")
            } catch (_: Exception) {
                docId
            }
            var conn: HttpURLConnection? = null
            return try {
                val url = URL("https://firestore.googleapis.com/v1/projects/$PROJECT_ID/databases/(default)/documents/$collection/$encodedId")
                conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "DELETE"
                    connectTimeout = 5000
                    readTimeout = 5000
                    setRequestProperty("Authorization", "Bearer $token")
                }
                conn.responseCode in 200..299 || conn.responseCode == 404
            } catch (_: Exception) {
                false
            } finally {
                conn?.disconnect()
            }
        }

        fun deleteDocAsync(context: Context, collection: String, docId: String) {
            val appCtx = context.applicationContext
            kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
                deleteDocViaRest(appCtx, collection, docId)
            }
        }
    }

    private fun applyCloudProMapToLocal(
        context: Context,
        d: Map<String, Any>,
        currentDeviceId: String
    ): Boolean {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val dRevoked = (d["revokedByAdmin"] as? Boolean) == true
        if (dRevoked) return false

        val hasExplicitIsProField = d.containsKey("isPro") && d["isPro"] is Boolean
        val cloudPro = (d["isPro"] as? Boolean) == true
        val isExplicitlyNotPro = hasExplicitIsProField && !cloudPro

        val proTier = (d["proTier"] as? String).orEmpty().trim()
        val cloudAccountPro = ((d["isAccountPro"] as? Boolean) == true) || (proTier == "ACCOUNT_PRO")
        val cloudUpgradedToAcc = (d["upgradedToAccountPro"] as? Boolean) == true
        val savedLicenseKey = (d["licenseKey"] as? String).orEmpty().trim()
        val cleanSavedKey = savedLicenseKey.replace("-", "").trim().uppercase()
        val expectedDevKeyClean = generateLicenseKeyForDevice(currentDeviceId).replace("-", "").trim().uppercase()
        val expectedAccKeyClean = generateAccountProLicenseKeyForDevice(currentDeviceId).replace("-", "").trim().uppercase()
        val hasValidCryptographicKey = cleanSavedKey.length >= 16 &&
            (cleanSavedKey == expectedDevKeyClean || cleanSavedKey == expectedAccKeyClean)

        val ownerEmail = (d["ownerEmail"] as? String).orEmpty().trim()
        val cloudTrialUsed = (d["freeTrialUsed"] as? Number)?.toInt() ?: 0
        if (cloudTrialUsed > getUsedFreeTrials(context)) {
            prefs.edit().putInt("free_trial_count_used", cloudTrialUsed).apply()
        }
        if (ownerEmail.contains("@") && !ownerEmail.contains(" ")) {
            prefs.edit().putString("last_familiar_email", ownerEmail.lowercase()).apply()
        }

        // Nếu bản ghi trên Cloud có trường isPro = false tường minh thì tuyệt đối KHÔNG tự khôi phục Pro từ các trường lịch sử cũ
        if (isExplicitlyNotPro) {
            return false
        }

        val hasMagicTuneProductSign = (d["appId"] as? String)?.equals("magictune", ignoreCase = true) == true ||
            (d["product"] as? String)?.contains("MAGICTUNE", ignoreCase = true) == true ||
            (d["magictunePro"] as? Boolean) == true

        // BẢO VỆ CHỐNG DÙNG CHÙA TỪ WEBSITE / APP KHÁC DÙNG CHUNG FIREBASE:
        // Thiết bị BẮT BUỘC phải có Mã License Key SHA-256 đặc thù của MagicTune
        // HOẶC có dấu hiệu bản quyền sản phẩm MagicTune rõ ràng!
        val wasPreviouslyVerifiedPro = hasValidCryptographicKey || (cloudPro && hasMagicTuneProductSign)

        if (wasPreviouslyVerifiedPro) {
            RestoreFamiliarProHelper.applyRestoredProState(
                context = context,
                deviceId = currentDeviceId,
                isAccountTier = cloudAccountPro || cloudUpgradedToAcc,
                licenseKey = savedLicenseKey.ifBlank { if (cloudAccountPro) "CLOUD_ACCOUNT_PRO_RESTORED" else "CLOUD_DEVICE_PRO_RESTORED" },
                recognizedEmail = ownerEmail,
                recognizedRole = ""
            )
            return true
        }
        return false
    }

    /**
     * Quét 7 tầng Firestore trực tiếp qua Cầu nối REST (`FirestoreRestTokenBridge`)
     * đảm bảo 100% hoạt động ngay cả khi người dùng chưa đăng nhập Google (`Firebase.auth.currentUser == null`)
     * và bị Firestore Security Rules (`request.auth != null`) chặn trên SDK thông thường.
     */
    private fun checkDeviceRecognizedProViaRestBridge(
        context: Context,
        deviceId: String,
        normCurrentId: String,
        hwId: String,
        candidateIds: List<String>,
        candidateKeyMap: Map<String, Boolean>,
        candidateCleanKeySet: Set<String>,
        candidateEmails: List<String>
    ): Boolean {
        try {
            // 1. Truy vấn nhanh trực tiếp theo Document ID trên `devices/{id}` cho các ID chính
            val fastDocIds = listOf(deviceId, normCurrentId, "MT-$normCurrentId")
                .filter { it.isNotBlank() }
                .distinct()
            for (fId in fastDocIds) {
                val fastMap = FirestoreRestTokenBridge.fetchDocMapViaRest(context, "devices", fId)
                if (fastMap != null && fastMap.isNotEmpty()) {
                    if (applyCloudProMapToLocal(context, fastMap, deviceId)) {
                        lastCloudLookupDiag = "Khớp trực tiếp thiết bị $fId trên bảng devices"
                        return true
                    }
                }
            }

            // 2. Quét toàn diện bảng `devices` qua REST
            val allDevices = FirestoreRestTokenBridge.fetchCollectionMapsViaRest(context, "devices")
            for (d in allDevices) {
                val docId = (d["__id"] as? String).orEmpty()
                val docDevId = (d["deviceId"] as? String).orEmpty().ifBlank { docId }
                val docHwId = (d["hardwareId"] as? String).orEmpty().trim()
                val docKeyClean = (d["licenseKey"] as? String).orEmpty().replace("-", "").trim().uppercase()
                val docOwnerEmail = (d["ownerEmail"] as? String).orEmpty().trim().lowercase()
                val docIsAcc = ((d["isAccountPro"] as? Boolean) == true) || ((d["proTier"] as? String) == "ACCOUNT_PRO")

                val isIdMatch = isDeviceIdMatchingCurrentDevice(context, docId) ||
                    isDeviceIdMatchingCurrentDevice(context, docDevId) ||
                    (hwId.isNotBlank() && docHwId.isNotBlank() && docHwId == hwId)
                val isKeyMatch = docKeyClean.length >= 12 && candidateCleanKeySet.contains(docKeyClean)
                val isEmailAccMatch = docIsAcc && docOwnerEmail.isNotBlank() && candidateEmails.contains(docOwnerEmail)

                if (isIdMatch || isKeyMatch || isEmailAccMatch) {
                    if (applyCloudProMapToLocal(context, d, deviceId)) {
                        lastCloudLookupDiag = "Khớp thiết bị $docDevId trên bảng devices (${allDevices.size} bản ghi)"
                        return true
                    }
                }
            }

            // 3. Quét toàn diện bảng `users` qua REST
            val allUsers = FirestoreRestTokenBridge.fetchCollectionMapsViaRest(context, "users")
            for (uDoc in allUsers) {
                if ((uDoc["revokedByAdmin"] as? Boolean) == true) continue
                val uEmail = (uDoc["email"] as? String).orEmpty().trim()
                val uRole = (uDoc["role"] as? String).orEmpty().trim()
                val isAdminAccount = uEmail.equals("vuongdhkmhn@gmail.com", ignoreCase = true) || uRole.equals("admin", ignoreCase = true)
                val isExplicitMagicTunePro = (uDoc["magictunePro"] as? Boolean) == true ||
                    ((uDoc["magictuneTier"] as? String) == "ACCOUNT_PRO") ||
                    ((uDoc["product"] as? String)?.contains("MAGICTUNE", ignoreCase = true) == true) ||
                    ((uDoc["appId"] as? String)?.equals("magictune", ignoreCase = true) == true)
                if (!isAdminAccount && !isExplicitMagicTunePro) continue

                val uIsAccountPro = ((uDoc["isAccountPro"] as? Boolean) == true) || ((uDoc["proTier"] as? String) == "ACCOUNT_PRO") || ((uDoc["magictuneTier"] as? String) == "ACCOUNT_PRO")
                val uIsPro = ((uDoc["isPro"] as? Boolean) == true) || uIsAccountPro || ((uDoc["proTier"] as? String) == "DEVICE_PRO")

                val uDevId = (uDoc["deviceId"] as? String).orEmpty()
                val uActDevId = (uDoc["activeDeviceId"] as? String).orEmpty()
                val uHwId = (uDoc["hardwareId"] as? String).orEmpty().trim()

                val matchesDevice = isDeviceIdMatchingCurrentDevice(context, uDevId) ||
                    isDeviceIdMatchingCurrentDevice(context, uActDevId) ||
                    (hwId.isNotBlank() && uHwId.isNotBlank() && uHwId == hwId)
                val matchesEmail = uEmail.isNotBlank() && candidateEmails.contains(uEmail.lowercase())

                if (matchesDevice || (matchesEmail && (isAdminAccount || uIsAccountPro || matchesDevice))) {
                    RestoreFamiliarProHelper.applyRestoredProState(
                        context = context,
                        deviceId = deviceId,
                        isAccountTier = uIsAccountPro || isAdminAccount,
                        licenseKey = if (isAdminAccount) "ADMIN_MASTER_PRO_RESTORED"
                        else if (uIsAccountPro) generateAccountProLicenseKeyForDevice(deviceId)
                        else generateLicenseKeyForDevice(deviceId),
                        recognizedEmail = uEmail,
                        recognizedRole = if (isAdminAccount) "admin" else uRole
                    )
                    lastCloudLookupDiag = "Khớp hồ sơ Pro ($uEmail) trên bảng users (${allUsers.size} bản ghi)"
                    return true
                }
            }

            // 4. Quét bảng `ai_pro_chat_logs` qua REST (CHỈ nhận các bản ghi đã thực sự được duyệt cấp Pro: proGranted == true)
            val allAiLogs = FirestoreRestTokenBridge.fetchCollectionMapsViaRest(context, "ai_pro_chat_logs")
            for (logDoc in allAiLogs) {
                val proGrantedLog = (logDoc["proGranted"] as? Boolean) == true
                if (!proGrantedLog) continue

                val key = (logDoc["generatedKey"] as? String).orEmpty().trim()
                val cleanKey = key.replace("-", "").trim().uppercase()
                val logDevId = (logDoc["deviceId"] as? String).orEmpty()

                val matchesLog = isDeviceIdMatchingCurrentDevice(context, logDevId) ||
                    (cleanKey.length >= 16 && candidateCleanKeySet.contains(cleanKey))

                if (matchesLog) {
                    val tier = (logDoc["grantedTier"] as? String).orEmpty().trim()
                    val isAcc = tier == "ACCOUNT_PRO" || key.startsWith("TKPR-", ignoreCase = true)
                    val email = (logDoc["ownerEmail"] as? String).orEmpty().trim()
                    RestoreFamiliarProHelper.applyRestoredProState(
                        context = context,
                        deviceId = deviceId,
                        isAccountTier = isAcc,
                        licenseKey = key.ifBlank { if (isAcc) generateAccountProLicenseKeyForDevice(deviceId) else generateLicenseKeyForDevice(deviceId) },
                        recognizedEmail = email,
                        recognizedRole = ""
                    )
                    lastCloudLookupDiag = "Khớp lịch sử duyệt Pro AI ($logDevId)"
                    return true
                }
            }

            // 5. Quét bảng `pro_recovery_requests` qua REST
            val allRecovery = FirestoreRestTokenBridge.fetchCollectionMapsViaRest(context, "pro_recovery_requests")
            for (rDoc in allRecovery) {
                val rStatus = (rDoc["status"] as? String).orEmpty().uppercase()
                val key = (rDoc["restoredKey"] as? String).orEmpty().trim()
                if (rStatus != "RESTORED" && rStatus != "APPROVED" && key.isBlank()) continue
                val docId = (rDoc["__id"] as? String).orEmpty()
                val rDevId = (rDoc["deviceId"] as? String).orEmpty().ifBlank { docId.removePrefix("recovery_") }
                val cleanKey = key.replace("-", "").trim().uppercase()
                if (isDeviceIdMatchingCurrentDevice(context, rDevId) ||
                    (cleanKey.length >= 12 && candidateCleanKeySet.contains(cleanKey))
                ) {
                    val email = (rDoc["ownerEmail"] as? String).orEmpty().trim()
                    val isAcc = key.startsWith("TKPR-", ignoreCase = true)
                    RestoreFamiliarProHelper.applyRestoredProState(
                        context = context,
                        deviceId = deviceId,
                        isAccountTier = isAcc,
                        licenseKey = key.ifBlank { generateLicenseKeyForDevice(deviceId) },
                        recognizedEmail = email,
                        recognizedRole = ""
                    )
                    lastCloudLookupDiag = "Khớp yêu cầu khôi phục Pro ($rDevId)"
                    return true
                }
            }

            // 6. Quét bảng `payment_intents` qua REST
            val allIntents = FirestoreRestTokenBridge.fetchCollectionMapsViaRest(context, "payment_intents")
            for (iDoc in allIntents) {
                if ((iDoc["isPro"] as? Boolean) != true) continue
                val docId = (iDoc["__id"] as? String).orEmpty()
                val iDevId = (iDoc["deviceId"] as? String).orEmpty().ifBlank { docId.substringBefore("_") }
                if (isDeviceIdMatchingCurrentDevice(context, iDevId)) {
                    val isAcc = (iDoc["isAccountPro"] as? Boolean) == true
                    val email = (iDoc["ownerEmail"] as? String).orEmpty().trim()
                    RestoreFamiliarProHelper.applyRestoredProState(
                        context = context,
                        deviceId = deviceId,
                        isAccountTier = isAcc,
                        licenseKey = if (isAcc) generateAccountProLicenseKeyForDevice(deviceId) else generateLicenseKeyForDevice(deviceId),
                        recognizedEmail = email,
                        recognizedRole = ""
                    )
                    lastCloudLookupDiag = "Khớp đơn thanh toán Pro ($iDevId)"
                    return true
                }
            }

            // 7. Quét `app_config/global` qua REST
            val globalMap = FirestoreRestTokenBridge.fetchDocMapViaRest(context, "app_config", "global")
            if (globalMap != null && globalMap.isNotEmpty()) {
                val proDevIdsRaw = (globalMap["pro_device_ids"] as? String).orEmpty().uppercase()
                val proKeysRaw = (globalMap["pro_keys_list"] as? String).orEmpty().uppercase()
                val knowledgeBaseText = (globalMap["ai_knowledge_base_key_list"] as? String).orEmpty().uppercase()

                val proDevTokens = proDevIdsRaw.split(Regex("[,;\\s\\n]+")).map { it.trim() }.filter { it.length >= 6 }
                val matchesDevId = proDevTokens.any { token -> isDeviceIdMatchingCurrentDevice(context, token) } ||
                    candidateIds.any { cId ->
                        val upperCId = cId.uppercase()
                        upperCId.length >= 8 && (proDevIdsRaw.contains(upperCId) || knowledgeBaseText.contains("DEVICEID=$upperCId") || knowledgeBaseText.contains("NORMID=$upperCId"))
                    }

                var matchedAccKey: String? = null
                var matchedDevKey: String? = null
                for ((candKey, isAcc) in candidateKeyMap) {
                    if (proKeysRaw.contains(candKey) || knowledgeBaseText.contains(candKey)) {
                        if (isAcc) matchedAccKey = candKey else matchedDevKey = candKey
                    }
                }

                if (matchesDevId || matchedAccKey != null || matchedDevKey != null) {
                    val isAcc = matchedAccKey != null
                    val finalKey = matchedAccKey ?: matchedDevKey ?: if (isAcc) {
                        generateAccountProLicenseKeyForDevice(deviceId)
                    } else {
                        generateLicenseKeyForDevice(deviceId)
                    }
                    RestoreFamiliarProHelper.applyRestoredProState(
                        context = context,
                        deviceId = deviceId,
                        isAccountTier = isAcc,
                        licenseKey = finalKey,
                        recognizedEmail = "",
                        recognizedRole = ""
                    )
                    lastCloudLookupDiag = "Khớp kho tri thức toàn cục app_config/global"
                    return true
                }
            }

            lastCloudLookupDiag = "Đã đối chiếu trực tiếp ${allDevices.size} thiết bị & ${allUsers.size} tài khoản trên Cloud phn-mm-ha-n"
        } catch (e: Exception) {
            android.util.Log.e("LicenseManager", "REST Bridge lookup error: ${e.localizedMessage}")
        }
        return false
    }

    /**
     * Kiểm tra toàn diện xem thiết bị hiện tại có phải là thiết bị quen thuộc đã lên Pro trên Firebase hay không.
     * Quét đồng thời CẢ 2 NGUỒN dữ liệu trên Firebase:
     * 1. Bảng `devices` (Danh sách thiết bị đã đăng ký trên Firebase — kể cả khôi phục lại nếu từng có licenseKey / proActivatedAt mà chưa bị Admin thu hồi).
     * 2. Bảng `users` (Danh sách tài khoản Pro trong trang Quản Trị của Admin — kiểm tra xem tài khoản Pro nào đang chứa `deviceId` / `activeDeviceId` / `activeDeviceModel` của máy này).
     * Khi phát hiện khớp ở bất kỳ nguồn nào -> Tự động kích hoạt lại Pro ngay lập tức cho thiết bị mà không cần người dùng phải thao tác!
     */
    private suspend fun getDocFresh(
        docRef: com.google.firebase.firestore.DocumentReference
    ): com.google.firebase.firestore.DocumentSnapshot? {
        return try {
            docRef.get(com.google.firebase.firestore.Source.SERVER).await()
        } catch (_: Exception) {
            try {
                docRef.get(com.google.firebase.firestore.Source.DEFAULT).await()
            } catch (_: Exception) {
                null
            }
        }
    }

    private suspend fun getQueryFresh(
        query: com.google.firebase.firestore.Query
    ): com.google.firebase.firestore.QuerySnapshot? {
        return try {
            query.get(com.google.firebase.firestore.Source.SERVER).await()
        } catch (_: Exception) {
            try {
                query.get(com.google.firebase.firestore.Source.DEFAULT).await()
            } catch (_: Exception) {
                null
            }
        }
    }

    private suspend fun queryWhereInBatches(
        collection: com.google.firebase.firestore.CollectionReference,
        field: String,
        rawValues: Collection<String>
    ): List<com.google.firebase.firestore.DocumentSnapshot> {
        val cleanList = rawValues.map { it.trim() }.filter { it.isNotBlank() }.distinct()
        if (cleanList.isEmpty()) return emptyList()
        val results = mutableListOf<com.google.firebase.firestore.DocumentSnapshot>()
        val seenIds = mutableSetOf<String>()
        for (chunk in cleanList.chunked(10)) {
            if (chunk.isEmpty()) continue
            val snap = getQueryFresh(collection.whereIn(field, chunk))
            if (snap != null) {
                for (doc in snap.documents) {
                    if (seenIds.add(doc.id)) {
                        results.add(doc)
                    }
                }
            }
        }
        return results
    }

    /**
     * HỆ THỐNG TRUY VẤN ĐÁM MÂY ĐA NGUỒN & ĐA CHIỀU (8-LAYER MULTI-VECTOR TARGETED CLOUD LOOKUP):
     * Kiểm tra toàn diện thiết bị hiện tại trên Cloud Firebase (không cần chỉ mục phức tạp Composite Index)
     * bằng mọi biến thể định danh phần cứng (`ANDROID_ID` 16 ký tự, `MT-XXXXXXXX` 8 ký tự, `MediaDrm Widevine HW-ID`),
     * mọi biến thể mã khóa SHA-256 cố định (`candidateKeys`), và đối chiếu chuẩn hóa sâu trên 8 tầng dữ liệu:
     * - Tầng 0: Chữ ký phần cứng bảo mật nội bộ (`Settings.Secure`) trên mọi biến thể Key của máy.
     * - Tầng 1: Tài khoản đang đăng nhập (`uid` & `email`), Email quen thuộc lưu trên máy & Đặc quyền Admin.
     * - Tầng 2: Bảng `devices` (5 phương thức: `hardwareId`, Direct `Document ID`, `whereIn("deviceId")`, `whereIn("licenseKey")`, `ownerEmail` & Quét chuẩn hóa sâu).
     * - Tầng 3: Bảng `users` (4 phương thức: `hardwareId`, `whereIn("deviceId")`, `whereIn("activeDeviceId")`, `email` & Quét chuẩn hóa sâu).
     * - Tầng 4: Bảng `ai_pro_chat_logs` (3 phương thức: `whereIn("deviceId")`, `whereIn("generatedKey")` & Quét nội dung biên lai AI đã duyệt).
     * - Tầng 5: Bảng `pro_recovery_requests` (3 phương thức: Direct `Document ID`, `whereIn("deviceId")` / `whereIn("restoredKey")` & Quét chuẩn hóa).
     * - Tầng 6: Bảng `payment_intents` (3 phương thức: Direct `Document ID`, `whereIn("deviceId")` & Quét chuẩn hóa các đơn `isPro == true`).
     * - Tầng 7 & 8: Kho Tri Thức Toàn Cục (`app_config/global`) & Danh sách thiết bị Pro từ xa (`PAID_DEVICES_URL`).
     */
    suspend fun checkDeviceRecognizedProInCloud(context: Context): Boolean = withContext(Dispatchers.IO) {
        val deviceId = getDeviceId(context).trim().uppercase()
        val normCurrentId = normalizeDeviceIdForMatch(deviceId)
        val hwId = getHardwareId().trim()
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val user = try { Firebase.auth.currentUser } catch (_: Exception) { null }

        // Tập hợp đầy đủ mọi biến thể ID và Mã Key SHA-256 của thiết bị hiện tại
        val candidateIds = getAllCandidateDeviceIds(context)
        val candidateKeyMap = getAllCandidateLicenseKeys(context)
        val candidateKeys = candidateKeyMap.keys.toList()
        val candidateCleanKeySet = candidateKeys.map { it.replace("-", "").trim().uppercase() }.toSet()

        val savedEmail = prefs.getString("current_user_email", "")?.trim()?.lowercase().orEmpty()
        val familiarEmail = prefs.getString("last_familiar_email", "")?.trim()?.lowercase().orEmpty()
        val authEmail = user?.email?.trim()?.lowercase().orEmpty()
        val candidateEmails = listOf(authEmail, savedEmail, familiarEmail)
            .filter { it.isNotBlank() && it.contains("@") && !it.contains(" ") }
            .distinct()

        // NẾU MÁY CHƯA ĐĂNG NHẬP (`user == null`), Firestore SDK mặc định sẽ bị `phn-mm-ha-n` chặn bởi quy tắc `request.auth != null` (HTTP 403).
        // Do đó, ưu tiên chạy thẳng qua Cầu nối Xác thực REST (`FirestoreRestTokenBridge`) để đọc 100% dữ liệu trên `phn-mm-ha-n`!
        if (user == null) {
            val matchedViaRest = checkDeviceRecognizedProViaRestBridge(
                context = context,
                deviceId = deviceId,
                normCurrentId = normCurrentId,
                hwId = hwId,
                candidateIds = candidateIds,
                candidateKeyMap = candidateKeyMap,
                candidateCleanKeySet = candidateCleanKeySet,
                candidateEmails = candidateEmails
            )
            if (matchedViaRest) return@withContext true
        }

        try {
            val db = FirebaseFirestore.getInstance()

            // =========================================================================
            // TẦNG 1: TÀI KHOẢN ĐANG ĐĂNG NHẬP / EMAIL QUEN THUỘC / ADMIN CHÍNH CHỦ
            // =========================================================================
            if (user != null) {
                val isAdminUser = authEmail.contains("vuongdhkmhn@gmail.com") || authEmail.contains("vuongdhkmhn@gmal.com")
                val uDoc = getDocFresh(db.collection("users").document(user.uid))
                val isExplicitMagicTunePro = (uDoc?.getBoolean("magictunePro") == true) ||
                    (uDoc?.getString("magictuneTier") == "ACCOUNT_PRO") ||
                    (uDoc?.getString("product")?.contains("MAGICTUNE", ignoreCase = true) == true) ||
                    (uDoc?.getString("appId")?.equals("magictune", ignoreCase = true) == true)
                val uIsPro = isAdminUser || isExplicitMagicTunePro
                val uRevoked = uDoc?.getBoolean("revokedByAdmin") == true
                if (uIsPro && !uRevoked) {
                    val isAccTier = isAdminUser ||
                        (uDoc?.getBoolean("isAccountPro") == true) ||
                        (uDoc?.getString("proTier") == "ACCOUNT_PRO") ||
                        (uDoc?.getString("magictuneTier") == "ACCOUNT_PRO")
                    RestoreFamiliarProHelper.applyRestoredProState(
                        context = context,
                        deviceId = deviceId,
                        isAccountTier = isAccTier,
                        licenseKey = if (isAdminUser) "ADMIN_MASTER_PRO_RESTORED"
                        else if (isAccTier) generateAccountProLicenseKeyForDevice(deviceId)
                        else generateLicenseKeyForDevice(deviceId),
                        recognizedEmail = authEmail,
                        recognizedRole = if (isAdminUser) "admin" else (uDoc?.getString("role") ?: "")
                    )
                    return@withContext true
                }
            }

            // Kiểm tra theo danh sách Email quen thuộc trên bảng `users` (Chỉ kiểm tra khi người dùng ĐÃ ĐĂNG NHẬP, không mở cho khách vãng lai)
            if (candidateEmails.isNotEmpty() && user != null) {
                val emailUserDocs = queryWhereInBatches(db.collection("users"), "email", candidateEmails)
                for (uDoc in emailUserDocs) {
                    if (uDoc.getBoolean("revokedByAdmin") == true) continue
                    val uEmail = (uDoc.getString("email") ?: "").trim()
                    val uRole = (uDoc.getString("role") ?: "user").trim()
                    val isAdminAccount = uEmail.equals("vuongdhkmhn@gmail.com", ignoreCase = true) || uRole.equals("admin", ignoreCase = true)
                    val isExplicitMagicTunePro = (uDoc.getBoolean("magictunePro") == true) ||
                        (uDoc.getString("magictuneTier") == "ACCOUNT_PRO") ||
                        (uDoc.getString("product")?.contains("MAGICTUNE", ignoreCase = true) == true) ||
                        (uDoc.getString("appId")?.equals("magictune", ignoreCase = true) == true)
                    if (!isAdminAccount && !isExplicitMagicTunePro) continue

                    val uIsAccountPro = (uDoc.getBoolean("isAccountPro") == true) || (uDoc.getString("proTier") == "ACCOUNT_PRO") || (uDoc.getString("magictuneTier") == "ACCOUNT_PRO")
                    val uIsPro = (uDoc.getBoolean("isPro") == true) || uIsAccountPro || (uDoc.getString("proTier") == "DEVICE_PRO")
                    val uDevId = uDoc.getString("deviceId") ?: ""
                    val uActDevId = uDoc.getString("activeDeviceId") ?: ""
                    val deviceMatchesUser = isDeviceIdMatchingCurrentDevice(context, uDevId) ||
                        isDeviceIdMatchingCurrentDevice(context, uActDevId) ||
                        (hwId.isNotBlank() && uDoc.getString("hardwareId") == hwId)

                    // Mở khóa nếu là tài khoản của chính chủ đang đăng nhập, hoặc gói Account Pro, hoặc trùng khớp ID thiết bị
                    if (isAdminAccount || (uIsPro && (uIsAccountPro || deviceMatchesUser))) {
                        RestoreFamiliarProHelper.applyRestoredProState(
                            context = context,
                            deviceId = deviceId,
                            isAccountTier = uIsAccountPro || isAdminAccount,
                            licenseKey = if (isAdminAccount) "ADMIN_MASTER_PRO_RESTORED"
                            else if (uIsAccountPro) generateAccountProLicenseKeyForDevice(deviceId)
                            else generateLicenseKeyForDevice(deviceId),
                            recognizedEmail = uEmail,
                            recognizedRole = if (isAdminAccount) "admin" else ""
                        )
                        return@withContext true
                    }
                }
            }

            // =========================================================================
            // TẦNG 2: BẢNG `devices` — TRUY VẤN 5 PHƯƠNG THỨC (MULTI-VECTOR DEVICES LOOKUP)
            // =========================================================================
            val checkedDeviceDocIds = mutableSetOf<String>()

            // 2A. Phương thức 1: Truy vấn theo Hardware ID (`MediaDrm Widevine ID`)
            if (hwId.isNotBlank()) {
                val hwVariants = listOf(hwId, hwId.take(16).uppercase(), "HW-${hwId.take(16).uppercase()}").distinct()
                val hwDocs = queryWhereInBatches(db.collection("devices"), "hardwareId", hwVariants)
                for (d in hwDocs) {
                    checkedDeviceDocIds.add(d.id)
                    if (applyCloudProRecordToLocal(context, d, deviceId)) return@withContext true
                }
            }

            // 2B. Phương thức 2: Truy vấn trực tiếp theo Document ID trên toàn bộ biến thể ID (`candidateIds`)
            for (candId in candidateIds) {
                if (!checkedDeviceDocIds.add(candId)) continue
                val d = getDocFresh(db.collection("devices").document(candId))
                if (d != null && d.exists()) {
                    if (applyCloudProRecordToLocal(context, d, deviceId)) return@withContext true
                }
            }

            // 2C. Phương thức 3: Truy vấn hàng loạt `whereIn("deviceId", ...)` cho tất cả biến thể ID
            val devFieldDocs = queryWhereInBatches(db.collection("devices"), "deviceId", candidateIds)
            for (d in devFieldDocs) {
                if (checkedDeviceDocIds.add(d.id)) {
                    if (applyCloudProRecordToLocal(context, d, deviceId)) return@withContext true
                }
            }

            // 2D. Phương thức 4: Truy vấn hàng loạt `whereIn("licenseKey", ...)` theo mã khóa SHA-256 cố định của máy
            val keyFieldDocs = queryWhereInBatches(db.collection("devices"), "licenseKey", candidateKeys)
            for (d in keyFieldDocs) {
                if (checkedDeviceDocIds.add(d.id)) {
                    if (applyCloudProRecordToLocal(context, d, deviceId)) return@withContext true
                }
            }

            // 2E. Phương thức 5: Truy vấn theo `ownerEmail` quen thuộc & Quét đối chiếu chuẩn hóa sâu trên `devices`
            if (candidateEmails.isNotEmpty()) {
                val ownerDocs = queryWhereInBatches(db.collection("devices"), "ownerEmail", candidateEmails)
                for (d in ownerDocs) {
                    val dDevId = d.getString("deviceId") ?: d.id
                    val dHwId = d.getString("hardwareId") ?: ""
                    val dIsAcc = (d.getBoolean("isAccountPro") == true) || (d.getString("proTier") == "ACCOUNT_PRO")
                    if (dIsAcc || isDeviceIdMatchingCurrentDevice(context, dDevId) || (hwId.isNotBlank() && dHwId == hwId)) {
                        if (applyCloudProRecordToLocal(context, d, deviceId)) return@withContext true
                    }
                }
            }

            val allDevicesSnap = getQueryFresh(db.collection("devices"))
            if (allDevicesSnap != null) {
                for (d in allDevicesSnap.documents) {
                    if (checkedDeviceDocIds.contains(d.id)) continue
                    val docDevId = d.getString("deviceId") ?: d.id
                    val docHwId = (d.getString("hardwareId") ?: "").trim()
                    val docKeyClean = (d.getString("licenseKey") ?: "").replace("-", "").trim().uppercase()

                    val isIdMatch = isDeviceIdMatchingCurrentDevice(context, d.id) ||
                        isDeviceIdMatchingCurrentDevice(context, docDevId) ||
                        (hwId.isNotBlank() && docHwId.isNotBlank() && docHwId == hwId)
                    val isKeyMatch = docKeyClean.length >= 12 && candidateCleanKeySet.contains(docKeyClean)

                    if (isIdMatch || isKeyMatch) {
                        if (applyCloudProRecordToLocal(context, d, deviceId)) return@withContext true
                    }
                }
            }

            // =========================================================================
            // TẦNG 3: BẢNG `users` — TRUY VẤN 4 PHƯƠNG THỨC (MULTI-VECTOR USERS LOOKUP)
            // =========================================================================
            val checkedUserDocIds = mutableSetOf<String>()
            val matchedUserDocs = mutableListOf<com.google.firebase.firestore.DocumentSnapshot>()

            // 3A. Theo `hardwareId`
            if (hwId.isNotBlank()) {
                matchedUserDocs.addAll(queryWhereInBatches(db.collection("users"), "hardwareId", listOf(hwId, hwId.take(16).uppercase())))
            }
            // 3B. Theo `deviceId` (mọi biến thể ID)
            matchedUserDocs.addAll(queryWhereInBatches(db.collection("users"), "deviceId", candidateIds))
            // 3C. Theo `activeDeviceId` (mọi biến thể ID)
            matchedUserDocs.addAll(queryWhereInBatches(db.collection("users"), "activeDeviceId", candidateIds))

            for (uDoc in matchedUserDocs) {
                if (!checkedUserDocIds.add(uDoc.id)) continue
                if (uDoc.getBoolean("revokedByAdmin") == true) continue

                val uRole = (uDoc.getString("role") ?: "user").trim()
                val uEmail = (uDoc.getString("email") ?: "").trim()
                val isAdminAccount = uEmail.equals("vuongdhkmhn@gmail.com", ignoreCase = true) || uRole.equals("admin", ignoreCase = true)
                val uIsAccountPro = (uDoc.getBoolean("isAccountPro") == true) || (uDoc.getString("proTier") == "ACCOUNT_PRO")
                val uIsPro = (uDoc.getBoolean("isPro") == true) || uIsAccountPro || (uDoc.getString("proTier") == "DEVICE_PRO")

                if (isAdminAccount || uIsPro) {
                    RestoreFamiliarProHelper.applyRestoredProState(
                        context = context,
                        deviceId = deviceId,
                        isAccountTier = uIsAccountPro,
                        licenseKey = if (isAdminAccount) "ADMIN_MASTER_PRO_RESTORED"
                        else if (uIsAccountPro) generateAccountProLicenseKeyForDevice(deviceId)
                        else generateLicenseKeyForDevice(deviceId),
                        recognizedEmail = uEmail,
                        recognizedRole = if (isAdminAccount) "admin" else ""
                    )
                    return@withContext true
                }
            }

            // 3D. Quét đối chiếu chuẩn hóa sâu trên `users`
            val allUsersSnap = getQueryFresh(db.collection("users"))
            if (allUsersSnap != null) {
                for (uDoc in allUsersSnap.documents) {
                    if (checkedUserDocIds.contains(uDoc.id)) continue
                    if (uDoc.getBoolean("revokedByAdmin") == true) continue

                    val uDevId = uDoc.getString("deviceId") ?: ""
                    val uActDevId = uDoc.getString("activeDeviceId") ?: ""
                    val uHwId = uDoc.getString("hardwareId") ?: ""
                    if (isDeviceIdMatchingCurrentDevice(context, uDevId) ||
                        isDeviceIdMatchingCurrentDevice(context, uActDevId) ||
                        (hwId.isNotBlank() && uHwId == hwId)
                    ) {
                        val uRole = (uDoc.getString("role") ?: "user").trim()
                        val uEmail = (uDoc.getString("email") ?: "").trim()
                        val isAdminAccount = uEmail.equals("vuongdhkmhn@gmail.com", ignoreCase = true) || uRole.equals("admin", ignoreCase = true)
                        val uIsAccountPro = (uDoc.getBoolean("isAccountPro") == true) || (uDoc.getString("proTier") == "ACCOUNT_PRO")
                        val uIsPro = (uDoc.getBoolean("isPro") == true) || uIsAccountPro || (uDoc.getString("proTier") == "DEVICE_PRO")
                        if (isAdminAccount || uIsPro) {
                            RestoreFamiliarProHelper.applyRestoredProState(
                                context = context,
                                deviceId = deviceId,
                                isAccountTier = uIsAccountPro,
                                licenseKey = if (isAdminAccount) "ADMIN_MASTER_PRO_RESTORED"
                                else if (uIsAccountPro) generateAccountProLicenseKeyForDevice(deviceId)
                                else generateLicenseKeyForDevice(deviceId),
                                recognizedEmail = uEmail,
                                recognizedRole = if (isAdminAccount) "admin" else ""
                            )
                            return@withContext true
                        }
                    }
                }
            }

            // =========================================================================
            // TẦNG 4: BẢNG `ai_pro_chat_logs` — TRUY VẤN 3 PHƯƠNG THỨC (AI AUDIT LOGS LOOKUP)
            // =========================================================================
            val checkedLogIds = mutableSetOf<String>()
            val matchedLogs = mutableListOf<com.google.firebase.firestore.DocumentSnapshot>()
            // 4A. Theo `deviceId` (mọi biến thể ID)
            matchedLogs.addAll(queryWhereInBatches(db.collection("ai_pro_chat_logs"), "deviceId", candidateIds))
            // 4B. Theo `generatedKey` (mọi biến thể Key SHA-256)
            matchedLogs.addAll(queryWhereInBatches(db.collection("ai_pro_chat_logs"), "generatedKey", candidateKeys))

            for (logDoc in matchedLogs) {
                if (!checkedLogIds.add(logDoc.id)) continue
                val key = (logDoc.getString("generatedKey") ?: "").trim()
                val proGrantedLog = logDoc.getBoolean("proGranted") == true
                if (proGrantedLog) {
                    val tier = (logDoc.getString("grantedTier") ?: "").trim()
                    val isAcc = tier == "ACCOUNT_PRO" || key.startsWith("TKPR-", ignoreCase = true)
                    val email = (logDoc.getString("ownerEmail") ?: "").trim()
                    RestoreFamiliarProHelper.applyRestoredProState(
                        context = context,
                        deviceId = deviceId,
                        isAccountTier = isAcc,
                        licenseKey = key.ifBlank { if (isAcc) generateAccountProLicenseKeyForDevice(deviceId) else generateLicenseKeyForDevice(deviceId) },
                        recognizedEmail = email,
                        recognizedRole = ""
                    )
                    return@withContext true
                }
            }

            // 4C. Quét chuẩn hóa sâu trên `ai_pro_chat_logs` (chỉ nhận các bản ghi proGranted == true)
            val allAiLogsSnap = getQueryFresh(db.collection("ai_pro_chat_logs"))
            if (allAiLogsSnap != null) {
                for (logDoc in allAiLogsSnap.documents) {
                    if (checkedLogIds.contains(logDoc.id)) continue
                    val proGrantedLog = logDoc.getBoolean("proGranted") == true
                    if (!proGrantedLog) continue

                    val key = (logDoc.getString("generatedKey") ?: "").trim()
                    val cleanKey = key.replace("-", "").trim().uppercase()
                    val logDevId = logDoc.getString("deviceId") ?: ""

                    val matchesLog = isDeviceIdMatchingCurrentDevice(context, logDevId) ||
                        (cleanKey.length >= 16 && candidateCleanKeySet.contains(cleanKey))

                    if (matchesLog) {
                        val tier = (logDoc.getString("grantedTier") ?: "").trim()
                        val isAcc = tier == "ACCOUNT_PRO" || key.startsWith("TKPR-", ignoreCase = true)
                        val email = (logDoc.getString("ownerEmail") ?: "").trim()
                        RestoreFamiliarProHelper.applyRestoredProState(
                            context = context,
                            deviceId = deviceId,
                            isAccountTier = isAcc,
                            licenseKey = key.ifBlank { if (isAcc) generateAccountProLicenseKeyForDevice(deviceId) else generateLicenseKeyForDevice(deviceId) },
                            recognizedEmail = email,
                            recognizedRole = ""
                        )
                        return@withContext true
                    }
                }
            }

            // =========================================================================
            // TẦNG 5: BẢNG `pro_recovery_requests` — TRUY VẤN 3 PHƯƠNG THỨC
            // =========================================================================
            val checkedRecoveryIds = mutableSetOf<String>()
            val recoveryCandidateDocs = mutableListOf<com.google.firebase.firestore.DocumentSnapshot>()

            // 5A. Direct Document ID (`recovery_<ID>` và `<ID>`)
            val recoveryDocIdCandidates = candidateIds.flatMap { listOf("recovery_$it", it) }.distinct()
            for (rId in recoveryDocIdCandidates) {
                val rDoc = getDocFresh(db.collection("pro_recovery_requests").document(rId))
                if (rDoc != null && rDoc.exists() && checkedRecoveryIds.add(rDoc.id)) {
                    recoveryCandidateDocs.add(rDoc)
                }
            }
            // 5B. `whereIn` trên `deviceId` và `restoredKey`
            for (rDoc in queryWhereInBatches(db.collection("pro_recovery_requests"), "deviceId", candidateIds)) {
                if (checkedRecoveryIds.add(rDoc.id)) recoveryCandidateDocs.add(rDoc)
            }
            for (rDoc in queryWhereInBatches(db.collection("pro_recovery_requests"), "restoredKey", candidateKeys)) {
                if (checkedRecoveryIds.add(rDoc.id)) recoveryCandidateDocs.add(rDoc)
            }

            for (rDoc in recoveryCandidateDocs) {
                val rStatus = (rDoc.getString("status") ?: "").uppercase()
                val key = (rDoc.getString("restoredKey") ?: "").trim()
                if (rStatus == "RESTORED" || rStatus == "APPROVED" || key.isNotBlank()) {
                    val email = (rDoc.getString("ownerEmail") ?: "").trim()
                    val isAcc = key.startsWith("TKPR-", ignoreCase = true)
                    RestoreFamiliarProHelper.applyRestoredProState(
                        context = context,
                        deviceId = deviceId,
                        isAccountTier = isAcc,
                        licenseKey = key.ifBlank { generateLicenseKeyForDevice(deviceId) },
                        recognizedEmail = email,
                        recognizedRole = ""
                    )
                    return@withContext true
                }
            }

            // 5C. Quét chuẩn hóa sâu trên `pro_recovery_requests`
            val allRecoverySnap = getQueryFresh(db.collection("pro_recovery_requests"))
            if (allRecoverySnap != null) {
                for (rDoc in allRecoverySnap.documents) {
                    if (checkedRecoveryIds.contains(rDoc.id)) continue
                    val rStatus = (rDoc.getString("status") ?: "").uppercase()
                    val key = (rDoc.getString("restoredKey") ?: "").trim()
                    if (rStatus != "RESTORED" && rStatus != "APPROVED" && key.isBlank()) continue

                    val rDevId = rDoc.getString("deviceId") ?: rDoc.id.removePrefix("recovery_")
                    val cleanKey = key.replace("-", "").trim().uppercase()
                    if (isDeviceIdMatchingCurrentDevice(context, rDevId) ||
                        (cleanKey.length >= 12 && candidateCleanKeySet.contains(cleanKey))
                    ) {
                        val email = (rDoc.getString("ownerEmail") ?: "").trim()
                        val isAcc = key.startsWith("TKPR-", ignoreCase = true)
                        RestoreFamiliarProHelper.applyRestoredProState(
                            context = context,
                            deviceId = deviceId,
                            isAccountTier = isAcc,
                            licenseKey = key.ifBlank { generateLicenseKeyForDevice(deviceId) },
                            recognizedEmail = email,
                            recognizedRole = ""
                        )
                        return@withContext true
                    }
                }
            }

            // =========================================================================
            // TẦNG 6: BẢNG `payment_intents` — TRUY VẤN 3 PHƯƠNG THỨC
            // =========================================================================
            val checkedIntentIds = mutableSetOf<String>()
            val intentDocs = mutableListOf<com.google.firebase.firestore.DocumentSnapshot>()

            // 6A. Direct Document ID
            for (candId in candidateIds) {
                val iDoc = getDocFresh(db.collection("payment_intents").document(candId))
                if (iDoc != null && iDoc.exists() && checkedIntentIds.add(iDoc.id)) {
                    intentDocs.add(iDoc)
                }
            }
            // 6B. `whereIn` trên `deviceId`
            for (iDoc in queryWhereInBatches(db.collection("payment_intents"), "deviceId", candidateIds)) {
                if (checkedIntentIds.add(iDoc.id)) intentDocs.add(iDoc)
            }

            for (iDoc in intentDocs) {
                if (iDoc.getBoolean("isPro") == true) {
                    val isAcc = iDoc.getBoolean("isAccountPro") == true
                    val email = (iDoc.getString("ownerEmail") ?: "").trim()
                    RestoreFamiliarProHelper.applyRestoredProState(
                        context = context,
                        deviceId = deviceId,
                        isAccountTier = isAcc,
                        licenseKey = if (isAcc) generateAccountProLicenseKeyForDevice(deviceId) else generateLicenseKeyForDevice(deviceId),
                        recognizedEmail = email,
                        recognizedRole = ""
                    )
                    return@withContext true
                }
            }

            // 6C. Quét chuẩn hóa sâu trên `payment_intents` (hỗ trợ cả Doc ID có hậu tố timestamp `MT-XXXX_1710...`)
            val allIntentsSnap = getQueryFresh(db.collection("payment_intents"))
            if (allIntentsSnap != null) {
                for (iDoc in allIntentsSnap.documents) {
                    if (checkedIntentIds.contains(iDoc.id)) continue
                    if (iDoc.getBoolean("isPro") != true) continue
                    val iDevId = iDoc.getString("deviceId")?.takeIf { it.isNotBlank() } ?: iDoc.id.substringBefore("_")
                    if (isDeviceIdMatchingCurrentDevice(context, iDevId)) {
                        val isAcc = iDoc.getBoolean("isAccountPro") == true
                        val email = (iDoc.getString("ownerEmail") ?: "").trim()
                        RestoreFamiliarProHelper.applyRestoredProState(
                            context = context,
                            deviceId = deviceId,
                            isAccountTier = isAcc,
                            licenseKey = if (isAcc) generateAccountProLicenseKeyForDevice(deviceId) else generateLicenseKeyForDevice(deviceId),
                            recognizedEmail = email,
                            recognizedRole = ""
                        )
                        return@withContext true
                    }
                }
            }

            // =========================================================================
            // TẦNG 7: BẢNG `app_config/global` (DANH SÁCH PRO & KHO TRI THỨC TOÀN CỤC)
            // =========================================================================
            val globalConfigSnap = getDocFresh(db.collection("app_config").document("global"))
            if (globalConfigSnap != null && globalConfigSnap.exists()) {
                val proDevIdsRaw = (globalConfigSnap.getString("pro_device_ids") ?: "").uppercase()
                val proKeysRaw = (globalConfigSnap.getString("pro_keys_list") ?: "").uppercase()
                val knowledgeBaseText = (globalConfigSnap.getString("ai_knowledge_base_key_list") ?: "").uppercase()

                val proDevTokens = proDevIdsRaw.split(Regex("[,;\\s\\n]+")).map { it.trim() }.filter { it.length >= 6 }
                val matchesDevId = proDevTokens.any { token -> isDeviceIdMatchingCurrentDevice(context, token) } ||
                    candidateIds.any { cId ->
                        val upperCId = cId.uppercase()
                        upperCId.length >= 8 && (proDevIdsRaw.contains(upperCId) || knowledgeBaseText.contains("DEVICEID=$upperCId") || knowledgeBaseText.contains("NORMID=$upperCId"))
                    }

                var matchedAccKey: String? = null
                var matchedDevKey: String? = null
                for ((candKey, isAcc) in candidateKeyMap) {
                    if (proKeysRaw.contains(candKey) || knowledgeBaseText.contains(candKey)) {
                        if (isAcc) matchedAccKey = candKey else matchedDevKey = candKey
                    }
                }

                if (matchesDevId || matchedAccKey != null || matchedDevKey != null) {
                    val isAcc = matchedAccKey != null
                    val finalKey = matchedAccKey ?: matchedDevKey ?: if (isAcc) {
                        generateAccountProLicenseKeyForDevice(deviceId)
                    } else {
                        generateLicenseKeyForDevice(deviceId)
                    }
                    RestoreFamiliarProHelper.applyRestoredProState(
                        context = context,
                        deviceId = deviceId,
                        isAccountTier = isAcc,
                        licenseKey = finalKey,
                        recognizedEmail = "",
                        recognizedRole = ""
                    )
                    return@withContext true
                }
            }

            // Nếu tài khoản đang đăng nhập mà các truy vấn SDK ở trên chưa tìm thấy (hoặc gặp lỗi quyền),
            // quét dự phòng một lần nữa qua Cầu nối REST để đảm bảo độ chính xác tuyệt đối 100%!
            if (user != null) {
                val matchedFallback = checkDeviceRecognizedProViaRestBridge(
                    context = context,
                    deviceId = deviceId,
                    normCurrentId = normCurrentId,
                    hwId = hwId,
                    candidateIds = candidateIds,
                    candidateKeyMap = candidateKeyMap,
                    candidateCleanKeySet = candidateCleanKeySet,
                    candidateEmails = candidateEmails
                )
                if (matchedFallback) return@withContext true
            }

            // =========================================================================
            // TẦNG 8: ĐỐI CHIẾU DANH SÁCH THIẾT BỊ TRẢ PHÍ TỪ XA (`PAID_DEVICES_URL`)
            // =========================================================================
            if (!prefs.getBoolean(KEY_REVOKED_BY_ADMIN, false)) {
                var connection: HttpURLConnection? = null
                try {
                    val url = URL(PAID_DEVICES_URL)
                    connection = (url.openConnection() as HttpURLConnection).apply {
                        requestMethod = "GET"
                        connectTimeout = 4500
                        readTimeout = 4500
                        useCaches = false
                    }
                    if (connection.responseCode == 200) {
                        val content = BufferedReader(InputStreamReader(connection.inputStream)).use { it.readText().uppercase() }
                        val remoteLines = content.split(Regex("[\\s,;\\n]+")).map { it.trim() }.filter { it.length >= 6 }
                        val matchedRemote = remoteLines.any { token -> isDeviceIdMatchingCurrentDevice(context, token) } ||
                            candidateIds.any { cId -> cId.length >= 8 && content.contains(cId.uppercase()) }
                        if (matchedRemote) {
                            RestoreFamiliarProHelper.applyRestoredProState(
                                context = context,
                                deviceId = deviceId,
                                isAccountTier = false,
                                licenseKey = generateLicenseKeyForDevice(deviceId),
                                recognizedEmail = "",
                                recognizedRole = ""
                            )
                            return@withContext true
                        }
                    }
                } catch (_: Exception) {
                } finally {
                    connection?.disconnect()
                }
            }

        } catch (e: Exception) {
            android.util.Log.e("LicenseManager", "Error checking Pro in cloud: ${e.localizedMessage}")
        }

        // Cuối cùng, trả về trạng thái Pro hiện tại của máy (bao gồm Tầng 0 - chữ ký phần cứng Settings.Secure)
        isProActivated(context)
    }

    /**
     * HÀM ĐỒNG BỘ TOÀN BỘ KNOWLEDGE BASE & KEY LIST AI LÊN CLOUD FIREBASE
     * Quét tất cả người dùng, thiết bị, log AI, yêu cầu khôi phục để tạo bộ tri thức chuẩn hóa 100%
     */
    fun syncAllKnowledgeBaseAndKeyListToCloud(
        context: Context,
        additionalGroqKeys: String = "",
        onComplete: (Boolean, Int, Int, String) -> Unit
    ) {
        val appCtx = context.applicationContext
        kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
            try {
                kotlinx.coroutines.withTimeout(30_000L) {
                    val db = FirebaseFirestore.getInstance()

                    // Quét đồng thời từ Firestore SDK và có fallback REST API nếu SDK rỗng hoặc lỗi mạng
                    val devicesSnap = try { db.collection("devices").get().await() } catch (_: Exception) { null }
                    val usersSnap = try { db.collection("users").get().await() } catch (_: Exception) { null }
                    val recoverySnap = try { db.collection("pro_recovery_requests").get().await() } catch (_: Exception) { null }
                    val aiLogsSnap = try { db.collection("ai_pro_chat_logs").get().await() } catch (_: Exception) { null }

                    val proDeviceIds = mutableSetOf<String>()
                    val proKeys = mutableSetOf<String>()
                    val proUserEmails = mutableSetOf<String>()
                    val knowledgeLines = mutableListOf<String>()

                    // 1. Quét bảng users (SDK hoặc REST)
                    if (usersSnap != null && !usersSnap.isEmpty) {
                        for (doc in usersSnap.documents) {
                            val isPro = doc.getBoolean("isPro") == true || doc.getBoolean("isAccountPro") == true || doc.getString("proTier") == "ACCOUNT_PRO"
                            val revoked = doc.getBoolean("revokedByAdmin") == true
                            if (isPro && !revoked) {
                                val email = (doc.getString("email") ?: "").trim()
                                val devId = (doc.getString("deviceId") ?: "").trim().uppercase()
                                val actDevId = (doc.getString("activeDeviceId") ?: "").trim().uppercase()
                                if (email.isNotBlank()) proUserEmails.add(email.lowercase())
                                if (devId.isNotBlank()) {
                                    proDeviceIds.add(devId)
                                    proDeviceIds.add(normalizeDeviceIdForMatch(devId))
                                }
                                if (actDevId.isNotBlank()) {
                                    proDeviceIds.add(actDevId)
                                    proDeviceIds.add(normalizeDeviceIdForMatch(actDevId))
                                }
                                knowledgeLines.add("USER_PRO: email=$email, deviceId=$devId, activeDeviceId=$actDevId")
                            }
                        }
                    } else {
                        // Fallback REST users
                        val restUsers = FirestoreRestTokenBridge.fetchCollectionMapsViaRest(appCtx, "users", 200)
                        for (map in restUsers) {
                            val isPro = (map["isPro"] == true) || (map["isAccountPro"] == true) || (map["proTier"] == "ACCOUNT_PRO")
                            val revoked = map["revokedByAdmin"] == true
                            if (isPro && !revoked) {
                                val email = (map["email"] as? String ?: "").trim()
                                val devId = (map["deviceId"] as? String ?: "").trim().uppercase()
                                val actDevId = (map["activeDeviceId"] as? String ?: "").trim().uppercase()
                                if (email.isNotBlank()) proUserEmails.add(email.lowercase())
                                if (devId.isNotBlank()) {
                                    proDeviceIds.add(devId)
                                    proDeviceIds.add(normalizeDeviceIdForMatch(devId))
                                }
                                if (actDevId.isNotBlank()) {
                                    proDeviceIds.add(actDevId)
                                    proDeviceIds.add(normalizeDeviceIdForMatch(actDevId))
                                }
                                knowledgeLines.add("USER_PRO: email=$email, deviceId=$devId, activeDeviceId=$actDevId")
                            }
                        }
                    }

                    // 2. Quét bảng devices (SDK hoặc REST)
                    if (devicesSnap != null && !devicesSnap.isEmpty) {
                        for (doc in devicesSnap.documents) {
                            val devId = (doc.getString("deviceId") ?: doc.id).trim().uppercase()
                            val normId = normalizeDeviceIdForMatch(devId)
                            val isPro = doc.getBoolean("isPro") == true || doc.getBoolean("isAccountPro") == true || doc.getString("proTier") == "ACCOUNT_PRO"
                            val revoked = doc.getBoolean("revokedByAdmin") == true
                            val key = (doc.getString("licenseKey") ?: "").trim()

                            if ((isPro || key.isNotBlank()) && !revoked) {
                                if (devId.isNotBlank()) proDeviceIds.add(devId)
                                if (normId.isNotBlank()) proDeviceIds.add(normId)
                                if (key.isNotBlank()) proKeys.add(key)
                                val ownerEmail = (doc.getString("ownerEmail") ?: "").trim()
                                if (ownerEmail.contains("@")) proUserEmails.add(ownerEmail.lowercase())
                                knowledgeLines.add("DEVICE_PRO: deviceId=$devId, normId=$normId, key=$key, owner=$ownerEmail")
                            }
                        }
                    } else {
                        // Fallback REST devices
                        val restDevices = FirestoreRestTokenBridge.fetchCollectionMapsViaRest(appCtx, "devices", 300)
                        for (map in restDevices) {
                            val devId = (map["deviceId"] as? String ?: map["__id"] as? String ?: "").trim().uppercase()
                            val normId = normalizeDeviceIdForMatch(devId)
                            val isPro = (map["isPro"] == true) || (map["isAccountPro"] == true) || (map["proTier"] == "ACCOUNT_PRO")
                            val revoked = map["revokedByAdmin"] == true
                            val key = (map["licenseKey"] as? String ?: "").trim()

                            if ((isPro || key.isNotBlank()) && !revoked) {
                                if (devId.isNotBlank()) proDeviceIds.add(devId)
                                if (normId.isNotBlank()) proDeviceIds.add(normId)
                                if (key.isNotBlank()) proKeys.add(key)
                                val ownerEmail = (map["ownerEmail"] as? String ?: "").trim()
                                if (ownerEmail.contains("@")) proUserEmails.add(ownerEmail.lowercase())
                                knowledgeLines.add("DEVICE_PRO: deviceId=$devId, normId=$normId, key=$key, owner=$ownerEmail")
                            }
                        }
                    }

                    // 3. Quét bảng ai_pro_chat_logs
                    if (aiLogsSnap != null && !aiLogsSnap.isEmpty) {
                        for (doc in aiLogsSnap.documents) {
                            val granted = doc.getBoolean("proGranted") == true
                            val key = (doc.getString("generatedKey") ?: "").trim()
                            val devId = (doc.getString("deviceId") ?: "").trim().uppercase()
                            val normId = normalizeDeviceIdForMatch(devId)
                            if ((granted || key.isNotBlank()) && devId.isNotBlank()) {
                                proDeviceIds.add(devId)
                                if (normId.isNotBlank()) proDeviceIds.add(normId)
                                if (key.isNotBlank()) proKeys.add(key)
                                knowledgeLines.add("AI_LOG_PRO: deviceId=$devId, key=$key")
                            }
                        }
                    } else {
                        val restLogs = FirestoreRestTokenBridge.fetchCollectionMapsViaRest(appCtx, "ai_pro_chat_logs", 150)
                        for (map in restLogs) {
                            val granted = map["proGranted"] == true
                            val key = (map["generatedKey"] as? String ?: "").trim()
                            val devId = (map["deviceId"] as? String ?: "").trim().uppercase()
                            val normId = normalizeDeviceIdForMatch(devId)
                            if ((granted || key.isNotBlank()) && devId.isNotBlank()) {
                                proDeviceIds.add(devId)
                                if (normId.isNotBlank()) proDeviceIds.add(normId)
                                if (key.isNotBlank()) proKeys.add(key)
                                knowledgeLines.add("AI_LOG_PRO: deviceId=$devId, key=$key")
                            }
                        }
                    }

                    // 4. Quét bảng pro_recovery_requests
                    if (recoverySnap != null && !recoverySnap.isEmpty) {
                        for (doc in recoverySnap.documents) {
                            val status = (doc.getString("status") ?: "").uppercase()
                            val devId = (doc.getString("deviceId") ?: doc.id).trim().uppercase()
                            val key = (doc.getString("restoredKey") ?: "").trim()
                            if ((status == "RESTORED" || status == "APPROVED") && devId.isNotBlank()) {
                                proDeviceIds.add(devId)
                                val normId = normalizeDeviceIdForMatch(devId)
                                if (normId.isNotBlank()) proDeviceIds.add(normId)
                                if (key.isNotBlank()) proKeys.add(key)
                            }
                        }
                    }

                    // Đồng bộ ngược lại bảng devices cho từng thiết bị Pro (Safe batch write)
                    try {
                        val batch = db.batch()
                        var batchCount = 0
                        for (pId in proDeviceIds) {
                            if (pId.length < 3) continue
                            val devRef = db.collection("devices").document(pId)
                            val expectedKey = if (pId.startsWith("TKPR-")) pId else generateLicenseKeyForDevice(pId)
                            batch.set(
                                devRef,
                                mapOf(
                                    "deviceId" to pId,
                                    "isPro" to true,
                                    "revokedByAdmin" to false,
                                    "licenseKey" to expectedKey,
                                    "updatedAt" to FieldValue.serverTimestamp()
                                ),
                                SetOptions.merge()
                            )
                            batchCount++
                            if (batchCount >= 450) break
                        }
                        if (batchCount > 0) {
                            batch.commit().await()
                        }
                    } catch (be: Exception) {
                        android.util.Log.w("LicenseManager", "Batch write devices warning: ${be.message}")
                    }

                    // Lưu kho API Key AI nếu có
                    val cleanPool = additionalGroqKeys.trim().ifBlank { getGroqApiKeyPool(appCtx) }
                    if (cleanPool.isNotBlank()) {
                        setGroqApiKeyPool(appCtx, cleanPool)
                    }

                    // Cắt tỉa nếu knowledgeBaseText quá lớn để đảm bảo an toàn dung lượng Firestore
                    val trimmedKnowledge = if (knowledgeLines.size > 2000) {
                        knowledgeLines.take(2000).joinToString("\n")
                    } else {
                        knowledgeLines.joinToString("\n")
                    }

                    val proDeviceIdsJoined = proDeviceIds.joinToString(",")
                    val proKeysJoined = proKeys.joinToString(",")
                    val proEmailsJoined = proUserEmails.joinToString(",")

                    val globalConfigUpdates = mapOf<String, Any>(
                        "ai_knowledge_base_key_list" to trimmedKnowledge,
                        "pro_device_ids" to proDeviceIdsJoined,
                        "pro_keys_list" to proKeysJoined,
                        "pro_user_emails" to proEmailsJoined,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )

                    // Ghi vào app_config/global: thử Firestore SDK trước, nếu lỗi thì Fallback qua REST Token Bridge
                    var writeSuccess = false
                    try {
                        db.collection("app_config").document("global").set(globalConfigUpdates, SetOptions.merge()).await()
                        writeSuccess = true
                    } catch (sdkEx: Exception) {
                        android.util.Log.w("LicenseManager", "SDK write global config failed, fallback to REST API: ${sdkEx.message}")
                        writeSuccess = FirestoreRestTokenBridge.patchDocViaRest(appCtx, "app_config", "global", globalConfigUpdates)
                    }

                    if (!writeSuccess) {
                        // Thử lại lần nữa qua REST
                        writeSuccess = FirestoreRestTokenBridge.patchDocViaRest(appCtx, "app_config", "global", globalConfigUpdates)
                    }

                    withContext(Dispatchers.Main) {
                        if (writeSuccess) {
                            onComplete(true, proDeviceIds.size, proKeys.size, "Đã đồng bộ ${proDeviceIds.size} thiết bị Pro và ${proKeys.size} Mã Key vào Knowledge Base & Cloud Firebase thành công!")
                        } else {
                            onComplete(false, proDeviceIds.size, proKeys.size, "Đã gom ${proDeviceIds.size} thiết bị Pro nhưng máy chủ Firebase tạm thời không phản hồi. Vui lòng thử lại sau vài giây.")
                        }
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    onComplete(false, 0, 0, "Lỗi khi đồng bộ: ${e.localizedMessage ?: "Quá thời gian kết nối (Timeout)"}")
                }
            }
        }
    }

    /**
     * Lưu chữ ký phần cứng Pro của thiết bị vào `Settings.Secure` (và qua `ShellEngine` nếu ADB/Shizuku đang bật)
     * để cả các máy Pro của Tài Khoản Vãng Lai (chưa từng đăng nhập) vẫn tự động được nhận diện trong 0ms ngay khi cài lại app!
     */
    fun persistHardwareProSignatureIfNeeded(context: Context, activated: Boolean = isProActivated(context)) {
        try {
            val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            val deviceId = getDeviceId(context).uppercase()
            val isUpgradedAcc = prefs.getBoolean(KEY_UPGRADED_TO_ACCOUNT_PRO, false)
            val expectedSig = if (activated && !isUpgradedAcc) {
                generateLicenseKeyForDevice(deviceId).replace("-", "").trim().uppercase()
            } else {
                ""
            }
            var wroteViaResolver = false
            try {
                wroteViaResolver = Settings.Secure.putString(context.contentResolver, SECURE_KEY_PRO_HW_SIG, expectedSig)
                Settings.Secure.putString(context.contentResolver, SECURE_KEY_PERSISTENT_DEVICE_ID, deviceId)
            } catch (_: Exception) {}

            if (!wroteViaResolver) {
                val appCtx = context.applicationContext
                val shell = com.example.core.shell.ShellEngine.getInstance(appCtx)
                if (shell.state.value.isAdbReady) {
                    kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
                        try {
                            val pkg = appCtx.packageName
                            shell.execute(
                                "pm grant --user 0 $pkg android.permission.WRITE_SECURE_SETTINGS >/dev/null 2>&1 || true; " +
                                    "settings put secure $SECURE_KEY_PRO_HW_SIG '$expectedSig' >/dev/null 2>&1; " +
                                    "settings put secure $SECURE_KEY_PERSISTENT_DEVICE_ID '$deviceId' >/dev/null 2>&1"
                            )
                        } catch (_: Exception) {}
                    }
                }
            }
        } catch (_: Exception) {}
    }

    private object RestoreFamiliarProHelper {
        fun applyRestoredProState(
            context: Context,
            deviceId: String,
            isAccountTier: Boolean,
            licenseKey: String,
            recognizedEmail: String,
            recognizedRole: String
        ) {
            val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            val editor = prefs.edit()
                .putBoolean(KEY_REVOKED_BY_ADMIN, false)
                .putBoolean(KEY_PRO_ACTIVATED, true)
                .putBoolean(KEY_ACCOUNT_PRO_ACTIVATED, isAccountTier)
                .putBoolean(KEY_UPGRADED_TO_ACCOUNT_PRO, isAccountTier)
                .putString(KEY_ACTIVATED_LICENSE, licenseKey.ifBlank { "CLOUD_FAMILIAR_DEVICE_RESTORED" })

            if (recognizedEmail.contains("@") && !recognizedEmail.contains(" ")) {
                editor.putString("last_familiar_email", recognizedEmail.lowercase())
                if (prefs.getString("current_user_email", "").isNullOrBlank()) {
                    editor.putString("current_user_email", recognizedEmail.lowercase())
                }
            }
            if (recognizedRole.equals("admin", ignoreCase = true) ||
                recognizedEmail.equals("vuongdhkmhn@gmail.com", ignoreCase = true)
            ) {
                editor.putString("current_user_role", "admin")
                markLocalAdminVerified(context, recognizedEmail.ifBlank { "vuongdhkmhn@gmail.com" })
            }
            editor.commit()
            writeProIntegritySeal(context, isPro = true, isAccPro = isAccountTier)

            // Lưu chữ ký phần cứng vào Settings.Secure (kèm fallback qua ShellEngine) để ngay cả khi offline lần sau vẫn nhận diện tức thì
            persistHardwareProSignatureIfNeeded(context, true)

            // Đồng bộ ngược lại bảng `devices/{deviceId}` để đảm bảo isPro = true luôn nhất quán trên Firebase
            try {
                val db = FirebaseFirestore.getInstance()
                val hwId = getHardwareId()
                val normId = normalizeDeviceIdForMatch(deviceId)
                val updateData = mutableMapOf<String, Any>(
                    "deviceId" to deviceId,
                    "normalizedDeviceId" to normId,
                    "hardwareId" to hwId,
                    "model" to "${Build.MANUFACTURER} ${Build.MODEL}",
                    "isPro" to true,
                    "isAccountPro" to isAccountTier,
                    "upgradedToAccountPro" to isAccountTier,
                    "proTier" to if (isAccountTier) "ACCOUNT_PRO" else "DEVICE_PRO",
                    "revokedByAdmin" to false,
                    "licenseKey" to licenseKey.ifBlank { generateLicenseKeyForDevice(deviceId) },
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                if (recognizedEmail.contains("@") && !recognizedEmail.contains(" ")) {
                    updateData["ownerEmail"] = recognizedEmail
                }
                db.collection("devices").document(deviceId).set(updateData, SetOptions.merge())
                if (normId.isNotBlank() && normId != deviceId) {
                    db.collection("devices").document(normId).set(updateData, SetOptions.merge())
                }
                if (normId.isNotBlank() && "MT-$normId" != deviceId) {
                    db.collection("devices").document("MT-$normId").set(updateData, SetOptions.merge())
                }
                val user = try { Firebase.auth.currentUser } catch (_: Exception) { null }
                if (user == null) {
                    FirestoreRestTokenBridge.patchDocAsync(context.applicationContext, "devices", deviceId, updateData)
                    if (normId.isNotBlank() && normId != deviceId) {
                        FirestoreRestTokenBridge.patchDocAsync(context.applicationContext, "devices", normId, updateData)
                    }
                    if (normId.isNotBlank() && "MT-$normId" != deviceId) {
                        FirestoreRestTokenBridge.patchDocAsync(context.applicationContext, "devices", "MT-$normId", updateData)
                    }
                }
            } catch (_: Exception) {}

            notifyProAndConfigStateChanged(context)
        }
    }

    fun getProPrice(context: Context): String {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val saved = prefs.getString("pro_price", null)
        if (!saved.isNullOrBlank()) return saved
        val sec = getSecureConfigString(context, "pro_price")
        if (!sec.isNullOrBlank()) {
            prefs.edit().putString("pro_price", sec).apply()
            return sec
        }
        return "50.000đ"
    }

    /**
     * Giá mua thẳng gói PRO TÀI KHOẢN (Đăng nhập đổi máy tự do - 1 máy hoạt động cùng lúc)
     * Cao hơn gói Pro theo ID máy (Mặc định: 100.000đ)
     */
    fun getAccountProPrice(context: Context): String {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val saved = prefs.getString("account_pro_price", null)
        if (!saved.isNullOrBlank()) return saved
        val sec = getSecureConfigString(context, "account_pro_price")
        if (!sec.isNullOrBlank()) {
            prefs.edit().putString("account_pro_price", sec).apply()
            return sec
        }
        return "100.000đ"
    }

    fun setAccountProPrice(context: Context, price: String) {
        val clean = price.trim().ifBlank { "100.000đ" }
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString("account_pro_price", clean).commit()
        putSecureConfigString(context, "account_pro_price", clean)
        try {
            val db = FirebaseFirestore.getInstance()
            db.collection("app_config").document("global").set(
                mapOf("account_pro_price" to clean, "updatedAt" to FieldValue.serverTimestamp()),
                SetOptions.merge()
            )
        } catch (_: Exception) {}
        notifyProAndConfigStateChanged(context)
    }

    /**
     * Phí nâng cấp từ PRO THIẾT BỊ (ID máy) lên PRO TÀI KHOẢN (Trả thêm tiền chênh lệch)
     * Mặc định: 50.000đ
     */
    fun getUpgradeToAccountProPrice(context: Context): String {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val saved = prefs.getString("upgrade_account_pro_price", null)
        if (!saved.isNullOrBlank()) return saved
        val sec = getSecureConfigString(context, "upgrade_account_pro_price")
        if (!sec.isNullOrBlank()) {
            prefs.edit().putString("upgrade_account_pro_price", sec).apply()
            return sec
        }
        return "50.000đ"
    }

    fun setUpgradeToAccountProPrice(context: Context, price: String) {
        val clean = price.trim().ifBlank { "50.000đ" }
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString("upgrade_account_pro_price", clean).commit()
        putSecureConfigString(context, "upgrade_account_pro_price", clean)
        try {
            val db = FirebaseFirestore.getInstance()
            db.collection("app_config").document("global").set(
                mapOf("upgrade_account_pro_price" to clean, "updatedAt" to FieldValue.serverTimestamp()),
                SetOptions.merge()
            )
        } catch (_: Exception) {}
        notifyProAndConfigStateChanged(context)
    }

    /**
     * Lưu đồng thời cả 3 mức giá Pro vào SharedPreferences + Settings.Secure + Firestore app_config/global trong 1 lệnh nguyên tử
     */
    fun saveAllProPrices(
        context: Context,
        proPrice: String,
        accountProPrice: String,
        upgradeAccountProPrice: String,
        onComplete: ((Boolean) -> Unit)? = null
    ) {
        val cleanPro = proPrice.trim().ifBlank { "50.000đ" }
        val cleanAcc = accountProPrice.trim().ifBlank { "100.000đ" }
        val cleanUpg = upgradeAccountProPrice.trim().ifBlank { "50.000đ" }

        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putString("pro_price", cleanPro)
            .putString("account_pro_price", cleanAcc)
            .putString("upgrade_account_pro_price", cleanUpg)
            .commit()

        putSecureConfigString(context, "pro_price", cleanPro)
        putSecureConfigString(context, "account_pro_price", cleanAcc)
        putSecureConfigString(context, "upgrade_account_pro_price", cleanUpg)

        notifyProAndConfigStateChanged(context)

        syncCloudGlobalConfigMap(
            context,
            mapOf(
                "pro_price" to cleanPro,
                "account_pro_price" to cleanAcc,
                "upgrade_account_pro_price" to cleanUpg
            ),
            onComplete
        )
    }

    /**
     * Xử lý tin nhắn SMS từ Ngân hàng / Momo
     */
    fun processIncomingSmsText(context: Context, rawBody: String, sender: String = ""): Boolean {
        return processIncomingPaymentText(context, rawBody, sender, source = "SMS")
    }

    /**
     * Kiểm tra thông báo/SMS có chứa từ khóa báo giao dịch thất bại, không đủ số dư, hủy bỏ, mã OTP hay yêu cầu chuyển tiền không.
     */
    fun containsPaymentFailureKeywords(upperText: String): Boolean {
        return upperText.contains("KHONG DU") ||
                upperText.contains("KHÔNG ĐỦ") ||
                upperText.contains("THAT BAI") ||
                upperText.contains("THẤT BẠI") ||
                upperText.contains("KHONG THANH CONG") ||
                upperText.contains("KHÔNG THÀNH CÔNG") ||
                upperText.contains("CHUA THANH CONG") ||
                upperText.contains("CHƯA THÀNH CÔNG") ||
                upperText.contains("TU CHOI") ||
                upperText.contains("TỪ CHỐI") ||
                upperText.contains("BI HUY") ||
                upperText.contains("BỊ HỦY") ||
                upperText.contains("DA HUY") ||
                upperText.contains("ĐÃ HỦY") ||
                upperText.contains("LOI GIAO DICH") ||
                upperText.contains("LỖI GIAO DỊCH") ||
                upperText.contains("MA OTP") ||
                upperText.contains("MÃ OTP") ||
                upperText.contains("MA XAC THUC") ||
                upperText.contains("MÃ XÁC THỰC") ||
                upperText.contains("KHONG CHIA SE MA") ||
                upperText.contains("KHÔNG CHIA SẺ MÃ") ||
                upperText.contains("YEU CAU CHUYEN") ||
                upperText.contains("YÊU CẦU CHUYỂN") ||
                upperText.contains("NHAC NO") ||
                upperText.contains("NHẮC NỢ")
    }

    /**
     * Kiểm tra đầu số gửi SMS có phải là Brandname chính thống của Ngân Hàng / Ví điện tử hay không.
     * Chặn hoàn toàn các số điện thoại cá nhân (09..., 03..., 07..., 08..., 05..., +84...) gửi tin nhắn SMS giả mạo biến động số dư!
     */
    fun isOfficialBankSmsSender(sender: String): Boolean {
        val clean = sender.trim().uppercase()
        if (clean.isBlank()) return false
        // Nếu người gửi chỉ toàn chữ số hoặc bắt đầu bằng +84 / 84 / 03 / 05 / 07 / 08 / 09 (số ĐT cá nhân) -> Chặn!
        val digitsOnly = clean.replace("+", "").replace(" ", "").replace("-", "")
        if (digitsOnly.all { it.isDigit() }) return false
        if (clean.startsWith("+84") || clean.startsWith("09") || clean.startsWith("03") ||
            clean.startsWith("07") || clean.startsWith("08") || clean.startsWith("05")
        ) {
            return false
        }

        val bankBrandnames = listOf(
            "MBBANK", "MB", "VIETCOMBANK", "VCB", "TECHCOMBANK", "TCB",
            "BIDV", "VIETINBANK", "CTG", "AGRIBANK", "ACB", "VPBANK",
            "TPBANK", "TPB", "SACOMBANK", "STB", "MSB", "OCB", "VIB",
            "SHB", "HDBANK", "SEABANK", "LPBANK", "LIENVIET", "EXIMBANK",
            "CAKE", "TIMO", "TNEX", "MOMO", "ZALOPAY", "VIETTELPAY",
            "VIETTELMONEY", "VNPAY", "NAMABANK", "BACABANK", "PVCOMBANK",
            "ABBANK", "KIENLONGBANK", "VIETBANK", "NCB", "BVBANK"
        )
        return bankBrandnames.any { clean.contains(it) }
    }

    /**
     * Bóc tách số tiền giao dịch thực tế (VNĐ) từ thông báo Ngân hàng / SMS.
     * Loại bỏ phần "Số dư cuối / SD:" để tránh trường hợp khách chuyển 1.000đ nhưng số dư tài khoản còn 500.000đ!
     */
    fun extractMaxVndAmount(rawText: String, deviceIdToStrip: String = ""): Long {
        var cleaned = rawText.uppercase()
        if (deviceIdToStrip.isNotBlank()) {
            cleaned = cleaned.replace(deviceIdToStrip.uppercase(), " ")
            cleaned = cleaned.replace(deviceIdToStrip.uppercase().replace("MT-", ""), " ")
        }
        // Loại bỏ số tài khoản 9-16 chữ số liền nhau để không nhầm STK với số tiền
        cleaned = cleaned.replace(Regex("\\b0[0-9]{8,15}\\b"), " ")

        // 1. Ưu tiên tìm số tiền đi kèm dấu +/- hoặc sau từ khóa GD / Số tiền / Thay đổi (Số tiền giao dịch trực tiếp)
        val signedTxRegex = Regex("""(?:GD|GIAO\s*DỊCH|GIAO\s*DICH|SỐ\s*TIỀN|SO\s*TIEN|THAY\s*ĐỔI|THAY\s*DOI|CHUYỂN|CHUYEN)?\s*[:=]?\s*[+-]\s*([0-9]{1,3}(?:[.,][0-9]{3})+|[0-9]{5,9})\s*(?:VND|VNĐ|Đ|D|\b)""")
        val signedMatches = signedTxRegex.findAll(cleaned).mapNotNull { m ->
            m.groupValues.getOrNull(1)?.replace(".", "")?.replace(",", "")?.toLongOrNull()
        }.filter { it in 1_000L..500_000_000L }.toList()

        if (signedMatches.isNotEmpty()) {
            // Nếu có số tiền biến động trực tiếp (+/-), trả về số tiền biến động đầu tiên (nếu < 50.000đ như 1.000đ/2.000đ sẽ bị phát hiện ngay!)
            return signedMatches.first()
        }

        // 2. Xóa các cụm "SD: xxx VND" / "Số dư: xxx VND" (không có chữ "thay đổi") trước khi quét số tiền kèm đơn vị VND/đ
        val withoutBalance = cleaned.replace(
            Regex("""(?:SD|SỐ\s*DƯ\s*CUỐI|SO\s*DU\s*CUOI|SỐ\s*DƯ\s*KHẢ\s*DỤNG|SO\s*DU\s*KHA\s*DUNG|SỐ\s*DƯ|SO\s*DU)\s*[:=]?\s*[0-9]{1,3}(?:[.,][0-9]{3})*\s*(?:VND|VNĐ|Đ|D)?"""),
            " "
        )

        val currencyRegex = Regex("""\b([0-9]{1,3}(?:[.,][0-9]{3})+|[0-9]{5,9})\s*(?:VND|VNĐ|Đ)\b""")
        val currencyMatches = currencyRegex.findAll(withoutBalance).mapNotNull { m ->
            m.groupValues.getOrNull(1)?.replace(".", "")?.replace(",", "")?.toLongOrNull()
        }.filter { it in 1_000L..500_000_000L }.toList()

        if (currencyMatches.isNotEmpty()) {
            return currencyMatches.first()
        }
        return 0L
    }

    /**
     * Xử lý nội dung thanh toán từ SMS hoặc Thông Báo Biến Động Số Dư (OTT) của Ngân Hàng / Ví điện tử
     * Kiểm tra:
     * 1. Có chứa Mã Kích Hoạt SHA-256 (License Key Thiết Bị hoặc Key Pro Tài Khoản TKPR-...)
     * 2. HOẶC (chỉ áp dụng cho BANK_NOTIFICATION từ đúng App Ngân Hàng chính thống hoặc SMS từ Brandname Ngân Hàng):
     *    Chứa Device ID + dấu hiệu giao dịch thành công + Số tiền thực tế >= 50.000 VNĐ (hoặc >= 100.000 VNĐ cho TKPRO).
     */
    fun processIncomingPaymentText(context: Context, rawBody: String, sender: String = "", source: String = "AUTO"): Boolean {
        if (rawBody.isBlank()) return false

        val normalizedBody = rawBody.uppercase().replace("-", "").replace(" ", "").replace("\n", "").trim()
        val deviceId = getDeviceId(context).uppercase()
        val expectedDeviceKey = generateLicenseKeyForDevice(deviceId).replace("-", "").trim().uppercase()
        val expectedAccountKey = generateAccountProLicenseKeyForDevice(deviceId).replace("-", "").trim().uppercase()

        // 1A. Kiểm tra mã Key PRO TÀI KHOẢN (TKPR-...) chuẩn SHA-256
        if (expectedAccountKey.length >= 16 && normalizedBody.contains(expectedAccountKey)) {
            val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            prefs.edit().putBoolean(KEY_REVOKED_BY_ADMIN, false).apply()
            activateAccountPro(context, "${source}_ACCOUNT_KEY_${System.currentTimeMillis()}", syncToCloud = true)
            return true
        }

        // 1B. Kiểm tra mã License Key chuẩn SHA-256 (Pro Thiết Bị)
        if (expectedDeviceKey.length >= 16 && normalizedBody.contains(expectedDeviceKey)) {
            val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            prefs.edit().putBoolean(KEY_REVOKED_BY_ADMIN, false).apply()
            setProActivated(context, true, "${source}_VERIFIED_KEY_${System.currentTimeMillis()}", syncToCloud = true)
            return true
        }

        // CHỐT CHẶN BẢO MẬT 1: Nếu người dùng bấm nút "Dán" từ bộ nhớ tạm (source == "PASTE"),
        // TUYỆT ĐỐI chỉ chấp nhận Mã Key mật mã SHA-256 ở bước 1A/1B, KHÔNG BAO GIỜ cấp Pro qua nội dung văn bản tự gõ!
        if (source.equals("PASTE", ignoreCase = true)) {
            return false
        }

        // CHỐT CHẶN BẢO MẬT 2 (QUAN TRỌNG NHẤT): KHÓA CHẶT TỰ CẤP PRO TRÊN MÁY KHÁCH!
        // Để chống thất thoát tiền tuyệt đối cho Admin:
        // Thiết bị của khách hàng KHÔNG ĐƯỢC PHÉP tự kích hoạt Pro từ thông báo ngân hàng / SMS của chính khách!
        // (Tránh trường hợp khách chuyển tiền cho người khác, nhận thông báo rút tiền, OTP, hoặc thông báo Shopee/Grab
        // rồi tự kích hoạt Pro vĩnh viễn trên máy mình).
        // Khách hàng BẮT BUỘC phải dùng Mã Key bản quyền SHA-256 (TKPR-...) ở bước 1A/1B hoặc được Admin duyệt trên Dashboard!
        val isAdminDevice = isCurrentUserAdmin(context)
        if (!isAdminDevice) {
            return false
        }

        return false
    }

    /**
     * Kiểm tra trạng thái thanh toán từ xa qua Firestore `devices/{deviceId}` và Server GitHub của Admin
     */
    suspend fun checkOnlinePaymentStatusRemote(context: Context): Boolean = withContext(Dispatchers.IO) {
        if (checkDeviceRecognizedProInCloud(context)) return@withContext true

        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        if (prefs.getBoolean(KEY_REVOKED_BY_ADMIN, false)) return@withContext false

        val deviceId = getDeviceId(context).uppercase()
        var connection: HttpURLConnection? = null
        try {
            val url = URL(PAID_DEVICES_URL)
            connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            connection.connectTimeout = 5000
            connection.readTimeout = 5000
            connection.useCaches = false

            if (connection.responseCode == 200) {
                val reader = BufferedReader(InputStreamReader(connection.inputStream))
                val content = reader.use { it.readText().uppercase() }

                val cleanDeviceId = deviceId.replace("MT-", "")
                if (content.contains(deviceId) || (cleanDeviceId.length >= 6 && content.contains(cleanDeviceId))) {
                    setProActivated(context, true, "ONLINE_SERVER_VERIFIED_${System.currentTimeMillis()}", syncToCloud = true)
                    return@withContext true
                }
            }
            false
        } catch (_: Exception) {
            false
        } finally {
            connection?.disconnect()
        }
    }

    /**
     * Cơ chế Kill-Switch an toàn từ xa
     */
    suspend fun checkKillSwitchRemote(): Boolean = withContext(Dispatchers.IO) {
        var connection: HttpURLConnection? = null
        try {
            val url = URL(KILL_SWITCH_URL)
            connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            connection.connectTimeout = 4000
            connection.readTimeout = 4000
            connection.useCaches = false

            if (connection.responseCode == 200) {
                val reader = BufferedReader(InputStreamReader(connection.inputStream))
                val content = reader.use { it.readText() }
                if (content.contains("STOPPED", ignoreCase = true)) {
                    return@withContext true
                }
            }
            false
        } catch (_: Exception) {
            false
        } finally {
            connection?.disconnect()
        }
    }

    private const val KEY_FREE_TRIAL_USED = "free_pro_trial_used"

    fun hasUsedFreeTrial(context: Context): Boolean {
        return getRemainingFreeTrials(context) <= 0
    }

    fun consumeFreeTrial(context: Context) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val used = prefs.getInt("free_trial_count_used", 0)
        prefs.edit()
            .putInt("free_trial_count_used", used + 1)
            .putBoolean(KEY_FREE_TRIAL_USED, true)
            .apply()
    }

    fun setProPrice(context: Context, price: String) {
        val clean = price.trim().ifBlank { "50.000đ" }
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString("pro_price", clean).commit()
        putSecureConfigString(context, "pro_price", clean)
        try {
            val db = FirebaseFirestore.getInstance()
            db.collection("app_config").document("global").set(
                mapOf("pro_price" to clean, "updatedAt" to FieldValue.serverTimestamp()),
                SetOptions.merge()
            )
        } catch (_: Exception) {}
        notifyProAndConfigStateChanged(context)
    }

    fun getUpdateLink(context: Context): String {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val saved = prefs.getString("custom_update_link", null)
        if (!saved.isNullOrBlank()) return saved
        val sec = getSecureConfigString(context, "custom_update_link")
        if (!sec.isNullOrBlank()) {
            prefs.edit().putString("custom_update_link", sec).apply()
            return sec
        }
        return "https://drive.google.com/drive/folders/1WLsS-OlxvKFUWzMPxnkrNn8kmlVIY6-k?usp=sharing"
    }

    fun setUpdateLink(context: Context, link: String) {
        val clean = link.trim()
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString("custom_update_link", clean).commit()
        putSecureConfigString(context, "custom_update_link", clean)
        syncCloudGlobalConfigMap(context, mapOf("custom_update_link" to clean))
        notifyProAndConfigStateChanged(context)
    }

    fun getFacebookLink(context: Context): String {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val saved = prefs.getString("custom_fb_link", null)
        if (!saved.isNullOrBlank()) return saved
        val sec = getSecureConfigString(context, "custom_fb_link")
        if (!sec.isNullOrBlank()) {
            prefs.edit().putString("custom_fb_link", sec).apply()
            return sec
        }
        return "https://www.facebook.com/profile.php?id=61578514512929"
    }

    fun setFacebookLink(context: Context, link: String) {
        val clean = link.trim()
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString("custom_fb_link", clean).commit()
        putSecureConfigString(context, "custom_fb_link", clean)
        syncCloudGlobalConfigMap(context, mapOf("custom_fb_link" to clean))
        notifyProAndConfigStateChanged(context)
    }

    const val KEY_ADMIN_LAST_ACTIVE = "admin_last_active_timestamp"
    const val KEY_AUTO_FREE_DAYS = "auto_free_inactivity_days"
    const val DEFAULT_AUTO_FREE_DAYS = 30

    /**
     * Cập nhật nhịp tim hoạt động của Admin lên Firestore (app_config/global).
     * Được gọi tự động mỗi khi Admin mở ứng dụng hoặc truy cập màn hình Quản Trị.
     */
    fun updateAdminHeartbeat(context: Context) {
        val appCtx = context.applicationContext
        try {
            val nowMs = System.currentTimeMillis()
            val prefs = appCtx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            prefs.edit().putLong(KEY_ADMIN_LAST_ACTIVE, nowMs).apply()

            syncCloudGlobalConfigMap(appCtx, mapOf("admin_last_active_ms" to nowMs))
        } catch (_: Exception) {}
    }

    /**
     * Lấy số ngày không có Admin truy cập thì tự động mở miễn phí toàn bộ ứng dụng (Mặc định: 30 ngày).
     */
    fun getAutoFreeInactivityDays(context: Context): Int {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val local = prefs.getInt(KEY_AUTO_FREE_DAYS, 0)
        if (local > 0) return local
        val sec = getSecureConfigString(context, KEY_AUTO_FREE_DAYS)?.toIntOrNull()
        if (sec != null && sec > 0) {
            prefs.edit().putInt(KEY_AUTO_FREE_DAYS, sec).apply()
            return sec
        }
        return DEFAULT_AUTO_FREE_DAYS
    }

    /**
     * Admin tùy chỉnh số ngày không hoạt động để tự động miễn phí hóa toàn bộ ứng dụng.
     */
    fun setAutoFreeInactivityDays(context: Context, days: Int, onComplete: ((Boolean) -> Unit)? = null) {
        val appCtx = context.applicationContext
        val cleanDays = days.coerceIn(1, 3650)
        val prefs = appCtx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putInt(KEY_AUTO_FREE_DAYS, cleanDays).apply()
        putSecureConfigString(appCtx, KEY_AUTO_FREE_DAYS, cleanDays.toString())

        syncCloudGlobalConfigMap(appCtx, mapOf(KEY_AUTO_FREE_DAYS to cleanDays), onComplete)
        notifyProAndConfigStateChanged(appCtx)
    }

    /**
     * Kiểm tra xem cơ chế Tự Động Miễn Phí (khi không có Admin quản lý trong X ngày) đã được kích hoạt hay chưa.
     */
    fun isAutoFreeDueToAdminInactivity(context: Context): Boolean {
        try {
            val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            val thresholdDays = prefs.getInt(KEY_AUTO_FREE_DAYS, DEFAULT_AUTO_FREE_DAYS).coerceAtLeast(1)
            val lastAdminActiveMs = prefs.getLong(KEY_ADMIN_LAST_ACTIVE, 0L)
            if (lastAdminActiveMs > 0L) {
                val diffMs = System.currentTimeMillis() - lastAdminActiveMs
                val diffDays = diffMs / (1000L * 60L * 60L * 24L)
                if (diffDays >= thresholdDays) {
                    return true
                }
            }
        } catch (_: Exception) {}
        return false
    }


    /**
     * Đồng bộ cấu hình toàn cầu lên Firestore `app_config/global` bằng cả Firestore SDK và REST API Token Bridge.
     * Đảm bảo mọi thay đổi của Admin được lưu vĩnh viễn trên Cloud và áp dụng toàn cầu ngay lập tức.
     */
    fun syncCloudGlobalConfigMap(
        context: Context,
        data: Map<String, Any>,
        onComplete: ((Boolean) -> Unit)? = null
    ) {
        val appCtx = context.applicationContext
        val mergedData = data + ("updatedAt" to FieldValue.serverTimestamp())
        var firestoreSuccess = false

        try {
            val db = FirebaseFirestore.getInstance()
            db.collection("app_config").document("global").set(mergedData, SetOptions.merge())
                .addOnSuccessListener {
                    firestoreSuccess = true
                    onComplete?.invoke(true)
                }
                .addOnFailureListener {
                    // Fallback REST API
                    FirestoreRestTokenBridge.patchDocAsync(appCtx, "app_config", "global", data)
                    onComplete?.invoke(true)
                }
        } catch (_: Exception) {
            FirestoreRestTokenBridge.patchDocAsync(appCtx, "app_config", "global", data)
            onComplete?.invoke(true)
        }

        // Luôn chạy song song một lượt REST API dự phòng để đảm bảo tính sẵn sàng cao nhất
        FirestoreRestTokenBridge.patchDocAsync(appCtx, "app_config", "global", data)
    }

    fun isAppFreeMode(context: Context): Boolean {
        // Nếu trong số ngày tùy chỉnh không có admin nào truy cập,
        // hệ thống tự động mở khóa toàn bộ ứng dụng thành MIỄN PHÍ vĩnh viễn!
        if (isAutoFreeDueToAdminInactivity(context)) {
            return true
        }
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val raw = prefs.getBoolean("is_app_free_mode", false)
        if (!raw) {
            val sec = getSecureConfigString(context, "is_app_free_mode")
            if (sec == "true") {
                prefs.edit().putBoolean("is_app_free_mode", true).apply()
                return true
            }
            return false
        }
        val storedSeal = prefs.getString(KEY_FREE_MODE_CRYPTO_SEAL, "") ?: ""
        val expectedGlobalSeal = computeGlobalConfigSeal("FREE_MODE_GLOBAL", "true")
        val expectedHwSeal = computeHardwareCryptoSeal(context, "FREE_MODE_GLOBAL", "true")
        if (storedSeal.isNotBlank() && (storedSeal == expectedGlobalSeal || storedSeal == expectedHwSeal)) {
            return true
        }
        val sec = getSecureConfigString(context, "is_app_free_mode")
        if (sec == "true") {
            val validSeal = computeGlobalConfigSeal("FREE_MODE_GLOBAL", "true")
            prefs.edit().putString(KEY_FREE_MODE_CRYPTO_SEAL, validSeal).apply()
            return true
        }
        // Chặn can thiệp sửa is_app_free_mode=true trong SharedPreferences XML
        prefs.edit()
            .putBoolean("is_app_free_mode", false)
            .remove(KEY_FREE_MODE_CRYPTO_SEAL)
            .commit()
        reportTamperAttemptToCloud(context, "Phát hiện sửa đổi trái phép cờ is_app_free_mode=true trong SharedPreferences XML")
        return false
    }

    fun setAppFreeMode(context: Context, isFree: Boolean) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val seal = computeGlobalConfigSeal("FREE_MODE_GLOBAL", isFree.toString())
        prefs.edit()
            .putBoolean("is_app_free_mode", isFree)
            .putString(KEY_FREE_MODE_CRYPTO_SEAL, seal)
            .commit()
        putSecureConfigString(context, "is_app_free_mode", isFree.toString())
        syncCloudGlobalConfigMap(context, mapOf("is_app_free_mode" to isFree))
        notifyProAndConfigStateChanged(context)
    }

    fun getFreeTrialLimit(context: Context): Int {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val rawLimit = prefs.getInt("free_trial_limit", 5).coerceAtLeast(0)
        val secLimit = getSecureConfigString(context, "free_trial_limit")?.toIntOrNull()

        // Khớp với Secure Storage dự phòng
        val candidateLimit = if (rawLimit <= 5 && secLimit != null && secLimit > 5) secLimit else rawLimit
        if (candidateLimit <= 5) return candidateLimit

        val storedSeal = prefs.getString(KEY_TRIAL_LIMIT_CRYPTO_SEAL, "") ?: ""
        val expectedGlobalSeal = computeGlobalConfigSeal("TRIAL_LIMIT_GLOBAL", candidateLimit.toString())
        val expectedHwSeal = computeHardwareCryptoSeal(context, "TRIAL_LIMIT_GLOBAL", candidateLimit.toString())

        if (storedSeal.isNotBlank() && (storedSeal == expectedGlobalSeal || storedSeal == expectedHwSeal)) {
            return candidateLimit
        }

        // Nếu có giá trị hợp lệ từ Secure Storage nhưng chưa có seal (sau khi cài lại app)
        if (secLimit != null && secLimit > 5 && secLimit == rawLimit) {
            val validSeal = computeGlobalConfigSeal("TRIAL_LIMIT_GLOBAL", secLimit.toString())
            prefs.edit().putString(KEY_TRIAL_LIMIT_CRYPTO_SEAL, validSeal).apply()
            return secLimit
        }

        // Chặn can thiệp sửa free_trial_limit=999999 trong SharedPreferences XML
        prefs.edit()
            .putInt("free_trial_limit", 5)
            .remove(KEY_TRIAL_LIMIT_CRYPTO_SEAL)
            .commit()
        putSecureConfigString(context, "free_trial_limit", "5")
        reportTamperAttemptToCloud(context, "Phát hiện sửa đổi trái phép giới hạn dùng thử free_trial_limit=$candidateLimit trong SharedPreferences XML")
        return 5
    }

    fun setFreeTrialLimit(context: Context, limit: Int) {
        val safeLimit = limit.coerceAtLeast(0)
        val seal = computeGlobalConfigSeal("TRIAL_LIMIT_GLOBAL", safeLimit.toString())
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putInt("free_trial_limit", safeLimit)
            .putString(KEY_TRIAL_LIMIT_CRYPTO_SEAL, seal)
            .commit()
        putSecureConfigString(context, "free_trial_limit", safeLimit.toString())
        syncCloudGlobalConfigMap(context, mapOf("free_trial_limit" to safeLimit))
        notifyProAndConfigStateChanged(context)
    }

    fun getPaymentBankName(context: Context): String {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val saved = prefs.getString(KEY_PAYMENT_BANK_NAME, null)
        if (!saved.isNullOrBlank()) return saved
        val sec = getSecureConfigString(context, KEY_PAYMENT_BANK_NAME)
        if (!sec.isNullOrBlank()) return sec
        return "MBBank"
    }

    fun getPaymentBankCode(context: Context): String {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val saved = prefs.getString(KEY_PAYMENT_BANK_CODE, null)
        if (!saved.isNullOrBlank()) return saved
        val sec = getSecureConfigString(context, KEY_PAYMENT_BANK_CODE)
        if (!sec.isNullOrBlank()) return sec
        return "MB"
    }

    fun getPaymentAccountNumber(context: Context): String {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val saved = prefs.getString(KEY_PAYMENT_ACCOUNT_NUMBER, null)
        if (!saved.isNullOrBlank()) return saved
        val sec = getSecureConfigString(context, KEY_PAYMENT_ACCOUNT_NUMBER)
        if (!sec.isNullOrBlank()) return sec
        return "0393368007"
    }

    fun getPaymentAccountHolder(context: Context): String {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val saved = prefs.getString(KEY_PAYMENT_ACCOUNT_HOLDER, null)
        if (!saved.isNullOrBlank()) return saved
        val sec = getSecureConfigString(context, KEY_PAYMENT_ACCOUNT_HOLDER)
        if (!sec.isNullOrBlank()) return sec
        return "NGUYEN VAN VUONG"
    }

    fun setPaymentAccount(
        context: Context,
        bankName: String,
        bankCode: String,
        accountNumber: String,
        accountHolder: String
    ) {
        val cleanBankName = bankName.trim().ifBlank { "MBBank" }
        val cleanBankCode = bankCode.trim().uppercase().ifBlank { "MB" }
        val cleanAccountNumber = accountNumber.trim().ifBlank { "0393368007" }
        val cleanAccountHolder = accountHolder.trim().uppercase().ifBlank { "NGUYEN VAN VUONG" }

        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putString(KEY_PAYMENT_BANK_NAME, cleanBankName)
            .putString(KEY_PAYMENT_BANK_CODE, cleanBankCode)
            .putString(KEY_PAYMENT_ACCOUNT_NUMBER, cleanAccountNumber)
            .putString(KEY_PAYMENT_ACCOUNT_HOLDER, cleanAccountHolder)
            .commit()

        putSecureConfigString(context, KEY_PAYMENT_BANK_NAME, cleanBankName)
        putSecureConfigString(context, KEY_PAYMENT_BANK_CODE, cleanBankCode)
        putSecureConfigString(context, KEY_PAYMENT_ACCOUNT_NUMBER, cleanAccountNumber)
        putSecureConfigString(context, KEY_PAYMENT_ACCOUNT_HOLDER, cleanAccountHolder)

        syncCloudGlobalConfigMap(
            context,
            mapOf(
                KEY_PAYMENT_BANK_NAME to cleanBankName,
                KEY_PAYMENT_BANK_CODE to cleanBankCode,
                KEY_PAYMENT_ACCOUNT_NUMBER to cleanAccountNumber,
                KEY_PAYMENT_ACCOUNT_HOLDER to cleanAccountHolder
            )
        )
        notifyProAndConfigStateChanged(context)
    }



    fun getGlobalBroadcast(context: Context): GlobalBroadcastMessage? {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val id = prefs.getString(KEY_BROADCAST_ID, "") ?: ""
        val title = prefs.getString(KEY_BROADCAST_TITLE, "") ?: ""
        val message = prefs.getString(KEY_BROADCAST_MESSAGE, "") ?: ""
        val type = prefs.getString(KEY_BROADCAST_TYPE, "UPDATE") ?: "UPDATE"
        val isActive = prefs.getBoolean(KEY_BROADCAST_ACTIVE, false)
        val url = prefs.getString(KEY_BROADCAST_URL, getUpdateLink(context)) ?: getUpdateLink(context)
        val sentAt = prefs.getLong(KEY_BROADCAST_SENT_AT, 0L)
        if (!isActive || (title.isBlank() && message.isBlank())) return null
        return GlobalBroadcastMessage(
            id = id,
            title = title,
            message = message,
            type = type,
            isActive = isActive,
            actionUrl = url,
            sentAtMs = sentAt
        )
    }

    fun isBroadcastDismissed(context: Context, broadcastId: String): Boolean {
        if (broadcastId.isBlank()) return false
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_DISMISSED_BROADCAST_ID, "") == broadcastId
    }

    fun markBroadcastDismissed(context: Context, broadcastId: String) {
        if (broadcastId.isBlank()) return
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_DISMISSED_BROADCAST_ID, broadcastId).apply()
    }

    fun sendGlobalBroadcast(
        context: Context,
        title: String,
        message: String,
        type: String = "UPDATE",
        customUpdateUrl: String = ""
    ) {
        val now = System.currentTimeMillis()
        val broadcastId = "BC_$now"
        val cleanTitle = title.trim().ifBlank { "🚀 Thông Báo Mới Từ Quản Trị Viên" }
        val cleanMsg = message.trim()
        val cleanUrl = customUpdateUrl.trim().ifBlank { getUpdateLink(context) }

        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val editor = prefs.edit()
            .putString(KEY_BROADCAST_ID, broadcastId)
            .putString(KEY_BROADCAST_TITLE, cleanTitle)
            .putString(KEY_BROADCAST_MESSAGE, cleanMsg)
            .putString(KEY_BROADCAST_TYPE, type)
            .putBoolean(KEY_BROADCAST_ACTIVE, true)
            .putString(KEY_BROADCAST_URL, cleanUrl)
            .putLong(KEY_BROADCAST_SENT_AT, now)
            .remove(KEY_DISMISSED_BROADCAST_ID)

        if (customUpdateUrl.isNotBlank()) {
            editor.putString("custom_update_link", cleanUrl)
        }
        editor.apply()

        val broadcastObj = GlobalBroadcastMessage(
            id = broadcastId,
            title = cleanTitle,
            message = cleanMsg,
            type = type,
            isActive = true,
            actionUrl = cleanUrl,
            sentAtMs = now
        )
        _globalBroadcastFlow.value = broadcastObj

        try {
            val db = FirebaseFirestore.getInstance()
            val payload = mutableMapOf<String, Any>(
                KEY_BROADCAST_ID to broadcastId,
                KEY_BROADCAST_TITLE to cleanTitle,
                KEY_BROADCAST_MESSAGE to cleanMsg,
                KEY_BROADCAST_TYPE to type,
                KEY_BROADCAST_ACTIVE to true,
                KEY_BROADCAST_URL to cleanUrl,
                KEY_BROADCAST_SENT_AT to now,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (customUpdateUrl.isNotBlank()) {
                payload["custom_update_link"] = cleanUrl
            }
            db.collection("app_config").document("global").set(payload, SetOptions.merge())
        } catch (_: Exception) {}
    }

    fun clearGlobalBroadcast(context: Context) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putBoolean(KEY_BROADCAST_ACTIVE, false)
            .apply()
        _globalBroadcastFlow.value = null
        try {
            val db = FirebaseFirestore.getInstance()
            db.collection("app_config").document("global").set(
                mapOf(
                    KEY_BROADCAST_ACTIVE to false,
                    "updatedAt" to FieldValue.serverTimestamp()
                ),
                SetOptions.merge()
            )
        } catch (_: Exception) {}
    }

    private fun showSystemBroadcastNotification(context: Context, broadcast: GlobalBroadcastMessage) {
        try {
            val channelId = "magictune_global_broadcast_channel"
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? android.app.NotificationManager ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = android.app.NotificationChannel(
                    channelId,
                    "Thông Báo Hệ Thống & Bản Cập Nhật",
                    android.app.NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Nhận thông báo phiên bản mới và thông báo quan trọng từ Admin"
                    enableVibration(true)
                }
                nm.createNotificationChannel(channel)
            }

            val openAppIntent = context.packageManager.getLaunchIntentForPackage(context.packageName)?.apply {
                flags = android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val pendingFlags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
            } else {
                android.app.PendingIntent.FLAG_UPDATE_CURRENT
            }
            val contentPendingIntent = if (openAppIntent != null) {
                android.app.PendingIntent.getActivity(context, 9001, openAppIntent, pendingFlags)
            } else null

            val builder = androidx.core.app.NotificationCompat.Builder(context, channelId)
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle(broadcast.title.ifBlank { "📢 Thông báo từ Magictune_Tool" })
                .setContentText(broadcast.message)
                .setStyle(androidx.core.app.NotificationCompat.BigTextStyle().bigText(broadcast.message))
                .setPriority(androidx.core.app.NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)

            if (contentPendingIntent != null) {
                builder.setContentIntent(contentPendingIntent)
            }

            if (broadcast.type == "UPDATE") {
                val updateUrl = broadcast.actionUrl.ifBlank { getUpdateLink(context) }
                val updateIntent = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(updateUrl)).apply {
                    addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                val updatePendingIntent = android.app.PendingIntent.getActivity(context, 9002, updateIntent, pendingFlags)
                builder.addAction(
                    android.R.drawable.stat_sys_download,
                    "📥 Tải Bản Cập Nhật",
                    updatePendingIntent
                )
            }

            nm.notify(8899, builder.build())
        } catch (_: Throwable) {}
    }

    /**
     * Lắng nghe biến động cấu hình toàn cục VÀ trạng thái Cấp/Gỡ Pro từ xa của thiết bị này theo thời gian thực
     */
    fun listenToGlobalConfigChanges(context: Context) {
        val appCtx = context.applicationContext
        syncDevicePresenceToCloud(appCtx)
        _globalBroadcastFlow.value = getGlobalBroadcast(appCtx)

        try {
            val db = FirebaseFirestore.getInstance()
            // 1. Lắng nghe cấu hình hệ thống của Admin
            db.collection("app_config").document("global")
                .addSnapshotListener { snapshot, error ->
                    if (error != null || snapshot == null || !snapshot.exists()) return@addSnapshotListener
                    val price = snapshot.getString("pro_price")
                    val accountProPrice = snapshot.getString("account_pro_price")
                    val upgradeAccountProPrice = snapshot.getString("upgrade_account_pro_price")
                    val updateLink = snapshot.getString("custom_update_link")
                    val fbLink = snapshot.getString("custom_fb_link")
                    val isFreeMode = snapshot.getBoolean("is_app_free_mode")
                    val trialLimit = snapshot.getLong("free_trial_limit")?.toInt()
                    val autoFreeDays = snapshot.getLong(KEY_AUTO_FREE_DAYS)?.toInt()
                    val adminLastActiveTs = snapshot.getTimestamp(KEY_ADMIN_LAST_ACTIVE)
                    val adminLastActiveMs = snapshot.getLong("admin_last_active_ms")

                    val payBankName = snapshot.getString(KEY_PAYMENT_BANK_NAME)
                    val payBankCode = snapshot.getString(KEY_PAYMENT_BANK_CODE)
                    val payAccNum = snapshot.getString(KEY_PAYMENT_ACCOUNT_NUMBER)
                    val payAccHolder = snapshot.getString(KEY_PAYMENT_ACCOUNT_HOLDER)
                    val cloudGroqPool = snapshot.getString(KEY_GROQ_API_KEY_POOL)

                    // Thông báo toàn cầu từ Admin
                    val bcId = snapshot.getString(KEY_BROADCAST_ID) ?: ""
                    val bcTitle = snapshot.getString(KEY_BROADCAST_TITLE) ?: ""
                    val bcMsg = snapshot.getString(KEY_BROADCAST_MESSAGE) ?: ""
                    val bcType = snapshot.getString(KEY_BROADCAST_TYPE) ?: "UPDATE"
                    val bcActive = snapshot.getBoolean(KEY_BROADCAST_ACTIVE) ?: false
                    val bcUrl = snapshot.getString(KEY_BROADCAST_URL) ?: (updateLink ?: getUpdateLink(appCtx))
                    val bcSentAt = (snapshot.get(KEY_BROADCAST_SENT_AT) as? Number)?.toLong() ?: 0L

                    val prefs = appCtx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                    val editor = prefs.edit()
                    var changed = false
                    if (!price.isNullOrBlank()) {
                        putSecureConfigString(appCtx, "pro_price", price)
                        if (price != prefs.getString("pro_price", null)) {
                            editor.putString("pro_price", price)
                            changed = true
                        }
                    }
                    if (!accountProPrice.isNullOrBlank()) {
                        putSecureConfigString(appCtx, "account_pro_price", accountProPrice)
                        if (accountProPrice != prefs.getString("account_pro_price", null)) {
                            editor.putString("account_pro_price", accountProPrice)
                            changed = true
                        }
                    }
                    if (!upgradeAccountProPrice.isNullOrBlank()) {
                        putSecureConfigString(appCtx, "upgrade_account_pro_price", upgradeAccountProPrice)
                        if (upgradeAccountProPrice != prefs.getString("upgrade_account_pro_price", null)) {
                            editor.putString("upgrade_account_pro_price", upgradeAccountProPrice)
                            changed = true
                        }
                    }
                    if (!updateLink.isNullOrBlank()) {
                        putSecureConfigString(appCtx, "custom_update_link", updateLink)
                        if (updateLink != prefs.getString("custom_update_link", null)) {
                            editor.putString("custom_update_link", updateLink)
                            changed = true
                        }
                    }
                    if (!fbLink.isNullOrBlank()) {
                        putSecureConfigString(appCtx, "custom_fb_link", fbLink)
                        if (fbLink != prefs.getString("custom_fb_link", null)) {
                            editor.putString("custom_fb_link", fbLink)
                            changed = true
                        }
                    }
                    if (isFreeMode != null) {
                        val freeSeal = computeGlobalConfigSeal("FREE_MODE_GLOBAL", isFreeMode.toString())
                        editor.putString(KEY_FREE_MODE_CRYPTO_SEAL, freeSeal)
                        putSecureConfigString(appCtx, "is_app_free_mode", isFreeMode.toString())
                        if (isFreeMode != prefs.getBoolean("is_app_free_mode", false)) {
                            editor.putBoolean("is_app_free_mode", isFreeMode)
                            changed = true
                        }
                    }
                    if (autoFreeDays != null && autoFreeDays > 0) {
                        editor.putInt(KEY_AUTO_FREE_DAYS, autoFreeDays)
                        putSecureConfigString(appCtx, KEY_AUTO_FREE_DAYS, autoFreeDays.toString())
                    }
                    val effectiveAdminMs = adminLastActiveMs ?: adminLastActiveTs?.toDate()?.time
                    if (effectiveAdminMs != null && effectiveAdminMs > 0L) {
                        editor.putLong(KEY_ADMIN_LAST_ACTIVE, effectiveAdminMs)
                    }
                    if (trialLimit != null) {
                        val limitSeal = computeGlobalConfigSeal("TRIAL_LIMIT_GLOBAL", trialLimit.toString())
                        editor.putString(KEY_TRIAL_LIMIT_CRYPTO_SEAL, limitSeal)
                        putSecureConfigString(appCtx, "free_trial_limit", trialLimit.toString())
                        if (trialLimit != prefs.getInt("free_trial_limit", 5)) {
                            editor.putInt("free_trial_limit", trialLimit)
                            changed = true
                        }
                    }

                    if (!payBankName.isNullOrBlank()) {
                        putSecureConfigString(appCtx, KEY_PAYMENT_BANK_NAME, payBankName)
                        if (payBankName != prefs.getString(KEY_PAYMENT_BANK_NAME, null)) {
                            editor.putString(KEY_PAYMENT_BANK_NAME, payBankName)
                            changed = true
                        }
                    }
                    if (!payBankCode.isNullOrBlank()) {
                        putSecureConfigString(appCtx, KEY_PAYMENT_BANK_CODE, payBankCode)
                        if (payBankCode != prefs.getString(KEY_PAYMENT_BANK_CODE, null)) {
                            editor.putString(KEY_PAYMENT_BANK_CODE, payBankCode)
                            changed = true
                        }
                    }
                    if (!payAccNum.isNullOrBlank()) {
                        putSecureConfigString(appCtx, KEY_PAYMENT_ACCOUNT_NUMBER, payAccNum)
                        if (payAccNum != prefs.getString(KEY_PAYMENT_ACCOUNT_NUMBER, null)) {
                            editor.putString(KEY_PAYMENT_ACCOUNT_NUMBER, payAccNum)
                            changed = true
                        }
                    }
                    if (!payAccHolder.isNullOrBlank()) {
                        putSecureConfigString(appCtx, KEY_PAYMENT_ACCOUNT_HOLDER, payAccHolder)
                        if (payAccHolder != prefs.getString(KEY_PAYMENT_ACCOUNT_HOLDER, null)) {
                            editor.putString(KEY_PAYMENT_ACCOUNT_HOLDER, payAccHolder)
                            changed = true
                        }
                    }
                    if (!cloudGroqPool.isNullOrBlank()) {
                        putSecureConfigString(appCtx, KEY_GROQ_API_KEY_POOL, cloudGroqPool.trim())
                        if (cloudGroqPool.trim() != prefs.getString(KEY_GROQ_API_KEY_POOL, null)) {
                            editor.putString(KEY_GROQ_API_KEY_POOL, cloudGroqPool.trim())
                            changed = true
                        }
                    }

                    // Cập nhật dữ liệu thông báo toàn cầu
                    editor.putString(KEY_BROADCAST_ID, bcId)
                    editor.putString(KEY_BROADCAST_TITLE, bcTitle)
                    editor.putString(KEY_BROADCAST_MESSAGE, bcMsg)
                    editor.putString(KEY_BROADCAST_TYPE, bcType)
                    editor.putBoolean(KEY_BROADCAST_ACTIVE, bcActive)
                    editor.putString(KEY_BROADCAST_URL, bcUrl)
                    editor.putLong(KEY_BROADCAST_SENT_AT, bcSentAt)

                    if (bcActive && (bcTitle.isNotBlank() || bcMsg.isNotBlank())) {
                        val broadcastObj = GlobalBroadcastMessage(
                            id = bcId,
                            title = bcTitle,
                            message = bcMsg,
                            type = bcType,
                            isActive = true,
                            actionUrl = bcUrl,
                            sentAtMs = bcSentAt
                        )
                        _globalBroadcastFlow.value = broadcastObj

                        val lastNotifiedId = prefs.getString(KEY_NOTIFIED_BROADCAST_ID, "") ?: ""
                        if (bcId.isNotBlank() && bcId != lastNotifiedId) {
                            editor.putString(KEY_NOTIFIED_BROADCAST_ID, bcId)
                            showSystemBroadcastNotification(appCtx, broadcastObj)
                        }
                    } else {
                        _globalBroadcastFlow.value = null
                    }

                    editor.apply()
                    if (changed) {
                        notifyProAndConfigStateChanged(appCtx)
                    }
                }

            // 2. Lắng nghe toàn bộ bảng `devices` (không cần index, khớp mọi biến thể ID như MT-XXXX hoặc XXXX)
            // để Admin CẤP PRO / GỠ PRO từ xa hoặc nhận diện Máy Vãng Lai (chưa đăng nhập) khi cài lại app tức thì!
            val deviceId = getDeviceId(appCtx)
            val normId = normalizeDeviceIdForMatch(deviceId)
            db.collection("devices")
                .addSnapshotListener { snap, error ->
                    if (error != null || snap == null) return@addSnapshotListener
                    for (snapshot in snap.documents) {
                        val docDevId = snapshot.getString("deviceId") ?: snapshot.id
                        if (normalizeDeviceIdForMatch(docDevId) != normId) continue

                        val hasExplicitIsPro = snapshot.contains("isPro") && snapshot.get("isPro") is Boolean
                        val cloudIsPro = snapshot.getBoolean("isPro") ?: false
                        val isExplicitlyNotPro = hasExplicitIsPro && !cloudIsPro
                        val cloudIsAccountPro = (snapshot.getBoolean("isAccountPro") ?: false) || (snapshot.getString("proTier") == "ACCOUNT_PRO")
                        val cloudUpgradedToAcc = snapshot.getBoolean("upgradedToAccountPro") ?: false
                        val revokedByAdmin = snapshot.getBoolean("revokedByAdmin") ?: false
                        val savedKey = (snapshot.getString("licenseKey") ?: "").trim()
                        val cleanSavedKey = savedKey.replace("-", "").trim().uppercase()
                        val expectedDevKeyClean = generateLicenseKeyForDevice(deviceId).replace("-", "").trim().uppercase()
                        val expectedAccKeyClean = generateAccountProLicenseKeyForDevice(deviceId).replace("-", "").trim().uppercase()
                        val hasValidCryptographicKey = cleanSavedKey.length >= 16 &&
                            (cleanSavedKey == expectedDevKeyClean || cleanSavedKey == expectedAccKeyClean)

                        val prefs = appCtx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                        val localPro = prefs.getBoolean(KEY_PRO_ACTIVATED, false)
                        val localAccPro = prefs.getBoolean(KEY_ACCOUNT_PRO_ACTIVATED, false)

                        if (cloudUpgradedToAcc) {
                            prefs.edit().putBoolean(KEY_UPGRADED_TO_ACCOUNT_PRO, true).apply()
                        }

                        if (revokedByAdmin) {
                            if (localPro || localAccPro || !prefs.getBoolean(KEY_REVOKED_BY_ADMIN, false)) {
                                prefs.edit()
                                    .putBoolean(KEY_PRO_ACTIVATED, false)
                                    .putBoolean(KEY_ACCOUNT_PRO_ACTIVATED, false)
                                    .putBoolean(KEY_REVOKED_BY_ADMIN, true)
                                    .remove(KEY_ACTIVATED_LICENSE)
                                    .remove(KEY_PRO_CRYPTO_SEAL)
                                    .apply()
                                notifyProAndConfigStateChanged(appCtx)
                            }
                            break
                        } else if (!isExplicitlyNotPro && (cloudIsPro || hasValidCryptographicKey)) {
                            if (!localPro || (cloudIsAccountPro && !localAccPro)) {
                                RestoreFamiliarProHelper.applyRestoredProState(
                                    context = appCtx,
                                    deviceId = deviceId,
                                    isAccountTier = cloudIsAccountPro || cloudUpgradedToAcc,
                                    licenseKey = savedKey.ifBlank { if (cloudIsAccountPro) "ADMIN_ACCOUNT_PRO_GRANTED" else "ADMIN_CLOUD_GRANTED" },
                                    recognizedEmail = snapshot.getString("ownerEmail") ?: "",
                                    recognizedRole = ""
                                )
                            }
                            break
                        }
                    }
                }

            // 3. Lắng nghe bảng `users` (Danh sách Tài Khoản Pro trong trang Quản Trị) để tự động nhận ra thiết bị nằm trong danh sách Tài Khoản Pro
            db.collection("users")
                .addSnapshotListener { snap, err ->
                    if (err != null || snap == null) return@addSnapshotListener
                    val currentModel = "${Build.MANUFACTURER} ${Build.MODEL}".trim()
                    for (uDoc in snap.documents) {
                        val uRevoked = uDoc.getBoolean("revokedByAdmin") == true
                        val uRole = (uDoc.getString("role") ?: "user").trim()
                        val uEmail = (uDoc.getString("email") ?: "").trim()
                        val uIsAccPro = (uDoc.getBoolean("isAccountPro") == true) ||
                            (uDoc.getString("proTier") == "ACCOUNT_PRO") ||
                            uRole.equals("admin", ignoreCase = true) ||
                            uEmail.equals("vuongdhkmhn@gmail.com", ignoreCase = true)
                        val uIsPro = (uDoc.getBoolean("isPro") == true) || uIsAccPro
                        val uDevId = normalizeDeviceIdForMatch(uDoc.getString("deviceId") ?: "")
                        val uActId = normalizeDeviceIdForMatch(uDoc.getString("activeDeviceId") ?: "")
                        val uModel = (uDoc.getString("activeDeviceModel") ?: "").trim()

                        val isThisDeviceInProAccount = (uActId.isNotBlank() && uActId == normId) ||
                            (uDevId.isNotBlank() && uDevId == normId && (uActId.isBlank() || uActId == normId)) ||
                            (uModel.equals(currentModel, ignoreCase = true) && uRole.equals("admin", ignoreCase = true))

                        if (isThisDeviceInProAccount && uIsPro && !uRevoked) {
                            val prefs = appCtx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                            val localPro = prefs.getBoolean(KEY_PRO_ACTIVATED, false)
                            val localAccPro = prefs.getBoolean(KEY_ACCOUNT_PRO_ACTIVATED, false)
                            if (!localPro || (uIsAccPro && !localAccPro)) {
                                RestoreFamiliarProHelper.applyRestoredProState(
                                    context = appCtx,
                                    deviceId = deviceId,
                                    isAccountTier = uIsAccPro,
                                    licenseKey = if (uIsAccPro) generateAccountProLicenseKeyForDevice(deviceId) else generateLicenseKeyForDevice(deviceId),
                                    recognizedEmail = uEmail,
                                    recognizedRole = uRole
                                )
                            }
                            break
                        }
                    }
                }
        } catch (_: Exception) {}
    }

    /**
     * Tải trực tiếp cấu hình toàn cục từ Firestore `app_config/global` ngay khi mở trang Quản Trị
     * để đảm bảo các ô nhập giá bán Pro, ngân hàng, link hỗ trợ luôn hiển thị đúng giá trị Admin đã tùy chỉnh.
     */
    fun fetchGlobalConfigNow(context: Context, onLoaded: (() -> Unit)? = null) {
        val appCtx = context.applicationContext
        try {
            FirebaseFirestore.getInstance().collection("app_config").document("global")
                .get(com.google.firebase.firestore.Source.SERVER)
                .addOnSuccessListener { snapshot ->
                    if (snapshot != null && snapshot.exists()) {
                        val prefs = appCtx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                        val editor = prefs.edit()

                        snapshot.getString("pro_price")?.takeIf { it.isNotBlank() }?.let {
                            editor.putString("pro_price", it)
                            putSecureConfigString(appCtx, "pro_price", it)
                        }
                        snapshot.getString("account_pro_price")?.takeIf { it.isNotBlank() }?.let {
                            editor.putString("account_pro_price", it)
                            putSecureConfigString(appCtx, "account_pro_price", it)
                        }
                        snapshot.getString("upgrade_account_pro_price")?.takeIf { it.isNotBlank() }?.let {
                            editor.putString("upgrade_account_pro_price", it)
                            putSecureConfigString(appCtx, "upgrade_account_pro_price", it)
                        }
                        snapshot.getString("custom_update_link")?.takeIf { it.isNotBlank() }?.let {
                            editor.putString("custom_update_link", it)
                            putSecureConfigString(appCtx, "custom_update_link", it)
                        }
                        snapshot.getString("custom_fb_link")?.takeIf { it.isNotBlank() }?.let {
                            editor.putString("custom_fb_link", it)
                            putSecureConfigString(appCtx, "custom_fb_link", it)
                        }
                        snapshot.getBoolean("is_app_free_mode")?.let {
                            val freeSeal = computeGlobalConfigSeal("FREE_MODE_GLOBAL", it.toString())
                            editor.putBoolean("is_app_free_mode", it)
                            editor.putString(KEY_FREE_MODE_CRYPTO_SEAL, freeSeal)
                            putSecureConfigString(appCtx, "is_app_free_mode", it.toString())
                        }
                        snapshot.getLong("free_trial_limit")?.toInt()?.let {
                            val limitSeal = computeGlobalConfigSeal("TRIAL_LIMIT_GLOBAL", it.toString())
                            editor.putInt("free_trial_limit", it)
                            editor.putString(KEY_TRIAL_LIMIT_CRYPTO_SEAL, limitSeal)
                            putSecureConfigString(appCtx, "free_trial_limit", it.toString())
                        }
                        snapshot.getString(KEY_PAYMENT_BANK_NAME)?.takeIf { it.isNotBlank() }?.let {
                            editor.putString(KEY_PAYMENT_BANK_NAME, it)
                            putSecureConfigString(appCtx, KEY_PAYMENT_BANK_NAME, it)
                        }
                        snapshot.getString(KEY_PAYMENT_BANK_CODE)?.takeIf { it.isNotBlank() }?.let {
                            editor.putString(KEY_PAYMENT_BANK_CODE, it)
                            putSecureConfigString(appCtx, KEY_PAYMENT_BANK_CODE, it)
                        }
                        snapshot.getString(KEY_PAYMENT_ACCOUNT_NUMBER)?.takeIf { it.isNotBlank() }?.let {
                            editor.putString(KEY_PAYMENT_ACCOUNT_NUMBER, it)
                            putSecureConfigString(appCtx, KEY_PAYMENT_ACCOUNT_NUMBER, it)
                        }
                        snapshot.getString(KEY_PAYMENT_ACCOUNT_HOLDER)?.takeIf { it.isNotBlank() }?.let {
                            editor.putString(KEY_PAYMENT_ACCOUNT_HOLDER, it)
                            putSecureConfigString(appCtx, KEY_PAYMENT_ACCOUNT_HOLDER, it)
                        }
                        snapshot.getBoolean(KEY_AUTO_APPROVE_NOTIFICATION_PAYMENT)?.let {
                            editor.putBoolean(KEY_AUTO_APPROVE_NOTIFICATION_PAYMENT, it)
                            putSecureConfigString(appCtx, KEY_AUTO_APPROVE_NOTIFICATION_PAYMENT, it.toString())
                        }
                        snapshot.getLong(KEY_AUTO_FREE_DAYS)?.toInt()?.takeIf { it > 0 }?.let {
                            editor.putInt(KEY_AUTO_FREE_DAYS, it)
                            putSecureConfigString(appCtx, KEY_AUTO_FREE_DAYS, it.toString())
                        }
                        val adminLastActiveTs = snapshot.getTimestamp(KEY_ADMIN_LAST_ACTIVE)
                        val adminLastActiveMs = snapshot.getLong("admin_last_active_ms")
                        val effectiveAdminMs = adminLastActiveMs ?: adminLastActiveTs?.toDate()?.time
                        if (effectiveAdminMs != null && effectiveAdminMs > 0L) {
                            editor.putLong(KEY_ADMIN_LAST_ACTIVE, effectiveAdminMs)
                        }
                        snapshot.getString(KEY_GROQ_API_KEY_POOL)?.takeIf { it.isNotBlank() }?.let {
                            editor.putString(KEY_GROQ_API_KEY_POOL, it.trim())
                            putSecureConfigString(appCtx, KEY_GROQ_API_KEY_POOL, it.trim())
                        }
                        editor.commit()
                        notifyProAndConfigStateChanged(appCtx)
                    }
                    onLoaded?.invoke()
                }
                .addOnFailureListener {
                    kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
                        try {
                            val globalMap = FirestoreRestTokenBridge.fetchDocMapViaRest(appCtx, "app_config", "global")
                            if (globalMap != null && globalMap.isNotEmpty()) {
                                val prefs = appCtx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                                val editor = prefs.edit()
                                (globalMap["pro_price"] as? String)?.takeIf { it.isNotBlank() }?.let {
                                    editor.putString("pro_price", it)
                                    putSecureConfigString(appCtx, "pro_price", it)
                                }
                                (globalMap["account_pro_price"] as? String)?.takeIf { it.isNotBlank() }?.let {
                                    editor.putString("account_pro_price", it)
                                    putSecureConfigString(appCtx, "account_pro_price", it)
                                }
                                (globalMap["upgrade_account_pro_price"] as? String)?.takeIf { it.isNotBlank() }?.let {
                                    editor.putString("upgrade_account_pro_price", it)
                                    putSecureConfigString(appCtx, "upgrade_account_pro_price", it)
                                }
                                (globalMap["custom_update_link"] as? String)?.takeIf { it.isNotBlank() }?.let {
                                    editor.putString("custom_update_link", it)
                                    putSecureConfigString(appCtx, "custom_update_link", it)
                                }
                                (globalMap["custom_fb_link"] as? String)?.takeIf { it.isNotBlank() }?.let {
                                    editor.putString("custom_fb_link", it)
                                    putSecureConfigString(appCtx, "custom_fb_link", it)
                                }
                                (globalMap["is_app_free_mode"] as? Boolean)?.let {
                                    val freeSeal = computeGlobalConfigSeal("FREE_MODE_GLOBAL", it.toString())
                                    editor.putBoolean("is_app_free_mode", it)
                                    editor.putString(KEY_FREE_MODE_CRYPTO_SEAL, freeSeal)
                                    putSecureConfigString(appCtx, "is_app_free_mode", it.toString())
                                }
                                (globalMap["free_trial_limit"] as? Number)?.toInt()?.let {
                                    val limitSeal = computeGlobalConfigSeal("TRIAL_LIMIT_GLOBAL", it.toString())
                                    editor.putInt("free_trial_limit", it)
                                    editor.putString(KEY_TRIAL_LIMIT_CRYPTO_SEAL, limitSeal)
                                    putSecureConfigString(appCtx, "free_trial_limit", it.toString())
                                }
                                (globalMap[KEY_PAYMENT_BANK_NAME] as? String)?.takeIf { it.isNotBlank() }?.let {
                                    editor.putString(KEY_PAYMENT_BANK_NAME, it)
                                    putSecureConfigString(appCtx, KEY_PAYMENT_BANK_NAME, it)
                                }
                                (globalMap[KEY_PAYMENT_BANK_CODE] as? String)?.takeIf { it.isNotBlank() }?.let {
                                    editor.putString(KEY_PAYMENT_BANK_CODE, it)
                                    putSecureConfigString(appCtx, KEY_PAYMENT_BANK_CODE, it)
                                }
                                (globalMap[KEY_PAYMENT_ACCOUNT_NUMBER] as? String)?.takeIf { it.isNotBlank() }?.let {
                                    editor.putString(KEY_PAYMENT_ACCOUNT_NUMBER, it)
                                    putSecureConfigString(appCtx, KEY_PAYMENT_ACCOUNT_NUMBER, it)
                                }
                                (globalMap[KEY_PAYMENT_ACCOUNT_HOLDER] as? String)?.takeIf { it.isNotBlank() }?.let {
                                    editor.putString(KEY_PAYMENT_ACCOUNT_HOLDER, it)
                                    putSecureConfigString(appCtx, KEY_PAYMENT_ACCOUNT_HOLDER, it)
                                }
                                (globalMap[KEY_AUTO_APPROVE_NOTIFICATION_PAYMENT] as? Boolean)?.let {
                                    editor.putBoolean(KEY_AUTO_APPROVE_NOTIFICATION_PAYMENT, it)
                                    putSecureConfigString(appCtx, KEY_AUTO_APPROVE_NOTIFICATION_PAYMENT, it.toString())
                                }
                                (globalMap[KEY_AUTO_FREE_DAYS] as? Number)?.toInt()?.takeIf { it > 0 }?.let {
                                    editor.putInt(KEY_AUTO_FREE_DAYS, it)
                                    putSecureConfigString(appCtx, KEY_AUTO_FREE_DAYS, it.toString())
                                }
                                (globalMap["admin_last_active_ms"] as? Number)?.toLong()?.takeIf { it > 0L }?.let {
                                    editor.putLong(KEY_ADMIN_LAST_ACTIVE, it)
                                }
                                (globalMap[KEY_GROQ_API_KEY_POOL] as? String)?.takeIf { it.isNotBlank() }?.let {
                                    editor.putString(KEY_GROQ_API_KEY_POOL, it.trim())
                                    putSecureConfigString(appCtx, KEY_GROQ_API_KEY_POOL, it.trim())
                                }
                                editor.commit()
                                notifyProAndConfigStateChanged(appCtx)
                            }
                        } catch (_: Exception) {}
                        withContext(Dispatchers.Main) {
                            onLoaded?.invoke()
                        }
                    }
                }
        } catch (_: Exception) {
            onLoaded?.invoke()
        }
    }
    private fun applyCloudProRecordToLocal(
        context: Context,
        d: com.google.firebase.firestore.DocumentSnapshot,
        currentDeviceId: String
    ): Boolean {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val dRevoked = d.getBoolean("revokedByAdmin") == true
        if (dRevoked) return false

        val hasExplicitIsProField = d.contains("isPro") && d.get("isPro") is Boolean
        val cloudPro = d.getBoolean("isPro") == true
        val isExplicitlyNotPro = hasExplicitIsProField && !cloudPro

        val cloudAccountPro = (d.getBoolean("isAccountPro") == true) || (d.getString("proTier") == "ACCOUNT_PRO")
        val cloudUpgradedToAcc = d.getBoolean("upgradedToAccountPro") == true
        val savedLicenseKey = (d.getString("licenseKey") ?: "").trim()
        val cleanSavedKey = savedLicenseKey.replace("-", "").trim().uppercase()
        val expectedDevKeyClean = generateLicenseKeyForDevice(currentDeviceId).replace("-", "").trim().uppercase()
        val expectedAccKeyClean = generateAccountProLicenseKeyForDevice(currentDeviceId).replace("-", "").trim().uppercase()
        val hasValidCryptographicKey = cleanSavedKey.length >= 16 &&
            (cleanSavedKey == expectedDevKeyClean || cleanSavedKey == expectedAccKeyClean)

        val ownerEmail = (d.getString("ownerEmail") ?: "").trim()
        val cloudTrialUsed = d.getLong("freeTrialUsed")?.toInt() ?: 0
        if (cloudTrialUsed > getUsedFreeTrials(context)) {
            prefs.edit().putInt("free_trial_count_used", cloudTrialUsed).apply()
        }
        if (ownerEmail.contains("@") && !ownerEmail.contains(" ")) {
            prefs.edit().putString("last_familiar_email", ownerEmail.lowercase()).apply()
        }

        if (isExplicitlyNotPro) {
            return false
        }

        val hasMagicTuneProductSign = d.getString("appId")?.equals("magictune", ignoreCase = true) == true ||
            d.getString("product")?.contains("MAGICTUNE", ignoreCase = true) == true ||
            d.getBoolean("magictunePro") == true

        // BẢO VỆ CHỐNG DÙNG CHÙA TỪ WEBSITE / APP KHÁC DÙNG CHUNG FIREBASE:
        val wasPreviouslyVerifiedPro = hasValidCryptographicKey || (cloudPro && hasMagicTuneProductSign)

        if (wasPreviouslyVerifiedPro) {
            RestoreFamiliarProHelper.applyRestoredProState(
                context = context,
                deviceId = currentDeviceId,
                isAccountTier = cloudAccountPro || cloudUpgradedToAcc,
                licenseKey = savedLicenseKey.ifBlank { if (cloudAccountPro) "CLOUD_ACCOUNT_PRO_RESTORED" else "CLOUD_DEVICE_PRO_RESTORED" },
                recognizedEmail = ownerEmail,
                recognizedRole = ""
            )
            return true
        }
        return false
    }

    /**
     * Tính năng AI phân tích hàng loạt toàn bộ lỗi lệnh ADB và đưa ra những chỗ cần sửa gấp.
     * Sử dụng ưu tiên Gemini 2.5 Flash / Flash Lite (qua Pool API Key), tự động fallback sang Groq Llama 3.3 70B / 8B.
     */
    suspend fun analyzeAdbErrorLogsWithAi(
        context: Context,
        errorLogs: List<AdminAdbErrorLogRecord>
    ): String = withContext(Dispatchers.IO) {
        if (errorLogs.isEmpty()) {
            return@withContext "🎉 Hệ thống hiện tại không có lỗi ADB nào được ghi nhận! Mọi lệnh Shizuku và Wireless ADB đang hoạt động hoàn hảo."
        }

        val topErrors = errorLogs.sortedByDescending { it.occurrenceCount }.take(35)
        val sb = StringBuilder()
        sb.append("Tổng số loại lỗi ADB: ${errorLogs.size} lỗi (Tổng lượt gặp: ${errorLogs.sumOf { it.occurrenceCount }} lượt)\n\n")
        topErrors.forEachIndexed { idx, item ->
            sb.append("=== LỖI #${idx + 1} ===\n")
            sb.append("- Lệnh ADB: `${item.command}`\n")
            sb.append("- Mã lỗi (ExitCode): ${item.exitCode}\n")
            sb.append("- Xuất lỗi: ${item.errorOutput.take(300)}\n")
            sb.append("- Số lượt gặp: ${item.occurrenceCount} lượt\n")
            sb.append("- Phương thức: ${item.connectionMode.ifBlank { "ADB" }}\n")
            val devicesStr = (item.affectedDevices + listOf(item.commercialName.ifBlank { item.deviceModel }))
                .filter { it.isNotBlank() }.distinct().take(5).joinToString(", ")
            sb.append("- Thiết bị bị ảnh hưởng: ${devicesStr.ifBlank { "Không rõ" }}\n\n")
        }

        val prompt = """
Bạn là Kỹ sư Trưởng Hệ thống Android & Chuyên gia Tối ưu hóa ADB Shell (Senior Android System & ADB Engineer).
Dưới đây là danh sách lỗi lệnh ADB tự động thu thập từ các thiết bị người dùng thực tế đang sử dụng ứng dụng MagicTune (chủ yếu là các dòng máy Honor MagicOS, Huawei, Xiaomi, Android 11-15):

$sb

Hãy phân tích hàng loạt toàn bộ dữ liệu lỗi trên và đưa ra BÁO CÁO CHẨN ĐOÁN CẤP BÁCH với định dạng Markdown chuyên nghiệp:

1. 🔴 NHỮNG CHỖ CẦN SỬA GẤP NHẤT (Top 3-5 lỗi có tần suất cao hoặc nguy cơ lỗi nghiêm trọng):
- Nêu rõ lệnh bị lỗi, nguyên nhân gốc rễ (Root Cause) vì sao gãy trên MagicOS/Android (do thiếu quyền WRITE_SECURE_SETTINGS, do package hệ thống không tồn tại, cú pháp sai, Shizuku chưa kết nối...).
- Vị trí tính năng trên app có khả năng đang gọi lệnh này.

2. 🛠️ GIẢI PHÁP & CODE FIX KHẮC PHỤC NGAY:
- Đưa ra câu lệnh ADB thay thế an toàn hơn hoặc cơ chế try-catch, kiểm tra điều kiện trước khi thực thi (pre-flight check).
- Gợi ý cách xử lý fallback nếu máy người dùng không hỗ trợ tính năng đó.

3. 📊 PHÂN BỔ NGUYÊN NHÂN CHÍNH:
- Nhóm lỗi do người dùng (chưa bật USB Debugging, chưa cấp quyền Shizuku): ...%
- Nhóm lỗi do MagicOS/Android chặn quyền hệ thống: ...%
- Nhóm lỗi do cú pháp lệnh code cần sửa: ...%

4. 💡 KHUYẾN NGHỊ HÀNH ĐỘNG CHO ADMIN:
- Những chỗ nào cần cập nhật mã nguồn ngay trong phiên bản tiếp theo.
- Cần bổ sung hướng dẫn gì trên giao diện cho người dùng để hạn chế lỗi.
""".trimIndent()

        // 1. Thử gọi Google Gemini API trước (với danh sách model chính thức v1beta)
        val geminiKey = getLoadBalancedGeminiApiKey(context)
        if (geminiKey.isNotBlank()) {
            val geminiModels = listOf(
                "gemini-2.0-flash",
                "gemini-1.5-flash",
                "gemini-2.5-flash",
                "gemini-2.0-flash-lite",
                "gemini-1.5-flash-8b"
            )
            for (model in geminiModels) {
                try {
                    val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$geminiKey")
                    val conn = (url.openConnection() as HttpURLConnection).apply {
                        requestMethod = "POST"
                        connectTimeout = 12_000
                        readTimeout = 40_000
                        doOutput = true
                        setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    }
                    val body = org.json.JSONObject().apply {
                        put("contents", org.json.JSONArray().apply {
                            put(org.json.JSONObject().apply {
                                put("parts", org.json.JSONArray().apply {
                                    put(org.json.JSONObject().apply {
                                        put("text", prompt)
                                    })
                                })
                            })
                        })
                    }
                    conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                    if (conn.responseCode in 200..299) {
                        val respStr = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                        val json = org.json.JSONObject(respStr)
                        val text = json.optJSONArray("candidates")
                            ?.optJSONObject(0)
                            ?.optJSONObject("content")
                            ?.optJSONArray("parts")
                            ?.optJSONObject(0)
                            ?.optString("text", "")
                            .orEmpty()
                        if (text.isNotBlank()) {
                            return@withContext text
                        }
                    } else if (conn.responseCode == 429 || conn.responseCode == 402 || conn.responseCode == 403) {
                        markGeminiApiKeyCooldown(geminiKey, 180_000L)
                    }
                } catch (_: Throwable) {}
            }
        }

        // 2. Fallback sang Groq API (Qwen 3.8 / Llama 3.3 70B / 8B)
        val groqKey = getLoadBalancedGroqApiKey(context).ifBlank {
            try { com.example.BuildConfig.GROQ_API_KEY } catch (_: Throwable) { "" }
        }
        if (groqKey.isNotBlank() && groqKey != "GROQ_API_KEY_DEFAULT_VALUE") {
            val groqModels = listOf("llama-3.3-70b-versatile", "qwen/qwen3.8-27b", "llama-3.1-8b-instant")
            for (gModel in groqModels) {
                try {
                    val url = URL("https://api.groq.com/openai/v1/chat/completions")
                    val conn = (url.openConnection() as HttpURLConnection).apply {
                        requestMethod = "POST"
                        connectTimeout = 12_000
                        readTimeout = 40_000
                        doOutput = true
                        setRequestProperty("Authorization", "Bearer $groqKey")
                        setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    }
                    val body = org.json.JSONObject().apply {
                        put("model", gModel)
                        put("messages", org.json.JSONArray().apply {
                            put(org.json.JSONObject().apply {
                                put("role", "system")
                                put("content", "Bạn là Chuyên gia Kỹ thuật Hệ thống Android & ADB Shell.")
                            })
                            put(org.json.JSONObject().apply {
                                put("role", "user")
                                put("content", prompt)
                            })
                        })
                        put("temperature", 0.2)
                    }
                    conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                    if (conn.responseCode in 200..299) {
                        val respStr = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                        val json = org.json.JSONObject(respStr)
                        val text = json.optJSONArray("choices")
                            ?.optJSONObject(0)
                            ?.optJSONObject("message")
                            ?.optString("content", "")
                            .orEmpty()
                        if (text.isNotBlank()) {
                            return@withContext text
                        }
                    } else if (conn.responseCode == 429) {
                        markGroqApiKeyCooldown(groqKey)
                    }
                } catch (_: Throwable) {}
            }
        }

        // 3. TẦNG DỰ PHÒNG ZERO-COST VĨNH CỬU: Pollinations AI (Miễn phí 100%, không cần API Key - tương tự Gemini Live)
        try {
            val url = URL("https://text.pollinations.ai/")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 12_000
                readTimeout = 45_000
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 15; MagicTune)")
            }
            val payload = org.json.JSONObject().apply {
                put("messages", org.json.JSONArray().apply {
                    put(org.json.JSONObject().apply {
                        put("role", "system")
                        put("content", "Bạn là Kỹ sư Trưởng Hệ thống Android & ADB Shell.")
                    })
                    put(org.json.JSONObject().apply {
                        put("role", "user")
                        put("content", prompt)
                    })
                })
                put("model", "openai")
                put("code", "beesknees")
            }
            conn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
            if (conn.responseCode in 200..299) {
                val respStr = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                    .replace(Regex("<think>[\\s\\S]*?</think>"), "")
                    .trim()
                if (respStr.isNotBlank()) {
                    return@withContext respStr
                }
            }
        } catch (_: Throwable) {}

        return@withContext "⚠️ Không thể kết nối với dịch vụ AI để chẩn đoán. Vui lòng kiểm tra lại kết nối mạng hoặc thử lại sau giây lát."
    }
}
