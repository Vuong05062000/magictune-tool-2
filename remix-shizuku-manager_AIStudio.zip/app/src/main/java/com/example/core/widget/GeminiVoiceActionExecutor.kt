﻿package com.example.core.widget

import android.app.ActivityManager
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.util.Log
import android.widget.Toast
import android.provider.Settings
import com.example.MainActivity
import com.example.core.license.LicenseManager
import com.example.core.service.MagicTuneCtsAccessibilityService
import com.example.core.service.AutoWakeupPatrolManager
import com.example.core.shell.ShellEngine
import java.text.Normalizer
import java.util.Locale
import kotlin.math.roundToInt
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Bộ Thực Thi Lệnh Điều Khiển Điện Thoại Bằng Giọng Nói (GeminiVoiceActionExecutor).
 *
 * Cho phép người dùng ra lệnh bằng Tiếng Việt tự nhiên ngay trong khi đàm thoại rảnh tay với Gemini Live Nổi:
 * - Mở bất kỳ ứng dụng nào trên máy (Zalo, Facebook, TikTok, YouTube, Shopee, Taobao, 1688, Máy ảnh, Cài đặt, Bản đồ...).
 * - Tìm kiếm trực tiếp trên YouTube, Google, Bản đồ Google Maps.
 * - Thao tác giao diện trực tiếp: Cuộn xuống, Cuộn lên, Vuốt trái/phải, Quay lại, Về màn hình chính, Mở đa nhiệm,
 *   Kéo thanh thông báo, Chụp màn hình, Khóa màn hình, hoặc "Bấm vào [Tên nút bất kỳ trên màn hình]".
 * - Điều khiển phần cứng: Bật/Tắt đèn pin, Tăng/Giảm/Đặt mức âm lượng, Tăng/Giảm độ sáng, Bật/Tắt Wi-Fi, Bluetooth,
 *   Kích hoạt Khoanh Tròn Tìm Kiếm hoặc Dịch Cuộn Trực Tiếp.
 */
object GeminiVoiceActionExecutor {

    /**
     * Nhận diện tên thương mại chính thức của thiết bị (ví dụ: Honor Magic 6 Pro thay vì mã nội địa BVL-AN16).
     */
    /**
     * Lấy tên người dùng đang hiển thị trên ứng dụng MagicTune (từ FirebaseAuth hoặc bộ nhớ đệm tài khoản / SharedPreferences).
     */
    fun getUserDisplayName(context: Context? = null): String {
        return try {
            val u = com.google.firebase.auth.FirebaseAuth.getInstance().currentUser
            when {
                !u?.displayName.isNullOrBlank() -> u?.displayName!!.trim()
                !u?.email.isNullOrBlank() -> u?.email!!.substringBefore("@").trim()
                context != null -> {
                    val sp = context.getSharedPreferences("magictune_user_pref", Context.MODE_PRIVATE)
                    val cachedName = sp.getString("user_display_name", "")?.trim().orEmpty()
                    val cachedEmail = sp.getString("user_email", "")?.trim().orEmpty()
                    when {
                        cachedName.isNotBlank() -> cachedName
                        cachedEmail.isNotBlank() && cachedEmail.contains("@") -> cachedEmail.substringBefore("@")
                        else -> "bạn"
                    }
                }
                else -> "bạn"
            }
        } catch (_: Throwable) {
            "bạn"
        }
    }

    fun getCommercialDeviceName(context: Context? = null): String {
        val model = Build.MODEL.trim()
        val manufacturer = Build.MANUFACTURER.trim()

        val knownHonorModels = mapOf(
            "BVL-AN16" to "Honor Magic 6 Pro",
            "BVL-AN00" to "Honor Magic 6 Pro",
            "BVL-AN20" to "Honor Magic 6 Ultimate",
            "BVL-N49" to "Honor Magic 6 RSR Porsche Design",
            "PGT-AN10" to "Honor Magic 5 Pro",
            "PGT-AN00" to "Honor Magic 5 Pro",
            "PGT-AN20" to "Honor Magic 5 Ultimate",
            "FRI-AN00" to "Honor Magic 7",
            "FRI-AN10" to "Honor Magic 7 Pro",
            "VER-AN10" to "Honor Magic V2",
            "VER-AN00" to "Honor Magic V2",
            "FCP-AN10" to "Honor Magic V3",
            "FCP-AN00" to "Honor Magic V3",
            "ANY-AN00" to "Honor 50",
            "FNE-AN00" to "Honor 70",
            "REA-AN00" to "Honor 90",
            "REA-NX9" to "Honor 90",
            "MAG-AN00" to "Honor 100",
            "MAG-AN10" to "Honor 100 Pro",
            "AMP-AN00" to "Honor 200",
            "AMP-AN10" to "Honor 200 Pro",
            "BRN-AL00" to "Honor X9b",
            "ALI-NX1" to "Honor X9b",
            "CLK-AN00" to "Honor 90 Lite",
            "REA-AN10" to "Honor 90 Pro",
            "FLT-AN00" to "Honor 300",
            "FLT-AN10" to "Honor 300 Pro",
            "FRI-AN20" to "Honor Magic 7 RSR",
            "FCA-AN00" to "Honor Magic Vs3",
            "BKC-AN00" to "Honor Magic V Flip",
            "WKG-AN00" to "Honor X50"
        )

        for ((mKey, mName) in knownHonorModels) {
            if (model.equals(mKey, ignoreCase = true) || model.contains(mKey, ignoreCase = true)) {
                return mName
            }
        }

        val propMarketing = try {
            val clz = Class.forName("android.os.SystemProperties")
            val getMethod = clz.getMethod("get", String::class.java)
            val p1 = getMethod.invoke(null, "ro.config.marketing_name") as? String
            val p2 = getMethod.invoke(null, "ro.product.model.display") as? String
            val p3 = getMethod.invoke(null, "ro.product.vendor.marketname") as? String
            listOfNotNull(p1, p2, p3).firstOrNull { it.isNotBlank() }
        } catch (_: Throwable) {
            null
        }

        if (!propMarketing.isNullOrBlank()) {
            return propMarketing.trim()
        }

        return if (model.startsWith(manufacturer, ignoreCase = true)) {
            model
        } else {
            "$manufacturer $model".trim()
        }
    }

    fun readSystemProperty(key: String): String {
        return try {
            val clz = Class.forName("android.os.SystemProperties")
            val getMethod = clz.getMethod("get", String::class.java, String::class.java)
            (getMethod.invoke(null, key, "") as? String)?.trim().orEmpty()
        } catch (_: Throwable) { "" }
    }

    fun getSocMarketingName(): String {
        val rawSoc = try {
            val p1 = readSystemProperty("ro.soc.model")
            val p2 = readSystemProperty("ro.board.platform")
            val p3 = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) Build.SOC_MODEL else ""
            val p4 = Build.HARDWARE
            listOf(p1, p2, p3, p4).firstOrNull { !it.isNullOrBlank() }?.trim().orEmpty()
        } catch (_: Throwable) { "" }

        val lower = rawSoc.lowercase(Locale.ROOT)
        return when {
            lower.contains("sm8750") || lower.contains("sun") -> "Snapdragon 8 Elite"
            lower.contains("sm8650") || lower.contains("pineapple") -> "Snapdragon 8 Gen 3"
            lower.contains("sm8550") || lower.contains("kalama") -> "Snapdragon 8 Gen 2"
            lower.contains("sm8475") || lower.contains("cape") -> "Snapdragon 8+ Gen 1"
            lower.contains("sm8450") || lower.contains("taro") -> "Snapdragon 8 Gen 1"
            lower.contains("sm7550") || lower.contains("crow") -> "Snapdragon 7 Gen 3"
            lower.contains("sm7435") || lower.contains("parrot") -> "Snapdragon 6 Gen 1"
            lower.contains("mt6989") || lower.contains("k6989") -> "MediaTek Dimensity 9300"
            lower.contains("mt6985") -> "MediaTek Dimensity 9200"
            lower.contains("mt6897") -> "MediaTek Dimensity 8300"
            lower.contains("mt6877") -> "MediaTek Dimensity 900"
            rawSoc.isNotBlank() -> rawSoc
            else -> "Qualcomm Snapdragon / MediaTek Dimensity"
        }
    }

    fun getMagicOsVersion(): String {
        val propKeys = listOf("ro.build.version.magic", "ro.build.magic.version", "ro.honor.build.version.magic", "ro.build.version.emui")
        for (k in propKeys) {
            val v = readSystemProperty(k)
            if (v.isNotBlank()) {
                return if (v.startsWith("MagicOS", ignoreCase = true)) v else "MagicOS $v"
            }
        }
        return "MagicOS"
    }

    data class DeviceRealtimeInfo(
        val commercialName: String,
        val rawModel: String,
        val manufacturer: String,
        val soc: String,
        val magicOsVersion: String,
        val androidVersion: String,
        val sdkInt: Int,
        val batteryPct: Int,
        val isCharging: Boolean,
        val chargingWatt: Double,
        val chargingTitle: String,
        val batteryTempC: Double,
        val batteryVoltageV: Double,
        val ramAvailGb: Double,
        val ramTotalGb: Double,
        val ramUsedPct: Int,
        val romAvailGb: Double,
        val romTotalGb: Double,
        val romUsedPct: Int,
        val refreshRateHz: Int
    )

    fun getDeviceRealtimeInfo(context: Context): DeviceRealtimeInfo {
        val appCtx = context.applicationContext
        val commercialName = getCommercialDeviceName(appCtx)
        val rawModel = Build.MODEL.trim()
        val manufacturer = Build.MANUFACTURER.trim()
        val soc = getSocMarketingName()
        val magicOs = getMagicOsVersion()
        val androidVer = Build.VERSION.RELEASE
        val sdk = Build.VERSION.SDK_INT

        val chargeData = try {
            BatteryInfoReader.read(appCtx, null)
        } catch (_: Throwable) {
            BatteryChargeData(
                batteryPct = 85, voltageV = 4.2, currentWatts = 0.5,
                isCharging = false, speedTitle = "Đang dùng pin",
                minutesToFull = 0, isSlowCharge = false,
                phoneDisplayName = commercialName, estimatedUsageText = ""
            )
        }

        val batteryIntent = try {
            appCtx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        } catch (_: Throwable) { null }
        val tempTenths = batteryIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
        val tempC = if (tempTenths > 0) tempTenths / 10.0 else 32.5

        var ramTotal = 16.0
        var ramAvail = 8.0
        var ramPct = 50
        try {
            val am = appCtx.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            if (am != null) {
                val memInfo = ActivityManager.MemoryInfo()
                am.getMemoryInfo(memInfo)
                val t = memInfo.totalMem.toDouble() / (1024.0 * 1024.0 * 1024.0)
                val a = memInfo.availMem.toDouble() / (1024.0 * 1024.0 * 1024.0)
                if (t > 0) {
                    ramTotal = t
                    ramAvail = a
                    val used = (t - a).coerceAtLeast(0.0)
                    ramPct = ((used / t) * 100.0).roundToInt().coerceIn(0, 100)
                }
            }
        } catch (_: Throwable) {}

        var romTotal = 256.0
        var romAvail = 128.0
        var romPct = 50
        try {
            val stat = StatFs(Environment.getDataDirectory().path)
            val t = (stat.blockSizeLong * stat.blockCountLong).toDouble() / (1024.0 * 1024.0 * 1024.0)
            val a = (stat.blockSizeLong * stat.availableBlocksLong).toDouble() / (1024.0 * 1024.0 * 1024.0)
            if (t > 0) {
                romTotal = t
                romAvail = a
                val used = (t - a).coerceAtLeast(0.0)
                romPct = ((used / t) * 100.0).roundToInt().coerceIn(0, 100)
            }
        } catch (_: Throwable) {}

        val refreshRate = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                appCtx.display?.refreshRate?.roundToInt() ?: 120
            } else {
                @Suppress("DEPRECATION")
                (appCtx.getSystemService(Context.WINDOW_SERVICE) as? android.view.WindowManager)?.defaultDisplay?.refreshRate?.roundToInt() ?: 120
            }
        } catch (_: Throwable) { 120 }

        return DeviceRealtimeInfo(
            commercialName = commercialName,
            rawModel = rawModel,
            manufacturer = manufacturer,
            soc = soc,
            magicOsVersion = magicOs,
            androidVersion = androidVer,
            sdkInt = sdk,
            batteryPct = chargeData.batteryPct,
            isCharging = chargeData.isCharging,
            chargingWatt = chargeData.currentWatts,
            chargingTitle = chargeData.speedTitle,
            batteryTempC = tempC,
            batteryVoltageV = chargeData.voltageV,
            ramAvailGb = ramAvail,
            ramTotalGb = ramTotal,
            ramUsedPct = ramPct,
            romAvailGb = romAvail,
            romTotalGb = romTotal,
            romUsedPct = romPct,
            refreshRateHz = refreshRate
        )
    }

    fun buildDeviceContextForAi(context: Context): String {
        val d = getDeviceRealtimeInfo(context)
        val ramFreeStr = String.format(Locale.US, "%.1f", d.ramAvailGb)
        val ramTotalStr = String.format(Locale.US, "%.1f", d.ramTotalGb)
        val romFreeStr = String.format(Locale.US, "%.1f", d.romAvailGb)
        val romTotalStr = String.format(Locale.US, "%.0f", d.romTotalGb)
        val tempStr = String.format(Locale.US, "%.1f", d.batteryTempC)
        val chargeStatusStr = if (d.isCharging) {
            val wattStr = if (d.chargingWatt > 1.0) " (Công suất sạc thực tế: ~${d.chargingWatt.roundToInt()}W)" else ""
            "Đang sạc pin - ${d.chargingTitle}$wattStr"
        } else {
            "Đang dùng pin (không cắm sạc)"
        }

        return """
        [THÔNG TIN PHẦN CỨNG & HỆ THỐNG THỰC TẾ CHIẾC ĐIỆN THOẠI CỦA NGƯỜI DÙNG HIỆN TẠI]:
        - Tên dòng máy: ${d.commercialName} (Mã kỹ thuật: ${d.rawModel}, Hãng: ${d.manufacturer})
        - Vi xử lý (Chipset): ${d.soc}
        - Hệ điều hành & Giao diện: ${d.magicOsVersion} trên nền Android ${d.androidVersion} (API ${d.sdkInt})
        - Màn hình: Tần số quét thực tế ${d.refreshRateHz}Hz
        - Tình trạng Pin: ${d.batteryPct}% • $chargeStatusStr • Nhiệt độ pin: ${tempStr}°C (Điện áp: ${String.format(Locale.US, "%.2f", d.batteryVoltageV)}V)
        - Bộ nhớ RAM: Đang trống $ramFreeStr GB / Tổng $ramTotalStr GB (Đã dùng ${d.ramUsedPct}%)
        - Bộ nhớ lưu trữ máy (ROM): Còn trống $romFreeStr GB / Tổng $romTotalStr GB (Đã dùng ${d.romUsedPct}%)
        - Cẩm nang tính năng điện thoại: Thiết bị có thanh Sidebar vuốt giữ từ mép để mở ứng dụng dạng cửa sổ nổi Mini-Window, tính năng Magic Portal kéo thả, dịch cuộn Taobao/1688 xuyên thấu và Khoanh tròn tìm kiếm Circle to Search của MagicTune.
        """.trimIndent()
    }

    suspend fun optimizeDeviceMemory(context: Context) {
        try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            if (am != null) {
                val runningApps = am.runningAppProcesses ?: emptyList()
                val myPkg = context.packageName
                for (proc in runningApps) {
                    if (proc.pkgList != null) {
                        for (pkg in proc.pkgList) {
                            if (pkg != myPkg && !pkg.contains("systemui") && !pkg.contains("launcher") && !pkg.contains("hihonor") && !pkg.contains("huawei") && !pkg.contains("android")) {
                                try {
                                    am.killBackgroundProcesses(pkg)
                                } catch (_: Throwable) {}
                            }
                        }
                    }
                }
            }
            System.gc()
            val shell = ShellEngine.getInstance(context)
            if (shell.state.value.isAdbReady) {
                shell.execute("am trim-memory \$(am get-current-app) RUNNING_CRITICAL")
                shell.execute("cmd activity idle-maintenance")
            }
        } catch (_: Throwable) {}
    }

    suspend fun setBatterySaverMode(context: Context, enable: Boolean): Boolean {
        return try {
            val shell = ShellEngine.getInstance(context)
            val v = if (enable) "1" else "0"
            if (shell.state.value.isAdbReady) {
                shell.execute("settings put global low_power $v")
                true
            } else {
                val intent = Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)
                launchIntentSafely(context, intent)
            }
        } catch (_: Throwable) {
            false
        }
    }

    data class MediaSearchIntent(
        val searchQuery: String,
        val spokenConfirmation: String,
        val autoPlay: Boolean = true
    )


    data class VoiceCommandResult(
        val handled: Boolean,
        val spokenConfirmation: String,
        val shouldDismissOverlay: Boolean = false,
        val shouldMinimizeOrPauseListening: Boolean = false,
        val screenContextForAi: String? = null
    )

    private val knownAppAliases: Map<String, List<String>> = mapOf(
        "zalo" to listOf("com.zing.zalo"),
        "facebook" to listOf("com.facebook.katana", "com.facebook.lite"),
        "fb" to listOf("com.facebook.katana", "com.facebook.lite"),
        "messenger" to listOf("com.facebook.orca", "com.facebook.mlite"),
        "mess" to listOf("com.facebook.orca"),
        "tiktok" to listOf("com.ss.android.ugc.trill", "com.zhiliaoapp.musically", "com.ss.android.ugc.aweme"),
        "tik tok" to listOf("com.ss.android.ugc.trill", "com.zhiliaoapp.musically", "com.ss.android.ugc.aweme"),
        "youtube" to listOf("com.google.android.youtube", "app.revanced.android.youtube"),
        "ytb" to listOf("com.google.android.youtube"),
        "shopee" to listOf("com.shopee.vn"),
        "lazada" to listOf("com.lazada.android"),
        "taobao" to listOf("com.taobao.taobao"),
        "1688" to listOf("com.alibaba.wireless"),
        "pinduoduo" to listOf("com.xunmeng.pinduoduo"),
        "wechat" to listOf("com.tencent.mm"),
        "alipay" to listOf("com.eg.android.AlipayGphone"),
        "chrome" to listOf("com.android.chrome", "com.hihonor.baidu.browser", "com.huawei.browser"),
        "trinh duyet" to listOf("com.android.chrome", "com.hihonor.baidu.browser", "com.huawei.browser"),
        "google" to listOf("com.google.android.googlequicksearchbox"),
        "gemini" to listOf("com.google.android.apps.bard"),
        "ban do" to listOf("com.google.android.apps.maps"),
        "google maps" to listOf("com.google.android.apps.maps"),
        "maps" to listOf("com.google.android.apps.maps"),
        "gmail" to listOf("com.google.android.gm", "com.hihonor.email"),
        "ch play" to listOf("com.android.vending"),
        "play store" to listOf("com.android.vending"),
        "cua hang play" to listOf("com.android.vending"),
        "may anh" to listOf("com.hihonor.camera", "com.huawei.camera", "com.android.camera", "com.android.camera2"),
        "camera" to listOf("com.hihonor.camera", "com.huawei.camera", "com.android.camera", "com.android.camera2"),
        "thu vien" to listOf("com.hihonor.photos", "com.huawei.photos", "com.google.android.apps.photos", "com.android.gallery3d"),
        "bo suu tap" to listOf("com.hihonor.photos", "com.huawei.photos", "com.google.android.apps.photos", "com.android.gallery3d"),
        "anh" to listOf("com.hihonor.photos", "com.huawei.photos", "com.google.android.apps.photos"),
        "cai dat" to listOf("com.android.settings"),
        "settings" to listOf("com.android.settings"),
        "dien thoai" to listOf("com.hihonor.contacts", "com.android.dialer", "com.google.android.dialer", "com.android.contacts"),
        "cuoc goi" to listOf("com.hihonor.contacts", "com.android.dialer", "com.google.android.dialer"),
        "danh ba" to listOf("com.hihonor.contacts", "com.android.contacts", "com.google.android.contacts"),
        "tin nhan" to listOf("com.google.android.apps.messaging", "com.android.mms", "com.hihonor.mms"),
        "dong ho" to listOf("com.hihonor.deskclock", "com.android.deskclock", "com.google.android.deskclock"),
        "bao thuc" to listOf("com.hihonor.deskclock", "com.android.deskclock", "com.google.android.deskclock"),
        "may tinh" to listOf("com.hihonor.calculator", "com.android.calculator2", "com.google.android.calculator"),
        "ghi chu" to listOf("com.hihonor.notepad", "com.huawei.notepad", "com.google.android.keep"),
        "lich" to listOf("com.hihonor.calendar", "com.android.calendar", "com.google.android.calendar"),
        "thoi tiet" to listOf("com.hihonor.android.totemweather", "com.huawei.android.totemweather", "com.google.android.apps.weather", "com.coloros.weather2"),
        "magictune" to listOf("com.magictune.tool", "com.example"),
        "magic tune" to listOf("com.magictune.tool", "com.example")
    )

    fun normalizeVi(text: String): String {
        val decomposed = Normalizer.normalize(text.lowercase(Locale.ROOT).trim(), Normalizer.Form.NFD)
        return decomposed
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
            .replace('đ', 'd')
            .replace(Regex("[^a-z0-9%\\s]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    /**
     * Phân tích và thực thi ngay câu lệnh điều khiển điện thoại của người dùng (nếu là câu lệnh thao tác).
     * Trả về `VoiceCommandResult(handled = false, ...)` nếu đây là câu hỏi trò chuyện thông thường.
     */
    suspend fun tryExecuteVoiceCommand(context: Context, rawSpokenText: String): VoiceCommandResult {
        val appCtx = context.applicationContext
        val cleanText = rawSpokenText.trim()
        val norm = normalizeVi(cleanText)
        if (norm.isEmpty()) return VoiceCommandResult(false, "")

        // 0. Lệnh Hỏi Tên / "Tôi là ai" / "Tên tôi là gì"
        if (norm == "toi la ai" || norm.contains("toi la ai") || norm.contains("ten toi la gi") ||
            norm.contains("ten cua toi la gi") || norm.contains("biet toi la ai khong") || norm.contains("ten nguoi dung")
        ) {
            val uName = getUserDisplayName(appCtx)
            val reply = if (uName.isNotBlank() && uName != "bạn") {
                "Bạn là $uName, chủ nhân của chiếc điện thoại này trên ứng dụng MagicTune!"
            } else {
                "Bạn là chủ nhân của thiết bị này trên ứng dụng MagicTune. Bạn có thể đặt tên hiển thị trong mục Cài đặt tài khoản nhé!"
            }
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = reply
            )
        }

        // 0.05. AI ĐẶC TRỊ FIX THÔNG BÁO GMAIL, FACEBOOK, MESSENGER & ZALO CHO HONOR
        val isFixNotificationQuery = (
            (norm.contains("thong bao") || norm.contains("tit thong bao") || norm.contains("mat thong bao") || norm.contains("tre thong bao") || norm.contains("khong co chuong")) &&
            (norm.contains("gmail") || norm.contains("mail") || norm.contains("facebook") || norm.contains("fb") || norm.contains("honor") || norm.contains("zalo") || norm.contains("tat ca"))
        ) || norm.contains("fix thong bao") || norm.contains("sua thong bao") || norm.contains("bat thong bao gmail") || norm.contains("sua loi thong bao") || norm.contains("danh thuc thong bao")

        if (isFixNotificationQuery) {
            AutoWakeupPatrolManager.performHonorNotificationDeepFix(appCtx)
            val confirm = "AI đã kết hợp cơ chế tuần tra đánh thức phần cứng và vô hiệu hóa các trình dìm ngầm của Honor (PowerGenius, iAware). Đã kích hoạt toàn quyền chạy ngầm, Standby Bucket Active và đồng bộ hóa tức thì cho Gmail, Facebook, Messenger và Zalo!"
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = confirm
            )
        }

        // 0.06. HƯỚNG DẪN / TẮT CHẾ ĐỘ NHÀ PHÁT TRIỂN & GIẢI THÍCH LÝ DO KHÔNG VÀO ĐƯỢC APP NGÂN HÀNG, VNEID
        val isDevOptionsQuery = norm.contains("nha phat trien") || norm.contains("developer option") || norm.contains("go loi usb") || norm.contains("debugging")
        val isCannotOpenBankGovQuery = (norm.contains("khong vao duoc") || norm.contains("khong truy cap duoc") || norm.contains("bi chan") || norm.contains("bi vang") || norm.contains("khong mo duoc") || norm.contains("canh bao") || norm.contains("tai sao")) &&
            (norm.contains("ngan hang") || norm.contains("vneid") || norm.contains("vssid") || norm.contains("dich vu cong") || norm.contains("app do") || norm.contains("ung dung do"))

        if (isDevOptionsQuery || isCannotOpenBankGovQuery) {
            val devIntent = Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            val openedDev = launchIntentSafely(appCtx, devIntent)
            var shellDisabled = false
            try {
                val shell = ShellEngine.getInstance(appCtx)
                if (shell.state.value.isAdbReady) {
                    shell.execute("settings put global development_settings_enabled 0 2>/dev/null; settings put global adb_enabled 0 2>/dev/null")
                    shellDisabled = true
                }
            } catch (_: Throwable) {}

            val explanation = when {
                shellDisabled -> "Các ứng dụng Ngân hàng và Cổng dịch vụ công Nhà Nước (VNeID) từ chối mở khi điện thoại đang bật Chế độ nhà phát triển hoặc Gỡ lỗi USB. AI đã tự động tắt Chế độ nhà phát triển giúp bạn để có thể truy cập an toàn!"
                openedDev -> "Các ứng dụng Ngân hàng và VNeID thường chặn truy cập nếu Chế độ nhà phát triển đang bật để bảo mật tài khoản. Tôi đã mở trang Cài đặt Chế độ nhà phát triển cho bạn, bạn chỉ cần gạt tắt công tắc ở dòng đầu tiên là vào được bình thường nhé!"
                else -> "Các ứng dụng Ngân hàng và Cổng dịch vụ công Nhà Nước (VNeID) từ chối mở khi điện thoại đang bật Chế độ nhà phát triển. Bạn chỉ cần vào Cài đặt -> Tùy chọn nhà phát triển và gạt Tắt đi là có thể sử dụng bình thường ngay nhé!"
            }
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = explanation
            )
        }

        // 0.1 Câu chào hỏi mở đầu siêu tốc: "Xin chào", "Chào bạn", "Hello", "Hi" (Phản hồi tức thì <0.1s không cần chờ mạng)
        if (norm in setOf("xin chao", "chao", "chao ban", "chao gemini", "hello", "hi", "alo", "helo", "hello gemini", "hi gemini")) {
            val uName = getUserDisplayName(appCtx)
            val greeting = if (uName.isNotBlank() && uName != "bạn") {
                "Xin chào $uName! Tôi là trợ lý Gemini Live. Tôi có thể giúp gì cho bạn hôm nay?"
            } else {
                "Xin chào bạn! Tôi là trợ lý Gemini Live. Tôi luôn sẵn sàng giúp bạn, bạn cần tôi hỗ trợ gì nào?"
            }
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = greeting
            )
        }

        // 1. Lệnh Đóng / Tạm biệt / Ngừng trò chuyện Gemini Live
        if (norm in setOf(
                "tam biet", "dung lai", "tat gemini", "dong gemini", "thoat gemini",
                "dung tro chuyen", "ket thuc tro chuyen", "nghi thoi", "tat di", "dong hop thoai"
            ) || norm.startsWith("tam biet gemini") || norm.startsWith("dong tro chuyen")
        ) {
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Tôi vẫn luôn ở đây sẵn sàng để giúp bạn bất kỳ lúc nào nhé!",
                shouldDismissOverlay = true
            )
        }

        // 1.1 Lệnh Hỏi Thông Tin Điện Thoại & Cấu Hình Máy (Device Info & Hardware Specs)
        if (norm in setOf("may toi la may gi", "dien thoai gi", "may nay la may gi", "may gi", "dien thoai cua toi", "ten dien thoai") ||
            norm.contains("may toi la may gi") || norm.contains("dien thoai cua toi la gi") ||
            norm.contains("thong tin may") || norm.contains("thong tin dien thoai") ||
            norm.contains("cau hinh may") || norm.contains("cau hinh dien thoai") ||
            norm.contains("chip gi") || norm.contains("vi xu ly gi") || norm.contains("chay chip gi") ||
            norm.contains("android may") || norm.contains("magicos may") || norm.contains("phien ban magicos")
        ) {
            val dev = getDeviceRealtimeInfo(appCtx)
            val reply = "Điện thoại của bạn là ${dev.commercialName}, chạy vi xử lý ${dev.soc}, giao diện ${dev.magicOsVersion} trên nền Android ${dev.androidVersion}, màn hình tần số quét ${dev.refreshRateHz}Hz."
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = reply
            )
        }

        // 1.2 Lệnh Hỏi Tình Trạng Pin, Công Suất Sạc & Nhiệt Độ (Battery & Charging & Temp)
        if (norm in setOf("pin con bao nhieu", "con bao nhieu pin", "pin the nao", "tinh trang pin") ||
            norm.contains("pin con bao nhieu") || norm.contains("may con may phan tram pin") ||
            norm.contains("con may phan tram pin") || norm.contains("con bao nhieu phan tram pin") ||
            norm.contains("tinh trang pin") || norm.contains("suc khoe pin") ||
            norm.contains("dang sac") || norm.contains("sac pin") || norm.contains("sac nhanh") ||
            norm.contains("sac bao nhieu oat") || norm.contains("sac bao nhieu watt") ||
            norm.contains("nhiet do pin") || norm.contains("pin co nong khong")
        ) {
            val dev = getDeviceRealtimeInfo(appCtx)
            val chargeDesc = if (dev.isCharging) {
                val wStr = if (dev.chargingWatt > 1.0) " với công suất khoảng ${dev.chargingWatt.roundToInt()}W" else ""
                ", máy đang cắm sạc (${dev.chargingTitle}$wStr)"
            } else {
                ", đang dùng pin"
            }
            val tempDesc = String.format(Locale.US, "%.1f", dev.batteryTempC)
            val reply = "Pin của bạn hiện còn ${dev.batteryPct}%$chargeDesc. Nhiệt độ pin mát mẻ ở mức $tempDesc độ C."
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = reply
            )
        }

        // 1.3 Lệnh Hỏi Bộ Nhớ RAM & Dung Lượng Lưu Trữ Máy (RAM & ROM Storage)
        if (norm.contains("ram con bao nhieu") || norm.contains("ram trong bao nhieu") ||
            norm.contains("ram dang dung bao nhieu") || norm.contains("dung luong ram") ||
            norm.contains("bo nho con trong bao nhieu") || norm.contains("bo nho con bao nhieu") ||
            norm.contains("dung luong con lai") || norm.contains("dung luong may") ||
            norm.contains("bo nho may") || norm.contains("bo nho trong")
        ) {
            val dev = getDeviceRealtimeInfo(appCtx)
            val ramFreeStr = String.format(Locale.US, "%.1f", dev.ramAvailGb)
            val ramTotalStr = String.format(Locale.US, "%.1f", dev.ramTotalGb)
            val romFreeStr = String.format(Locale.US, "%.1f", dev.romAvailGb)
            val romTotalStr = String.format(Locale.US, "%.0f", dev.romTotalGb)
            val reply = "Bộ nhớ RAM đang còn trống $ramFreeStr GB trên tổng $ramTotalStr GB. Dung lượng bộ nhớ trong máy còn trống $romFreeStr GB trên tổng $romTotalStr GB."
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = reply
            )
        }

        // 1.4 Lệnh Tối Ưu Tăng Tốc Máy & Dọn Dẹp RAM (RAM Boost & Cleanup)
        if (norm.contains("don dep ram") || norm.contains("giai phong ram") ||
            norm.contains("toi uu ram") || norm.contains("tang toc may") ||
            norm.contains("don rac") || norm.contains("giai phong bo nho") ||
            norm.contains("don bo nho") || norm.contains("tang toc dien thoai")
        ) {
            optimizeDeviceMemory(appCtx)
            val dev = getDeviceRealtimeInfo(appCtx)
            val ramFreeStr = String.format(Locale.US, "%.1f", dev.ramAvailGb)
            val reply = "Đã dọn dẹp RAM và giải phóng bộ nhớ ngầm cho bạn! Hiện máy còn trống $ramFreeStr GB RAM, hoạt động rất mượt mà."
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = reply
            )
        }

        // 1.5 Lệnh Làm Mát & Hạ Nhiệt Điện Thoại (Device Cool Down)
        if (norm.contains("ha nhiet may") || norm.contains("lam mat may") ||
            norm.contains("giam nhiet do") || norm.contains("ha nhiet dien thoai")
        ) {
            optimizeDeviceMemory(appCtx)
            val dev = getDeviceRealtimeInfo(appCtx)
            val tempDesc = String.format(Locale.US, "%.1f", dev.batteryTempC)
            val reply = "Nhiệt độ pin máy hiện tại là $tempDesc độ C. Tôi đã tắt các tiến trình ngầm tốn tài nguyên để giúp máy nhanh chóng hạ nhiệt mát mẻ hơn!"
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = reply
            )
        }

        // 1.6 Lệnh Bật / Tắt Tiết Kiệm Pin (Battery Saver Mode)
        if (norm.contains("bat tiet kiem pin") || norm.contains("mo tiet kiem pin") || norm.contains("bat che do tiet kiem pin")) {
            setBatterySaverMode(appCtx, true)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đã bật chế độ tiết kiệm pin để tối ưu thời lượng sử dụng cho máy."
            )
        }
        if (norm.contains("tat tiet kiem pin") || norm.contains("tat che do tiet kiem pin")) {
            setBatterySaverMode(appCtx, false)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đã tắt chế độ tiết kiệm pin, máy đã trở về hiệu năng đầy đủ."
            )
        }

        // 2. Lệnh Đọc / Tóm tắt nội dung đang hiển thị trên màn hình hiện tại
        if (norm.contains("doc man hinh") ||
            norm.contains("tom tat man hinh") ||
            norm.contains("tren man hinh co gi") ||
            norm.contains("man hinh dang hien gi") ||
            norm.contains("dich man hinh nay")
        ) {
            MagicTuneCtsAccessibilityService.ensureServiceEnabledViaSecureSettings(appCtx)
            val nodes = MagicTuneCtsAccessibilityService.extractVisibleScreenNodesNow(appCtx)
            if (nodes.isNotEmpty()) {
                val joined = nodes.take(35).joinToString(" | ") { it.text }
                return VoiceCommandResult(
                    handled = false,
                    spokenConfirmation = "",
                    screenContextForAi = joined
                )
            }
        }

        // 2.1. Lệnh Hỏi Thời Tiết Thông Minh (Mở Google tra cứu thời tiết chuẩn theo vị trí GPS/mạng của máy, rồi AI đọc ngay kết quả vị trí + độ C trên màn hình)
        if (norm.contains("thoi tiet") || norm.contains("du bao thoi tiet")) {
            val weatherQuery = if (cleanText.length >= 8) cleanText else "thời tiết hôm nay"
            launchGoogleWebSearch(appCtx, weatherQuery)
            // Nhường quyền cho Gemini đọc trực tiếp thẻ kết quả vị trí & thời tiết thực tế đang hiện trên Google
            return VoiceCommandResult(
                handled = false,
                spokenConfirmation = "",
                screenContextForAi = null
            )
        }

        // 3. Lệnh Kích hoạt Khoanh Tròn Tìm Kiếm hoặc Dịch Cuộn Trực Tiếp của MagicTune
        if (norm.contains("khoanh tron tim kiem") || norm == "khoanh tron" || norm.contains("bat khoanh tron")) {
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đang mở màn hình Khoanh tròn tìm kiếm cho bạn.",
                shouldDismissOverlay = true
            ).also {
                CircleToSearchOverlayActivity.launch(appCtx)
            }
        }

        if (norm.contains("dich man hinh") || norm.contains("dich tin nhan") || norm.contains("dich doan chat") ||
            norm.contains("ho dang nhan gi") || norm.contains("ho noi gi") || norm.contains("ho vua nhan gi") ||
            norm.contains("ho nhan gi the") || norm.contains("tin nhan moi nhat") || norm.contains("dich tin moi nhat") ||
            norm.contains("dich chu tren man hinh")
        ) {
            GeminiLiveFloatingOverlay.translateCurrentScreenForeignText(appCtx)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "",
                shouldDismissOverlay = false
            )
        }

        if (norm.contains("hoi ve man hinh") || norm.contains("man hinh dang co gi") || norm.contains("tren man hinh co gi") || norm.contains("xem man hinh nay")) {
            GeminiLiveFloatingOverlay.askAboutCurrentScreen(appCtx)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đang quan sát màn hình...",
                shouldDismissOverlay = false
            )
        }

        if (norm.contains("bat dich cuon") || norm.contains("dich cuon truc tiep") || norm.contains("dich taobao")) {
            GoogleLiveTranslateOverlay.start(appCtx)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đã bật chế độ dịch cuộn trực tiếp trên màn hình.",
                shouldDismissOverlay = true
            )
        }

        if (norm.contains("tat dich cuon") || norm.contains("dung dich cuon")) {
            GoogleLiveTranslateOverlay.stop(appCtx)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đã tắt chế độ dịch cuộn trực tiếp."
            )
        }

        // 4. Lệnh Điều khiển Đèn Pin (Flashlight / Torch)
        if (norm.contains("bat den pin") || norm.contains("mo den pin") || norm.contains("bat den flash") || norm.contains("bat flash")) {
            val ok = setFlashlightState(appCtx, true)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = if (ok) "Đã bật đèn pin cho bạn." else "Không thể bật đèn pin trên thiết bị này."
            )
        }
        if (norm.contains("tat den pin") || norm.contains("tat den flash") || norm.contains("tat flash")) {
            val ok = setFlashlightState(appCtx, false)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = if (ok) "Đã tắt đèn pin." else "Không thể tắt đèn pin."
            )
        }

        // 5. Lệnh Điều khiển Âm lượng (Volume Control)
        val volumePercentMatch = Regex("""(?:am luong|muc am luong|dat am luong|chinh am luong)\s*(\d{1,3})\s*(?:%|phan tram)?""").find(norm)
        if (volumePercentMatch != null) {
            val pct = volumePercentMatch.groupValues[1].toIntOrNull()?.coerceIn(0, 100) ?: 50
            setMediaVolumePercent(appCtx, pct)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đã chỉnh âm lượng ở mức $pct phần trăm."
            )
        }
        if (norm.contains("tang am luong") || norm.contains("cho to tieng") || norm.contains("mo to len") || norm.contains("tang tieng")) {
            val newPct = adjustMediaVolumeByStep(appCtx, deltaPercent = +20)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đã tăng âm lượng lên $newPct phần trăm."
            )
        }
        if (norm.contains("giam am luong") || norm.contains("cho nho tieng") || norm.contains("nho tieng xuong") || norm.contains("giam tieng")) {
            val newPct = adjustMediaVolumeByStep(appCtx, deltaPercent = -20)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đã giảm âm lượng xuống $newPct phần trăm."
            )
        }
        if (norm.contains("am luong toi da") || norm.contains("mo het co am luong") || norm.contains("max am luong")) {
            setMediaVolumePercent(appCtx, 100)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đã bật âm lượng tối đa 100 phần trăm."
            )
        }
        if (norm == "tat tieng" || norm.contains("tat am thanh") || norm.contains("che do im lang")) {
            setMediaVolumePercent(appCtx, 0)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đã tắt tiếng thiết bị."
            )
        }

        // 6. Lệnh Điều khiển Độ sáng màn hình (Brightness)
        val brightnessPercentMatch = Regex("""(?:do sang|muc do sang|chinh do sang)\s*(\d{1,3})\s*(?:%|phan tram)?""").find(norm)
        if (brightnessPercentMatch != null) {
            val pct = brightnessPercentMatch.groupValues[1].toIntOrNull()?.coerceIn(5, 100) ?: 70
            setScreenBrightnessPercent(appCtx, pct)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đã chỉnh độ sáng màn hình ở mức $pct phần trăm."
            )
        }
        if (norm.contains("tang do sang") || norm.contains("man hinh sang len")) {
            val pct = adjustScreenBrightnessByStep(appCtx, +25)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đã tăng độ sáng màn hình lên $pct phần trăm."
            )
        }
        if (norm.contains("giam do sang") || norm.contains("ha do sang") || norm.contains("man hinh toi xuong")) {
            val pct = adjustScreenBrightnessByStep(appCtx, -25)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đã giảm độ sáng màn hình xuống $pct phần trăm."
            )
        }

        // 7. Lệnh Điều khiển Wi-Fi / Bluetooth / Cài đặt hệ thống
        if (norm.contains("bat wifi") || norm.contains("mo wifi") || norm.contains("bat mang wifi")) {
            toggleWifiOrOpenPanel(appCtx, enable = true)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đang bật kết nối Wi-Fi cho bạn."
            )
        }
        // Bảo vệ kết nối mạng & ứng dụng trợ lý: Không cho phép tắt Wi-Fi, Dữ liệu di động hay tắt MagicTune
        if (norm.contains("tat wifi") || norm.contains("ngat wifi") || norm.contains("tat mang") || norm.contains("tat du lieu di dong") || norm.contains("tat 4g") || norm.contains("tat 5g")) {
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Tôi không thể tắt mạng Wi-Fi hoặc dữ liệu di động vì cần kết nối mạng để trợ lý Gemini hoạt động liên tục phục vụ bạn!"
            )
        }
        if (norm.contains("tat magictune") || norm.contains("tat ung dung nay") || norm.contains("xoa magictune") || norm.contains("go cai dat magictune")) {
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Tôi không thể tắt hoặc gỡ ứng dụng MagicTune vì đây là ứng dụng đang duy trì trợ lý cho bạn!"
            )
        }
        if (norm.contains("bat bluetooth") || norm.contains("mo bluetooth")) {
            toggleBluetoothDirectOrInSettings(appCtx, enable = true)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đang bật kết nối Bluetooth trong cài đặt cho bạn."
            )
        }
        if (norm.contains("tat bluetooth") || norm.contains("ngat bluetooth") || norm.contains("dong bluetooth")) {
            toggleBluetoothDirectOrInSettings(appCtx, enable = false)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đang tắt kết nối Bluetooth trong cài đặt."
            )
        }

        // 8. Lệnh Điều hướng & Cử chỉ Màn hình (Back, Home, Recents, Notifications, Screenshot, Lock, Scroll/Swipe)
        if (norm in setOf("quay lai", "tro lai", "tro ve", "bam nut quay lai", "nhan quay lai")) {
            MagicTuneCtsAccessibilityService.performVoiceGlobalAction(appCtx, AccessibilityService.GLOBAL_ACTION_BACK)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đã quay lại trang trước."
            )
        }
        if (norm in setOf("ve man hinh chinh", "man hinh chinh", "ve trang chu", "trang chu", "ve home", "thoat ra man hinh chinh")) {
            MagicTuneCtsAccessibilityService.performVoiceGlobalAction(appCtx, AccessibilityService.GLOBAL_ACTION_HOME)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đã về màn hình chính."
            )
        }
        if (norm.contains("mo da nhiem") || norm.contains("ung dung gan day") || norm.contains("xem da nhiem")) {
            MagicTuneCtsAccessibilityService.performVoiceGlobalAction(appCtx, AccessibilityService.GLOBAL_ACTION_RECENTS)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đã mở màn hình đa nhiệm."
            )
        }
        if (norm.contains("mo thanh thong bao") || norm.contains("keo thanh thong bao") || norm.contains("xem thong bao")) {
            MagicTuneCtsAccessibilityService.performVoiceGlobalAction(appCtx, AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đã mở thanh thông báo."
            )
        }
        if (norm.contains("mo cai dat nhanh") || norm.contains("keo cai dat nhanh")) {
            MagicTuneCtsAccessibilityService.performVoiceGlobalAction(appCtx, AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đã mở bảng cài đặt nhanh."
            )
        }
        if (norm.contains("chup man hinh") || norm.contains("chup anh man hinh")) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                MagicTuneCtsAccessibilityService.performVoiceGlobalAction(appCtx, AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)
                return VoiceCommandResult(
                    handled = true,
                    spokenConfirmation = "Đã chụp ảnh màn hình."
                )
            }
        }
        if (norm.contains("khoa man hinh") || norm.contains("tat man hinh")) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                MagicTuneCtsAccessibilityService.performVoiceGlobalAction(appCtx, AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
                return VoiceCommandResult(
                    handled = true,
                    spokenConfirmation = "Đang khóa màn hình.",
                    shouldDismissOverlay = true
                )
            }
        }

        // Cuộn lên / Cuộn xuống / Vuốt trái / Vuốt phải
        if (norm in setOf("cuon xuong", "luot xuong", "keo xuong", "vuot len", "xem tiep", "cuon tiep", "luot tiep")) {
            MagicTuneCtsAccessibilityService.performVoiceScrollOrSwipe(appCtx, "DOWN")
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đã cuộn xuống."
            )
        }
        if (norm in setOf("cuon len", "luot len", "keo len", "vuot xuong", "quay len dau")) {
            MagicTuneCtsAccessibilityService.performVoiceScrollOrSwipe(appCtx, "UP")
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đã cuộn lên."
            )
        }
        if (norm in setOf("vuot sang trai", "luot sang trai", "vuot trai", "trang tiep theo")) {
            MagicTuneCtsAccessibilityService.performVoiceScrollOrSwipe(appCtx, "LEFT")
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đã vuốt sang trái."
            )
        }
        if (norm in setOf("vuot sang phai", "luot sang phai", "vuot phai")) {
            MagicTuneCtsAccessibilityService.performVoiceScrollOrSwipe(appCtx, "RIGHT")
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đã vuốt sang phải."
            )
        }

        // 9. Lệnh Bấm / Nhấn / Chạm vào một nút hoặc dòng chữ trên màn hình hiện tại
        val clickTarget = extractClickTargetFromVoice(cleanText, norm)
        if (clickTarget != null && clickTarget.length >= 2) {
            val clicked = MagicTuneCtsAccessibilityService.clickScreenElementByVoiceText(appCtx, clickTarget)
            if (clicked) {
                return VoiceCommandResult(
                    handled = true,
                    spokenConfirmation = "Đã nhấn vào \"$clickTarget\" trên màn hình."
                )
            }
        }

        // 10. Lệnh YouTube Thông Minh (Quay về trang chủ, tự động phát video ngay, chuyển bài / đổi video khác siêu tốc)
        val fgPkg = MagicTuneCtsAccessibilityService.getActiveForegroundPackage().orEmpty()
        val isYoutubeForeground = fgPkg.contains("youtube")

        if (norm in setOf("ve trang chu youtube", "quay ve trang chu youtube", "trang chu youtube", "ve youtube", "quay ve youtube", "tro ve trang chu youtube") ||
            (isYoutubeForeground && norm in setOf("ve trang chu", "quay ve trang chu", "quay lai trang chu", "trang chu"))) {
            launchYoutubeHome(appCtx)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đang đưa bạn quay về trang chủ YouTube."
            )
        }

        // Đổi video khác / bài khác / video tiếp theo khi đang xem YouTube
        if (norm in setOf("video khac", "bai khac", "bai hat khac", "doi video", "doi bai", "bai tiep theo", "video tiep theo", "chuyen bai", "chuyen video", "next bai", "next video") ||
            (isYoutubeForeground && norm in setOf("khac", "doi bai khac", "video khac di", "bai khac di", "tiep theo"))) {
            val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
            scope.launch {
                MagicTuneCtsAccessibilityService.performVoiceGlobalAction(appCtx, AccessibilityService.GLOBAL_ACTION_BACK)
                delay(400L)
                MagicTuneCtsAccessibilityService.clickFirstVideoOrContentCard(appCtx)
            }
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đang đổi sang video khác cho bạn."
            )
        }

        val mediaIntent = extractMediaSearchIntent(cleanText, norm)
        if (mediaIntent != null) {
            launchYoutubeSearch(appCtx, mediaIntent.searchQuery, autoPlay = mediaIntent.autoPlay)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = mediaIntent.spokenConfirmation
            )
        }

        val mapsQuery = extractMapsSearchQuery(cleanText, norm)
        if (mapsQuery != null) {
            launchGoogleMapsSearch(appCtx, mapsQuery)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đang mở Bản đồ chỉ đường tới \"$mapsQuery\"."
            )
        }

        val googleWebQuery = extractGoogleSearchQuery(cleanText, norm)
        if (googleWebQuery != null) {
            launchGoogleWebSearch(appCtx, googleWebQuery)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = "Đang tìm kiếm \"$googleWebQuery\" trên Google cho bạn."
            )
        }

        // 10.5. Lệnh Sáng Tạo Hình Ảnh & Video với App Gemini (Gemini Creative Hand-off)
        val creativeIntent = extractGeminiCreativeIntent(cleanText, norm)
        if (creativeIntent != null) {
            launchGeminiCreativeHandOff(appCtx, creativeIntent.prompt, creativeIntent.isVideo)
            return VoiceCommandResult(
                handled = true,
                spokenConfirmation = creativeIntent.spokenConfirmation,
                shouldDismissOverlay = true
            )
        }

        // 11. Lệnh Mở bất kỳ ứng dụng nào trên điện thoại (Open App by Voice)
        val requestedAppName = extractAppNameToOpen(cleanText, norm)
        if (requestedAppName != null) {
            val normApp = normalizeVi(requestedAppName)
            val sensitiveList = listOf(
                "vneid", "vssid", "dich vu cong", "cong dich vu cong", "etax", "thue dien tu",
                "ngan hang", "vietcombank", "techcombank", "mb bank", "mbbank", "bidv", "vietinbank",
                "agribank", "acb", "vpbank", "tpbank", "hdbank", "shb", "msb", "ocb", "sacombank",
                "viettel money", "momo", "zalopay", "vnpt pay", "vnpay", "shopeepay"
            )
            if (sensitiveList.any { normApp == it || normApp.contains(it) }) {
                val politeDecline = "Tôi được thiết kế để bảo vệ an toàn cho bạn và không can thiệp vào các ứng dụng quan trọng của Chính phủ, Nhà Nước hay Ngân hàng. Rất tiếc tôi không thể giúp bạn tự động thao tác trên ứng dụng này, mong bạn thông cảm và mở trực tiếp nhé!"
                return VoiceCommandResult(
                    handled = true,
                    spokenConfirmation = politeDecline
                )
            }

            val launchedLabel = findAndLaunchAppByName(appCtx, requestedAppName)
            if (launchedLabel != null) {
                return VoiceCommandResult(
                    handled = true,
                    spokenConfirmation = "Đang mở ứng dụng $launchedLabel cho bạn."
                )
            } else {
                return VoiceCommandResult(
                    handled = true,
                    spokenConfirmation = "Tôi không tìm thấy ứng dụng \"$requestedAppName\" được cài trên máy của bạn."
                )
            }
        }

        return VoiceCommandResult(handled = false, spokenConfirmation = "")
    }

    /**
     * Thực thi thẻ lệnh `[ACTION:...]` do mô hình AI đính kèm trong phản hồi (khi người dùng nói câu tự nhiên phức tạp).
     * Trả về văn bản sạch (đã gỡ bỏ thẻ `[ACTION:...]`) để đọc thành tiếng.
     */
    suspend fun processAiActionTagsIfPresent(context: Context, aiRawReply: String): String {
        val appCtx = context.applicationContext
        val tagRegex = Regex("""\[([A-Z_]+):([^\]]*)\]""")
        val matches = tagRegex.findAll(aiRawReply).toList()
        if (matches.isEmpty()) return aiRawReply.trim()

        for (match in matches) {
            val actionType = match.groupValues[1].uppercase(Locale.ROOT).trim()
            val param = match.groupValues[2].trim()
            when (actionType) {
                "OPEN_APP" -> {
                    if (param.isNotEmpty()) {
                        findAndLaunchAppByName(appCtx, param)
                    }
                }
                "YOUTUBE_HOME" -> {
                    launchYoutubeHome(appCtx)
                }
                "YOUTUBE_SEARCH" -> {
                    if (param.isNotEmpty()) {
                        launchYoutubeSearch(appCtx, param)
                    }
                }
                "GOOGLE_SEARCH" -> {
                    if (param.isNotEmpty()) {
                        launchGoogleWebSearch(appCtx, param)
                    }
                }
                "MAPS_SEARCH" -> {
                    if (param.isNotEmpty()) {
                        launchGoogleMapsSearch(appCtx, param)
                    }
                }
                "CLICK_TEXT" -> {
                    if (param.isNotEmpty()) {
                        MagicTuneCtsAccessibilityService.clickScreenElementByVoiceText(appCtx, param)
                    }
                }
                "SCROLL" -> {
                    MagicTuneCtsAccessibilityService.performVoiceScrollOrSwipe(appCtx, param.ifEmpty { "DOWN" })
                }
                "GLOBAL" -> {
                    when (param.uppercase(Locale.ROOT)) {
                        "BACK" -> MagicTuneCtsAccessibilityService.performVoiceGlobalAction(appCtx, AccessibilityService.GLOBAL_ACTION_BACK)
                        "HOME" -> MagicTuneCtsAccessibilityService.performVoiceGlobalAction(appCtx, AccessibilityService.GLOBAL_ACTION_HOME)
                        "RECENTS" -> MagicTuneCtsAccessibilityService.performVoiceGlobalAction(appCtx, AccessibilityService.GLOBAL_ACTION_RECENTS)
                        "NOTIFICATIONS" -> MagicTuneCtsAccessibilityService.performVoiceGlobalAction(appCtx, AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
                        "SCREENSHOT" -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                            MagicTuneCtsAccessibilityService.performVoiceGlobalAction(appCtx, AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)
                        }
                    }
                }
                "TORCH" -> {
                    setFlashlightState(appCtx, param.equals("ON", ignoreCase = true))
                }
                "VOLUME" -> {
                    when (param.uppercase(Locale.ROOT)) {
                        "UP" -> adjustMediaVolumeByStep(appCtx, +20)
                        "DOWN" -> adjustMediaVolumeByStep(appCtx, -20)
                        "MUTE" -> setMediaVolumePercent(appCtx, 0)
                        "MAX" -> setMediaVolumePercent(appCtx, 100)
                        else -> param.toIntOrNull()?.let { setMediaVolumePercent(appCtx, it) }
                    }
                }
                "BLUETOOTH" -> {
                    toggleBluetoothDirectOrInSettings(appCtx, param.equals("ON", ignoreCase = true))
                }
                "WIFI" -> {
                    toggleWifiOrOpenPanel(appCtx, param.equals("ON", ignoreCase = true))
                }
                "OPTIMIZE_RAM" -> {
                    optimizeDeviceMemory(appCtx)
                }
                "POWER_SAVER" -> {
                    setBatterySaverMode(appCtx, param.equals("ON", ignoreCase = true))
                }
            }
        }

        return aiRawReply.replace(tagRegex, "").replace(Regex("\\s+"), " ").trim()
    }

    private fun extractClickTargetFromVoice(raw: String, norm: String): String? {
        val prefixes = listOf(
            "bam vao nut ", "nhan vao nut ", "cham vao nut ", "an vao nut ", "kich vao nut ",
            "bam vao muc ", "nhan vao muc ", "chon muc ", "an vao muc ",
            "bam vao chữ ", "nhan vao chu ", "bam vao ", "nhan vao ", "cham vao ", "an vao ",
            "bam ho toi ", "bam ho ", "nhan ho toi ", "nhan ho ", "cham ho ",
            "bam nut ", "nhan nut ", "cham nut ", "an nut ", "chon nut ",
            "bam cho nao ", "bam vao cho ", "nhan vao cho ", "cham vao cho ",
            "bam vao ", "nhan vao ", "chon "
        )
        for (prefix in prefixes) {
            if (norm.startsWith(prefix)) {
                val remainder = norm.removePrefix(prefix)
                    .removeSuffix(" tren man hinh")
                    .removeSuffix(" giup toi")
                    .removeSuffix(" đi")
                    .removeSuffix(" di")
                    .trim()
                if (remainder.isNotEmpty() && !remainder.startsWith("ung dung ") && !remainder.startsWith("app ")) {
                    return remainder
                }
            }
        }
        return null
    }

    fun extractMediaSearchIntent(raw: String, norm: String): MediaSearchIntent? {
        // 1. YouTube trực tiếp có từ khóa youtube
        val ytExplicit = Regex("""^(?:mo|vao|bat)\s+youtube\s+(?:tim kiem|tim|phat|nghe|xem|mo)\s+(.+)$""").find(norm)
        if (ytExplicit != null) {
            val q = ytExplicit.groupValues[1].removeSuffix(" giup toi").removeSuffix(" cho toi").trim()
            if (q.isNotEmpty()) return MediaSearchIntent(q, "Đang mở và phát \"$q\" trên YouTube cho bạn.", autoPlay = true)
        }

        val ytSuffix = Regex("""^(?:tim|tim kiem|phat|mo|nghe|xem)\s+(.+?)\s+tren\s+youtube$""").find(norm)
        if (ytSuffix != null) {
            val q = ytSuffix.groupValues[1].removeSuffix(" giup toi").removeSuffix(" cho toi").trim()
            if (q.isNotEmpty()) return MediaSearchIntent(q, "Đang mở và phát \"$q\" trên YouTube cho bạn.", autoPlay = true)
        }

        val ytPrefix = Regex("""^(?:xem tren youtube|tim tren youtube|nghe tren youtube|mo tren youtube)\s+(.+)$""").find(norm)
        if (ytPrefix != null) {
            val q = ytPrefix.groupValues[1].removeSuffix(" giup toi").removeSuffix(" cho toi").trim()
            if (q.isNotEmpty()) return MediaSearchIntent(q, "Đang mở và phát \"$q\" trên YouTube cho bạn.", autoPlay = true)
        }

        // 2. Phim / Phim bộ / Phim hoạt hình / Anime / Chiếu phim
        val movieMatch = Regex("""^(?:mo|xem|chieu|bat|tim|tim kiem)\s+(?:phim|bo phim|tap phim|hoat hinh|anime)\s+(.+)$""").find(norm)
        if (movieMatch != null) {
            val t = movieMatch.groupValues[1].removeSuffix(" tren youtube").removeSuffix(" giup toi").removeSuffix(" cho toi").trim()
            if (t.isNotEmpty()) {
                val searchQuery = if (t.startsWith("phim") || t.startsWith("hoat hinh")) t else "phim $t"
                return MediaSearchIntent(searchQuery, "Đang mở phim \"$t\" trên YouTube cho bạn.")
            }
        }
        if (norm.startsWith("phim ") || norm.startsWith("hoat hinh ")) {
            val t = norm.removeSuffix(" tren youtube").removeSuffix(" giup toi").trim()
            if (t.length > 5) return MediaSearchIntent(t, "Đang tìm phim \"$t\" trên YouTube cho bạn.")
        }

        // 3. Bài hát / Ca khúc / Album / Podcast
        val songMatch = Regex("""^(?:mo|nghe|phat|bat|tim|tim kiem)\s+(?:bai hat|ca khuc|bai ca|album|podcast)\s+(.+)$""").find(norm)
        if (songMatch != null) {
            val t = songMatch.groupValues[1].removeSuffix(" tren youtube").removeSuffix(" giup toi").removeSuffix(" cho toi").trim()
            if (t.isNotEmpty()) {
                val searchQuery = if (t.startsWith("bai hat") || t.startsWith("ca khuc")) t else "bài hát $t"
                return MediaSearchIntent(searchQuery, "Đang phát bài hát \"$t\" trên YouTube cho bạn.")
            }
        }
        val songShortMatch = Regex("""^(?:mo|nghe|phat|bat)\s+bai\s+(.+)$""").find(norm)
        if (songShortMatch != null) {
            val t = songShortMatch.groupValues[1].removeSuffix(" tren youtube").removeSuffix(" giup toi").removeSuffix(" cho toi").trim()
            if (t.isNotEmpty()) {
                return MediaSearchIntent("bài hát $t", "Đang phát bài \"$t\" trên YouTube cho bạn.")
            }
        }

        // 4. Nhạc (nhạc trẻ, remix, không lời, ballad...)
        val musicMatch = Regex("""^(?:bat nhac|mo nhac|nghe nhac|phat nhac|tim nhac)\s*(.*)$""").find(norm)
        if (musicMatch != null) {
            val t = musicMatch.groupValues[1].removeSuffix(" tren youtube").removeSuffix(" giup toi").removeSuffix(" cho toi").trim()
            val searchQuery = if (t.isNotEmpty()) (if (t.startsWith("nhac")) t else "nhạc $t") else "nhạc trẻ remix hot trend"
            val spoken = if (t.isNotEmpty()) "Đang phát nhạc \"$t\" trên YouTube cho bạn." else "Đang mở nhạc hay trên YouTube cho bạn."
            return MediaSearchIntent(searchQuery, spoken)
        }

        // 5. Video / Clip
        val videoMatch = Regex("""^(?:mo|xem|phat|bat|tim|tim kiem)\s+(?:video|clip|video clip)\s+(.+)$""").find(norm)
        if (videoMatch != null) {
            val t = videoMatch.groupValues[1].removeSuffix(" tren youtube").removeSuffix(" giup toi").removeSuffix(" cho toi").trim()
            if (t.isNotEmpty()) {
                val searchQuery = if (t.startsWith("video") || t.startsWith("clip")) t else "video $t"
                return MediaSearchIntent(searchQuery, "Đang mở video \"$t\" trên YouTube cho bạn.")
            }
        }

        // 6. Hài kịch / Tiểu phẩm
        val comedyMatch = Regex("""^(?:mo|xem|phat)\s+(?:hai|hai huoc|hai kich|kich)\s+(.+)$""").find(norm)
        if (comedyMatch != null) {
            val t = comedyMatch.groupValues[1].removeSuffix(" tren youtube").removeSuffix(" giup toi").removeSuffix(" cho toi").trim()
            if (t.isNotEmpty()) {
                return MediaSearchIntent("hài $t", "Đang mở hài \"$t\" trên YouTube cho bạn.")
            }
        }

        return null
    }

    private fun extractYoutubeSearchQuery(raw: String, norm: String): String? {
        return extractMediaSearchIntent(raw, norm)?.searchQuery
    }

    private fun extractMapsSearchQuery(raw: String, norm: String): String? {
        val patterns = listOf(
            Regex("""^(?:chi duong|dan duong)\s+(?:den|toi|di)\s+(.+)$"""),
            Regex("""^(?:mo ban do|mo google maps|vao ban do)\s+(?:tim|den|toi|chi duong)\s+(.+)$""")
        )
        for (p in patterns) {
            val m = p.find(norm)
            if (m != null) {
                val q = m.groupValues[1].removeSuffix(" giup toi").trim()
                if (q.isNotEmpty()) return q
            }
        }
        return null
    }

    private fun extractGoogleSearchQuery(raw: String, norm: String): String? {
        val patterns = listOf(
            Regex("""^(?:tim tren google|tra google|tim google|google tim|hoi google)\s+(.+)$"""),
            Regex("""^(?:tim kiem tren google|tra cuu tren google|tra tren google)\s+(.+)$"""),
            Regex("""^(?:mo cach|tim cach|huong dan cach|cach lam|cong thuc)\s+(.+)$"""),
            Regex("""^(?:tra cuu|tim hieu ve|tra cuu thong tin ve)\s+(.+)$"""),
            Regex("""^(?:gia vang|gia xang|ti gia|chung khoan)\s*(.*)$""")
        )
        for (p in patterns) {
            val m = p.find(norm)
            if (m != null) {
                val q = if (m.groupValues.size > 1 && m.groupValues[1].isNotBlank()) {
                    m.groupValues[1].trim()
                } else {
                    norm
                }
                if (q.isNotEmpty()) return q
            }
        }
        return null
    }

    data class GeminiCreativeIntent(
        val prompt: String,
        val isVideo: Boolean,
        val spokenConfirmation: String
    )

    fun extractGeminiCreativeIntent(raw: String, norm: String): GeminiCreativeIntent? {
        val clean = raw.trim()
        val n = norm.trim()

        // 1. Nhận diện các mẫu lệnh Tạo Video
        val videoRegexes = listOf(
            Regex("""^(?:nho gemini|bao gemini|mo gemini|dung gemini|gemini)\s+(?:tao|lam|quay|render)\s+(?:video|clip|phim)\s+(.+)$"""),
            Regex("""^(?:tao|lam|quay|render)\s+(?:giup toi|ho toi|cho toi)?\s*(?:video|clip|doan phim|phim ngan)\s+(.+)$"""),
            Regex("""^(?:tao video|lam video|quay video ai|tao clip ai|render video)\s+(.+)$"""),
            Regex("""^(?:tao video|lam video|quay video ai|tao clip ai)$""")
        )
        for (r in videoRegexes) {
            val m = r.find(n)
            if (m != null) {
                val groupVal = if (m.groupValues.size > 1) m.groupValues[1].trim() else ""
                val promptText = if (groupVal.isNotEmpty()) {
                    clean.removePrefix("Gemini").removePrefix("gemini").trim()
                } else "Tạo một đoạn video AI sáng tạo và ấn tượng"
                val spoken = "Đang mở ứng dụng Gemini cho bạn. Tôi đã sao chép sẵn yêu cầu: \"$promptText\" vào bộ nhớ tạm. Bạn chỉ cần nhấn Dán và gửi nhé!"
                return GeminiCreativeIntent(promptText, isVideo = true, spokenConfirmation = spoken)
            }
        }

        // 2. Nhận diện các mẫu lệnh Tạo Ảnh / Vẽ Tranh
        val imageRegexes = listOf(
            Regex("""^(?:nho gemini|bao gemini|mo gemini|dung gemini|gemini)\s+(?:tao|ve|lam)\s+(?:anh|hinh anh|buc anh|tranh|buc tranh|hinh)\s+(.+)$"""),
            Regex("""^(?:tao|ve|lam)\s+(?:giup toi|ho toi|cho toi)?\s*(?:buc anh|tam anh|hinh anh|anh|tranh|buc tranh)\s+(.+)$"""),
            Regex("""^(?:ve|draw)\s+(?:cho toi|giup toi)?\s*(?:hinh|anh|buc tranh)?\s*(.+)$"""),
            Regex("""^(?:tao anh|tao hinh anh|tao buc anh|ve anh|ve tranh|ve hinh|tao image)\s*(.*)$""")
        )
        for (r in imageRegexes) {
            val m = r.find(n)
            if (m != null) {
                val groupVal = if (m.groupValues.size > 1) m.groupValues[1].trim() else ""
                val promptText = if (groupVal.isNotEmpty()) {
                    clean.removePrefix("Gemini").removePrefix("gemini").trim()
                } else "Tạo một bức ảnh nghệ thuật tuyệt đẹp"
                val spoken = "Đang mở ứng dụng Gemini cho bạn. Tôi đã sao chép sẵn yêu cầu tạo ảnh: \"$promptText\" vào bộ nhớ tạm. Bạn chỉ cần nhấn Dán và gửi nhé!"
                return GeminiCreativeIntent(promptText, isVideo = false, spokenConfirmation = spoken)
            }
        }

        return null
    }

    fun launchGeminiCreativeHandOff(context: Context, prompt: String, isVideo: Boolean) {
        val appCtx = context.applicationContext
        try {
            // 1. Lưu vào khay nhớ tạm (Clipboard)
            val clipboard = appCtx.getSystemService(Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager
            if (clipboard != null) {
                val clip = android.content.ClipData.newPlainText("Gemini Creative Prompt", prompt)
                clipboard.setPrimaryClip(clip)
            }

            // 2. Hiển thị Toast thông báo hướng dẫn
            val typeStr = if (isVideo) "video" else "ảnh"
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                Toast.makeText(
                    appCtx,
                    "🎨 Đã copy prompt tạo $typeStr!\nNhấn 'Dán' vào Gemini và bấm Gửi để tạo ngay.",
                    Toast.LENGTH_LONG
                ).show()
            }

            // 3. Khởi chạy Google Gemini App hoặc Fallback sang Trình duyệt Web
            val geminiPackages = listOf(
                "com.google.android.apps.bard",
                "com.google.android.googlequicksearchbox"
            )
            var launched = false
            for (pkg in geminiPackages) {
                val launchIntent = appCtx.packageManager.getLaunchIntentForPackage(pkg)
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    appCtx.startActivity(launchIntent)
                    launched = true
                    break
                }
            }

            if (!launched) {
                val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://gemini.google.com/app")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                appCtx.startActivity(webIntent)
            }
        } catch (e: Throwable) {
            Log.e("GeminiAction", "Lỗi mở Gemini Creative: ${e.message}", e)
        }
    }

    private fun extractAppNameToOpen(raw: String, norm: String): String? {
        val cleanNorm = norm
            .removePrefix("gemini oi ")
            .removePrefix("gemini ")
            .removePrefix("hay ")
            .removePrefix("lam on ")
            .removePrefix("giup toi ")
            .trim()

        val openRegex = Regex("""^(?:mo|bat|vao|khoi dong|chay)\s+(?:ung dung\s+|app\s+|phan mem\s+)?(.+)$""")
        val m = openRegex.find(cleanNorm) ?: return null
        val target = m.groupValues[1]
            .removeSuffix(" len giup toi")
            .removeSuffix(" giup toi")
            .removeSuffix(" cho toi")
            .removeSuffix(" len nhe")
            .removeSuffix(" len di")
            .removeSuffix(" len")
            .removeSuffix(" nhe")
            .removeSuffix(" di")
            .trim()

        // 1. Tránh nhận nhầm các lệnh phần cứng / hệ thống đã xử lý ở trên
        val ignoredTargets = setOf(
            "den pin", "den flash", "flash", "wifi", "bluetooth", "da nhiem",
            "thanh thong bao", "cai dat nhanh", "to len", "nho xuong"
        )
        if (target.isEmpty() || target in ignoredTargets || target.split(" ").size > 5) {
            return null
        }

        // 2. BỘ LỌC THÔNG MINH: Tuyệt đối không nhận nhầm phim, nhạc, bài hát, video, hoặc câu hỏi tìm kiếm thành mở ứng dụng!
        val nonAppIndicators = listOf(
            "phim", "bo phim", "tap phim", "hoat hinh", "anime", "cinema",
            "nhac", "bai hat", "ca khuc", "bai ca", "album", "podcast",
            "video", "clip", "mv",
            "cach ", "huong dan ", "lam the nao", "tai sao", "cong thuc",
            "gia vang", "gia xang", "thoi tiet", "tin tuc", "dia chi",
            "thong tin", "cau hinh", "pin con", "ram con", "bo nho", "tiet kiem pin"
        )
        for (indicator in nonAppIndicators) {
            if (target == indicator || target.startsWith("$indicator ") || target.contains(" $indicator ")) {
                return null
            }
        }

        return target
    }

    /**
     * Tìm và khởi chạy bất kỳ ứng dụng nào đã cài đặt trên máy theo tên Tiếng Việt / Tiếng Anh.
     */
    suspend fun findAndLaunchAppByName(context: Context, requestedName: String): String? {
        val appCtx = context.applicationContext
        val pm = appCtx.packageManager
        val normReq = normalizeVi(requestedName)
        if (normReq.isEmpty()) return null

        // AN TOÀN TUYỆT ĐỐI CHO NGƯỜI DÙNG:
        // Chặn thao tác tự động can thiệp vào các ứng dụng Ngân hàng, Ví điện tử hoặc Cổng Dịch vụ công/VNeID của Nhà Nước
        val sensitiveNames = listOf(
            "vneid", "vssid", "dich vu cong", "cong dich vu cong", "etax", "thue dien tu",
            "ngan hang", "vietcombank", "techcombank", "mb bank", "mbbank", "bidv", "vietinbank",
            "agribank", "acb", "vpbank", "tpbank", "hdbank", "shb", "msb", "ocb", "sacombank",
            "viettel money", "momo", "zalopay", "vnpt pay", "vnpay", "shopeepay"
        )
        if (sensitiveNames.any { normReq == it || normReq.contains(it) }) {
            Toast.makeText(appCtx, "Vì lý do bảo mật, AI không tự động thao tác trên ứng dụng Ngân hàng và Cổng dịch vụ công Nhà Nước.", Toast.LENGTH_LONG).show()
            // Vẫn cho phép mở app lên nếu người dùng yêu cầu mở, nhưng chỉ mở app thuần túy không tự thao tác
        }

        // 0. Nếu là cài đặt con đặc biệt (Cài đặt Wi-Fi, Cài đặt Bluetooth, Cài đặt Âm thanh, Cài đặt Hiển thị, Chế độ nhà phát triển)
        if (normReq.contains("nha phat trien") || normReq.contains("developer option")) {
            return if (launchIntentSafely(appCtx, Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))) "Chế độ nhà phát triển" else null
        }
        if (normReq.contains("cai dat wifi") || normReq == "wifi") {
            return if (launchIntentSafely(appCtx, Intent(Settings.ACTION_WIFI_SETTINGS))) "Cài đặt Wi-Fi" else null
        }
        if (normReq.contains("cai dat bluetooth")) {
            return if (launchIntentSafely(appCtx, Intent(Settings.ACTION_BLUETOOTH_SETTINGS))) "Cài đặt Bluetooth" else null
        }
        if (normReq.contains("cai dat am thanh")) {
            return if (launchIntentSafely(appCtx, Intent(Settings.ACTION_SOUND_SETTINGS))) "Cài đặt Âm thanh" else null
        }
        if (normReq.contains("cai dat hien thi") || normReq.contains("cai dat man hinh")) {
            return if (launchIntentSafely(appCtx, Intent(Settings.ACTION_DISPLAY_SETTINGS))) "Cài đặt Hiển thị" else null
        }

        // 1. Kiểm tra danh sách Alias phổ biến trước
        val aliasPackages = knownAppAliases[normReq] ?: knownAppAliases.entries.firstOrNull { (k, _) ->
            normReq == k || normReq.replace(" ", "") == k.replace(" ", "")
        }?.value

        if (!aliasPackages.isNullOrEmpty()) {
            for (pkg in aliasPackages) {
                if (pkg == appCtx.packageName || pkg == "com.magictune.tool" || pkg == "com.example") {
                    val selfIntent = Intent(appCtx, MainActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    }
                    if (launchIntentSafely(appCtx, selfIntent)) return "MagicTune"
                }
                val launchIntent = pm.getLaunchIntentForPackage(pkg)
                if (launchIntent != null && launchIntentSafely(appCtx, launchIntent)) {
                    val label = try {
                        pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
                    } catch (_: Throwable) {
                        requestedName.replaceFirstChar { it.uppercase() }
                    }
                    return label
                }
            }
        }

        // 2. Quét toàn bộ danh sách ứng dụng có Launcher Icon trên thiết bị
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolveInfos = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.queryIntentActivities(mainIntent, PackageManager.ResolveInfoFlags.of(0L))
            } else {
                @Suppress("DEPRECATION")
                pm.queryIntentActivities(mainIntent, 0)
            }
        } catch (_: Throwable) {
            emptyList()
        }

        var bestPkg: String? = null
        var bestLabel: String? = null
        var bestScore = 0
        val compactReq = normReq.replace(" ", "")

        for (ri in resolveInfos) {
            val pkg = ri.activityInfo?.packageName ?: continue
            val rawLabel = try {
                ri.loadLabel(pm).toString().trim()
            } catch (_: Throwable) {
                ""
            }
            if (rawLabel.isEmpty()) continue
            val normLabel = normalizeVi(rawLabel)
            val compactLabel = normLabel.replace(" ", "")
            val normPkg = pkg.lowercase(Locale.ROOT)

            // Tạo từ viết tắt của tên app (ví dụ: Liên Quân Mobile -> lqm, Bản Đồ -> bd)
            val acronym = normLabel.split(" ").filter { it.isNotEmpty() }.map { it.first() }.joinToString("")

            val score = when {
                normLabel == normReq || compactLabel == compactReq -> 100
                acronym.isNotEmpty() && (acronym == normReq || acronym == compactReq) -> 95
                normLabel.startsWith(normReq) || compactLabel.startsWith(compactReq) -> 88
                normReq.startsWith(normLabel) && normLabel.length >= 3 -> 85
                normLabel.contains(normReq) || compactLabel.contains(compactReq) -> 76
                normReq.contains(normLabel) && normLabel.length >= 3 -> 68
                normPkg.contains(compactReq) && compactReq.length >= 3 -> 60
                normReq.split(" ").any { part -> part.length >= 3 && normLabel.contains(part) } -> 55
                else -> 0
            }

            if (score > bestScore) {
                bestScore = score
                bestPkg = pkg
                bestLabel = rawLabel
            }
        }

        if (bestPkg != null && bestScore >= 50) {
            val launchIntent = pm.getLaunchIntentForPackage(bestPkg)
            if (launchIntent != null && launchIntentSafely(appCtx, launchIntent)) {
                return bestLabel ?: requestedName
            }
            // Dự phòng qua ShellEngine nếu bật ADB / Shizuku
            val shell = ShellEngine.getInstance(appCtx)
            if (shell.state.value.isAdbReady) {
                try {
                    shell.execute("monkey -p $bestPkg -c android.intent.category.LAUNCHER 1 >/dev/null 2>&1")
                    return bestLabel ?: requestedName
                } catch (_: Throwable) {}
            }
        }

        return null
    }

    private fun launchYoutubeHome(context: Context) {
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
            setPackage("com.google.android.youtube")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        if (!launchIntentSafely(context, intent)) {
            val webUri = Uri.parse("https://www.youtube.com")
            launchIntentSafely(context, Intent(Intent.ACTION_VIEW, webUri))
        }
    }

    fun launchYoutubeSearch(context: Context, query: String, autoPlay: Boolean = true) {
        val appCtx = context.applicationContext
        val intent = Intent(Intent.ACTION_SEARCH).apply {
            setPackage("com.google.android.youtube")
            putExtra("query", query)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val launched = launchIntentSafely(appCtx, intent)
        if (!launched) {
            val webUri = Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode(query)}")
            launchIntentSafely(appCtx, Intent(Intent.ACTION_VIEW, webUri))
        }

        // TỰ ĐỘNG PHÁT VIDEO NGAY LẬP TỨC:
        // Sau khi ứng dụng YouTube mở trang kết quả, tự động nhấp vào video đầu tiên phù hợp để phát ngay,
        // người dùng không cần chạm tay vào màn hình!
        if (autoPlay) {
            val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
            scope.launch {
                for (retry in 0..5) {
                    delay(650L)
                    val clicked = MagicTuneCtsAccessibilityService.clickFirstVideoOrContentCard(appCtx)
                    if (clicked) break
                }
            }
        }
    }

    private fun launchGoogleMapsSearch(context: Context, query: String) {
        val gmmIntentUri = Uri.parse("geo:0,0?q=${Uri.encode(query)}")
        val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri).apply {
            setPackage("com.google.android.apps.maps")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        if (!launchIntentSafely(context, mapIntent)) {
            val webUri = Uri.parse("https://www.google.com/maps/search/?api=1&query=${Uri.encode(query)}")
            launchIntentSafely(context, Intent(Intent.ACTION_VIEW, webUri))
        }
    }

    private fun launchGoogleWebSearch(context: Context, query: String) {
        val webUri = Uri.parse("https://www.google.com/search?q=${Uri.encode(query)}&hl=vi")
        launchIntentSafely(context, Intent(Intent.ACTION_VIEW, webUri))
    }

    private fun launchIntentSafely(context: Context, intent: Intent): Boolean {
        return try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                val options = android.app.ActivityOptions.makeBasic().apply {
                    setPendingIntentBackgroundActivityStartMode(
                        @Suppress("DEPRECATION") android.app.ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED
                    )
                }
                context.startActivity(intent, options.toBundle())
            } else {
                context.startActivity(intent)
            }
            true
        } catch (_: Throwable) {
            try {
                context.startActivity(intent)
                true
            } catch (_: Throwable) {
                false
            }
        }
    }

    private fun setFlashlightState(context: Context, enabled: Boolean): Boolean {
        return try {
            val cm = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager ?: return false
            for (id in cm.cameraIdList) {
                try {
                    cm.setTorchMode(id, enabled)
                    return true
                } catch (_: Throwable) {}
            }
            false
        } catch (_: Throwable) {
            false
        }
    }

    private fun setMediaVolumePercent(context: Context, percent: Int): Int {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return percent
        val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val targetVol = ((percent.coerceIn(0, 100) / 100f) * maxVol).roundToInt().coerceIn(0, maxVol)
        try {
            am.setStreamVolume(AudioManager.STREAM_MUSIC, targetVol, AudioManager.FLAG_SHOW_UI)
        } catch (_: Throwable) {}
        return ((targetVol.toFloat() / maxVol) * 100f).roundToInt()
    }

    private fun adjustMediaVolumeByStep(context: Context, deltaPercent: Int): Int {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return 50
        val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val curVol = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        val curPct = ((curVol.toFloat() / maxVol) * 100f).roundToInt()
        val nextPct = (curPct + deltaPercent).coerceIn(0, 100)
        return setMediaVolumePercent(context, nextPct)
    }

    private suspend fun setScreenBrightnessPercent(context: Context, percent: Int): Int {
        val clamped = percent.coerceIn(5, 100)
        val brightnessVal = ((clamped / 100f) * 255f).roundToInt().coerceIn(10, 255)
        var success = false
        try {
            if (Settings.System.canWrite(context)) {
                Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, brightnessVal)
                success = true
            }
        } catch (_: Throwable) {}

        if (!success) {
            val shell = ShellEngine.getInstance(context.applicationContext)
            if (shell.state.value.isAdbReady) {
                try {
                    shell.execute("settings put system screen_brightness_mode 0; settings put system screen_brightness $brightnessVal")
                } catch (_: Throwable) {}
            }
        }
        return clamped
    }

    private suspend fun adjustScreenBrightnessByStep(context: Context, deltaPercent: Int): Int {
        val curVal = try {
            Settings.System.getInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, 140)
        } catch (_: Throwable) {
            140
        }
        val curPct = ((curVal / 255f) * 100f).roundToInt().coerceIn(5, 100)
        return setScreenBrightnessPercent(context, (curPct + deltaPercent).coerceIn(5, 100))
    }

    private suspend fun toggleWifiOrOpenPanel(context: Context, enable: Boolean) {
        val shell = ShellEngine.getInstance(context.applicationContext)
        if (shell.state.value.isAdbReady) {
            try {
                shell.execute(if (enable) "svc wifi enable" else "svc wifi disable")
                return
            } catch (_: Throwable) {}
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            if (!launchIntentSafely(context, Intent(Settings.Panel.ACTION_WIFI))) {
                launchIntentSafely(context, Intent(Settings.ACTION_WIFI_SETTINGS))
            }
        } else {
            launchIntentSafely(context, Intent(Settings.ACTION_WIFI_SETTINGS))
        }
    }

    private suspend fun toggleBluetoothDirectOrInSettings(context: Context, enable: Boolean) {
        val appCtx = context.applicationContext
        val shell = ShellEngine.getInstance(appCtx)
        if (shell.state.value.isAdbReady) {
            try {
                shell.execute(if (enable) "svc bluetooth enable" else "svc bluetooth disable")
                return
            } catch (_: Throwable) {}
        }
        launchIntentSafely(appCtx, Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
        kotlinx.coroutines.delay(450L)
        MagicTuneCtsAccessibilityService.toggleSettingSwitchByTitle(appCtx, "Bluetooth", enable)
    }
    /**
     * Tra cứu nhanh thời tiết thực tế (nhiệt độ, cảm giác thực tế, tình trạng mưa/nắng) và dịch sang tiếng Việt tự nhiên
     * để AI đọc to thành tiếng ngay cho người dùng nghe rảnh tay 100%.
     */
    fun fetchInstantWeatherSummary(userQuery: String): String? {
        return try {
            val queryLower = userQuery.lowercase(Locale.ROOT)
            val city = when {
                queryLower.contains("ha noi") || queryLower.contains("hà nội") -> "Hanoi"
                queryLower.contains("ho chi minh") || queryLower.contains("hồ chí minh") || queryLower.contains("sai gon") || queryLower.contains("sài gòn") -> "Ho_Chi_Minh_City"
                queryLower.contains("da nang") || queryLower.contains("đà nẵng") -> "Da_Nang"
                queryLower.contains("hai phong") || queryLower.contains("hải phòng") -> "Hai_Phong"
                queryLower.contains("can tho") || queryLower.contains("cần thơ") -> "Can_Tho"
                queryLower.contains("nha trang") -> "Nha_Trang"
                queryLower.contains("hue") || queryLower.contains("huế") -> "Hue"
                queryLower.contains("da lat") || queryLower.contains("đà lạt") -> "Da_Lat"
                queryLower.contains("vung tau") || queryLower.contains("vũng tàu") -> "Vung_Tau"
                queryLower.contains("quy nhon") || queryLower.contains("quy nhơn") -> "Quy_Nhon"
                else -> "Hanoi"
            }
            val url = java.net.URL("https://wttr.in/${java.net.URLEncoder.encode(city, "UTF-8")}?format=j1")
            val conn = (url.openConnection() as java.net.HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 3200
                readTimeout = 4000
                setRequestProperty("User-Agent", "curl/7.68.0")
            }
            if (conn.responseCode in 200..299) {
                val jsonStr = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                val root = org.json.JSONObject(jsonStr)
                val cur = root.optJSONArray("current_condition")?.optJSONObject(0) ?: return null
                val tempC = cur.optString("temp_C", "")
                val feelsLikeC = cur.optString("FeelsLikeC", "")
                val rawDesc = cur.optJSONArray("weatherDesc")?.optJSONObject(0)?.optString("value", "").orEmpty()
                val humidity = cur.optString("humidity", "")

                val viDesc = when {
                    rawDesc.contains("Sunny", ignoreCase = true) || rawDesc.contains("Clear", ignoreCase = true) -> "trời nắng ráo, quang đãng"
                    rawDesc.contains("Partly cloudy", ignoreCase = true) -> "trời có mây, nắng gián đoạn"
                    rawDesc.contains("Cloudy", ignoreCase = true) || rawDesc.contains("Overcast", ignoreCase = true) -> "trời nhiều mây, râm mát"
                    rawDesc.contains("Patchy rain", ignoreCase = true) || rawDesc.contains("Light rain", ignoreCase = true) -> "có mưa rào nhẹ rải rác"
                    rawDesc.contains("Heavy rain", ignoreCase = true) || rawDesc.contains("Moderate rain", ignoreCase = true) -> "có mưa to"
                    rawDesc.contains("Thunder", ignoreCase = true) -> "có dông và sấm sét"
                    rawDesc.contains("Fog", ignoreCase = true) || rawDesc.contains("Mist", ignoreCase = true) -> "có sương mù"
                    else -> rawDesc
                }

                val cityDisplay = when (city) {
                    "Hanoi" -> "Hà Nội"
                    "Ho_Chi_Minh_City" -> "Hồ Chí Minh"
                    "Da_Nang" -> "Đà Nẵng"
                    "Hai_Phong" -> "Hải Phòng"
                    "Can_Tho" -> "Cần Thơ"
                    "Nha_Trang" -> "Nha Trang"
                    "Hue" -> "Huế"
                    "Da_Lat" -> "Đà Lạt"
                    "Vung_Tau" -> "Vũng Tàu"
                    "Quy_Nhon" -> "Quy Nhơn"
                    else -> "khu vực của bạn"
                }

                if (tempC.isNotBlank()) {
                    val feelsText = if (feelsLikeC.isNotBlank() && feelsLikeC != tempC) ", cảm giác như ${feelsLikeC} độ" else ""
                    val humText = if (humidity.isNotBlank()) ", độ ẩm ${humidity}%" else ""
                    "Thời tiết tại $cityDisplay hiện tại là ${tempC} độ C$feelsText, $viDesc$humText."
                } else null
            } else null
        } catch (_: Throwable) {
            null
        }
    }
}
