package com.example.core.shell

import kotlinx.coroutines.delay

data class UiNode(
    val text: String,
    val contentDesc: String,
    val resourceId: String,
    val className: String,
    val checkable: Boolean,
    val checked: Boolean,
    val clickable: Boolean,
    val enabled: Boolean,
    val left: Int,
    val top: Int,
    val right: Int,
    val bottom: Int
) {
    val centerX: Int get() = (left + right) / 2
    val centerY: Int get() = (top + bottom) / 2
    val width: Int get() = (right - left).coerceAtLeast(0)
    val height: Int get() = (bottom - top).coerceAtLeast(0)

    val isSwitchLike: Boolean
        get() = checkable ||
            className.contains("Switch", ignoreCase = true) ||
            className.contains("HwSwitch", ignoreCase = true) ||
            className.contains("CheckBox", ignoreCase = true) ||
            className.contains("CompoundButton", ignoreCase = true) ||
            className.contains("ToggleButton", ignoreCase = true) ||
            resourceId.contains("switch", ignoreCase = true) ||
            resourceId.contains("checkbox", ignoreCase = true) ||
            resourceId.contains("hwswitch", ignoreCase = true)
}

data class UiSwitchMatch(
    val labelNode: UiNode,
    val switchNode: UiNode,
    val isChecked: Boolean,
    val tapX: Int,
    val tapY: Int
)

data class VisualToggleReport(
    val packageName: String,
    val appName: String,
    val openedSettingsOk: Boolean,
    val masterNotifTurnedOn: Boolean,
    val gentleTurnedOff: Boolean,
    val bannerTurnedOn: Boolean,
    val lockScreenTurnedOn: Boolean,
    val soundTurnedOn: Boolean = false,
    val vibrateTurnedOn: Boolean = false,
    val badgeTurnedOn: Boolean = false,
    val detailMessage: String
)

data class DumpsysNotifPkgStatus(
    val packageName: String,
    val foundInDumpsys: Boolean,
    val hasLowOrGentleChannel: Boolean,
    val hasDefaultNoBannerChannel: Boolean,
    val hasHighBannerChannel: Boolean
) {
    val needsGentleOrBannerFix: Boolean
        get() = hasLowOrGentleChannel || hasDefaultNoBannerChannel || !hasHighBannerChannel
}

object UiAutomatorSwitchHelper {

    private val nodeRegex = Regex("""<node\s+([^>]+?)/?>""")
    private val attrRegex = Regex("""([a-zA-Z0-9_-]+)="([^"]*)"""")
    private val boundsRegex = Regex("""\[(\d+),(\d+)\]\[(\d+),(\d+)\]""")

    /**
     * Parses uiautomator XML hierarchy dump into a flat list of UiNode items.
     */
    fun parseUiNodes(xmlContent: String): List<UiNode> {
        if (xmlContent.isBlank() || !xmlContent.contains("<node")) return emptyList()
        val list = mutableListOf<UiNode>()
        for (match in nodeRegex.findAll(xmlContent)) {
            val attrsRaw = match.groupValues[1]
            val attrs = HashMap<String, String>()
            for (attrMatch in attrRegex.findAll(attrsRaw)) {
                attrs[attrMatch.groupValues[1]] = attrMatch.groupValues[2]
            }
            val boundsStr = attrs["bounds"] ?: continue
            val bMatch = boundsRegex.find(boundsStr) ?: continue
            val l = bMatch.groupValues[1].toIntOrNull() ?: continue
            val t = bMatch.groupValues[2].toIntOrNull() ?: continue
            val r = bMatch.groupValues[3].toIntOrNull() ?: continue
            val b = bMatch.groupValues[4].toIntOrNull() ?: continue
            if (r <= l || b <= t) continue

            val textVal = attrs["text"]?.trim().orEmpty()
            val descVal = attrs["content-desc"]?.trim().orEmpty()
            val checkedAttr = attrs["checked"] == "true" ||
                attrs["selected"] == "true" ||
                descVal.equals("đã bật", ignoreCase = true) ||
                descVal.equals("on", ignoreCase = true)

            list.add(
                UiNode(
                    text = textVal,
                    contentDesc = descVal,
                    resourceId = attrs["resource-id"]?.trim().orEmpty(),
                    className = attrs["class"]?.trim().orEmpty(),
                    checkable = attrs["checkable"] == "true",
                    checked = checkedAttr,
                    clickable = attrs["clickable"] == "true",
                    enabled = attrs["enabled"] != "false",
                    left = l,
                    top = t,
                    right = r,
                    bottom = b
                )
            )
        }
        return list
    }

    /**
     * Finds the Switch/CheckBox node associated with a row label (e.g. "Thông báo nhẹ nhàng", "Biểu ngữ").
     */
    fun findSwitchForLabel(
        nodes: List<UiNode>,
        keywords: List<String>,
        excludeKeywords: List<String> = emptyList()
    ): UiSwitchMatch? {
        val labelCandidates = nodes.filter { node ->
            val combined = "${node.text} ${node.contentDesc}".lowercase()
            combined.isNotBlank() &&
                keywords.any { kw -> combined.contains(kw.lowercase()) } &&
                excludeKeywords.none { ex -> combined.contains(ex.lowercase()) }
        }
        if (labelCandidates.isEmpty()) return null

        val switchCandidates = nodes.filter { it.isSwitchLike && it.enabled }

        for (label in labelCandidates) {
            // Case 1: The label node itself is a Switch / CheckBox
            if (label.isSwitchLike) {
                return UiSwitchMatch(
                    labelNode = label,
                    switchNode = label,
                    isChecked = label.checked,
                    tapX = label.centerX,
                    tapY = label.centerY
                )
            }

            // Case 2: Standard Settings Row (Label on the left, Switch on the right within same vertical band)
            val rowSwitch = switchCandidates
                .filter { sw ->
                    sw.centerX > label.left &&
                        sw.top <= label.bottom + 260 &&
                        sw.bottom >= label.top - 200
                }
                .minByOrNull { sw -> kotlin.math.abs(sw.centerY - label.centerY) }

            if (rowSwitch != null) {
                return UiSwitchMatch(
                    labelNode = label,
                    switchNode = rowSwitch,
                    isChecked = rowSwitch.checked,
                    tapX = rowSwitch.centerX,
                    tapY = rowSwitch.centerY
                )
            }

            // Case 3: Card / Column Style (e.g., 3-card notification style where checkbox is directly below/above label)
            val cardSwitch = switchCandidates
                .filter { sw ->
                    kotlin.math.abs(sw.centerX - label.centerX) <= 200 &&
                        kotlin.math.abs(sw.centerY - label.centerY) <= 300
                }
                .minByOrNull { sw -> kotlin.math.abs(sw.centerY - label.centerY) }

            if (cardSwitch != null) {
                return UiSwitchMatch(
                    labelNode = label,
                    switchNode = cardSwitch,
                    isChecked = cardSwitch.checked,
                    tapX = cardSwitch.centerX,
                    tapY = cardSwitch.centerY
                )
            }

            // Case 4: Clickable Row Fallback (If row itself is clickable, tap directly on row center)
            if (label.clickable || label.enabled) {
                return UiSwitchMatch(
                    labelNode = label,
                    switchNode = label,
                    isChecked = label.checked,
                    tapX = label.centerX,
                    tapY = label.centerY
                )
            }
        }
        return null
    }

    private suspend fun dumpCurrentScreenNodes(shellEngine: ShellEngine): List<UiNode> {
        // Dùng --compressed giúp uiautomator dump nhanh gấp 3 lần và bỏ qua các node trang trí rỗng
        val fastDumpCmd =
            "uiautomator dump --compressed /data/local/tmp/mt_ui.xml >/dev/null 2>&1 && cat /data/local/tmp/mt_ui.xml"
        val res = shellEngine.execute(fastDumpCmd)
        val parsed = parseUiNodes(res.output)
        if (parsed.isNotEmpty()) return parsed

        // Fallback: Giải phóng uiautomator bị kẹt (nếu có) và dump lại ngay
        val retryCmd =
            "pkill -f uiautomator >/dev/null 2>&1; uiautomator dump --compressed /data/local/tmp/mt_ui.xml >/dev/null 2>&1 && cat /data/local/tmp/mt_ui.xml || (uiautomator dump /sdcard/mt_ui.xml >/dev/null 2>&1 && cat /sdcard/mt_ui.xml)"
        val retryRes = shellEngine.execute(retryCmd)
        return parseUiNodes(retryRes.output)
    }

    /**
     * Automatically opens the target app's Notification Settings page on the phone screen,
     * reads the real switch states via fast compressed uiautomator, and physically taps:
     * - "Cho phép thông báo" -> ON (if OFF)
     * - "Thông báo nhẹ nhàng" (Gentle notifications) -> OFF (if ON)
     * - "Biểu ngữ" (Banners / Heads-up) -> ON (if OFF)
     * - "Màn hình khóa" (Lock screen) -> ON (if switch is OFF)
     * right in front of the user's eyes using batched shell taps for 3x faster speed!
     */
    suspend fun autoToggleAppNotificationScreen(
        shellEngine: ShellEngine,
        pkg: String,
        appName: String,
        pressBackWhenDone: Boolean = false,
        onProgressUpdate: (String) -> Unit = {},
        onLog: (String) -> Unit
    ): VisualToggleReport {
        onProgressUpdate("Đang mở trang Cài đặt Thông báo của $appName...")
        onLog("⚡ [Auto-Click Turbo] Mở nhanh Cài đặt Thông báo của $appName ($pkg)...")

        val openCmd =
            "am start --user 0 --activity-clear-top --activity-single-top --activity-no-animation -a android.settings.APP_NOTIFICATION_SETTINGS --es android.provider.extra.APP_PACKAGE $pkg --es app_package $pkg >/dev/null 2>&1"
        val openRes = shellEngine.execute(openCmd)
        if (!openRes.isSuccess) {
            return VisualToggleReport(
                packageName = pkg,
                appName = appName,
                openedSettingsOk = false,
                masterNotifTurnedOn = false,
                gentleTurnedOff = false,
                bannerTurnedOn = false,
                lockScreenTurnedOn = false,
                detailMessage = "Không thể mở trang Cài đặt Thông báo cho $appName"
            )
        }

        // Nhờ --activity-no-animation, màn hình Cài đặt hiển thị ngay lập tức chỉ sau ~340ms
        delay(340)

        onProgressUpdate("Đang quét tọa độ công tắc Thông báo nhẹ nhàng & Biểu ngữ...")
        var nodes = dumpCurrentScreenNodes(shellEngine)
        if (nodes.isEmpty()) {
            delay(220)
            nodes = dumpCurrentScreenNodes(shellEngine)
        }

        var masterTurnedOn = false
        var gentleTurnedOff = false
        var bannerTurnedOn = false
        var lockScreenTurnedOn = false
        var soundTurnedOn = false
        var vibrateTurnedOn = false
        var badgeTurnedOn = false
        val actionsTaken = mutableListOf<String>()

        // 1. Kiểm tra công tắc tổng: "Cho phép thông báo" / "Allow notifications" / "允许通知"
        val masterMatch = findSwitchForLabel(
            nodes = nodes,
            keywords = listOf("cho phép thông báo", "allow notifications", "hiển thị thông báo", "cho phép", "允许通知"),
            excludeKeywords = listOf("nhẹ nhàng", "biểu ngữ", "âm thanh", "rung")
        )
        if (masterMatch != null && !masterMatch.isChecked) {
            onProgressUpdate("⚡ Gạt BẬT 'Cho phép thông báo' tại (${masterMatch.tapX}, ${masterMatch.tapY})...")
            onLog("👉 'Cho phép thông báo' của $appName đang TẮT -> Gạt BẬT tại (${masterMatch.tapX}, ${masterMatch.tapY})...")
            shellEngine.execute("input tap ${masterMatch.tapX} ${masterMatch.tapY}")
            masterTurnedOn = true
            actionsTaken.add("Bật Cho phép thông báo")
            delay(320)
            nodes = dumpCurrentScreenNodes(shellEngine)
        }

        // Hàm quét và gạt đồng loạt toàn diện cho MagicOS 11:
        // Thông báo nhẹ nhàng (TẮT) + Biểu ngữ (BẬT) + Màn hình khóa (BẬT) + Âm thanh (BẬT) + Rung (BẬT) + Huy hiệu (BẬT)
        suspend fun inspectAndToggleMagicOS11Switches(currentNodes: List<UiNode>): Boolean {
            var foundAnyTargetRow = false
            val batchedTaps = mutableListOf<String>()

            // 2. "Thông báo nhẹ nhàng" / "Gentle notifications" -> BẮT BUỘC TẮT (OFF)
            val gentleMatch = findSwitchForLabel(
                nodes = currentNodes,
                keywords = listOf("thông báo nhẹ nhàng", "báo nhẹ nhàng", "gentle notification", "gentle", "im lặng", "静默通知", "静音", "tiêu đề nhẹ nhàng")
            )
            var needRedumpForBanner = false
            if (gentleMatch != null) {
                foundAnyTargetRow = true
                if (gentleMatch.isChecked) {
                    onProgressUpdate("⚡ Gạt TẮT 'Thông báo nhẹ nhàng' tại (${gentleMatch.tapX}, ${gentleMatch.tapY})...")
                    onLog("👉 'Thông báo nhẹ nhàng' của $appName đang BẬT -> Gạt TẮT tại (${gentleMatch.tapX}, ${gentleMatch.tapY})!")
                    batchedTaps.add("input tap ${gentleMatch.tapX} ${gentleMatch.tapY}")
                    gentleTurnedOff = true
                    actionsTaken.add("Tắt Thông báo nhẹ nhàng")
                } else {
                    actionsTaken.add("Thông báo nhẹ nhàng đã TẮT")
                }
            }

            // 3. "Biểu ngữ" / "Banners" / "横幅" -> BẮT BUỘC BẬT (ON)
            val bannerMatch = findSwitchForLabel(
                nodes = currentNodes,
                keywords = listOf("biểu ngữ", "banners", "banner", "thông báo nổi", "hiển thị biểu ngữ", "横幅", "横幅通知", "cửa sổ bật lên", "hiển thị dạng biểu ngữ")
            )
            if (bannerMatch != null) {
                foundAnyTargetRow = true
                if (!bannerMatch.isChecked) {
                    onProgressUpdate("⚡ Gạt BẬT 'Biểu ngữ' tại (${bannerMatch.tapX}, ${bannerMatch.tapY})...")
                    onLog("👉 'Biểu ngữ' của $appName đang TẮT -> Gạt BẬT tại (${bannerMatch.tapX}, ${bannerMatch.tapY})!")
                    batchedTaps.add("input tap ${bannerMatch.tapX} ${bannerMatch.tapY}")
                    bannerTurnedOn = true
                    actionsTaken.add("Bật Biểu ngữ nổi")
                } else {
                    actionsTaken.add("Biểu ngữ đã BẬT")
                }
            } else if (gentleTurnedOff) {
                needRedumpForBanner = true
            }

            // 4. "Màn hình khóa" / "Lock screen" -> BẮT BUỘC BẬT (ON)
            val lockMatch = findSwitchForLabel(
                nodes = currentNodes,
                keywords = listOf("thông báo trên màn hình khóa", "màn hình khóa", "lock screen", "锁屏通知", "hiển thị trên màn hình khóa", "nội dung màn hình khóa")
            )
            if (lockMatch != null && !lockMatch.isChecked) {
                foundAnyTargetRow = true
                batchedTaps.add("input tap ${lockMatch.tapX} ${lockMatch.tapY}")
                lockScreenTurnedOn = true
                actionsTaken.add("Bật Màn hình khóa")
            }

            // 5. "Âm thanh" / "Sound" / "Ringtone" trên MagicOS 11 -> BẮT BUỘC BẬT (ON)
            val soundMatch = findSwitchForLabel(
                nodes = currentNodes,
                keywords = listOf("âm thanh", "chuông", "sound", "ringtone", "tiếng chuông", "声音", "铃声", "phát âm thanh", "nhạc chuông"),
                excludeKeywords = listOf("nhẹ nhàng", "rung", "biểu ngữ")
            )
            if (soundMatch != null && !soundMatch.isChecked) {
                foundAnyTargetRow = true
                batchedTaps.add("input tap ${soundMatch.tapX} ${soundMatch.tapY}")
                soundTurnedOn = true
                actionsTaken.add("Bật Âm thanh chuông")
            }

            // 6. "Rung" / "Vibration" trên MagicOS 11 -> BẮT BUỘC BẬT (ON)
            val vibrateMatch = findSwitchForLabel(
                nodes = currentNodes,
                keywords = listOf("rung", "vibrate", "vibration", "chấn động", "震动", "rung khi có thông báo")
            )
            if (vibrateMatch != null && !vibrateMatch.isChecked) {
                foundAnyTargetRow = true
                batchedTaps.add("input tap ${vibrateMatch.tapX} ${vibrateMatch.tapY}")
                vibrateTurnedOn = true
                actionsTaken.add("Bật Rung")
            }

            // 7. "Huy hiệu biểu tượng ứng dụng" / "Badges" trên MagicOS 11 -> BẮT BUỘC BẬT (ON)
            val badgeMatch = findSwitchForLabel(
                nodes = currentNodes,
                keywords = listOf("huy hiệu biểu tượng ứng dụng", "huy hiệu", "dấu chấm", "app icon badges", "badges", "角标", "应用图标角标", "dấu chấm thông báo")
            )
            if (badgeMatch != null && !badgeMatch.isChecked) {
                foundAnyTargetRow = true
                batchedTaps.add("input tap ${badgeMatch.tapX} ${badgeMatch.tapY}")
                badgeTurnedOn = true
                actionsTaken.add("Bật Huy hiệu icon")
            }

            // Thực thi toàn bộ thao tác gạt công tắc trong 1 lượt mượt mà
            if (batchedTaps.isNotEmpty()) {
                val combinedTapCmd = batchedTaps.joinToString("; sleep 0.16; ")
                shellEngine.execute(combinedTapCmd)
                delay(240)
            }

            // Nếu vừa tắt Báo nhẹ nhàng mà Biểu ngữ lúc đầu bị ẩn thì quét bổ sung
            if (needRedumpForBanner) {
                val afterGentleNodes = dumpCurrentScreenNodes(shellEngine)
                val postBannerMatch = findSwitchForLabel(
                    nodes = afterGentleNodes,
                    keywords = listOf("biểu ngữ", "banners", "banner", "thông báo nổi", "hiển thị biểu ngữ", "横幅")
                )
                if (postBannerMatch != null && !postBannerMatch.isChecked) {
                    onProgressUpdate("⚡ Gạt BẬT 'Biểu ngữ' tại (${postBannerMatch.tapX}, ${postBannerMatch.tapY})...")
                    shellEngine.execute("input tap ${postBannerMatch.tapX} ${postBannerMatch.tapY}")
                    bannerTurnedOn = true
                    actionsTaken.add("Bật Biểu ngữ nổi")
                    delay(200)
                }
            }

            return foundAnyTargetRow
        }

        // Lượt 1: Quét và gạt các công tắc trên phần nhìn thấy đầu tiên
        inspectAndToggleMagicOS11Switches(nodes)

        // Lượt 2: Cuộn màn hình để quét triệt để các mục dưới mép của MagicOS 11 (Âm thanh, Rung, Huy hiệu, Danh mục)
        onProgressUpdate("Đang cuộn xuống quét các công tắc Âm thanh, Rung & Biểu ngữ MagicOS 11...")
        shellEngine.execute("input swipe 540 1450 540 680 180")
        delay(300)
        val scrolledNodes = dumpCurrentScreenNodes(shellEngine)
        if (scrolledNodes.isNotEmpty()) {
            inspectAndToggleMagicOS11Switches(scrolledNodes)
        }

        // 8. ĐIỀU KHIỂN TỰ ĐỘNG BẤM VÀO TỪNG DANH MỤC / KÊNH THÔNG BÁO (NOTIFICATION CHANNELS):
        // Bấm vào từng danh mục (Tin nhắn, Cuộc gọi, Nhóm, Trò chuyện...), tắt Nhẹ nhàng & bật Biểu ngữ + Âm thanh + Rung rồi quay ra
        val allInspectedNodes = if (scrolledNodes.isNotEmpty()) scrolledNodes else nodes
        val channelRows = findClickableChannelRows(allInspectedNodes)
        if (channelRows.isNotEmpty()) {
            val maxChannelsToVisit = 5
            for ((index, channel) in channelRows.take(maxChannelsToVisit).withIndex()) {
                val chName = channel.text.ifBlank { "Mục thông báo #${index + 1}" }
                onProgressUpdate("👉 Bấm vào mục '$chName' để kích hoạt Biểu ngữ & Âm thanh MagicOS 11...")
                onLog("👉 [MagicOS 11 Turbo] Tự bấm vào mục '$chName' tại (${channel.centerX}, ${channel.centerY})...")

                // Chạm vào mục con
                shellEngine.execute("input tap ${channel.centerX} ${channel.centerY}")
                delay(380)

                // Quét và gạt công tắc trong trang chi tiết của mục con
                val subNodes = dumpCurrentScreenNodes(shellEngine)
                if (subNodes.isNotEmpty()) {
                    val toggledInSub = inspectAndToggleMagicOS11Switches(subNodes)
                    if (toggledInSub) {
                        actionsTaken.add("Mục $chName: Đủ Biểu ngữ & Chuông")
                    }
                    delay(260)
                }

                // Tự bấm Back quay lại danh sách
                onProgressUpdate("🔙 Đã gạt xong mục '$chName' ➔ Quay ra...")
                shellEngine.execute("input keyevent 4")
                delay(320)
            }
        }

        if (pressBackWhenDone) {
            delay(180)
            shellEngine.execute("input keyevent 4 >/dev/null 2>&1 || true")
        } else {
            delay(160)
        }

        val summary = if (actionsTaken.isNotEmpty()) {
            actionsTaken.distinct().joinToString(" • ")
        } else {
            "Đã kiểm tra & gạt chuẩn toàn bộ công tắc MagicOS 11"
        }
        onProgressUpdate("✅ $appName: $summary")

        return VisualToggleReport(
            packageName = pkg,
            appName = appName,
            openedSettingsOk = true,
            masterNotifTurnedOn = masterTurnedOn,
            gentleTurnedOff = gentleTurnedOff,
            bannerTurnedOn = bannerTurnedOn,
            lockScreenTurnedOn = lockScreenTurnedOn,
            soundTurnedOn = soundTurnedOn,
            vibrateTurnedOn = vibrateTurnedOn,
            badgeTurnedOn = badgeTurnedOn,
            detailMessage = summary
        )
    }

    /**
     * Parses `dumpsys notification --noredact` output to detect real per-app NotificationChannel importance.
     * On Android / Honor MagicOS:
     * - importance=1 (MIN) or importance=2 (LOW) = "Thông báo nhẹ nhàng" (Gentle Notification, no sound, no banner).
     * - importance=3 (DEFAULT) = Sound allowed, but NO Banner (Heads-up pop-up).
     * - importance=4 (HIGH) or importance=5 (MAX) = Full Banner (Biểu ngữ nổi) + Sound enabled!
     */
    fun parseDumpsysNotificationChannels(
        dumpsysOutput: String,
        targetPackages: Set<String>
    ): Map<String, DumpsysNotifPkgStatus> {
        if (dumpsysOutput.isBlank()) return emptyMap()
        val result = HashMap<String, DumpsysNotifPkgStatus>()

        var currentPkg: String? = null
        var hasLow = false
        var hasDefault = false
        var hasHigh = false

        fun flushCurrent() {
            val pkg = currentPkg ?: return
            if (pkg in targetPackages) {
                val prev = result[pkg]
                result[pkg] = DumpsysNotifPkgStatus(
                    packageName = pkg,
                    foundInDumpsys = true,
                    hasLowOrGentleChannel = (prev?.hasLowOrGentleChannel ?: false) || hasLow,
                    hasDefaultNoBannerChannel = (prev?.hasDefaultNoBannerChannel ?: false) || hasDefault,
                    hasHighBannerChannel = (prev?.hasHighBannerChannel ?: false) || hasHigh
                )
            }
        }

        val pkgHeaderRegex = Regex("""(?:AppSettings:\s+|PackagePreferences:\s+|pkg=)([a-zA-Z0-9_.]+)""")
        val importanceRegex = Regex("""(?:mImportance|importance)=(\d)""", RegexOption.IGNORE_CASE)

        for (rawLine in dumpsysOutput.lineSequence()) {
            val line = rawLine.trim()
            val pkgMatch = pkgHeaderRegex.find(line)
            if (pkgMatch != null) {
                flushCurrent()
                currentPkg = pkgMatch.groupValues[1]
                hasLow = false
                hasDefault = false
                hasHigh = false
            }

            if (currentPkg != null && (line.contains("NotificationChannel", ignoreCase = true) || line.contains("importance=", ignoreCase = true))) {
                val impMatch = importanceRegex.find(line)
                val imp = impMatch?.groupValues?.get(1)?.toIntOrNull()
                if (imp != null) {
                    when (imp) {
                        1, 2 -> hasLow = true
                        3 -> hasDefault = true
                        4, 5 -> hasHigh = true
                    }
                }
                if (line.contains("gentle=true", ignoreCase = true) ||
                    line.contains("mGentle=true", ignoreCase = true)
                ) {
                    hasLow = true
                }
                if (line.contains("showBanner=false", ignoreCase = true) ||
                    line.contains("canShowBanner=false", ignoreCase = true)
                ) {
                    hasDefault = true
                }
            }
        }
        flushCurrent()
        return result
    }

    /**
     * Tìm các dòng danh mục / kênh thông báo có thể bấm vào được (Tin nhắn, Cuộc gọi, Nhóm, Trò chuyện...)
     */
    fun findClickableChannelRows(nodes: List<UiNode>): List<UiNode> {
        val excludeKeywords = listOf(
            "cho phép thông báo", "allow notifications", "thông báo nhẹ nhàng", "gentle notification",
            "biểu ngữ", "banners", "màn hình khóa", "lock screen", "âm thanh", "sound", "rung", "vibrate",
            "dấu chấm", "huy hiệu", "badge", "cài đặt bổ sung", "thông báo từ ứng dụng này", "danh mục thông báo",
            "loại thông báo", "khóa", "tất cả", "xem tất cả", "tìm kiếm"
        )
        val channelKeywords = listOf(
            "tin nhắn", "cuộc gọi", "trò chuyện", "thông báo", "chat", "call", "message", "direct",
            "nhóm", "bình luận", "khác", "đơn hàng", "khuyến mãi", "nhắc nhở", "tài khoản", "giao dịch",
            "cá nhân", "friends", "general", "default", "alert", "voice", "video"
        )

        val candidates = nodes.filter { node ->
            val txt = node.text.trim().lowercase()
            val desc = node.contentDesc.trim().lowercase()
            val combined = "$txt $desc"

            val isExcluded = excludeKeywords.any { combined.contains(it) } || combined.length < 2 || combined.length > 45
            val isNotSwitch = !node.isSwitchLike
            val isChannelKeyword = channelKeywords.any { combined.contains(it) }
            val isClickableRow = (node.clickable || node.className.contains("TextView") || node.className.contains("LinearLayout")) && node.top > 380

            !isExcluded && isNotSwitch && (isChannelKeyword || isClickableRow)
        }

        val distinctRows = mutableListOf<UiNode>()
        for (cand in candidates) {
            if (distinctRows.none { kotlin.math.abs(it.centerY - cand.centerY) < 45 }) {
                distinctRows.add(cand)
            }
        }
        return distinctRows
    }
}
