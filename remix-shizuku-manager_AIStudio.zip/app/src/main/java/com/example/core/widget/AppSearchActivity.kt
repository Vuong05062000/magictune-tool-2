package com.example.core.widget

import android.app.Activity
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class AppSearchEntry(
    val packageName: String,
    val appName: String,
    val icon: Drawable?,
    val isSystemApp: Boolean
)

object RecentAppsHistoryManager {
    private const val PREFS_NAME = "magictune_recent_apps"
    private const val KEY_HISTORY = "recent_packages"

    /**
     * Kiểm tra xem một package có phải là app người dùng hoặc app Cài đặt cho phép hiển thị hay không.
     * TUYỆT ĐỐI LOẠI BỎ: Các service ngầm, launcher, input method, systemui, overlay, google play services...
     */
    fun isAllowedUserApp(context: Context, packageName: String): Boolean {
        // Cho phép hiển thị app Cài Đặt của hệ thống
        if (packageName == "com.android.settings" || packageName == "com.hihonor.systemmanager") {
            return true
        }
        // Loại bỏ chính MagicTune, launcher màn hình chính, bàn phím, Google Services
        if (packageName == context.packageName) return false
        if (packageName.startsWith("com.google.android.gms") ||
            packageName.startsWith("com.google.android.gsf") ||
            packageName.contains("systemui", ignoreCase = true) ||
            packageName.contains("launcher", ignoreCase = true) ||
            packageName.contains("inputmethod", ignoreCase = true) ||
            packageName.contains("powergenius", ignoreCase = true) ||
            packageName.contains("iaware", ignoreCase = true) ||
            packageName.contains("keyguard", ignoreCase = true)) {
            return false
        }

        return try {
            val pm = context.packageManager
            val appInfo = pm.getApplicationInfo(packageName, 0)
            val isSystem = (appInfo.flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM) != 0
            val isUpdatedSystem = (appInfo.flags and android.content.pm.ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
            val hasLaunchIntent = try { pm.getLaunchIntentForPackage(packageName) != null } catch (_: Exception) { false }

            !isSystem || isUpdatedSystem || hasLaunchIntent
        } catch (_: Exception) {
            false
        }
    }

    fun getRecentPackageNames(context: Context): List<String> {
        val result = mutableListOf<String>()

        // 1. Thử lấy từ UsageStatsManager (Hệ thống Android theo dõi chính xác app mở gần đây nhất)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
            try {
                val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
                val endTime = System.currentTimeMillis()
                val startTime = endTime - 1000L * 60 * 60 * 24 * 7 // 7 ngày gần nhất
                val stats = usm?.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, startTime, endTime)
                if (!stats.isNullOrEmpty()) {
                    val sorted = stats.filter { it.lastTimeUsed > 0 && isAllowedUserApp(context, it.packageName) }
                        .sortedByDescending { it.lastTimeUsed }
                        .map { it.packageName }
                        .distinct()
                    if (sorted.isNotEmpty()) {
                        result.addAll(sorted.take(20))
                    }
                }
            } catch (_: Exception) {}
        }

        // 2. Kết hợp với lịch sử cục bộ lưu trong SharedPreferences (luôn hoạt động 100%)
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val savedRaw = prefs.getString(KEY_HISTORY, "") ?: ""
        if (savedRaw.isNotBlank()) {
            val savedList = savedRaw.split(",").filter { it.isNotBlank() && isAllowedUserApp(context, it) }
            for (pkg in savedList) {
                if (!result.contains(pkg)) {
                    result.add(pkg)
                }
            }
        }

        return result.take(20)
    }

    fun recordAppLaunched(context: Context, packageName: String) {
        if (!isAllowedUserApp(context, packageName)) return
        try {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val savedRaw = prefs.getString(KEY_HISTORY, "") ?: ""
            val list = savedRaw.split(",").filter { it.isNotBlank() && it != packageName }.toMutableList()
            list.add(0, packageName)
            val updated = list.take(20).joinToString(",")
            prefs.edit().putString(KEY_HISTORY, updated).apply()
        } catch (_: Exception) {}
    }
}

class AppSearchActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            AppSearchScreen(
                onDismiss = { finish() },
                onLaunchApp = { pkg ->
                    RecentAppsHistoryManager.recordAppLaunched(this, pkg)
                    try {
                        val launchIntent = packageManager.getLaunchIntentForPackage(pkg)
                        if (launchIntent != null) {
                            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            startActivity(launchIntent)
                        } else {
                            val detailsIntent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                data = Uri.parse("package:$pkg")
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            startActivity(detailsIntent)
                        }
                    } catch (_: Exception) {}
                    finish()
                },
                onOpenAppManagementSettings = {
                    try {
                        val manageIntent = Intent(Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        startActivity(manageIntent)
                    } catch (_: Exception) {
                        try {
                            val altIntent = Intent(Settings.ACTION_APPLICATION_SETTINGS).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            startActivity(altIntent)
                        } catch (_: Exception) {}
                    }
                    finish()
                }
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppSearchScreen(
    onDismiss: () -> Unit,
    onLaunchApp: (String) -> Unit,
    onOpenAppManagementSettings: () -> Unit
) {
    val context = LocalContext.current
    var query by remember { mutableStateOf("") }
    var allApps by remember { mutableStateOf<List<AppSearchEntry>>(emptyList()) }
    var recentApps by remember { mutableStateOf<List<AppSearchEntry>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    val focusRequester = remember { FocusRequester() }

    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            val pm = context.packageManager
            val appMap = mutableMapOf<String, AppSearchEntry>()

            // 1. Quét tất cả ứng dụng có launcher icon hiển thị trên điện thoại (dùng queryIntentActivities chuẩn Android)
            try {
                val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
                    addCategory(Intent.CATEGORY_LAUNCHER)
                }
                val resolveInfos = pm.queryIntentActivities(mainIntent, 0)
                for (ri in resolveInfos) {
                    try {
                        val pkg = ri.activityInfo.packageName
                        if (pkg == context.packageName) continue
                        val name = ri.loadLabel(pm).toString()
                        val icon = try { ri.loadIcon(pm) } catch (_: Exception) { null }
                        val isSys = (ri.activityInfo.applicationInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                        appMap[pkg] = AppSearchEntry(pkg, name, icon, isSys)
                    } catch (_: Exception) {}
                }
            } catch (_: Exception) {}

            // 2. Dự phòng: Quét thêm danh sách ứng dụng đã cài đặt nếu map quá nhỏ
            if (appMap.size < 5) {
                val installed = try {
                    pm.getInstalledApplications(PackageManager.GET_META_DATA)
                } catch (_: Exception) {
                    emptyList()
                }
                for (appInfo in installed) {
                    try {
                        val pkg = appInfo.packageName
                        if (pkg == context.packageName) continue
                        val name = pm.getApplicationLabel(appInfo).toString()
                        val isSys = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                        if (!appMap.containsKey(pkg)) {
                            val icon = try { pm.getApplicationIcon(appInfo) } catch (_: Exception) { null }
                            appMap[pkg] = AppSearchEntry(pkg, name, icon, isSys)
                        }
                    } catch (_: Exception) {}
                }
            }

            allApps = appMap.values.sortedBy { it.appName.lowercase() }

            // Lấy danh sách app mở gần đây
            val recentPkgNames = RecentAppsHistoryManager.getRecentPackageNames(context)
            recentApps = recentPkgNames.mapNotNull { appMap[it] }

            isLoading = false
        }
    }

    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(100)
        focusRequester.requestFocus()
    }

    val filteredApps = remember(query, allApps) {
        val q = query.trim().lowercase()
        if (q.isBlank()) {
            allApps.take(30)
        } else {
            allApps.filter {
                it.appName.lowercase().contains(q) || it.packageName.lowercase().contains(q)
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xD9020617)) // Semi-transparent dark overlay
            .clickable(onClick = onDismiss),
        contentAlignment = Alignment.TopCenter
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.96f)
                .padding(top = 42.dp, bottom = 24.dp)
                .clickable(enabled = false) {}, // Consume clicks inside
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
            border = androidx.compose.foundation.BorderStroke(
                1.5.dp,
                Brush.linearGradient(listOf(Color(0xFF38BDF8), Color(0xFF34D399)))
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Header Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF38BDF8).copy(alpha = 0.2f))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "TÌM NHANH ỨNG DỤNG",
                            color = Color(0xFF38BDF8),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black
                        )
                    }

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Nút Quản lý ứng dụng cài đặt hệ thống
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0xFF1E293B))
                                .border(1.dp, Color(0xFF334155), RoundedCornerShape(10.dp))
                                .clickable(onClick = onOpenAppManagementSettings)
                                .padding(horizontal = 9.dp, vertical = 5.dp)
                        ) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Settings,
                                    contentDescription = null,
                                    tint = Color(0xFF38BDF8),
                                    modifier = Modifier.size(13.dp)
                                )
                                Text(
                                    text = "Quản lý App",
                                    color = Color(0xFFE2E8F0),
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        // Close button
                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier.size(30.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Đóng",
                                tint = Color(0xFF94A3B8),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }

                // Input Search Field
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(focusRequester),
                    placeholder = {
                        Text(
                            text = "Gõ tên ứng dụng để mở ngay...",
                            color = Color(0xFF94A3B8),
                            fontSize = 13.sp
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = null,
                            tint = Color(0xFF38BDF8),
                            modifier = Modifier.size(20.dp)
                        )
                    },
                    trailingIcon = {
                        if (query.isNotEmpty()) {
                            IconButton(onClick = { query = "" }) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Xóa",
                                    tint = Color(0xFF94A3B8),
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color(0xFF020617),
                        unfocusedContainerColor = Color(0xFF020617),
                        focusedBorderColor = Color(0xFF38BDF8),
                        unfocusedBorderColor = Color(0xFF334155),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    )
                )

                // 🌟 MỤC LỊCH SỬ ỨNG DỤNG MỞ GẦN ĐÂY (Recent Apps Row)
                if (recentApps.isNotEmpty() && query.isBlank()) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.History,
                                contentDescription = null,
                                tint = Color(0xFF34D399),
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "MỞ GẦN ĐÂY",
                                color = Color(0xFF34D399),
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Black
                            )
                        }

                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            contentPadding = PaddingValues(horizontal = 2.dp)
                        ) {
                            items(recentApps, key = { "recent_${it.packageName}" }) { appItem ->
                                Column(
                                    modifier = Modifier
                                        .width(62.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(Color(0xFF1E293B))
                                        .border(1.dp, Color(0xFF334155), RoundedCornerShape(12.dp))
                                        .clickable { onLaunchApp(appItem.packageName) }
                                        .padding(horizontal = 4.dp, vertical = 8.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    if (appItem.icon != null) {
                                        val bitmap = remember(appItem.packageName) {
                                            try {
                                                appItem.icon.toBitmap(width = 80, height = 80).asImageBitmap()
                                            } catch (_: Exception) { null }
                                        }
                                        if (bitmap != null) {
                                            Image(
                                                bitmap = bitmap,
                                                contentDescription = appItem.appName,
                                                modifier = Modifier
                                                    .size(34.dp)
                                                    .clip(RoundedCornerShape(8.dp))
                                            )
                                        } else {
                                            Box(
                                                modifier = Modifier
                                                    .size(34.dp)
                                                    .clip(RoundedCornerShape(8.dp))
                                                    .background(Color(0xFF334155)),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(
                                                    text = appItem.appName.take(1).uppercase(),
                                                    color = Color.White,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 13.sp
                                                )
                                            }
                                        }
                                    } else {
                                        Box(
                                            modifier = Modifier
                                                .size(34.dp)
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(Color(0xFF334155)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = appItem.appName.take(1).uppercase(),
                                                color = Color.White,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp
                                            )
                                        }
                                    }

                                    Text(
                                        text = appItem.appName,
                                        color = Color(0xFFE2E8F0),
                                        fontSize = 9.5.sp,
                                        fontWeight = FontWeight.Medium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }
                    }
                }

                // Results Counter & Quick Status
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isLoading) "Đang nạp ứng dụng..." else if (query.isBlank()) "TẤT CẢ ỨNG DỤNG (${allApps.size})" else "TÌM THẤY (${filteredApps.size})",
                        color = Color(0xFF64748B),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Chạm để mở trực tiếp",
                        color = Color(0xFF38BDF8),
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                // App list items
                if (isLoading) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(
                            color = Color(0xFF38BDF8),
                            modifier = Modifier.size(32.dp),
                            strokeWidth = 2.5.dp
                        )
                    }
                } else if (filteredApps.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF020617)),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "Không tìm thấy ứng dụng nào khớp",
                                color = Color(0xFF94A3B8),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Gõ từ khóa khác hoặc bấm 'Quản lý App' ở trên",
                                color = Color(0xFF64748B),
                                fontSize = 11.sp
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = if (recentApps.isNotEmpty() && query.isBlank()) 330.dp else 420.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(filteredApps, key = { it.packageName }) { appItem ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0xFF1E293B).copy(alpha = 0.6f))
                                    .border(1.dp, Color(0xFF334155).copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                                    .clickable { onLaunchApp(appItem.packageName) }
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // App Icon
                                if (appItem.icon != null) {
                                    val bitmap = remember(appItem.packageName) {
                                        try {
                                            appItem.icon.toBitmap(width = 96, height = 96).asImageBitmap()
                                        } catch (_: Exception) { null }
                                    }
                                    if (bitmap != null) {
                                        Image(
                                            bitmap = bitmap,
                                            contentDescription = appItem.appName,
                                            modifier = Modifier
                                                .size(36.dp)
                                                .clip(RoundedCornerShape(8.dp))
                                        )
                                    } else {
                                        Box(
                                            modifier = Modifier
                                                .size(36.dp)
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(Color(0xFF334155)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = appItem.appName.take(1).uppercase(),
                                                color = Color.White,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(Color(0xFF334155)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = appItem.appName.take(1).uppercase(),
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.width(10.dp))

                                Column(
                                    modifier = Modifier.weight(1f),
                                    verticalArrangement = Arrangement.spacedBy(1.dp)
                                ) {
                                    Text(
                                        text = appItem.appName,
                                        color = Color(0xFFF1F5F9),
                                        fontSize = 12.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = appItem.packageName,
                                        color = Color(0xFF64748B),
                                        fontSize = 9.5.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }

                                Spacer(modifier = Modifier.width(8.dp))

                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color(0xFF38BDF8).copy(alpha = 0.2f))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = "Mở",
                                        color = Color(0xFF38BDF8),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
