package com.example.core.receiver

import android.appwidget.AppWidgetManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.core.service.MagicTuneKeepAliveService
import com.example.core.widget.MagicTuneAppSearchWidgetProvider
import com.example.core.widget.MagicTuneBatteryWidgetProvider
import com.example.core.widget.MagicTuneMemoryWidgetProvider

/**
 * MagicTuneBootReceiver: Lắng nghe sự kiện khởi động thiết bị hoặc mở khóa máy.
 * Tuân thủ 100% chính sách Background / Foreground Service của Android 14, 15, 16 và Android 17 (API 37):
 * Tuyệt đối không gọi startForegroundService trực tiếp từ BroadcastReceiver chạy ngầm,
 * mà cập nhật trực tiếp hệ thống AppWidget và chỉ kích hoạt dịch vụ khi ứng dụng đang hiển thị.
 */
class MagicTuneBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        if (context == null || intent == null) return
        val action = intent.action ?: return

        when (action) {
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_LOCKED_BOOT_COMPLETED,
            "android.intent.action.QUICKBOOT_POWERON",
            "com.htc.intent.action.QUICKBOOT_POWERON",
            Intent.ACTION_MY_PACKAGE_REPLACED,
            Intent.ACTION_USER_PRESENT,
            MagicTuneKeepAliveService.ACTION_REVIVE_KEEPALIVE -> {
                try {
                    val appWidgetManager = AppWidgetManager.getInstance(context)
                    for (id in appWidgetManager.getAppWidgetIds(ComponentName(context, MagicTuneBatteryWidgetProvider::class.java))) {
                        MagicTuneBatteryWidgetProvider.updateWidget(context, appWidgetManager, id)
                    }
                    for (id in appWidgetManager.getAppWidgetIds(ComponentName(context, MagicTuneMemoryWidgetProvider::class.java))) {
                        MagicTuneMemoryWidgetProvider.updateWidget(context, appWidgetManager, id)
                    }
                    for (id in appWidgetManager.getAppWidgetIds(ComponentName(context, MagicTuneAppSearchWidgetProvider::class.java))) {
                        MagicTuneAppSearchWidgetProvider.updateWidget(context, appWidgetManager, id)
                    }
                    // Khởi chạy bền vững dịch vụ duy trì Khoanh tròn Google & Trò chuyện Gemini ngay sau khi khởi động lại máy hoặc tắt WLAN/ADB
                    MagicTuneKeepAliveService.startOrUpdate(
                        context,
                        "Đang duy trì Google Khoanh Tròn & Trò chuyện Gemini 24/7",
                        forceFromBootOrOverlay = true
                    )
                    com.example.core.service.SystemFloatingHudOverlay.syncNavBarBridge(context)
                    com.example.core.service.SystemFloatingHudOverlay.ensureNavBridgeHealthy(context)
                    if (action == Intent.ACTION_USER_PRESENT) {
                        com.example.core.service.SystemFloatingHudOverlay.onDeviceUnlockedByUser(context)
                    }
                } catch (t: Throwable) {
                    Log.w("MagicTuneBootReceiver", "Bỏ qua cập nhật ngầm từ receiver: ${t.message}")
                }
            }
        }
    }
}
