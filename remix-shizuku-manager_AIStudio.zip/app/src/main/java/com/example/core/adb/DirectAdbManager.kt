package com.example.core.adb

import android.content.Context
import android.os.Build
import android.util.Log
import com.example.core.shell.ShellMode
import com.example.core.shell.ShellResult
import io.github.muntashirakon.adb.AbsAdbConnectionManager
import io.github.muntashirakon.adb.AdbStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.math.BigInteger
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.PrivateKey
import java.security.SecureRandom
import java.security.cert.Certificate
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.spec.PKCS8EncodedKeySpec
import java.util.Date
import java.util.concurrent.TimeUnit

/**
 * DirectAdbManager: Quản lý kết nối Direct WLAN ADB (UID 2000) độc lập.
 * Tách biệt hoàn toàn việc nạp thư viện gốc (Conscrypt / SPAKE2 / AbsAdbConnectionManager)
 * vào lớp nội bộ khởi tạo lười (Lazy Isolation), giúp ứng dụng mở tức thì và tương thích 100%
 * trên mọi thiết bị từ Android 8 đến Android 17 (API 37+) cũng như máy ảo Preview.
 */
class DirectAdbManager(private val context: Context) {

    companion object {
        private const val TAG = "DirectAdbManager"
        private const val KEY_DIR = "adb_keys"
        private const val PRIVATE_KEY_FILE = "magictune_adb.priv"
        private const val CERTIFICATE_FILE = "magictune_adb.cert"

        @Volatile
        private var instance: DirectAdbManager? = null

        fun getInstance(context: Context): DirectAdbManager {
            return instance ?: synchronized(this) {
                instance ?: DirectAdbManager(context.applicationContext).also { instance = it }
            }
        }

        /**
         * Kiểm tra trạng thái kết nối Direct ADB hoàn toàn không khóa (Lock-Free, 0ms),
         * không nạp lớp native Conscrypt khi khởi động app.
         */
        fun isInstanceConnectedFast(): Boolean {
            val inst = instance ?: return false
            return inst.isConnectedFast()
        }
    }

    private class InternalAdbEngine(private val owner: DirectAdbManager) : AbsAdbConnectionManager() {
        init {
            try {
                setHostAddress("127.0.0.1")
                setApi(Build.VERSION.SDK_INT)
                setTimeout(3, TimeUnit.SECONDS)
            } catch (t: Throwable) {
                Log.w(TAG, "InternalAdbEngine init fallback: ${t.message}")
            }
        }

        override fun getPrivateKey(): PrivateKey = owner.obtainPrivateKey()

        override fun getCertificate(): Certificate = owner.obtainCertificate()

        override fun getDeviceName(): String = "MagicTune Direct ADB (UID 2000)"
    }

    @Volatile
    private var internalEngine: InternalAdbEngine? = null

    private fun getOrCreateEngine(): InternalAdbEngine? {
        internalEngine?.let { return it }
        return synchronized(this) {
            internalEngine ?: try {
                InternalAdbEngine(this).also { internalEngine = it }
            } catch (t: Throwable) {
                Log.e(TAG, "Không thể khởi tạo engine ADB TLS trên thiết bị này: ${t.message}", t)
                null
            }
        }
    }

    private var cachedPrivateKey: PrivateKey? = null
    private var cachedCertificate: Certificate? = null

    @Volatile
    private var fastConnectedFlag: Boolean = false

    private val connectMutex = kotlinx.coroutines.sync.Mutex()

    val isConnected: Boolean
        get() = isConnectedFast()

    /**
     * Kiểm tra kết nối không bao giờ gây treo luồng gọi và không nạp thư viện native nếu chưa kết nối.
     */
    fun isConnectedFast(): Boolean {
        if (!fastConnectedFlag) return false
        val eng = internalEngine ?: return false
        if (connectMutex.isLocked) return fastConnectedFlag
        return try {
            val real = eng.isConnected
            fastConnectedFlag = real
            real
        } catch (_: Throwable) {
            false
        }
    }

    internal fun obtainPrivateKey(): PrivateKey {
        return cachedPrivateKey ?: synchronized(this) {
            cachedPrivateKey ?: loadOrGenerateKeys().first.also { cachedPrivateKey = it }
        }
    }

    internal fun obtainCertificate(): Certificate {
        return cachedCertificate ?: synchronized(this) {
            cachedCertificate ?: loadOrGenerateKeys().second.also { cachedCertificate = it }
        }
    }

    private fun loadOrGenerateKeys(): Pair<PrivateKey, Certificate> {
        val keysDir = File(context.filesDir, KEY_DIR)
        if (!keysDir.exists()) {
            keysDir.mkdirs()
        }
        val privFile = File(keysDir, PRIVATE_KEY_FILE)
        val certFile = File(keysDir, CERTIFICATE_FILE)

        if (privFile.exists() && certFile.exists()) {
            try {
                val privBytes = privFile.readBytes()
                val kf = KeyFactory.getInstance("RSA")
                val privKey = kf.generatePrivate(PKCS8EncodedKeySpec(privBytes))

                val cf = CertificateFactory.getInstance("X.509")
                FileInputStream(certFile).use { fis ->
                    val cert = cf.generateCertificate(fis)
                    cachedPrivateKey = privKey
                    cachedCertificate = cert
                    return Pair(privKey, cert)
                }
            } catch (e: Throwable) {
                Log.w(TAG, "Failed to load cached ADB keys, regenerating...", e)
            }
        }

        val kpg = KeyPairGenerator.getInstance("RSA")
        kpg.initialize(2048, SecureRandom())
        val keyPair = kpg.generateKeyPair()

        val cert = generateSelfSignedCertificate(keyPair)

        try {
            FileOutputStream(privFile).use { it.write(keyPair.private.encoded) }
            FileOutputStream(certFile).use { it.write(cert.encoded) }
        } catch (e: Throwable) {
            Log.e(TAG, "Failed to save generated ADB keys to disk", e)
        }

        cachedPrivateKey = keyPair.private
        cachedCertificate = cert
        return Pair(keyPair.private, cert)
    }

    private fun generateSelfSignedCertificate(keyPair: java.security.KeyPair): X509Certificate {
        val info = android.sun.security.x509.X509CertInfo()
        val notBefore = Date(System.currentTimeMillis() - 1000L * 60 * 60 * 24)
        val notAfter = Date(System.currentTimeMillis() + 1000L * 60 * 60 * 24 * 365 * 30) // 30 years
        val interval = android.sun.security.x509.CertificateValidity(notBefore, notAfter)
        val serial = android.sun.security.x509.CertificateSerialNumber(BigInteger(64, SecureRandom()))
        val owner = android.sun.security.x509.X500Name("CN=MagicTune Direct ADB, O=AI Studio, C=VN")

        info.set(android.sun.security.x509.X509CertInfo.VALIDITY, interval)
        info.set(android.sun.security.x509.X509CertInfo.SERIAL_NUMBER, serial)
        info.set(android.sun.security.x509.X509CertInfo.SUBJECT, android.sun.security.x509.CertificateSubjectName(owner))
        info.set(android.sun.security.x509.X509CertInfo.ISSUER, android.sun.security.x509.CertificateIssuerName(owner))
        info.set(android.sun.security.x509.X509CertInfo.KEY, android.sun.security.x509.CertificateX509Key(keyPair.public))
        info.set(android.sun.security.x509.X509CertInfo.VERSION, android.sun.security.x509.CertificateVersion(android.sun.security.x509.CertificateVersion.V3))

        val alg = android.sun.security.x509.AlgorithmId(android.sun.security.x509.AlgorithmId.sha256WithRSAEncryption_oid)
        info.set(android.sun.security.x509.X509CertInfo.ALGORITHM_ID, android.sun.security.x509.CertificateAlgorithmId(alg))

        val certImpl = android.sun.security.x509.X509CertImpl(info)
        certImpl.sign(keyPair.private, "SHA256withRSA")
        return certImpl
    }

    @Volatile
    var activeHost: String = "127.0.0.1"
        private set

    @Volatile
    var activePort: Int = 5555
        private set

    private fun isTcpEndpointReachable(host: String, port: Int, timeoutMs: Int = 650): Boolean {
        return try {
            java.net.Socket().use { socket ->
                socket.connect(java.net.InetSocketAddress(host, port), timeoutMs)
                true
            }
        } catch (_: Throwable) {
            false
        }
    }

    /**
     * Collects all valid local IPv4 addresses where Android's Wireless Debugging (`adbd`) may bind.
     */
    fun getCandidateHosts(preferredHost: String? = null): List<String> {
        val hosts = LinkedHashSet<String>()
        if (!preferredHost.isNullOrBlank() &&
            preferredHost != "0.0.0.0" &&
            !preferredHost.startsWith("169.254") &&
            !preferredHost.contains(":")
        ) {
            hosts.add(preferredHost.trim())
        }
        try {
            val scannerState = AdbNsdScanner.getInstance(context).state.value
            scannerState.connectHost?.takeIf { it.isNotBlank() && it != "0.0.0.0" && !it.contains(":") }?.let { hosts.add(it) }
            scannerState.pairingHost?.takeIf { it.isNotBlank() && it != "0.0.0.0" && !it.contains(":") }?.let { hosts.add(it) }
        } catch (_: Throwable) {}

        try {
            val interfaces = java.net.NetworkInterface.getNetworkInterfaces()
            if (interfaces != null) {
                for (intf in interfaces) {
                    if (!intf.isUp || intf.isLoopback) continue
                    val name = intf.name.lowercase()
                    if (name.startsWith("wlan") || name.startsWith("ap") || name.startsWith("eth")) {
                        for (addr in intf.inetAddresses) {
                            if (addr is java.net.Inet4Address && !addr.isLoopbackAddress) {
                                val ip = addr.hostAddress
                                if (!ip.isNullOrBlank() && ip != "0.0.0.0") {
                                    hosts.add(ip)
                                }
                            }
                        }
                    }
                }
            }
        } catch (_: Throwable) {}

        hosts.add("127.0.0.1")
        return hosts.toList()
    }

    /**
     * Pair directly with Android Wireless Debugging using 6-digit PIN and Pairing Port.
     */
    suspend fun pairDirect(port: Int, pairingCode: String, preferredHost: String? = null): Result<Boolean> = withContext(Dispatchers.IO) {
        connectMutex.lock()
        try {
            val eng = getOrCreateEngine()
                ?: return@withContext Result.failure(Exception("Thiết bị không hỗ trợ thư viện mã hóa ADB TLS"))
            val cleanCode = pairingCode.trim()
            val candidates = getCandidateHosts(preferredHost)
            var lastError: Throwable? = null

            // Ưu tiên 1: Địa chỉ IP thực tế do AdbNsdScanner phát hiện từ mDNS (_adb-tls-pairing._tcp)
            val nsdHost = try { AdbNsdScanner.getInstance(context).state.value.pairingHost } catch (_: Throwable) { null }
            val orderedForPairing = (listOfNotNull(nsdHost, preferredHost) + candidates + listOf("127.0.0.1"))
                .filter { it.isNotBlank() && it != "0.0.0.0" }
                .distinct()

            for (host in orderedForPairing) {
                if (!isTcpEndpointReachable(host, port, 600)) continue
                try {
                    Log.d(TAG, "Pairing with $host:$port using code: $cleanCode")
                    try { eng.setHostAddress(host) } catch (_: Throwable) {}
                    try { eng.setTimeout(3, TimeUnit.SECONDS) } catch (_: Throwable) {}

                    // Giới hạn thời gian tối đa 5 giây cho mỗi lần bắt tay SPAKE2, không bao giờ để luồng bị treo
                    val ok = kotlinx.coroutines.withTimeoutOrNull(5000L) {
                        try {
                            eng.pair(host, port, cleanCode)
                        } catch (t: Throwable) {
                            Log.w(TAG, "Inner pair exception on $host:$port: ${t.message}")
                            false
                        }
                    } ?: false

                    Log.d(TAG, "Direct pairing result on $host:$port -> $ok")
                    if (ok) {
                        activeHost = host
                        return@withContext Result.success(true)
                    }
                } catch (e: Throwable) {
                    lastError = e
                    Log.w(TAG, "Direct pairing attempt failed on $host:$port: ${e.message}")
                }
            }
            Result.failure(Exception(lastError?.localizedMessage ?: "Ghép nối thất bại tại cổng $port. Vui lòng kiểm tra mã PIN 6 số và mở đúng cửa sổ ghép đôi.", lastError))
        } finally {
            connectMutex.unlock()
        }
    }

    /**
     * Connect directly to ADB daemon over <Wi-Fi IP or 127.0.0.1>:<mainPort> using TLS 1.3 / Conscrypt.
     */
    suspend fun connectDirect(port: Int, preferredHost: String? = null): Result<Boolean> = withContext(Dispatchers.IO) {
        if (fastConnectedFlag && activePort == port && isConnectedFast()) {
            return@withContext Result.success(true)
        }
        connectMutex.lock()
        try {
            val eng = getOrCreateEngine()
                ?: return@withContext Result.failure(Exception("Thiết bị không hỗ trợ thư viện mã hóa ADB TLS"))
            if (fastConnectedFlag && activePort == port) {
                try {
                    if (eng.isConnected) return@withContext Result.success(true)
                } catch (_: Throwable) {}
            }
            if (fastConnectedFlag) {
                fastConnectedFlag = false
                try { eng.disconnect() } catch (_: Throwable) {}
            }

            val candidates = getCandidateHosts(preferredHost)
            var lastError: Throwable? = null

            for (host in candidates) {
                if (!isTcpEndpointReachable(host, port, 650)) continue
                try {
                    Log.d(TAG, "Connecting Direct ADB to $host:$port")
                    try { eng.setHostAddress(host) } catch (_: Throwable) {}
                    try { eng.setTimeout(3, TimeUnit.SECONDS) } catch (_: Throwable) {}
                    val ok = eng.connect(host, port)
                    val connectedNow = ok && eng.isConnected
                    Log.d(TAG, "Direct connect result on $host:$port -> ok=$ok, isConnected=$connectedNow")
                    if (connectedNow) {
                        activeHost = host
                        activePort = port
                        fastConnectedFlag = true
                        return@withContext Result.success(true)
                    }
                } catch (e: Throwable) {
                    lastError = e
                    Log.w(TAG, "Direct connect attempt failed on $host:$port: ${e.message}")
                }
            }
            fastConnectedFlag = false
            Result.failure(Exception(lastError?.localizedMessage ?: "Cổng $port chưa mở hoặc chưa ghép nối", lastError))
        } finally {
            connectMutex.unlock()
        }
    }

    /**
     * Disconnect ADB connection gracefully.
     */
    fun disconnectDirect() {
        fastConnectedFlag = false
        val eng = internalEngine ?: return
        try {
            if (!connectMutex.isLocked && eng.isConnected) {
                eng.disconnect()
            }
        } catch (e: Throwable) {
            Log.w(TAG, "DisconnectDirect error", e)
        }
    }

    private val execMutex = kotlinx.coroutines.sync.Mutex()

    @Volatile
    private var activeCommandStream: AdbStream? = null

    /**
     * Ngắt ngay lập tức lệnh Direct ADB đang chạy (nếu có) để ưu tiên lệnh mới nhất.
     */
    fun abortCurrentCommand(): Boolean {
        val s = activeCommandStream ?: return false
        return try {
            s.close()
            activeCommandStream = null
            true
        } catch (_: Throwable) {
            false
        }
    }

    /**
     * Execute shell command directly over TLS socket with UID 2000 (Native ADB Shell).
     */
    suspend fun executeCommand(command: String, timeoutSec: Long = 15): ShellResult = withContext(Dispatchers.IO) {
        val trimmed = command.trim()
        val eng = internalEngine
        if (eng == null || !isConnectedFast()) {
            return@withContext ShellResult(
                command = trimmed,
                exitCode = 1,
                output = "",
                error = "Direct ADB chưa được kết nối (127.0.0.1).",
                modeUsed = ShellMode.WIRELESS_ADB
            )
        }

        execMutex.lock()
        var stream: AdbStream? = null
        try {
            stream = eng.openStream("shell:")
            activeCommandStream = stream
            val activeStream = stream
            val os = activeStream.openOutputStream()
            val `is` = activeStream.openInputStream()

            val markerPart1 = "---MT_EXIT_"
            val markerPart2 = "MARKER---"
            val fullMarker = markerPart1 + markerPart2
            val startPart1 = "---MT_START_"
            val startPart2 = "MARKER---"
            val fullStartMarker = startPart1 + startPart2
            val exitRegex = Regex("${Regex.escape(fullMarker)}:(-?\\d+)")

            val execScript = buildString {
                append("export PATH=/sbin:/system/sbin:/system/bin:/system/xbin:/odm/bin:/vendor/bin:/vendor/xbin:\$PATH\n")
                append("echo \"$startPart1\"\"$startPart2\"\n")
                append(trimmed).append("\n")
                append("__mt_ec=\$?\n")
                append("echo \"$markerPart1\"\"$markerPart2:\$__mt_ec\"\n")
                append("exit\n")
            }
            os.write(execScript.toByteArray(Charsets.UTF_8))
            os.flush()

            val outputBuilder = StringBuilder()
            var foundMarker = false

            val readDeferred = async(Dispatchers.IO) {
                val buffer = ByteArray(4096)
                try {
                    while (!activeStream.isClosed) {
                        val read = `is`.read(buffer)
                        if (read == -1) break
                        if (read > 0) {
                            val chunk = String(buffer, 0, read, Charsets.UTF_8)
                            synchronized(outputBuilder) {
                                outputBuilder.append(chunk)
                                val bLen = outputBuilder.length
                                if (bLen >= fullMarker.length) {
                                    val tailLen = (fullMarker.length + 80).coerceAtMost(bLen)
                                    val tailStr = outputBuilder.substring(bLen - tailLen)
                                    if (exitRegex.containsMatchIn(tailStr)) {
                                        foundMarker = true
                                        return@async true
                                    }
                                }
                            }
                        }
                    }
                } catch (_: Throwable) {
                }
                foundMarker
            }

            val completedInTime = withTimeoutOrNull(timeoutSec * 1000L) {
                readDeferred.await()
            }

            if (completedInTime == null) {
                try { activeStream.close() } catch (_: Throwable) {}
                readDeferred.cancel()
                val partialOut = synchronized(outputBuilder) { outputBuilder.toString().trim() }
                return@withContext ShellResult(
                    command = trimmed,
                    exitCode = 124,
                    output = partialOut,
                    error = "Quá thời gian thực thi lệnh qua Direct ADB (Timeout > ${timeoutSec}s)",
                    modeUsed = ShellMode.WIRELESS_ADB
                )
            }

            var exitCode = 0
            var fullText = synchronized(outputBuilder) {
                outputBuilder.toString().replace("\r\n", "\n")
            }

            val match = exitRegex.findAll(fullText).lastOrNull()
            if (match != null) {
                exitCode = match.groupValues[1].toIntOrNull() ?: 0
                fullText = fullText.substring(0, match.range.first)
            }

            val startIdx = fullText.indexOf(fullStartMarker)
            if (startIdx >= 0) {
                fullText = fullText.substring(startIdx + fullStartMarker.length)
            }

            val cleanLines = fullText.lines().filterNot { line ->
                val l = line.trim()
                l == trimmed ||
                    l.startsWith("export PATH=") ||
                    l.contains("__mt_ec=") ||
                    l.contains("\"$markerPart1\"\"$markerPart2") ||
                    l.contains("\"$startPart1\"\"$startPart2")
            }
            val cleanOutput = cleanLines.joinToString("\n").trim()

            ShellResult(
                command = trimmed,
                exitCode = exitCode,
                output = cleanOutput,
                error = if (exitCode != 0) cleanOutput else "",
                modeUsed = ShellMode.WIRELESS_ADB
            )
        } catch (e: Throwable) {
            Log.e(TAG, "Execute command direct error: $trimmed", e)
            ShellResult(
                command = trimmed,
                exitCode = 1,
                output = "",
                error = e.localizedMessage ?: "Direct ADB execution error",
                modeUsed = ShellMode.WIRELESS_ADB
            )
        } finally {
            activeCommandStream = null
            try { stream?.close() } catch (_: Throwable) {}
            execMutex.unlock()
        }
    }
}
