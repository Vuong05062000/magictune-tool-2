package com.example.core.assistant

import android.content.Context
import android.os.Bundle
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import com.example.core.widget.GeminiLiveFloatingOverlay

/**
 * Phiên Tương Tác Trợ Lý Hệ Thống (VoiceInteractionSessionService).
 * Đón nhận tín hiệu khi người dùng gọi "Ok Google", nhấn nút nguồn hoặc cử chỉ góc màn hình để mở Gemini Live.
 */
class MagicTuneVoiceSessionService : VoiceInteractionSessionService() {

    override fun onNewSession(args: Bundle?): VoiceInteractionSession {
        return MagicTuneVoiceSession(this)
    }

    private class MagicTuneVoiceSession(context: Context) : VoiceInteractionSession(context) {

        override fun onShow(args: Bundle?, showFlags: Int) {
            super.onShow(args, showFlags)
            // Kích hoạt ngay hộp thoại Gemini Voice Nổi trực tiếp trên màn hình hiện tại (kể cả khi đang khóa máy)
            val ctx = context
            GeminiLiveFloatingOverlay.showAndStartListening(ctx)
            // Ẩn cửa sổ mặc định của Android session để nhường 100% hiển thị cho GeminiLiveFloatingOverlay
            hide()
        }

        override fun onHide() {
            super.onHide()
        }
    }
}
