package com.example.core.adb

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.RemoteInput
import com.example.MainActivity
import com.example.core.shell.ShellEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Quản lý thông báo ghép nối ADB Không Dây tương tác trực tiếp (Inline RemoteInput) chuẩn Shizuku:
 * - Giúp người dùng nhập 6 số mã PIN ngay trên thanh thông báo trong khi vẫn đang mở màn hình Cài đặt.
 * - Ngăn chặn việc Android tự đóng hộp thoại mã ghép đôi khi chuyển ứng dụng.
 */
object AdbPairingNotificationManager {

    const val CHANNEL_ID = "magictune_adb_pairing_channel"
    const val NOTIFICATION_ID = 20020
    const val KEY_PAIRING_CODE = "key_adb_pairing_pin_code"

    const val ACTION_SUBMIT_PIN = "com.example.core.adb.ACTION_SUBMIT_PAIRING_PIN"
    const val ACTION_STOP_PAIRING = "com.example.core.adb.ACTION_STOP_PAIRING_SEARCH"
    const val EXTRA_PAIRING_PORT = "extra_pairing_port"

    /**
     * Cờ cấu hình bật thông báo ghép nối tương tác.
     */
    const val SHOW_PAIRING_NOTIFICATIONS = true

    @Volatile
    var activeShellEngine: ShellEngine? = null

    @Volatile
    var isNotificationPairingActive: Boolean = false

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    fun ensureChannel(context: Context) {
        if (!SHOW_PAIRING_NOTIFICATIONS) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = context.getSystemService(NotificationManager::class.java) ?: return
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Ghép nối Gỡ lỗi Wi-Fi (Chuẩn Shizuku)",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Hiển thị ô nhập mã PIN 6 số ngay trên thanh thông báo khi phát hiện dịch vụ _adb-tls-pairing._tcp"
                enableVibration(true)
            }
            nm.createNotificationChannel(channel)
        }
    }

    /**
     * Khởi chạy tiến trình lắng nghe NSD và ghim thông báo chờ ghép nối giống hệt Shizuku.
     */
    fun startInteractiveNotificationPairing(context: Context, shellEngine: ShellEngine? = null) {
        val engine = shellEngine ?: activeShellEngine ?: ShellEngine.getInstance(context.applicationContext)
        startInteractivePairingNotification(context, engine)
    }

    fun startInteractivePairingNotification(context: Context, shellEngine: ShellEngine) {
        val appCtx = context.applicationContext
        activeShellEngine = shellEngine
        if (!SHOW_PAIRING_NOTIFICATIONS) {
            stopInteractivePairingNotification(appCtx)
            return
        }
        isNotificationPairingActive = true
        ensureChannel(appCtx)

        val scanner = AdbNsdScanner.getInstance(appCtx)
        scanner.onPairingPortDiscovered = { port, _ ->
            showPinInputNotification(appCtx, port)
        }
        scanner.onConnectPortDiscovered = { connectPort, _ ->
            // Chỉ tự động kết nối nếu thiết bị ĐÃ TỪNG ghép nối thành công trước đó
            scope.launch {
                if (shellEngine.hasPairedBefore() && !shellEngine.state.value.isWirelessAdbConnected) {
                    val ok = shellEngine.connectWirelessAdb(connectPort)
                    if (ok) {
                        isNotificationPairingActive = false
                        showPairingResultNotification(
                            appCtx,
                            success = true,
                            title = "✅ Đã tự động kết nối WLAN ADB (Cổng $connectPort)",
                            message = "Dịch vụ _adb-tls-connect._tcp đã tự động kết nối thành công với quyền UID 2000!"
                        )
                    }
                }
            }
        }

        scanner.startDiscovery()
        showSearchingNotification(appCtx)
    }

    fun stopInteractivePairingNotification(context: Context) {
        val appCtx = context.applicationContext
        isNotificationPairingActive = false
        val scanner = AdbNsdScanner.getInstance(appCtx)
        scanner.stopDiscovery()
        val nm = appCtx.getSystemService(NotificationManager::class.java)
        nm?.cancel(NOTIFICATION_ID)
    }

    fun showSearchingNotification(context: Context) {
        if (!SHOW_PAIRING_NOTIFICATIONS) return
        ensureChannel(context)
        val nm = context.getSystemService(NotificationManager::class.java) ?: return

        val stopIntent = Intent(context, AdbPairingReceiver::class.java).apply {
            action = ACTION_STOP_PAIRING
        }
        val stopPendingIntent = PendingIntent.getBroadcast(
            context,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val openSettingsIntent = Intent(android.provider.Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        val contentPendingIntent = PendingIntent.getActivity(
            context,
            2,
            openSettingsIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(com.example.R.drawable.ic_stat_magictune)
            .setContentTitle("🔍 Đang lắng nghe dịch vụ ghép nối ADB...")
            .setContentText("Vào Gỡ lỗi qua Wi-Fi ➔ Bấm 'Ghép nối thiết bị bằng mã ghép đôi'")
            .setStyle(
                NotificationCompat.BigTextStyle().bigText(
                    "MagicTune đang quét tự động dịch vụ _adb-tls-pairing._tcp.\n" +
                        "👉 Hãy mở Cài đặt nhà phát triển ➔ Gỡ lỗi qua Wi-Fi ➔ Bấm 'Ghép nối thiết bị bằng mã ghép đôi'.\n" +
                        "Ngay khi cửa sổ mã PIN hiện ra, thông báo này sẽ tự động bắt cổng và hiện ô nhập 6 số mã PIN!"
                )
            )
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setOngoing(true)
            .setOnlyAlertOnce(false)
            .setContentIntent(contentPendingIntent)
            .addAction(
                com.example.R.drawable.ic_stat_magictune,
                "Dừng tìm kiếm",
                stopPendingIntent
            )
            .build()

        try {
            nm.notify(NOTIFICATION_ID, notification)
        } catch (_: Throwable) {}
    }

    fun showPinInputNotification(context: Context, pairingPort: Int) {
        if (!SHOW_PAIRING_NOTIFICATIONS) return
        ensureChannel(context)
        val nm = context.getSystemService(NotificationManager::class.java) ?: return

        val remoteInput = RemoteInput.Builder(KEY_PAIRING_CODE)
            .setLabel("Nhập 6 chữ số mã ghép đôi...")
            .build()

        val submitIntent = Intent(context, AdbPairingReceiver::class.java).apply {
            action = ACTION_SUBMIT_PIN
            putExtra(EXTRA_PAIRING_PORT, pairingPort)
        }

        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT
        }

        val replyPendingIntent = PendingIntent.getBroadcast(context, 10, submitIntent, flags)

        val replyAction = NotificationCompat.Action.Builder(
            com.example.R.drawable.ic_stat_magictune,
            "🔑 NHẬP MÃ GHÉP ĐÔI (6 SỐ)",
            replyPendingIntent
        )
            .addRemoteInput(remoteInput)
            .setAllowGeneratedReplies(false)
            .build()

        val stopIntent = Intent(context, AdbPairingReceiver::class.java).apply {
            action = ACTION_STOP_PAIRING
        }
        val stopPendingIntent = PendingIntent.getBroadcast(
            context,
            11,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(com.example.R.drawable.ic_stat_magictune)
            .setContentTitle("🟢 Đã tìm thấy dịch vụ ghép nối (Cổng: $pairingPort)")
            .setContentText("Bấm 'NHẬP MÃ GHÉP ĐÔI' bên dưới và gõ 6 số mã PIN ngay tại đây!")
            .setStyle(
                NotificationCompat.BigTextStyle().bigText(
                    "Đã tự động điền cổng ghép nối: $pairingPort (qua _adb-tls-pairing._tcp).\n" +
                        "👉 Chỉ cần bấm nút '🔑 NHẬP MÃ GHÉP ĐÔI (6 SỐ)' bên dưới và gõ 6 chữ số đang hiển thị trên màn hình!"
                )
            )
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setOngoing(true)
            .addAction(replyAction)
            .addAction(com.example.R.drawable.ic_stat_magictune, "Hủy", stopPendingIntent)
            .build()

        try {
            nm.notify(NOTIFICATION_ID, notification)
        } catch (_: Throwable) {}
    }

    fun showProgressNotification(context: Context, message: String) {
        if (!SHOW_PAIRING_NOTIFICATIONS) return
        ensureChannel(context)
        val nm = context.getSystemService(NotificationManager::class.java) ?: return
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(com.example.R.drawable.ic_stat_magictune)
            .setContentTitle("⏳ Đang xử lý ghép nối ADB...")
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setProgress(0, 0, true)
            .setOngoing(true)
            .build()
        try {
            nm.notify(NOTIFICATION_ID, notification)
        } catch (_: Throwable) {}
    }

    fun showPairingResultNotification(
        context: Context,
        success: Boolean,
        title: String,
        message: String,
        retryPort: Int? = null
    ) {
        if (!SHOW_PAIRING_NOTIFICATIONS) return
        ensureChannel(context)
        val nm = context.getSystemService(NotificationManager::class.java) ?: return

        val openAppIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPendingIntent = PendingIntent.getActivity(
            context,
            20,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(com.example.R.drawable.ic_stat_magictune)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setOngoing(false)
            .setContentIntent(openPendingIntent)

        if (!success && retryPort != null && retryPort > 0) {
            val remoteInput = RemoteInput.Builder(KEY_PAIRING_CODE)
                .setLabel("Nhập lại 6 chữ số mã ghép đôi...")
                .build()
            val submitIntent = Intent(context, AdbPairingReceiver::class.java).apply {
                action = ACTION_SUBMIT_PIN
                putExtra(EXTRA_PAIRING_PORT, retryPort)
            }
            val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
            } else {
                PendingIntent.FLAG_UPDATE_CURRENT
            }
            val replyPendingIntent = PendingIntent.getBroadcast(context, 21, submitIntent, flags)
            val replyAction = NotificationCompat.Action.Builder(
                com.example.R.drawable.ic_stat_magictune,
                "🔄 NHẬP LẠI MÃ PIN",
                replyPendingIntent
            ).addRemoteInput(remoteInput).build()
            builder.addAction(replyAction)
        }

        try {
            nm.notify(NOTIFICATION_ID, builder.build())
        } catch (_: Throwable) {}
    }
}

/**
 * BroadcastReceiver nhận mã PIN 6 số người dùng gõ từ thanh thông báo (RemoteInput)
 * và thực hiện ghép nối + tự động kết nối vào cổng chính _adb-tls-connect._tcp.
 */
class AdbPairingReceiver : BroadcastReceiver() {

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    override fun onReceive(context: Context, intent: Intent) {
        val appCtx = context.applicationContext
        when (intent.action) {
            AdbPairingNotificationManager.ACTION_STOP_PAIRING -> {
                AdbPairingNotificationManager.stopInteractivePairingNotification(appCtx)
            }

            AdbPairingNotificationManager.ACTION_SUBMIT_PIN -> {
                val results = RemoteInput.getResultsFromIntent(intent)
                val rawPin = results?.getCharSequence(AdbPairingNotificationManager.KEY_PAIRING_CODE)?.toString().orEmpty()
                val cleanPin = rawPin.filter { it.isDigit() }.take(6)
                val scanner = AdbNsdScanner.getInstance(appCtx)
                val pairingPort = scanner.state.value.pairingPort
                    ?: intent.getIntExtra(AdbPairingNotificationManager.EXTRA_PAIRING_PORT, 0)

                if (cleanPin.length < 6 || pairingPort <= 0) {
                    AdbPairingNotificationManager.showPairingResultNotification(
                        context = appCtx,
                        success = false,
                        title = "⚠️ Mã PIN không hợp lệ",
                        message = "Vui lòng nhập đủ 6 chữ số mã ghép đôi (Đang phát hiện cổng: $pairingPort).",
                        retryPort = if (pairingPort > 0) pairingPort else null
                    )
                    return
                }

                AdbPairingNotificationManager.showProgressNotification(
                    appCtx,
                    "Đang ghép nối với 127.0.0.1:$pairingPort bằng mã PIN $cleanPin..."
                )

                val pendingResult = goAsync()
                scope.launch {
                    try {
                        kotlinx.coroutines.withTimeoutOrNull(14000L) {
                            val engine = AdbPairingNotificationManager.activeShellEngine ?: ShellEngine.getInstance(appCtx)
                            val pairRes = engine.pairWirelessAdb(pairingPort, cleanPin)
                            val pairOk = pairRes.isSuccess && pairRes.getOrDefault(false)

                            if (pairOk) {
                                // Chuẩn Shizuku: Kiểm tra ngay cổng kết nối hoặc làm mới mDNS _adb-tls-connect._tcp để bắt tức thì
                                var connectPort = scanner.getBestConnectPort()
                                var connectedOk = false
                                if (connectPort != null && connectPort > 0) {
                                    connectedOk = engine.connectWirelessAdb(connectPort)
                                }
                                if (!connectedOk) {
                                    scanner.refreshConnectDiscovery()
                                    for (i in 1..20) {
                                        delay(450)
                                        if (i == 10) {
                                            scanner.refreshConnectDiscovery()
                                        }
                                        connectPort = scanner.getBestConnectPort()
                                        if (connectPort != null && connectPort > 0) {
                                            connectedOk = engine.connectWirelessAdb(connectPort)
                                            if (connectedOk) break
                                        }
                                    }
                                }

                                // Giữ callback tự động kết nối nếu cổng mDNS báo về trễ vài giây khi người dùng chuyển về app
                                scanner.onConnectPortDiscovered = { discoveredPort, _ ->
                                    scope.launch {
                                        if (!engine.state.value.isWirelessAdbConnected) {
                                            val ok = engine.connectWirelessAdb(discoveredPort)
                                            if (ok) {
                                                AdbPairingNotificationManager.isNotificationPairingActive = false
                                                AdbPairingNotificationManager.showPairingResultNotification(
                                                    context = appCtx,
                                                    success = true,
                                                    title = "✅ Đã kết nối Direct ADB (Cổng $discoveredPort)",
                                                    message = "Đã tự động kết nối cổng chính $discoveredPort (UID 2000) thành công!"
                                                )
                                            }
                                        }
                                    }
                                }

                                if (connectedOk) {
                                    AdbPairingNotificationManager.isNotificationPairingActive = false
                                    AdbPairingNotificationManager.showPairingResultNotification(
                                        context = appCtx,
                                        success = true,
                                        title = "✅ Ghép nối & Kết nối ADB thành công!",
                                        message = "Đã ghép nối cổng $pairingPort và tự động kết nối cổng chính $connectPort (UID 2000). Nhấn để mở MagicTune!"
                                    )
                                } else {
                                    AdbPairingNotificationManager.showPairingResultNotification(
                                        context = appCtx,
                                        success = true,
                                        title = "✅ Ghép nối mã PIN thành công!",
                                        message = "Đã ghép nối thành công tại cổng $pairingPort! Hãy quay lại MagicTune để phiên ADB tự động hoàn tất kết nối."
                                    )
                                }
                            } else {
                                val errMsg = pairRes.exceptionOrNull()?.localizedMessage
                                    ?: "Mã PIN không đúng hoặc hộp thoại mã ghép đôi đã đóng."
                                AdbPairingNotificationManager.showPairingResultNotification(
                                    context = appCtx,
                                    success = false,
                                    title = "❌ Ghép nối thất bại (Cổng $pairingPort)",
                                    message = "$errMsg\nHãy mở lại 'Ghép nối bằng mã ghép đôi' và thử lại.",
                                    retryPort = pairingPort
                                )
                            }
                        }
                    } finally {
                        try { pendingResult.finish() } catch (_: Throwable) {}
                    }
                }
            }
        }
    }
}
