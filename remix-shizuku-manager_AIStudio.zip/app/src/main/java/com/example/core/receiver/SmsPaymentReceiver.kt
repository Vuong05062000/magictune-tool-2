package com.example.core.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * SmsPaymentReceiver:
 * Unused stub receiver after removal of SMS listening features for user privacy.
 */
class SmsPaymentReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        // Disabled for user privacy
    }
}
