package com.example.core.service

import android.annotation.SuppressLint
import android.app.Activity
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.Toast
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import com.example.MainActivity
import com.example.core.shell.ShellEngine
import com.example.data.FloatingMiniWindowState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.delay
import kotlin.math.abs

/**
 * Quản lý 2 lớp phủ Hệ thống (TYPE_APPLICATION_OVERLAY - Hiển thị trên ứng dụng khác):
 * 1. Live Automation PiP HUD: Nổi trực tiếp TRÊN màn hình Cài đặt Android khi đang tự động gạt công tắc
 *    "Thông báo nhẹ nhàng" -> TẮT và "Biểu ngữ" -> BẬT tận mắt người dùng.
 *    Sử dụng FLAG_NOT_FOCUSABLE để không bao giờ cướp tiêu điểm (focus) của màn hình Cài đặt bên dưới,
 *    giúp uiautomator dump và input tap hoạt động chính xác 100%.
 * 2. Smart NavBar Google / Gemini Bridge: Cầu nối cảm ứng thanh điều hướng đáy + Chặn YOYO chiếm quyền,
 *    đảm bảo nhấn giữ thanh điều hướng trên Honor MagicOS luôn gọi Google Khoanh Tròn Tìm Kiếm hoặc Gemini Voice
 *    kể cả khi hệ thống Honor khóa cứng cho YOYO hoặc khi đã tắt Gỡ lỗi / Tùy chọn nhà phát triển.
 */
object SystemFloatingHudOverlay {

    private val mainHandler = Handler(Looper.getMainLooper())
    private val ioScope = CoroutineScope(Dispatchers.IO)

    // --- 1. LIVE AUTOMATION FLOATING HUD STATE ---
    private var hudRootView: View? = null
    private var hudStepBadgeView: TextView? = null
    private var hudAppTitleView: TextView? = null
    private var hudActionDetailView: TextView? = null
    private var hudProgressBar: ProgressBar? = null
    private var hudLayoutParams: WindowManager.LayoutParams? = null
    private var onStopAutomationCallback: (() -> Unit)? = null

        // --- 2. DUAL SPLIT NAVBAR BUTTONS (LEFT: GOOGLE CIRCLE TO SEARCH, RIGHT: GEMINI LIVE) ---
    private var navLeftView: View? = null
    private var navLeftParams: WindowManager.LayoutParams? = null
    private var navRightView: View? = null
    private var navRightParams: WindowManager.LayoutParams? = null
    const val KEY_TOP_LEFT_CARRIER_SWIPE_ENABLED = "magictune_top_left_carrier_swipe_enabled"
    @Volatile
    private var isNavBridgeSuppressedForCts: Boolean = false
    @Volatile
    private var lastAssistantTriggerMs: Long = 0L

    // --- 3. POST-FACE-UNLOCK HANDS-FREE GEMINI VOICE WAKE LISTENER ---
    private var unlockSpeechRecognizer: android.speech.SpeechRecognizer? = null
    @Volatile
    private var isUnlockVoiceListening: Boolean = false
    @Volatile
    private var geminiSessionActiveUntilMs: Long = 0L
    private val stopUnlockListenRunnable = Runnable {
        stopUnlockVoiceWakeListener()
    }

    private val yoyoPackages = setOf(
        "com.hihonor.magicvoice",
        "com.hihonor.yoyo",
        "com.hihonor.assistant",
        "com.hihonor.ai.agent",
        "com.hihonor.aiagent",
        "com.hihonor.vassistant",
        "com.huawei.vassistant",
        "com.hihonor.voiceassistant",
        "com.hihonor.hiaction",
        "com.hihonor.hiaye"
    )

    private val geminiAndGoogleVoicePackages = setOf(
        "com.google.android.apps.bard",
        "com.google.android.googlequicksearchbox"
    )

    fun canDrawSystemOverlay(context: Context): Boolean {
        return try {
            Settings.canDrawOverlays(context)
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Cập nhật hoặc hiển thị cửa sổ PiP HUD nổi trực tiếp trên các ứng dụng khác (như Cài đặt Android)
     * trong suốt quá trình tự động mở trang thông báo và gạt công tắc.
     */
    fun updateAutomationHud(
        context: Context,
        state: FloatingMiniWindowState,
        onStopClick: () -> Unit
    ) {
        val appCtx = context.applicationContext
        onStopAutomationCallback = onStopClick
        mainHandler.post {
            try {
                if (!state.isVisible || !canDrawSystemOverlay(appCtx)) {
                    removeHudInternal(appCtx)
                    return@post
                }
                // Chỉ hiển thị System Overlay HUD khi đang chạy tự động hóa (vì lúc đó Cài đặt Android đè lên MagicTune)
                // Khi đã quay về màn hình MagicTune và kết thúc, Compose FloatingAutomationOverlay sẽ hiển thị kết quả.
                if (!state.isRunningAutomation) {
                    removeHudInternal(appCtx)
                    return@post
                }

                ensureHudViewCreated(appCtx)
                val pct = if (state.totalSteps > 0) {
                    ((state.currentStep.toFloat() / state.totalSteps.toFloat()) * 100f).toInt().coerceIn(5, 100)
                } else 0

                hudStepBadgeView?.text = "⚡ AUTO-CLICKER • Bước ${state.currentStep}/${state.totalSteps} ($pct%)"
                hudAppTitleView?.text = "🎯 ${state.currentAppName.ifBlank { "Đang xử lý..." }}"
                hudActionDetailView?.text = state.currentActionDetail.ifBlank { "Đang tự động gạt công tắc..." }
                hudProgressBar?.progress = pct
            } catch (_: Exception) {}
        }
    }

    fun hideAutomationHud(context: Context) {
        val appCtx = context.applicationContext
        mainHandler.post {
            removeHudInternal(appCtx)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun ensureHudViewCreated(context: Context) {
        if (hudRootView != null) return
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return

        val density = context.resources.displayMetrics.density
        fun dp(v: Int): Int = (v * density).toInt()

        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(14).toFloat()
                setColor(Color.parseColor("#F20F172A"))
                setStroke(dp(2), Color.parseColor("#06B6D4"))
            }
            elevation = dp(10).toFloat()
        }

        // Top row: Badge + Stop Button
        val topRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val stepBadge = TextView(context).apply {
            text = "⚡ AUTO-CLICKER ĐANG GẠT CÔNG TẮC"
            setTextColor(Color.parseColor("#22D3EE"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        hudStepBadgeView = stepBadge

        val stopBtn = TextView(context).apply {
            text = "⏹ DỪNG"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(10), dp(4), dp(10), dp(4))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(8).toFloat()
                setColor(Color.parseColor("#EF4444"))
            }
            setOnClickListener {
                onStopAutomationCallback?.invoke()
                removeHudInternal(context)
            }
        }

        topRow.addView(stepBadge)
        topRow.addView(stopBtn)
        container.addView(topRow)

        // App Title
        val appTitle = TextView(context).apply {
            text = "Đang mở Cài đặt thông báo..."
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            typeface = Typeface.DEFAULT_BOLD
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setPadding(0, dp(4), 0, dp(2))
        }
        hudAppTitleView = appTitle
        container.addView(appTitle)

        // Action Detail
        val detailTv = TextView(context).apply {
            text = "Tự động tắt Báo nhẹ nhàng & bật Biểu ngữ..."
            setTextColor(Color.parseColor("#A7F3D0"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        }
        hudActionDetailView = detailTv
        container.addView(detailTv)

        // Progress Bar
        val progress = ProgressBar(context, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 15
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(5)
            ).apply {
                topMargin = dp(6)
            }
        }
        hudProgressBar = progress
        container.addView(progress)

        val screenWidth = context.resources.displayMetrics.widthPixels
        val hudWidth = (screenWidth - dp(24)).coerceAtMost(dp(420))

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            hudWidth,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(32)
        }

        // Cho phép kéo thanh HUD lên/xuống nếu người dùng muốn đổi vị trí
        var initialY = 0
        var touchStartY = 0f
        container.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    initialY = params.y
                    touchStartY = event.rawY
                    false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dy = (event.rawY - touchStartY).toInt()
                    if (abs(dy) > dp(6)) {
                        params.y = (initialY + dy).coerceIn(dp(16), dp(500))
                        try {
                            wm.updateViewLayout(container, params)
                        } catch (_: Exception) {}
                        true
                    } else false
                }
                else -> false
            }
        }

        wm.addView(container, params)
        hudRootView = container
        hudLayoutParams = params
    }

    private fun removeHudInternal(context: Context) {
        val view = hudRootView ?: return
        hudRootView = null
        hudStepBadgeView = null
        hudAppTitleView = null
        hudActionDetailView = null
        hudProgressBar = null
        hudLayoutParams = null
        try {
            val wm = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
            wm?.removeViewImmediate(view)
        } catch (_: Exception) {}
    }

    // ========================================================================================
    // 2. SMART NAVBAR GOOGLE / GEMINI BRIDGE (VƯỢT KHÓA CỨNG YOYO TRÊN HONOR MAGICOS)
    // ========================================================================================

    private const val PREFS_NAV_BRIDGE = "magictune_nav_bridge_forever_prefs"
    private const val KEY_NAV_MOD_MODE = "magictune_nav_mod_mode"
    private const val KEY_NAV_EXPLICIT_DISABLED = "magictune_nav_explicit_disabled"
    private const val KEY_TRIGGER_GESTURE_TYPE = "magictune_trigger_gesture_type"

    private fun getNavBridgePrefs(context: Context): android.content.SharedPreferences {
        val appCtx = context.applicationContext ?: context
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                val dpCtx = appCtx.createDeviceProtectedStorageContext()
                dpCtx.getSharedPreferences(PREFS_NAV_BRIDGE, Context.MODE_PRIVATE)
            } else {
                appCtx.getSharedPreferences(PREFS_NAV_BRIDGE, Context.MODE_PRIVATE)
            }
        } catch (_: Throwable) {
            appCtx.getSharedPreferences(PREFS_NAV_BRIDGE, Context.MODE_PRIVATE)
        }
    }

    /**
     * Lưu chế độ Mod Phím Điều Hướng bền vững qua Khởi động lại máy (Direct Boot + SharedPreferences + Settings.Secure + ShellEngine)
     * để tính năng Google Khoanh Tròn & Trò Chuyện Gemini luôn hoạt động ngay cả khi tắt Gỡ lỗi WLAN / ADB hoặc khởi động lại điện thoại,
     * chỉ ẩn đi khi người dùng gỡ cài đặt ứng dụng chính hoặc chủ động bấm Khôi phục YOYO gốc.
     */
    fun savePersistentNavModMode(context: Context, mode: String, explicitlyDisabled: Boolean = false) {
        val appCtx = context.applicationContext ?: context
        try {
            getNavBridgePrefs(appCtx).edit()
                .putString(KEY_NAV_MOD_MODE, mode)
                .putBoolean(KEY_NAV_EXPLICIT_DISABLED, explicitlyDisabled)
                .apply()
        } catch (_: Throwable) {}
        try {
            appCtx.getSharedPreferences(PREFS_NAV_BRIDGE, Context.MODE_PRIVATE).edit()
                .putString(KEY_NAV_MOD_MODE, mode)
                .putBoolean(KEY_NAV_EXPLICIT_DISABLED, explicitlyDisabled)
                .apply()
        } catch (_: Throwable) {}
        try {
            ShellEngine.getInstance(appCtx).setPersistedSetting("secure", KEY_NAV_MOD_MODE, mode)
        } catch (_: Throwable) {}
        try {
            Settings.Secure.putString(appCtx.contentResolver, KEY_NAV_MOD_MODE, mode)
        } catch (_: Throwable) {}
    }

    /**
     * Đọc chế độ Mod Phím Điều Hướng hiện tại ("CIRCLE_TO_SEARCH", "GEMINI_VOICE", hoặc "DEFAULT").
     * Mặc định luôn duy trì "CIRCLE_TO_SEARCH" (cho phép đồng thời cả Khoanh tròn Google & Trò chuyện Gemini Live)
     * kể cả sau khi khởi động lại máy hay tắt WLAN/ADB, trừ khi người dùng chủ động tắt.
     */
    fun getActiveNavModMode(context: Context): String {
        val appCtx = context.applicationContext ?: context
        try {
            val dpPrefs = getNavBridgePrefs(appCtx)
            if (dpPrefs.getBoolean(KEY_NAV_EXPLICIT_DISABLED, false)) {
                return "DEFAULT"
            }
            val savedDp = dpPrefs.getString(KEY_NAV_MOD_MODE, null)
            if (savedDp == "CIRCLE_TO_SEARCH" || savedDp == "GEMINI_VOICE") {
                return savedDp
            }
        } catch (_: Throwable) {}

        try {
            val stdPrefs = appCtx.getSharedPreferences(PREFS_NAV_BRIDGE, Context.MODE_PRIVATE)
            if (stdPrefs.getBoolean(KEY_NAV_EXPLICIT_DISABLED, false)) {
                return "DEFAULT"
            }
            val savedStd = stdPrefs.getString(KEY_NAV_MOD_MODE, null)
            if (savedStd == "CIRCLE_TO_SEARCH" || savedStd == "GEMINI_VOICE") {
                return savedStd
            }
        } catch (_: Throwable) {}

        try {
            val shell = ShellEngine.getInstance(appCtx)
            val persisted = shell.getPersistedSetting("secure", KEY_NAV_MOD_MODE)
            if (persisted == "CIRCLE_TO_SEARCH" || persisted == "GEMINI_VOICE") {
                savePersistentNavModMode(appCtx, persisted, explicitlyDisabled = false)
                return persisted
            }
        } catch (_: Throwable) {}

        val secureMode = try {
            Settings.Secure.getString(appCtx.contentResolver, KEY_NAV_MOD_MODE)
        } catch (_: Exception) {
            null
        }
        if (secureMode == "CIRCLE_TO_SEARCH" || secureMode == "GEMINI_VOICE") {
            savePersistentNavModMode(appCtx, secureMode, explicitlyDisabled = false)
            return secureMode
        }

        // Mặc định luôn bật CIRCLE_TO_SEARCH (hỗ trợ cả Khoanh Tròn & Gemini Voice) khi app còn cài trên máy
        savePersistentNavModMode(appCtx, "CIRCLE_TO_SEARCH", explicitlyDisabled = false)
        return "CIRCLE_TO_SEARCH"
    }

    /**
     * Kiểm tra công tắc cho phép lắng nghe giọng nói mở khóa gọi Gemini hay không.
     * Khi người dùng TẮT tính năng gọi Gemini để tiết kiệm pin, Micro sẽ ngắt hoàn toàn 100%.
     */
    fun isGeminiMicWakeEnabled(context: Context): Boolean {
        val mode = getActiveNavModMode(context)
        if (mode != "GEMINI_VOICE") return false
        val shell = ShellEngine.getInstance(context.applicationContext)
        val micWakeFlag = shell.getPersistedSetting("secure", "magictune_gemini_mic_wake")
        return micWakeFlag != "0"
    }

    const val GESTURE_TYPE_BOTH = "BOTH"
    const val GESTURE_TYPE_NAV_HOLD = "NAV_HOLD"
    const val GESTURE_TYPE_CORNER_SWIPE = "CORNER_SWIPE"

    /**
     * Đọc kiểu cử chỉ kích hoạt Trợ lý ("BOTH" - Cả hai, "NAV_HOLD" - Nhấn thanh đáy, "CORNER_SWIPE" - Vuốt góc dưới màn hình).
     */
    fun getTriggerGestureType(context: Context): String {
        val appCtx = context.applicationContext ?: context
        try {
            val saved = getNavBridgePrefs(appCtx).getString(KEY_TRIGGER_GESTURE_TYPE, null)
            if (!saved.isNullOrBlank()) return saved
        } catch (_: Throwable) {}
        return try {
            val shell = ShellEngine.getInstance(appCtx)
            val persisted = shell.getPersistedSetting("secure", KEY_TRIGGER_GESTURE_TYPE)
            if (!persisted.isNullOrBlank()) return persisted
            Settings.Secure.getString(appCtx.contentResolver, KEY_TRIGGER_GESTURE_TYPE) ?: GESTURE_TYPE_NAV_HOLD
        } catch (_: Exception) {
            GESTURE_TYPE_NAV_HOLD
        }
    }

    /**
     * Lưu kiểu cử chỉ kích hoạt theo sở thích người dùng ("BOTH", "NAV_HOLD", hoặc "CORNER_SWIPE").
     */
    fun isTopLeftCarrierSwipeEnabled(context: Context): Boolean {
        val appCtx = context.applicationContext ?: context
        return try {
            getNavBridgePrefs(appCtx).getBoolean(KEY_TOP_LEFT_CARRIER_SWIPE_ENABLED, false)
        } catch (_: Throwable) {
            false
        }
    }

    fun setTopLeftCarrierSwipeEnabled(context: Context, enabled: Boolean) {
        val appCtx = context.applicationContext ?: context
        try {
            getNavBridgePrefs(appCtx).edit().putBoolean(KEY_TOP_LEFT_CARRIER_SWIPE_ENABLED, enabled).apply()
            appCtx.getSharedPreferences(PREFS_NAV_BRIDGE, Context.MODE_PRIVATE)
                .edit().putBoolean(KEY_TOP_LEFT_CARRIER_SWIPE_ENABLED, enabled).apply()
        } catch (_: Throwable) {}
        try {
            val shell = ShellEngine.getInstance(appCtx)
            shell.setPersistedSetting("secure", KEY_TOP_LEFT_CARRIER_SWIPE_ENABLED, if (enabled) "1" else "0")
        } catch (_: Throwable) {}
        mainHandler.post {
            removeNavBridgeInternal(appCtx)
            syncNavBarBridge(appCtx)
        }
    }

    fun setTriggerGestureType(context: Context, type: String) {
        val appCtx = context.applicationContext
        try {
            getNavBridgePrefs(appCtx).edit().putString(KEY_TRIGGER_GESTURE_TYPE, type).apply()
            appCtx.getSharedPreferences(PREFS_NAV_BRIDGE, Context.MODE_PRIVATE)
                .edit().putString(KEY_TRIGGER_GESTURE_TYPE, type).apply()
        } catch (_: Throwable) {}
        try {
            val shell = ShellEngine.getInstance(appCtx)
            shell.setPersistedSetting("secure", KEY_TRIGGER_GESTURE_TYPE, type)
        } catch (_: Throwable) {}
        try {
            Settings.Secure.putString(appCtx.contentResolver, KEY_TRIGGER_GESTURE_TYPE, type)
        } catch (_: Exception) {}
        mainHandler.post {
            removeNavBridgeInternal(appCtx)
            syncNavBarBridge(appCtx)
        }
    }

    /**
     * Tự động ẩn / thu nhỏ và thụt xuống dưới nút điều hướng ảo khi màn hình Khoanh Tròn Tìm Kiếm
     * (`CircleToSearchOverlayActivity`) hoặc Gemini Nổi đang hiển thị, giúp người dùng bấm hàng nút chức năng
     * ở đáy màn hình chính xác 100% mà không bao giờ bị ấn nhầm.
     */
    fun setNavBridgeSuppressedForOverlay(context: Context, suppressed: Boolean) {
        isNavBridgeSuppressedForCts = suppressed
        val appCtx = context.applicationContext
        mainHandler.post {
            try {
                val wm = appCtx.getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return@post
                val density = appCtx.resources.displayMetrics.density
                fun dp(v: Int): Int = (v * density).toInt()

                val shouldSuppress = suppressed ||
                    com.example.core.widget.CircleToSearchOverlayActivity.isOverlayActive ||
                    com.example.core.widget.GeminiLiveFloatingOverlay.isShowing
                isNavBridgeSuppressedForCts = shouldSuppress

                // Đồng bộ cả 2 nút điều hướng tách đôi (Trái: Google Khoanh Tròn, Phải: Gemini Live)
                listOf(
                    navLeftView to navLeftParams,
                    navRightView to navRightParams
                ).forEach { (navView, navParams) ->
                    if (navView != null && navParams != null) {
                        if (shouldSuppress) {
                            navView.visibility = View.GONE
                            navView.isClickable = false
                            navParams.width = 1
                            navParams.height = 1
                            navParams.y = -dp(32)
                            navParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        } else {
                            navView.visibility = View.VISIBLE
                            navView.isClickable = true
                            navParams.width = dp(88)
                            navParams.height = dp(24)
                            navParams.y = 0
                            navParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        }
                        wm.updateViewLayout(navView, navParams)
                    }
                }
} catch (_: Exception) {}
        }
    }

    /**
     * Kiểm tra định kỳ (Watchdog) đảm bảo cầu nối Thanh điều hướng đáy & 2 góc vuốt luôn gắn trên WindowManager
     * kể cả khi xoay màn hình, đổi độ phân giải, khởi động lại SystemUI hoặc tắt Gỡ lỗi WLAN / ADB.
     */
    fun ensureNavBridgeHealthy(context: Context) {
        val appCtx = context.applicationContext ?: context
        mainHandler.post {
            try {
                val mode = getActiveNavModMode(appCtx)
                if ((mode == "CIRCLE_TO_SEARCH" || mode == "GEMINI_VOICE") && canDrawSystemOverlay(appCtx)) {
                    val dead = navLeftView == null || !navLeftView!!.isAttachedToWindow ||
                        navRightView == null || !navRightView!!.isAttachedToWindow
                    if (dead) {
                        removeNavBridgeInternal(appCtx)
                        syncNavBarBridge(appCtx)
                    }
                }
            } catch (_: Throwable) {}
        }
    }

    /**
     * Đồng bộ Cầu nối cảm ứng Thanh điều hướng đáy & Cảm biến vuốt góc dưới màn hình (Bottom Corner Swipe).
     * Hỗ trợ 3 tùy chọn theo sở thích người dùng:
     * - "BOTH": Cho phép cả Nhấn giữ thanh đáy VÀ Vuốt từ góc dưới màn hình.
     * - "NAV_HOLD": Chỉ nhận Nhấn giữ thanh điều hướng.
     * - "CORNER_SWIPE": Chỉ nhận Vuốt chéo từ góc dưới màn hình (Góc trái: Google Khoanh Tròn, Góc phải: Gemini Live).
     */
    @SuppressLint("ClickableViewAccessibility")
    fun syncNavBarBridge(context: Context) {
        val appCtx = context.applicationContext
        mainHandler.post {
            try {
                val mode = getActiveNavModMode(appCtx)
                val shouldEnable = (mode == "CIRCLE_TO_SEARCH" || mode == "GEMINI_VOICE") && canDrawSystemOverlay(appCtx)
                if (!shouldEnable) {
                    removeNavBridgeInternal(appCtx)
                    if (mode != "GEMINI_VOICE") {
                        stopUnlockVoiceWakeListener()
                    }
                    return@post
                }

                val wm = appCtx.getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return@post
                val density = appCtx.resources.displayMetrics.density
                fun dp(v: Int): Int = (v * density).toInt()

                val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                } else {
                    @Suppress("DEPRECATION")
                    WindowManager.LayoutParams.TYPE_PHONE
                }

                val suppressedInitially = isNavBridgeSuppressedForCts ||
                    com.example.core.widget.CircleToSearchOverlayActivity.isOverlayActive ||
                    com.example.core.widget.GeminiLiveFloatingOverlay.isShowing

                // =========================================================================
                // TÁCH ĐÔI PHÍM ĐIỀU HƯỚNG THÀNH 2 NÚT RIÊNG BIỆT (KHÔNG DÙNG VUỐT GÓC/CẠNH):
                // 1. NỬA TRÁI (dp(88) x dp(24)): NHẤN GIỮ GỌI GOOGLE KHOANH TRÒN (CIRCLE TO SEARCH)
                // 2. NỬA PHẢI (dp(88) x dp(24)): NHẤN GIỮ GỌI GEMINI LIVE VOICE AI
                // =========================================================================

                // --- 1. NÚT NỬA TRÁI -> GOOGLE KHOANH TRÒN ---
                if (navLeftView != null && !navLeftView!!.isAttachedToWindow) {
                    navLeftView = null
                    navLeftParams = null
                }
                if (navLeftView == null) {
                    val leftPill = View(appCtx).apply {
                        background = GradientDrawable().apply {
                            shape = GradientDrawable.RECTANGLE
                            cornerRadius = dp(12).toFloat()
                            setColor(Color.TRANSPARENT)
                        }
                    }

                    val leftParams = WindowManager.LayoutParams(
                        if (suppressedInitially) 1 else dp(88),
                        if (suppressedInitially) 1 else dp(24),
                        overlayType,
                        if (suppressedInitially) {
                            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        } else {
                            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        },
                        PixelFormat.TRANSLUCENT
                    ).apply {
                        gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                        x = -dp(46) // Lệch sang trái 46dp
                        y = if (suppressedInitially) -dp(32) else 0
                    }

                    leftPill.visibility = if (suppressedInitially) View.GONE else View.VISIBLE
                    leftPill.isClickable = !suppressedInitially
                    var downX = 0f
                    var downY = 0f
                    var longPressTriggered = false
                    var swipeTriggered = false

                    val leftLongPressRunnable = Runnable {
                        if (!swipeTriggered && !isNavBridgeSuppressedForCts && !com.example.core.widget.CircleToSearchOverlayActivity.isOverlayActive) {
                            longPressTriggered = true
                            triggerHapticFeedback(appCtx, leftPill)
                            leftPill.background = GradientDrawable().apply {
                                shape = GradientDrawable.RECTANGLE
                                cornerRadius = dp(12).toFloat()
                                setColor(Color.parseColor("#9906B6D4")) // Cyan cho Google
                            }
                            mainHandler.postDelayed({
                                leftPill.background = GradientDrawable().apply {
                                    shape = GradientDrawable.RECTANGLE
                                    cornerRadius = dp(12).toFloat()
                                    setColor(Color.TRANSPARENT)
                                }
                            }, 300L)

                            triggerConfiguredAssistantNow(appCtx, explicitMode = "CIRCLE_TO_SEARCH")
                        }
                    }

                    leftPill.setOnTouchListener { _, event ->
                        if (isNavBridgeSuppressedForCts || com.example.core.widget.CircleToSearchOverlayActivity.isOverlayActive) {
                            return@setOnTouchListener false
                        }
                        when (event.actionMasked) {
                            MotionEvent.ACTION_DOWN -> {
                                downX = event.rawX
                                downY = event.rawY
                                longPressTriggered = false
                                swipeTriggered = false
                                mainHandler.removeCallbacks(leftLongPressRunnable)
                                mainHandler.postDelayed(leftLongPressRunnable, 150L)
                                true
                            }
                            MotionEvent.ACTION_MOVE -> {
                                val dx = event.rawX - downX
                                val dy = event.rawY - downY
                                if (!longPressTriggered && !swipeTriggered) {
                                    if (Math.abs(dx) > dp(14) || Math.abs(dy) > dp(14)) {
                                        swipeTriggered = true
                                        mainHandler.removeCallbacks(leftLongPressRunnable)
                                        if (dy < -dp(16)) {
                                            performHomeGesture(appCtx)
                                        }
                                    }
                                }
                                true
                            }
                            MotionEvent.ACTION_UP -> {
                                mainHandler.removeCallbacks(leftLongPressRunnable)
                                if (!longPressTriggered && !swipeTriggered) {
                                    val navMode = try {
                                        Settings.Secure.getInt(appCtx.contentResolver, "navigation_mode", 2)
                                    } catch (_: Exception) { 2 }
                                    if (navMode == 0) {
                                        performHomeGesture(appCtx)
                                    }
                                }
                                true
                            }
                            MotionEvent.ACTION_CANCEL -> {
                                mainHandler.removeCallbacks(leftLongPressRunnable)
                                true
                            }
                            else -> true
                        }
                    }

                    wm.addView(leftPill, leftParams)
                    navLeftView = leftPill
                    navLeftParams = leftParams
                }

                // --- 2. NÚT NỬA PHẢI -> GEMINI LIVE VOICE AI ---
                if (navRightView != null && !navRightView!!.isAttachedToWindow) {
                    navRightView = null
                    navRightParams = null
                }
                if (navRightView == null) {
                    val rightPill = View(appCtx).apply {
                        background = GradientDrawable().apply {
                            shape = GradientDrawable.RECTANGLE
                            cornerRadius = dp(12).toFloat()
                            setColor(Color.TRANSPARENT)
                        }
                    }

                    val rightParams = WindowManager.LayoutParams(
                        if (suppressedInitially) 1 else dp(88),
                        if (suppressedInitially) 1 else dp(24),
                        overlayType,
                        if (suppressedInitially) {
                            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        } else {
                            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        },
                        PixelFormat.TRANSLUCENT
                    ).apply {
                        gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                        x = dp(46) // Lệch sang phải 46dp
                        y = if (suppressedInitially) -dp(32) else 0
                    }

                    rightPill.visibility = if (suppressedInitially) View.GONE else View.VISIBLE
                    rightPill.isClickable = !suppressedInitially
                    var downX = 0f
                    var downY = 0f
                    var longPressTriggered = false
                    var swipeTriggered = false

                    val rightLongPressRunnable = Runnable {
                        if (!swipeTriggered && !isNavBridgeSuppressedForCts && !com.example.core.widget.CircleToSearchOverlayActivity.isOverlayActive) {
                            longPressTriggered = true
                            triggerHapticFeedback(appCtx, rightPill)
                            rightPill.background = GradientDrawable().apply {
                                shape = GradientDrawable.RECTANGLE
                                cornerRadius = dp(12).toFloat()
                                setColor(Color.parseColor("#998B5CF6")) // Tím cho Gemini Live
                            }
                            mainHandler.postDelayed({
                                rightPill.background = GradientDrawable().apply {
                                    shape = GradientDrawable.RECTANGLE
                                    cornerRadius = dp(12).toFloat()
                                    setColor(Color.TRANSPARENT)
                                }
                            }, 300L)

                            triggerConfiguredAssistantNow(appCtx, explicitMode = "GEMINI_VOICE")
                        }
                    }

                    rightPill.setOnTouchListener { _, event ->
                        if (isNavBridgeSuppressedForCts || com.example.core.widget.CircleToSearchOverlayActivity.isOverlayActive) {
                            return@setOnTouchListener false
                        }
                        when (event.actionMasked) {
                            MotionEvent.ACTION_DOWN -> {
                                downX = event.rawX
                                downY = event.rawY
                                longPressTriggered = false
                                swipeTriggered = false
                                mainHandler.removeCallbacks(rightLongPressRunnable)
                                mainHandler.postDelayed(rightLongPressRunnable, 150L)
                                true
                            }
                            MotionEvent.ACTION_MOVE -> {
                                val dx = event.rawX - downX
                                val dy = event.rawY - downY
                                if (!longPressTriggered && !swipeTriggered) {
                                    if (Math.abs(dx) > dp(14) || Math.abs(dy) > dp(14)) {
                                        swipeTriggered = true
                                        mainHandler.removeCallbacks(rightLongPressRunnable)
                                        if (dy < -dp(16)) {
                                            performHomeGesture(appCtx)
                                        }
                                    }
                                }
                                true
                            }
                            MotionEvent.ACTION_UP -> {
                                mainHandler.removeCallbacks(rightLongPressRunnable)
                                if (!longPressTriggered && !swipeTriggered) {
                                    val navMode = try {
                                        Settings.Secure.getInt(appCtx.contentResolver, "navigation_mode", 2)
                                    } catch (_: Exception) { 2 }
                                    if (navMode == 0) {
                                        performHomeGesture(appCtx)
                                    }
                                }
                                true
                            }
                            MotionEvent.ACTION_CANCEL -> {
                                mainHandler.removeCallbacks(rightLongPressRunnable)
                                true
                            }
                            else -> true
                        }
                    }

                    wm.addView(rightPill, rightParams)
                    navRightView = rightPill
                    navRightParams = rightParams
                }
            } catch (_: Exception) {}
        }
    }

    private fun removeNavBridgeInternal(context: Context) {
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
        navLeftView?.let { v ->
            navLeftView = null
            navLeftParams = null
            try { wm?.removeViewImmediate(v) } catch (_: Exception) {}
        }
        navRightView?.let { v ->
            navRightView = null
            navRightParams = null
            try { wm?.removeViewImmediate(v) } catch (_: Exception) {}
        }
    }

    /**
     * Kiểm tra tiến trình tiền cảnh:
     * 1. Nếu biểu tượng trò chuyện của Gemini / Google Assistant (`com.google.android.apps.bard` hoặc `com.google.android.googlequicksearchbox`)
     *    xuất hiện -> LẬP TỨC trả lại 100% quyền Micro của thiết bị cho Gemini ngay lập tức!
     * 2. Nếu tiến trình YOYO cố tình bật lên khi người dùng đang bật CIRCLE_TO_SEARCH hoặc GEMINI_VOICE -> Chặn YOYO và bật Google/Gemini Nổi đè lên!
     */
    fun interceptYoyoIfForeground(context: Context) {
        try {
            val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager ?: return
            val now = System.currentTimeMillis()
            val events = usm.queryEvents(now - 2500L, now) ?: return
            val event = UsageEvents.Event()
            var latestForegroundPkg: String? = null
            while (events.hasNextEvent()) {
                events.getNextEvent(event)
                if (event.eventType == UsageEvents.Event.ACTIVITY_RESUMED ||
                    @Suppress("DEPRECATION") (event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND)
                ) {
                    latestForegroundPkg = event.packageName
                }
            }

            if (latestForegroundPkg != null && geminiAndGoogleVoicePackages.contains(latestForegroundPkg)) {
                // Ngay khi biểu tượng trò chuyện của Gemini / Google xuất hiện -> Trả lại quyền Micro tức khắc cho Gemini!
                releaseMicrophoneForGeminiImmediately(context)
                if (latestForegroundPkg == "com.google.android.apps.bard") {
                    com.example.core.widget.GeminiLiveFloatingOverlay.yieldMicrophoneAndDismissForExternalGemini(context)
                }
                return
            }

            val mode = getActiveNavModMode(context)
            if (mode != "CIRCLE_TO_SEARCH" && mode != "GEMINI_VOICE") return

            if (latestForegroundPkg != null && yoyoPackages.contains(latestForegroundPkg)) {
                if (now - lastAssistantTriggerMs > 1200L) {
                    triggerConfiguredAssistantNow(context, mode)
                }
            }
        } catch (_: Exception) {}
    }

    private fun performHomeGesture(context: Context) {
        try {
            val homeIntent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_HOME)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            startActivityAllowingBackground(context, homeIntent)
        } catch (_: Exception) {}
    }

    private fun startActivityAllowingBackground(
        context: Context,
        intent: Intent,
        @Suppress("UNUSED_PARAMETER") preferFloatingWindow: Boolean = false
    ): Boolean {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            val options = android.app.ActivityOptions.makeBasic().apply {
                if (Build.VERSION.SDK_INT >= 34) {
                    setPendingIntentBackgroundActivityStartMode(
                        @Suppress("DEPRECATION") android.app.ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED
                    )
                }
            }
            context.startActivity(intent, options.toBundle())
            true
        } catch (_: Exception) {
            try {
                if (Build.VERSION.SDK_INT >= 34) {
                    val fallbackOpts = android.app.ActivityOptions.makeBasic()
                        .setPendingIntentBackgroundActivityStartMode(
                            android.app.ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED
                        )
                    context.startActivity(intent, fallbackOpts.toBundle())
                } else {
                    context.startActivity(intent)
                }
                true
            } catch (_: Exception) {
                try {
                    context.startActivity(intent)
                    true
                } catch (_: Exception) {
                    false
                }
            }
        }
    }

    private fun triggerHapticFeedback(context: Context, view: View?) {
        try {
            view?.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(35L, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(35L)
            }
        } catch (_: Exception) {}
    }

    /**
     * Giải phóng và trả lại 100% quyền Micro + Audio Focus cho Gemini ngay tức khắc (<5ms).
     * Đảm bảo ứng dụng MagicTune không bao giờ giữ kênh thu âm làm mất tiếng của Gemini.
     */
    fun releaseMicrophoneForGeminiImmediately(context: Context? = null) {
        // Khóa không cho bộ lắng nghe mở khóa chiếm lại Micro trong suốt 120 giây khi Gemini đang hội thoại
        geminiSessionActiveUntilMs = System.currentTimeMillis() + 120_000L
        stopUnlockVoiceWakeListener()
        if (context != null) {
            val appCtx = context.applicationContext
            try {
                val am = appCtx.getSystemService(Context.AUDIO_SERVICE) as? android.media.AudioManager
                @Suppress("DEPRECATION")
                am?.abandonAudioFocus(null)
            } catch (_: Throwable) {}

            val shell = ShellEngine.getInstance(appCtx)
            if (shell.state.value.isAdbReady) {
                ioScope.launch {
                    try {
                        val pkg = appCtx.packageName
                        shell.execute(
                            "pm grant --user 0 $pkg android.permission.RECORD_AUDIO >/dev/null 2>&1 || pm grant $pkg android.permission.RECORD_AUDIO >/dev/null 2>&1; " +
                            "cmd appops set $pkg RECORD_AUDIO allow >/dev/null 2>&1; " +
                            "cmd appops set --uid $pkg RECORD_AUDIO allow >/dev/null 2>&1"
                        )
                    } catch (_: Throwable) {}
                }
            }
        }
    }

    /**
     * Kích hoạt tính năng Khoanh Tròn Tìm Kiếm (Ép hoạt động trên Honor) / Tìm Kiếm Giọng Nói Google / Gemini Voice Nổi:
     * - Chế độ CIRCLE_TO_SEARCH (Ô #22):
     *   + Mở lớp phủ Khoanh Tròn Tìm Kiếm & Dịch Màn Hình (CircleToSearchOverlayActivity), tự động ẩn nút điều hướng ảo
     *     và có tích hợp sẵn nút "✨ Gemini" để nhường quyền hiển thị nổi cho Gemini bất cứ lúc nào.
     * - Chế độ GOOGLE_VOICE_DIRECT: Gọi thẳng hộp thoại Tìm Kiếm Giọng Nói chính gốc của App Google (VoiceSearchActivity).
     * - Chế độ GEMINI_VOICE (Ô #29):
     *   + Lập tức nhả và trả lại 100% quyền Micro cho Gemini (`releaseMicrophoneForGeminiImmediately`).
     *   + Tự động thu hồi/đóng lớp phủ Khoanh Tròn Tìm Kiếm (nếu đang mở) để nhường quyền hiển thị nổi trên màn hình cho Gemini.
     *   + Ép mở hộp thoại Trò Chuyện Giọng Nói Gemini NỔI NGAY TRÊN MÀN HÌNH HIỆN TẠI ở bất kỳ đâu, tuyệt đối KHÔNG chuyển hướng vào bên trong full app Gemini!
     */
    fun triggerConfiguredAssistantNow(context: Context, explicitMode: String? = null): Boolean {
        val now = System.currentTimeMillis()
        if (now - lastAssistantTriggerMs < 350L) return true
        lastAssistantTriggerMs = now

        val appCtx = context.applicationContext
        val mode = explicitMode ?: getActiveNavModMode(appCtx)
        val shell = ShellEngine.getInstance(appCtx)
        val isAdbReady = shell.state.value.isAdbReady

        // 0. Trả lại 100% quyền Micro tức khắc cho Gemini trước khi gọi hộp thoại nổi
        releaseMicrophoneForGeminiImmediately(appCtx)

        if (mode == "GEMINI_VOICE") {
            // Nhường quyền hiển thị nổi: Tự động đóng Khoanh Tròn Tìm Kiếm & Dịch Cuộn nếu đang hiển thị
            com.example.core.widget.CircleToSearchOverlayActivity.dismissIfActiveForGemini()
            if (com.example.core.widget.GoogleLiveTranslateOverlay.isRunning) {
                com.example.core.widget.GoogleLiveTranslateOverlay.stop(appCtx)
            }
        }

        // 1. Gọi trực tiếp Hộp Thoại Nổi Gemini Voice (GeminiLiveFloatingOverlay) hoặc Khoanh Tròn Tìm Kiếm
        val directLaunched = when (mode) {
            "GEMINI_VOICE" -> launchGeminiVoiceDirect(context)
            "GOOGLE_VOICE_DIRECT" -> launchGoogleVoiceSearchDirect(context)
            else -> {
                // Chế độ CIRCLE_TO_SEARCH: Tự ẩn thanh điều hướng ảo và mở bộ Ép Khoanh Tròn Tìm Kiếm & Dịch Màn Hình
                setNavBridgeSuppressedForOverlay(appCtx, true)
                com.example.core.widget.CircleToSearchOverlayActivity.launch(context)
            }
        }

        // 2. Thực thi lệnh Shell song song nếu Shizuku / ADB sẵn sàng:
        //    - Tự động cấp quyền RECORD_AUDIO + SYSTEM_ALERT_WINDOW cho MagicTune & Gemini
        //    - Đóng thanh thông báo (statusbar collapse) và chặn YOYO chiếm quyền
        if (isAdbReady) {
            ioScope.launch {
                try {
                    withTimeoutOrNull(2500L) {
                        val pkg = appCtx.packageName
                        val stopYoyo = "am force-stop com.hihonor.magicvoice >/dev/null 2>&1; am force-stop com.hihonor.yoyo >/dev/null 2>&1; am force-stop com.hihonor.assistant >/dev/null 2>&1; am force-stop com.hihonor.hiaye >/dev/null 2>&1"
                        when (mode) {
                            "GEMINI_VOICE" -> {
                                val grantMicAndFloating =
                                    "pm grant $pkg android.permission.RECORD_AUDIO >/dev/null 2>&1; " +
                                    "appops set $pkg RECORD_AUDIO allow >/dev/null 2>&1; " +
                                    "appops set $pkg SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1; " +
                                    "appops set com.google.android.googlequicksearchbox RECORD_AUDIO allow >/dev/null 2>&1; " +
                                    "appops set com.google.android.apps.bard RECORD_AUDIO allow >/dev/null 2>&1; " +
                                    "appops set com.google.android.googlequicksearchbox SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1; " +
                                    "appops set com.google.android.apps.bard SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1"
                                shell.execute("$stopYoyo; $grantMicAndFloating; cmd statusbar collapse >/dev/null 2>&1")
                                if (!com.example.core.widget.GeminiLiveFloatingOverlay.isShowing) {
                                    mainHandler.post {
                                        com.example.core.widget.GeminiLiveFloatingOverlay.showAndStartListening(appCtx)
                                    }
                                }
                            }
                            "GOOGLE_VOICE_DIRECT" -> {
                                val stopGeminiIfHijacked = "am force-stop com.google.android.apps.bard >/dev/null 2>&1"
                                shell.execute(
                                    "$stopYoyo; $stopGeminiIfHijacked; cmd statusbar collapse >/dev/null 2>&1; am start --user 0 -a android.speech.action.WEB_SEARCH -n com.google.android.googlequicksearchbox/com.google.android.googlequicksearchbox.VoiceSearchActivity --es android.speech.extra.LANGUAGE_MODEL web_search --ez com.google.android.voicesearch.extra.CALLED_FROM_SEARCH_PLATE true >/dev/null 2>&1 || am start --user 0 -n com.google.android.googlequicksearchbox/com.google.android.googlequicksearchbox.VoiceSearchActivity >/dev/null 2>&1 || true"
                                )
                            }
                            else -> {
                                delay(90L)
                                if (!com.example.core.widget.CircleToSearchOverlayActivity.isOverlayActive) {
                                    shell.execute(
                                        "$stopYoyo; am start --user 0 -n $pkg/com.example.core.widget.CircleToSearchOverlayActivity --activity-single-top --activity-clear-top --activity-exclude-from-recents --activity-no-animation >/dev/null 2>&1 || true"
                                    )
                                } else {
                                    shell.execute("$stopYoyo >/dev/null 2>&1 || true")
                                }
                            }
                        }
                    }
                } catch (_: Exception) {}
            }
        }

        return directLaunched || isAdbReady
    }

    /**
     * Mở TRỰC TIẾP tính năng Tìm Kiếm Giọng Nói của App Google (VoiceSearchActivity) trên màn hình,
     * KHÔNG mở trang chủ tin tức của App Google và KHÔNG gọi sang Gemini Voice.
     */
    private fun launchGoogleVoiceSearchDirect(context: Context): Boolean {
        releaseMicrophoneForGeminiImmediately(context)
        val pm = context.packageManager
        val candidates = listOf(
            // 1. Gọi trực tiếp VoiceSearchActivity chính gốc của App Google với ACTION_WEB_SEARCH
            Intent(android.speech.RecognizerIntent.ACTION_WEB_SEARCH).apply {
                setClassName(
                    "com.google.android.googlequicksearchbox",
                    "com.google.android.googlequicksearchbox.VoiceSearchActivity"
                )
                putExtra(
                    android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    android.speech.RecognizerIntent.LANGUAGE_MODEL_WEB_SEARCH
                )
                putExtra("com.google.android.voicesearch.extra.CALLED_FROM_SEARCH_PLATE", true)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            },
            // 2. Gọi trực tiếp component VoiceSearchActivity của App Google
            Intent().apply {
                setClassName(
                    "com.google.android.googlequicksearchbox",
                    "com.google.android.googlequicksearchbox.VoiceSearchActivity"
                )
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            },
            // 3. Action SEARCH_LONG_PRESS chuẩn của App Google (mở hộp thoại tìm kiếm nổi của Google)
            Intent(Intent.ACTION_SEARCH_LONG_PRESS).apply {
                setPackage("com.google.android.googlequicksearchbox")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            },
            // 4. Action WEB_SEARCH đóng gói riêng cho App Google
            Intent(android.speech.RecognizerIntent.ACTION_WEB_SEARCH).apply {
                setPackage("com.google.android.googlequicksearchbox")
                putExtra(
                    android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    android.speech.RecognizerIntent.LANGUAGE_MODEL_WEB_SEARCH
                )
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            }
        )

        for (intent in candidates) {
            if (pm.resolveActivity(intent, 0) != null && startActivityAllowingBackground(context, intent)) {
                return true
            }
        }
        return false
    }

    fun launchGeminiAssistantFromForeground(activity: Activity): Boolean {
        releaseMicrophoneForGeminiImmediately(activity)
        com.example.core.widget.CircleToSearchOverlayActivity.dismissIfActiveForGemini()
        val shown = com.example.core.widget.GeminiLiveFloatingOverlay.showAndStartListening(activity)
        if (shown) return true
        return launchGeminiVoiceDirect(activity)
    }

    private fun isPackageInstalled(context: Context, pkg: String): Boolean {
        return try {
            context.packageManager.getPackageInfo(pkg, 0)
            true
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Kích hoạt Hộp Thoại Giọng Nói NỔI (`GeminiLiveFloatingOverlay`) trực tiếp trên màn hình hiện tại
     * ở bất kỳ đâu trên Honor MagicOS 11 / Android 17 để người dùng trò chuyện bằng âm thanh ngay ngoài màn hình
     * mà KHÔNG chuyển hướng vào bên trong full app Gemini.
     */
    fun launchGeminiVoiceDirect(context: Context): Boolean {
        releaseMicrophoneForGeminiImmediately(context)
        com.example.core.widget.CircleToSearchOverlayActivity.dismissIfActiveForGemini()

        // 1. Ưu tiên số 1: Hiển thị trực tiếp Hộp Thoại Giọng Nói Nổi GeminiLiveFloatingOverlay ngay trên màn hình hiện tại (0ms)
        if (com.example.core.widget.GeminiLiveFloatingOverlay.showAndStartListening(context)) {
            return true
        }

        // 2. Nếu chưa cấp quyền vẽ trên ứng dụng khác hoặc cần xin quyền Micro qua Activity trong suốt:
        if (com.example.core.widget.GeminiVoiceLockscreenActivity.launchFromOverlay(context)) {
            return true
        }

        // 3. Dự phòng mở App Gemini chính thức nếu chưa cấp quyền lớp phủ
        return com.example.core.widget.GeminiLiveFloatingOverlay.openOfficialGeminiAppAndYieldMic(context)
    }

    // ========================================================================================
    // 3. TIẾP NHẬN MICRO & GỌI GEMINI NỔI BẰNG GIỌNG ĐỌC NGAY SAU KHI MỞ KHÓA KHUÔN MẶT
    // ========================================================================================

    /**
     * Tự động kích hoạt phiên lắng nghe giọng đọc rảnh tay (6 giây) ngay sau khi màn hình khóa
     * vừa được mở khóa bằng khuôn mặt / vân tay (`Intent.ACTION_USER_PRESENT`), CHỈ KHI tính năng
     * gọi Gemini đang được BẬT và Gemini chưa mở trên màn hình.
     *
     * Ngay khi người dùng đọc từ khóa hoặc biểu tượng Gemini xuất hiện -> Ứng dụng lập tức nhả Micro
     * trong <5ms (`releaseMicrophoneForGeminiImmediately`) để trả lại quyền Micro 100% cho Gemini!
     */
    fun onDeviceUnlockedByUser(context: Context) {
        val appCtx = context.applicationContext
        // Nếu người dùng đã TẮT tính năng gọi Gemini để tiết kiệm pin -> Không bật Micro!
        if (!isGeminiMicWakeEnabled(appCtx)) {
            stopUnlockVoiceWakeListener()
            return
        }
        // Nếu Gemini vừa được kích hoạt hoặc đang hội thoại -> Tuyệt đối không chạm vào Micro để tránh cướp Micro của Gemini!
        if (System.currentTimeMillis() < geminiSessionActiveUntilMs) {
            stopUnlockVoiceWakeListener()
            return
        }

        val hasMicPerm = androidx.core.content.ContextCompat.checkSelfPermission(
            appCtx,
            android.Manifest.permission.RECORD_AUDIO
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED

        if (!hasMicPerm) {
            val shell = ShellEngine.getInstance(appCtx)
            if (shell.state.value.isAdbReady) {
                ioScope.launch {
                    try {
                        val pkg = appCtx.packageName
                        shell.execute("pm grant $pkg android.permission.RECORD_AUDIO >/dev/null 2>&1; appops set $pkg RECORD_AUDIO allow >/dev/null 2>&1")
                    } catch (_: Throwable) {}
                }
            }
            return
        }

        mainHandler.post {
            try {
                if (isUnlockVoiceListening || System.currentTimeMillis() < geminiSessionActiveUntilMs) return@post
                if (!isGeminiMicWakeEnabled(appCtx)) return@post
                if (!android.speech.SpeechRecognizer.isRecognitionAvailable(appCtx)) return@post

                stopUnlockVoiceWakeListener()
                val recognizer = android.speech.SpeechRecognizer.createSpeechRecognizer(appCtx)
                unlockSpeechRecognizer = recognizer
                isUnlockVoiceListening = true

                val recognizerIntent = Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(
                        android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                        android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                    )
                    putExtra(android.speech.RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(android.speech.RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                    putExtra(android.speech.RecognizerIntent.EXTRA_CALLING_PACKAGE, appCtx.packageName)
                }

                recognizer.setRecognitionListener(object : android.speech.RecognitionListener {
                    override fun onReadyForSpeech(params: android.os.Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {}

                    override fun onError(error: Int) {
                        stopUnlockVoiceWakeListener()
                    }

                    override fun onResults(results: android.os.Bundle?) {
                        val matches = results?.getStringArrayList(android.speech.SpeechRecognizer.RESULTS_RECOGNITION)
                        if (checkWakeWordsAndTriggerGemini(appCtx, matches)) return
                        stopUnlockVoiceWakeListener()
                    }

                    override fun onPartialResults(partialResults: android.os.Bundle?) {
                        val matches = partialResults?.getStringArrayList(android.speech.SpeechRecognizer.RESULTS_RECOGNITION)
                        checkWakeWordsAndTriggerGemini(appCtx, matches)
                    }

                    override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
                })

                recognizer.startListening(recognizerIntent)
                // Tự động đóng phiên lắng nghe sau 6 giây nếu người dùng không gọi Gemini để tiết kiệm pin và giải phóng Micro
                mainHandler.removeCallbacks(stopUnlockListenRunnable)
                mainHandler.postDelayed(stopUnlockListenRunnable, 6000L)
            } catch (_: Throwable) {
                stopUnlockVoiceWakeListener()
            }
        }
    }

    private fun checkWakeWordsAndTriggerGemini(context: Context, phrases: List<String>?): Boolean {
        if (phrases.isNullOrEmpty()) return false
        val wakeKeywords = listOf(
            "gemini",
            "ge mi ni",
            "ok google",
            "okay google",
            "hey google",
            "trợ lý",
            "tro ly",
            "alo gemini",
            "mở gemini",
            "gọi gemini"
        )
        for (raw in phrases) {
            val normalized = raw.lowercase().trim()
            if (wakeKeywords.any { normalized.contains(it) }) {
                // Trả lại Micro ngay tức khắc (<5ms) trước khi bật hộp thoại Gemini Voice Nổi
                releaseMicrophoneForGeminiImmediately(context)
                triggerConfiguredAssistantNow(context, explicitMode = "GEMINI_VOICE")
                return true
            }
        }
        return false
    }

    fun stopUnlockVoiceWakeListener() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post { stopUnlockVoiceWakeListener() }
            return
        }
        mainHandler.removeCallbacks(stopUnlockListenRunnable)
        isUnlockVoiceListening = false
        val rec = unlockSpeechRecognizer ?: return
        unlockSpeechRecognizer = null
        try {
            rec.stopListening()
        } catch (_: Throwable) {}
        try {
            rec.cancel()
        } catch (_: Throwable) {}
        try {
            rec.destroy()
        } catch (_: Throwable) {}
    }
}
