package com.example.core.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.provider.Settings
import android.view.View
import android.widget.RemoteViews
import androidx.core.graphics.drawable.toBitmap
import com.example.R

class MagicTuneAppSearchWidgetProvider : AppWidgetProvider() {

    companion object {
        fun updateWidget(
            context: Context,
            appWidgetManager: AppWidgetManager,
            appWidgetId: Int
        ) {
            val views = RemoteViews(context.packageName, R.layout.widget_app_search)

            // 1. Chạm vào ô tìm kiếm: Mở ngay cửa sổ tìm kiếm ứng dụng tức thì (AppSearchActivity)
            val searchIntent = Intent(context, AppSearchActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            }
            val searchPendingIntent = PendingIntent.getActivity(
                context,
                2001,
                searchIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_search_touch_area, searchPendingIntent)
            views.setOnClickPendingIntent(R.id.widget_search_bar_root, searchPendingIntent)

            // 2. Chạm vào nút App / Cài đặt App: Mở thẳng trang Quản lý Ứng dụng trong Cài đặt điện thoại Honor
            val manageAppsIntent = Intent(Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            val appsPendingIntent = PendingIntent.getActivity(
                context,
                2002,
                manageAppsIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_btn_apps, appsPendingIntent)

            // 2b. Chạm vào nút 🎙️ Gemini: Mở ngay Gemini Voice AI
            val geminiIntent = Intent(context, GeminiVoiceLockscreenActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val geminiPendingIntent = PendingIntent.getActivity(
                context,
                2003,
                geminiIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_btn_gemini, geminiPendingIntent)

            // 3. Nạp danh sách 10 ứng dụng mở gần đây hiển thị 2 Hàng (5 app / hàng)
            // Lọc CHỈ HIỂN THỊ app của người dùng, không hiện app hệ thống (trừ app Cài đặt)
            val recentPkgNames = RecentAppsHistoryManager.getRecentPackageNames(context).take(10)
            val pm = context.packageManager

            val appSlotIds = listOf(
                // Hàng 1
                Triple(R.id.widget_recent_app_1, R.id.widget_recent_icon_1, R.id.widget_recent_name_1),
                Triple(R.id.widget_recent_app_2, R.id.widget_recent_icon_2, R.id.widget_recent_name_2),
                Triple(R.id.widget_recent_app_3, R.id.widget_recent_icon_3, R.id.widget_recent_name_3),
                Triple(R.id.widget_recent_app_4, R.id.widget_recent_icon_4, R.id.widget_recent_name_4),
                Triple(R.id.widget_recent_app_5, R.id.widget_recent_icon_5, R.id.widget_recent_name_5),
                // Hàng 2
                Triple(R.id.widget_recent_app_6, R.id.widget_recent_icon_6, R.id.widget_recent_name_6),
                Triple(R.id.widget_recent_app_7, R.id.widget_recent_icon_7, R.id.widget_recent_name_7),
                Triple(R.id.widget_recent_app_8, R.id.widget_recent_icon_8, R.id.widget_recent_name_8),
                Triple(R.id.widget_recent_app_9, R.id.widget_recent_icon_9, R.id.widget_recent_name_9),
                Triple(R.id.widget_recent_app_10, R.id.widget_recent_icon_10, R.id.widget_recent_name_10)
            )

            for (i in 0 until 10) {
                val (layoutId, iconId, nameId) = appSlotIds[i]
                if (i < recentPkgNames.size) {
                    val pkg = recentPkgNames[i]
                    try {
                        val appInfo = pm.getApplicationInfo(pkg, 0)
                        val name = pm.getApplicationLabel(appInfo).toString()
                        val iconDrawable = pm.getApplicationIcon(appInfo)
                        val bitmap = drawableToBitmap(iconDrawable)

                        views.setViewVisibility(layoutId, View.VISIBLE)
                        views.setImageViewBitmap(iconId, bitmap)
                        views.setTextViewText(nameId, name)

                        // Intent mở ứng dụng trực tiếp khi chạm vào icon trên thẻ widget
                        val launchIntent = pm.getLaunchIntentForPackage(pkg)?.apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        } ?: Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                            data = android.net.Uri.parse("package:$pkg")
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }

                        val launchPending = PendingIntent.getActivity(
                            context,
                            3000 + i,
                            launchIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                        )
                        views.setOnClickPendingIntent(layoutId, launchPending)
                    } catch (_: Exception) {
                        views.setViewVisibility(layoutId, View.GONE)
                    }
                } else {
                    views.setViewVisibility(layoutId, View.GONE)
                }
            }

            // Kiểm tra hàng 2 có app nào không, nếu không có thì ẩn hàng 2 để tiết kiệm không gian
            val hasRow2Apps = recentPkgNames.size > 5
            views.setViewVisibility(R.id.widget_recent_row_2, if (hasRow2Apps) View.VISIBLE else View.GONE)

            appWidgetManager.updateAppWidget(appWidgetId, views)
        }

        private fun drawableToBitmap(drawable: Drawable): Bitmap {
            if (drawable is BitmapDrawable && drawable.bitmap != null) {
                return drawable.bitmap
            }
            val width = if (drawable.intrinsicWidth > 0) drawable.intrinsicWidth else 96
            val height = if (drawable.intrinsicHeight > 0) drawable.intrinsicHeight else 96
            val bitmap = Bitmap.createBitmap(width.coerceAtMost(128), height.coerceAtMost(128), Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            drawable.setBounds(0, 0, canvas.width, canvas.height)
            drawable.draw(canvas)
            return bitmap
        }
    }

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        for (appWidgetId in appWidgetIds) {
            updateWidget(context, appWidgetManager, appWidgetId)
        }
    }
}
