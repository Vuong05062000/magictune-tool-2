package com.example.core.auth

import android.app.Activity
import android.content.Context
import android.util.Log
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.example.R
import com.example.core.license.LicenseManager
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.Companion.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.firestore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

object TimeFormatUtils {
    /**
     * Định dạng thời gian online cuối theo ngày thực tế (Real-Calendar Date Comparison):
     * - Xác định chính xác ngày hôm nay (ngày, tháng, năm) theo múi giờ thiết bị hiện tại.
     * - Nếu cùng ngày lịch với ngày hôm nay:
     *   + Dưới 3 phút: "🟢 Vừa online tức thì"
     *   + Dưới 60 phút: "🟢 Online X phút trước"
     *   + Còn lại trong ngày: "🟡 Online lúc HH:mm hôm nay (dd/MM)"
     * - Nếu rơi vào ngày hôm qua (dù cách dưới 24h, ví dụ 23:00 hôm 29 và 08:00 hôm 30):
     *   + Hiển thị chính xác: "⚪ Hôm qua (dd/MM) lúc HH:mm" (tuyệt đối không bị nhầm là hôm nay)
     * - Nếu trước ngày hôm qua:
     *   + Hiển thị đầy đủ ngày/tháng/năm và giờ: "⚪ dd/MM/yyyy lúc HH:mm"
     */
    fun formatLastActive(timestamp: com.google.firebase.Timestamp?): String {
        val date = timestamp?.toDate() ?: return "Chưa rõ thời gian"
        val now = java.util.Date()

        val timeFormat = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault())
        val dateFormat = java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault())
        val dayMonthFormat = java.text.SimpleDateFormat("dd/MM", java.util.Locale.getDefault())

        val diffMillis = now.time - date.time
        val diffMinutes = (diffMillis / (60 * 1000)).coerceAtLeast(0)

        val calNow = java.util.Calendar.getInstance().apply { time = now }
        val calDate = java.util.Calendar.getInstance().apply { time = date }

        val isSameYear = calNow.get(java.util.Calendar.YEAR) == calDate.get(java.util.Calendar.YEAR)
        val isSameDay = isSameYear && calNow.get(java.util.Calendar.DAY_OF_YEAR) == calDate.get(java.util.Calendar.DAY_OF_YEAR)

        val calYesterday = java.util.Calendar.getInstance().apply {
            time = now
            add(java.util.Calendar.DAY_OF_YEAR, -1)
        }
        val isYesterday = calYesterday.get(java.util.Calendar.YEAR) == calDate.get(java.util.Calendar.YEAR) &&
            calYesterday.get(java.util.Calendar.DAY_OF_YEAR) == calDate.get(java.util.Calendar.DAY_OF_YEAR)

        return when {
            isSameDay && diffMinutes < 3 -> "🟢 Vừa online tức thì"
            isSameDay && diffMinutes < 60 -> "🟢 Online $diffMinutes phút trước"
            isSameDay -> "🟡 Online lúc ${timeFormat.format(date)} hôm nay (${dayMonthFormat.format(date)})"
            isYesterday -> "⚪ Hôm qua (${dayMonthFormat.format(date)}) lúc ${timeFormat.format(date)}"
            else -> "⚪ ${dateFormat.format(date)} lúc ${timeFormat.format(date)}"
        }
    }
}

@IgnoreExtraProperties
data class UserProfile(
    val userId: String = "",
    val email: String = "",
    val phoneNumber: String = "",
    val displayName: String = "",
    val role: String = "user", // "admin" hoặc "user"
    val isPro: Boolean = false,
    val isAccountPro: Boolean = false,
    val proTier: String = "FREE", // "ACCOUNT_PRO", "DEVICE_PRO", "FREE"
    val deviceId: String = "",
    val hardwareId: String = "",
    val activeDeviceId: String = "",
    val activeDeviceModel: String = "",
    val activeSessionToken: String = "",
    val lastActive: com.google.firebase.Timestamp? = null,
    val createdAt: com.google.firebase.Timestamp? = null
) {
    fun getLastActiveFormatted(): String = TimeFormatUtils.formatLastActive(lastActive)

    fun getCreatedAtFormatted(): String {
        val timestamp = createdAt ?: return "Mới tham gia"
        val date = timestamp.toDate()
        val dateFormat = java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault())
        return dateFormat.format(date)
    }
}

@IgnoreExtraProperties
data class DeviceRecord(
    val deviceId: String = "",
    val hardwareId: String = "",
    val model: String = "",
    val isPro: Boolean = false,
    val isAccountPro: Boolean = false,
    val upgradedToAccountPro: Boolean = false,
    val revokedByAdmin: Boolean = false,
    val ownerUid: String = "",
    val ownerEmail: String = "",
    val ownerName: String = "",
    val freeTrialUsed: Int = 0,
    val licenseKey: String = "",
    val lastActive: com.google.firebase.Timestamp? = null,
    val createdAt: com.google.firebase.Timestamp? = null,
    val proActivatedAt: com.google.firebase.Timestamp? = null
) {
    fun getLastActiveFormatted(): String = TimeFormatUtils.formatLastActive(lastActive)

    fun getCreatedAtFormatted(): String {
        val timestamp = createdAt ?: return "Vừa thêm"
        val date = timestamp.toDate()
        val dateFormat = java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault())
        return dateFormat.format(date)
    }

    fun getProActivatedAtFormatted(): String {
        val timestamp = proActivatedAt ?: return "Chưa rõ"
        val date = timestamp.toDate()
        val dateFormat = java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", java.util.Locale.getDefault())
        return dateFormat.format(date)
    }
}

@IgnoreExtraProperties
data class PaymentIntentRecord(
    val intentId: String = "",
    val deviceId: String = "",
    val model: String = "",
    val ownerEmail: String = "",
    val ownerName: String = "",
    val actionType: String = "",
    val details: String = "",
    val isPro: Boolean = false,
    val timestamp: com.google.firebase.Timestamp? = null
) {
    fun getTimestampFormatted(): String {
        val ts = timestamp ?: return "Vừa xong"
        val date = ts.toDate()
        val fmt = java.text.SimpleDateFormat("HH:mm:ss dd/MM/yyyy", java.util.Locale.getDefault())
        return fmt.format(date)
    }
}

object FirebaseAuthManager {

    private const val TAG = "FirebaseAuthManager"
    private val INITIAL_ADMIN_EMAIL: String
        get() = runCatching { com.example.BuildConfig.ADMIN_EMAIL }.getOrNull()?.ifBlank { null } ?: "vuongdhkmhn@gmail.com"
    private val INITIAL_ADMIN_EMAIL_ALT: String
        get() = runCatching { com.example.BuildConfig.ADMIN_EMAIL }.getOrNull()?.ifBlank { null } ?: "vuongdhkmhn@gmail.com"
    private val INITIAL_ADMIN_PHONE: String
        get() = runCatching { com.example.BuildConfig.ADMIN_PHONE }.getOrNull()?.ifBlank { null } ?: "0393368007"
    const val ACTION_SINGLE_DEVICE_KICKED = "com.example.core.auth.ACTION_SINGLE_DEVICE_KICKED"

    private var singleDeviceListener: com.google.firebase.firestore.ListenerRegistration? = null
    private var watchedUserId: String? = null
    private var authStateListenerInitialized = false
    private val mainHandler = android.os.Handler(android.os.Looper.getMainLooper())

    fun getAuth(): FirebaseAuth = Firebase.auth
    fun getDb(): FirebaseFirestore = Firebase.firestore

    /**
     * Khởi chạy bộ gác cổng "1 Tài Khoản - 1 Thiết Bị Duy Nhất" theo thời gian thực (Real-time Single-Device Session Guard):
     * - Khi người dùng đăng nhập tài khoản trên Thiết Bị Mới (Máy B), `activeDeviceId` và `activeSessionToken` trên Firestore `users/{uid}` sẽ đổi sang Máy B.
     * - Thiết Bị Cũ (Máy A) đang lắng nghe `users/{uid}` sẽ phát hiện tức thì `activeDeviceId != localDeviceId`,
     *   tự động Đăng Xuất khỏi Máy A và thu hồi phiên Pro Tài Khoản trên Máy A ngay lập tức!
     */
    fun startSingleDeviceSessionGuard(context: Context) {
        val appCtx = context.applicationContext
        if (!authStateListenerInitialized) {
            authStateListenerInitialized = true
            try {
                Firebase.auth.addAuthStateListener { firebaseAuth ->
                    val current = firebaseAuth.currentUser
                    if (current != null) {
                        attachSingleDeviceListenerForUser(appCtx, current.uid)
                    } else {
                        singleDeviceListener?.remove()
                        singleDeviceListener = null
                        watchedUserId = null
                    }
                }
            } catch (_: Exception) {}
        }

        val currentUser = try { Firebase.auth.currentUser } catch (_: Exception) { null }
        if (currentUser != null) {
            attachSingleDeviceListenerForUser(appCtx, currentUser.uid)
        }
    }

    private fun attachSingleDeviceListenerForUser(appCtx: Context, uid: String) {
        if (uid.isBlank()) return
        if (watchedUserId == uid && singleDeviceListener != null) return

        singleDeviceListener?.remove()
        watchedUserId = uid

        try {
            singleDeviceListener = getDb().collection("users").document(uid)
                .addSnapshotListener { snapshot, error ->
                    if (error != null || snapshot == null || !snapshot.exists()) return@addSnapshotListener
                    val currentUser = try { Firebase.auth.currentUser } catch (_: Exception) { null }
                    if (currentUser == null || currentUser.uid != uid) return@addSnapshotListener

                    val localDeviceId = LicenseManager.getDeviceId(appCtx).trim().uppercase()
                    val remoteActiveDeviceId = (snapshot.getString("activeDeviceId") ?: "").trim().uppercase()
                    val remoteDeviceModel = (snapshot.getString("activeDeviceModel") ?: "Thiết bị mới").trim()
                    val remoteSessionToken = (snapshot.getString("activeSessionToken") ?: "").trim()
                    val remoteRole = (snapshot.getString("role") ?: "").trim()
                    val remoteEmail = (snapshot.getString("email") ?: currentUser.email ?: "").trim()

                    // ĐẶC QUYỀN ADMIN: Tài khoản Admin tuyệt đối KHÔNG BAO GIỜ bị SingleDeviceSessionGuard tự động đá văng / đăng xuất
                    // khi Admin đăng nhập kiểm tra trên nhiều máy hoặc khi cài đè APK mới!
                    val isAdminUser = remoteEmail.equals(INITIAL_ADMIN_EMAIL, ignoreCase = true) ||
                        remoteEmail.equals(INITIAL_ADMIN_EMAIL_ALT, ignoreCase = true) ||
                        remoteRole.equals("admin", ignoreCase = true) ||
                        LicenseManager.isCurrentUserAdmin(appCtx)

                    if (isAdminUser) {
                        if (remoteEmail.isNotBlank()) {
                            LicenseManager.markLocalAdminVerified(appCtx, remoteEmail)
                        }
                        return@addSnapshotListener
                    }

                    val prefs = appCtx.getSharedPreferences("magictune_pro_prefs", Context.MODE_PRIVATE)
                    val localSessionToken = (prefs.getString(LicenseManager.KEY_ACTIVE_SESSION_TOKEN, "") ?: "").trim()

                    // Kiểm tra nếu tài khoản vừa được đăng nhập trên một thiết bị KHÁC (activeDeviceId khác máy hiện tại)
                    val kickedByAnotherDevice = remoteActiveDeviceId.isNotBlank() &&
                            !remoteActiveDeviceId.equals(localDeviceId, ignoreCase = true)

                    val kickedByNewSessionOnOtherDevice = remoteSessionToken.isNotBlank() &&
                            localSessionToken.isNotBlank() &&
                            remoteSessionToken != localSessionToken &&
                            remoteActiveDeviceId.isNotBlank() &&
                            !remoteActiveDeviceId.equals(localDeviceId, ignoreCase = true)

                    if (kickedByAnotherDevice || kickedByNewSessionOnOtherDevice) {
                        Log.w(TAG, "Phát hiện đăng nhập trên máy mới ($remoteActiveDeviceId - $remoteDeviceModel). Tự động đăng xuất máy cũ ($localDeviceId)!")
                        singleDeviceListener?.remove()
                        singleDeviceListener = null
                        watchedUserId = null

                        try {
                            Firebase.auth.signOut()
                        } catch (_: Exception) {}

                        prefs.edit()
                            .remove("current_user_role")
                            .remove("current_user_email")
                            .remove(LicenseManager.KEY_ACTIVE_SESSION_TOKEN)
                            .apply()

                        // Thu hồi quyền Pro Tài Khoản trên máy cũ ngay lập tức để đảm bảo chỉ 1 máy dùng Pro
                        LicenseManager.deactivateAccountProOnLogout(appCtx)

                        try {
                            val credentialManager = CredentialManager.create(appCtx)
                            CoroutineScope(Dispatchers.IO).launch {
                                try {
                                    credentialManager.clearCredentialState(ClearCredentialStateRequest())
                                } catch (_: Exception) {}
                            }
                        } catch (_: Exception) {}

                        mainHandler.post {
                            try {
                                android.widget.Toast.makeText(
                                    appCtx,
                                    "⚠️ Tài khoản vừa đăng nhập trên máy mới ($remoteDeviceModel). Máy cũ đã tự động đăng xuất (Quy định 1 máy/tài khoản)!",
                                    android.widget.Toast.LENGTH_LONG
                                ).show()
                                appCtx.sendBroadcast(android.content.Intent(ACTION_SINGLE_DEVICE_KICKED))
                                appCtx.sendBroadcast(android.content.Intent(LicenseManager.ACTION_CONFIG_UPDATED))
                                appCtx.sendBroadcast(android.content.Intent(LicenseManager.ACTION_PRO_ACTIVATED))
                            } catch (_: Exception) {}
                        }
                        return@addSnapshotListener
                    }

                    // Nếu máy hiện tại đang là máy hợp lệ duy nhất và tài khoản có Pro Tài Khoản trên Cloud -> Đồng bộ xuống máy ngay
                    val cloudAccountPro = snapshot.getBoolean("isAccountPro") == true ||
                            snapshot.getString("proTier") == "ACCOUNT_PRO"
                    val cloudRevoked = snapshot.getBoolean("revokedByAdmin") == true

                    if (cloudRevoked && !LicenseManager.isCurrentUserAdmin(appCtx)) {
                        LicenseManager.deactivateAccountProOnLogout(appCtx)
                    } else if (cloudAccountPro && !LicenseManager.isAccountProActivated(appCtx)) {
                        LicenseManager.activateAccountPro(appCtx, "CLOUD_ACCOUNT_PRO_SYNC", syncToCloud = false)
                    }
                }
        } catch (e: Exception) {
            Log.e(TAG, "Lỗi khởi tạo SingleDeviceSessionGuard: ${e.message}")
        }
    }

    /**
     * Đọc trường Timestamp an toàn tuyệt đối (Không bao giờ văng lỗi "Field '...' is not a com.google.firebase.Timestamp"
     * kể cả khi dữ liệu cũ trên Firestore lưu dưới dạng số Long/Number, Date hoặc String).
     */
    fun safeGetTimestamp(
        doc: com.google.firebase.firestore.DocumentSnapshot,
        field: String
    ): com.google.firebase.Timestamp? {
        if (!doc.exists()) return null
        return try {
            when (val raw = doc.get(field)) {
                is com.google.firebase.Timestamp -> raw
                is Number -> {
                    val v = raw.toLong()
                    val millis = if (v in 1..9_999_999_999L) v * 1000L else v
                    if (millis > 0L) com.google.firebase.Timestamp(java.util.Date(millis)) else null
                }
                is java.util.Date -> com.google.firebase.Timestamp(raw)
                is String -> {
                    val v = raw.trim().toLongOrNull()
                    if (v != null && v > 0L) {
                        val millis = if (v in 1..9_999_999_999L) v * 1000L else v
                        com.google.firebase.Timestamp(java.util.Date(millis))
                    } else null
                }
                else -> null
            }
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Ghi nhớ email quen thuộc đã dùng trên thiết bị này để gợi ý đăng nhập nhanh
     */
    fun rememberFamiliarEmail(context: Context, email: String) {
        val clean = email.trim().lowercase()
        if (clean.isBlank() || !clean.contains("@") || clean.contains(" ")) return
        try {
            val prefs = context.getSharedPreferences("magictune_pro_prefs", Context.MODE_PRIVATE)
            val existingCsv = prefs.getString("familiar_emails_csv", "") ?: ""
            val list = existingCsv.split(",")
                .map { it.trim().lowercase() }
                .filter { it.isNotBlank() && it.contains("@") }
                .toMutableList()
            list.remove(clean)
            list.add(0, clean)
            val updatedCsv = list.take(5).joinToString(",")
            prefs.edit()
                .putString("familiar_emails_csv", updatedCsv)
                .putString("last_familiar_email", clean)
                .apply()
        } catch (_: Exception) {}
    }

    /**
     * Lấy danh sách email quen thuộc đã lưu cục bộ trên máy
     */
    fun getLocalFamiliarEmails(context: Context): List<String> {
        return try {
            val prefs = context.getSharedPreferences("magictune_pro_prefs", Context.MODE_PRIVATE)
            val result = mutableListOf<String>()
            val lastEmail = prefs.getString("last_familiar_email", "")?.trim()?.lowercase() ?: ""
            val currentEmail = prefs.getString("current_user_email", "")?.trim()?.lowercase() ?: ""
            val csv = prefs.getString("familiar_emails_csv", "") ?: ""
            if (lastEmail.contains("@")) result.add(lastEmail)
            if (currentEmail.contains("@") && !result.contains(currentEmail)) result.add(currentEmail)
            csv.split(",").map { it.trim().lowercase() }.forEach { item ->
                if (item.contains("@") && !result.contains(item)) {
                    result.add(item)
                }
            }
            result
        } catch (_: Exception) {
            emptyList()
        }
    }

    /**
     * Phát hiện thiết bị quen thuộc (từ Firestore devices & users + bộ nhớ máy) và trả về danh sách email gợi ý
     */
    suspend fun fetchFamiliarDeviceEmails(context: Context): Pair<Boolean, List<String>> = withContext(Dispatchers.IO) {
        val emails = getLocalFamiliarEmails(context).toMutableList()
        val deviceId = LicenseManager.getDeviceId(context).trim().uppercase()
        var isFamiliarDevice = emails.isNotEmpty() || LicenseManager.isProActivated(context)

        try {
            // 1. Kiểm tra trong bảng devices/{deviceId}
            val deviceDoc = getDb().collection("devices").document(deviceId).get().await()
            if (deviceDoc.exists()) {
                isFamiliarDevice = true
                val ownerEmail = (deviceDoc.getString("ownerEmail") ?: "").trim().lowercase()
                if (ownerEmail.contains("@") && !ownerEmail.contains(" ")) {
                    emails.remove(ownerEmail)
                    emails.add(0, ownerEmail)
                    rememberFamiliarEmail(context, ownerEmail)
                }
            }
        } catch (_: Exception) {}

        try {
            // 2. Kiểm tra trong bảng users có tài khoản nào gắn với mã thiết bị này không (không cần index)
            val normTarget = LicenseManager.normalizeDeviceIdForMatch(deviceId)
            val userQuery = getDb().collection("users").get().await()
            for (doc in userQuery.documents) {
                val docDev = LicenseManager.normalizeDeviceIdForMatch(doc.getString("deviceId") ?: "")
                val docActDev = LicenseManager.normalizeDeviceIdForMatch(doc.getString("activeDeviceId") ?: "")
                if (normTarget.isNotBlank() && (docDev == normTarget || docActDev == normTarget)) {
                    isFamiliarDevice = true
                    val uEmail = (doc.getString("email") ?: "").trim().lowercase()
                    if (uEmail.contains("@") && !uEmail.contains(" ")) {
                        if (!emails.contains(uEmail)) {
                            emails.add(uEmail)
                        }
                        rememberFamiliarEmail(context, uEmail)
                    }
                }
            }
        } catch (_: Exception) {}

        Pair(isFamiliarDevice, emails.distinct())
    }

    /**
     * Lấy User hiện tại đang đăng nhập
     */
    fun getCurrentUser(): FirebaseUser? = Firebase.auth.currentUser

    /**
     * Kiểm tra xem user hiện tại có phải là Admin hay không (Có fallback qua SharedPreferences nếu session Firebase chưa khôi phục)
     */
    fun isCurrentAdmin(context: Context? = null, profile: UserProfile? = null): Boolean {
        val u = try { getCurrentUser() } catch (_: Exception) { null }
        val email = (u?.email ?: profile?.email ?: "").trim()
        val phone = (u?.phoneNumber ?: profile?.phoneNumber ?: "").trim()
        val role = (profile?.role ?: "").trim()

        if (email.equals(INITIAL_ADMIN_EMAIL, ignoreCase = true) ||
            email.equals(INITIAL_ADMIN_EMAIL_ALT, ignoreCase = true) ||
            (phone.isNotBlank() && phone.contains(INITIAL_ADMIN_PHONE)) ||
            role.equals("admin", ignoreCase = true)
        ) {
            if (context != null && email.isNotBlank()) {
                LicenseManager.markLocalAdminVerified(context, email)
            }
            return true
        }

        if (context != null) {
            if (LicenseManager.isCurrentUserAdmin(context)) {
                return true
            }
            val prefs = context.getSharedPreferences("magictune_pro_prefs", Context.MODE_PRIVATE)
            val savedRole = (prefs.getString("current_user_role", "") ?: "").trim()
            val savedEmail = (prefs.getString("current_user_email", "") ?: "").trim()
            if (savedEmail.equals(INITIAL_ADMIN_EMAIL, ignoreCase = true) ||
                savedEmail.equals(INITIAL_ADMIN_EMAIL_ALT, ignoreCase = true) ||
                (savedEmail.isNotBlank() && savedRole.equals("admin", ignoreCase = true))
            ) {
                return true
            }
        }
        return false
    }

    /**
     * Đồng bộ hồ sơ người dùng lên Firestore ngay sau khi đăng nhập thành công.
     * Đồng thời ghi nhận `activeDeviceId` và `activeSessionToken` của máy mới lên `users/{uid}`
     * để kích hoạt cơ chế tự động đăng xuất trên máy cũ (1 tài khoản chỉ đăng nhập 1 máy tại 1 thời điểm).
     */
    suspend fun syncUserProfile(context: Context): UserProfile {
        val user = Firebase.auth.currentUser ?: throw IllegalStateException("Chưa đăng nhập Firebase!")
        val uid = user.uid
        val email = user.email ?: ""
        val phone = user.phoneNumber ?: ""
        val name = user.displayName ?: if (email.isNotBlank()) email.substringBefore("@") else "Người dùng Magictune_Tool"
        val deviceId = LicenseManager.getDeviceId(context).trim().uppercase()
        val deviceModel = "${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}"

        val docRef = getDb().collection("users").document(uid)
        val snap = try {
            docRef.get().await()
        } catch (e: Exception) {
            Log.w(TAG, "Không thể đọc users/$uid trên Firestore, dùng dữ liệu cục bộ: ${e.message}")
            null
        }

        val existingRole = try { snap?.getString("role") } catch (_: Exception) { null } ?: "user"
        val cloudPro = try { snap?.getBoolean("isPro") } catch (_: Exception) { null }
        val cloudAccountPro = try {
            (snap?.getBoolean("isAccountPro") == true) || (snap?.getString("proTier") == "ACCOUNT_PRO")
        } catch (_: Exception) { false }
        val previousBoundDeviceId = try {
            (snap?.getString("deviceId") ?: "").trim().uppercase()
        } catch (_: Exception) { "" }
        val previousActiveDeviceId = try {
            (snap?.getString("activeDeviceId") ?: "").trim().uppercase()
        } catch (_: Exception) { "" }

        val isAdminAccount = email.equals(INITIAL_ADMIN_EMAIL, ignoreCase = true) ||
                email.equals(INITIAL_ADMIN_EMAIL_ALT, ignoreCase = true) ||
                phone.contains(INITIAL_ADMIN_PHONE) ||
                existingRole == "admin"

        // QUAN TRỌNG: Quét đối chiếu bảng `devices` (và 8 tầng dữ liệu Cloud) TRƯỚC KHI tính toán trạng thái Pro của hồ sơ đăng nhập!
        // Điều này ngăn chặn triệt để lỗi: thiết bị đã được cấp Pro trong bảng `devices/{deviceId}` nhưng khi cài lại app và đăng nhập,
        // `users/{uid}` lại ghi đè `isPro = false` do chưa kịp đọc trạng thái Pro từ bảng `devices`.
        val cloudDeviceRecognized = try {
            LicenseManager.checkDeviceRecognizedProInCloud(context)
        } catch (_: Exception) {
            false
        }

        val localAccountPro = LicenseManager.isAccountProActivated(context) || LicenseManager.hasPendingAccountProBind(context)
        val localDevicePro = cloudDeviceRecognized || LicenseManager.isProActivated(context)

        // Tài khoản có gói PRO TÀI KHOẢN (được phép mang quyền Pro sang thiết bị khác) khi:
        // - Là Admin, hoặc đã nâng cấp Pro Tài Khoản trên Cloud (`cloudAccountPro`), hoặc vừa kích hoạt Pro Tài Khoản trên máy này (`localAccountPro`)
        val isAccountProToSave = isAdminAccount || cloudAccountPro || localAccountPro

        // Xác định quyền Pro trên thiết bị hiện tại:
        // - Nếu có Pro Tài Khoản (`isAccountProToSave == true`): Được kích hoạt Pro trên BẤT KỲ thiết bị nào đăng nhập (và tự động đá thiết bị cũ ra).
        // - Nếu chỉ có Pro Thiết Bị (`isAccountProToSave == false`): Chỉ máy có đúng ID thiết bị đã mua Pro Thiết Bị mới có Pro; đăng nhập sang máy khác sẽ KHÔNG tự có Pro nếu chưa nâng cấp lên Pro Tài Khoản!
        val normCurrent = LicenseManager.normalizeDeviceIdForMatch(deviceId)
        val isSameOriginalProDevice = cloudPro == true && (
            (previousBoundDeviceId.isNotBlank() && LicenseManager.isDeviceIdMatchingCurrentDevice(context, previousBoundDeviceId)) ||
                (previousActiveDeviceId.isNotBlank() && LicenseManager.isDeviceIdMatchingCurrentDevice(context, previousActiveDeviceId)) ||
                (previousBoundDeviceId.isNotBlank() && LicenseManager.normalizeDeviceIdForMatch(previousBoundDeviceId) == normCurrent) ||
                (previousActiveDeviceId.isNotBlank() && LicenseManager.normalizeDeviceIdForMatch(previousActiveDeviceId) == normCurrent)
            )
        val isProOnThisDevice = isAccountProToSave || localDevicePro || isSameOriginalProDevice
        val isProToSaveInUserDoc = isAccountProToSave || (cloudPro == true) || localDevicePro
        val proTierToSave = when {
            isAccountProToSave -> "ACCOUNT_PRO"
            isProToSaveInUserDoc -> "DEVICE_PRO"
            else -> "FREE"
        }

        val roleToSave = if (isAdminAccount) "admin" else existingRole

        // Tạo mã phiên đăng nhập mới cho thiết bị này để vô hiệu hóa mọi thiết bị cũ đang đăng nhập cùng tài khoản
        val newSessionToken = "${deviceId}_${System.currentTimeMillis()}"

        val prefs = context.getSharedPreferences("magictune_pro_prefs", Context.MODE_PRIVATE)
        prefs.edit()
            .putString("current_user_role", roleToSave)
            .putString("current_user_email", email)
            .putString(LicenseManager.KEY_ACTIVE_SESSION_TOKEN, newSessionToken)
            .apply()
        if (isAdminAccount && email.isNotBlank()) {
            LicenseManager.markLocalAdminVerified(context, email)
        }
        rememberFamiliarEmail(context, email)

        val existingCreatedAt = if (snap != null) safeGetTimestamp(snap, "createdAt") else null
        val hwId = LicenseManager.getHardwareId()

        val profileData = mutableMapOf<String, Any>(
            "userId" to uid,
            "email" to email,
            "phoneNumber" to phone,
            "displayName" to name,
            "role" to roleToSave,
            "isPro" to isProToSaveInUserDoc,
            "isAccountPro" to isAccountProToSave,
            "proTier" to proTierToSave,
            "deviceId" to if (previousBoundDeviceId.isNotBlank() && !isAccountProToSave) previousBoundDeviceId else deviceId,
            "hardwareId" to hwId,
            "activeDeviceId" to deviceId,
            "activeDeviceModel" to deviceModel,
            "activeSessionToken" to newSessionToken,
            "lastActive" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        if (snap == null || !snap.exists() || snap.get("createdAt") !is com.google.firebase.Timestamp) {
            profileData["createdAt"] = existingCreatedAt ?: FieldValue.serverTimestamp()
        }

        try {
            docRef.set(profileData, SetOptions.merge()).await()
            // Nếu tài khoản có Pro Tài Khoản đăng nhập sang thiết bị mới -> Thu hồi trạng thái Pro trên thiết bị cũ trong bảng `devices` (1 máy/lần)
            if (isAccountProToSave && previousActiveDeviceId.isNotBlank() &&
                LicenseManager.normalizeDeviceIdForMatch(previousActiveDeviceId) != normCurrent
            ) {
                getDb().collection("devices").document(previousActiveDeviceId).set(
                    mapOf(
                        "isPro" to false,
                        "isAccountPro" to false,
                        "licenseKey" to "",
                        "updatedAt" to FieldValue.serverTimestamp()
                    ),
                    SetOptions.merge()
                )
            }
        } catch (e: Exception) {
            Log.w(TAG, "Không thể ghi hồ sơ users/$uid lên Firestore: ${e.message}")
        }

        if (isAdminAccount) {
            // Đặc quyền Admin: Tự động cấp Pro vĩnh viễn (gồm cả Pro Tài Khoản và Pro Thiết Bị cố định theo máy) cho bất kỳ thiết bị nào Admin đăng nhập
            LicenseManager.activateAccountPro(context, "ADMIN_LOGIN_AUTO_GRANT_PERMANENT", syncToCloud = true)
            LicenseManager.setProActivated(context, true, "ADMIN_LOGIN_AUTO_GRANT_PERMANENT", syncToCloud = true)
        } else if (isAccountProToSave) {
            LicenseManager.activateAccountPro(context, "FIREBASE_ACCOUNT_PRO_LOGIN", syncToCloud = true)
        } else if (isProOnThisDevice) {
            LicenseManager.setProActivated(context, true, "FIREBASE_DEVICE_PRO_SYNC", syncToCloud = true)
        } else {
            // Máy mới đăng nhập vào tài khoản chỉ có Pro Thiết Bị của máy cũ -> Không cấp Pro chùa trên máy mới
            LicenseManager.deactivateAccountProOnLogout(context)
            LicenseManager.syncDevicePresenceToCloud(context)
        }

        // Bật ngay bộ gác cổng 1 thiết bị / 1 tài khoản sau khi đồng bộ
        startSingleDeviceSessionGuard(context)

        return UserProfile(
            userId = uid,
            email = email,
            phoneNumber = phone,
            displayName = name,
            role = roleToSave,
            isPro = isProOnThisDevice,
            isAccountPro = isAccountProToSave,
            proTier = proTierToSave,
            deviceId = deviceId,
            hardwareId = hwId,
            activeDeviceId = deviceId,
            activeDeviceModel = deviceModel,
            activeSessionToken = newSessionToken,
            lastActive = com.google.firebase.Timestamp.now(),
            createdAt = existingCreatedAt ?: com.google.firebase.Timestamp.now()
        )
    }

    private fun safeParseRestTimestamp(raw: Any?): com.google.firebase.Timestamp? {
        if (raw == null) return null
        return try {
            when (raw) {
                is com.google.firebase.Timestamp -> raw
                is java.util.Date -> com.google.firebase.Timestamp(raw)
                is Number -> {
                    val v = raw.toLong()
                    val millis = if (v in 1..9_999_999_999L) v * 1000L else v
                    if (millis > 0L) com.google.firebase.Timestamp(java.util.Date(millis)) else null
                }
                is String -> {
                    val s = raw.trim()
                    val numeric = s.toLongOrNull()
                    if (numeric != null && numeric > 0L) {
                        val millis = if (numeric in 1..9_999_999_999L) numeric * 1000L else numeric
                        com.google.firebase.Timestamp(java.util.Date(millis))
                    } else {
                        val cleanIso = s.substringBefore(".").removeSuffix("Z")
                        val fmt = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", java.util.Locale.US).apply {
                            timeZone = java.util.TimeZone.getTimeZone("UTC")
                        }
                        val parsed = fmt.parse(cleanIso)
                        if (parsed != null) com.google.firebase.Timestamp(parsed) else null
                    }
                }
                else -> null
            }
        } catch (_: Exception) {
            null
        }
    }

    suspend fun fetchAllUsersViaRest(context: Context): List<UserProfile> = withContext(Dispatchers.IO) {
        try {
            val rawDocs = LicenseManager.fetchAdminCollectionMapsViaRest(context, "users", 400)
            rawDocs.mapNotNull { m ->
                try {
                    val docId = (m["__id"] as? String).orEmpty()
                    val lastAct = safeParseRestTimestamp(m["lastActive"]) ?: safeParseRestTimestamp(m["updatedAt"])
                    val created = safeParseRestTimestamp(m["createdAt"])
                    val isAccPro = (m["isAccountPro"] as? Boolean == true) || ((m["proTier"] as? String) == "ACCOUNT_PRO")
                    val rawPro = (m["isPro"] as? Boolean == true) || isAccPro
                    val devId = (m["deviceId"] as? String).orEmpty()
                    UserProfile(
                        userId = (m["userId"] as? String)?.takeIf { it.isNotBlank() } ?: docId,
                        email = (m["email"] as? String).orEmpty(),
                        phoneNumber = (m["phoneNumber"] as? String).orEmpty(),
                        displayName = (m["displayName"] as? String)?.takeIf { it.isNotBlank() } ?: "Chưa đặt tên",
                        role = (m["role"] as? String)?.takeIf { it.isNotBlank() } ?: "user",
                        isPro = rawPro,
                        isAccountPro = isAccPro,
                        proTier = (m["proTier"] as? String)?.takeIf { it.isNotBlank() }
                            ?: if (isAccPro) "ACCOUNT_PRO" else if (rawPro) "DEVICE_PRO" else "FREE",
                        deviceId = devId,
                        activeDeviceId = (m["activeDeviceId"] as? String)?.takeIf { it.isNotBlank() } ?: devId,
                        activeDeviceModel = (m["activeDeviceModel"] as? String).orEmpty(),
                        activeSessionToken = (m["activeSessionToken"] as? String).orEmpty(),
                        lastActive = lastAct,
                        createdAt = created
                    )
                } catch (_: Exception) {
                    null
                }
            }.sortedWith(
                compareByDescending<UserProfile> { it.isPro }
                    .thenByDescending { it.lastActive?.toDate()?.time ?: it.createdAt?.toDate()?.time ?: 0L }
            )
        } catch (_: Exception) {
            emptyList()
        }
    }

    suspend fun fetchAllDevicesViaRest(context: Context): List<DeviceRecord> = withContext(Dispatchers.IO) {
        try {
            val rawDocs = LicenseManager.fetchAdminCollectionMapsViaRest(context, "devices", 400)
            rawDocs.mapNotNull { m ->
                try {
                    val docId = (m["__id"] as? String).orEmpty()
                    val ts = safeParseRestTimestamp(m["lastActive"]) ?: safeParseRestTimestamp(m["updatedAt"])
                    val created = safeParseRestTimestamp(m["createdAt"])
                    val proAt = safeParseRestTimestamp(m["proActivatedAt"])
                    val dKey = (m["licenseKey"] as? String).orEmpty().trim()
                    val dReason = (m["approvedByAiReason"] as? String).orEmpty().trim()
                    val dRevoked = (m["revokedByAdmin"] as? Boolean) ?: false
                    val dUpgraded = (m["upgradedToAccountPro"] as? Boolean) ?: false
                    val dAccPro = (m["isAccountPro"] as? Boolean == true) || ((m["proTier"] as? String) == "ACCOUNT_PRO")
                    val effectivePro = !dRevoked && (
                        (m["isPro"] as? Boolean == true) ||
                            dAccPro ||
                            dUpgraded ||
                            dKey.isNotBlank() ||
                            proAt != null ||
                            dReason.isNotBlank()
                        )
                    DeviceRecord(
                        deviceId = (m["deviceId"] as? String)?.takeIf { it.isNotBlank() } ?: docId,
                        model = (m["model"] as? String)?.takeIf { it.isNotBlank() } ?: "Thiết bị Android",
                        isPro = effectivePro,
                        isAccountPro = dAccPro,
                        upgradedToAccountPro = dUpgraded,
                        revokedByAdmin = dRevoked,
                        ownerUid = (m["ownerUid"] as? String).orEmpty(),
                        ownerEmail = (m["ownerEmail"] as? String)?.takeIf { it.isNotBlank() } ?: "👤 Khách vãng lai (Chưa đăng nhập)",
                        ownerName = (m["ownerName"] as? String)?.takeIf { it.isNotBlank() } ?: "Khách vãng lai",
                        freeTrialUsed = (m["freeTrialUsed"] as? Number)?.toInt() ?: 0,
                        licenseKey = dKey,
                        lastActive = ts,
                        createdAt = created,
                        proActivatedAt = proAt
                    )
                } catch (_: Exception) {
                    null
                }
            }.sortedWith(
                compareByDescending<DeviceRecord> { it.isPro }
                    .thenByDescending {
                        it.lastActive?.toDate()?.time
                            ?: it.proActivatedAt?.toDate()?.time
                            ?: it.createdAt?.toDate()?.time
                            ?: 0L
                    }
            )
        } catch (_: Exception) {
            emptyList()
        }
    }

    suspend fun fetchPaymentIntentsViaRest(context: Context): List<PaymentIntentRecord> = withContext(Dispatchers.IO) {
        try {
            val rawDocs = LicenseManager.fetchAdminCollectionMapsViaRest(context, "payment_intents", 300)
            val parsed = rawDocs.mapNotNull { m ->
                try {
                    val docId = (m["__id"] as? String).orEmpty()
                    val rawDeviceId = (m["deviceId"] as? String).orEmpty().trim().ifBlank {
                        docId.substringBefore("_").trim()
                    }
                    val normId = LicenseManager.normalizeDeviceIdForMatch(rawDeviceId)
                    val canonicalDeviceId = if (normId.isNotBlank()) "MT-$normId" else rawDeviceId
                    PaymentIntentRecord(
                        intentId = docId,
                        deviceId = canonicalDeviceId,
                        model = (m["model"] as? String).orEmpty(),
                        ownerEmail = (m["ownerEmail"] as? String).orEmpty(),
                        ownerName = (m["ownerName"] as? String).orEmpty(),
                        actionType = (m["actionType"] as? String).orEmpty(),
                        details = (m["details"] as? String).orEmpty(),
                        isPro = (m["isPro"] as? Boolean) ?: false,
                        timestamp = safeParseRestTimestamp(m["timestamp"])
                    )
                } catch (_: Exception) {
                    null
                }
            }
            parsed.groupBy { rec ->
                LicenseManager.normalizeDeviceIdForMatch(rec.deviceId).ifBlank {
                    "${rec.ownerEmail.trim().lowercase()}_${rec.model.trim().lowercase()}"
                }
            }.mapValues { (_, list) ->
                list.sortedWith(
                    compareByDescending<PaymentIntentRecord> { it.actionType == "CLICKED_I_PAID" }
                        .thenByDescending { it.timestamp?.toDate()?.time ?: 0L }
                ).first()
            }.values
                .filter { !it.isPro }
                .sortedByDescending { it.timestamp?.toDate()?.time ?: 0L }
                .take(100)
        } catch (_: Exception) {
            emptyList()
        }
    }

    suspend fun fetchHonorAppsViaRest(context: Context): List<com.example.data.HonorAppItem> = withContext(Dispatchers.IO) {
        try {
            val rawDocs = LicenseManager.fetchAdminCollectionMapsViaRest(context, "honor_apps", 200)
            rawDocs.mapNotNull { m ->
                try {
                    val docId = (m["__id"] as? String).orEmpty()
                    com.example.data.HonorAppItem(
                        id = (m["id"] as? String)?.takeIf { it.isNotBlank() } ?: docId,
                        name = (m["name"] as? String).orEmpty(),
                        description = (m["description"] as? String).orEmpty(),
                        downloadUrl = (m["downloadUrl"] as? String).orEmpty(),
                        category = (m["category"] as? String)?.takeIf { it.isNotBlank() } ?: "Tiện Ích",
                        version = (m["version"] as? String)?.takeIf { it.isNotBlank() } ?: "1.0",
                        author = (m["author"] as? String)?.takeIf { it.isNotBlank() } ?: "Admin VXM",
                        isProOnly = (m["isProOnly"] as? Boolean) ?: false,
                        iconName = (m["iconName"] as? String)?.takeIf { it.isNotBlank() } ?: "apps",
                        status = (m["status"] as? String)?.takeIf { it.isNotBlank() } ?: "APPROVED",
                        contributorEmail = (m["contributorEmail"] as? String).orEmpty(),
                        createdAt = (m["createdAt"] as? Number)?.toLong()
                            ?: safeParseRestTimestamp(m["createdAt"])?.toDate()?.time
                            ?: 0L
                    )
                } catch (_: Exception) {
                    null
                }
            }.sortedByDescending { it.createdAt }
        } catch (_: Exception) {
            emptyList()
        }
    }

    /**
     * Lắng nghe danh sách TẤT CẢ Người Dùng dành cho ADMIN (Kênh Kép: Nạp ngay qua REST + Lắng nghe Realtime SDK)
     */
    fun observeAllUsers(context: Context? = null): Flow<List<UserProfile>> = callbackFlow {
        if (context != null) {
            val appCtx = context.applicationContext
            launch(Dispatchers.IO) {
                val initialRest = fetchAllUsersViaRest(appCtx)
                if (initialRest.isNotEmpty()) {
                    trySend(initialRest)
                }
            }
        }
        val listener = getDb().collection("users")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(TAG, "Cảnh báo lắng nghe danh sách users: ${error.message}")
                    if (context != null) {
                        val appCtx = context.applicationContext
                        launch(Dispatchers.IO) {
                            val fallback = fetchAllUsersViaRest(appCtx)
                            if (fallback.isNotEmpty()) {
                                trySend(fallback)
                            }
                        }
                    }
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val list = snapshot.documents.mapNotNull { doc ->
                        try {
                            val lastAct = safeGetTimestamp(doc, "lastActive") ?: safeGetTimestamp(doc, "updatedAt")
                            val created = safeGetTimestamp(doc, "createdAt")
                            val isAccPro = (doc.getBoolean("isAccountPro") == true) || (doc.getString("proTier") == "ACCOUNT_PRO")
                            UserProfile(
                                userId = doc.getString("userId") ?: doc.id,
                                email = doc.getString("email") ?: "",
                                phoneNumber = doc.getString("phoneNumber") ?: "",
                                displayName = doc.getString("displayName") ?: "Chưa đặt tên",
                                role = doc.getString("role") ?: "user",
                                isPro = (doc.getBoolean("isPro") ?: false) || isAccPro,
                                isAccountPro = isAccPro,
                                proTier = doc.getString("proTier") ?: if (isAccPro) "ACCOUNT_PRO" else if (doc.getBoolean("isPro") == true) "DEVICE_PRO" else "FREE",
                                deviceId = doc.getString("deviceId") ?: "",
                                activeDeviceId = doc.getString("activeDeviceId") ?: (doc.getString("deviceId") ?: ""),
                                activeDeviceModel = doc.getString("activeDeviceModel") ?: "",
                                activeSessionToken = doc.getString("activeSessionToken") ?: "",
                                lastActive = lastAct,
                                createdAt = created
                            )
                        } catch (_: Exception) { null }
                    }.sortedWith(
                        compareByDescending<UserProfile> { it.isPro }
                            .thenByDescending { it.lastActive?.toDate()?.time ?: it.createdAt?.toDate()?.time ?: 0L }
                    )
                    trySend(list)
                }
            }
        awaitClose { listener.remove() }
    }

    /**
     * Lắng nghe danh sách TẤT CẢ Thiết Bị dành cho ADMIN (Kênh Kép: Nạp ngay qua REST + Lắng nghe Realtime SDK)
     */
    fun observeAllDevices(context: Context? = null): Flow<List<DeviceRecord>> = callbackFlow {
        if (context != null) {
            val appCtx = context.applicationContext
            launch(Dispatchers.IO) {
                val initialRest = fetchAllDevicesViaRest(appCtx)
                if (initialRest.isNotEmpty()) {
                    trySend(initialRest)
                }
            }
        }
        val listener = getDb().collection("devices")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(TAG, "Cảnh báo lắng nghe danh sách devices: ${error.message}")
                    if (context != null) {
                        val appCtx = context.applicationContext
                        launch(Dispatchers.IO) {
                            val fallback = fetchAllDevicesViaRest(appCtx)
                            if (fallback.isNotEmpty()) {
                                trySend(fallback)
                            }
                        }
                    }
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val list = snapshot.documents.mapNotNull { doc ->
                        try {
                            val ts = safeGetTimestamp(doc, "lastActive") ?: safeGetTimestamp(doc, "updatedAt")
                            val created = safeGetTimestamp(doc, "createdAt")
                            val proAt = safeGetTimestamp(doc, "proActivatedAt")
                            val dKey = (doc.getString("licenseKey") ?: "").trim()
                            val dReason = (doc.getString("approvedByAiReason") ?: "").trim()
                            val dRevoked = doc.getBoolean("revokedByAdmin") ?: false
                            val dUpgraded = doc.getBoolean("upgradedToAccountPro") ?: false
                            val dAccPro = (doc.getBoolean("isAccountPro") ?: false) || (doc.getString("proTier") == "ACCOUNT_PRO")
                            val effectivePro = !dRevoked && (
                                (doc.getBoolean("isPro") ?: false) ||
                                    dAccPro ||
                                    dUpgraded ||
                                    dKey.isNotBlank() ||
                                    proAt != null ||
                                    dReason.isNotBlank()
                                )
                            DeviceRecord(
                                deviceId = doc.getString("deviceId") ?: doc.id,
                                model = doc.getString("model") ?: "Thiết bị Android",
                                isPro = effectivePro,
                                isAccountPro = dAccPro,
                                upgradedToAccountPro = dUpgraded,
                                revokedByAdmin = dRevoked,
                                ownerUid = doc.getString("ownerUid") ?: "",
                                ownerEmail = doc.getString("ownerEmail") ?: "👤 Khách vãng lai (Chưa đăng nhập)",
                                ownerName = doc.getString("ownerName") ?: "Khách vãng lai",
                                freeTrialUsed = (doc.get("freeTrialUsed") as? Number)?.toInt() ?: 0,
                                licenseKey = dKey,
                                lastActive = ts,
                                createdAt = created,
                                proActivatedAt = proAt
                            )
                        } catch (_: Exception) { null }
                    }.sortedWith(
                        compareByDescending<DeviceRecord> { it.isPro }
                            .thenByDescending {
                                it.lastActive?.toDate()?.time
                                    ?: it.proActivatedAt?.toDate()?.time
                                    ?: it.createdAt?.toDate()?.time
                                    ?: 0L
                            }
                    )
                    trySend(list)
                }
            }
        awaitClose { listener.remove() }
    }

    /**
     * Lắng nghe danh sách ý định thanh toán / hoạt động khách hàng dành cho ADMIN (Kênh Kép: REST + Realtime SDK)
     */
    fun observePaymentIntents(context: Context? = null): Flow<List<PaymentIntentRecord>> = callbackFlow {
        if (context != null) {
            val appCtx = context.applicationContext
            launch(Dispatchers.IO) {
                val initialRest = fetchPaymentIntentsViaRest(appCtx)
                if (initialRest.isNotEmpty()) {
                    trySend(initialRest)
                }
            }
        }
        val db = getDb()
        val listener = db.collection("payment_intents")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(TAG, "Cảnh báo lắng nghe danh sách payment_intents: ${error.message}")
                    if (context != null) {
                        val appCtx = context.applicationContext
                        launch(Dispatchers.IO) {
                            val fallback = fetchPaymentIntentsViaRest(appCtx)
                            if (fallback.isNotEmpty()) {
                                trySend(fallback)
                            }
                        }
                    }
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val rawDocs = snapshot.documents.mapNotNull { doc ->
                        try {
                            val rawDeviceId = (doc.getString("deviceId") ?: "").trim().ifBlank {
                                doc.id.substringBefore("_").trim()
                            }
                            val normId = LicenseManager.normalizeDeviceIdForMatch(rawDeviceId)
                            val canonicalDeviceId = if (normId.isNotBlank()) "MT-$normId" else rawDeviceId
                            val record = PaymentIntentRecord(
                                intentId = doc.id,
                                deviceId = canonicalDeviceId,
                                model = doc.getString("model") ?: "",
                                ownerEmail = doc.getString("ownerEmail") ?: "",
                                ownerName = doc.getString("ownerName") ?: "",
                                actionType = doc.getString("actionType") ?: "",
                                details = doc.getString("details") ?: "",
                                isPro = doc.getBoolean("isPro") ?: false,
                                timestamp = safeGetTimestamp(doc, "timestamp")
                            )
                            Pair(doc, record)
                        } catch (_: Exception) { null }
                    }

                    val grouped = rawDocs.groupBy { (_, rec) ->
                        LicenseManager.normalizeDeviceIdForMatch(rec.deviceId).ifBlank {
                            "${rec.ownerEmail.trim().lowercase()}_${rec.model.trim().lowercase()}"
                        }
                    }

                    val deduplicated = mutableListOf<PaymentIntentRecord>()
                    val duplicateDocRefsToDelete = mutableListOf<com.google.firebase.firestore.DocumentReference>()

                    for ((_, docPairs) in grouped) {
                        val sorted = docPairs.sortedWith(
                            compareByDescending<Pair<com.google.firebase.firestore.DocumentSnapshot, PaymentIntentRecord>> {
                                it.second.actionType == "CLICKED_I_PAID"
                            }.thenByDescending {
                                it.second.timestamp?.toDate()?.time ?: 0L
                            }
                        )
                        val keeper = sorted.first().second
                        if (!keeper.isPro) {
                            deduplicated.add(keeper)
                        }
                        if (sorted.size > 1) {
                            sorted.drop(1).forEach { (dupDoc, _) ->
                                duplicateDocRefsToDelete.add(dupDoc.reference)
                            }
                        }
                    }

                    if (duplicateDocRefsToDelete.isNotEmpty()) {
                        try {
                            val batch = db.batch()
                            duplicateDocRefsToDelete.take(400).forEach { ref -> batch.delete(ref) }
                            batch.commit()
                        } catch (_: Exception) {}
                    }

                    val finalSorted = deduplicated
                        .sortedByDescending { it.timestamp?.toDate()?.time ?: 0L }
                        .take(100)
                    trySend(finalSorted)
                }
            }
        awaitClose { listener.remove() }
    }

    /**
     * Lắng nghe danh sách ỨNG DỤNG TRONG KHO (Kênh Kép: REST + Realtime SDK)
     */
    fun observeHonorApps(context: Context? = null): Flow<List<com.example.data.HonorAppItem>> = callbackFlow {
        if (context != null) {
            val appCtx = context.applicationContext
            launch(Dispatchers.IO) {
                val initialRest = fetchHonorAppsViaRest(appCtx)
                if (initialRest.isNotEmpty()) {
                    trySend(initialRest)
                }
            }
        }
        val listener = getDb().collection("honor_apps")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(TAG, "Cảnh báo lắng nghe danh sách honor_apps: ${error.message}")
                    if (context != null) {
                        val appCtx = context.applicationContext
                        launch(Dispatchers.IO) {
                            val fallback = fetchHonorAppsViaRest(appCtx)
                            if (fallback.isNotEmpty()) {
                                trySend(fallback)
                            }
                        }
                    }
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val list = snapshot.documents.mapNotNull { doc ->
                        try {
                            com.example.data.HonorAppItem(
                                id = doc.id,
                                name = doc.getString("name") ?: "",
                                description = doc.getString("description") ?: "",
                                downloadUrl = doc.getString("downloadUrl") ?: "",
                                category = doc.getString("category") ?: "Tiện Ích",
                                version = doc.getString("version") ?: "1.0",
                                author = doc.getString("author") ?: "Admin VXM",
                                isProOnly = doc.getBoolean("isProOnly") ?: false,
                                iconName = doc.getString("iconName") ?: "apps",
                                status = doc.getString("status") ?: "APPROVED",
                                contributorEmail = doc.getString("contributorEmail") ?: "",
                                createdAt = (doc.get("createdAt") as? Number)?.toLong()
                                    ?: safeGetTimestamp(doc, "createdAt")?.toDate()?.time
                                    ?: 0L
                            )
                        } catch (_: Exception) { null }
                    }.sortedByDescending { it.createdAt }
                    trySend(list)
                }
            }
        awaitClose { listener.remove() }
    }

    /**
     * ADMIN: Thêm hoặc Cập nhật ứng dụng vào Kho App
     */
    suspend fun saveHonorApp(app: com.example.data.HonorAppItem) {
        val collection = getDb().collection("honor_apps")
        val docRef = if (app.id.isNotBlank()) collection.document(app.id) else collection.document()
        val data = mapOf(
            "id" to docRef.id,
            "name" to app.name.trim(),
            "description" to app.description.trim(),
            "downloadUrl" to app.downloadUrl.trim(),
            "category" to app.category.trim(),
            "version" to app.version.trim(),
            "author" to app.author.trim(),
            "isProOnly" to app.isProOnly,
            "iconName" to app.iconName.trim(),
            "status" to app.status,
            "contributorEmail" to app.contributorEmail,
            "updatedAt" to FieldValue.serverTimestamp(),
            "createdAt" to (if (app.createdAt > 0) app.createdAt else System.currentTimeMillis())
        )
        docRef.set(data, SetOptions.merge()).await()
    }

    /**
     * NGƯỜI DÙNG: Đóng góp ứng dụng vào Kho App (Cần Admin duyệt)
     */
    suspend fun contributeHonorApp(app: com.example.data.HonorAppItem) {
        val collection = getDb().collection("honor_apps")
        val docRef = collection.document()
        val data = mapOf(
            "id" to docRef.id,
            "name" to app.name.trim(),
            "description" to app.description.trim(),
            "downloadUrl" to app.downloadUrl.trim(),
            "category" to app.category.trim(),
            "version" to app.version.trim(),
            "author" to app.author.trim(),
            "isProOnly" to app.isProOnly,
            "iconName" to app.iconName.trim(),
            "status" to "PENDING",
            "contributorEmail" to (getCurrentUser()?.email ?: ""),
            "createdAt" to System.currentTimeMillis()
        )
        docRef.set(data).await()
    }

    /**
     * ADMIN: Duyệt hoặc Từ chối ứng dụng
     */
    suspend fun updateHonorAppStatus(appId: String, newStatus: String) {
        getDb().collection("honor_apps").document(appId)
            .update("status", newStatus)
            .await()
    }

    /**
     * ADMIN: Xóa ứng dụng khỏi Kho App
     */
    suspend fun deleteHonorApp(appId: String) {
        if (appId.isNotBlank()) {
            getDb().collection("honor_apps").document(appId).delete().await()
        }
    }

    /**
     * ADMIN: Nâng cấp một tài khoản bất kỳ lên làm ADMIN
     */
    suspend fun upgradeUserToAdmin(targetUserId: String) {
        getDb().collection("users").document(targetUserId)
            .update(
                mapOf(
                    "role" to "admin",
                    "isPro" to true,
                    "isAccountPro" to true,
                    "proTier" to "ACCOUNT_PRO",
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
    }

    /**
     * ADMIN: Kích hoạt / Hủy bản PRO TÀI KHOẢN (Account Pro - Đổi máy tự do, 1 máy hoạt động) cho một tài khoản
     */
    suspend fun toggleUserProStatus(targetUserId: String, isPro: Boolean, deviceId: String = "") {
        getDb().collection("users").document(targetUserId)
            .set(
                mapOf(
                    "appId" to "magictune",
                    "product" to "MAGICTUNE_PRO",
                    "magictunePro" to isPro,
                    "magictuneTier" to if (isPro) "ACCOUNT_PRO" else "FREE",
                    "isPro" to isPro,
                    "isAccountPro" to isPro,
                    "proTier" to if (isPro) "ACCOUNT_PRO" else "FREE",
                    "revokedByAdmin" to !isPro,
                    "updatedAt" to FieldValue.serverTimestamp()
                ),
                SetOptions.merge()
            ).await()

        val resolvedDeviceId = if (deviceId.isNotBlank()) {
            deviceId
        } else {
            try {
                val doc = getDb().collection("users").document(targetUserId).get().await()
                doc.getString("activeDeviceId") ?: doc.getString("deviceId") ?: ""
            } catch (_: Exception) { "" }
        }

        if (resolvedDeviceId.isNotBlank()) {
            val cleanId = resolvedDeviceId.trim().uppercase()
            val devMap = mutableMapOf<String, Any>(
                "deviceId" to cleanId,
                "appId" to "magictune",
                "product" to "MAGICTUNE_PRO",
                "magictunePro" to isPro,
                "isPro" to isPro,
                "isAccountPro" to isPro,
                "upgradedToAccountPro" to isPro,
                "proTier" to if (isPro) "ACCOUNT_PRO" else "FREE",
                "revokedByAdmin" to !isPro,
                "licenseKey" to if (isPro) LicenseManager.generateAccountProLicenseKeyForDevice(cleanId) else "",
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (isPro) {
                devMap["proActivatedAt"] = FieldValue.serverTimestamp()
            } else {
                devMap["proActivatedAt"] = FieldValue.delete()
            }
            getDb().collection("devices").document(cleanId).set(devMap, SetOptions.merge()).await()
            val normId = LicenseManager.normalizeDeviceIdForMatch(cleanId)
            if (normId.isNotBlank() && normId != cleanId) {
                getDb().collection("devices").document(normId).set(devMap, SetOptions.merge())
            }
        }
    }

    /**
     * ADMIN: Cấp Pro cho một thiết bị có kiểm tra xem thiết bị đó đã tồn tại (đã cài app/đồng bộ) trên hệ thống chưa.
     * Ném ngoại lệ nếu thiết bị không tồn tại, ngăn chặn việc admin nhập nhầm ID ảo.
     */
    suspend fun verifyAndToggleDeviceProStatus(deviceId: String, isPro: Boolean): Boolean {
        if (deviceId.isBlank()) throw IllegalArgumentException("Device ID không được để trống!")
        val cleanId = deviceId.trim().uppercase()
        val normId = LicenseManager.normalizeDeviceIdForMatch(cleanId)
        val docRef = getDb().collection("devices").document(cleanId)
        val snapshot = docRef.get().await()

        val existsInDevices = if (snapshot.exists()) {
            true
        } else {
            val allDevs = try { getDb().collection("devices").get().await() } catch (_: Exception) { null }
            allDevs?.documents?.any {
                LicenseManager.normalizeDeviceIdForMatch(it.getString("deviceId") ?: it.id) == normId
            } == true
        }

        if (isPro && !existsInDevices) {
            throw IllegalStateException("Không tìm thấy thiết bị '$cleanId' trên hệ thống! Thiết bị này chưa cài đặt ứng dụng hoặc chưa đồng bộ dữ liệu, không thể kích hoạt Pro.")
        }

        val updateMap = mutableMapOf<String, Any>(
            "deviceId" to cleanId,
            "appId" to "magictune",
            "product" to "MAGICTUNE_PRO",
            "magictunePro" to isPro,
            "isPro" to isPro,
            "revokedByAdmin" to !isPro,
            "licenseKey" to if (isPro) LicenseManager.generateLicenseKeyForDevice(cleanId) else "",
            "updatedAt" to FieldValue.serverTimestamp()
        )
        if (isPro) {
            updateMap["proActivatedAt"] = FieldValue.serverTimestamp()
        } else {
            updateMap["proActivatedAt"] = FieldValue.delete()
        }
        docRef.set(updateMap, SetOptions.merge()).await()
        if (normId.isNotBlank() && normId != cleanId) {
            getDb().collection("devices").document(normId).set(updateMap, SetOptions.merge())
        }
        return true
    }

    /**
     * ADMIN: Cấp Pro hoặc GỠ QUYỀN PRO trực tiếp trên một thiết bị bất kỳ (Kể cả thiết bị ẩn danh)
     * Đồng thời đồng bộ sang bảng `users` nếu có tài khoản đang gắn với thiết bị này.
     */
    suspend fun toggleDeviceProStatus(deviceId: String, isPro: Boolean) {
        if (deviceId.isBlank()) return
        val cleanId = deviceId.trim().uppercase()
        val normId = LicenseManager.normalizeDeviceIdForMatch(cleanId)
        val docRef = getDb().collection("devices").document(cleanId)
        val updateMap = mutableMapOf<String, Any>(
            "deviceId" to cleanId,
            "appId" to "magictune",
            "product" to "MAGICTUNE_PRO",
            "magictunePro" to isPro,
            "isPro" to isPro,
            "revokedByAdmin" to !isPro,
            "licenseKey" to if (isPro) LicenseManager.generateLicenseKeyForDevice(cleanId) else "",
            "updatedAt" to FieldValue.serverTimestamp()
        )
        if (isPro) {
            updateMap["proActivatedAt"] = FieldValue.serverTimestamp()
        } else {
            updateMap["proActivatedAt"] = FieldValue.delete()
            updateMap["isAccountPro"] = false
            updateMap["upgradedToAccountPro"] = false
            updateMap["proTier"] = "FREE"
        }
        docRef.set(updateMap, SetOptions.merge()).await()
        if (normId.isNotBlank() && normId != cleanId) {
            getDb().collection("devices").document(normId).set(updateMap, SetOptions.merge())
        }

        // Đồng bộ trạng thái thu hồi/cấp Pro sang bảng `users` nếu có tài khoản đang giữ thiết bị này (không cần index)
        try {
            val allUsers = getDb().collection("users").get().await()
            for (uDoc in allUsers.documents) {
                val uAct = LicenseManager.normalizeDeviceIdForMatch(uDoc.getString("activeDeviceId") ?: "")
                val uDev = LicenseManager.normalizeDeviceIdForMatch(uDoc.getString("deviceId") ?: "")
                if (normId.isNotBlank() && (uAct == normId || uDev == normId)) {
                    uDoc.reference.set(
                        mapOf(
                            "isPro" to isPro,
                            "revokedByAdmin" to !isPro,
                            "updatedAt" to FieldValue.serverTimestamp()
                        ),
                        SetOptions.merge()
                    )
                }
            }
        } catch (_: Exception) {}
    }

    /**
     * Đăng xuất Firebase Auth & Credential Manager an toàn trên Main Thread (Chống đơ/trắng màn hình)
     * Đồng thời thu hồi phiên Pro Tài Khoản trên thiết bị vừa đăng xuất để tài khoản có thể đăng nhập sang máy khác.
     */
    fun signOut(context: Context, credentialManager: CredentialManager, scope: CoroutineScope, onComplete: () -> Unit) {
        try {
            singleDeviceListener?.remove()
            singleDeviceListener = null
            watchedUserId = null
            Firebase.auth.signOut()
            val prefs = context.getSharedPreferences("magictune_pro_prefs", Context.MODE_PRIVATE)
            prefs.edit()
                .remove("current_user_role")
                .remove("current_user_email")
                .remove(LicenseManager.KEY_ACTIVE_SESSION_TOKEN)
                .apply()
            LicenseManager.clearLocalAdminSession(context)
            LicenseManager.deactivateAccountProOnLogout(context)
            LicenseManager.syncDevicePresenceToCloud(context)
        } catch (_: Exception) {}

        scope.launch(Dispatchers.IO) {
            try {
                credentialManager.clearCredentialState(ClearCredentialStateRequest())
            } catch (e: Exception) {
                Log.e(TAG, "Lỗi xóa CredentialState", e)
            } finally {
                withContext(Dispatchers.Main) {
                    onComplete()
                }
            }
        }
    }

    /**
     * Đăng nhập tương tác bằng Google Sign-In via Credential Manager
     */
    fun signInWithGoogle(
        activity: Activity,
        credentialManager: CredentialManager,
        scope: CoroutineScope,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        val clientId = try {
            activity.getString(R.string.default_web_client_id)
        } catch (e: Exception) {
            onError("Chưa cấu hình default_web_client_id trong google-services.json!")
            return
        }

        val signInOption = GetSignInWithGoogleOption.Builder(serverClientId = clientId).build()
        val request = GetCredentialRequest.Builder().addCredentialOption(signInOption).build()

        scope.launch {
            try {
                val result = credentialManager.getCredential(activity, request)
                val credential = result.credential
                if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                    val googleIdToken = GoogleIdTokenCredential.createFrom(credential.data).idToken
                    val authCredential = GoogleAuthProvider.getCredential(googleIdToken, null)
                    Firebase.auth.signInWithCredential(authCredential).await()
                    syncUserProfile(activity)
                    onSuccess()
                } else {
                    onError("Loại xác thực không phù hợp!")
                }
            } catch (e: GetCredentialCancellationException) {
                Log.w(TAG, "Đăng nhập Google bị hủy: ${e.message}")
                onError("Đã hủy thao tác đăng nhập Google!")
            } catch (e: Exception) {
                Log.e(TAG, "Đăng nhập Google thất bại", e)
                onError(e.localizedMessage ?: "Đăng nhập thất bại!")
            }
        }
    }

    /**
     * Đăng nhập bằng Email & Mật khẩu
     */
    /**
     * Dịch toàn bộ thông báo lỗi từ FirebaseAuth sang Tiếng Việt chuẩn xác, thân thiện
     */
    fun translateAuthError(e: Throwable?): String {
        val msg = e?.message ?: ""
        val lower = msg.lowercase()
        return when {
            lower.contains("invalid-credential") || lower.contains("wrong-password") || lower.contains("invalid_login_credentials") ->
                "Mật khẩu hoặc email không chính xác. Vui lòng kiểm tra lại!"
            lower.contains("user-not-found") ->
                "Tài khoản email này chưa được đăng ký trong hệ thống. Vui lòng bấm 'Chưa có tài khoản? Đăng ký' bên trên!"
            lower.contains("email-already-in-use") || lower.contains("email-already-exists") ->
                "Địa chỉ email này đã được sử dụng. Vui lòng bấm 'Đăng nhập' hoặc dùng tính năng 'Quên mật khẩu'!"
            lower.contains("invalid-email") ->
                "Định dạng địa chỉ email không hợp lệ. Vui lòng kiểm tra lại ký tự @ và tên miền!"
            lower.contains("weak-password") ->
                "Mật khẩu quá ngắn hoặc quá đơn giản. Vui lòng đặt mật khẩu từ 6 ký tự trở lên!"
            lower.contains("user-disabled") ->
                "Tài khoản này đã bị tạm khóa bởi quản trị viên hệ thống."
            lower.contains("too-many-requests") ->
                "Bạn đã thử đăng nhập sai quá nhiều lần. Vui lòng chờ 1-2 phút rồi thử lại để bảo mật tài khoản!"
            lower.contains("network-request-failed") || lower.contains("unable to resolve host") || lower.contains("timeout") ->
                "Lỗi kết nối mạng. Vui lòng kiểm tra kết nối Wi-Fi hoặc 4G/5G trên thiết bị!"
            lower.contains("recent-login-required") || lower.contains("requires-recent-login") ->
                "Vì lý do bảo mật, bạn cần nhập lại mật khẩu hiện tại hoặc vừa đăng nhập để thực hiện đổi mật khẩu/email mới!"
            lower.contains("operation-not-allowed") ->
                "Phương thức đăng nhập này chưa được kích hoạt trên máy chủ Firebase."
            else ->
                "Xác thực không thành công: ${e?.localizedMessage ?: "Vui lòng thử lại sau giây lát!"}"
        }
    }

    suspend fun signInWithEmail(email: String, pass: String): FirebaseUser {
        val res = Firebase.auth.signInWithEmailAndPassword(email.trim(), pass).await()
        return res.user ?: throw IllegalStateException("Đăng nhập bằng Email thất bại!")
    }

    /**
     * Đăng ký tài khoản mới bằng Email & Mật khẩu
     */
    suspend fun signUpWithEmail(email: String, pass: String, name: String): FirebaseUser {
        val res = Firebase.auth.createUserWithEmailAndPassword(email.trim(), pass).await()
        val user = res.user ?: throw IllegalStateException("Tạo tài khoản thất bại!")
        if (name.isNotBlank()) {
            val req = com.google.firebase.auth.userProfileChangeRequest {
                this.displayName = name.trim()
            }
            user.updateProfile(req).await()
        }
        return user
    }

    /**
     * Gửi email khôi phục mật khẩu (Quên mật khẩu)
     */
    suspend fun sendPasswordResetEmail(email: String) {
        Firebase.auth.sendPasswordResetEmail(email.trim()).await()
    }
}
