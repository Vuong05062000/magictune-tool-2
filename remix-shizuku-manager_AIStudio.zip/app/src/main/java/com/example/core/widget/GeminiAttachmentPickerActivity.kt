package com.example.core.widget

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.util.Base64
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.ZipInputStream

/**
 * Activity trung gian trong suốt (Translucent Trampoline) xử lý:
 * 1. Chụp ảnh camera trực tiếp bằng FileProvider
 * 2. Tải ảnh từ thư viện thiết bị / Google Photos
 * 3. Đính kèm tệp & tài liệu (PDF, Word docx, TXT, JSON, CSV...) từ bộ nhớ máy hoặc Google Drive
 * để truyền thẳng vào Gemini Live giải đáp, phân tích và trích xuất tóm tắt.
 */
class GeminiAttachmentPickerActivity : ComponentActivity() {

    companion object {
        const val EXTRA_PICKER_MODE = "EXTRA_PICKER_MODE"
        const val MODE_CAMERA = "MODE_CAMERA"
        const val MODE_GALLERY = "MODE_GALLERY"
        const val MODE_DOCUMENT = "MODE_DOCUMENT"

        fun launch(context: Context, mode: String) {
            val intent = Intent(context, GeminiAttachmentPickerActivity::class.java).apply {
                putExtra(EXTRA_PICKER_MODE, mode)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            }
            context.startActivity(intent)
        }
    }

    private var photoFile: File? = null

    private val takePictureLauncher = registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        try {
            if (success && photoFile != null && photoFile!!.exists() && photoFile!!.length() > 0) {
                processAndAttachImageFile(photoFile!!, "Ảnh chụp camera")
            }
        } catch (e: Throwable) {
            Toast.makeText(this, "Không thể nhận ảnh chụp: ${e.message}", Toast.LENGTH_SHORT).show()
        } finally {
            finish()
        }
    }

    private val pickImageLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        try {
            if (uri != null) {
                processAndAttachImageUri(uri)
            }
        } catch (e: Throwable) {
            Toast.makeText(this, "Không thể tải ảnh: ${e.message}", Toast.LENGTH_SHORT).show()
        } finally {
            finish()
        }
    }

    private val pickDocumentLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        try {
            if (uri != null) {
                processAndAttachDocumentUri(uri)
            }
        } catch (e: Throwable) {
            Toast.makeText(this, "Không thể tải tệp: ${e.message}", Toast.LENGTH_SHORT).show()
        } finally {
            finish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val mode = intent.getStringExtra(EXTRA_PICKER_MODE) ?: MODE_GALLERY

        when (mode) {
            MODE_CAMERA -> {
                try {
                    val file = File(cacheDir, "gemini_camera_${System.currentTimeMillis()}.jpg")
                    photoFile = file
                    val uri = FileProvider.getUriForFile(this, "${packageName}.fileprovider", file)
                    takePictureLauncher.launch(uri)
                } catch (e: Throwable) {
                    Toast.makeText(this, "Không thể khởi động máy ảnh: ${e.message}", Toast.LENGTH_SHORT).show()
                    finish()
                }
            }
            MODE_GALLERY -> {
                try {
                    pickImageLauncher.launch("image/*")
                } catch (e: Throwable) {
                    Toast.makeText(this, "Không thể mở bộ sưu tập: ${e.message}", Toast.LENGTH_SHORT).show()
                    finish()
                }
            }
            MODE_DOCUMENT -> {
                try {
                    pickDocumentLauncher.launch(
                        arrayOf(
                            "application/pdf",
                            "text/*",
                            "application/msword",
                            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                            "application/vnd.ms-excel",
                            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                            "application/json",
                            "*/*"
                        )
                    )
                } catch (e: Throwable) {
                    Toast.makeText(this, "Không thể mở trình chọn tệp: ${e.message}", Toast.LENGTH_SHORT).show()
                    finish()
                }
            }
            else -> finish()
        }
    }

    private fun processAndAttachImageUri(uri: Uri) {
        val inputStream = contentResolver.openInputStream(uri) ?: return
        val bitmap = BitmapFactory.decodeStream(inputStream)
        inputStream.close()
        if (bitmap != null) {
            val fileName = getFileName(uri) ?: "Ảnh đính kèm"
            processAndAttachBitmap(bitmap, fileName)
        }
    }

    private fun processAndAttachImageFile(file: File, displayName: String) {
        val bitmap = BitmapFactory.decodeFile(file.absolutePath)
        if (bitmap != null) {
            processAndAttachBitmap(bitmap, displayName)
        }
    }

    private fun processAndAttachBitmap(bitmap: Bitmap, displayName: String) {
        // Tối ưu kích thước tối đa 1280px để nén nhanh, gửi AI tức thì
        val maxDim = 1280
        val w = bitmap.width
        val h = bitmap.height
        val scaledBitmap = if (w > maxDim || h > maxDim) {
            val ratio = if (w > h) maxDim.toFloat() / w else maxDim.toFloat() / h
            Bitmap.createScaledBitmap(bitmap, (w * ratio).toInt(), (h * ratio).toInt(), true)
        } else {
            bitmap
        }
        val baos = ByteArrayOutputStream()
        scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 82, baos)
        val base64 = Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
        GeminiLiveFloatingOverlay.attachImageDirectly(this, base64, displayName)
    }

    private fun processAndAttachDocumentUri(uri: Uri) {
        val fileName = getFileName(uri) ?: "Tài liệu đính kèm"
        val textContent = extractTextFromDocument(uri, fileName)
        if (textContent.isNotBlank()) {
            GeminiLiveFloatingOverlay.attachDocumentDirectly(this, fileName, textContent)
        } else {
            Toast.makeText(this, "Đã chọn tệp: $fileName", Toast.LENGTH_SHORT).show()
            GeminiLiveFloatingOverlay.attachDocumentDirectly(this, fileName, "Tệp: $fileName")
        }
    }

    private fun extractTextFromDocument(uri: Uri, fileName: String): String {
        return try {
            val stream = contentResolver.openInputStream(uri) ?: return ""

            // 1. Nếu là tệp Word .docx (Định dạng nén zip chứa word/document.xml)
            if (fileName.endsWith(".docx", ignoreCase = true)) {
                try {
                    ZipInputStream(stream).use { zis ->
                        var entry = zis.nextEntry
                        while (entry != null) {
                            if (entry.name == "word/document.xml") {
                                val xml = zis.bufferedReader(Charsets.UTF_8).readText()
                                val plain = xml.replace(Regex("<[^>]+>"), " ")
                                    .replace(Regex("\\s+"), " ")
                                    .trim()
                                return plain.take(24000)
                            }
                            entry = zis.nextEntry
                        }
                    }
                } catch (_: Throwable) {}
            }

            // 2. Tệp PDF: trích xuất các chuỗi ký tự văn bản
            if (fileName.endsWith(".pdf", ignoreCase = true)) {
                val bytes = stream.readBytes()
                val rawStr = String(bytes, Charsets.UTF_8)
                val textOnly = rawStr.replace(Regex("""[^\\p{L}\\p{N}\\p{P}\\s]"""), " ")
                    .replace(Regex("""\\s+"""), " ")
                    .trim()
                return if (textOnly.length > 60) {
                    textOnly.take(24000)
                } else {
                    "Tệp PDF: $fileName (Kích thước: ${bytes.size / 1024} KB). Hãy tóm tắt hoặc trả lời dựa trên tên tệp này."
                }
            }

            // 3. Các tệp văn bản khác (.txt, .json, .csv, .md, .xml, .html...)
            val text = stream.bufferedReader(Charsets.UTF_8).readText()
            text.take(24000)
        } catch (_: Throwable) {
            "Tệp đính kèm: $fileName"
        }
    }

    private fun getFileName(uri: Uri): String? {
        var name: String? = null
        try {
            val cursor = contentResolver.query(uri, null, null, null, null)
            cursor?.use {
                if (it.moveToFirst()) {
                    val idx = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) name = it.getString(idx)
                }
            }
        } catch (_: Throwable) {}
        return name
    }
}
