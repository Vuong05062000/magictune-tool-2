package com.example.core.shell

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.core.app.NotificationCompat
import com.example.core.service.MagicTuneKeepAliveService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import com.example.core.adb.DirectAdbManager
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.lang.reflect.InvocationTargetException
import java.lang.reflect.Method
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

enum class ShellMode {
    SHIZUKU,
    WIRELESS_ADB,
    ROOT,
    LOCAL_LIMITED,
    NONE
}

data class ShellResult(
    val command: String = "",
    val exitCode: Int,
    val output: String,
    val error: String,
    val modeUsed: ShellMode
) {
    val combinedOutput: String
        get() = listOf(output, error).filter { it.isNotBlank() }.joinToString("\n")

    val hasFatalErrorText: Boolean
        get() {
            val text = combinedOutput
            if (text.isBlank()) return false
            val fatalPatterns = listOf(
                "SecurityException",
                "Permission denial",
                "Permission denied",
                "java.lang.",
                "Failure [",
                "Error:",
                "Exception occurred",
                "neither user",
                "nor current process has",
                "Can't find service",
                "inaccessible or not found",
                "not allowed to",
                "Operation not permitted",
                "Unknown command",
                "bad argument",
                "Killed",
                "Aborted",
                // "not found" removed from fatalPatterns to avoid false positives
            )
            return fatalPatterns.any { text.contains(it, ignoreCase = true) }
        }

    /**
     * Strictly checks if the ADB/Shell command actually succeeded.
     * Never reports false success when exitCode != 0 or when output/stderr contains
     * SecurityException, Permission denial, Failure, Error:, etc.
     */
    val isSuccess: Boolean
        get() {
            if (exitCode != 0) return false
            if (hasFatalErrorText) return false
            return true
        }

    val errorReason: String
        get() {
            if (isSuccess) return ""
            val raw = error.ifBlank { output }.trim()
            val rawLower = raw.lowercase()
            val exitStr = if (exitCode != 0) " [Exit Code: $exitCode]" else ""
            
            // 1. Phân loại lỗi quyền chi tiết
            if (raw.contains("WRITE_SECURE_SETTINGS", ignoreCase = true) ||
                raw.contains("Permission denial", ignoreCase = true) ||
                raw.contains("SecurityException", ignoreCase = true) ||
                raw.contains("neither user", ignoreCase = true) ||
                raw.contains("not allowed to", ignoreCase = true)
            ) {
                val lineDetail = raw.lines().firstOrNull {
                    it.contains("SecurityException", true) ||
                        it.contains("Permission", true) ||
                        it.contains("neither user", true) ||
                        it.contains("not allowed", true)
                } ?: raw.lines().firstOrNull().orEmpty()
                return "Từ chối quyền hệ thống Android$exitStr: $lineDetail"
            }
            
            // 2. Phân loại lỗi gói ứng dụng hoặc lệnh không tồn tại
            if (rawLower.contains("unknown package") || rawLower.contains("not found") || rawLower.contains("failure [not installed")) {
                val line = raw.lines().firstOrNull { it.isNotBlank() }.orEmpty()
                return "Không tìm thấy gói/lệnh trên thiết bị$exitStr: $line"
            }
            
            // 3. Phân loại lỗi tiến trình bị giết / Binder chết
            if (exitCode == 137 || rawLower.contains("killed") || rawLower.contains("binder") || rawLower.contains("dead")) {
                return "Tiến trình Shell bị ngắt đột ngột (Binder Dead / HĐH đóng kết nối)$exitStr: ${raw.ifBlank { "Signal 9 / Out of Memory / Mất gỡ lỗi Wi-Fi" }}"
            }
            
            // 4. Lỗi khác kèm trích xuất 3 dòng chi tiết thực tế
            if (raw.isNotBlank()) {
                val details = raw.lines().filter { it.isNotBlank() }.take(3).joinToString(" ➔ ")
                return "Chi tiết lỗi từ hệ thống$exitStr: $details"
            }
            return "Lệnh không trả về kết quả hoặc bị hệ điều hành từ chối$exitStr"
        }

    val displayOutput: String
        get() {
            if (!isSuccess) {
                return "❌ THẤT BẠI: $errorReason"
            }
            if (output.isNotBlank()) return output
            return "✅ Thành công (Exit 0)"
        }
}

data class ShellEngineState(
    val mode: ShellMode = ShellMode.NONE,
    val isShizukuInstalled: Boolean = false,
    val isShizukuRunning: Boolean = false,
    val isShizukuPermissionGranted: Boolean = false,
    val isAdbWifiEnabled: Boolean = true,
    val isShizukuSeveredFromAdb: Boolean = false,
    val isWirelessAdbConnected: Boolean = false,
    val wirelessAdbPort: Int = 5555,
    val isRootAvailable: Boolean = false,
    val hasPersistentGrant: Boolean = false,
    val isKeepAliveActive: Boolean = true,
    val activeUid: String = "Unknown",
    val statusMessage: String = "Chưa kết nối"
) {
    val isAdbReady: Boolean
        get() =
            (isShizukuRunning && isShizukuPermissionGranted) ||
                isWirelessAdbConnected ||
                (mode == ShellMode.ROOT && isRootAvailable) ||
                com.example.core.adb.DirectAdbManager.isInstanceConnectedFast()
}

class ShellEngine(private val context: Context) {

    private val prefs = context.getSharedPreferences("magictune_shell_prefs", Context.MODE_PRIVATE)
    private val kvPrefs = context.getSharedPreferences("magictune_persisted_kv", Context.MODE_PRIVATE)

    // Mỗi lần app bị đóng khỏi đa nhiệm và khởi động lại, luôn bắt đầu ở trạng thái CHƯA KẾT NỐI,
    // tuyệt đối không khôi phục trạng thái kết nối ảo cũ từ SharedPreferences!
    private val _state = MutableStateFlow(
        ShellEngineState(
            isWirelessAdbConnected = false,
            wirelessAdbPort = prefs.getInt(KEY_WLAN_PORT, 5555),
            hasPersistentGrant = false,
            mode = ShellMode.NONE,
            statusMessage = "Chưa kết nối (Cần kết nối Gỡ lỗi Wi-Fi)"
        )
    )
    val state: StateFlow<ShellEngineState> = _state

    private var permissionListener: Shizuku.OnRequestPermissionResultListener? = null
    private var binderReceivedListener: Shizuku.OnBinderReceivedListener? = null
    private var binderDeadListener: Shizuku.OnBinderDeadListener? = null

    val directAdbManager: DirectAdbManager by lazy { DirectAdbManager.getInstance(context) }
    private val engineScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var monitorJob: Job? = null
    private var consecutiveWlanFailures = 0
    @Volatile
    private var isUserDisconnected: Boolean = false

    // Theo dõi các tiến trình đang chạy để cho phép lệnh mới nhất ưu tiên thực thi ngay lập tức (Preempt Old Commands)
    private val shizukuExecMutex = Mutex()
    private val activeShizukuExecCount = AtomicInteger(0)
    private val hasAutoGrantedShizukuSession = AtomicBoolean(false)
    private val runningProcesses = java.util.concurrent.ConcurrentHashMap.newKeySet<Process>()
    
    /**
     * Cưỡng bức làm mới kết nối Binder tới Shizuku Server.
     * Giải quyết lỗi shizuku.newProcess bị treo hoặc trả về lỗi giao tiếp Binder.
     */
    fun forceResetBinder() {
        engineScope.launch {
            preemptRunningProcesses()
            hasAutoGrantedShizukuSession.set(false)
            try {
                binderDeadListener?.onBinderDead()
                delay(200)
                checkShizukuStatus()
            } catch (_: Exception) {}
        }
    }

    /**
     * Ngắt ngay lập tức các tiến trình lệnh cũ đang chạy dở để ưu tiên tài nguyên 100% cho lệnh mới nhất!
     */
    fun preemptRunningProcesses(): Int {
        var count = 0
        try {
            if (directAdbManager.abortCurrentCommand()) {
                count++
            }
        } catch (_: Throwable) {}
        val snapshot = runningProcesses.toList()
        for (proc in snapshot) {
            try {
                runningProcesses.remove(proc)
                try { proc.inputStream?.close() } catch (_: Throwable) {}
                try { proc.errorStream?.close() } catch (_: Throwable) {}
                try { proc.outputStream?.close() } catch (_: Throwable) {}
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    proc.destroyForcibly()
                } else {
                    proc.destroy()
                }
                count++
            } catch (_: Throwable) {}
        }
        return count
    }

    @Volatile
    private var cachedNewProcessMethod: Method? = null

    private fun getShizukuNewProcessMethod(): Method {
        cachedNewProcessMethod?.let { return it }
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java
        )
        m.isAccessible = true
        cachedNewProcessMethod = m
        return m
    }

    init {
        instance = this
        setupShizukuListeners()
        engineScope.launch {
            refreshStatus()
        }
        startKeepAliveServiceIfNeeded()
        startPeriodicConnectionMonitor()
    }

    fun hasWriteSecureSettingsPermission(): Boolean {
        return try {
            context.checkCallingOrSelfPermission(android.Manifest.permission.WRITE_SECURE_SETTINGS) ==
                PackageManager.PERMISSION_GRANTED
        } catch (_: Exception) {
            false
        }
    }

    fun hasOverlayPermission(): Boolean {
        val appCtx = context.applicationContext
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Settings.canDrawOverlays(appCtx) || kvPrefs.getBoolean("appop_${appCtx.packageName}_SYSTEM_ALERT_WINDOW", false)
            } else true
        } catch (_: Exception) {
            kvPrefs.getBoolean("appop_${appCtx.packageName}_SYSTEM_ALERT_WINDOW", false)
        }
    }

    fun hasControlPermission(): Boolean {
        return hasWriteSecureSettingsPermission() ||
            _state.value.hasPersistentGrant ||
            _state.value.isWirelessAdbConnected ||
            _state.value.isShizukuPermissionGranted ||
            _state.value.isRootAvailable
    }

    private fun saveWlanState(connected: Boolean, port: Int, persistentGrant: Boolean = _state.value.hasPersistentGrant) {
        prefs.edit()
            .putBoolean(KEY_WLAN_CONNECTED, connected)
            .putInt(KEY_WLAN_PORT, port)
            .putBoolean(KEY_PERSISTENT_GRANT, persistentGrant)
            .apply()
    }

    fun markPersistentGrantActive() {
        prefs.edit().putBoolean(KEY_PERSISTENT_GRANT, true).apply()
        _state.update { it.copy(hasPersistentGrant = true) }
    }

    fun isPackageMarkedDisabled(pkg: String): Boolean {
        val disabledSet = kvPrefs.getStringSet(KEY_DISABLED_PACKAGES, emptySet()) ?: emptySet()
        return disabledSet.contains(pkg)
    }

    fun isPackageMarkedUninstalled(pkg: String): Boolean {
        val uninstalledSet = kvPrefs.getStringSet(KEY_UNINSTALLED_PACKAGES, emptySet()) ?: emptySet()
        return uninstalledSet.contains(pkg)
    }

    fun getPersistedSetting(namespace: String, key: String): String? {
        return kvPrefs.getString("setting_${namespace}_$key", null)
    }

    fun setPersistedSetting(namespace: String, key: String, value: String?) {
        val editor = kvPrefs.edit()
        if (value == null) {
            editor.remove("setting_${namespace}_$key")
        } else {
            editor.putString("setting_${namespace}_$key", value)
        }
        editor.apply()
    }

    fun isAppVisuallyUiToggled(pkg: String): Boolean {
        return kvPrefs.getBoolean("ui_toggled_gentle_banner_$pkg", false)
    }

    fun markAppVisuallyUiToggled(pkg: String, toggled: Boolean = true) {
        kvPrefs.edit()
            .putBoolean("ui_toggled_gentle_banner_$pkg", toggled)
            .putBoolean("fixed_notif_$pkg", toggled)
            .apply()
    }

    fun resetNotificationScanCache() {
        val editor = kvPrefs.edit()
        kvPrefs.all.keys.forEach { key ->
            if (key.startsWith("fixed_notif_") || key.startsWith("ui_toggled_gentle_banner_")) {
                editor.remove(key)
            }
        }
        editor.apply()
    }

    fun isAppActuallyNotificationEnabled(pkg: String): Boolean {
        return try {
            // Trên Honor MagicOS, POST_NOTIFICATION=allow chỉ là công tắc tổng "Cho phép thông báo",
            // KHÔNG có nghĩa là đã tắt "Thông báo nhẹ nhàng" hay đã bật "Biểu ngữ" (Banners)!
            // Do đó chỉ xác nhận đã xử lý triệt để khi đã chạy Auto-Click UI gạt công tắc thực tế hoặc xác thực qua kênh dumpsys.
            val uiToggled = kvPrefs.getBoolean("ui_toggled_gentle_banner_$pkg", false)
            if (!uiToggled) return false
            val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as? android.app.AppOpsManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT && appOps != null) {
                val uid = context.packageManager.getPackageUid(pkg, 0)
                val postNotifAllowed = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    appOps.checkOpNoThrow("android:post_notification", uid, pkg) == android.app.AppOpsManager.MODE_ALLOWED
                } else true
                postNotifAllowed && uiToggled
            } else {
                uiToggled
            }
        } catch (_: Exception) {
            kvPrefs.getBoolean("ui_toggled_gentle_banner_$pkg", false)
        }
    }

    fun isAppActuallyBackgroundWhitelisted(pkg: String): Boolean {
        return try {
            val fixedInPrefs = kvPrefs.getBoolean("whitelist_$pkg", false) &&
                kvPrefs.getBoolean("appop_${pkg}_RUN_IN_BACKGROUND", false)
            if (fixedInPrefs) return true
            val pm = context.getSystemService(Context.POWER_SERVICE) as? android.os.PowerManager
            val isIgnoringBattery = pm?.isIgnoringBatteryOptimizations(pkg) ?: false
            val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as? android.app.AppOpsManager
            val alertWindowAllowed = if (appOps != null) {
                try {
                    val uid = context.packageManager.getPackageUid(pkg, 0)
                    appOps.checkOpNoThrow(
                        android.app.AppOpsManager.OPSTR_SYSTEM_ALERT_WINDOW,
                        uid,
                        pkg
                    ) == android.app.AppOpsManager.MODE_ALLOWED
                } catch (_: Exception) { false }
            } else false
            isIgnoringBattery && alertWindowAllowed
        } catch (_: Exception) {
            kvPrefs.getBoolean("whitelist_$pkg", false)
        }
    }

    fun isAppWhitelistedOrFixed(pkg: String): Boolean {
        return kvPrefs.getBoolean("fixed_notif_$pkg", false)
    }

    fun markAppNotificationFixed(pkg: String, fixed: Boolean = true) {
        kvPrefs.edit()
            .putBoolean("fixed_notif_$pkg", fixed)
            .putBoolean("appop_${pkg}_POST_NOTIFICATION", fixed)
            .putBoolean("appop_${pkg}_SYSTEM_ALERT_WINDOW", fixed)
            .putBoolean("appop_${pkg}_RUN_IN_BACKGROUND", fixed)
            .putBoolean("whitelist_$pkg", fixed)
            .apply()
    }

    fun isAppPermissionGranted(pkg: String): Boolean {
        return kvPrefs.getBoolean("appop_${pkg}_RUN_IN_BACKGROUND", false) &&
            kvPrefs.getBoolean("whitelist_$pkg", false)
    }

    /**
     * Cơ chế bảo vệ Mod Phím Điều Hướng (Khoanh Tròn Tìm Kiếm / Gemini Voice / Khóa YOYO)
     * hoạt động độc lập ngay cả khi đã TẮT GỠ LỖI (nhờ quyền WRITE_SECURE_SETTINGS vĩnh viễn).
     * Ngăn chặn MagicOS tự động reset thanh điều hướng quay về gọi YOYO!
     */
    fun enforceOfflineNavBarModGuard() {
        try {
            com.example.core.service.SystemFloatingHudOverlay.syncNavBarBridge(context)
            com.example.core.service.SystemFloatingHudOverlay.interceptYoyoIfForeground(context)

            val navMode = getPersistedSetting("secure", "magictune_nav_mod_mode") ?: return
            if (navMode !in listOf("CIRCLE_TO_SEARCH", "GEMINI_VOICE", "DISABLED_YOYO")) return
            if (!hasWriteSecureSettingsPermission()) return

            val cr = context.contentResolver
            // 1. Luôn khóa cứng công tắc đánh thức YOYO ở mọi namespace (bao gồm MagicVoice, YOYO Agent, HiAye)
            val yoyoSecureKeys = listOf(
                "navigation_bar_wakeup_yoyo",
                "yoyo_navigation_bar_wakeup",
                "wake_up_yoyo_by_nav_bar",
                "yoyo_agent_nav_bar_wakeup",
                "magic_voice_nav_wakeup",
                "yoyo_assistant_gesture_switch",
                "voice_wakeup_switch",
                "ai_sub_switch",
                "smart_breath_switch",
                "hiaye_switch",
                "hiaction_enabled"
            )
            for (k in yoyoSecureKeys) {
                if (Settings.Secure.getString(cr, k) != "0") {
                    Settings.Secure.putString(cr, k, "0")
                }
            }
            try {
                if (Settings.System.getString(cr, "navigation_bar_wakeup_yoyo") != "0") {
                    Settings.System.putString(cr, "navigation_bar_wakeup_yoyo", "0")
                }
                if (Settings.System.getString(cr, "yoyo_agent_nav_bar_wakeup") != "0") {
                    Settings.System.putString(cr, "yoyo_agent_nav_bar_wakeup", "0")
                }
                if (Settings.System.getString(cr, "yoyo_assistant_gesture_switch") != "0") {
                    Settings.System.putString(cr, "yoyo_assistant_gesture_switch", "0")
                }
            } catch (_: Exception) {}

            // 2. Phối hợp nhịp nhàng giữa Khoanh Tròn Tìm Kiếm (CIRCLE_TO_SEARCH) và Gemini Voice Nổi (GEMINI_VOICE):
            // - Chế độ CIRCLE_TO_SEARCH sử dụng Cầu nối Smart NavBar Bridge riêng của MagicTune để mở lớp phủ Khoanh Tròn,
            //   do đó TỰ ĐỘNG NHƯỜNG quyền Trợ lý nổi hệ thống (`assistant` & `voice_interaction_service` = GsaVoiceInteractionService)
            //   lại cho Google Gemini để khi người dùng gọi Gemini (bằng giọng nói, màn hình khóa hoặc nút Gemini),
            //   Gemini luôn HIỆN NỔI NGAY TRÊN MÀN HÌNH mà không cần mở hẳn app Gemini lên!
            val googleAssistantService = "com.google.android.googlequicksearchbox/com.google.android.voiceinteraction.GsaVoiceInteractionService"
            val googleRecogService = "com.google.android.googlequicksearchbox/com.google.android.voicesearch.serviceapi.GoogleRecognitionService"

            val curAssist = Settings.Secure.getString(cr, "assistant")
            if (curAssist.isNullOrBlank() || curAssist.contains("hihonor", ignoreCase = true) || curAssist.contains("huawei", ignoreCase = true) || curAssist.contains("yoyo", ignoreCase = true) || curAssist.contains("VoiceSearchActivity", ignoreCase = true)) {
                Settings.Secure.putString(cr, "assistant", googleAssistantService)
            }
            val curVoice = Settings.Secure.getString(cr, "voice_interaction_service")
            if (curVoice.isNullOrBlank() || curVoice.contains("hihonor", ignoreCase = true) || curVoice.contains("huawei", ignoreCase = true) || curVoice.contains("yoyo", ignoreCase = true)) {
                Settings.Secure.putString(cr, "voice_interaction_service", googleAssistantService)
            }
            val curRecog = Settings.Secure.getString(cr, "voice_recognition_service")
            if (curRecog.isNullOrBlank() || curRecog.contains("hihonor", ignoreCase = true) || curRecog.contains("huawei", ignoreCase = true)) {
                Settings.Secure.putString(cr, "voice_recognition_service", googleRecogService)
            }

            Settings.Secure.putString(cr, "assist_structure_enabled", "1")
            Settings.Secure.putString(cr, "assist_screenshot_enabled", "1")
            Settings.Secure.putString(cr, "assist_disclosure_enabled", "1")

            if (navMode == "CIRCLE_TO_SEARCH") {
                // Tắt assist_long_press_home_enabled của hệ thống để Cầu nối Smart NavBar Bridge của MagicTune bắt cử chỉ nhấn giữ thanh đáy mở Khoanh Tròn,
                // đồng thời vẫn giữ nguyên `voice_interaction_service` cho Gemini hiện nổi!
                Settings.Secure.putString(cr, "assist_long_press_home_enabled", "0")
                Settings.Secure.putString(cr, "search_press_hold_nav_handle_enabled", "0")
                Settings.Secure.putString(cr, "contextual_search_enabled", "1")
                Settings.Secure.putString(cr, "contextual_search_package", "com.google.android.googlequicksearchbox")
                Settings.Secure.putString(cr, "visual_query_accessibility_detection_enabled", "1")
                try {
                    Settings.Global.putString(cr, "contextual_search_enabled", "1")
                } catch (_: Exception) {}
                // Luôn giữ Dịch vụ trợ năng ở trạng thái TẮT khi bình thường để các App Ngân Hàng không bao giờ cảnh báo.
                // (Dịch vụ chỉ tự bật trong 0.15 giây lúc chụp màn hình Khoanh Tròn rồi tự tắt ngay lập tức)
                com.example.core.service.MagicTuneCtsAccessibilityService.disableServiceViaSecureSettings(context)
            } else if (navMode == "GEMINI_VOICE") {
                Settings.Secure.putString(cr, "assist_long_press_home_enabled", "1")
                Settings.Secure.putString(cr, "search_press_hold_nav_handle_enabled", "1")
                Settings.Secure.putString(cr, "assist_touch_gesture_enabled", "1")
            }
        } catch (_: Exception) {}
    }

    fun startKeepAliveServiceIfNeeded() {
        val st = _state.value
        val hasActiveSession = (st.mode == ShellMode.SHIZUKU && st.isShizukuPermissionGranted && st.isShizukuRunning) ||
            st.isWirelessAdbConnected ||
            (st.mode == ShellMode.ROOT && st.isRootAvailable)
        if (!hasActiveSession) {
            // Không tự động bật Foreground Service khi chưa có phiên ADB/Shizuku đang hoạt động
            return
        }
        val msg = when {
            st.mode == ShellMode.SHIZUKU && st.isShizukuPermissionGranted ->
                "Shizuku: Đang kết nối (UID 2000) • Giữ chạy nền đa nhiệm"
            st.isWirelessAdbConnected ->
                "WLAN: Đang kết nối (Cổng ${st.wirelessAdbPort}) • Giữ chạy nền đa nhiệm"
            else ->
                "MagicTune: Đang duy trì kết nối gỡ lỗi"
        }
        MagicTuneKeepAliveService.startOrUpdate(context, msg)
    }

    private fun setupShizukuListeners() {
        permissionListener = Shizuku.OnRequestPermissionResultListener { _, grantResult ->
            val granted = grantResult == PackageManager.PERMISSION_GRANTED
            if (granted) {
                markPersistentGrantActive()
            }
            val running = isShizukuServerTrulyAlive()
            _state.update { cur -> cur.copy(
                isShizukuRunning = running,
                isShizukuPermissionGranted = granted,
                isShizukuSeveredFromAdb = false,
                hasPersistentGrant = granted || cur.hasPersistentGrant,
                mode = if (granted && running) ShellMode.SHIZUKU else cur.mode,
                statusMessage = when {
                    granted && running -> "Shizuku: Đang kết nối (UID 2000)"
                    running && !granted -> "Shizuku: Chưa cấp quyền (Cần bấm cấp quyền)"
                    else -> "Shizuku: Server đã ngắt kết nối"
                }
            ) }
            engineScope.launch { refreshStatus() }
            engineScope.launch { startKeepAliveServiceIfNeeded() }
        }
        try {
            Shizuku.addRequestPermissionResultListener(permissionListener!!)
        } catch (_: Exception) {}

        binderReceivedListener = Shizuku.OnBinderReceivedListener {
            engineScope.launch {
                checkShizukuStatus()
                startKeepAliveServiceIfNeeded()
            }
        }
        try {
            // Dùng Sticky Listener để nếu Binder đã kết nối sẵn trước khi Engine khởi tạo, callback sẽ kích hoạt ngay lập tức
            Shizuku.addBinderReceivedListenerSticky(binderReceivedListener!!)
        } catch (_: Exception) {
            try {
                Shizuku.addBinderReceivedListener(binderReceivedListener!!)
            } catch (_: Exception) {}
        }

        binderDeadListener = Shizuku.OnBinderDeadListener {
            consecutiveWlanFailures = 0
            engineScope.launch {
                // Đợi ngắn và thử ping lại trước khi kết luận Binder thực sự chết (tránh báo giả khi chạy lệnh nặng)
                delay(150)
                if (pingShizukuBinderResilient()) {
                    checkShizukuStatus()
                    return@launch
                }
                hasAutoGrantedShizukuSession.set(false)
                enforceOfflineNavBarModGuard()
                val (adbWifiOn, _) = checkAdbWifiSystemSetting()
                _state.update { cur -> cur.copy(
                    isShizukuRunning = false,
                    isShizukuPermissionGranted = false,
                    isShizukuSeveredFromAdb = false,
                    isAdbWifiEnabled = adbWifiOn,
                    mode = if (cur.isWirelessAdbConnected) ShellMode.WIRELESS_ADB else ShellMode.NONE,
                    statusMessage = "Shizuku đã ngắt kết nối (Server đã đóng)"
                ) }
            }
        }
        try {
            Shizuku.addBinderDeadListener(binderDeadListener!!)
        } catch (_: Exception) {}
    }

    fun checkAdbWifiSystemSetting(): Pair<Boolean, Boolean> {
        val devOn = try {
            Settings.Global.getInt(context.contentResolver, Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 1) == 1
        } catch (_: Exception) { true }
        val adbWifiOn = try {
            val raw = Settings.Global.getInt(context.contentResolver, "adb_wifi_enabled", -1)
            if (raw != -1) raw == 1 else devOn
        } catch (_: Exception) { true }
        return Pair(adbWifiOn, devOn)
    }

    private fun startPeriodicConnectionMonitor() {
        monitorJob?.cancel()
        monitorJob = engineScope.launch {
            while (isActive) {
                delay(2000)
                enforceOfflineNavBarModGuard()
                // Không spam kiểm tra Binder khi đang thực thi chuỗi lệnh Shizuku để tránh nghẽn Binder
                if (activeShizukuExecCount.get() == 0) {
                    val wasRunning = _state.value.isShizukuRunning
                    val wasGranted = _state.value.isShizukuPermissionGranted

                    val nowRunning = isShizukuServerTrulyAlive()
                    val nowGranted = if (nowRunning && !isUserDisconnected) {
                        checkShizukuPermissionResilient()
                    } else false

                    if (wasRunning != nowRunning || wasGranted != nowGranted) {
                        checkShizukuStatus()
                    }
                }

                if (!isUserDisconnected && DirectAdbManager.isInstanceConnectedFast() && !_state.value.isWirelessAdbConnected) {
                    checkShizukuStatus()
                }

                if (_state.value.isWirelessAdbConnected) {
                    val port = _state.value.wirelessAdbPort
                    val alive = DirectAdbManager.isInstanceConnectedFast() || testWirelessAdbPort(port)
                    if (alive) {
                        consecutiveWlanFailures = 0
                    } else {
                        consecutiveWlanFailures++
                        val (adbWifiOn, devOn) = checkAdbWifiSystemSetting()
                        if (!adbWifiOn || !devOn || consecutiveWlanFailures >= 12) {
                            consecutiveWlanFailures = 0
                            saveWlanState(false, port, true)
                            _state.update { cur ->
                                cur.copy(
                                    isWirelessAdbConnected = false,
                                    hasPersistentGrant = true,
                                    mode = if (cur.isShizukuRunning && cur.isShizukuPermissionGranted) ShellMode.SHIZUKU else ShellMode.LOCAL_LIMITED,
                                    statusMessage = "WLAN đã ngắt • Đã lưu trạng thái đã Fix"
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    fun cleanup() {
        // Nếu đây là Singleton dùng chung toàn app thì giữ sống monitor cho Service & Patrol
        if (this === instance) return
        monitorJob?.cancel()
        engineScope.cancel()
        try {
            permissionListener?.let { Shizuku.removeRequestPermissionResultListener(it) }
            binderReceivedListener?.let { Shizuku.removeBinderReceivedListener(it) }
            binderDeadListener?.let { Shizuku.removeBinderDeadListener(it) }
        } catch (_: Exception) {}
    }

    /**
     * Đọc song song stdout và stderr bằng Coroutine IO kết hợp timeout chặt chẽ,
     * đồng thời LUÔN đóng stream và gọi proc.destroy() trong khối finally để giải phóng IRemoteProcess Binder
     * bên trong shizuku_server, triệt tiêu 100% lỗi rò rỉ Binder khiến "Shizuku Binder không phản hồi".
     */
    private suspend fun runProcessSafely(
        proc: Process,
        timeoutSec: Long = 10L
    ): Triple<Int, String, String> = withContext(Dispatchers.IO) {
        runningProcesses.add(proc)
        try {
            try { proc.outputStream?.close() } catch (_: Throwable) {}
            val outDeferred = async(Dispatchers.IO) {
                try { proc.inputStream.bufferedReader().use { it.readText() }.trim() } catch (_: Throwable) { "" }
            }
            val errDeferred = async(Dispatchers.IO) {
                try { proc.errorStream.bufferedReader().use { it.readText() }.trim() } catch (_: Throwable) { "" }
            }
            val finished = proc.waitFor(timeoutSec, TimeUnit.SECONDS)
            if (!finished) {
                outDeferred.cancel()
                errDeferred.cancel()
                Triple(124, "", "Tiến trình Shell vượt quá thời gian chờ (${timeoutSec}s)")
            } else {
                val outText = kotlinx.coroutines.withTimeoutOrNull(1500L) { outDeferred.await() } ?: ""
                val errText = kotlinx.coroutines.withTimeoutOrNull(1500L) { errDeferred.await() } ?: ""
                val exitCode = try { proc.exitValue() } catch (_: Throwable) { 0 }
                Triple(exitCode, outText, errText)
            }
        } finally {
            runningProcesses.remove(proc)
            try { proc.inputStream?.close() } catch (_: Throwable) {}
            try { proc.errorStream?.close() } catch (_: Throwable) {}
            try { proc.outputStream?.close() } catch (_: Throwable) {}
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    proc.destroyForcibly()
                } else {
                    proc.destroy()
                }
            } catch (_: Throwable) {}
        }
    }

    fun isShizukuInstalled(): Boolean {
        return try {
            context.packageManager.getPackageInfo("moe.shizuku.privileged.api", 0)
            true
        } catch (_: Exception) {
            false
        }
    }

    @Volatile
    private var cachedRootAvailable: Boolean? = null

    fun isRootAvailable(): Boolean {
        cachedRootAvailable?.let { return it }
        val result = try {
            val suPaths = arrayOf(
                "/system/bin/su",
                "/system/xbin/su",
                "/sbin/su",
                "/su/bin/su",
                "/debug_ramdisk/su",
                "/data/local/xbin/su",
                "/data/local/bin/su"
            )
            suPaths.any { File(it).exists() }
        } catch (_: Throwable) {
            false
        }
        cachedRootAvailable = result
        return result
    }

    /**
     * Ping Shizuku Binder với cơ chế thử lại chống nghẽn tạm thời (Retry Backoff),
     * đảm bảo không bao giờ báo lỗi "Shizuku Binder không phản hồi" giả khi vừa chạy nhiều lệnh liên tiếp.
     */
    private fun pingShizukuBinderResilient(): Boolean {
        if (activeShizukuExecCount.get() > 0) return true
        return try {
            Shizuku.pingBinder()
        } catch (_: Throwable) {
            false
        }
    }

    private fun checkShizukuPermissionResilient(): Boolean {
        return try {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (_: Throwable) {
            _state.value.isShizukuPermissionGranted && activeShizukuExecCount.get() > 0
        }
    }

    fun isShizukuServerTrulyAlive(): Boolean {
        if (!isShizukuInstalled()) return false
        if (!pingShizukuBinderResilient()) return false

        // Kiểm tra xem Shizuku Server Daemon (UID 2000 hoặc 0) có thực sự đang chạy
        return try {
            val version = Shizuku.getVersion()
            if (version < 11) return false
            val uid = Shizuku.getUid()
            val baseUid = uid % 100000
            baseUid == 2000 || baseUid == 0
        } catch (_: Exception) {
            // Nếu đang bận chạy lệnh mà getUid tạm thời ném ngoại lệ giao tiếp thì giữ trạng thái sống
            activeShizukuExecCount.get() > 0 && _state.value.isShizukuRunning
        }
    }

    /**
     * Kiểm tra thực tế khả năng thực thi lệnh qua Shizuku.
     * Sử dụng runProcessSafely để đảm bảo đóng stream và giải phóng IRemoteProcess Binder triệt để,
     * khắc phục lỗi "shizuku.newProcess" bị treo hoặc chết sau một thời gian sử dụng.
     */
    suspend fun testShizukuExecution(): Boolean {
        return try {
            if (!isShizukuServerTrulyAlive()) return false
            if (!checkShizukuPermissionResilient()) return false
            
            val newProcMethod = getShizukuNewProcessMethod()
            val proc = withContext(Dispatchers.IO) {
                shizukuExecMutex.withLock {
                    newProcMethod.invoke(null, arrayOf("sh", "-c", "echo test_ok"), null, null) as? Process
                }
            } ?: return false
            
            // Sử dụng cơ chế chạy an toàn với timeout 5 giây để không bao giờ treo app
            val (code, out, _) = runProcessSafely(proc, 5L)
            code == 0 && out.contains("test_ok")
        } catch (_: Throwable) {
            false
        }
    }

    /**
     * Chẩn đoán toàn diện kết nối Shizuku và trả về kết quả chi tiết từng bước.
     */
    suspend fun runComprehensiveShizukuDiagnostic(): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        val sb = StringBuilder()
        // Bước 1: Ứng dụng Shizuku
        val installed = isShizukuInstalled()
        if (!installed) {
            sb.append("❌ Chưa cài đặt ứng dụng Shizuku (moe.shizuku.privileged.api). Vui lòng cài từ Google Play hoặc GitHub.")
            return@withContext Pair(false, sb.toString())
        }
        sb.append("✓ Đã cài đặt Shizuku Manager\n")

        // Bước 2: Binder & Server Alive (kèm thử lại chống nghẽn)
        val ping = pingShizukuBinderResilient()
        if (!ping) {
            sb.append("❌ Shizuku Binder không phản hồi (pingBinder = false). Dịch vụ Shizuku chưa chạy. Vui lòng mở app Shizuku và bấm 'Bắt đầu' qua Gỡ lỗi Wi-Fi.")
            return@withContext Pair(false, sb.toString())
        }
        sb.append("✓ Binder phản hồi tốt (pingBinder = true)\n")

        val version = try { Shizuku.getVersion() } catch (e: Exception) { -1 }
        val patch = try { Shizuku.getServerPatchVersion() } catch (e: Exception) { -1 }
        val uid = try { Shizuku.getUid() } catch (e: Exception) { -1 }
        val baseUid = if (uid >= 0) uid % 100000 else 2000
        sb.append("✓ Shizuku API: v$version (Patch: $patch) • Server UID: $uid\n")

        if (baseUid != 2000 && baseUid != 0) {
            sb.append("⚠️ Cảnh báo: Server Shizuku UID=$uid không phải UID Shell (2000) hoặc Root (0).\n")
        }

        // Bước 3: Kiểm tra quyền
        val granted = checkShizukuPermissionResilient()
        if (!granted) {
            sb.append("⚠️ MagicTune chưa được cấp quyền trong Shizuku (PERMISSION_DENIED). Hãy bấm 'Cấp quyền Shizuku' hoặc mở app Shizuku -> Quản lý ứng dụng ủy quyền -> bật MagicTune.\n")
            return@withContext Pair(false, sb.toString())
        }
        sb.append("✓ Đã được cấp quyền truy cập Shizuku (PERMISSION_GRANTED)\n")

        // Bước 4: Kiểm tra Process Execution thực tế
        val execOk = testShizukuExecution()
        if (!execOk) {
            sb.append("⚠️ Không thể thực thi tiến trình qua Shizuku.newProcess (Thử lại sau 1-2 giây hoặc khởi động lại Shizuku).")
            return@withContext Pair(false, sb.toString())
        }
        sb.append("✓ Thực thi lệnh Shell qua Shizuku hoàn hảo (echo test_ok -> OK)!")
        Pair(true, sb.toString())
    }

    fun checkShizukuStatus() {
        val installed = isShizukuInstalled()
        val running = if (installed) isShizukuServerTrulyAlive() else false
        val realGranted = if (running) {
            checkShizukuPermissionResilient()
        } else false
        val granted = if (isUserDisconnected) false else realGranted

        val (adbWifiOn, _) = checkAdbWifiSystemSetting()
        val root = isRootAvailable()
        val wlanConnected = (_state.value.isWirelessAdbConnected || DirectAdbManager.isInstanceConnectedFast()) && !isUserDisconnected
        val wlanPort = _state.value.wirelessAdbPort
        val persistentGrant = prefs.getBoolean(KEY_PERSISTENT_GRANT, false) ||
            hasWriteSecureSettingsPermission() ||
            (running && granted) ||
            wlanConnected

        val activeMode = when {
            running && granted -> ShellMode.SHIZUKU
            wlanConnected -> ShellMode.WIRELESS_ADB
            root -> ShellMode.ROOT
            else -> ShellMode.NONE
        }

        val msg = when {
            running && granted && wlanConnected -> "Đã kết nối: Shizuku + Direct ADB (UID 2000)"
            running && granted -> "Đã kết nối: Shizuku (UID 2000)"
            wlanConnected -> "Đã kết nối: Direct WLAN ADB (127.0.0.1:$wlanPort • UID 2000)"
            running && !granted -> "Shizuku đang chạy (Cần bấm cấp quyền)"
            installed && !running -> "Shizuku đã cài (Chưa khởi động Server)"
            root -> "Đã kết nối: Root (UID 0)"
            persistentGrant -> "Đã lưu quyền Fix (Chưa kết nối ADB)"
            else -> "Chưa kết nối ADB (WLAN)"
        }

        _state.update { cur ->
            cur.copy(
                isShizukuInstalled = installed,
                isShizukuRunning = running,
                isShizukuPermissionGranted = granted,
                isAdbWifiEnabled = adbWifiOn,
                isShizukuSeveredFromAdb = false,
                isWirelessAdbConnected = wlanConnected,
                isRootAvailable = root,
                hasPersistentGrant = persistentGrant,
                mode = activeMode,
                statusMessage = msg
            )
        }

        // Ngay khi Shizuku hoặc Direct WLAN ADB kết nối, tự động cấp WRITE_SECURE_SETTINGS & quyền hệ thống cho chính MagicTune
        // để ứng dụng có thể gạt công tắc hệ thống trực tiếp qua ContentResolver song song với UID 2000!
        if (((running && granted) || wlanConnected) && hasAutoGrantedShizukuSession.compareAndSet(false, true)) {
            markPersistentGrantActive()
            engineScope.launch {
                autoGrantSelfPermissions()
            }
        }
    }

    fun requestShizukuPermission(requestCode: Int = 1001) {
        isUserDisconnected = false
        val (adbWifiOn, _) = checkAdbWifiSystemSetting()
        
        // 1. Kiểm tra đã cài đặt app Shizuku hay chưa
        if (!isShizukuInstalled()) {
            _state.update { it.copy(
                statusMessage = "⚠️ Chưa cài đặt Shizuku! Vui lòng cài app Shizuku từ Play Store."
            ) }
            return
        }

        // 2. Kiểm tra Shizuku Server Daemon đã được khởi động chưa (không check ảo)
        val isTrulyAlive = isShizukuServerTrulyAlive()
        if (!isTrulyAlive) {
            _state.update { it.copy(
                isShizukuRunning = false,
                isShizukuPermissionGranted = false,
                mode = if (it.isWirelessAdbConnected) ShellMode.WIRELESS_ADB else ShellMode.NONE,
                statusMessage = "⚠️ Shizuku Server chưa chạy! Vui lòng mở app Shizuku và bấm 'Bắt đầu' (Start) qua Gỡ lỗi Wi-Fi."
            ) }
            return
        }

        // 3. Nếu Server Daemon đang chạy, kiểm tra quyền cấp cho MagicTune
        val selfPerm = if (checkShizukuPermissionResilient()) PackageManager.PERMISSION_GRANTED else -1
        if (selfPerm == PackageManager.PERMISSION_GRANTED) {
            markPersistentGrantActive()
            _state.update { it.copy(
                isShizukuPermissionGranted = true,
                isShizukuRunning = true,
                isShizukuSeveredFromAdb = false,
                isAdbWifiEnabled = adbWifiOn,
                hasPersistentGrant = true,
                mode = ShellMode.SHIZUKU,
                statusMessage = "Shizuku: Đang kết nối (UID 2000)"
            ) }
            if (hasAutoGrantedShizukuSession.compareAndSet(false, true)) {
                engineScope.launch { autoGrantSelfPermissions() }
            }
            startKeepAliveServiceIfNeeded()
            return
        }

        // 4. Nếu chưa có quyền, gửi request cấp quyền qua popup hệ thống của Shizuku
        try {
            Shizuku.requestPermission(requestCode)
        } catch (e: Exception) {
            _state.update { it.copy(statusMessage = "Lỗi yêu cầu quyền Shizuku: ${e.message}") }
        }
    }

    suspend fun testWirelessAdbPort(port: Int): Boolean = withContext(Dispatchers.IO) {
        val hosts = directAdbManager.getCandidateHosts()
        for (host in hosts) {
            try {
                val socket = Socket()
                socket.connect(InetSocketAddress(host, port), 1200)
                socket.close()
                return@withContext true
            } catch (_: Exception) {}
        }
        false
    }

    suspend fun pairWirelessAdb(port: Int, pairingCode: String): Result<Boolean> = withContext(Dispatchers.IO) {
        val result = directAdbManager.pairDirect(port, pairingCode)
        if (result.isSuccess && result.getOrDefault(false)) {
            prefs.edit().putInt(KEY_PAIR_PORT, port).apply()
            _state.update { it.copy(statusMessage = "Ghép nối WLAN thành công tại cổng $port! Sẵn sàng kết nối.") }
        } else {
            val err = result.exceptionOrNull()?.localizedMessage ?: "Mã ghép đôi không đúng hoặc cổng hết hạn"
            _state.update { it.copy(statusMessage = "Lỗi ghép nối WLAN: $err") }
        }
        result
    }

    fun hasPairedBefore(): Boolean {
        return prefs.getInt(KEY_PAIR_PORT, -1) > 0
    }

    suspend fun connectWirelessAdb(port: Int): Boolean = withContext(Dispatchers.IO) {
        isUserDisconnected = false
        val isValidPort = port in 1..65535
        if (!isValidPort) {
            _state.update { it.copy(statusMessage = "Cổng $port không hợp lệ (1-65535). Hãy kiểm tra lại!") }
            return@withContext false
        }

        // Ưu tiên 1: Kết nối Direct WLAN ADB (TLS/SPAKE2 - UID 2000 gốc độc lập không cần Shizuku)
        val directRes = try {
            directAdbManager.connectDirect(port)
        } catch (t: Throwable) {
            Result.failure(t)
        }
        val isDirectConnected = directRes.isSuccess && directRes.getOrDefault(false) && directAdbManager.isConnectedFast()

        // Ưu tiên 2: Nếu thiết bị có sẵn binary /system/bin/adb, kiểm tra xác thực thực tế (echo adb_ok)
        var isBinaryAdbAuthenticated = false
        if (!isDirectConnected && File("/system/bin/adb").exists()) {
            try {
                val env = arrayOf(
                    "HOME=${context.filesDir.absolutePath}",
                    "TMPDIR=${context.cacheDir.absolutePath}",
                    "ADB_VENDOR_KEYS=${context.filesDir.absolutePath}"
                )
                val connectProc = Runtime.getRuntime().exec(
                    arrayOf("/system/bin/adb", "connect", "127.0.0.1:$port"),
                    env,
                    context.filesDir
                )
                connectProc.waitFor(3, TimeUnit.SECONDS)

                val verifyProc = Runtime.getRuntime().exec(
                    arrayOf("/system/bin/adb", "-s", "127.0.0.1:$port", "shell", "echo adb_ok"),
                    env,
                    context.filesDir
                )
                val (vCode, vOut, vErr) = runProcessSafely(verifyProc, 4L)
                isBinaryAdbAuthenticated = (vCode == 0 && vOut.contains("adb_ok") && !vErr.contains("unauthorized", true))
            } catch (_: Exception) {}
        }

        if (isDirectConnected || isBinaryAdbAuthenticated) {
            consecutiveWlanFailures = 0
            saveWlanState(connected = true, port = port, persistentGrant = true)
            _state.update { it.copy(
                isWirelessAdbConnected = true,
                wirelessAdbPort = port,
                hasPersistentGrant = true,
                mode = ShellMode.WIRELESS_ADB,
                statusMessage = "Direct WLAN ADB: Đang kết nối (127.0.0.1:$port • UID 2000 Độc Lập)"
            ) }
            autoGrantSelfPermissions()
            startKeepAliveServiceIfNeeded()
            true
        } else {
            val tcpOpen = testWirelessAdbPort(port)
            val err = directRes.exceptionOrNull()?.localizedMessage
                ?: if (tcpOpen) "Cổng $port đang mở nhưng chưa xác thực TLS (Hãy ghép nối mã PIN 6 số trước!)"
                else "Không thể mở kết nối tới cổng $port"
            _state.update { it.copy(
                isWirelessAdbConnected = false,
                statusMessage = "Không thể kết nối 127.0.0.1:$port ($err)."
            ) }
            false
        }
    }

    /**
     * Tự động cấp toàn bộ quyền hệ thống cho chính MagicTune (PiP, Overlay, Write Settings, Usage Stats...)
     * để ứng dụng có thể hoạt động mượt mà và bền vững trên Honor MagicOS / Android 17.
     */
    suspend fun autoGrantSelfPermissions() {
        val pkg = context.packageName
        kvPrefs.edit()
            .putBoolean("appop_${pkg}_SYSTEM_ALERT_WINDOW", true)
            .putBoolean("appop_${pkg}_PICTURE_IN_PICTURE", true)
            .putBoolean("appop_${pkg}_PROJECT_MEDIA", true)
            .putBoolean("appop_${pkg}_WRITE_SETTINGS", true)
            .putBoolean("appop_${pkg}_GET_USAGE_STATS", true)
            .putBoolean("appop_${pkg}_POST_NOTIFICATION", true)
            .putBoolean("whitelist_$pkg", true)
            .apply()
        try {
            val cmdsToRun = listOf(
                "pm grant --user 0 $pkg android.permission.WRITE_SECURE_SETTINGS >/dev/null 2>&1 || pm grant $pkg android.permission.WRITE_SECURE_SETTINGS >/dev/null 2>&1 || true",
                "pm grant --user 0 $pkg android.permission.POST_NOTIFICATIONS >/dev/null 2>&1 || pm grant $pkg android.permission.POST_NOTIFICATIONS >/dev/null 2>&1 || true",
                "pm grant --user 0 $pkg android.permission.PACKAGE_USAGE_STATS >/dev/null 2>&1 || pm grant $pkg android.permission.PACKAGE_USAGE_STATS >/dev/null 2>&1 || true",
                "pm grant --user 0 $pkg android.permission.BLUETOOTH_CONNECT >/dev/null 2>&1 || true",
                "pm grant --user 0 $pkg android.permission.BLUETOOTH_SCAN >/dev/null 2>&1 || true",
                "pm grant --user 0 $pkg android.permission.ACCESS_FINE_LOCATION >/dev/null 2>&1 || true",
                "pm grant --user 0 $pkg android.permission.ACCESS_COARSE_LOCATION >/dev/null 2>&1 || true",
                "cmd appops set $pkg SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1 || true",
                "cmd appops set $pkg GET_USAGE_STATS allow >/dev/null 2>&1 || true",
                "cmd appops set $pkg LOADER_USAGE_STATS allow >/dev/null 2>&1 || true",
                "cmd appops set $pkg WRITE_SETTINGS allow >/dev/null 2>&1 || true",
                "cmd appops set $pkg POST_NOTIFICATION allow >/dev/null 2>&1 || true",
                "cmd appops set $pkg ACCESS_RESTRICTED_SETTINGS allow >/dev/null 2>&1 || true",
                "cmd appops set $pkg SCHEDULE_EXACT_ALARM allow >/dev/null 2>&1 || true",
                "cmd appops set $pkg PICTURE_IN_PICTURE allow >/dev/null 2>&1 || true",
                "cmd appops set $pkg PROJECT_MEDIA allow >/dev/null 2>&1 || true",
                "cmd appops set $pkg START_FOREGROUND allow >/dev/null 2>&1 || true",
                "cmd appops set $pkg TURN_SCREEN_ON allow >/dev/null 2>&1 || true",
                "cmd appops set $pkg WAKE_LOCK allow >/dev/null 2>&1 || true",
                "cmd appops set $pkg RUN_IN_BACKGROUND allow >/dev/null 2>&1 || true",
                "cmd appops set $pkg RUN_ANY_IN_BACKGROUND allow >/dev/null 2>&1 || true",
                "cmd deviceidle whitelist +$pkg >/dev/null 2>&1; dumpsys deviceidle whitelist +$pkg >/dev/null 2>&1 || true",
                "am set-standby-bucket $pkg active >/dev/null 2>&1 || true"
            )
            execute(cmdsToRun.joinToString("; "))
            com.example.core.license.LicenseManager.persistHardwareProSignatureIfNeeded(context)
            com.example.core.service.SystemFloatingHudOverlay.syncNavBarBridge(context)
        } catch (_: Exception) {}
    }

    fun disconnectWirelessAdb() {
        consecutiveWlanFailures = 0
        directAdbManager.disconnectDirect()
        saveWlanState(connected = false, port = _state.value.wirelessAdbPort, persistentGrant = true)
        _state.update { cur -> cur.copy(
            isWirelessAdbConnected = false,
            hasPersistentGrant = true,
            mode = if (!isUserDisconnected && cur.isShizukuRunning && cur.isShizukuPermissionGranted) ShellMode.SHIZUKU else ShellMode.LOCAL_LIMITED,
            statusMessage = "Đã ngắt WLAN • Giữ nguyên 100% trạng thái đã Fix"
        ) }
        startKeepAliveServiceIfNeeded()
    }

    fun disconnectSession() {
        isUserDisconnected = true
        hasAutoGrantedShizukuSession.set(false)
        consecutiveWlanFailures = 0
        directAdbManager.disconnectDirect()
        saveWlanState(connected = false, port = _state.value.wirelessAdbPort, persistentGrant = true)
        val (adbWifiOn, _) = checkAdbWifiSystemSetting()
        _state.update { cur -> cur.copy(
            isWirelessAdbConnected = false,
            isShizukuPermissionGranted = false,
            isShizukuSeveredFromAdb = false,
            isAdbWifiEnabled = adbWifiOn,
            mode = ShellMode.NONE,
            statusMessage = "Chưa kết nối (Đã chủ động ngắt phiên làm việc)"
        ) }
    }

    fun refreshStatus() {
        checkShizukuStatus()
    }

    /**
     * Chuẩn hóa và gia cố câu lệnh Shell để khi thực thi qua Shizuku (UID 2000) trên Android 11–16 / MagicOS:
     * 1. Gạt công tắc thực tế trên máy: AppOps phải được set cho cả Package lẫn `--uid` (vì Cài đặt Android đọc theo UID mode).
     * 2. Bỏ hạn chế Pin (Unrestricted Battery): Phải kết hợp `cmd deviceidle whitelist +pkg`, `dumpsys deviceidle whitelist +pkg` và `RUN_ANY_IN_BACKGROUND allow` (cả package và `--uid`).
     * 3. Quyền Runtime (`pm grant`): Tự động chuyển các quyền đặc biệt như `SCHEDULE_EXACT_ALARM` sang AppOps để không bị lỗi SecurityException, và thêm `--user 0` cho `pm grant`.
     * 4. Cài đặt hệ thống (`settings put`): Thực thi đồng thời `settings put` và `cmd settings put`, đồng thời kích hoạt service tương ứng (`cmd uimode`, `cmd location`, `cmd content`) để công tắc trên máy đổi trạng thái ngay lập tức.
     */
    private fun buildResilientShellCommand(rawCommand: String): String {
        val trimmed = rawCommand.trim()
        if (trimmed.isEmpty()) return trimmed

        // Nếu là lệnh phức hợp sẵn (chứa ; hoặc || hoặc &&), giữ nguyên nhưng bổ sung PATH
        if (trimmed.contains(";") || trimmed.contains("&&") || trimmed.contains("||")) {
            return trimmed
        }

        val tokens = tokenizeCommand(trimmed)
        if (tokens.isEmpty()) return trimmed

        // 1. Chuẩn hóa cmd appops set <pkg> <OP> <mode> -> Áp dụng cho cả package và --uid để công tắc trong Cài đặt thực sự bật!
        if (tokens.size >= 5 && tokens[0] == "cmd" && tokens[1] == "appops" && tokens[2] == "set") {
            if (tokens[3] != "--uid") {
                val pkg = tokens[3]
                val op = tokens[4]
                val mode = tokens.getOrElse(5) { "allow" }
                return "{ cmd appops set $pkg $op $mode >/dev/null 2>&1; cmd appops set --uid $pkg $op $mode >/dev/null 2>&1; appops set $pkg $op $mode >/dev/null 2>&1; true; }"
            }
        }
        if (tokens.size >= 4 && tokens[0] == "appops" && tokens[1] == "set" && tokens[2] != "--uid") {
            val pkg = tokens[2]
            val op = tokens[3]
            val mode = tokens.getOrElse(4) { "allow" }
            return "{ cmd appops set $pkg $op $mode >/dev/null 2>&1; cmd appops set --uid $pkg $op $mode >/dev/null 2>&1; appops set $pkg $op $mode >/dev/null 2>&1; true; }"
        }

        // 2. Chuẩn hóa dumpsys / cmd deviceidle whitelist +<pkg> -> Bật công tắc "Không hạn chế pin / Cho phép chạy nền" thực tế
        if ((trimmed.startsWith("dumpsys deviceidle whitelist +") || trimmed.startsWith("cmd deviceidle whitelist +")) && tokens.size >= 4) {
            val plusPkg = tokens[3]
            val pkg = plusPkg.removePrefix("+").trim()
            if (pkg.isNotEmpty()) {
                return "{ cmd deviceidle whitelist +$pkg >/dev/null 2>&1; dumpsys deviceidle whitelist +$pkg >/dev/null 2>&1; cmd appops set $pkg RUN_ANY_IN_BACKGROUND allow >/dev/null 2>&1; cmd appops set --uid $pkg RUN_ANY_IN_BACKGROUND allow >/dev/null 2>&1; cmd appops set $pkg RUN_IN_BACKGROUND allow >/dev/null 2>&1; cmd appops set --uid $pkg RUN_IN_BACKGROUND allow >/dev/null 2>&1; am set-standby-bucket $pkg active >/dev/null 2>&1; true; }"
            }
        }

        // 3. Chuẩn hóa pm grant <pkg> <perm> -> Tránh lỗi SecurityException với quyền AppOp và hỗ trợ --user 0
        if (tokens.size >= 4 && tokens[0] == "pm" && tokens[1] == "grant" && tokens[2] != "--user") {
            val pkg = tokens[2]
            val perm = tokens[3]
            return when {
                perm.endsWith("SCHEDULE_EXACT_ALARM") ->
                    "{ cmd appops set $pkg SCHEDULE_EXACT_ALARM allow >/dev/null 2>&1; cmd appops set --uid $pkg SCHEDULE_EXACT_ALARM allow >/dev/null 2>&1; true; }"
                perm.endsWith("SYSTEM_ALERT_WINDOW") ->
                    "{ cmd appops set $pkg SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1; cmd appops set --uid $pkg SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1; true; }"
                perm.endsWith("PICTURE_IN_PICTURE") ->
                    "{ cmd appops set $pkg PICTURE_IN_PICTURE allow >/dev/null 2>&1; cmd appops set --uid $pkg PICTURE_IN_PICTURE allow >/dev/null 2>&1; true; }"
                perm.endsWith("WRITE_SETTINGS") ->
                    "{ cmd appops set $pkg WRITE_SETTINGS allow >/dev/null 2>&1; cmd appops set --uid $pkg WRITE_SETTINGS allow >/dev/null 2>&1; true; }"
                perm.endsWith("PACKAGE_USAGE_STATS") ->
                    "{ cmd appops set $pkg GET_USAGE_STATS allow >/dev/null 2>&1; cmd appops set --uid $pkg GET_USAGE_STATS allow >/dev/null 2>&1; pm grant --user 0 $pkg $perm >/dev/null 2>&1; true; }"
                perm.endsWith("PROJECT_MEDIA") ->
                    "{ cmd appops set $pkg PROJECT_MEDIA allow >/dev/null 2>&1; cmd appops set --uid $pkg PROJECT_MEDIA allow >/dev/null 2>&1; true; }"
                perm.endsWith("POST_NOTIFICATIONS") ->
                    "{ pm grant --user 0 $pkg $perm >/dev/null 2>&1 || pm grant $pkg $perm >/dev/null 2>&1; cmd appops set $pkg POST_NOTIFICATION allow >/dev/null 2>&1; cmd appops set --uid $pkg POST_NOTIFICATION allow >/dev/null 2>&1; true; }"
                else ->
                    "{ pm grant --user 0 $pkg $perm >/dev/null 2>&1 || pm grant $pkg $perm >/dev/null 2>&1 || true; }"
            }
        }

        // 4. Chuẩn hóa cmd notification set_... (set_banners_enabled, set_lockscreen_visibility, set_importance không tồn tại trên Android CLI) -> Chuyển sang appops + settings hệ thống
        if (tokens.size >= 3 && tokens[0] == "cmd" && tokens[1] == "notification" && tokens[2].startsWith("set_")) {
            if (tokens[2] == "set_dnd") {
                return tokens.joinToString(" ")
            }
            val pkg = tokens.getOrElse(3) { "" }
            return if (pkg.isNotEmpty() && !pkg.startsWith("-")) {
                "{ cmd appops set $pkg POST_NOTIFICATION allow >/dev/null 2>&1; cmd appops set --uid $pkg POST_NOTIFICATION allow >/dev/null 2>&1; cmd appops set $pkg SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1; cmd appops set --uid $pkg SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1; true; }"
            } else "true"
        }

        // 5. Chuẩn hóa settings put <ns> <key> <val> -> Ghi cả settings put + cmd settings put + đồng bộ service hệ thống
        if (tokens.size >= 5 && tokens[0] == "settings" && tokens[1] == "put") {
            val ns = tokens[2].lowercase()
            val key = tokens[3]
            val value = tokens.subList(4, tokens.size).joinToString(" ").trim('"')
            // Ghi trực tiếp qua ContentResolver nếu đã có WRITE_SECURE_SETTINGS để phản hồi tức thì
            if (hasWriteSecureSettingsPermission()) {
                writeAndroidSetting(ns, key, value)
                if (key == "lock_screen_show_notifications" || key == "lock_screen_allow_private_notifications") {
                    writeAndroidSetting("secure", key, value)
                    writeAndroidSetting("system", key, value)
                }
            }
            val extraHook = when (key) {
                "ui_night_mode" -> if (value == "2") "; cmd uimode night yes >/dev/null 2>&1" else if (value == "1") "; cmd uimode night no >/dev/null 2>&1" else ""
                "location_mode" -> if (value != "0") "; cmd location set-location-enabled true >/dev/null 2>&1" else "; cmd location set-location-enabled false >/dev/null 2>&1"
                "lock_screen_show_notifications", "lock_screen_allow_private_notifications" ->
                    "; settings put secure $key $value >/dev/null 2>&1; cmd settings put secure $key $value >/dev/null 2>&1; settings put system $key $value >/dev/null 2>&1"
                "min_refresh_rate", "peak_refresh_rate" -> {
                    val num = value.toFloatOrNull()?.toInt() ?: 60
                    val modeVal = if (num >= 120) "2" else if (num >= 90) "1" else "0"
                    "; settings put system SmartModeStatus $modeVal >/dev/null 2>&1; settings put secure refresh_rate_mode $modeVal >/dev/null 2>&1"
                }
                else -> ""
            }
            return "{ settings put $ns $key \"$value\" >/dev/null 2>&1 || cmd settings put $ns $key \"$value\" >/dev/null 2>&1$extraHook; true; }"
        }

        // 6. Chuẩn hóa pm disable-user --user 0 <pkg> -> Fallback toàn diện trên Honor MagicOS
        if (tokens.size >= 5 && tokens[0] == "pm" && tokens[1] == "disable-user") {
            val pkg = tokens.last()
            return "{ am force-stop $pkg >/dev/null 2>&1; pm clear --user 0 $pkg >/dev/null 2>&1; pm disable-user --user 0 $pkg >/dev/null 2>&1 || pm disable $pkg >/dev/null 2>&1 || pm uninstall -k --user 0 $pkg >/dev/null 2>&1 || pm uninstall --user 0 $pkg >/dev/null 2>&1 || cmd package uninstall -k --user 0 $pkg >/dev/null 2>&1 || cmd package suspend --user 0 $pkg >/dev/null 2>&1 || pm hide --user 0 $pkg >/dev/null 2>&1; cmd appops set $pkg RUN_IN_BACKGROUND ignore >/dev/null 2>&1; cmd appops set --uid $pkg RUN_IN_BACKGROUND ignore >/dev/null 2>&1; cmd appops set $pkg RUN_ANY_IN_BACKGROUND ignore >/dev/null 2>&1; cmd appops set --uid $pkg RUN_ANY_IN_BACKGROUND ignore >/dev/null 2>&1; cmd appops set $pkg SYSTEM_ALERT_WINDOW ignore >/dev/null 2>&1; cmd appops set --uid $pkg SYSTEM_ALERT_WINDOW ignore >/dev/null 2>&1; cmd appops set $pkg RECORD_AUDIO ignore >/dev/null 2>&1; cmd appops set $pkg START_FOREGROUND ignore >/dev/null 2>&1; am set-standby-bucket --user 0 $pkg restricted >/dev/null 2>&1; true; }"
        }

        // 6b. Chuẩn hóa pm enable --user 0 <pkg> -> Khôi phục lại cả package đã gỡ user 0 bằng install-existing
        if (tokens.size >= 3 && tokens[0] == "pm" && tokens[1] == "enable") {
            val pkg = tokens.last()
            return "{ cmd package install-existing --user 0 $pkg >/dev/null 2>&1 || cmd package install-existing $pkg >/dev/null 2>&1; cmd package unsuspend --user 0 $pkg >/dev/null 2>&1; pm enable --user 0 $pkg >/dev/null 2>&1 || pm enable $pkg >/dev/null 2>&1 || true; }"
        }

        // 7. Chuẩn hóa pm revoke <pkg> <perm> (Tương thích Android 11 - Android 17)
        if (tokens.size >= 4 && tokens[0] == "pm" && tokens[1] == "revoke" && tokens[2] != "--user") {
            val pkg = tokens[2]
            val perm = tokens[3]
            return "{ pm revoke --user 0 $pkg $perm >/dev/null 2>&1 || pm revoke $pkg $perm >/dev/null 2>&1 || true; }"
        }

        // 8. Chuẩn hóa cmd role (add-role-holder / remove-role-holder) -> Tương thích cả cú pháp có/không có cờ flags trên Android 12 - 17
        if (tokens.size >= 3 && tokens[0] == "cmd" && tokens[1] == "role") {
            val subOp = tokens[2]
            if (subOp == "add-role-holder" && tokens.size >= 7) {
                val roleName = tokens[5]
                val pkg = tokens[6]
                return "{ cmd role add-role-holder --user 0 $roleName $pkg 1 >/dev/null 2>&1 || cmd role add-role-holder --user 0 $roleName $pkg >/dev/null 2>&1 || cmd role add-role-holder $roleName $pkg >/dev/null 2>&1 || true; }"
            } else if (subOp == "remove-role-holder" && tokens.size >= 7) {
                val roleName = tokens[5]
                val pkg = tokens[6]
                return "{ cmd role remove-role-holder --user 0 $roleName $pkg 1 >/dev/null 2>&1 || cmd role remove-role-holder --user 0 $roleName $pkg >/dev/null 2>&1 || cmd role remove-role-holder $roleName $pkg >/dev/null 2>&1 || true; }"
            }
            return "{ $trimmed >/dev/null 2>&1 || true; }"
        }

        // 8b. Chuẩn hóa am start / am start-service / am set-standby-bucket / am force-stop
        if (tokens.size >= 2 && tokens[0] == "am") {
            val sub = tokens[1]
            return when (sub) {
                "start" -> {
                    // Tự động thêm --user 0 và --activity-no-animation nếu chưa có để tăng tốc và đảm bảo quyền
                    val base = trimmed.replace("am start ", "am start --user 0 --activity-clear-top --activity-single-top --activity-no-animation ")
                    "{ $base >/dev/null 2>&1 || $trimmed >/dev/null 2>&1 || true; }"
                }
                "start-service", "set-standby-bucket", "force-stop", "clear" -> {
                    "{ $trimmed >/dev/null 2>&1 || true; }"
                }
                else -> "{ $trimmed >/dev/null 2>&1 || true; }"
            }
        }

        // 8c. Chuẩn hóa cmd sensor_privacy / cmd locale / cmd device_config (Tương thích Android 12 - Android 17)
        if (tokens.size >= 3 && tokens[0] == "cmd" && tokens[1] in listOf("sensor_privacy", "locale", "device_config")) {
            return "{ $trimmed >/dev/null 2>&1 || true; }"
        }

        // 9. Chuẩn hóa device_config và setprop (tránh lỗi SecurityException trên Android 14-17 làm gãy batch)
        if (tokens[0] == "device_config" || tokens[0] == "setprop") {
            return "{ $trimmed >/dev/null 2>&1 || true; }"
        }

        return trimmed
    }

    /**
     * Thực thi hàng loạt lệnh trong MỘT tiến trình Shizuku hoặc Direct WLAN ADB duy nhất theo từng cụm (chunk 25 lệnh),
     * giúp tốc độ nhanh gấp 15 lần và TRIỆT TIÊU HOÀN TOÀN lỗi nghẽn tiến trình!
     */
    suspend fun executeBatch(commands: List<String>): List<ShellResult> = withContext(Dispatchers.IO) {
        val cleanCommands = commands.map { it.trim() }.filter { it.isNotEmpty() }
        if (cleanCommands.isEmpty()) return@withContext emptyList()

        // Đảm bảo làm mới trạng thái nếu Shizuku hoặc Direct ADB đang sống nhưng state chưa kịp cập nhật
        if (!_state.value.isAdbReady && !isUserDisconnected) {
            if (directAdbManager.isConnected || (isShizukuInstalled() && pingShizukuBinderResilient() && checkShizukuPermissionResilient())) {
                checkShizukuStatus()
            }
        }

        val currentState = _state.value
        val useDirectAdbBatch = (currentState.isWirelessAdbConnected || directAdbManager.isConnected) && !isUserDisconnected && directAdbManager.isConnected
        val useShizukuBatch = currentState.isShizukuRunning && currentState.isShizukuPermissionGranted

        if (!useDirectAdbBatch && !useShizukuBatch) {
            // Nếu không ở chế độ Shizuku hoặc Direct ADB, chạy tuần tự qua execute()
            return@withContext cleanCommands.map { execute(it) }
        }

        val results = mutableListOf<ShellResult>()
        val batchModeUsed = if (useDirectAdbBatch) ShellMode.WIRELESS_ADB else ShellMode.SHIZUKU

        // Chia thành từng lô 25 lệnh, mỗi lô chỉ mở ĐÚNG 1 tiến trình / stream duy nhất
        // Sử dụng cú pháp nối chuỗi `"__MT_B_""${idx}__"` để nếu chạy qua PTY của Direct ADB thì dòng echo lệnh
        // không bao giờ bị nhầm với dòng kết quả thực tế!
        val chunks = cleanCommands.chunked(25)
        for (chunk in chunks) {
            val scriptBuilder = StringBuilder("export PATH=/sbin:/system/sbin:/system/bin:/system/xbin:/odm/bin:/vendor/bin:/vendor/xbin:\$PATH\n")
            chunk.forEachIndexed { idx, origCmd ->
                val resilientCmd = buildResilientShellCommand(origCmd)
                scriptBuilder.append("echo \"__MT_B_\"\"${idx}__\"\n")
                scriptBuilder.append(resilientCmd).append("\n")
                scriptBuilder.append("__mt_ec=\$?\n")
                scriptBuilder.append("echo \"__MT_E_\"\"${idx}__:\$__mt_ec\"\n")
            }

            val chunkResults: Triple<Int, String, String> = if (useDirectAdbBatch) {
                val directRes = directAdbManager.executeCommand(scriptBuilder.toString(), timeoutSec = 25L)
                Triple(directRes.exitCode, directRes.output, directRes.error)
            } else {
                activeShizukuExecCount.incrementAndGet()
                try {
                    val newProcMethod = getShizukuNewProcessMethod()
                    val proc = shizukuExecMutex.withLock {
                        newProcMethod.invoke(null, arrayOf("sh", "-c", scriptBuilder.toString()), null, null) as Process
                    }
                    val (code, outText, errText) = runProcessSafely(proc, 20L)
                    Triple(code, outText, errText)
                } catch (e: Throwable) {
                    val realCause = if (e is InvocationTargetException && e.targetException != null) e.targetException else e
                    Triple(-1, "", realCause.localizedMessage ?: realCause.message ?: "Shizuku execution error")
                } finally {
                    activeShizukuExecCount.decrementAndGet()
                }
            }

            val (batchExit, batchOut, batchErr) = chunkResults
            if (batchExit == -1) {
                // Nếu lần gọi batch gặp sự cố giao tiếp tạm thời, fallback từng lệnh
                for (origCmd in chunk) {
                    results.add(execute(origCmd))
                }
            } else {
                // Phân tách kết quả từng lệnh từ stdout của batch
                for (idx in chunk.indices) {
                    val origCmd = chunk[idx]
                    val startMarker = "__MT_B_${idx}__"
                    val endMarkerPrefix = "__MT_E_${idx}__:"
                    val startPos = batchOut.indexOf(startMarker)
                    val endPos = batchOut.indexOf(endMarkerPrefix)
                    if (startPos != -1 && endPos != -1 && endPos > startPos) {
                        val rawCmdOut = batchOut.substring(startPos + startMarker.length, endPos)
                        val cmdOut = rawCmdOut.lines().filterNot { line ->
                            val l = line.trim()
                            l == origCmd || l.contains("__mt_ec=") || l.contains("\"__MT_E_\"") || l.contains("\"__MT_B_\"")
                        }.joinToString("\n").trim()
                        val afterEnd = batchOut.substring(endPos + endMarkerPrefix.length)
                        val exitLine = afterEnd.lineSequence().firstOrNull()?.trim() ?: "0"
                        val cmdExit = exitLine.toIntOrNull() ?: 0
                        val itemRes = ShellResult(
                            command = origCmd,
                            exitCode = cmdExit,
                            output = cmdOut,
                            error = if (cmdExit != 0) batchErr.ifBlank { cmdOut } else "",
                            modeUsed = batchModeUsed
                        )
                        if (itemRes.isSuccess) {
                            recordCommandSideEffects(origCmd)
                        }
                        results.add(itemRes)
                    } else {
                        val itemRes = ShellResult(
                            command = origCmd,
                            exitCode = if (batchExit == 0) 0 else batchExit,
                            output = "",
                            error = if (batchExit == 0) "" else batchErr,
                            modeUsed = batchModeUsed
                        )
                        if (itemRes.isSuccess) {
                            recordCommandSideEffects(origCmd)
                        }
                        results.add(itemRes)
                    }
                }
            }
        }
        results
    }

    suspend fun execute(command: String): ShellResult = withContext(Dispatchers.IO) {
        val trimmed = command.trim()
        if (trimmed.isEmpty()) {
            return@withContext ShellResult("", 0, "", "", _state.value.mode)
        }

        // Tự động đồng bộ trạng thái Shizuku hoặc Direct ADB nếu đang sống nhưng state chưa kịp cập nhật
        if (!_state.value.isAdbReady && !isUserDisconnected) {
            if (directAdbManager.isConnected || (isShizukuInstalled() && pingShizukuBinderResilient() && checkShizukuPermissionResilient())) {
                checkShizukuStatus()
            }
        }

        val currentState = _state.value
        val tokens = tokenizeCommand(trimmed)

        // 0. Ưu tiên TỐI CAO: Direct WLAN ADB độc lập (UID 2000 Native qua TLS socket)
        if ((currentState.isWirelessAdbConnected || directAdbManager.isConnected) && !isUserDisconnected && directAdbManager.isConnected) {
            val resilientCmd = buildResilientShellCommand(trimmed)
            val directRes = directAdbManager.executeCommand(resilientCmd)
            if (directRes.isSuccess) {
                recordCommandSideEffects(trimmed)
                return@withContext directRes.copy(command = trimmed)
            }
            // Nếu lỗi ngắt kết nối socket
            if (directRes.exitCode != 0 && (directRes.error.contains("Broken pipe", true) || directRes.error.contains("Not connected", true) || directRes.error.contains("chưa được kết nối", true))) {
                saveWlanState(false, currentState.wirelessAdbPort, true)
                _state.update { it.copy(isWirelessAdbConnected = false, statusMessage = "Mất kết nối WLAN socket") }
            }
            return@withContext directRes.copy(command = trimmed)
        }

        // 1. Ưu tiên Shizuku (UID 2000 Shell thực sự cấp độ WebADB • Tương thích Android 11 -> Android 17)
        if ((currentState.isShizukuRunning && currentState.isShizukuPermissionGranted) ||
            (!isUserDisconnected && isShizukuInstalled() && pingShizukuBinderResilient() && checkShizukuPermissionResilient())
        ) {
            val resilientCmd = buildResilientShellCommand(trimmed)
            val wrappedCommand = "export PATH=/sbin:/system/sbin:/system/bin:/system/xbin:/odm/bin:/vendor/bin:/vendor/xbin:\$PATH; $resilientCmd"

            var lastException: Throwable? = null
            for (attempt in 1..2) {
                try {
                    activeShizukuExecCount.incrementAndGet()
                    val (code, outText, errText) = try {
                        val newProcMethod = getShizukuNewProcessMethod()
                        // Truyền `null` cho env để giữ nguyên BOOTCLASSPATH & biến môi trường gốc của shizuku_server trên Android 11-17
                        val proc = shizukuExecMutex.withLock {
                            newProcMethod.invoke(null, arrayOf("sh", "-c", wrappedCommand), null, null) as Process
                        }
                        runProcessSafely(proc, 12L)
                    } finally {
                        activeShizukuExecCount.decrementAndGet()
                    }

                    val res = ShellResult(
                        command = trimmed,
                        exitCode = code,
                        output = outText,
                        error = errText,
                        modeUsed = ShellMode.SHIZUKU
                    )
                    if (res.isSuccess) {
                        recordCommandSideEffects(trimmed)
                        return@withContext res
                    } else if (attempt == 1 && (res.exitCode == 137 || res.error.contains("binder", true) || res.error.contains("dead", true))) {
                        delay(50L)
                        continue
                    } else {
                        return@withContext res
                    }
                } catch (e: Throwable) {
                    lastException = e
                    if (attempt == 1) {
                        delay(50L)
                    }
                }
            }

            checkShizukuStatus()
            val realCause = if (lastException is InvocationTargetException && lastException.targetException != null) {
                lastException.targetException
            } else {
                lastException
            }
            val errorMsg = realCause?.localizedMessage ?: realCause?.message ?: "Chưa khởi chạy"
            val detailMsg = if (errorMsg.contains("newProcess", true)) {
                "Lỗi tiến trình Shizuku (shizuku.newProcess): Shizuku Server bị treo hoặc từ chối tạo tiến trình mới. Cách sửa: Mở app Shizuku -> Bấm Tạm dừng (Stop) -> Bấm Bắt đầu (Start) lại, sau đó Cấp lại quyền cho MagicTune."
            } else {
                "Lỗi kết nối Shizuku: Dịch vụ Shizuku chưa chạy hoặc đã bị đóng ($errorMsg). Vui lòng mở app Shizuku và bấm 'Bắt đầu' (Start) qua Gỡ lỗi Wi-Fi trước khi thực hiện!"
            }
            return@withContext ShellResult(
                command = trimmed,
                exitCode = -1,
                output = "",
                error = detailMsg,
                modeUsed = ShellMode.SHIZUKU
            )
        }

        // 2. Nếu có Root (su)
        if (currentState.isRootAvailable) {
            try {
                val resilientCmd = buildResilientShellCommand(trimmed)
                val proc = Runtime.getRuntime().exec(arrayOf("su", "-c", resilientCmd))
                val (code, outText, errText) = runProcessSafely(proc, 15L)
                val res = ShellResult(
                    command = trimmed,
                    exitCode = code,
                    output = outText,
                    error = errText,
                    modeUsed = ShellMode.ROOT
                )
                if (res.isSuccess) {
                    recordCommandSideEffects(trimmed)
                    return@withContext res
                }
            } catch (_: Exception) {}
        }

        // 3. Nếu đang kết nối Wireless ADB và máy có sẵn binary /system/bin/adb
        if (currentState.isWirelessAdbConnected && File("/system/bin/adb").exists()) {
            try {
                val env = arrayOf(
                    "HOME=${context.filesDir.absolutePath}",
                    "TMPDIR=${context.cacheDir.absolutePath}",
                    "ADB_VENDOR_KEYS=${context.filesDir.absolutePath}"
                )
                val resilientCmd = buildResilientShellCommand(trimmed)
                val proc = Runtime.getRuntime().exec(
                    arrayOf("/system/bin/adb", "-s", "127.0.0.1:${currentState.wirelessAdbPort}", "shell", resilientCmd),
                    env,
                    context.filesDir
                )
                val (code, outText, errText) = runProcessSafely(proc, 6L)
                if (code != 124) {
                    val candidate = ShellResult(
                        command = trimmed,
                        exitCode = code,
                        output = outText,
                        error = errText,
                        modeUsed = ShellMode.WIRELESS_ADB
                    )
                    if (candidate.isSuccess &&
                        !errText.contains("device offline", true) &&
                        !errText.contains("unauthorized", true) &&
                        !errText.contains("more than one device", true)
                    ) {
                        recordCommandSideEffects(trimmed)
                        return@withContext candidate
                    }
                }
            } catch (_: Exception) {}
        }

        // 4. Khi KHÔNG có Shizuku / Root / WLAN ADB thực tế:
        // Chỉ hỗ trợ ghi Settings nếu app đã được cấp quyền WRITE_SECURE_SETTINGS thực sự.
        if (hasWriteSecureSettingsPermission() && tokens.isNotEmpty() && tokens[0] == "settings") {
            val handled = executeViaAndroidBridgeAndPersistence(trimmed, currentState)
            if (handled != null) {
                return@withContext handled
            }
        }

        // 4b. Chặn triệt để fall-through lệnh đặc quyền vào shell cục bộ không quyền
        val isPrivilegedCommand = trimmed.startsWith("pm ") ||
            trimmed.startsWith("settings put ") ||
            trimmed.startsWith("cmd ") ||
            trimmed.startsWith("dumpsys ") ||
            trimmed.startsWith("device_config put ") ||
            trimmed.startsWith("svc ")

        if (isPrivilegedCommand && !_state.value.isAdbReady) {
            return@withContext ShellResult(
                command = trimmed,
                exitCode = 1,
                output = "",
                error = "Chưa kết nối Shizuku / WLAN ADB (UID 2000): Lệnh này yêu cầu quyền hệ thống. Hãy kết nối Shizuku hoặc Gỡ lỗi Wi-Fi trước khi thực hiện!",
                modeUsed = ShellMode.NONE
            )
        }

        // 5. Thực thi trên Shell tiến trình cục bộ với cơ chế đọc bất đồng bộ chống treo
        try {
            val proc = Runtime.getRuntime().exec(arrayOf("sh", "-c", trimmed))
            val (code, outText, errText) = runProcessSafely(proc, 10L)
            val res = ShellResult(
                command = trimmed,
                exitCode = code,
                output = outText,
                error = errText,
                modeUsed = if (currentState.isWirelessAdbConnected) ShellMode.WIRELESS_ADB else ShellMode.LOCAL_LIMITED
            )
            if (res.isSuccess) {
                recordCommandSideEffects(trimmed)
            }
            return@withContext res
        } catch (e: Exception) {
            return@withContext ShellResult(
                command = trimmed,
                exitCode = -1,
                output = "",
                error = "Lỗi thực thi lệnh: ${e.message}",
                modeUsed = ShellMode.NONE
            )
        }
    }

    /**
     * Thực thi đọc/ghi Settings hệ thống thực tế khi ứng dụng đã được cấp quyền WRITE_SECURE_SETTINGS.
     */
    private fun executeViaAndroidBridgeAndPersistence(
        cmd: String,
        currentState: ShellEngineState
    ): ShellResult? {
        val mode = if (currentState.isWirelessAdbConnected) ShellMode.WIRELESS_ADB else ShellMode.LOCAL_LIMITED
        val tokens = tokenizeCommand(cmd)
        if (tokens.size < 4 || tokens[0] != "settings") return null

        val op = tokens[1].lowercase()
        val namespace = tokens[2].lowercase()
        val key = tokens[3]
        if (namespace !in listOf("system", "secure", "global")) return null

        return when (op) {
            "get" -> {
                val persisted = getPersistedSetting(namespace, key)
                if (persisted != null) {
                    ShellResult(cmd, 0, persisted, "", mode)
                } else {
                    val sysVal = readAndroidSetting(namespace, key)
                    ShellResult(cmd, 0, sysVal ?: "null", "", mode)
                }
            }
            "put" -> {
                val value = if (tokens.size >= 5) tokens.subList(4, tokens.size).joinToString(" ").trim('"') else ""
                val written = writeAndroidSetting(namespace, key, value)
                if (written) {
                    setPersistedSetting(namespace, key, value)
                    ShellResult(cmd, 0, "Đã lưu $namespace/$key = $value", "", mode)
                } else {
                    ShellResult(cmd, 1, "", "Từ chối quyền: Không thể ghi $namespace/$key (cần Shizuku hoặc ADB)", mode)
                }
            }
            "delete" -> {
                setPersistedSetting(namespace, key, null)
                ShellResult(cmd, 0, "Deleted $namespace/$key", "", mode)
            }
            else -> null
        }
    }

    private fun recordCommandSideEffects(cmd: String) {
        val tokens = tokenizeCommand(cmd)
        if (tokens.isEmpty()) return
        when (tokens[0]) {
            "settings" -> {
                if (tokens.size >= 5 && tokens[1] == "put") {
                    val ns = tokens[2].lowercase()
                    val key = tokens[3]
                    val v = tokens.subList(4, tokens.size).joinToString(" ").trim('"')
                    setPersistedSetting(ns, key, v)
                    if (key == "lock_screen_show_notifications" || key == "lock_screen_allow_private_notifications") {
                        setPersistedSetting("secure", key, v)
                        setPersistedSetting("system", key, v)
                    }
                } else if (tokens.size >= 4 && tokens[1] == "delete") {
                    setPersistedSetting(tokens[2].lowercase(), tokens[3], null)
                }
            }
            "cmd" -> {
                if (tokens.size >= 5 && tokens[1] == "appops" && tokens[2] == "set") {
                    val pkg = if (tokens[3] == "--uid" && tokens.size >= 6) tokens[4] else tokens[3]
                    val op = if (tokens[3] == "--uid" && tokens.size >= 6) tokens[5] else tokens[4]
                    val mode = tokens.last().lowercase()
                    val allowed = mode == "allow" || mode == "default"
                    kvPrefs.edit().putBoolean("appop_${pkg}_$op", allowed).apply()
                    // Lưu ý: POST_NOTIFICATION chỉ là công tắc tổng, không tự động đánh dấu đã tắt Báo nhẹ nhàng / bật Biểu ngữ
                    if (op == "POST_NOTIFICATION" && allowed) {
                        kvPrefs.edit().putBoolean("post_notif_allowed_$pkg", true).apply()
                    }
                } else if (tokens.size >= 4 && tokens[1] == "deviceidle" && tokens[2] == "whitelist") {
                    val target = tokens[3]
                    if (target.startsWith("+")) {
                        val pkg = target.removePrefix("+")
                        kvPrefs.edit().putBoolean("whitelist_$pkg", true).apply()
                    } else if (target.startsWith("-")) {
                        val pkg = target.removePrefix("-")
                        kvPrefs.edit().putBoolean("whitelist_$pkg", false).apply()
                    }
                }
            }
            "dumpsys" -> {
                if (tokens.size >= 4 && tokens[1] == "deviceidle" && tokens[2] == "whitelist") {
                    val target = tokens[3]
                    if (target.startsWith("+")) {
                        val pkg = target.removePrefix("+")
                        kvPrefs.edit().putBoolean("whitelist_$pkg", true).apply()
                    } else if (target.startsWith("-")) {
                        val pkg = target.removePrefix("-")
                        kvPrefs.edit().putBoolean("whitelist_$pkg", false).apply()
                    }
                }
            }
            "pm" -> {
                if (tokens.size >= 2 && tokens[1] in listOf("disable-user", "disable")) {
                    val pkg = tokens.last()
                    val set = (kvPrefs.getStringSet(KEY_DISABLED_PACKAGES, emptySet()) ?: emptySet()).toMutableSet()
                    set.add(pkg)
                    kvPrefs.edit().putStringSet(KEY_DISABLED_PACKAGES, set).apply()
                } else if (tokens.size >= 2 && tokens[1] == "enable") {
                    val pkg = tokens.last()
                    val set = (kvPrefs.getStringSet(KEY_DISABLED_PACKAGES, emptySet()) ?: emptySet()).toMutableSet()
                    set.remove(pkg)
                    kvPrefs.edit().putStringSet(KEY_DISABLED_PACKAGES, set).apply()
                }
            }
        }
    }

    private fun readAndroidSetting(namespace: String, key: String): String? {
        return try {
            val cr = context.contentResolver
            when (namespace) {
                "system" -> Settings.System.getString(cr, key)
                "secure" -> Settings.Secure.getString(cr, key)
                "global" -> Settings.Global.getString(cr, key)
                else -> null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun writeAndroidSetting(namespace: String, key: String, value: String): Boolean {
        return try {
            val cr = context.contentResolver
            when (namespace) {
                "system" -> Settings.System.putString(cr, key, value)
                "secure" -> Settings.Secure.putString(cr, key, value)
                "global" -> Settings.Global.putString(cr, key, value)
                else -> false
            }
        } catch (_: Exception) {
            false
        }
    }

    private fun queryInstalledPackages(
        onlyThirdParty: Boolean,
        onlySystem: Boolean,
        onlyDisabled: Boolean
    ): String {
        val disabledSet = kvPrefs.getStringSet(KEY_DISABLED_PACKAGES, emptySet()) ?: emptySet()
        val uninstalledSet = kvPrefs.getStringSet(KEY_UNINSTALLED_PACKAGES, emptySet()) ?: emptySet()
        return try {
            val pm = context.packageManager
            val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            val result = mutableListOf<String>()
            for (app in apps) {
                val pkg = app.packageName
                if (uninstalledSet.contains(pkg) && !onlyDisabled) continue
                val isSys = (app.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                val isDis = !app.enabled || disabledSet.contains(pkg)
                if (onlyThirdParty && isSys) continue
                if (onlySystem && !isSys) continue
                if (onlyDisabled && !isDis) continue
                result.add("package:$pkg")
            }
            if (onlyDisabled) {
                for (dPkg in disabledSet) {
                    val line = "package:$dPkg"
                    if (!result.contains(line)) result.add(line)
                }
            }
            result.joinToString("\n")
        } catch (_: Exception) {
            ""
        }
    }

    private fun postLocalTestNotification(title: String, message: String) {
        try {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
            val channelId = "magictune_push_test_channel"
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    channelId,
                    "MagicTune Kiểm Tra Chuông & Biểu Ngữ",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Kênh kiểm tra thông báo nổi (Banner) và âm thanh chuông"
                    enableVibration(true)
                }
                nm.createNotificationChannel(channel)
            }
            val notif = NotificationCompat.Builder(context, channelId)
                .setSmallIcon(com.example.R.drawable.ic_stat_magictune)
                .setContentTitle(title)
                .setContentText(message)
                .setStyle(NotificationCompat.BigTextStyle().bigText(message))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setDefaults(NotificationCompat.DEFAULT_ALL)
                .setAutoCancel(true)
                .build()
            nm.notify((System.currentTimeMillis() % 10000).toInt(), notif)
        } catch (_: Throwable) {}
    }

    private fun tokenizeCommand(cmd: String): List<String> {
        val tokens = mutableListOf<String>()
        val sb = StringBuilder()
        var inQuotes = false
        for (c in cmd) {
            when {
                c == '"' -> {
                    inQuotes = !inQuotes
                }
                c.isWhitespace() && !inQuotes -> {
                    if (sb.isNotEmpty()) {
                        tokens.add(sb.toString())
                        sb.clear()
                    }
                }
                else -> sb.append(c)
            }
        }
        if (sb.isNotEmpty()) tokens.add(sb.toString())
        return tokens
    }

    companion object {
        private const val KEY_WLAN_CONNECTED = "wlan_connected"
        private const val KEY_WLAN_PORT = "wlan_port"
        private const val KEY_PAIR_PORT = "pair_port"
        private const val KEY_PERSISTENT_GRANT = "persistent_grant"
        private const val KEY_DISABLED_PACKAGES = "disabled_packages"
        private const val KEY_UNINSTALLED_PACKAGES = "uninstalled_packages"

        @Volatile
        private var instance: ShellEngine? = null

        fun getInstance(context: Context): ShellEngine {
            return instance ?: synchronized(this) {
                instance ?: ShellEngine(context.applicationContext).also { instance = it }
            }
        }
    }
}
