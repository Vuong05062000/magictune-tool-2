package com.example.core.widget







import com.example.MainActivity



import android.Manifest



import android.annotation.SuppressLint



import android.content.Context



import android.content.Intent



import android.content.pm.PackageManager



import android.graphics.Canvas



import android.graphics.Color



import android.graphics.LinearGradient



import android.graphics.Paint
import android.graphics.Path
import android.widget.HorizontalScrollView



import android.graphics.PixelFormat



import android.graphics.RectF



import android.graphics.Shader



import android.graphics.Typeface



import android.graphics.drawable.GradientDrawable



import android.media.AudioAttributes



import android.media.AudioFormat



import android.media.AudioManager



import android.media.AudioRecord



import android.media.MediaPlayer



import android.media.MediaRecorder



import android.media.audiofx.AcousticEchoCanceler



import android.media.audiofx.AutomaticGainControl



import android.media.audiofx.NoiseSuppressor



import android.net.Uri



import android.os.Build



import android.os.Handler



import android.os.Looper



import android.os.VibrationEffect



import android.os.Vibrator



import android.os.VibratorManager



import android.provider.Settings



import android.speech.tts.TextToSpeech



import android.text.TextUtils



import android.util.TypedValue



import android.view.Gravity



import android.view.MotionEvent



import android.view.View



import android.view.WindowManager



import android.widget.FrameLayout



import android.widget.LinearLayout



import android.widget.ScrollView



import android.widget.TextView
import android.widget.EditText
import android.view.inputmethod.InputMethodManager
import android.view.inputmethod.EditorInfo



import android.widget.Toast



import android.graphics.Bitmap



import android.util.Base64



import androidx.core.content.ContextCompat



import com.example.core.license.LicenseManager



import com.example.core.service.MagicTuneCtsAccessibilityService



import com.example.core.service.SystemFloatingHudOverlay



import com.example.core.shell.ShellEngine



import kotlinx.coroutines.CoroutineScope



import kotlinx.coroutines.Dispatchers



import kotlinx.coroutines.Job



import kotlinx.coroutines.SupervisorJob



import kotlinx.coroutines.cancelChildren



import kotlinx.coroutines.delay



import kotlinx.coroutines.isActive



import kotlinx.coroutines.launch



import kotlinx.coroutines.withContext



import org.json.JSONArray



import org.json.JSONObject



import java.io.ByteArrayOutputStream



import java.io.DataOutputStream



import java.io.File



import java.io.FileOutputStream



import java.net.HttpURLConnection



import java.net.URL



import java.net.URLEncoder



import java.nio.ByteBuffer



import java.nio.ByteOrder



import java.util.Locale



import kotlin.math.abs



import kotlin.math.cos



import kotlin.math.max



import kotlin.math.min



import kotlin.math.sin



import kotlin.math.sqrt







/**



 * HỘP THOẠI TRÒ CHUYỆN GIỌNG NÓI GEMINI NỔI TRỰC TIẾP TRÊN MÀN HÌNH (Forced Floating Gemini Live Voice Overlay)



 * thiết kế chuyên biệt cho Honor MagicOS 11 / Android 15 - 17.



 *



 * Giải quyết triệt để hạn chế trên ROM Honor MagicOS nội địa:



 * 1. Hiển thị NỔI TRỰC TIẾP ngay trên màn hình hiện tại (`TYPE_APPLICATION_OVERLAY`) ở bất kỳ ứng dụng nào



 *    (Facebook, Zalo, TikTok, Taobao, Màn hình chính...) mà KHÔNG chuyển hướng người dùng vào bên trong full app Gemini.



 * 2. Thu âm giọng nói trực tiếp kèm tự động ngắt câu thông minh (VAD - Voice Activity Detection) + Nhận diện Tiếng Việt



 *    đa tầng (Cloud Whisper Turbo + Dự phòng đa nguồn), hoạt động 100% ngay cả khi máy Honor nội địa bị khóa Google Speech Services.



 * 3. Phản hồi thông minh bằng giọng nói Tiếng Việt tự nhiên (Neural Vietnamese Voice Stream + TTS) phát trực tiếp ngay ngoài màn hình,



 *    tự động nghe tiếp câu sau (Hội thoại rảnh tay liên tục - Gemini Live Mode).



 * 4. Tự động giải phóng và trả lại 100% quyền Micro (`< 5ms`) ngay khi người dùng mở ứng dụng Gemini chính thức



 *    hoặc khi biểu tượng trò chuyện của app Gemini xuất hiện.



 */



object GeminiLiveFloatingOverlay {







    private val mainHandler = Handler(Looper.getMainLooper())



    private val overlayScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)







    @Volatile



    var isShowing: Boolean = false



        private set







    @Volatile



    var isRecordingMic: Boolean = false



        private set







    private var rootContainer: FrameLayout? = null



    private var statusTitleView: TextView? = null



    private var transcriptTextView: TextView? = null



    private var replyTextView: TextView? = null



    private var replyScrollView: ScrollView? = null



    private var micActionBtn: TextView? = null



    private var continuousModeBtn: TextView? = null



    private var waveVisualizerView: GeminiWaveView? = null
    private var overlayLayoutParams: WindowManager.LayoutParams? = null
    private var manualTextInput: EditText? = null

    /**
     * Bật / tắt cờ Focusable của cửa sổ nổi:
     * - Khi người dùng bấm vào ô nhập liệu: Tắt FLAG_NOT_FOCUSABLE để bàn phím ảo hiển thị và gõ phím được.
     * - Khi gửi hoặc ẩn bàn phím: Bật lại FLAG_NOT_FOCUSABLE để các thao tác vuốt / chạm ngoài màn hình không bị cản trở.
     */
    /**
     * Bật / tắt cờ Focusable & tự động nâng ô nhập liệu cao hơn bàn phím điện thoại:
     * - Khi người dùng bấm vào ô nhập liệu: Tắt FLAG_NOT_FOCUSABLE, set SOFT_INPUT_ADJUST_RESIZE,
     *   và đồng thời tự động nâng y offset lên trên để toàn bộ ô nhập và bảng nổi luôn nổi rõ ràng trên bàn phím (không bị che).
     * - Khi gửi tin nhắn hoặc tắt bàn phím: Hạ y về vị trí chuẩn và bật lại FLAG_NOT_FOCUSABLE để không cản trở màn hình.
     */
    fun updateWindowFocusable(context: Context, focusable: Boolean) {
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return
        val root = rootContainer ?: return
        val lp = overlayLayoutParams ?: return
        val currentFocusable = (lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE) == 0

        // Khi người dùng nhập liệu: Tự động nâng độ cao y offset lên 340dp (hoặc xấp xỉ chiều cao bàn phím thông thường)
        // để toàn bộ ô nhập và bảng điều khiển Gemini Live nổi hẳn lên trên bàn phím Gboard, Laban Key...
        val targetY = if (focusable) dp(context, 340) else dp(context, 10)

        if (currentFocusable != focusable || lp.y != targetY) {
            lp.y = targetY
            if (focusable) {
                // Xóa FLAG_NOT_FOCUSABLE và tuyệt đối KHÔNG có FLAG_ALT_FOCUSABLE_IM (đây là cờ chặn bàn phím IME bên thứ 3)
                lp.flags = (lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()) and WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM.inv()
                lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN or WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE
            } else {
                lp.flags = (lp.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE) and WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM.inv()
                lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING or WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN
            }
            try {
                wm.updateViewLayout(root, lp)
            } catch (_: Throwable) {}
        }
    }

    /**
     * Kiểm tra xem người dùng có thực sự đang chủ động hỏi về nội dung trên màn hình hay không.
     * Chỉ khi người dùng nói hoặc gõ các từ khóa rõ ràng ("màn hình", "trong ảnh", "nội dung này", "dịch màn hình", "trên đây", "trên app này")
     * thì mới gắn context màn hình vào câu hỏi.
     * Ngược lại, nếu người dùng trò chuyện, hỏi đáp kiến thức, hỏi thời tiết, toán học, đời sống...
     * thì Gemini sẽ tập trung 100% vào câu hỏi của người dùng, KHÔNG bị phân tâm bởi chữ nền trên màn hình!
     */
    fun isExplicitScreenQuestion(query: String): Boolean {
        val q = query.trim().lowercase(java.util.Locale.getDefault())
        val screenKeywords = listOf(
            "màn hình", "man hinh", "trên màn", "tren man",
            "màn này", "man nay", "trên đây", "tren day",
            "trong ảnh", "trong anh", "bức ảnh này", "buc anh nay",
            "app này", "ứng dụng này", "trên app", "trong hình",
            "chữ này", "đoạn này", "văn bản này", "tin nhắn này",
            "dịch màn", "dich man", "đang xem", "dang xem",
            "khoanh tròn", "vùng này", "khoanh này", "nội dung này"
        )
        return screenKeywords.any { q.contains(it) }
    }







    private var activeVoiceJob: Job? = null



    private var micKeepAliveDrainJob: Job? = null



    private val audioRecordLock = Any()



    private var audioRecord: AudioRecord? = null



    private var noiseSuppressor: NoiseSuppressor? = null



    private var acousticEchoCanceler: AcousticEchoCanceler? = null



    private var automaticGainControl: AutomaticGainControl? = null



    private var mediaPlayer: MediaPlayer? = null



    private var ttsEngine: TextToSpeech? = null



    private var isTtsReady = false







    @Volatile



    private var lastMicReacquirePulseMs: Long = 0L







    @Volatile



    private var forceFinishRecordingNow = false







    @Volatile



    private var isContinuousConversationEnabled = true







    @Volatile



    private var consecutiveSilentTurns = 0







    private var pendingNextTurnRunnable: Runnable? = null







    @Volatile



    private var currentVoiceAmplitude: Float = 0.08f







    @Volatile



    private var attachedImageBase64: String? = null
    @Volatile
    private var attachedImageDisplayName: String? = null
    @Volatile
    private var attachedDocumentText: String? = null
    @Volatile
    private var attachedDocumentName: String? = null

    private var attachmentBadgeContainer: LinearLayout? = null
    private var attachmentBadgeText: TextView? = null
    private var attachmentMenuContainer: LinearLayout? = null



    @Volatile



    private var attachedImageFile: File? = null



    @Volatile



    private var attachedImageOcrSummary: String? = null







    private val conversationHistory = mutableListOf<Pair<String, String>>() // Pair(role, content)







    /**



     * Kích hoạt hộp thoại Gemini Voice Nổi kèm hình ảnh vừa khoanh trên màn hình để hỏi Gemini.



     */



    fun attachImageDirectly(context: Context, base64: String, displayName: String) {
        attachedImageBase64 = base64
        attachedImageDisplayName = displayName
        attachedDocumentText = null
        attachedDocumentName = null
        mainHandler.post {
            updateAttachmentUi(context)
            transcriptTextView?.text = "🖼️ $displayName\n\"Hãy phân tích chi tiết nội dung và các chi tiết trong ảnh này.\""
            askGeminiDirectly(
                context = context,
                userQuery = "Hãy quan sát và phân tích chi tiết bức ảnh tôi vừa gửi: giải thích đồ vật, nội dung, văn bản trong ảnh và những điểm quan trọng nhất.",
                displayStatus = "🖼️ Đang phân tích bức ảnh: $displayName..."
            )
        }
    }

    fun attachDocumentDirectly(context: Context, fileName: String, textContent: String) {
        attachedDocumentText = textContent
        attachedDocumentName = fileName
        attachedImageBase64 = null
        attachedImageDisplayName = null
        mainHandler.post {
            updateAttachmentUi(context)
            transcriptTextView?.text = "📄 $fileName\n\"Hãy đọc và tóm tắt nội dung chính của tài liệu này.\""
            askGeminiDirectly(
                context = context,
                userQuery = "Hãy đọc và tóm tắt các ý chính, thông tin hoặc nội dung cốt lõi của tài liệu tôi vừa đính kèm.",
                displayStatus = "📄 Đang đọc và tóm tắt tài liệu: $fileName..."
            )
        }
    }

    fun askGeminiDirectly(
        context: Context,
        userQuery: String,
        displayStatus: String = "✨ Gemini đang trả lời bạn...",
        screenContextOverride: String? = null
    ) {
        val appCtx = context.applicationContext
        activeVoiceJob?.cancel()
        activeVoiceJob = overlayScope.launch(Dispatchers.Main) {
            stopSpeakingImmediately()
            isRecordingMic = false
            forceFinishRecordingNow = false
            statusTitleView?.text = displayStatus
            micActionBtn?.text = "⏳ Đang xử lý..."
            waveVisualizerView?.setMode(listening = false, speaking = false)

            // Kiểm tra và thực thi ngay lệnh phần cứng / hệ thống (bật đèn pin, mở app, âm lượng...) khi người dùng gõ văn bản
            val cmdResult = withContext(Dispatchers.IO) {
                GeminiVoiceActionExecutor.tryExecuteVoiceCommand(appCtx, userQuery)
            }
            if (!isActive || !isShowing) return@launch
            if (cmdResult.handled) {
                val confirmMsg = cmdResult.spokenConfirmation
                replyScrollView?.visibility = View.VISIBLE
                replyTextView?.text = "⚡ $confirmMsg"
                replyScrollView?.post {
                    replyScrollView?.fullScroll(View.FOCUS_UP)
                }
                statusTitleView?.text = "🔊 Gemini đã thực hiện lệnh của bạn"
                micActionBtn?.text = "🎙️ Chạm để nói ngay"
                waveVisualizerView?.setMode(listening = false, speaking = true)

                speakVietnameseResponse(appCtx, confirmMsg) {
                    if (cmdResult.shouldDismissOverlay) {
                        dismiss(appCtx)
                    } else if (isShowing) {
                        scheduleNextTurnOrStandby(appCtx)
                    }
                }
                return@launch
            }

            // CHỈ gắn context màn hình khi người dùng THỰC SỰ hỏi về màn hình hoặc có screenContextOverride rõ ràng
            val shouldIncludeScreen = !screenContextOverride.isNullOrBlank() || isExplicitScreenQuestion(userQuery)
            val screenContext = if (shouldIncludeScreen) {
                screenContextOverride ?: run {
                    try {
                        val nodes = MagicTuneCtsAccessibilityService.extractVisibleScreenNodesNow(appCtx)
                        if (nodes.isNotEmpty()) {
                            nodes.take(50).joinToString(" | ") { it.text }
                        } else null
                    } catch (_: Throwable) { null }
                }
            } else null

            val promptForAi = if (!screenContext.isNullOrBlank()) {
                "$userQuery\n[THÔNG TIN THAM KHẢO TỪ MÀN HÌNH ĐIỆN THOẠI: $screenContext]"
            } else {
                userQuery
            }

            val rawAiAnswer = withContext(Dispatchers.IO) {
                generateGeminiVoiceResponse(appCtx, promptForAi)
            }.trim()

            if (!isActive || !isShowing) return@launch

            val cleanAiAnswer = withContext(Dispatchers.IO) {
                val processed = GeminiVoiceActionExecutor.processAiActionTagsIfPresent(appCtx, rawAiAnswer)
                cleanConversationOutput(processed)
            }

            replyScrollView?.visibility = View.VISIBLE
            replyTextView?.text = cleanAiAnswer
            replyScrollView?.post {
                replyScrollView?.fullScroll(View.FOCUS_UP)
            }

            statusTitleView?.text = "🔊 Gemini đang nói chuyện với bạn..."
            micActionBtn?.text = "🎙️ Chạm để ngắt lời & nói tiếp"
            waveVisualizerView?.setMode(listening = false, speaking = true)

            speakVietnameseResponse(appCtx, cleanAiAnswer) {
                if (isShowing) {
                    scheduleNextTurnOrStandby(appCtx)
                }
            }
        }
    }

    /**
     * Làm sạch câu trả lời trò chuyện thông thường: Lọc thẻ suy nghĩ <think>, định dạng thừa,
     * tuyệt đối KHÔNG gắn tiền tố 'Họ nhắn:' vì đây là cuộc trò chuyện trực tiếp giữa người dùng và AI.
     */
    private fun cleanConversationOutput(rawText: String): String {
        return rawText
            .replace(Regex("<think>[\\s\\S]*?</think>"), "")
            .trim()
    }

    /**
     * Lọc sạch 100% mọi rò rỉ prompt, quy tắc hệ thống hoặc câu giải thích thừa thãi
     * để câu trả lời dịch thuật chỉ còn duy nhất nội dung dịch tin nhắn thực tế.
     */
    private fun sanitizeTranslationOutput(rawText: String): String {
        val clean = rawText
            .replace(Regex("<think>[\\s\\S]*?</think>"), "")
            .replace("**", "")
            .replace("*", "")
            .trim()

        val filteredLines = clean.lines()
            .map { it.trim() }
            .filter { line ->
                val lower = line.lowercase()
                !lower.contains("quy tắc") &&
                !lower.contains("quy tac") &&
                !lower.contains("bắt buộc") &&
                !lower.contains("bat buoc") &&
                !lower.contains("nhiệm vụ") &&
                !lower.contains("nhiem vu") &&
                !lower.contains("bạn là trợ lý") &&
                !lower.contains("ban la tro ly") &&
                !lower.contains("mẫu trả lời") &&
                !lower.contains("định dạng") &&
                !lower.contains("yêu cầu") &&
                !lower.contains("hướng dẫn") &&
                !lower.contains("cốt lõi") &&
                !lower.startsWith("1.") &&
                !lower.startsWith("2.") &&
                !lower.startsWith("3.") &&
                !lower.startsWith("4.") &&
                !lower.contains("tìm tin nhắn") &&
                !lower.contains("dịch trực tiếp") &&
                !lower.contains("tuyệt đối không") &&
                !lower.contains("không chào hỏi") &&
                !lower.contains("tôi thấy trên màn hình")
            }

        val result = filteredLines.joinToString("\n").trim()
        val finalAnswer = if (result.isNotBlank()) {
            result
        } else {
            clean.lines().firstOrNull { it.trim().startsWith("Họ nhắn:", ignoreCase = true) }?.trim()
                ?: if (clean.isNotBlank()) clean else "Họ nhắn: [Đã nhận tin nhắn mới]"
        }

        // Đảm bảo luôn có tiền tố "Họ nhắn:" nếu model quên
        return if (!finalAnswer.startsWith("Họ nhắn:", ignoreCase = true) && !finalAnswer.startsWith("Họ bảo:", ignoreCase = true)) {
            "Họ nhắn: $finalAnswer"
        } else {
            finalAnswer
        }
    }

    fun translateCurrentScreenForeignText(context: Context) {
        val appCtx = context.applicationContext
        activeVoiceJob?.cancel()
        activeVoiceJob = overlayScope.launch(Dispatchers.Main) {
            stopSpeakingImmediately()
            isRecordingMic = false
            forceFinishRecordingNow = false
            statusTitleView?.text = "🌐 Đang dịch tin nhắn gần nhất..."
            transcriptTextView?.text = "🌐 Dịch tin nhắn đối phương (Shopee, 1688, TikTok, Zalo, Telegram, WhatsApp...)"
            micActionBtn?.text = "⏳ Đang dịch..."
            waveVisualizerView?.setMode(listening = false, speaking = false)

            // 1. Tạm ẩn nhẹ thẻ nổi 65ms để ảnh chụp màn hình sạch 100% không bị vướng thẻ Gemini
            rootContainer?.alpha = 0f
            delay(65L)

            val (screenshotBase64, screenTextSummary) = withContext(Dispatchers.IO) {
                var bmp = MagicTuneCtsAccessibilityService.captureScreenOffline(appCtx)
                if (bmp == null) {
                    try {
                        val shell = ShellEngine.getInstance(appCtx)
                        if (shell.state.value.isAdbReady) {
                            val sharedDir = appCtx.externalCacheDir ?: appCtx.cacheDir
                            val shotFile = java.io.File(sharedDir, "gemini_screen_capture.png")
                            if (shotFile.exists()) shotFile.delete()
                            shell.execute("screencap -p '${shotFile.absolutePath}' >/dev/null 2>&1")
                            if (shotFile.exists() && shotFile.length() > 1024L) {
                                bmp = android.graphics.BitmapFactory.decodeFile(shotFile.absolutePath)
                            }
                        }
                    } catch (_: Throwable) {}
                }

                val base64Str = if (bmp != null) {
                    try {
                        val maxDim = 1280
                        val w = bmp.width
                        val h = bmp.height
                        val scaled = if (w > maxDim || h > maxDim) {
                            val ratio = if (w > h) maxDim.toFloat() / w else maxDim.toFloat() / h
                            Bitmap.createScaledBitmap(bmp, (w * ratio).toInt(), (h * ratio).toInt(), true)
                        } else bmp
                        val baos = ByteArrayOutputStream()
                        scaled.compress(Bitmap.CompressFormat.JPEG, 80, baos)
                        val encoded = Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
                        if (scaled !== bmp) scaled.recycle()
                        bmp.recycle()
                        encoded
                    } catch (_: Throwable) { null }
                } else null

                val nodes = try {
                    MagicTuneCtsAccessibilityService.extractVisibleScreenNodesNow(appCtx)
                } catch (_: Throwable) { emptyList() }

                val textList = nodes.map { it.text.trim() }
                    .filter { it.length >= 2 }
                    .distinct()

                val summary = if (textList.isNotEmpty()) {
                    // Ưu tiên các tin nhắn mới nhất nằm ở phía cuối đoạn chat (Shopee, 1688, TikTok, Zalo, Telegram, WhatsApp...)
                    val recent = if (textList.size > 35) textList.takeLast(35) else textList
                    recent.joinToString(" | ")
                } else ""

                Pair(base64Str, summary)
            }

            // 2. Hiện lại cửa sổ nổi
            rootContainer?.alpha = 1f

            if (!isActive || !isShowing) return@launch

            attachedImageBase64 = screenshotBase64
            attachedImageDisplayName = "Màn hình dịch tin nhắn"
            attachedImageOcrSummary = screenTextSummary.ifBlank { null }
            updateAttachmentUi(appCtx)

            val userPrompt = "Dịch tin nhắn mới nhất của đối phương trên màn hình chat sang Tiếng Việt. Chỉ ghi đúng 1 câu theo mẫu: Họ nhắn: [bản dịch]. Không chào hỏi, không thêm bất kỳ quy tắc hay giải thích nào."

            statusTitleView?.text = "🌐 Gemini đang dịch tin nhắn..."
            micActionBtn?.text = "⏳ Đang dịch..."

            val promptForAi: String = if (screenTextSummary.isNotBlank()) {
                "$userPrompt\n[Các chuỗi văn bản trích xuất từ màn hình: $screenTextSummary]"
            } else {
                userPrompt
            }

            val rawAiAnswer = withContext(Dispatchers.IO) {
                generateGeminiVoiceResponse(appCtx, promptForAi)
            }.trim()

            if (!isActive || !isShowing) return@launch

            val cleanAiAnswer = withContext(Dispatchers.IO) {
                val processed = GeminiVoiceActionExecutor.processAiActionTagsIfPresent(appCtx, rawAiAnswer)
                cleanConversationOutput(processed)
            }

            replyScrollView?.visibility = View.VISIBLE
            replyTextView?.text = cleanAiAnswer
            replyScrollView?.post {
                replyScrollView?.fullScroll(View.FOCUS_UP)
            }

            statusTitleView?.text = "🌐 Đã dịch tin nhắn đối phương"
            micActionBtn?.text = "🎙️ Chạm để trả lời hoặc hỏi tiếp"
            waveVisualizerView?.setMode(listening = false, speaking = true)

            // Giọng nói TTS chỉ đọc trực tiếp câu dịch tin nhắn của đối phương (không đọc rườm rà)
            val lines = cleanAiAnswer.lines().map { it.trim() }.filter { it.isNotEmpty() }
            val directMsgLine = lines.firstOrNull { it.startsWith("Họ nhắn:", ignoreCase = true) }
                ?: lines.firstOrNull()
                ?: cleanAiAnswer
            val speechToRead = directMsgLine.replace("**", "").replace("*", "").trim()

            speakVietnameseResponse(appCtx, speechToRead) {
                if (isShowing) {
                    scheduleNextTurnOrStandby(appCtx)
                }
            }
        }
    }


    fun askAboutCurrentScreen(context: Context) {
        val appCtx = context.applicationContext
        activeVoiceJob?.cancel()
        activeVoiceJob = overlayScope.launch(Dispatchers.Main) {
            stopSpeakingImmediately()
            isRecordingMic = false
            forceFinishRecordingNow = false
            statusTitleView?.text = "📸 Đang quan sát màn hình hiện tại..."
            transcriptTextView?.text = "✨ Đang xem màn hình:\n\"Trên màn hình đang có nội dung gì?\""
            micActionBtn?.text = "⏳ Đang chụp màn hình..."
            waveVisualizerView?.setMode(listening = false, speaking = false)

            // 1. Tạm ẩn nhẹ thẻ nổi 65ms để ảnh chụp màn hình sạch 100% không bị vướng thẻ Gemini
            rootContainer?.alpha = 0f
            delay(65L)

            val (screenshotBase64, screenTextSummary) = withContext(Dispatchers.IO) {
                var bmp = MagicTuneCtsAccessibilityService.captureScreenOffline(appCtx)
                if (bmp == null) {
                    try {
                        val shell = ShellEngine.getInstance(appCtx)
                        if (shell.state.value.isAdbReady) {
                            val sharedDir = appCtx.externalCacheDir ?: appCtx.cacheDir
                            val shotFile = java.io.File(sharedDir, "gemini_screen_capture.png")
                            if (shotFile.exists()) shotFile.delete()
                            shell.execute("screencap -p '${shotFile.absolutePath}' >/dev/null 2>&1")
                            if (shotFile.exists() && shotFile.length() > 1024L) {
                                bmp = android.graphics.BitmapFactory.decodeFile(shotFile.absolutePath)
                            }
                        }
                    } catch (_: Throwable) {}
                }

                val base64Str = if (bmp != null) {
                    try {
                        val maxDim = 1280
                        val w = bmp.width
                        val h = bmp.height
                        val scaled = if (w > maxDim || h > maxDim) {
                            val ratio = if (w > h) maxDim.toFloat() / w else maxDim.toFloat() / h
                            Bitmap.createScaledBitmap(bmp, (w * ratio).toInt(), (h * ratio).toInt(), true)
                        } else bmp
                        val baos = ByteArrayOutputStream()
                        scaled.compress(Bitmap.CompressFormat.JPEG, 80, baos)
                        val encoded = Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
                        if (scaled !== bmp) scaled.recycle()
                        bmp.recycle()
                        encoded
                    } catch (_: Throwable) { null }
                } else null

                val nodes = try {
                    MagicTuneCtsAccessibilityService.extractVisibleScreenNodesNow(appCtx)
                } catch (_: Throwable) { emptyList() }

                val textList = nodes.map { it.text.trim() }
                    .filter { it.length >= 2 }
                    .distinct()
                    .take(65)

                val summary = if (textList.isNotEmpty()) {
                    textList.joinToString(" | ")
                } else ""

                Pair(base64Str, summary)
            }

            // 2. Hiện lại cửa sổ nổi
            rootContainer?.alpha = 1f

            if (!isActive || !isShowing) return@launch

            attachedImageBase64 = screenshotBase64
            attachedImageDisplayName = "Ảnh chụp màn hình hiện tại"
            attachedImageOcrSummary = screenTextSummary.ifBlank { null }
            updateAttachmentUi(appCtx)

            val userPrompt = "Hãy quan sát màn hình điện thoại hiện tại của tôi và giải thích chi tiết: Trên màn hình đang có nội dung gì, ứng dụng nào đang mở, và các thông tin hoặc thông báo quan trọng nhất là gì?"

            statusTitleView?.text = "✨ Gemini đang trả lời về màn hình..."
            micActionBtn?.text = "⏳ Đang phân tích..."

            val promptForAi = if (screenTextSummary.isNotBlank()) {
                "$userPrompt\n[Dữ liệu chữ đang hiển thị trên màn hình: $screenTextSummary]"
            } else {
                userPrompt
            }

            val rawAiAnswer = withContext(Dispatchers.IO) {
                generateGeminiVoiceResponse(appCtx, promptForAi)
            }.trim()

            if (!isActive || !isShowing) return@launch

            val cleanAiAnswer = withContext(Dispatchers.IO) {
                GeminiVoiceActionExecutor.processAiActionTagsIfPresent(appCtx, rawAiAnswer)
            }

            replyScrollView?.visibility = View.VISIBLE
            replyTextView?.text = cleanAiAnswer
            replyScrollView?.post {
                replyScrollView?.fullScroll(View.FOCUS_UP)
            }

            statusTitleView?.text = "🔊 Gemini đang giải thích màn hình cho bạn..."
            micActionBtn?.text = "🎙️ Chạm để ngắt lời & nói tiếp"
            waveVisualizerView?.setMode(listening = false, speaking = true)

            speakVietnameseResponse(appCtx, cleanAiAnswer) {
                if (isShowing) {
                    scheduleNextTurnOrStandby(appCtx)
                }
            }
        }
    }

    fun clearAttachment(context: Context) {
        attachedImageBase64 = null
        attachedImageDisplayName = null
        attachedDocumentText = null
        attachedDocumentName = null
        mainHandler.post {
            updateAttachmentUi(context)
            statusTitleView?.text = "Sẵn sàng • Chạm micro để nói chuyện hoặc ra lệnh..."
            transcriptTextView?.text = "🎙️ Nói tự nhiên hoặc ra lệnh: \"Mở Zalo\", \"Tăng âm lượng\", \"Bật đèn pin\"..."
        }
    }

    private fun updateAttachmentUi(context: Context) {
        val badge = attachmentBadgeContainer ?: return
        val badgeTv = attachmentBadgeText ?: return
        when {
            attachedImageBase64 != null -> {
                badge.visibility = View.VISIBLE
                badge.background = GradientDrawable().apply {
                    setColor(Color.parseColor("#1E3A5F"))
                    cornerRadius = dp(context, 12).toFloat()
                    setStroke(dp(context, 1), Color.parseColor("#38BDF8"))
                }
                badgeTv.setTextColor(Color.parseColor("#7DD3FC"))
                badgeTv.text = "🖼️ ${attachedImageDisplayName ?: "Ảnh đính kèm"} • Chạm để xóa ✕"
            }
            !attachedDocumentText.isNullOrBlank() -> {
                badge.visibility = View.VISIBLE
                badge.background = GradientDrawable().apply {
                    setColor(Color.parseColor("#312E81"))
                    cornerRadius = dp(context, 12).toFloat()
                    setStroke(dp(context, 1), Color.parseColor("#818CF8"))
                }
                badgeTv.setTextColor(Color.parseColor("#C7D2FE"))
                badgeTv.text = "📄 ${attachedDocumentName ?: "Tài liệu đính kèm"} • Chạm để xóa ✕"
            }
            else -> {
                badge.visibility = View.GONE
            }
        }
    }

    fun showWithAttachedScreenQuery(



        context: Context,



        base64Jpeg: String? = null,



        imageFile: File? = null,



        ocrSummary: String? = null



    ): Boolean {



        attachedImageBase64 = base64Jpeg



        attachedImageFile = imageFile



        attachedImageOcrSummary = ocrSummary



        // conversationHistory kept for continuous memory



        return showAndStartListening(context)



    }







    /**



     * Kích hoạt ngay hộp thoại Gemini Voice Nổi trên màn hình hiện tại và bắt đầu lắng nghe giọng nói.



     */



    fun showAndStartListening(context: Context): Boolean {



        val appCtx = context.applicationContext







        // 0. Kiểm tra quyền Gemini Live: Phải là PRO, còn lượt Dùng Thử, hoặc ĐÃ TỰ THÊM GEMINI API KEY (BYOK)



        val hasCustomKey = LicenseManager.getUserCustomGeminiKey(appCtx).trim().isNotBlank()



        val canAccess = LicenseManager.canAccessGeminiLive(appCtx)



        if (!canAccess) {



            Toast.makeText(



                appCtx,



                "🔒 Bạn đã dùng hết lượt dùng thử Gemini! Vui lòng nâng cấp PRO hoặc vào 'Ô #14 Thiết Lập' thêm Gemini API Key của bạn để tiếp tục trò chuyện miễn phí.",



                Toast.LENGTH_LONG



            ).show()



            try {



                val intent = Intent(appCtx, MainActivity::class.java).apply {



                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)



                    putExtra("TARGET_TAB", "SETUP")



                }



                appCtx.startActivity(intent)



            } catch (_: Throwable) {}



            return false



        }



        // Nếu người dùng dùng key cá nhân BYOK thì không cần trừ lượt dùng thử Pro



        if (!hasCustomKey) {



            LicenseManager.checkAndConsumeProOrTrial(appCtx, "Trợ Lý AI Gemini Live Nổi")



        }







        // 1. Đóng màn hình Khoanh Tròn Tìm Kiếm / Dịch Cuộn nếu đang mở để nhường màn hình cho Gemini Voice



        CircleToSearchOverlayActivity.dismissIfActiveForGemini()



        if (GoogleLiveTranslateOverlay.isRunning) {



            GoogleLiveTranslateOverlay.stop(appCtx)



        }







        // 2. Giải phóng bộ lắng nghe mở khóa ngầm để nhường Micro và nâng cấp Foreground Service giữ Micro



        com.example.core.service.MagicTuneKeepAliveService.ensureMicrophoneForeground(appCtx)



        SystemFloatingHudOverlay.releaseMicrophoneForGeminiImmediately(appCtx)







        // 3. Kiểm tra quyền vẽ trên ứng dụng khác & quyền Micro



        val hasOverlay = Settings.canDrawOverlays(appCtx)



        val hasMic = ContextCompat.checkSelfPermission(



            appCtx,



            Manifest.permission.RECORD_AUDIO



        ) == PackageManager.PERMISSION_GRANTED







        if (!hasOverlay || !hasMic) {



            val shell = ShellEngine.getInstance(appCtx)



            if (shell.state.value.isAdbReady) {



                overlayScope.launch(Dispatchers.IO) {



                    try {



                        val pkg = appCtx.packageName



                        shell.execute(



                            "pm grant --user 0 $pkg android.permission.RECORD_AUDIO >/dev/null 2>&1 || pm grant $pkg android.permission.RECORD_AUDIO >/dev/null 2>&1; " +



                                "cmd appops set $pkg RECORD_AUDIO allow >/dev/null 2>&1; " +



                                "cmd appops set --uid $pkg RECORD_AUDIO allow >/dev/null 2>&1; " +



                                "cmd appops set $pkg SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1"



                        )



                    } catch (_: Throwable) {}



                    withContext(Dispatchers.Main) {



                        if (Settings.canDrawOverlays(appCtx)) {



                            showOverlayInternal(appCtx)



                        } else {



                            GeminiVoiceLockscreenActivity.launchFromOverlay(appCtx)



                        }



                    }



                }



                return true



            }







            // Nếu chưa có quyền Overlay hoặc chưa cấp quyền Micro và không bật ADB -> Mở Activity trong suốt để xin quyền & hiển thị



            if (!hasOverlay || !hasMic) {



                return GeminiVoiceLockscreenActivity.launchFromOverlay(appCtx)



            }



        }







        mainHandler.post {



            showOverlayInternal(appCtx)



        }



        return true



    }







    /**



     * Giải phóng Micro tức khắc (<5ms) và đóng lớp phủ Gemini Nổi của MagicTune



     * khi phát hiện người dùng chuyển sang mở ứng dụng Gemini chính thức.



     */



    fun yieldMicrophoneAndDismissForExternalGemini(context: Context? = null) {



        releaseHardwareMicrophoneCompletely()



        stopSpeakingImmediately()



        if (isShowing && context != null) {



            dismiss(context.applicationContext)



        }



    }







    fun dismiss(context: Context) {



        val appCtx = context.applicationContext



        pendingNextTurnRunnable?.let { mainHandler.removeCallbacks(it) }



        pendingNextTurnRunnable = null



        releaseHardwareMicrophoneCompletely()



        stopSpeakingImmediately()



        activeVoiceJob?.cancel()



        activeVoiceJob = null



        overlayScope.coroutineContext.cancelChildren()







        mainHandler.post {



            val view = rootContainer



            rootContainer = null



            statusTitleView = null

            transcriptTextView = null

            replyTextView = null

            manualTextInput = null

            overlayLayoutParams = null



            replyScrollView = null



            micActionBtn = null



            continuousModeBtn = null



            waveVisualizerView?.stopAnimation()



            waveVisualizerView = null



            isShowing = false



            attachedImageBase64 = null



            attachedImageFile = null



            attachedImageOcrSummary = null
        attachedImageDisplayName = null
        attachedDocumentText = null
        attachedDocumentName = null
        attachmentBadgeContainer?.visibility = View.GONE
        attachmentMenuContainer?.visibility = View.GONE







            if (view != null) {



                try {



                    val wm = appCtx.getSystemService(Context.WINDOW_SERVICE) as? WindowManager



                    wm?.removeViewImmediate(view)



                } catch (_: Throwable) {}



            }



            SystemFloatingHudOverlay.setNavBridgeSuppressedForOverlay(appCtx, false)



        }



    }







    private fun showOverlayInternal(context: Context) {



        val appCtx = context.applicationContext



        if (!Settings.canDrawOverlays(appCtx)) {



            GeminiVoiceLockscreenActivity.launchFromOverlay(appCtx)



            return



        }







        triggerGentleHaptic(appCtx)



        SystemFloatingHudOverlay.setNavBridgeSuppressedForOverlay(appCtx, true)



        consecutiveSilentTurns = 0







        if (isShowing && rootContainer != null) {



            // Nếu hộp thoại đang hiện sẵn -> Bắt đầu lượt nghe mới ngay lập tức



            startNewVoiceConversationTurn(appCtx)



            return



        }







        val wm = appCtx.getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return



        val cardView = buildFloatingGeminiCardUi(appCtx)



        rootContainer = cardView







        val lp = WindowManager.LayoutParams(



            WindowManager.LayoutParams.MATCH_PARENT,



            WindowManager.LayoutParams.WRAP_CONTENT,



            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {



                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY



            } else {



                @Suppress("DEPRECATION")



                WindowManager.LayoutParams.TYPE_PHONE



            },



            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or



                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or



                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,



            PixelFormat.TRANSLUCENT



        ).apply {



            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL



            y = dp(appCtx, 10)



        }







        overlayLayoutParams = lp
        try {

            wm.addView(cardView, lp)

            isShowing = true



            waveVisualizerView?.startAnimation()



            initTtsIfNeeded(appCtx)



            startNewVoiceConversationTurn(appCtx)



        } catch (_: Throwable) {



            isShowing = false



            rootContainer = null



            SystemFloatingHudOverlay.setNavBridgeSuppressedForOverlay(appCtx, false)



        }



    }







    private fun updateContinuousButtonStyle(context: Context) {
        val btn = continuousModeBtn ?: return
        if (isContinuousConversationEnabled) {
            btn.text = "🔄 Trò chuyện: BẬT"
            btn.setTextColor(Color.parseColor("#7DD3FC"))
            btn.background = GradientDrawable().apply {
                setColor(Color.parseColor("#1E3A5F"))
                cornerRadius = dp(context, 16).toFloat()
                setStroke(dp(context, 1), Color.parseColor("#38BDF8"))
            }
        } else {
            btn.text = "⏸️ Trò chuyện: TẮT"
            btn.setTextColor(Color.parseColor("#94A3B8"))
            btn.background = GradientDrawable().apply {
                setColor(Color.parseColor("#25272C"))
                cornerRadius = dp(context, 16).toFloat()
                setStroke(dp(context, 1), Color.parseColor("#383A3F"))
            }
        }
    }

    private fun buildFloatingGeminiCardUi(context: Context): FrameLayout {
        val outerWrapper = FrameLayout(context).apply {
            setPadding(dp(context, 10), dp(context, 4), dp(context, 10), dp(context, 8))
        }

        // Official Google Gemini Material 3 Dark theme floating card surface
        val cardBg = GradientDrawable().apply {
            setColor(Color.parseColor("#18191B"))
            cornerRadius = dp(context, 28).toFloat()
            setStroke(dp(context, 1), Color.parseColor("#35373C"))
        }

        val cardColumn = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            background = cardBg
            setPadding(dp(context, 16), dp(context, 10), dp(context, 16), dp(context, 14))
            elevation = dp(context, 20).toFloat()
        }

        // 1. Drag Handle (Official Gemini Android Overlay centered pill)
        val dragHandle = View(context).apply {
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#4A4C52"))
                cornerRadius = dp(context, 2).toFloat()
            }
        }
        cardColumn.addView(dragHandle, LinearLayout.LayoutParams(dp(context, 38), dp(context, 4)).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            bottomMargin = dp(context, 10)
        })

        // 2. Official Gemini Header Row: [Sparkle Star + Gemini + Live Badge] ... [↗ App Gemini] [✕ Close]
        val headerRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        // Official Gemini 4-pointed Sparkle Star Icon
        val sparkleIcon = GeminiSparkleView(context)
        headerRow.addView(sparkleIcon, LinearLayout.LayoutParams(dp(context, 22), dp(context, 22)).apply {
            rightMargin = dp(context, 8)
        })

        val titleTv = TextView(context).apply {
            text = "Gemini"
            setTextColor(Color.parseColor("#F0F4F9"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            setTypeface(typeface, Typeface.BOLD)
            maxLines = 1
        }
        headerRow.addView(titleTv, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))

        // Official "Live" Badge Pill
        val liveBadge = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(context, 7), dp(context, 3), dp(context, 7), dp(context, 3))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#25272B"))
                cornerRadius = dp(context, 10).toFloat()
                setStroke(dp(context, 1), Color.parseColor("#383A3F"))
            }
        }
        val liveDot = View(context).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#38BDF8"))
            }
        }
        liveBadge.addView(liveDot, LinearLayout.LayoutParams(dp(context, 5), dp(context, 5)).apply {
            rightMargin = dp(context, 4)
        })
        val liveTv = TextView(context).apply {
            text = "Live"
            setTextColor(Color.parseColor("#78D9EC"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            setTypeface(typeface, Typeface.BOLD)
        }
        liveBadge.addView(liveTv, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))
        headerRow.addView(liveBadge, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            leftMargin = dp(context, 8)
        })

        // Spacer pushing action buttons to the right
        val spacer = View(context)
        headerRow.addView(spacer, LinearLayout.LayoutParams(0, 0, 1f))

        // Open App / Expand circular button
        val openAppBtn = TextView(context).apply {
            text = "↗"
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#C4C7C5"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            setTypeface(typeface, Typeface.BOLD)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#25272C"))
                setStroke(dp(context, 1), Color.parseColor("#383A3F"))
            }
            setOnClickListener {
                openOfficialGeminiAppAndYieldMic(context)
            }
        }
        headerRow.addView(openAppBtn, LinearLayout.LayoutParams(dp(context, 32), dp(context, 32)).apply {
            rightMargin = dp(context, 8)
        })

        // Close circular button
        val closeBtn = TextView(context).apply {
            text = "✕"
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#C4C7C5"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setTypeface(typeface, Typeface.BOLD)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#25272C"))
                setStroke(dp(context, 1), Color.parseColor("#383A3F"))
            }
            setOnClickListener {
                dismiss(context)
            }
        }
        headerRow.addView(closeBtn, LinearLayout.LayoutParams(dp(context, 32), dp(context, 32)))

        cardColumn.addView(headerRow, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            bottomMargin = dp(context, 8)
        })

        // 3. Official Gemini Contextual Chips Row (Horizontal Scroll)
        val chipsScroll = HorizontalScrollView(context).apply {
            overScrollMode = View.OVER_SCROLL_NEVER
            isHorizontalScrollBarEnabled = false
        }
        val chipsRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        // Chip 0: Dịch tin nhắn nước ngoài trên màn hình
        val translateChip = TextView(context).apply {
            text = "🌐 Dịch tin nhắn"
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#38BDF8"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(context, 11), dp(context, 6), dp(context, 11), dp(context, 6))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#25272C"))
                cornerRadius = dp(context, 16).toFloat()
                setStroke(dp(context, 1), Color.parseColor("#383A3F"))
            }
            setOnClickListener {
                translateCurrentScreenForeignText(context)
            }
        }
        chipsRow.addView(translateChip, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            rightMargin = dp(context, 6)
        })

        // Chip 1: Screen Context - Trả lời trực tiếp ngay trên Gemini Live
        val screenChip = TextView(context).apply {
            text = "✨ Hỏi về màn hình này"
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#E3E3E3"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(context, 11), dp(context, 6), dp(context, 11), dp(context, 6))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#25272C"))
                cornerRadius = dp(context, 16).toFloat()
                setStroke(dp(context, 1), Color.parseColor("#383A3F"))
            }
            setOnClickListener {
                askAboutCurrentScreen(context)
            }
        }
        chipsRow.addView(screenChip, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            rightMargin = dp(context, 6)
        })

        // Chip 2: Circle to Search
        val circleChip = TextView(context).apply {
            text = "🔍 Khoanh tròn"
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#38BDF8"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(context, 11), dp(context, 6), dp(context, 11), dp(context, 6))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#25272C"))
                cornerRadius = dp(context, 16).toFloat()
                setStroke(dp(context, 1), Color.parseColor("#383A3F"))
            }
            setOnClickListener {
                dismiss(context)
                SystemFloatingHudOverlay.setNavBridgeSuppressedForOverlay(context, true)
                CircleToSearchOverlayActivity.launch(context)
            }
        }
        chipsRow.addView(circleChip, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            rightMargin = dp(context, 6)
        })



        // Chip 3: Continuous Conversation Mode Toggle
        val contBtn = TextView(context).apply {
            gravity = Gravity.CENTER
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(context, 11), dp(context, 6), dp(context, 11), dp(context, 6))
            setOnClickListener {
                isContinuousConversationEnabled = !isContinuousConversationEnabled
                updateContinuousButtonStyle(context)
                if (isContinuousConversationEnabled && !isRecordingMic && mediaPlayer == null) {
                    consecutiveSilentTurns = 0
                    startNewVoiceConversationTurn(context)
                }
            }
        }
        continuousModeBtn = contBtn
        updateContinuousButtonStyle(context)
        chipsRow.addView(contBtn, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))

        chipsScroll.addView(chipsRow, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        ))
        cardColumn.addView(chipsScroll, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            bottomMargin = dp(context, 8)
        })

        // 4. Live Soundwave (GeminiWaveView) + Status
        val statusTv = TextView(context).apply {
            text = "Sẵn sàng • Chạm micro để nói chuyện hoặc ra lệnh..."
            setTextColor(Color.parseColor("#9AA0A6"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
            setTypeface(typeface, Typeface.NORMAL)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        statusTitleView = statusTv
        cardColumn.addView(statusTv, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            bottomMargin = dp(context, 6)
        })

        val waveView = GeminiWaveView(context).apply {
            setOnClickListener {
                consecutiveSilentTurns = 0
                if (isRecordingMic) {
                    forceFinishRecordingNow = true
                } else {
                    startNewVoiceConversationTurn(context)
                }
            }
        }
        waveVisualizerView = waveView
        cardColumn.addView(waveView, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dp(context, 36)
        ).apply {
            bottomMargin = dp(context, 6)
        })

        // 5. User Speech Transcript & Gemini Reply
        val userSaidTv = TextView(context).apply {
            text = "🎙️ Nói tự nhiên hoặc ra lệnh: \"Mở Zalo\", \"Tăng âm lượng\", \"Bật đèn pin\"..."
            setTextColor(Color.parseColor("#F0F4F9"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setTypeface(typeface, Typeface.NORMAL)
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        }
        transcriptTextView = userSaidTv
        cardColumn.addView(userSaidTv, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            bottomMargin = dp(context, 6)
        })

        val scroll = ScrollView(context).apply {
            isVerticalScrollBarEnabled = true
            visibility = View.GONE
        }
        replyScrollView = scroll

        val replyTv = TextView(context).apply {
            text = ""
            setTextColor(Color.parseColor("#F0F4F9"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setLineSpacing(dp(context, 3).toFloat(), 1.15f)
            setPadding(dp(context, 12), dp(context, 10), dp(context, 12), dp(context, 10))
            setTextIsSelectable(true)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#1F2023"))
                cornerRadius = dp(context, 16).toFloat()
                setStroke(dp(context, 1), Color.parseColor("#2F3136"))
            }
        }
        replyTextView = replyTv
        scroll.addView(replyTv, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        ))
        cardColumn.addView(scroll, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dp(context, 105)
        ).apply {
            bottomMargin = dp(context, 8)
        })

        // 7.5. Ô NHẬP LIỆU THỦ CÔNG: Cho phép gõ tin nhắn hỏi Gemini Live bất kỳ lúc nào
        val textInputContainer = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(context, 8), dp(context, 2), dp(context, 4), dp(context, 2))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(context, 20).toFloat()
                setColor(Color.parseColor("#1E2024"))
                setStroke(dp(context, 1), Color.parseColor("#383A3F"))
            }
        }

        val inputEdit = EditText(context).apply {
            hint = "Nhập câu hỏi cho Gemini..."
            setHintTextColor(Color.parseColor("#94A3B8"))
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            background = null
            imeOptions = EditorInfo.IME_ACTION_SEND
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            maxLines = 3
            setPadding(dp(context, 8), dp(context, 6), dp(context, 8), dp(context, 6))

            // Hỗ trợ mượt mà mọi bàn phím bên thứ 3 (Gboard, Laban Key, Samsung...)
            isFocusable = true
            isFocusableInTouchMode = true

            val triggerIme = Runnable {
                updateWindowFocusable(context, true)
                requestFocus()
                val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
                imm?.showSoftInput(this, InputMethodManager.SHOW_FORCED)
            }

            setOnClickListener {
                post(triggerIme)
            }

            setOnTouchListener { _, event ->
                if (event.action == MotionEvent.ACTION_UP) {
                    post(triggerIme)
                }
                false
            }

            setOnFocusChangeListener { _, hasFocus ->
                updateWindowFocusable(context, hasFocus)
                if (hasFocus) {
                    val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
                    imm?.showSoftInput(this, InputMethodManager.SHOW_FORCED)
                }
            }
        }
        manualTextInput = inputEdit

        val sendBtn = TextView(context).apply {
            text = "🚀"
            gravity = Gravity.CENTER
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#2563EB"))
            }
        }

        val sendAction: () -> Unit = {
            val q = inputEdit.text?.toString()?.trim().orEmpty()
            if (q.isNotBlank()) {
                inputEdit.setText("")
                // GIỮ NGUYÊN BÀN PHÍM: Không tự động đóng bàn phím của người dùng đi để có thể tiếp tục gõ trò chuyện liền mạch.
                // Vẫn giữ focus trên ô nhập liệu và giữ vị trí nâng cao trên bàn phím.
                inputEdit.requestFocus()

                // Dừng phát âm thanh hoặc nghe cũ để trả lời ngay câu hỏi văn bản
                stopSpeakingImmediately()
                pauseCurrentTurnCaptureOnly()
                statusTitleView?.text = "✨ Gemini Live • Đang giải đáp..."
                transcriptTextView?.text = "💬 Bạn hỏi: $q"

                askGeminiDirectly(context, q, displayStatus = "✨ Gemini đang trả lời câu hỏi...")
            }
        }

        sendBtn.setOnClickListener { sendAction() }
        inputEdit.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND || actionId == EditorInfo.IME_ACTION_DONE) {
                sendAction()
                true
            } else {
                false
            }
        }

        textInputContainer.addView(inputEdit, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        textInputContainer.addView(sendBtn, LinearLayout.LayoutParams(dp(context, 34), dp(context, 34)).apply {
            leftMargin = dp(context, 4)
        })

        cardColumn.addView(textInputContainer, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            bottomMargin = dp(context, 8)
        })

        // 8. Hàng nút điều khiển dưới đáy: [🌐 Dịch] + [🎙️ Mic] + [⏹️ Dừng]
        val bottomActionsRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        // Nút biểu tượng Dịch '🌐' (Dịch tức thì văn bản & tin nhắn nước ngoài trên màn hình)
        val translateScreenBtn = TextView(context).apply {
            text = "🌐"
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#F0F4F9"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#25272C"))
                setStroke(dp(context, 1), Color.parseColor("#383A3F"))
            }
            setOnClickListener {
                translateCurrentScreenForeignText(context)
            }
        }
        bottomActionsRow.addView(translateScreenBtn, LinearLayout.LayoutParams(dp(context, 42), dp(context, 42)).apply {
            rightMargin = dp(context, 8)
        })

        // Main Mic Action Pill Button (42dp capsule)
        val micBtn = TextView(context).apply {
            text = if (isContinuousConversationEnabled) "🎙️ Đang nghe liên tục... (Chạm để gửi)" else "🎙️ Đang nghe... (Chạm để gửi)"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(context, 12), dp(context, 0), dp(context, 12), dp(context, 0))
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(
                    Color.parseColor("#1D4ED8"), // Google Blue
                    Color.parseColor("#7C3AED"), // Gemini Purple
                    Color.parseColor("#0284C7")  // Sky Blue
                )
            ).apply {
                cornerRadius = dp(context, 21).toFloat()
            }
            setOnClickListener {
                consecutiveSilentTurns = 0
                if (isRecordingMic) {
                    forceFinishRecordingNow = true
                } else {
                    startNewVoiceConversationTurn(context)
                }
            }
        }
        micActionBtn = micBtn
        bottomActionsRow.addView(micBtn, LinearLayout.LayoutParams(0, dp(context, 42), 1f).apply {
            rightMargin = dp(context, 8)
        })

        // Stop / End Session circular button (42dp)
        val stopBtn = TextView(context).apply {
            text = "⏹️"
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#F87171"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#25272C"))
                setStroke(dp(context, 1), Color.parseColor("#383A3F"))
            }
            setOnClickListener {
                dismiss(context)
            }
        }
        bottomActionsRow.addView(stopBtn, LinearLayout.LayoutParams(dp(context, 42), dp(context, 42)))

        cardColumn.addView(bottomActionsRow, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))

        outerWrapper.addView(cardColumn, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        ))

        return outerWrapper
    }








    /**



     * Bắt đầu một lượt lắng nghe giọng nói người dùng -> Chuyển giọng nói thành văn bản ->



     * Kiểm tra lệnh điều khiển điện thoại (Mở app, Cuộn trang, Bấm nút, Đèn pin, Âm lượng...) hoặc Truy vấn AI ->



     * Phát âm thanh trả lời Tiếng Việt trực tiếp trên màn hình -> Tự động nghe tiếp câu sau liền mạch!



     */



    private fun startNewVoiceConversationTurn(context: Context) {



        val appCtx = context.applicationContext







        // Hủy bỏ mọi Runnable chờ trước đó để tránh cuộc gọi muộn hủy lượt ghi âm đang chạy



        pendingNextTurnRunnable?.let { mainHandler.removeCallbacks(it) }



        pendingNextTurnRunnable = null







        // Luôn làm mới quyền giữ Micro liên tục cho Gemini & đảm bảo Foreground Service giữ kênh Micro



        com.example.core.service.MagicTuneKeepAliveService.ensureMicrophoneForeground(appCtx)



        SystemFloatingHudOverlay.releaseMicrophoneForGeminiImmediately(appCtx)







        stopSpeakingImmediately()



        // QUAN TRỌNG: Chỉ dừng vòng lặp thu của lượt trước, TUYỆT ĐỐI KHÔNG đóng/release AudioRecord phần cứng



        // để Android 14/15/16/MagicOS không bao giờ thu hồi quyền Micro khi sang câu thứ 2, thứ 3!



        pauseCurrentTurnCaptureOnly()



        activeVoiceJob?.cancel()







        val hasMic = ContextCompat.checkSelfPermission(



            appCtx,



            Manifest.permission.RECORD_AUDIO



        ) == PackageManager.PERMISSION_GRANTED







        if (!hasMic) {



            statusTitleView?.text = "⚠️ Gemini Live đang chờ cấp quyền Micro"



            transcriptTextView?.text = "👉 Chạm vào nút bên dưới để cấp quyền Micro cho Gemini Voice"



            micActionBtn?.text = "🎙️ Cấp quyền Micro ngay"



            micActionBtn?.setOnClickListener {



                GeminiVoiceLockscreenActivity.launchFromOverlay(appCtx)



            }



            GeminiVoiceLockscreenActivity.launchFromOverlay(appCtx)



            return



        }







        activeVoiceJob = overlayScope.launch {



            statusTitleView?.text = if (isContinuousConversationEnabled) {



                "✨ Gemini Live • Đang nghe liền mạch (Rảnh tay)..."



            } else {



                "✨ Gemini Live Nổi • Đang lắng nghe bạn nói..."



            }



            if (conversationHistory.isEmpty() && consecutiveSilentTurns == 0) {



                transcriptTextView?.text = "🎙️ Hãy nói câu hỏi hoặc ra lệnh: \"Mở Zalo\", \"Cuộn xuống\", \"Bật đèn pin\"..."



            } else {



                transcriptTextView?.text = "🎙️ Micro đang mở • Hãy nói câu tiếp theo của bạn..."



            }



            micActionBtn?.text = "🎙️ Đang nghe... (Chạm để gửi)"



            waveVisualizerView?.setMode(listening = true, speaking = false)







            val wavBytes = withContext(Dispatchers.IO) {



                recordVoiceWithAutoVad(appCtx)



            }







            if (!isActive || !isShowing) return@launch







            if (wavBytes == null || wavBytes.size < 1600) {



                handleSilentOrEmptyTurn(appCtx)



                return@launch



            }







            statusTitleView?.text = "✨ Gemini Live • Đang nhận diện & xử lý..."



            transcriptTextView?.text = "⏳ Đang nhận diện giọng nói của bạn..."



            micActionBtn?.text = "⏳ Đang xử lý..."



            waveVisualizerView?.setMode(listening = false, speaking = true)







            val spokenText = withContext(Dispatchers.IO) {



                transcribeAudioBytesToVietnamese(appCtx, wavBytes)



            }.trim()







            if (!isActive || !isShowing) return@launch







            if (spokenText.isBlank()) {



                // STT không nhận diện được chữ (tiếng thở, ồn nền hoặc nói quá khẽ):



                // Hiển thị hướng dẫn trên UI, TUYỆT ĐỐI không gọi TTS giọng nói làm phiền



                // và không đệ quy loop để triệt tiêu vĩnh viễn hiện tượng loop feedback gây giật lag bảng nổi!



                statusTitleView?.text = "🎙️ Chưa nhận diện được câu nói"



                transcriptTextView?.text = "👉 Chưa nghe rõ từ ngữ. Hãy chạm vào 'Chạm để nói' và nói lại..."



                micActionBtn?.text = "🎙️ Chạm để nói"



                waveVisualizerView?.setMode(listening = false, speaking = false)



                return@launch



            }







            consecutiveSilentTurns = 0



            transcriptTextView?.text = "🗣️ Bạn: \"$spokenText\""







            // 1. Nếu người dùng ra lệnh mở hẳn vào trong App Gemini gốc



            val lowerCmd = spokenText.lowercase(Locale.ROOT)



            if (lowerCmd.contains("mở app gemini") || lowerCmd.contains("mở ứng dụng gemini")) {



                openOfficialGeminiAppAndYieldMic(appCtx)



                return@launch



            }







            // 2. Kiểm tra & Thực thi ngay lập tức các lệnh điều khiển điện thoại (Mở App, Cuộn/Vuốt, Bấm nút, Đèn pin, Âm lượng...)



            statusTitleView?.text = "⚡ Đang xử lý yêu cầu..."



            val cmdResult = withContext(Dispatchers.IO) {



                GeminiVoiceActionExecutor.tryExecuteVoiceCommand(appCtx, spokenText)



            }







            if (!isActive || !isShowing) return@launch







            if (cmdResult.handled) {



                val confirmMsg = cmdResult.spokenConfirmation



                replyScrollView?.visibility = View.VISIBLE



                replyTextView?.text = "⚡ $confirmMsg"



                replyScrollView?.post {



                    replyScrollView?.fullScroll(View.FOCUS_UP)



                }







                statusTitleView?.text = "🔊 Gemini đã thực hiện lệnh của bạn"



                micActionBtn?.text = "🎙️ Chạm để nói ngay"



                waveVisualizerView?.setMode(listening = false, speaking = true)







                speakVietnameseResponse(appCtx, confirmMsg) {



                    if (cmdResult.shouldDismissOverlay) {



                        dismiss(appCtx)



                    } else if (isShowing) {



                        scheduleNextTurnOrStandby(appCtx)



                    }



                }



                return@launch



            }







            // 3. Trò chuyện AI thông minh (tự động trích xuất ngữ cảnh màn hình đang hiển thị để hiểu và đọc kết quả chính cho người dùng)



            statusTitleView?.text = "✨ Gemini đang trả lời bạn..."



            // Nếu vừa mở trang tìm kiếm Google / web bên ngoài, chờ nhẹ 800ms để trình duyệt tải xong thẻ thời tiết/kết quả



            if (spokenText.contains("thời tiết", ignoreCase = true) || spokenText.contains("thoi tiet", ignoreCase = true)) {



                kotlinx.coroutines.delay(850L)



            }



            val screenContext = if (!cmdResult.screenContextForAi.isNullOrBlank()) {



                cmdResult.screenContextForAi



            } else {



                try {



                    val nodes = MagicTuneCtsAccessibilityService.extractVisibleScreenNodesNow(appCtx)



                    if (nodes.isNotEmpty()) {



                        nodes.take(50).joinToString(" | ") { it.text }



                    } else null



                } catch (_: Throwable) { null }



            }







            // CHỈ gắn context màn hình khi người dùng thực sự hỏi về màn hình (tránh việc hỏi thời sự, trò chuyện bình thường lại đi đọc chữ trên màn hình)
            val promptForAi = if (!screenContext.isNullOrBlank() && isExplicitScreenQuestion(spokenText)) {

                "$spokenText\n[THÔNG TIN THAM KHẢO TỪ MÀN HÌNH ĐIỆN THOẠI: $screenContext]"

            } else {

                spokenText

            }







            val rawAiAnswer = withContext(Dispatchers.IO) {



                generateGeminiVoiceResponse(appCtx, promptForAi)



            }.trim()







            if (!isActive || !isShowing) return@launch







            val cleanAiAnswer = withContext(Dispatchers.IO) {



                GeminiVoiceActionExecutor.processAiActionTagsIfPresent(appCtx, rawAiAnswer)



            }







            replyScrollView?.visibility = View.VISIBLE



            replyTextView?.text = cleanAiAnswer



            replyScrollView?.post {



                replyScrollView?.fullScroll(View.FOCUS_UP)



            }







            statusTitleView?.text = "🔊 Gemini đang nói chuyện với bạn..."



            micActionBtn?.text = "🎙️ Chạm để ngắt lời & nói ngay"



            waveVisualizerView?.setMode(listening = false, speaking = true)







            // Phát giọng đọc Tiếng Việt tự nhiên ngay ngoài màn hình, sau đó TỰ ĐỘNG nghe tiếp câu sau!



            speakVietnameseResponse(appCtx, cleanAiAnswer) {



                if (isShowing) {



                    scheduleNextTurnOrStandby(appCtx)



                }



            }



        }



    }







    /**



     * Khi chưa phát hiện giọng nói trong 1 chu kỳ:



     * Nếu đang bật chế độ Đàm thoại liền mạch (`isContinuousConversationEnabled`),



     * tự động duy trì lắng nghe vô hạn chu kỳ để người dùng có thể nói câu tiếp bất kỳ lúc nào.



     */



    private fun handleSilentOrEmptyTurn(context: Context) {



        if (!isShowing) return



        pendingNextTurnRunnable?.let { mainHandler.removeCallbacks(it) }



        pendingNextTurnRunnable = null







        if (isContinuousConversationEnabled) {



            consecutiveSilentTurns++



            if (consecutiveSilentTurns >= 3) {



                // Sau 3 chu kỳ im lặng, chuyển về chế độ chờ để tiết kiệm pin và tránh spam CPU/mạng



                consecutiveSilentTurns = 0



                statusTitleView?.text = "✨ Gemini Live • Đang chờ bạn nói tiếp"



                transcriptTextView?.text = "👉 Chạm vào nút '🎙️ Chạm để nói' để tiếp tục trò chuyện"



                micActionBtn?.text = "🎙️ Chạm để nói"



                waveVisualizerView?.setMode(listening = false, speaking = false)



                return



            }







            statusTitleView?.text = "✨ Gemini Live • Vẫn đang mở Micro nghe bạn nói..."



            transcriptTextView?.text = "🎙️ Micro đang sẵn sàng, bạn cứ nói câu tiếp theo..."



            waveVisualizerView?.setMode(listening = true, speaking = false)



            



            val runnable = Runnable {



                pendingNextTurnRunnable = null



                if (isShowing && isContinuousConversationEnabled && !isRecordingMic) {



                    startNewVoiceConversationTurn(context)



                }



            }



            pendingNextTurnRunnable = runnable



            mainHandler.postDelayed(runnable, 600L)



            return



        }







        consecutiveSilentTurns = 0



        statusTitleView?.text = "✨ Gemini Live • Đang chờ bạn nói tiếp"



        transcriptTextView?.text = "👉 Chạm vào nút '🎙️ Nói tiếp' hoặc chạm vào sóng âm để tiếp tục trò chuyện"



        micActionBtn?.text = "🎙️ Chạm để nói tiếp"



        waveVisualizerView?.setMode(listening = false, speaking = false)



    }







    /**



     * Ngay sau khi Gemini đọc xong câu trả lời:



     * Nếu chế độ Liên tục đang BẬT -> Tự động chuyển sang lắng nghe câu tiếp theo của người dùng sau 180ms



     * trong khi luồng AudioRecord phần cứng vẫn đang được giữ mở xuyên suốt.



     */



    private fun scheduleNextTurnOrStandby(context: Context) {



        pendingNextTurnRunnable?.let { mainHandler.removeCallbacks(it) }



        pendingNextTurnRunnable = null







        mainHandler.post {



            if (!isShowing) return@post



            if (isContinuousConversationEnabled) {



                statusTitleView?.text = "✨ Gemini Live • Đang mở Micro nghe bạn nói câu tiếp..."



                transcriptTextView?.text = "🎙️ Đã sẵn sàng nghe câu tiếp theo của bạn..."



                micActionBtn?.text = "🎙️ Đang nghe tiếp... (Chạm để gửi)"



                waveVisualizerView?.setMode(listening = true, speaking = false)



                triggerGentleHaptic(context)







                val runnable = Runnable {



                    pendingNextTurnRunnable = null



                    if (isShowing && isContinuousConversationEnabled && !isRecordingMic) {



                        startNewVoiceConversationTurn(context)



                    }



                }



                pendingNextTurnRunnable = runnable



                mainHandler.postDelayed(runnable, 800L)



            } else {



                statusTitleView?.text = "✨ Gemini Live • Đã trả lời xong"



                micActionBtn?.text = "🎙️ Chạm để nói câu tiếp theo"



                waveVisualizerView?.setMode(listening = false, speaking = false)



            }



        }



    }







    /**



     * Khởi tạo hoặc tái sử dụng phiên `AudioRecord` phần cứng xuyên suốt toàn bộ cuộc hội thoại.



     * TUYỆT ĐỐI KHÔNG đóng/release `AudioRecord` sau câu 1 để ngăn chặn Android 14/15/16 & Honor MagicOS



     * thu hồi quyền Micro khi ứng dụng đang hiển thị dưới dạng hộp thoại nổi (`TYPE_APPLICATION_OVERLAY`).



     */



    @SuppressLint("MissingPermission")



    private fun getOrCreatePersistentAudioRecord(



        context: Context,



        forceRecreate: Boolean = false



    ): AudioRecord? {



        synchronized(audioRecordLock) {



            val existing = audioRecord



            if (!forceRecreate && existing != null && existing.state == AudioRecord.STATE_INITIALIZED) {



                try {



                    if (existing.recordingState != AudioRecord.RECORDSTATE_RECORDING) {



                        existing.startRecording()



                    }



                    if (existing.recordingState == AudioRecord.RECORDSTATE_RECORDING) {



                        return existing



                    }



                } catch (_: Throwable) {}



            }







            if (existing != null) {



                try {



                    existing.stop()



                } catch (_: Throwable) {}



                try {



                    existing.release()



                } catch (_: Throwable) {}



                audioRecord = null



            }







            try {



                val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager



                am?.mode = AudioManager.MODE_NORMAL



            } catch (_: Throwable) {}







            val sampleRate = 16000



            val channelConfig = AudioFormat.CHANNEL_IN_MONO



            val audioFormat = AudioFormat.ENCODING_PCM_16BIT



            val minBufSize = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat)



            if (minBufSize <= 0) return null



            val bufferSize = max(minBufSize * 2, 3200)







            // Ưu tiên VOICE_RECOGNITION chuẩn của Android chuyên dùng cho Speech-to-Text / AI Assistant



            val audioSources = listOf(



                MediaRecorder.AudioSource.VOICE_RECOGNITION,



                MediaRecorder.AudioSource.MIC,



                MediaRecorder.AudioSource.DEFAULT



            )







            for (attempt in 0..1) {



                for (source in audioSources) {



                    try {



                        val rec = AudioRecord(source, sampleRate, channelConfig, audioFormat, bufferSize)



                        if (rec.state == AudioRecord.STATE_INITIALIZED) {



                            rec.startRecording()



                            if (rec.recordingState == AudioRecord.RECORDSTATE_RECORDING) {



                                audioRecord = rec



                                attachAudioHardwareEffects(rec.audioSessionId)



                                return rec



                            } else {



                                rec.release()



                            }



                        } else {



                            rec.release()



                        }



                    } catch (_: Throwable) {}



                }



                try {



                    Thread.sleep(10L)



                } catch (_: Throwable) {}



            }



            return null



        }



    }







    /**



     * Trong lúc Gemini đang xử lý văn bản hoặc đang phát tiếng nói trả lời (TTS),



     * duy trì đọc xả nhẹ (`drain`) bộ đệm của `AudioRecord` mỗi 35ms.



     * Nhờ đó:



     * 1. Hệ điều hành thấy kênh Micro vẫn đang hoạt động liên tục không ngắt quãng -> Không bao giờ thu hồi quyền Micro!



     * 2. Xả sạch âm vọng từ loa ngoài khi Gemini đang đọc câu trả lời -> Khi vừa đọc xong câu 1, bộ đệm sạch 100% để nghe câu 2 ngay tức khắc!



     */



    private fun startMicKeepAliveDrainBetweenTurns() {



        micKeepAliveDrainJob?.cancel()



        if (!isShowing) return



        micKeepAliveDrainJob = overlayScope.launch(Dispatchers.IO) {



            val drainBuf = ShortArray(512)



            while (isActive && isShowing && !isRecordingMic) {



                val rec = synchronized(audioRecordLock) { audioRecord }



                if (rec != null && rec.state == AudioRecord.STATE_INITIALIZED) {



                    try {



                        if (rec.recordingState != AudioRecord.RECORDSTATE_RECORDING) {



                            rec.startRecording()



                        }



                        rec.read(drainBuf, 0, drainBuf.size)



                    } catch (_: Throwable) {}



                } else {



                    delay(40L)



                }



                delay(20L)



            }



        }



    }







    /**



     * Thu âm trực tiếp từ Micro phần cứng (16kHz Mono PCM) kèm thuật toán VAD (Voice Activity Detection):



     * - Giữ nguyên phiên `AudioRecord` xuyên suốt các lượt hội thoại để không bao giờ bị HĐH thu hồi Micro ở câu 2, câu 3...



     * - Tự động phát hiện nếu luồng Micro bị HĐH làm câm (`rms < 0.05` liên tiếp) và tự động kích hoạt khôi phục quyền Micro tức thì.



     * - Sử dụng bộ đệm Pre-Roll (~600ms trước khi phát hiện giọng nói) để không mất chữ đầu tiên và không gửi khoảng im lặng rỗng.



     */



    @SuppressLint("MissingPermission")



    private fun recordVoiceWithAutoVad(context: Context): ByteArray? {



        val appCtx = context.applicationContext



        micKeepAliveDrainJob?.cancel()



        micKeepAliveDrainJob = null







        val sampleRate = 16000



        var recorder = getOrCreatePersistentAudioRecord(appCtx, forceRecreate = false)



        if (recorder == null) {



            // Nếu chưa mở được AudioRecord do app đang ở nền -> Kích hoạt xung Foreground 120ms để lấy quyền Micro



            requestSilentForegroundMicPulseIfNeeded(appCtx)



            try {



                Thread.sleep(20L)



            } catch (_: Throwable) {}



            recorder = getOrCreatePersistentAudioRecord(appCtx, forceRecreate = true)



        }



        if (recorder == null) return null







        isRecordingMic = true



        forceFinishRecordingNow = false







        val pcmOut = ByteArrayOutputStream()



        val preRollQueue = ArrayDeque<ByteArray>()



        val readBuffer = ShortArray(1024)



        var startTime = System.currentTimeMillis()



        var hasDetectedSpeech = false



        var firstSpeechTimestamp = 0L



        var lastSpeechTimestamp = startTime



        var speechFramesCount = 0



        var consecutiveErrorFrames = 0



        var consecutiveDeadZeroFrames = 0



        var ambientNoiseRms = 18.0



        var warmupFramesToFlush = 2 // Xả 2 frame đầu (~120ms) để loại bỏ dư âm loa ngoài sau khi TTS vừa dứt







        try {



            while (isRecordingMic && !forceFinishRecordingNow && isShowing) {



                val activeRec = recorder ?: break



                if (activeRec.recordingState != AudioRecord.RECORDSTATE_RECORDING) {



                    try {



                        activeRec.startRecording()



                    } catch (_: Throwable) {}



                }







                val now = System.currentTimeMillis()



                val elapsed = now - startTime



                if (elapsed > 18_000L) break



                // Sau 4.5 giây nếu người dùng chưa mở lời thì mới chuyển lượt, đảm bảo đủ thời gian cho người dùng ở xa ~2m chuẩn bị câu nói



                if (!hasDetectedSpeech && elapsed > 4_500L) break







                val readCount = activeRec.read(readBuffer, 0, readBuffer.size)



                if (readCount > 0) {



                    if (warmupFramesToFlush > 0) {



                        warmupFramesToFlush--



                        continue



                    }







                    consecutiveErrorFrames = 0



                    var sumSq = 0.0



                    var maxAbsSample = 0







                    // Ghi nhận mẫu âm thanh nguyên bản (Clean Natural PCM), bảo toàn 100% âm sắc tiếng Việt



                    val byteBuf = ByteBuffer.allocate(readCount * 2).order(ByteOrder.LITTLE_ENDIAN)



                    for (i in 0 until readCount) {



                        val sample = readBuffer[i]



                        byteBuf.putShort(sample)



                        val absVal = abs(sample.toInt())



                        if (absVal > maxAbsSample) maxAbsSample = absVal



                        sumSq += (sample.toDouble() * sample.toDouble())



                    }







                    val rms = sqrt(sumSq / readCount)







                    // Phát hiện trường hợp HĐH Android / MagicOS khóa ngầm luồng Micro (trả về toàn mẫu 0 tuyệt đối)



                    if (maxAbsSample == 0 || rms < 0.02) {



                        consecutiveDeadZeroFrames++



                        if (consecutiveDeadZeroFrames >= 10) {



                            consecutiveDeadZeroFrames = 0



                            requestSilentForegroundMicPulseIfNeeded(appCtx)



                            try {



                                Thread.sleep(20L)



                            } catch (_: Throwable) {}



                            val recovered = getOrCreatePersistentAudioRecord(appCtx, forceRecreate = true)



                            if (recovered != null) {



                                recorder = recovered



                                startTime = System.currentTimeMillis()



                            }



                            continue



                        }



                    } else {



                        consecutiveDeadZeroFrames = 0



                    }







                    val normalizedAmp = (rms / 3500.0).toFloat().coerceIn(0.06f, 1.0f)



                    currentVoiceAmplitude = normalizedAmp







                    val frameBytes = byteBuf.array()

                    if (!hasDetectedSpeech) {
                        // 1. Giai đoạn lắng nghe câu mở đầu:
                        // Liên tục học mức tạp âm nền phòng (quạt gió, máy lạnh, tiếng ồn tĩnh)
                        if (rms < 35.0 && maxAbsSample < 180) {
                            ambientNoiseRms = (ambientNoiseRms * 0.85) + (rms * 0.15)
                        }

                        // Ngưỡng bắt đầu nói: Nhạy vừa đủ để bắt trọn từ đầu tiên, không bị kích hoạt bởi tiếng thở
                        val startSpeechThresholdRms = (ambientNoiseRms * 1.55).coerceIn(22.0, 40.0)
                        val isStartCandidate = (rms > startSpeechThresholdRms && maxAbsSample > 95) ||
                                (rms > 32.0 && maxAbsSample > 150)

                        if (isStartCandidate) {
                            speechFramesCount++
                            if (speechFramesCount >= 2) {
                                hasDetectedSpeech = true
                                firstSpeechTimestamp = now
                                lastSpeechTimestamp = now
                                // Đổ bộ đệm Pre-Roll (~450ms) để bảo toàn 100% từ đầu tiên của câu hỏi
                                while (preRollQueue.isNotEmpty()) {
                                    pcmOut.write(preRollQueue.removeFirst())
                                }
                            }
                        } else {
                            speechFramesCount = (speechFramesCount - 1).coerceAtLeast(0)
                        }

                        preRollQueue.addLast(frameBytes)
                        while (preRollQueue.size > 7) {
                            preRollQueue.removeFirst()
                        }
                    } else {
                        // 2. Giai đoạn người dùng đang nói:
                        pcmOut.write(frameBytes)

                        // Phân biệt chính xác giữa giọng nói thực tế và tiếng thở nhẹ / tiếng ồn sau khi dứt câu:
                        val ongoingSpeechThresholdRms = (ambientNoiseRms * 1.65).coerceIn(28.0, 48.0)
                        val isOngoingSpeech = (rms > ongoingSpeechThresholdRms && maxAbsSample > 140) ||
                                (rms > 42.0 && maxAbsSample > 200)

                        if (isOngoingSpeech) {
                            lastSpeechTimestamp = now
                        }

                        val silenceAfterSpeechMs = now - lastSpeechTimestamp
                        val totalSpeechWindowMs = now - firstSpeechTimestamp

                        // Tự động ngắt câu thông minh & dứt khoát:
                        // - Câu bình thường (> 450ms): Chỉ cần dứt lời im lặng 580ms là ngắt ngay lập tức!
                        // - Câu dài (> 1200ms): Người dùng đã nói xong trọn vẹn, chỉ cần 520ms im lặng là chốt và gửi xử lý!
                        val requiredSilenceMs = if (totalSpeechWindowMs > 1200L) 520L else 580L

                        if (totalSpeechWindowMs >= 400L && silenceAfterSpeechMs >= requiredSilenceMs) {
                            break
                        }
                    }



                } else {



                    consecutiveErrorFrames++



                    if (consecutiveErrorFrames > 15) {



                        val recovered = getOrCreatePersistentAudioRecord(appCtx, forceRecreate = true)



                        if (recovered != null) {



                            recorder = recovered



                            consecutiveErrorFrames = 0



                        } else {



                            break



                        }



                    }



                    Thread.sleep(10)



                }



            }



        } catch (_: Throwable) {



        } finally {



            isRecordingMic = false



            currentVoiceAmplitude = 0.08f



            // QUAN TRỌNG: Giữ nguyên AudioRecord mở và kích hoạt luồng drain ngầm trong lúc Gemini xử lý & trả lời



            if (isShowing) {



                startMicKeepAliveDrainBetweenTurns()



            }



        }







        // Nếu người dùng bấm nút "Gửi ngay" khi chưa vượt ngưỡng VAD thì lấy luôn phần preRollQueue



        if (!hasDetectedSpeech && forceFinishRecordingNow) {



            while (preRollQueue.isNotEmpty()) {



                pcmOut.write(preRollQueue.removeFirst())



            }



        } else if (!hasDetectedSpeech) {



            return null



        }







        val rawPcm = pcmOut.toByteArray()



        if (rawPcm.size < 1600) return null



        return wrapPcmInWavHeader(rawPcm, sampleRate, 1, 16)



    }







    private fun requestSilentForegroundMicPulseIfNeeded(context: Context) {



        val appCtx = context.applicationContext



        com.example.core.service.MagicTuneKeepAliveService.ensureMicrophoneForeground(appCtx)



        SystemFloatingHudOverlay.releaseMicrophoneForGeminiImmediately(appCtx)







        val now = System.currentTimeMillis()



        if (now - lastMicReacquirePulseMs > 3500L) {



            lastMicReacquirePulseMs = now



            mainHandler.post {



                if (isShowing) {



                    GeminiVoiceLockscreenActivity.launchFromOverlay(appCtx, reacquireMicOnly = true)



                }



            }



        }



    }







    /**



     * Chỉ tạm dừng vòng lặp thu của câu hiện tại, GIỮ NGUYÊN phiên `AudioRecord` phần cứng



     * để câu thứ 2, thứ 3... luôn thu âm được ngay mà không bị HĐH thu hồi quyền Micro.



     */



    private fun pauseCurrentTurnCaptureOnly() {



        isRecordingMic = false



        forceFinishRecordingNow = true



        micKeepAliveDrainJob?.cancel()



        micKeepAliveDrainJob = null



    }







    /**



     * Đóng và giải phóng hoàn toàn `AudioRecord` phần cứng (chỉ gọi khi đóng hẳn hộp thoại Gemini Nổi



     * hoặc khi nhường Micro sang cho ứng dụng Gemini chính thức).



     */



    private fun attachAudioHardwareEffects(sessionId: Int) {



        releaseAudioHardwareEffects()



        // Trên ROM MagicOS/EMUI nội địa, không kích hoạt chồng chéo NoiseSuppressor phần mềm



        // để tránh xung đột với bộ lọc ồn AI DSP của chip làm dập tắt giọng nói về 0.



        // Chỉ kích hoạt AGC (AutomaticGainControl) để khuếch đại giọng nói nếu người dùng nói nhỏ.



        try {



            if (AutomaticGainControl.isAvailable()) {



                automaticGainControl = AutomaticGainControl.create(sessionId)?.apply {



                    enabled = true



                }



            }



        } catch (_: Throwable) {}



    }







    private fun releaseAudioHardwareEffects() {



        try {



            noiseSuppressor?.release()



        } catch (_: Throwable) {}



        noiseSuppressor = null



        try {



            acousticEchoCanceler?.release()



        } catch (_: Throwable) {}



        acousticEchoCanceler = null



        try {



            automaticGainControl?.release()



        } catch (_: Throwable) {}



        automaticGainControl = null



    }







    private fun releaseHardwareMicrophoneCompletely() {



        isRecordingMic = false



        forceFinishRecordingNow = true



        micKeepAliveDrainJob?.cancel()



        micKeepAliveDrainJob = null



        releaseAudioHardwareEffects()



        synchronized(audioRecordLock) {



            val rec = audioRecord



            audioRecord = null



            if (rec != null) {



                try {



                    rec.stop()



                } catch (_: Throwable) {}



                try {



                    rec.release()



                } catch (_: Throwable) {}



            }



        }



    }







    private fun wrapPcmInWavHeader(



        pcmData: ByteArray,



        sampleRate: Int,



        channels: Int,



        bitsPerSample: Int



    ): ByteArray {



        val byteRate = sampleRate * channels * bitsPerSample / 8



        val totalDataLen = pcmData.size + 36



        val out = ByteArrayOutputStream(pcmData.size + 44)



        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)



        header.put("RIFF".toByteArray(Charsets.US_ASCII))



        header.putInt(totalDataLen)



        header.put("WAVE".toByteArray(Charsets.US_ASCII))



        header.put("fmt ".toByteArray(Charsets.US_ASCII))



        header.putInt(16) // Subchunk1Size for PCM



        header.putShort(1) // AudioFormat = 1 (PCM)



        header.putShort(channels.toShort())



        header.putInt(sampleRate)



        header.putInt(byteRate)



        header.putShort((channels * bitsPerSample / 8).toShort())



        header.putShort(bitsPerSample.toShort())



        header.put("data".toByteArray(Charsets.US_ASCII))



        header.putInt(pcmData.size)



        out.write(header.array())



        out.write(pcmData)



        return out.toByteArray()



    }







    /**



     * Chuyển đổi âm thanh WAV vừa thu từ Micro sang văn bản Tiếng Việt siêu tốc (~300ms)



     * qua Whisper Large V3 Turbo (Hoạt động trên 100% máy Honor MagicOS 11 không cần Google Speech Services).



     */



    private fun transcribeAudioBytesToVietnamese(context: Context, wavBytes: ByteArray): String {



        val apiKey = LicenseManager.getLoadBalancedGroqApiKey(context).ifBlank {



            try {



                com.example.BuildConfig.GROQ_API_KEY



            } catch (_: Throwable) {



                ""



            }



        }



        if (apiKey.isBlank() || apiKey == "GROQ_API_KEY_DEFAULT_VALUE") {



            return ""



        }







        val models = listOf("whisper-large-v3-turbo", "whisper-large-v3")



        for (modelName in models) {



            try {



                val boundary = "----MagicTuneVoiceBoundary${System.currentTimeMillis()}"



                val url = URL("https://api.groq.com/openai/v1/audio/transcriptions")



                val conn = (url.openConnection() as HttpURLConnection).apply {



                    requestMethod = "POST"



                    doOutput = true



                    doInput = true



                    connectTimeout = 4000



                    readTimeout = 7000



                    setRequestProperty("Authorization", "Bearer $apiKey")



                    setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")



                    setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 15; MagicTune) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36")



                }







                DataOutputStream(conn.outputStream).use { dos ->



                    // 1. File part



                    dos.writeBytes("--$boundary\r\n")



                    dos.writeBytes("Content-Disposition: form-data; name=\"file\"; filename=\"voice.wav\"\r\n")



                    dos.writeBytes("Content-Type: audio/wav\r\n\r\n")



                    dos.write(wavBytes)



                    dos.writeBytes("\r\n")







                    // 2. Model part



                    dos.writeBytes("--$boundary\r\n")



                    dos.writeBytes("Content-Disposition: form-data; name=\"model\"\r\n\r\n")



                    dos.writeBytes("$modelName\r\n")







                    // 3. Language part (Ép cố định Tiếng Việt chuẩn xác)



                    dos.writeBytes("--$boundary\r\n")



                    dos.writeBytes("Content-Disposition: form-data; name=\"language\"\r\n\r\n")



                    dos.writeBytes("vi\r\n")







                    // 3.1 Temperature: 0.0 để nhận diện chính xác nhất



                    dos.writeBytes("--$boundary\r\n")



                    dos.writeBytes("Content-Disposition: form-data; name=\"temperature\"\r\n\r\n")



                    dos.writeBytes("0.0\r\n")







                    // 3.2 Prompt mồi ngữ cảnh đa vùng miền, phát âm địa phương, nói ngọng l/n, giọng trầm khàn



                    val sttGuidePrompt = "Đây là hội thoại tiếng Việt tự nhiên của người Việt 3 miền Bắc, Trung, Nam; bao gồm giọng địa phương Nghệ An, Hà Tĩnh, Huế, Quảng Nam, miền Tây, nói ngọng L/N, dấu hỏi ngã, giọng nam trầm ồm hoặc nói nhanh. Các từ khóa: YouTube, Google, Zalo, Facebook, TikTok, thời tiết, mở nhạc, bật đèn pin, bản đồ, MagicTune."



                    dos.writeBytes("--$boundary\r\n")



                    dos.writeBytes("Content-Disposition: form-data; name=\"prompt\"\r\n\r\n")



                    dos.write(sttGuidePrompt.toByteArray(Charsets.UTF_8))



                    dos.writeBytes("\r\n")







                    // 4. Response format



                    dos.writeBytes("--$boundary\r\n")



                    dos.writeBytes("Content-Disposition: form-data; name=\"response_format\"\r\n\r\n")



                    dos.writeBytes("json\r\n")







                    dos.writeBytes("--$boundary--\r\n")



                    dos.flush()



                }







                if (conn.responseCode in 200..299) {



                    val respStr = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }



                    val json = JSONObject(respStr)



                    val text = json.optString("text", "").trim()



                    // Lọc bỏ các phụ đề ảo khi im lặng của Whisper



                    val ignoredHallucinations = listOf(



                        "hãy subscribe", "đăng ký kênh", "cảm ơn các bạn đã theo dõi",



                        "thank you for watching", "subtitles by", "amara.org",



                        "hẹn gặp lại trong những video tiếp theo",



                        "hẹn gặp lại trong các video tiếp theo",



                        "hẹn gặp lại các bạn trong video tiếp theo",



                        "hẹn gặp lại các bạn trong những video tiếp theo",



                        "hẹn gặp lại các bạn ở những video tiếp theo",



                        "hẹn gặp lại ở video tiếp theo",



                        "hẹn gặp lại trong video sau",



                        "hẹn gặp lại các bạn",



                        "hẹn gặp lại",



                        "chúc các bạn xem video vui vẻ"



                    )



                    if (text.isNotEmpty() && ignoredHallucinations.none { text.lowercase(Locale.ROOT).contains(it) }) {



                        return text



                    }



                }



            } catch (_: Throwable) {}



        }



        return ""



    }







    /**



     * Sinh câu trả lời thông minh cho cuộc hội thoại giọng nói nổi trên màn hình.



     */



    private fun generateGeminiVoiceResponse(context: Context, userQuery: String): String {
        val deviceContextInfo = GeminiVoiceActionExecutor.buildDeviceContextForAi(context)
        val commercialName = GeminiVoiceActionExecutor.getCommercialDeviceName(context)

        val imageContextInfo = buildString {
            if (!attachedImageOcrSummary.isNullOrBlank()) {
                append(" [HÌNH ẢNH MÀN HÌNH ĐÃ KHOANH: Người dùng vừa khoanh tròn một vùng trên màn hình chứa chữ/nội dung: \"$attachedImageOcrSummary\"]")
            } else if (attachedImageBase64 != null) {
                append(" [HÌNH ẢNH ĐÍNH KÈM: Người dùng vừa đính kèm một bức ảnh (\"${attachedImageDisplayName ?: "ảnh chụp"}\") để yêu cầu bạn giải đáp, dịch thuật hoặc phân tích]")
            }
            if (!attachedDocumentText.isNullOrBlank()) {
                append(" [TÀI LIỆU ĐÍNH KÈM (\"${attachedDocumentName ?: "tài liệu"}\"): \"$attachedDocumentText\"]")
            }
        }

        val userName = GeminiVoiceActionExecutor.getUserDisplayName(context)
        val systemPrompt =
            "Bạn là trợ lý AI Gemini tiếng Việt toàn năng, thấu hiểu sâu sắc tiếng Việt 3 miền Bắc - Trung - Nam, kể cả khi người dùng nói ngọng (L/N, hỏi/ngã, tr/ch, s/x, gi/d/v), giọng địa phương (miền Trung Nghệ Tĩnh, Huế, Quảng Nam, miền Tây Nam Bộ), giọng nói nhanh, nói tắt, giọng khàn hoặc rất trầm ồm. Hãy luôn suy luận ngữ cảnh chuẩn xác để hiểu trọn vẹn ý định người dùng tên là \"$userName\" trên điện thoại $commercialName và phản hồi đúng trọng tâm. " +
                "Người dùng đang hỏi bạn tên là: $userName. Khi người dùng hỏi 'tôi là ai', 'tên tôi là gì', hãy xưng hô và gọi đúng tên $userName của họ một cách thân thiết và tự nhiên. " +
                deviceContextInfo + " " +
                "BẠN CÓ TRÍ NHỚ TOÀN DIỆN VỀ LỊCH SỬ CUỘC TRÒ CHUYỆN HIỆN TẠI: Toàn bộ các câu hỏi của người dùng và câu trả lời trước đó của bạn từ đầu cuộc trò chuyện đều được ghi nhớ đầy đủ trong danh sách nội dung gửi kèm. Khi người dùng hỏi về các câu trước ('câu trước tôi hỏi gì', 'vừa nãy bạn nói gì', 'tôi vừa bảo bạn làm gì', 'tóm tắt những gì chúng ta đã nói từ nãy đến giờ', 'câu đầu tiên tôi hỏi là gì'...), bạn hãy xem lại chính xác các lượt hỏi - đáp phía trên để trả lời cụ thể, chính xác, trung thực. " +
                "Bạn am hiểu sâu sắc về thông số của chiếc máy này và cẩm nang sử dụng MagicOS / Android: " +
                "cách mở cửa sổ nổi mini-window (vuốt giữ từ mép màn hình vào trong để mở Sidebar rồi bấm app), " +
                "cách khoanh tròn tìm kiếm (nhấn giữ thanh điều hướng hoặc vuốt từ góc dưới bên trái), " +
                "cách gọi Gemini (nói 'Ok Google', 'Hey Google', 'Gemini' sau khi mở khóa hoặc vuốt từ góc dưới bên phải), " +
                "cách dịch màn hình tức thì, cách chia đôi màn hình, tối ưu pin chạy ngầm. " +
                "ĐẶC BIỆT KHI NGƯỜI DÙNG HỎI VỀ TÍNH NĂNG MIỄN PHÍ HOẶC CHƯA LÊN PRO: Bạn hãy nhiệt tình giới thiệu các tính năng hoàn toàn MIỄN PHÍ MÃI MÃI của MagicTune: " +
                "(1) Google Khoanh tròn tìm kiếm Circle to Search nhấn giữ thanh đáy thay thế YOYO tiếng Trung; " +
                "(2) Dịch cuộn màn hình xuyên thấu và tự đổi giá sang tiền Việt khi mua hàng Taobao, 1688; " +
                "(3) Dùng Gemini Live miễn phí bằng cách tự dán API Key cá nhân từ aistudio.google.com mà không cần lên Pro; " +
                "(4) Quét chẩn đoán lỗi thông báo và lỗi pin chạy ngầm; " +
                "(5) Mở cập nhật hệ thống OUC/HOTA cho máy xách tay; " +
                "(6) Toàn bộ Widget Pin đo W sạc, RAM, ROM trên màn hình chính! " +
                "Khi người dùng hỏi về thông tin chiếc máy đang dùng (máy là máy gì, cấu hình, vi xử lý, pin còn bao nhiêu %, đang sạc công suất bao nhiêu W, pin có nóng không, RAM còn trống bao nhiêu GB, bộ nhớ trong còn bao nhiêu GB, màn hình bao nhiêu Hz), hãy trả lời chính xác, nhiệt tình dựa trên các thông số phần cứng thực tế ở trên! " +
                imageContextInfo + " " +
                "Hãy trả lời hoàn toàn bằng Tiếng Việt tự nhiên, thân thiện, ngắn gọn và súc tích (tối đa 2-4 câu) để đọc thành tiếng mượt mà nhất. Không dùng ký hiệu markdown phức tạp như **, ## hay bảng biểu. " +
                "QUAN TRỌNG VỀ PHÂN BIỆT Ý ĐỊNH VÀ ĐIỀU KHIỂN HỆ THỐNG: " +
                "1. PHÂN BIỆT RÕ RÀNG MỞ APP VỚI NỘI DUNG GIẢI TRÍ / PHIM / NHẠC / TRA CỨU: " +
                "- Khi người dùng bảo mở hoặc xem phim ('mở phim Doraemon', 'xem phim Bố Già', 'chiếu phim Tây Du Ký'...), mở hoặc nghe bài hát ('phát bài Lạc Trôi', 'mở bài hát Đen Vâu', 'bật nhạc remix'...), xem video hoặc clip ('mở video review xe', 'xem clip hài'...): ĐÂY LÀ YÊU CẦU NỘI DUNG GIẢI TRÍ, TUYỆT ĐỐI KHÔNG ĐƯỢC COI LÀ TÊN ỨNG DỤNG! Hãy dùng thẻ [YOUTUBE_SEARCH:Tên phim/bài hát/video/clip] để mở trực tiếp trên YouTube! " +
                "- Khi người dùng hỏi cách làm, hướng dẫn, tra cứu thông tin ('cách làm bánh', 'hướng dẫn cài đặt', 'giá vàng hôm nay', 'thời tiết'): Hãy trả lời giải thích tự nhiên hoặc dùng thẻ [GOOGLE_SEARCH:Từ khóa tra cứu], KHÔNG ĐƯỢC tìm mở ứng dụng! " +
                "- CHỈ DÙNG [OPEN_APP:Tên ứng dụng] khi người dùng thực sự muốn mở một ứng dụng phần mềm cụ thể đã cài trên máy (như Zalo, Facebook, TikTok, Shopee, Cài đặt, Bản đồ, Máy tính, Máy ảnh, v.v.). " +
                "2. THAO TÁC TRÊN MÀN HÌNH: Bạn là trợ lý rảnh tay 100%: Bạn CÓ THỂ tự động bấm chạm vào màn hình hộ người dùng! Khi người dùng bảo bấm vào nút nào trên màn hình, hãy gắn thẻ [CLICK_TEXT:Chữ trên màn hình]. Tuyệt đối KHÔNG ĐƯỢC từ chối! " +
                "3. ĐỌC KẾT QUẢ ĐÚNG VỊ TRÍ: Khi tra cứu thông tin thời tiết hoặc kết quả Google, hãy đọc đúng địa danh và nhiệt độ thực tế đang hiện trên màn hình. " +
                "4. NGUYÊN TẮC AN TOÀN BẢO MẬT: Bạn CÓ THỂ mở Cài đặt và bật/tắt mọi mục cài đặt hộ người dùng (như Bluetooth, âm thanh, độ sáng, tiết kiệm pin, dọn RAM...), TRỪ tắt Wi-Fi, tắt 4G/5G hoặc tắt/xóa MagicTune. " +
                "Nếu người dùng yêu cầu thực hiện thao tác trên điện thoại, hãy trả lời xác nhận ngắn gọn kèm đúng 1 thẻ lệnh ở cuối câu theo cú pháp: " +
                "[OPEN_APP:Tên ứng dụng] để mở app, [YOUTUBE_SEARCH:Từ khóa] để tìm/mở phim, nhạc, video trên YouTube, [GOOGLE_SEARCH:Từ khóa] để tìm Google, " +
                "[MAPS_SEARCH:Địa điểm] để chỉ đường, [CLICK_TEXT:Chữ trên màn hình] để bấm nút trên màn hình, " +
                "[SCROLL:DOWN] hoặc [SCROLL:UP] để cuộn màn hình, [GLOBAL:BACK] để quay lại, [GLOBAL:HOME] để về màn hình chính, " +
                "[OPTIMIZE_RAM] để dọn dẹp RAM tăng tốc máy, [POWER_SAVER:ON] hoặc [POWER_SAVER:OFF] để bật/tắt tiết kiệm pin, " +
                "[TORCH:ON] hoặc [TORCH:OFF] để bật/tắt đèn pin, [VOLUME:UP] hoặc [VOLUME:DOWN] để chỉnh âm lượng, [BLUETOOTH:ON] hoặc [BLUETOOTH:OFF] để bật/tắt Bluetooth trong cài đặt, [WIFI:ON] hoặc [WIFI:OFF] để bật/tắt Wi-Fi."







        // 1. ƯU TIÊN HÀNG ĐẦU: Google Gemini API (Gemini 2.5 Flash / Flash Lite) với Pool cân bằng tải đa Key + BYOK



        val geminiKey = LicenseManager.getLoadBalancedGeminiApiKey(context)



        if (geminiKey.isNotBlank()) {



            val geminiModels = listOf("gemini-2.0-flash", "gemini-1.5-flash", "gemini-2.5-flash", "gemini-2.0-flash-lite", "gemini-1.5-flash-8b")



            for (gModel in geminiModels) {



                try {



                    val geminiUrl = URL("https://generativelanguage.googleapis.com/v1beta/models/$gModel:generateContent?key=$geminiKey")



                    val conn = (geminiUrl.openConnection() as HttpURLConnection).apply {



                        requestMethod = "POST"



                        doOutput = true



                        doInput = true



                        connectTimeout = 3000



                        readTimeout = 4500



                        setRequestProperty("Content-Type", "application/json; charset=UTF-8")



                    }







                    val contentsArr = JSONArray()

                    // 1. Thêm toàn bộ lịch sử các lượt đối thoại trước đó trong cuộc trò chuyện (Multi-turn Chat History)
                    synchronized(conversationHistory) {
                        for ((role, histText) in conversationHistory.takeLast(60)) {
                            if (histText.isNotBlank()) {
                                val geminiRole = if (role == "assistant" || role == "model") "model" else "user"
                                contentsArr.put(JSONObject().apply {
                                    put("role", geminiRole)
                                    put("parts", JSONArray().apply {
                                        put(JSONObject().apply {
                                            put("text", histText)
                                        })
                                    })
                                })
                            }
                        }
                    }



                    val userPartsArr = JSONArray()







                    // Gửi kèm ảnh nếu người dùng vừa khoanh tròn màn hình



                    if (attachedImageBase64 != null) {



                        userPartsArr.put(JSONObject().apply {



                            put("inline_data", JSONObject().apply {



                                put("mime_type", "image/jpeg")



                                put("data", attachedImageBase64)



                            })



                        })



                    }







                    val queryText = if (!attachedImageOcrSummary.isNullOrBlank()) {
                    "$userQuery\n[Dữ liệu chữ trên màn hình vừa khoanh: $attachedImageOcrSummary]"
                } else if (!attachedDocumentText.isNullOrBlank()) {
                    "$userQuery\n[Dữ liệu tài liệu đính kèm ($attachedDocumentName):\n$attachedDocumentText]"
                } else {
                    userQuery
                }



                    userPartsArr.put(JSONObject().apply {



                        put("text", queryText)



                    })







                    contentsArr.put(JSONObject().apply {



                        put("role", "user")



                        put("parts", userPartsArr)



                    })







                    val geminiPayload = JSONObject().apply {



                        put("contents", contentsArr)



                        put("system_instruction", JSONObject().apply {



                            put("parts", JSONArray().put(JSONObject().put("text", systemPrompt)))



                        })



                        put("generationConfig", JSONObject().apply {



                            put("temperature", 0.3)



                            put("maxOutputTokens", 500)



                        })



                    }







                    conn.outputStream.use { os ->



                        os.write(geminiPayload.toString().toByteArray(Charsets.UTF_8))



                    }







                    if (conn.responseCode in 200..299) {



                        val body = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }



                        val json = JSONObject(body)



                        val text = json.optJSONArray("candidates")



                            ?.optJSONObject(0)



                            ?.optJSONObject("content")



                            ?.optJSONArray("parts")



                            ?.optJSONObject(0)



                            ?.optString("text", "")



                            .orEmpty()



                            .replace(Regex("<think>[\\s\\S]*?</think>"), "")



                            .replace("**", "")



                            .trim()







                        if (text.isNotEmpty()) {
                            val historyUser = if (userQuery.contains("Dịch tin nhắn") || userQuery.contains("Dịch nhanh tin nhắn")) "Dịch tin nhắn mới nhất" else queryText
                            conversationHistory.add("user" to historyUser)
                            conversationHistory.add("model" to text)



                            if (conversationHistory.size > 80) {



                                repeat(2) { if (conversationHistory.isNotEmpty()) conversationHistory.removeAt(0) }



                            }



                            return text



                        }



                    } else if (conn.responseCode == 429 || conn.responseCode == 402) {



                        LicenseManager.markGeminiApiKeyCooldown(geminiKey, 180_000L)



                    }



                } catch (_: Throwable) {}



            }



        }







        // 2. DỰ PHÒNG THÔNG MINH (FALLBACK): Groq API (Qwen 3.8 / GPT-OSS)



        val apiKey = LicenseManager.getLoadBalancedGroqApiKey(context).ifBlank {



            try {



                com.example.BuildConfig.GROQ_API_KEY



            } catch (_: Throwable) {



                ""



            }



        }







        if (apiKey.isNotBlank() && apiKey != "GROQ_API_KEY_DEFAULT_VALUE") {



            // Sử dụng các model đang hoạt động chuẩn xác với tốc độ phản hồi siêu nhanh (~0.4s) trên Groq



            val models = if (attachedImageBase64 != null) {



                listOf("qwen/qwen3.8-27b", "openai/gpt-oss-20b", "openai/gpt-oss-120b")



            } else {



                listOf("qwen/qwen3.8-27b", "openai/gpt-oss-20b", "openai/gpt-oss-120b")



            }



            for (model in models) {



                try {



                    val url = URL("https://api.groq.com/openai/v1/chat/completions")



                    val conn = (url.openConnection() as HttpURLConnection).apply {



                        requestMethod = "POST"



                        doOutput = true



                        doInput = true



                        connectTimeout = 4000



                        readTimeout = 8000



                        setRequestProperty("Authorization", "Bearer $apiKey")



                        setRequestProperty("Content-Type", "application/json; charset=UTF-8")



                        setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 15; MagicTune) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36")



                    }







                    val messagesArr = JSONArray()



                    messagesArr.put(JSONObject().apply {



                        put("role", "system")



                        put("content", systemPrompt)



                    })



                    synchronized(conversationHistory) {
                        for ((role, content) in conversationHistory.takeLast(60)) {
                            val oaiRole = if (role == "model" || role == "assistant") "assistant" else "user"
                            messagesArr.put(JSONObject().apply {
                                put("role", oaiRole)
                                put("content", content)
                            })
                        }
                    }
                    if (false) for ((role, content) in conversationHistory.takeLast(6)) {



                        messagesArr.put(JSONObject().apply {



                            put("role", role)



                            put("content", content)



                        })



                    }







                    // Nếu là model vision và có ảnh vừa khoanh -> Gửi multimodal message



                    val userMsgObj = JSONObject()



                    userMsgObj.put("role", "user")



                    if (model.contains("vision") && attachedImageBase64 != null) {



                        val contentArr = JSONArray()



                        contentArr.put(JSONObject().apply {



                            put("type", "text")



                            put("text", userQuery)



                        })



                        contentArr.put(JSONObject().apply {



                            put("type", "image_url")



                            put("image_url", JSONObject().apply {



                                put("url", "data:image/jpeg;base64,${attachedImageBase64}")



                            })



                        })



                        userMsgObj.put("content", contentArr)



                    } else {



                        val enrichedQuery = if (!attachedImageOcrSummary.isNullOrBlank()) {



                            "$userQuery (Dữ liệu chữ trên ảnh vừa khoanh: $attachedImageOcrSummary)"



                        } else {



                            userQuery



                        }



                        userMsgObj.put("content", enrichedQuery)



                    }



                    messagesArr.put(userMsgObj)







                    val payload = JSONObject().apply {



                        put("model", model)



                        put("temperature", 0.3)



                        put("max_tokens", 160)



                        put("messages", messagesArr)



                    }







                    conn.outputStream.use { os ->



                        os.write(payload.toString().toByteArray(Charsets.UTF_8))



                    }







                    if (conn.responseCode in 200..299) {



                        val body = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }



                        val json = JSONObject(body)



                        val rawReply = json.optJSONArray("choices")



                            ?.optJSONObject(0)



                            ?.optJSONObject("message")



                            ?.optString("content", "")



                            .orEmpty()



                            .replace(Regex("<think>[\\s\\S]*?</think>"), "")



                            .replace("**", "")



                            .trim()







                        if (rawReply.isNotEmpty()) {



                            val historyUser2 = if (userQuery.contains("Dịch tin nhắn") || userQuery.contains("Dịch nhanh tin nhắn")) "Dịch tin nhắn mới nhất" else userQuery
                            conversationHistory.add("user" to historyUser2)
                            conversationHistory.add("assistant" to rawReply)



                            if (conversationHistory.size > 80) {



                                repeat(2) { if (conversationHistory.isNotEmpty()) conversationHistory.removeAt(0) }



                            }



                            return rawReply



                        }



                    }



                } catch (_: Throwable) {}



            }



        }







        // 3. TẦNG DỰ PHÒNG ZERO-COST VĨNH CỬU: DuckDuckGo AI / Pollinations OpenAI (Miễn phí 100%, không giới hạn, phục vụ hàng triệu người không tốn 1 xu)



        try {



            val url = URL("https://text.pollinations.ai/")



            val conn = (url.openConnection() as HttpURLConnection).apply {



                requestMethod = "POST"



                doOutput = true



                doInput = true



                connectTimeout = 5000



                readTimeout = 8000



                setRequestProperty("Content-Type", "application/json; charset=UTF-8")



                setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 15; MagicTune)")



            }







            val messagesArr = JSONArray()



            messagesArr.put(JSONObject().apply {



                put("role", "system")



                put("content", systemPrompt)



            })



            for ((role, content) in conversationHistory.takeLast(60)) {



                messagesArr.put(JSONObject().apply {



                    put("role", role)



                    put("content", content)



                })



            }



            messagesArr.put(JSONObject().apply {



                put("role", "user")



                put("content", userQuery)



            })







            val payload = JSONObject().apply {



                put("messages", messagesArr)



                put("model", "openai")



                put("code", "beesknees")



            }







            conn.outputStream.use { os ->



                os.write(payload.toString().toByteArray(Charsets.UTF_8))



            }







            if (conn.responseCode in 200..299) {



                val reply = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }



                    .replace(Regex("<think>[\\s\\S]*?</think>"), "")



                    .replace("**", "")



                    .trim()



                if (reply.isNotEmpty()) {



                    val historyUser3 = if (userQuery.contains("Dịch tin nhắn") || userQuery.contains("Dịch nhanh tin nhắn")) "Dịch tin nhắn mới nhất" else userQuery
                    conversationHistory.add("user" to historyUser3)
                    conversationHistory.add("assistant" to reply)



                    return reply



                }



            }



        } catch (_: Throwable) {}







        return "Tôi đã nghe câu hỏi \"$userQuery\" của bạn. Tôi vẫn luôn ở đây sẵn sàng hỗ trợ bạn nhé!"



    }







    /**



     * Phát giọng nói Tiếng Việt tự nhiên ngay trên màn hình hiện tại:



     * - Ưu tiên luồng giọng đọc Tiếng Việt Google Neural TTS (`translate.googleapis.com/translate_tts`)



     *   để máy Honor MagicOS nội địa (vốn không có gói TTS Tiếng Việt hệ thống) vẫn phát giọng đọc Tiếng Việt chuẩn 100%.



     * - Dự phòng sang `TextToSpeech` hệ thống nếu không tải được âm thanh.



     */



    private fun speakVietnameseResponse(



        context: Context,



        text: String,



        onFinished: () -> Unit



    ) {



        stopSpeakingImmediately()



        val cleanText = text



            .replace(Regex("[*#_`~>]"), " ")



            .replace(Regex("\\s+"), " ")



            .trim()



        if (cleanText.isEmpty()) {



            onFinished()



            return



        }







        overlayScope.launch(Dispatchers.IO) {



            val chunks = splitTextIntoSpeechChunks(cleanText, 120)



            var playedViaStream = false







            for (chunk in chunks) {



                if (!isActive || !isShowing) break



                val audioBytes = downloadGoogleVietnameseTtsMp3(chunk)



                if (audioBytes != null && audioBytes.size > 256) {



                    playedViaStream = true



                    playMp3BytesBlocking(context, audioBytes)



                } else {



                    break



                }



            }







            if (!playedViaStream && isShowing) {



                withContext(Dispatchers.Main) {



                    if (isTtsReady && ttsEngine != null) {



                        ttsEngine?.speak(cleanText, TextToSpeech.QUEUE_FLUSH, null, "gemini_live_utt")



                    }



                }



                delay(min(8000L, max(2000L, cleanText.length * 65L)))



            }







            withContext(Dispatchers.Main) {



                onFinished()



            }



        }



    }







    private fun splitTextIntoSpeechChunks(text: String, maxLen: Int): List<String> {



        if (text.length <= maxLen) return listOf(text)



        val result = mutableListOf<String>()



        val sentences = text.split(Regex("(?<=[.!?。；;\\n])\\s*"))



        var current = StringBuilder()



        for (sentence in sentences) {



            if (sentence.isBlank()) continue



            if (current.length + sentence.length + 1 <= maxLen) {



                if (current.isNotEmpty()) current.append(" ")



                current.append(sentence)



            } else {



                if (current.isNotEmpty()) {



                    result.add(current.toString())



                    current = StringBuilder()



                }



                if (sentence.length <= maxLen) {



                    current.append(sentence)



                } else {



                    var start = 0



                    while (start < sentence.length) {



                        val end = min(start + maxLen, sentence.length)



                        result.add(sentence.substring(start, end))



                        start = end



                    }



                }



            }



        }



        if (current.isNotEmpty()) result.add(current.toString())



        return result



    }







    private fun downloadGoogleVietnameseTtsMp3(chunk: String): ByteArray? {



        return try {



            val encoded = URLEncoder.encode(chunk, "UTF-8")



            val ttsUrl = "https://translate.googleapis.com/translate_tts?ie=UTF-8&q=$encoded&tl=vi&client=gtx"



            val conn = (URL(ttsUrl).openConnection() as HttpURLConnection).apply {



                requestMethod = "GET"



                connectTimeout = 5000



                readTimeout = 7000



                setRequestProperty(



                    "User-Agent",



                    "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"



                )



            }



            if (conn.responseCode in 200..299) {



                conn.inputStream.use { it.readBytes() }



            } else {



                null



            }



        } catch (_: Throwable) {



            null



        }



    }







    private suspend fun playMp3BytesBlocking(context: Context, mp3Bytes: ByteArray) {



        val tempFile = try {



            val f = File(context.cacheDir, "gemini_live_tts.mp3")



            FileOutputStream(f).use { it.write(mp3Bytes) }



            f



        } catch (_: Throwable) {



            null



        } ?: return







        val doneSignal = kotlinx.coroutines.CompletableDeferred<Unit>()



        withContext(Dispatchers.Main) {



            try {



                stopSpeakingImmediately()



                val mp = MediaPlayer()



                mediaPlayer = mp



                mp.setAudioAttributes(



                    AudioAttributes.Builder()



                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)



                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)



                        .build()



                )



                mp.setDataSource(tempFile.absolutePath)



                mp.setOnCompletionListener {



                    doneSignal.complete(Unit)



                }



                mp.setOnErrorListener { _, _, _ ->



                    doneSignal.complete(Unit)



                    true



                }



                mp.prepare()



                mp.start()



            } catch (_: Throwable) {



                doneSignal.complete(Unit)



            }



        }







        try {



            // Hiệu ứng sóng âm nhấp nhô khi Gemini đang phát tiếng nói



            while (!doneSignal.isCompleted && isShowing) {



                currentVoiceAmplitude = (0.25f + Math.random().toFloat() * 0.55f)



                delay(60L)



            }



        } finally {



            currentVoiceAmplitude = 0.08f



            withContext(Dispatchers.Main) {



                stopSpeakingImmediately()



            }



        }



    }







    private fun stopSpeakingImmediately() {



        val mp = mediaPlayer



        mediaPlayer = null



        if (mp != null) {



            try {



                if (mp.isPlaying) mp.stop()



            } catch (_: Throwable) {}



            try {



                mp.release()



            } catch (_: Throwable) {}



        }



        try {



            ttsEngine?.stop()



        } catch (_: Throwable) {}



    }







    private fun initTtsIfNeeded(context: Context) {



        if (ttsEngine != null) return



        try {



            ttsEngine = TextToSpeech(context.applicationContext) { status ->



                if (status == TextToSpeech.SUCCESS) {



                    val res = ttsEngine?.setLanguage(Locale.forLanguageTag("vi-VN"))



                    isTtsReady = res != TextToSpeech.LANG_MISSING_DATA && res != TextToSpeech.LANG_NOT_SUPPORTED



                }



            }



        } catch (_: Throwable) {}



    }







    /**



     * Khi người dùng muốn chuyển sang mở hẳn ứng dụng Google Gemini gốc:



     * Lập tức nhả Micro 100%, đóng hộp thoại nổi và mở thẳng app Gemini (`com.google.android.apps.bard`).



     */



    fun openOfficialGeminiAppAndYieldMic(context: Context): Boolean {



        val appCtx = context.applicationContext



        releaseHardwareMicrophoneCompletely()



        stopSpeakingImmediately()



        SystemFloatingHudOverlay.releaseMicrophoneForGeminiImmediately(appCtx)



        dismiss(appCtx)







        val pm = appCtx.packageManager



        val bardIntent = pm.getLaunchIntentForPackage("com.google.android.apps.bard")?.apply {



            addFlags(



                Intent.FLAG_ACTIVITY_NEW_TASK or



                    Intent.FLAG_ACTIVITY_CLEAR_TOP or



                    Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED



            )



            putExtra("launch_voice_mode", true)



            putExtra("extra_launch_voice_mode", true)



        }



        if (bardIntent != null) {



            try {



                val opts = android.app.ActivityOptions.makeBasic().apply {



                    if (Build.VERSION.SDK_INT >= 34) {



                        setPendingIntentBackgroundActivityStartMode(



                            @Suppress("DEPRECATION") android.app.ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED



                        )



                    }



                }



                appCtx.startActivity(bardIntent, opts.toBundle())



                return true



            } catch (_: Throwable) {



                try {



                    appCtx.startActivity(bardIntent)



                    return true



                } catch (_: Throwable) {}



            }



        }







        val shell = ShellEngine.getInstance(appCtx)



        if (shell.state.value.isAdbReady) {



            overlayScope.launch(Dispatchers.IO) {



                try {



                    shell.execute(



                        "am start --user 0 -n com.google.android.apps.bard/com.google.android.apps.bard.shellapp.BardEntryPointActivity >/dev/null 2>&1 || " +



                            "monkey -p com.google.android.apps.bard -c android.intent.category.LAUNCHER 1 >/dev/null 2>&1 || true"



                    )



                } catch (_: Throwable) {}



            }



            return true



        }







        return try {



            appCtx.startActivity(



                Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.google.android.apps.bard")).apply {



                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)



                }



            )



            true



        } catch (_: Throwable) {



            Toast.makeText(



                appCtx,



                "Vui lòng cài đặt ứng dụng Google Gemini từ CH Play!",



                Toast.LENGTH_SHORT



            ).show()



            false



        }



    }







    private fun triggerGentleHaptic(context: Context) {



        try {



            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {



                val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager



                vm?.defaultVibrator



            } else {



                @Suppress("DEPRECATION")



                context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator



            }



            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {



                vibrator?.vibrate(VibrationEffect.createOneShot(30L, VibrationEffect.DEFAULT_AMPLITUDE))



            } else {



                @Suppress("DEPRECATION")



                vibrator?.vibrate(30L)



            }



        } catch (_: Throwable) {}



    }







    private fun dp(context: Context, value: Int): Int {



        return TypedValue.applyDimension(



            TypedValue.COMPLEX_UNIT_DIP,



            value.toFloat(),



            context.resources.displayMetrics



        ).toInt()



    }







    /**



     * Thanh sóng âm ánh sáng Gemini (Gemini Glow Waveform Visualizer) phản hồi theo biên độ giọng nói thực tế.



     */



        /**
     * Biểu tượng Ngôi sao lấp lánh 4 cánh gradient chuẩn Google Gemini (Gemini 4-Pointed Sparkle Star).
     */
    private class GeminiSparkleView(context: Context) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
        }
        private val starPath = Path()

        override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
            super.onSizeChanged(w, h, oldw, oldh)
            if (w > 0 && h > 0) {
                paint.shader = LinearGradient(
                    0f,
                    0f,
                    w.toFloat(),
                    h.toFloat(),
                    intArrayOf(
                        Color.parseColor("#4285F4"),
                        Color.parseColor("#9B72CB"),
                        Color.parseColor("#D96570"),
                        Color.parseColor("#78D9EC")
                    ),
                    null,
                    Shader.TileMode.CLAMP
                )
                starPath.reset()
                val cx = w / 2f
                val cy = h / 2f
                val pinch = 0.28f
                starPath.moveTo(cx, 0f)
                starPath.quadTo(cx + (cx * pinch), cy - (cy * pinch), w.toFloat(), cy)
                starPath.quadTo(cx + (cx * pinch), cy + (cy * pinch), cx, h.toFloat())
                starPath.quadTo(cx - (cx * pinch), cy + (cy * pinch), 0f, cy)
                starPath.quadTo(cx - (cx * pinch), cy - (cy * pinch), cx, 0f)
                starPath.close()
            }
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            canvas.drawPath(starPath, paint)
        }
    }

    private class GeminiWaveView(context: Context) : View(context) {



        private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {



            style = Paint.Style.FILL



        }



        private val barRect = RectF()



        private var phase = 0f



        private var isAnimating = false



        private var isListeningMode = true



        private var isSpeakingMode = false







        private val frameRunnable = object : Runnable {



            override fun run() {



                if (!isAnimating) return



                phase += 0.24f



                invalidate()



                postDelayed(this, 32L)



            }



        }







        fun setMode(listening: Boolean, speaking: Boolean) {



            isListeningMode = listening



            isSpeakingMode = speaking



            if (listening || speaking) {



                startAnimation()



            } else {



                stopAnimation()



            }



            invalidate()



        }







        fun startAnimation() {



            if (isAnimating) return



            isAnimating = true



            post(frameRunnable)



        }







        fun stopAnimation() {



            isAnimating = false



            removeCallbacks(frameRunnable)



        }







        override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {



            super.onSizeChanged(w, h, oldw, oldh)



            if (w > 0) {



            barPaint.shader = LinearGradient(
                0f,
                0f,
                w.toFloat(),
                0f,
                intArrayOf(
                    Color.parseColor("#4285F4"),
                    Color.parseColor("#818CF8"),
                    Color.parseColor("#9B72CB"),
                    Color.parseColor("#D96570"),
                    Color.parseColor("#78D9EC"),
                    Color.parseColor("#4285F4")
                ),
                null,
                Shader.TileMode.CLAMP
            )



            }



        }







        override fun onDraw(canvas: Canvas) {



            super.onDraw(canvas)



            val w = width.toFloat()



            val h = height.toFloat()



            if (w <= 0f || h <= 0f) return







            val barCount = 28



            val spacing = w / (barCount * 1.65f)



            val barWidth = spacing * 0.85f



            val totalBarsWidth = barCount * barWidth + (barCount - 1) * (spacing - barWidth)



            val startX = (w - totalBarsWidth) / 2f



            val centerY = h / 2f



            val amp = if (isListeningMode || isSpeakingMode) {



                max(0.18f, currentVoiceAmplitude)



            } else {



                0.08f



            }







            for (i in 0 until barCount) {



                val centerFactor = 1f - abs((i - barCount / 2f) / (barCount / 2f)) * 0.55f



                val wave = abs(sin((phase + i * 0.45f).toDouble())).toFloat() *



                    abs(cos((phase * 0.7f - i * 0.25f).toDouble())).toFloat()



                val barHeight = (h * (0.16f + 0.80f * amp * wave * centerFactor)).coerceIn(h * 0.14f, h * 0.94f)



                val left = startX + i * spacing



                val top = centerY - barHeight / 2f



                val bottom = centerY + barHeight / 2f



                barRect.set(left, top, left + barWidth, bottom)



                canvas.drawRoundRect(barRect, barWidth / 2f, barWidth / 2f, barPaint)



            }



        }



    }



}



