package com.example.core.service

import android.app.Notification
import android.app.AlarmManager
import android.app.PendingIntent
import android.os.SystemClock
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.appwidget.AppWidgetManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.BatteryManager
import android.os.PowerManager
import android.provider.Settings
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.core.widget.AppSearchActivity
import com.example.core.widget.BatteryInfoReader
import com.example.core.widget.BatteryChargeData
import com.example.core.widget.MagicTuneBatteryWidgetProvider
import com.example.core.widget.MagicTuneMemoryWidgetProvider
import kotlinx.coroutines.launch
import java.util.Locale

class MagicTuneKeepAliveService : Service() {

    private var liveBatteryReceiver: BroadcastReceiver? = null
    private var screenStateReceiver: BroadcastReceiver? = null
    private var wasFullyChargedNotified = false

    // Scope nền chuyên biệt để đọc sysfs pin, cập nhật Widget và UsageStats mà không bao giờ gây khựng Main Thread (120Hz/144Hz)
    private val serviceScope = kotlinx.coroutines.CoroutineScope(
        kotlinx.coroutines.SupervisorJob() + kotlinx.coroutines.Dispatchers.IO
    )

    // Handler chu kỳ cập nhật widget & canh gác cầu nối Khoanh Tròn Google / Gemini Voice 24/7
    private val loopHandler = Handler(Looper.getMainLooper())
    private val realtimeTickerRunnable = object : Runnable {
        override fun run() {
            val pm = getSystemService(Context.POWER_SERVICE) as? PowerManager
            val isScreenInteractive = pm?.isInteractive ?: true

            // Chỉ cập nhật tick liên tục khi màn hình đang BẬT (chạy hoàn toàn trên luồng IO nền)
            if (isScreenInteractive) {
                SystemFloatingHudOverlay.ensureNavBridgeHealthy(applicationContext)
                SystemFloatingHudOverlay.syncNavBarBridge(applicationContext)
                serviceScope.launch {
                    updateAllHomeWidgetsRealtime()
                    checkChargingNotification()
                    SystemFloatingHudOverlay.interceptYoyoIfForeground(applicationContext)
                }
            }
            AutoWakeupPatrolManager.performSilentPulseIfDue(applicationContext)

            // Cập nhật trạng thái hiện diện (Online Heartbeat) lên Cloud Firestore để trang quản trị luôn biết máy đang online
            try {
                com.example.core.license.LicenseManager.syncDevicePresenceToCloud(applicationContext)
            } catch (_: Throwable) {}

            // Khi tắt màn hình giãn chu kỳ lên 60s để ngủ sâu và tiết kiệm 100% pin
            val nextDelay = if (isScreenInteractive) 15000L else 180000L
            loopHandler.postDelayed(this, nextDelay)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
        val initialNotif = try {
            if (isSearchNotificationEnabled(this)) buildPinnedSearchNotification() else buildSilentNotification()
        } catch (_: Throwable) {
            buildSilentNotification()
        }
        startForegroundSafely(initialNotif)
        registerLiveBatteryListener()
        registerScreenStateListener()
        startRealtimeWidgetTicker()
        SystemFloatingHudOverlay.syncNavBarBridge(applicationContext)
    }

    private fun startRealtimeWidgetTicker() {
        loopHandler.removeCallbacks(realtimeTickerRunnable)
        loopHandler.post(realtimeTickerRunnable)
    }

    private fun registerScreenStateListener() {
        if (screenStateReceiver == null) {
            screenStateReceiver = object : BroadcastReceiver() {
                override fun onReceive(context: Context?, intent: Intent?) {
                    when (intent?.action) {
                        Intent.ACTION_SCREEN_ON -> {
                            // Khi bật màn hình: cập nhật ngay tức thì trên luồng IO rồi tiếp tục tick
                            loopHandler.removeCallbacks(realtimeTickerRunnable)
                            loopHandler.post(realtimeTickerRunnable)
                        }
                        Intent.ACTION_USER_PRESENT -> {
                            // Ngay sau khi mở khóa màn hình (Mở khóa khuôn mặt / Vân tay):
                            // Kích hoạt phiên lắng nghe giọng đọc rảnh tay (8s) để gọi Gemini Nổi ngay khi đọc "Gemini" / "Ok Google"
                            SystemFloatingHudOverlay.syncNavBarBridge(applicationContext)
                            SystemFloatingHudOverlay.onDeviceUnlockedByUser(applicationContext)
                        }
                        Intent.ACTION_SCREEN_OFF -> {
                            // Khi tắt màn hình: đóng ngay phiên lắng nghe Micro và giãn cách cập nhật để CPU vào chế độ Deep Sleep hoàn toàn
                            SystemFloatingHudOverlay.stopUnlockVoiceWakeListener()
                            loopHandler.removeCallbacks(realtimeTickerRunnable)
                            loopHandler.postDelayed(realtimeTickerRunnable, 60000L)
                        }
                    }
                }
            }
            val filter = IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_ON)
                addAction(Intent.ACTION_SCREEN_OFF)
                addAction(Intent.ACTION_USER_PRESENT)
            }
            try {
                androidx.core.content.ContextCompat.registerReceiver(
                    this,
                    screenStateReceiver,
                    filter,
                    androidx.core.content.ContextCompat.RECEIVER_NOT_EXPORTED
                )
            } catch (_: Throwable) {
                try {
                    registerReceiver(screenStateReceiver, filter)
                } catch (_: Throwable) {}
            }
        }
    }

    private fun updateAllHomeWidgetsRealtime() {
        try {
            val appWidgetManager = AppWidgetManager.getInstance(this)

            val batComp = ComponentName(this, MagicTuneBatteryWidgetProvider::class.java)
            val batIds = appWidgetManager.getAppWidgetIds(batComp)
            for (id in batIds) {
                MagicTuneBatteryWidgetProvider.updateWidget(this, appWidgetManager, id)
            }

            val memComp = ComponentName(this, MagicTuneMemoryWidgetProvider::class.java)
            val memIds = appWidgetManager.getAppWidgetIds(memComp)
            for (id in memIds) {
                MagicTuneMemoryWidgetProvider.updateWidget(this, appWidgetManager, id)
            }

            val searchComp = ComponentName(this, com.example.core.widget.MagicTuneAppSearchWidgetProvider::class.java)
            val searchIds = appWidgetManager.getAppWidgetIds(searchComp)
            for (id in searchIds) {
                com.example.core.widget.MagicTuneAppSearchWidgetProvider.updateWidget(this, appWidgetManager, id)
            }
        } catch (_: Exception) {}
    }

    private fun registerLiveBatteryListener() {
        if (liveBatteryReceiver == null) {
            liveBatteryReceiver = object : BroadcastReceiver() {
                override fun onReceive(context: Context?, intent: Intent?) {
                    serviceScope.launch {
                        updateAllHomeWidgetsRealtime()
                        checkChargingNotification()
                    }
                }
            }
            val filter = IntentFilter().apply {
                addAction(Intent.ACTION_BATTERY_CHANGED)
                addAction(Intent.ACTION_POWER_CONNECTED)
                addAction(Intent.ACTION_POWER_DISCONNECTED)
            }
            try {
                androidx.core.content.ContextCompat.registerReceiver(
                    this,
                    liveBatteryReceiver,
                    filter,
                    androidx.core.content.ContextCompat.RECEIVER_NOT_EXPORTED
                )
            } catch (_: Throwable) {
                try {
                    registerReceiver(liveBatteryReceiver, filter)
                } catch (_: Throwable) {}
            }
        }
    }

    @Volatile
    private var lastAutoCoolingTriggerTime = 0L

    private fun checkAutoThermalCooling(batteryIntent: Intent?) {
        try {
            if (batteryIntent == null) return
            val tempTenths = batteryIntent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1)
            if (tempTenths <= 0) return
            val tempC = tempTenths / 10.0f
            val isAutoCoolingEnabled = isAutoCoolingEnabled(this)
            
            // Kích hoạt khi nhiệt độ pin/máy vượt quá 42.0°C (ngưỡng nóng thực tế) và giãn cách ít nhất 5 phút
            val now = System.currentTimeMillis()
            if (isAutoCoolingEnabled && tempC >= 42.0f && (now - lastAutoCoolingTriggerTime > 300000L)) {
                lastAutoCoolingTriggerTime = now
                android.util.Log.w("MagicTuneCooling", "⚠️ Cảnh báo nhiệt độ $tempC°C >= 42°C! Tự động kích hoạt giải pháp làm mát an toàn.")
                
                // 1. Chạy lệnh shell làm mát hệ thống qua ShellEngine (UID 2000) trên Coroutine IO
                kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
                    try {
                        val shell = com.example.core.shell.ShellEngine.getInstance(applicationContext)
                        if (shell.state.value.isAdbReady) {
                            val cmds = listOf(
                                "settings put global user_powersaver_enable 1",
                                "settings put global low_power 1",
                                "settings put system peak_refresh_rate 60.0",
                                "settings put system min_refresh_rate 60.0",
                                "settings put system user_refresh_rate 60",
                                "settings put system thermal_limit_refresh_rate 60",
                                "settings put global window_animation_scale 0.5",
                                "settings put global transition_animation_scale 0.5",
                                "settings put global animator_duration_scale 0.5",
                                "settings put system auto_download_magazine_wifi 0",
                                "settings put global wifi_scan_always_enabled 0",
                                "settings put global ble_scan_always_enabled 0",
                                "setprop persist.sys.purge_buffers 1"
                            )
                            shell.execute(cmds.joinToString(" ; "))
                        }
                    } catch (_: Exception) {}
                }

                // 2. Bắn thông báo High-Priority cảnh báo người dùng máy đang được hạ nhiệt
                val manager = getSystemService(NotificationManager::class.java)
                if (manager != null) {
                    val openIntent = Intent(this, MainActivity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                    }
                    val pi = PendingIntent.getActivity(
                        this,
                        2,
                        openIntent,
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                    )
                    val coolingNotif = NotificationCompat.Builder(this, CHANNEL_ALERT_ID)
                        .setContentTitle(String.format(Locale.US, "❄️ Đã tự động kích hoạt làm mát (%.1f°C)", tempC))
                        .setContentText("Đang làm mát giúp bạn")
                        .setSmallIcon(R.drawable.ic_stat_magictune)
                        .setPriority(NotificationCompat.PRIORITY_HIGH)
                        .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                        .setAutoCancel(true)
                        .setContentIntent(pi)
                        .build()
                    manager.notify(NOTIF_ID_COOLING_ALERT, coolingNotif)
                }
            }
        } catch (_: Exception) {}
    }

    @Volatile
    private var lastSmartChargeCoolingTime = 0L

    /**
     * Tự động điều tiết tài nguyên nền khi đang cắm sạc nhanh (USB-PD / SuperCharge):
     * Giảm tải CPU vô ích để máy hạ 2-3°C, giữ nhiệt độ pin dưới ngưỡng bóp sạc của chip sạc,
     * giúp máy sạc nhanh hơn, ổn định dòng điện mà pin vẫn mát mẻ và an toàn tuyệt đối.
     */
    private fun performSmartFastChargeCoolingGuard(data: BatteryChargeData) {
        try {
            val now = System.currentTimeMillis()
            // Nếu nhiệt độ pin bắt đầu ấm lên (38.5°C - 41.5°C) khi sạc nhanh: Dọn dẹp tác vụ nền để hạ nhiệt
            if (data.temperatureC in 38.5..41.5 && (now - lastSmartChargeCoolingTime > 180000L)) {
                lastSmartChargeCoolingTime = now
                kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
                    try {
                        val shell = com.example.core.shell.ShellEngine.getInstance(applicationContext)
                        if (shell.state.value.isAdbReady) {
                            val cmds = listOf(
                                "setprop persist.sys.purge_buffers 1",
                                "settings put global wifi_scan_always_enabled 0",
                                "settings put global ble_scan_always_enabled 0"
                            )
                            shell.execute(cmds.joinToString(" ; "))
                        }
                    } catch (_: Throwable) {}
                }
            }
        } catch (_: Throwable) {}
    }

    private fun checkChargingNotification() {
        try {
            val batteryIntent = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            checkAutoThermalCooling(batteryIntent)
            val data = BatteryInfoReader.read(this, batteryIntent)
            if (data.isCharging) {
                performSmartFastChargeCoolingGuard(data)
            }
            val manager = getSystemService(NotificationManager::class.java) ?: return

            val isChargingNotifEnabled = isChargingNotificationEnabled(this)
            val isSearchNotifEnabled = isSearchNotificationEnabled(this)

            if (data.isCharging) {
                if (data.batteryPct >= 100) {
                    if (!wasFullyChargedNotified) {
                        wasFullyChargedNotified = true
                        val fullNotif = buildFullyChargedNotification(data.phoneDisplayName)
                        manager.notify(NOTIF_ID_CHARGED_ALERT, fullNotif)
                    }
                } else {
                    wasFullyChargedNotified = false
                }
            } else {
                wasFullyChargedNotified = false
                manager.cancel(NOTIF_ID_CHARGED_ALERT)
            }

            // Ưu tiên hiển thị:
            // 1. Nếu đang bật Thanh Tìm Kiếm Ghim Trên Cùng: Luôn hiển thị thanh tìm kiếm cố định
            // 2. Nếu không bật tìm kiếm mà bật Báo Sạc: Hiển thị báo sạc khi cắm sạc
            // 3. Mặc định: Giữ chạy nền âm thầm
            val activeNotif = when {
                isSearchNotifEnabled -> buildPinnedSearchNotification()
                isChargingNotifEnabled && data.isCharging -> {
                    val contentText = if (data.batteryPct >= 100) {
                        "✅ Pin đã sạc đầy 100%! Vui lòng rút sạc để bảo vệ pin."
                    } else {
                        String.format(
                            Locale.US,
                            "%s • Pin %d%% • Dự kiến đầy sau: ~%dp (%.1fW)",
                            data.speedTitle,
                            data.batteryPct,
                            data.minutesToFull,
                            data.currentWatts
                        )
                    }
                    buildChargingLockscreenNotification(contentText)
                }
                else -> buildSilentNotification()
            }
            loopHandler.post {
                startForegroundSafely(activeNotif)
            }
        } catch (_: Throwable) {}
    }

    private fun startForegroundSafely(notif: Notification) {
        val hasMicPerm = androidx.core.content.ContextCompat.checkSelfPermission(
            this,
            android.Manifest.permission.RECORD_AUDIO
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                val fgsType = if (hasMicPerm) {
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE or
                        android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                } else {
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                }
                startForeground(NOTIFICATION_ID, notif, fgsType)
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && hasMicPerm) {
                startForeground(
                    NOTIFICATION_ID,
                    notif,
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                )
            } else {
                startForeground(NOTIFICATION_ID, notif)
            }
        } catch (_: Throwable) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                    startForeground(
                        NOTIFICATION_ID,
                        notif,
                        android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                    )
                } else {
                    startForeground(NOTIFICATION_ID, notif)
                }
            } catch (_: Throwable) {
                try {
                    val fallback = buildSilentNotification()
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                        startForeground(
                            NOTIFICATION_ID,
                            fallback,
                            android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                        )
                    } else {
                        startForeground(NOTIFICATION_ID, fallback)
                    }
                } catch (_: Throwable) {
                    try {
                        stopSelf()
                    } catch (_: Throwable) {}
                }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val initialNotif = try {
            if (isSearchNotificationEnabled(this)) buildPinnedSearchNotification() else buildSilentNotification()
        } catch (_: Throwable) {
            buildSilentNotification()
        }
        startForegroundSafely(initialNotif)
        serviceScope.launch {
            updateAllHomeWidgetsRealtime()
            checkChargingNotification()
        }
        return START_STICKY
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)

            // Channel nền hoàn toàn âm thầm: IMPORTANCE_MIN (không biểu tượng thanh trạng thái, không âm thanh, không rung, không banner)
            val silentChannel = NotificationChannel(
                CHANNEL_ID,
                "MagicTune Dịch Vụ Nền",
                NotificationManager.IMPORTANCE_MIN
            ).apply {
                description = "Duy trì đồng bộ widget và ADB ngầm âm thầm không hiển thị lên màn hình"
                setShowBadge(false)
                lockscreenVisibility = Notification.VISIBILITY_SECRET
                enableVibration(false)
                enableLights(false)
                setSound(null, null)
            }
            manager?.createNotificationChannel(silentChannel)

            // Channel Ghim Tìm Kiếm Trên Cùng & Màn Hình Khóa (IMPORTANCE_HIGH, Ongoing, Silent)
            val searchChannel = NotificationChannel(
                CHANNEL_SEARCH_ID,
                "MagicTune Thanh Tìm Kiếm Cố Định",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Ghim thanh tìm kiếm ứng dụng lên đầu thanh điều hướng và màn hình khóa"
                setShowBadge(false)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                enableVibration(false)
                enableLights(false)
                setSound(null, null)
            }
            manager?.createNotificationChannel(searchChannel)

            // Channel cảnh báo khi đầy pin (Âm thanh + Rung + Nổi màn hình khóa nếu người dùng cần)
            val fullAlertChannel = NotificationChannel(
                CHANNEL_ALERT_ID,
                "MagicTune Cảnh Báo Pin Đầy",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Báo chuông và rung thông báo khi điện thoại sạc đạt 100%"
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                enableVibration(true)
            }
            manager?.createNotificationChannel(fullAlertChannel)
        }
    }

    /**
     * Thanh tìm kiếm ứng dụng & Gọi Gemini Voice ghim cố định ở vị trí trên cùng của Thanh thông báo & Màn hình khóa
     */
    private fun buildPinnedSearchNotification(): Notification {
        val searchIntent = Intent(this, AppSearchActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val searchPendingIntent = PendingIntent.getActivity(
            this,
            5001,
            searchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val manageAppsIntent = Intent(Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        val appsPendingIntent = PendingIntent.getActivity(
            this,
            5002,
            manageAppsIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val geminiLockscreenIntent = Intent(this, com.example.core.widget.GeminiVoiceLockscreenActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val geminiPendingIntent = PendingIntent.getActivity(
            this,
            5003,
            geminiLockscreenIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val customViews = try {
            RemoteViews(packageName, R.layout.notification_app_search).apply {
                setOnClickPendingIntent(R.id.notif_search_bar, searchPendingIntent)
                setOnClickPendingIntent(R.id.notif_search_root, searchPendingIntent)
                setOnClickPendingIntent(R.id.notif_btn_gemini, geminiPendingIntent)
                setOnClickPendingIntent(R.id.notif_btn_apps, appsPendingIntent)
            }
        } catch (_: Throwable) { null }

        val builder = NotificationCompat.Builder(this, CHANNEL_SEARCH_ID)
            .setSmallIcon(R.drawable.ic_stat_magictune)
            .setContentTitle("🔍 Tìm kiếm App & 🎙️ Gọi Gemini Voice")
            .setContentText("Chạm 🎙️ Gemini trên màn hình khóa để mở khóa khuôn mặt & trò chuyện AI...")
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MAX) // Ưu tiên cao nhất để ghim trên cùng
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC) // Hiển thị đầy đủ trên màn hình khóa
            .setOnlyAlertOnce(true)
            .setSilent(true) // Hoàn toàn không phát âm thanh làm phiền
            .setContentIntent(searchPendingIntent)

        if (customViews != null) {
            builder.setCustomContentView(customViews)
            builder.setCustomBigContentView(customViews)
            builder.setStyle(NotificationCompat.DecoratedCustomViewStyle())
        } else {
            builder.addAction(
                android.R.drawable.ic_btn_speak_now,
                "🎙️ Gọi Gemini Voice",
                geminiPendingIntent
            )
        }

        return builder.build()
    }

    /**
     * Thông báo chạy ngầm hoàn toàn âm thầm, không hiển thị biểu ngữ nổi,
     * không làm phiền người dùng trên thanh thông báo.
     */
    private fun buildSilentNotification(): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("MagicTune")
            .setContentText("Đang chạy ngầm tiết kiệm pin")
            .setSmallIcon(R.drawable.ic_stat_magictune)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setVisibility(NotificationCompat.VISIBILITY_SECRET)
            .setSilent(true)
            .setContentIntent(pendingIntent)
            .build()
    }

    private fun buildChargingLockscreenNotification(contentText: String): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("⚡ Giám Sát Sạc Pin Thời Gian Thực")
            .setContentText(contentText)
            .setSmallIcon(R.drawable.ic_stat_magictune)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setContentIntent(pendingIntent)
            .build()
    }

    private fun buildFullyChargedNotification(phoneName: String): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            1,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ALERT_ID)
            .setContentTitle("🔋 $phoneName Đã Sạc Đầy 100%!")
            .setContentText("Pin đã đầy hoàn toàn. Hãy rút dây sạc để bảo vệ tuổi thọ pin tối ưu.")
            .setSmallIcon(R.drawable.ic_stat_magictune)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        try {
            SystemFloatingHudOverlay.syncNavBarBridge(applicationContext)
            scheduleAutoReviveAlarm(applicationContext)
            updateAllHomeWidgetsRealtime()
        } catch (_: Throwable) {}
    }

    override fun onDestroy() {
        loopHandler.removeCallbacks(realtimeTickerRunnable)
        try {
            serviceScope.coroutineContext[kotlinx.coroutines.Job]?.cancel()
        } catch (_: Exception) {}
        try {
            screenStateReceiver?.let { unregisterReceiver(it) }
            screenStateReceiver = null
        } catch (_: Exception) {}
        try {
            liveBatteryReceiver?.let { unregisterReceiver(it) }
            liveBatteryReceiver = null
        } catch (_: Exception) {}
        try {
            if (!isExplicitStopRequested) {
                scheduleAutoReviveAlarm(applicationContext)
            }
        } catch (_: Throwable) {}

        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val CHANNEL_ID = "magictune_keepalive_channel_silent"
        private const val CHANNEL_SEARCH_ID = "magictune_pinned_search_channel"
        private const val CHANNEL_ALERT_ID = "magictune_battery_alert_channel"
        private const val NOTIFICATION_ID = 20001
        private const val NOTIF_ID_CHARGED_ALERT = 20002
        private const val PREFS_NAME = "magictune_charging_prefs"
        private const val KEY_CHARGING_NOTIF_ENABLED = "charging_notification_enabled"
        private const val KEY_SEARCH_NOTIF_ENABLED = "search_notification_pinned_enabled"
        private const val KEY_AUTO_COOLING_ENABLED = "auto_cooling_enabled"
        private const val NOTIF_ID_COOLING_ALERT = 20003
        const val ACTION_REVIVE_KEEPALIVE = "com.example.core.service.ACTION_REVIVE_KEEPALIVE"

        @Volatile
        private var isExplicitStopRequested = false

        fun isAutoCoolingEnabled(context: Context): Boolean {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            return prefs.getBoolean(KEY_AUTO_COOLING_ENABLED, true) // Mặc định BẬT bảo vệ phần cứng
        }

        fun setAutoCoolingEnabled(context: Context, enabled: Boolean) {
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putBoolean(KEY_AUTO_COOLING_ENABLED, enabled)
                .apply()
        }
        const val EXTRA_STATUS_TEXT = "extra_status_text"

        fun isChargingNotificationEnabled(context: Context): Boolean {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            return prefs.getBoolean(KEY_CHARGING_NOTIF_ENABLED, false)
        }

        fun setChargingNotificationEnabled(context: Context, enabled: Boolean) {
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putBoolean(KEY_CHARGING_NOTIF_ENABLED, enabled)
                .apply()
        }

        fun isSearchNotificationEnabled(context: Context): Boolean {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            return prefs.getBoolean(KEY_SEARCH_NOTIF_ENABLED, true) // Mặc định BẬT để tiện dụng
        }

        fun setSearchNotificationEnabled(context: Context, enabled: Boolean) {
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putBoolean(KEY_SEARCH_NOTIF_ENABLED, enabled)
                .apply()
        }

        private fun isAppInForeground(): Boolean {
            return try {
                val info = android.app.ActivityManager.RunningAppProcessInfo()
                android.app.ActivityManager.getMyMemoryState(info)
                info.importance <= android.app.ActivityManager.RunningAppProcessInfo.IMPORTANCE_VISIBLE
            } catch (_: Throwable) {
                false
            }
        }

        fun scheduleAutoReviveAlarm(context: Context) {
            try {
                val appCtx = context.applicationContext ?: context
                val alarmManager = appCtx.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
                val reviveIntent = Intent(appCtx, com.example.core.receiver.MagicTuneBootReceiver::class.java).apply {
                    action = ACTION_REVIVE_KEEPALIVE
                }
                val pi = PendingIntent.getBroadcast(
                    appCtx,
                    9091,
                    reviveIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                val triggerAt = SystemClock.elapsedRealtime() + 1500L
                alarmManager.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAt, pi)
            } catch (_: Throwable) {}
        }

        fun startOrUpdate(
            context: Context,
            statusText: String = "Đang duy trì Google Khoanh Tròn & Trò chuyện Gemini 24/7",
            forceFromBootOrOverlay: Boolean = false
        ) {
            try {
                isExplicitStopRequested = false
                val appCtx = context.applicationContext ?: context
                val hasOverlayExemption = try { Settings.canDrawOverlays(appCtx) } catch (_: Throwable) { false }
                if (!forceFromBootOrOverlay && !isAppInForeground() && !hasOverlayExemption) return

                val intent = Intent(appCtx, MagicTuneKeepAliveService::class.java).apply {
                    putExtra(EXTRA_STATUS_TEXT, statusText)
                }
                try {
                    appCtx.startService(intent)
                } catch (_: Throwable) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        androidx.core.content.ContextCompat.startForegroundService(appCtx, intent)
                    }
                }
            } catch (_: Throwable) {}
        }

        fun ensureMicrophoneForeground(context: Context) {
            try {
                isExplicitStopRequested = false
                val appCtx = context.applicationContext ?: context
                val intent = Intent(appCtx, MagicTuneKeepAliveService::class.java).apply {
                    putExtra(EXTRA_STATUS_TEXT, "Gemini Live Active")
                }
                try {
                    appCtx.startService(intent)
                } catch (_: Throwable) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        androidx.core.content.ContextCompat.startForegroundService(appCtx, intent)
                    }
                }
            } catch (_: Throwable) {}
        }

        fun stop(context: Context) {
            try {
                isExplicitStopRequested = true
                context.stopService(Intent(context, MagicTuneKeepAliveService::class.java))
            } catch (_: Throwable) {}
        }
    }
}
