package com.example.core.permission

import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat

data class AppSelfPermissionStatus(
    val hasNotificationPermission: Boolean,
    val isIgnoringBatteryOptimizations: Boolean,
    val hasOverlayPermission: Boolean,
    val hasUsageStatsPermission: Boolean,
    val hasWriteSecureSettings: Boolean,
    val isShizukuGranted: Boolean
) {
    val isFullyGranted: Boolean
        get() = hasNotificationPermission &&
                isIgnoringBatteryOptimizations &&
                hasOverlayPermission &&
                hasUsageStatsPermission

    val missingCount: Int
        get() {
            var count = 0
            if (!hasNotificationPermission) count++
            if (!isIgnoringBatteryOptimizations) count++
            if (!hasOverlayPermission) count++
            if (!hasUsageStatsPermission) count++
            return count
        }
}

object AppPermissionChecker {

    fun checkSelfPermissions(context: Context, isShizukuReady: Boolean = false): AppSelfPermissionStatus {
        val pkg = context.packageName

        // 1. Quyền Thông Báo (POST_NOTIFICATIONS / NotificationManagerCompat)
        val hasNotif = try {
            val nm = NotificationManagerCompat.from(context)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED && nm.areNotificationsEnabled()
            } else {
                nm.areNotificationsEnabled()
            }
        } catch (_: Exception) { true }

        // 2. Quyền Chạy ngầm không giới hạn / Bỏ tối ưu pin (Ignore Battery Optimizations)
        val isIgnoringBattery = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
                pm?.isIgnoringBatteryOptimizations(pkg) ?: true
            } else true
        } catch (_: Exception) { true }

        // 3. Quyền Hiển thị trên ứng dụng khác (SYSTEM_ALERT_WINDOW / Overlay)
        val hasOverlay = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Settings.canDrawOverlays(context)
            } else true
        } catch (_: Exception) { true }

        // 4. Quyền Truy cập lịch sử sử dụng để đọc App gần đây (PACKAGE_USAGE_STATS)
        val hasUsage = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as? AppOpsManager
                val mode = appOps?.checkOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS,
                    android.os.Process.myUid(),
                    pkg
                )
                mode == AppOpsManager.MODE_ALLOWED
            } else true
        } catch (_: Exception) { false }

        // 5. Quyền WRITE_SECURE_SETTINGS (Cấp qua ADB/Shizuku)
        val hasSecure = try {
            context.checkCallingOrSelfPermission(android.Manifest.permission.WRITE_SECURE_SETTINGS) == PackageManager.PERMISSION_GRANTED
        } catch (_: Exception) { false }

        return AppSelfPermissionStatus(
            hasNotificationPermission = hasNotif,
            isIgnoringBatteryOptimizations = isIgnoringBattery,
            hasOverlayPermission = hasOverlay,
            hasUsageStatsPermission = hasUsage,
            hasWriteSecureSettings = hasSecure,
            isShizukuGranted = isShizukuReady
        )
    }

    // Các hàm mở trang cấp quyền tương ứng cho từng mục:
    fun requestNotificationPermission(context: Context) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                    putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            } else {
                openAppDetailsSettings(context)
            }
        } catch (_: Exception) {
            openAppDetailsSettings(context)
        }
    }

    fun requestIgnoreBatteryOptimizations(context: Context) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = Uri.parse("package:${context.packageName}")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            }
        } catch (_: Exception) {
            try {
                val intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            } catch (_: Exception) {
                openAppDetailsSettings(context)
            }
        }
    }

    fun requestOverlayPermission(context: Context) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:${context.packageName}")
                ).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            }
        } catch (_: Exception) {
            openAppDetailsSettings(context)
        }
    }

    fun requestUsageStatsPermission(context: Context) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                val intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            }
        } catch (_: Exception) {
            openAppDetailsSettings(context)
        }
    }

    fun openAppDetailsSettings(context: Context) {
        try {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.parse("package:${context.packageName}")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Exception) {}
    }

    /**
     * Mở trực tiếp trang 'Quản lý khởi chạy ứng dụng' (App Launch / Auto-start) trên MagicOS Honor.
     * Cho phép người dùng chuyển từ Tự động quản lý sang Quản lý thủ công (Bật Tự khởi chạy, Khởi chạy thứ cấp, Chạy ngầm).
     */
    fun openHonorAppLaunchSettings(context: Context) {
        val intents = listOf(
            Intent().setClassName("com.hihonor.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"),
            Intent().setClassName("com.hihonor.systemmanager", "com.hihonor.systemmanager.startupmgr.ui.StartupNormalAppListActivity"),
            Intent().setClassName("com.hihonor.systemmanager", "com.hihonor.systemmanager.optimize.bootstart.BootStartActivity"),
            Intent().setClassName("com.hihonor.systemmanager", "com.huawei.systemmanager.appcontrol.activity.StartupAppControlActivity"),
            Intent().setClassName("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"),
            Intent().setClassName("com.huawei.systemmanager", "com.huawei.systemmanager.optimize.bootstart.BootStartActivity")
        )

        for (intent in intents) {
            try {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                return
            } catch (_: Exception) {}
        }

        openAppDetailsSettings(context)
    }

    /**
     * Cố gắng mở trang gỡ bỏ 'Cài đặt bị hạn chế' (Restricted Settings) cho MagicTune trên Android 13+.
     * Trên MagicOS, nếu mục bị ẩn, người dùng cần vào Cài đặt ứng dụng -> Dấu 3 chấm -> Cho phép cài đặt bị hạn chế.
     */
    fun openRestrictedSettingsGuide(context: Context) {
        // Không có Intent trực tiếp để gỡ hạn chế, nhưng mở trang Chi tiết ứng dụng là bước đầu tiên
        openAppDetailsSettings(context)
    }

    /**
     * Mở trang 'Quyền đặc biệt' (Special App Access) nơi chứa Usage Stats và Write Settings.
     */
    fun openSpecialAppAccess(context: Context) {
        try {
            val intent = Intent("android.settings.SPECIAL_APP_ACCESS").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Exception) {
            openAppDetailsSettings(context)
        }
    }
}
