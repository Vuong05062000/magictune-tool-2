package com.example.core.service

import android.content.Context
import android.os.SystemClock
import com.example.core.shell.ShellEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * AutoWakeupPatrolManager:
 * Hệ thống Tuần Tra & Đánh Thức AI Cấp Phần Cứng & Phần Mềm trên MagicOS / Honor.
 *
 * Khắc phục triệt để lỗi "tịt thông báo" kinh niên của Gmail, Facebook, Messenger, Zalo trên Honor:
 * 1. Ép Standby Bucket sang ACTIVE liên tục.
 * 2. Vô hiệu hóa và chặn đứng các tiến trình diệt ngầm của Honor: PowerGenius (com.hihonor.powergenius),
 *    iAware (com.hihonor.iaware), PowerGenie cũ.
 * 3. Whitelist Doze / DeviceIdle vĩnh viễn cho GMS, FCM, Gmail, Facebook, Messenger.
 * 4. Kích hoạt định kỳ bộ thu C2DM/FCM Broadcast và Network Connectivity Sync.
 * 5. Cấp toàn quyền AppOps chạy ngầm, WAKE_LOCK, POST_NOTIFICATION, AUTO_START.
 */
object AutoWakeupPatrolManager {

    private const val PREFS_NAME = "magictune_wakeup_prefs"
    private const val KEY_ENABLED = "auto_wakeup_enabled"
    private const val KEY_LAST_PULSE = "last_wakeup_pulse_ms"

    // Chu kỳ tuần tra đánh thức định kỳ: 5 phút (300.000 ms)
    private const val PULSE_INTERVAL_MS = 5 * 60 * 1000L

    private val patrolScope = CoroutineScope(Dispatchers.IO)
    private var lastRunElapsed = 0L

    fun isAutoWakeupEnabled(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(KEY_ENABLED, true) // Mặc định BẬT để bảo vệ thông báo
    }

    fun setAutoWakeupEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_ENABLED, enabled)
            .apply()
    }

    /**
     * Kịch bản AI Đặc Trị Khắc Phục Triệt Để 100% Thông Báo Gmail & Facebook Honor:
     * Chạy ngay lập tức khi người dùng yêu cầu AI hoặc bật tính năng.
     */
    fun performHonorNotificationDeepFix(context: Context, onComplete: ((Boolean) -> Unit)? = null) {
        patrolScope.launch {
            try {
                val shell = ShellEngine.getInstance(context.applicationContext)
                val criticalApps = listOf(
                    context.packageName,
                    "com.google.android.gm",
                    "com.google.android.gms",
                    "com.facebook.katana",
                    "com.facebook.orca",
                    "com.zing.zalo",
                    "org.telegram.messenger",
                    "com.whatsapp"
                )

                val cmds = mutableListOf<String>()

                // 1. Vô hiệu hóa trình dìm ngầm độc quyền của MagicOS / Honor (Dùng pm disable an toàn không lỗi)
                cmds.add("pm disable com.hihonor.powergenius 2>/dev/null || pm disable-user --user 0 com.hihonor.powergenius 2>/dev/null")
                cmds.add("pm disable com.hihonor.iaware 2>/dev/null || pm disable-user --user 0 com.hihonor.iaware 2>/dev/null")
                cmds.add("pm disable com.huawei.powergenie 2>/dev/null || pm disable-user --user 0 com.huawei.powergenie 2>/dev/null")

                // 2. Tắt chế độ "Thông báo nhẹ nhàng" (Gentle Notification) - nguyên nhân gây tịt chuông và ẩn banner trên Honor
                cmds.add("settings put system gentle_notification_enabled 0")
                cmds.add("settings put system hw_notification_gentle_switch 0")
                cmds.add("settings put global heads_up_notifications_enabled 1")
                cmds.add("settings put system notification_banner_enabled 1")
                cmds.add("settings put system lock_screen_notification_style 0")
                cmds.add("settings put system lock_screen_details_notification 1")
                cmds.add("settings put secure lock_screen_show_notifications 1")
                cmds.add("settings put secure lock_screen_allow_private_notifications 1")
                cmds.add("settings put system lock_screen_show_notifications 1")

                // 3. Tối ưu JobScheduler và Network Policy để nhận push tức thì không gom lô (batching)
                cmds.add("settings put global job_scheduler_constants \"min_ready_non_active_jobs_count=1,max_non_active_job_batch_delay_ms=0\"")
                cmds.add("device_config put jobscheduler min_ready_non_active_jobs_count 1 2>/dev/null")
                cmds.add("device_config put jobscheduler max_non_active_job_batch_delay_ms 0 2>/dev/null")

                // 4. Mở khóa toàn diện AppOps & Whitelist cho Gmail, Facebook, GMS, Zalo
                for (pkg in criticalApps) {
                    cmds.add("am set-standby-bucket $pkg active 2>/dev/null")
                    cmds.add("dumpsys deviceidle whitelist +$pkg 2>/dev/null")
                    cmds.add("cmd netpolicy add restrict-background-whitelist $(pm list packages -U | grep $pkg | awk -F 'uid:' '{print \$2}') 2>/dev/null")
                    cmds.add("cmd appops set $pkg RUN_IN_BACKGROUND allow 2>/dev/null")
                    cmds.add("cmd appops set --uid $pkg RUN_IN_BACKGROUND allow 2>/dev/null")
                    cmds.add("cmd appops set $pkg RUN_ANY_IN_BACKGROUND allow 2>/dev/null")
                    cmds.add("cmd appops set $pkg START_FOREGROUND allow 2>/dev/null")
                    cmds.add("cmd appops set $pkg POST_NOTIFICATION allow 2>/dev/null")
                    cmds.add("cmd appops set $pkg WAKE_LOCK allow 2>/dev/null")
                    cmds.add("cmd appops set $pkg TURN_SCREEN_ON allow 2>/dev/null")
                    cmds.add("cmd appops set $pkg GET_USAGE_STATS allow 2>/dev/null")
                    cmds.add("cmd appops set $pkg AUTO_START allow 2>/dev/null")
                    cmds.add("cmd appops set $pkg SYSTEM_ALERT_WINDOW allow 2>/dev/null")
                }

                // 5. Kích hoạt xung nhịp đánh thức ngầm tức thì cho Google Sync & Facebook
                cmds.add("am broadcast -a com.google.android.c2dm.intent.RECEIVE -p com.google.android.gms --ei google.delivered_priority 1 2>/dev/null")
                cmds.add("am broadcast -a android.net.conn.CONNECTIVITY_CHANGE -p com.google.android.gm 2>/dev/null")
                cmds.add("am broadcast -a android.net.conn.CONNECTIVITY_CHANGE -p com.facebook.katana 2>/dev/null")
                cmds.add("am broadcast -a android.net.conn.CONNECTIVITY_CHANGE -p com.facebook.orca 2>/dev/null")
                cmds.add("am broadcast -a android.net.conn.CONNECTIVITY_CHANGE -p com.zing.zalo 2>/dev/null")

                val result = shell.execute(cmds.joinToString("\n"))
                lastRunElapsed = SystemClock.elapsedRealtime()

                context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                    .edit()
                    .putLong(KEY_LAST_PULSE, System.currentTimeMillis())
                    .apply()

                onComplete?.invoke(result.exitCode == 0)
            } catch (_: Exception) {
                onComplete?.invoke(false)
            }
        }
    }

    /**
     * Gửi xung nhịp định kỳ đánh thức ngầm các ứng dụng bị MagicOS dìm (Gmail, FCM, Facebook, Zalo...)
     */
    fun performSilentPulseIfDue(context: Context) {
        if (!isAutoWakeupEnabled(context)) return

        val now = SystemClock.elapsedRealtime()
        if (now - lastRunElapsed < PULSE_INTERVAL_MS && lastRunElapsed != 0L) {
            return
        }
        lastRunElapsed = now

        patrolScope.launch {
            try {
                val shell = ShellEngine.getInstance(context.applicationContext)
                val myPkg = context.packageName
                val criticalApps = listOf(
                    myPkg,
                    "com.google.android.gm",
                    "com.google.android.gms",
                    "com.facebook.katana",
                    "com.facebook.orca",
                    "com.zing.zalo",
                    "org.telegram.messenger",
                    "com.whatsapp"
                )

                val bucketCommands = criticalApps.map { "am set-standby-bucket $it active 2>/dev/null" }
                val whitelistCommands = criticalApps.map { "dumpsys deviceidle whitelist +$it 2>/dev/null" }
                val wakeCommands = listOf(
                    "am broadcast -a com.google.android.c2dm.intent.RECEIVE -p com.google.android.gms --ei google.delivered_priority 1 2>/dev/null",
                    "am broadcast -a android.net.conn.CONNECTIVITY_CHANGE -p com.google.android.gm 2>/dev/null",
                    "am broadcast -a android.net.conn.CONNECTIVITY_CHANGE -p com.facebook.katana 2>/dev/null",
                    "am broadcast -a android.net.conn.CONNECTIVITY_CHANGE -p com.facebook.orca 2>/dev/null",
                    "am broadcast -a android.net.conn.CONNECTIVITY_CHANGE -p com.zing.zalo 2>/dev/null"
                )

                val allCommands = bucketCommands + whitelistCommands + wakeCommands
                shell.execute(allCommands.joinToString("\n"))

                context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                    .edit()
                    .putLong(KEY_LAST_PULSE, System.currentTimeMillis())
                    .apply()
            } catch (_: Exception) {}
        }
    }
}
