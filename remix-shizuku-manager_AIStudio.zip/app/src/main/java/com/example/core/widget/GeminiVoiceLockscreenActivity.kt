package com.example.core.widget

import android.app.Activity
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import android.widget.Toast
import com.example.core.service.SystemFloatingHudOverlay

/**
 * Activity trong suốt chuyên dụng để gọi Gemini Voice AI từ Màn Hình Khóa (Lockscreen Notification)
 * hoặc Thanh Thông Báo.
 *
 * Cơ chế hoạt động trên máy Honor / MagicOS nội địa (vốn bị khóa "OK Google" / Voice Match):
 * 1. Khi người dùng chạm vào nút "🎙️ Gemini" trên thông báo ghim ở màn hình khóa:
 * 2. Hệ thống tự động kích hoạt Mở khóa bằng khuôn mặt (Face Unlock / Vân tay).
 *    - Nếu khuôn mặt đã được nhận diện sẵn trên màn hình khóa Honor, Keyguard sẽ mở khóa tức thì (0ms).
 *    - Nếu đang khóa, KeyguardManager.requestDismissKeyguard() sẽ yêu cầu Face Unlock mở khóa rồi tự động
 *      gọi thẳng vào Gemini Voice ngay lập tức.
 */
class GeminiVoiceLockscreenActivity : Activity() {

    private val mainHandler = Handler(Looper.getMainLooper())
    private var hasTriggered = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Đảm bảo màn hình sáng lên nếu người dùng chạm từ màn hình khóa đang tối
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
            )
        }

        handleUnlockAndLaunchGemini()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        hasTriggered = false
        handleUnlockAndLaunchGemini()
    }

    private fun handleUnlockAndLaunchGemini() {
        val keyguardManager = getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager

        if (keyguardManager != null && keyguardManager.isKeyguardLocked) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                keyguardManager.requestDismissKeyguard(
                    this,
                    object : KeyguardManager.KeyguardDismissCallback() {
                        override fun onDismissSucceeded() {
                            super.onDismissSucceeded()
                            // Ngay khi mở khóa bằng khuôn mặt / vân tay thành công -> Bật Gemini Voice ngay
                            mainHandler.postDelayed({
                                triggerGeminiVoiceAndFinish()
                            }, 80L)
                        }

                        override fun onDismissCancelled() {
                            super.onDismissCancelled()
                            finishSilently()
                        }

                        override fun onDismissError() {
                            super.onDismissError()
                            triggerGeminiVoiceAndFinish()
                        }
                    }
                )
            } else {
                @Suppress("DEPRECATION")
                window.addFlags(WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD)
                mainHandler.postDelayed({
                    triggerGeminiVoiceAndFinish()
                }, 100L)
            }
        } else {
            // Đã mở khóa (hoặc Face Unlock đã mở khóa ngay khi chạm thông báo)
            triggerGeminiVoiceAndFinish()
        }
    }

    private fun triggerGeminiVoiceAndFinish() {
        if (hasTriggered) return
        hasTriggered = true

        val hasMicPerm = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) ==
                android.content.pm.PackageManager.PERMISSION_GRANTED
        } else {
            true
        }

        if (!hasMicPerm && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                requestPermissions(arrayOf(android.Manifest.permission.RECORD_AUDIO), 101)
                return
            } catch (_: Throwable) {}
        }

        launchOverlayAndFinishNow()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        launchOverlayAndFinishNow()
    }

    private fun launchOverlayAndFinishNow() {
        try {
            // Khi Activity đang ở trạng thái Foreground (PROCESS_STATE_TOP), lập tức nâng cấp
            // MagicTuneKeepAliveService lên FOREGROUND_SERVICE_TYPE_MICROPHONE để Android 14/15/16/MagicOS
            // giữ quyền thu âm Micro xuyên suốt mọi câu hội thoại mà không bao giờ bị thu hồi ngầm!
            com.example.core.service.MagicTuneKeepAliveService.ensureMicrophoneForeground(this)
            SystemFloatingHudOverlay.releaseMicrophoneForGeminiImmediately(this)

            val reacquireOnly = intent?.getBooleanExtra(EXTRA_REACQUIRE_MIC_ONLY, false) == true
            if (!reacquireOnly) {
                val shown = GeminiLiveFloatingOverlay.showAndStartListening(applicationContext)
                if (!shown) {
                    val opened = GeminiLiveFloatingOverlay.openOfficialGeminiAppAndYieldMic(this)
                    if (!opened) {
                        Toast.makeText(
                            applicationContext,
                            "Vui lòng cấp quyền Hiển thị trên ứng dụng khác cho MagicTune để bật Gemini Voice nổi!",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
            }
        } catch (_: Throwable) {
        }
        mainHandler.postDelayed({
            finishSilently()
        }, 120L)
    }

    private fun finishSilently() {
        try {
            finish()
            @Suppress("DEPRECATION")
            overridePendingTransition(0, 0)
        } catch (_: Throwable) {}
    }

    companion object {
        private const val EXTRA_REACQUIRE_MIC_ONLY = "extra_reacquire_mic_only"

        fun launchFromOverlay(context: Context, reacquireMicOnly: Boolean = false): Boolean {
            return try {
                val intent = Intent(context, GeminiVoiceLockscreenActivity::class.java).apply {
                    putExtra(EXTRA_REACQUIRE_MIC_ONLY, reacquireMicOnly)
                    addFlags(
                        Intent.FLAG_ACTIVITY_NEW_TASK or
                            Intent.FLAG_ACTIVITY_CLEAR_TOP or
                            Intent.FLAG_ACTIVITY_SINGLE_TOP or
                            Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS or
                            Intent.FLAG_ACTIVITY_NO_ANIMATION
                    )
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                    val options = android.app.ActivityOptions.makeBasic().apply {
                        setPendingIntentBackgroundActivityStartMode(
                            @Suppress("DEPRECATION") android.app.ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED
                        )
                    }
                    context.startActivity(intent, options.toBundle())
                } else {
                    context.startActivity(intent)
                }
                true
            } catch (_: Throwable) {
                false
            }
        }
    }
}
