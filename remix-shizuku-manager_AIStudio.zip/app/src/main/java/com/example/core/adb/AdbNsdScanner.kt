package com.example.core.adb

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean

data class AdbNsdState(
    val isScanning: Boolean = false,
    val pairingPort: Int? = null,
    val pairingHost: String? = null,
    val pairingServiceName: String? = null,
    val connectPort: Int? = null,
    val connectHost: String? = null,
    val connectServiceName: String? = null,
    val statusText: String = "Chưa quét dịch vụ mDNS"
)

/**
 * Module NsdManager (Network Service Discovery) chuẩn Shizuku:
 * Tự động lắng nghe 2 dịch vụ mDNS của Android Wireless Debugging:
 * 1. `_adb-tls-pairing._tcp` -> Tự động phát hiện và điền cổng ghép nối (Pairing Port) 5 số khi mở hộp thoại mã ghép đôi.
 * 2. `_adb-tls-connect._tcp` -> Tự động phát hiện và điền cổng kết nối chính (Connect Port) 5 số khi bật Gỡ lỗi qua Wi-Fi.
 */
class AdbNsdScanner(private val context: Context) {

    companion object {
        private const val TAG = "AdbNsdScanner"
        const val SERVICE_TYPE_PAIRING = "_adb-tls-pairing._tcp"
        const val SERVICE_TYPE_CONNECT = "_adb-tls-connect._tcp"

        @Volatile
        private var instance: AdbNsdScanner? = null

        fun getInstance(context: Context): AdbNsdScanner {
            return instance ?: synchronized(this) {
                instance ?: AdbNsdScanner(context.applicationContext).also { instance = it }
            }
        }
    }

    private val nsdManager: NsdManager? by lazy {
        context.getSystemService(Context.NSD_SERVICE) as? NsdManager
    }

    private val wifiManager: WifiManager? by lazy {
        context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
    }

    private var multicastLock: WifiManager.MulticastLock? = null
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private val _state = MutableStateFlow(AdbNsdState())
    val state: StateFlow<AdbNsdState> = _state.asStateFlow()

    private val isPairingDiscoveryActive = AtomicBoolean(false)
    private val isConnectDiscoveryActive = AtomicBoolean(false)

    private var pairingDiscoveryListener: NsdManager.DiscoveryListener? = null
    private var connectDiscoveryListener: NsdManager.DiscoveryListener? = null

    var onPairingPortDiscovered: ((port: Int, host: String) -> Unit)? = null
    var onConnectPortDiscovered: ((port: Int, host: String) -> Unit)? = null

    @Volatile
    var lastKnownConnectPort: Int? = null
        private set

    /**
     * Đọc trực tiếp cổng TLS của Wireless Debugging từ SystemProperties (`service.adb.tls.port`)
     * làm radar dự phòng tức thì khi mDNS bị trễ trên MagicOS.
     */
    fun readSystemAdbTlsPort(): Int? {
        try {
            val spClass = Class.forName("android.os.SystemProperties")
            val getMethod = spClass.getMethod("get", String::class.java, String::class.java)
            val raw = (getMethod.invoke(null, "service.adb.tls.port", "") as? String)?.trim().orEmpty()
            val port = raw.toIntOrNull()
            if (port != null && port in 1024..65535) return port
        } catch (_: Throwable) {}
        return null
    }

    /**
     * Trả về cổng kết nối ADB tốt nhất hiện có (từ mDNS hiện tại, bộ nhớ đệm mDNS gần nhất, hoặc SystemProperties).
     */
    fun getBestConnectPort(): Int? {
        _state.value.connectPort?.takeIf { it in 1..65535 }?.let { return it }
        lastKnownConnectPort?.takeIf { it in 1..65535 }?.let { return it }
        readSystemAdbTlsPort()?.let { sysPort ->
            lastKnownConnectPort = sysPort
            _state.value = _state.value.copy(connectPort = sysPort)
            return sysPort
        }
        return null
    }

    /**
     * Bắt đầu lắng nghe đồng thời cả _adb-tls-pairing._tcp và _adb-tls-connect._tcp.
     */
    fun startDiscovery() {
        readSystemAdbTlsPort()?.let { sysPort ->
            lastKnownConnectPort = sysPort
            if (_state.value.connectPort == null) {
                _state.value = _state.value.copy(connectPort = sysPort)
            }
        }

        val manager = nsdManager ?: run {
            _state.value = _state.value.copy(
                isScanning = false,
                statusText = "Thiết bị không hỗ trợ NsdManager"
            )
            return
        }

        acquireMulticastLock()

        _state.value = _state.value.copy(
            isScanning = true,
            statusText = "Đang lắng nghe _adb-tls-pairing._tcp & _adb-tls-connect._tcp..."
        )

        startPairingDiscovery(manager)
        startConnectDiscovery(manager)
    }

    /**
     * Làm mới riêng bộ quét cổng chính `_adb-tls-connect._tcp` ngay sau khi ghép nối mã PIN thành công
     * để bắt lại tức thì cổng kết nối mà không làm mất trạng thái đã lưu.
     */
    fun refreshConnectDiscovery() {
        readSystemAdbTlsPort()?.let { sysPort ->
            lastKnownConnectPort = sysPort
            _state.value = _state.value.copy(connectPort = sysPort)
            onConnectPortDiscovered?.invoke(sysPort, _state.value.connectHost ?: "127.0.0.1")
        }
        val manager = nsdManager ?: return
        acquireMulticastLock()
        if (!isConnectDiscoveryActive.get()) {
            startConnectDiscovery(manager)
        }
    }

    /**
     * Làm mới tiến trình quét dịch vụ mDNS (_adb-tls-pairing._tcp & _adb-tls-connect._tcp).
     */
    fun refreshDiscovery() {
        stopDiscovery()
        startDiscovery()
    }

    /**
     * Dừng toàn bộ tiến trình quét NSD và giải phóng MulticastLock.
     */
    fun stopDiscovery() {
        val manager = nsdManager
        if (manager != null) {
            if (isPairingDiscoveryActive.compareAndSet(true, false)) {
                try {
                    pairingDiscoveryListener?.let { manager.stopServiceDiscovery(it) }
                } catch (e: Exception) {
                    Log.w(TAG, "Stop pairing discovery error", e)
                }
            }
            if (isConnectDiscoveryActive.compareAndSet(true, false)) {
                try {
                    connectDiscoveryListener?.let { manager.stopServiceDiscovery(it) }
                } catch (e: Exception) {
                    Log.w(TAG, "Stop connect discovery error", e)
                }
            }
        }
        pairingDiscoveryListener = null
        connectDiscoveryListener = null
        releaseMulticastLock()

        _state.value = _state.value.copy(
            isScanning = false,
            statusText = "Đã dừng quét dịch vụ mDNS"
        )
    }

    private fun acquireMulticastLock() {
        try {
            if (multicastLock == null) {
                multicastLock = wifiManager?.createMulticastLock("magictune_adb_nsd_lock")?.apply {
                    setReferenceCounted(false)
                }
            }
            if (multicastLock?.isHeld == false) {
                multicastLock?.acquire()
            }
        } catch (e: Exception) {
            Log.w(TAG, "Could not acquire MulticastLock", e)
        }
    }

    private fun releaseMulticastLock() {
        try {
            if (multicastLock?.isHeld == true) {
                multicastLock?.release()
            }
        } catch (e: Exception) {
            Log.w(TAG, "Could not release MulticastLock", e)
        }
    }

    private fun startPairingDiscovery(manager: NsdManager) {
        if (isPairingDiscoveryActive.get()) return

        val listener = object : NsdManager.DiscoveryListener {
            override fun onStartDiscoveryFailed(serviceType: String?, errorCode: Int) {
                Log.w(TAG, "Pairing discovery start failed: $errorCode")
                isPairingDiscoveryActive.set(false)
            }

            override fun onStopDiscoveryFailed(serviceType: String?, errorCode: Int) {
                isPairingDiscoveryActive.set(false)
            }

            override fun onDiscoveryStarted(serviceType: String?) {
                Log.d(TAG, "Started NSD discovery for $serviceType")
                isPairingDiscoveryActive.set(true)
            }

            override fun onDiscoveryStopped(serviceType: String?) {
                Log.d(TAG, "Stopped NSD discovery for $serviceType")
                isPairingDiscoveryActive.set(false)
            }

            override fun onServiceFound(serviceInfo: NsdServiceInfo?) {
                if (serviceInfo == null) return
                Log.d(TAG, "Found pairing service: ${serviceInfo.serviceName}")
                resolveDiscoveredService(manager, serviceInfo, isPairing = true)
            }

            override fun onServiceLost(serviceInfo: NsdServiceInfo?) {
                if (serviceInfo == null) return
                Log.d(TAG, "Lost pairing service: ${serviceInfo.serviceName}")
                if (_state.value.pairingServiceName == serviceInfo.serviceName) {
                    _state.value = _state.value.copy(
                        pairingPort = null,
                        pairingServiceName = null,
                        statusText = "Cửa sổ mã ghép đôi đã đóng • Đang kết nối cổng chính..."
                    )
                }
            }
        }

        pairingDiscoveryListener = listener
        try {
            manager.discoverServices(SERVICE_TYPE_PAIRING, NsdManager.PROTOCOL_DNS_SD, listener)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start pairing discovery", e)
        }
    }

    private fun startConnectDiscovery(manager: NsdManager) {
        if (isConnectDiscoveryActive.get()) return

        val listener = object : NsdManager.DiscoveryListener {
            override fun onStartDiscoveryFailed(serviceType: String?, errorCode: Int) {
                Log.w(TAG, "Connect discovery start failed: $errorCode")
                isConnectDiscoveryActive.set(false)
            }

            override fun onStopDiscoveryFailed(serviceType: String?, errorCode: Int) {
                isConnectDiscoveryActive.set(false)
            }

            override fun onDiscoveryStarted(serviceType: String?) {
                Log.d(TAG, "Started NSD discovery for $serviceType")
                isConnectDiscoveryActive.set(true)
            }

            override fun onDiscoveryStopped(serviceType: String?) {
                Log.d(TAG, "Stopped NSD discovery for $serviceType")
                isConnectDiscoveryActive.set(false)
            }

            override fun onServiceFound(serviceInfo: NsdServiceInfo?) {
                if (serviceInfo == null) return
                Log.d(TAG, "Found connect service: ${serviceInfo.serviceName}")
                resolveDiscoveredService(manager, serviceInfo, isPairing = false)
            }

            override fun onServiceLost(serviceInfo: NsdServiceInfo?) {
                if (serviceInfo == null) return
                // Không xóa trắng connectPort khi người dùng mở hộp thoại ghép nối hoặc kéo thanh thông báo,
                // chỉ xóa nếu tính năng Gỡ lỗi qua Wi-Fi thực sự bị tắt trong Cài đặt hệ thống.
                val adbWifiStillOn = try {
                    android.provider.Settings.Global.getInt(context.contentResolver, "adb_wifi_enabled", 1) == 1
                } catch (_: Exception) { true }
                if (!adbWifiStillOn && _state.value.connectServiceName == serviceInfo.serviceName) {
                    lastKnownConnectPort = null
                    _state.value = _state.value.copy(
                        connectPort = null,
                        connectServiceName = null
                    )
                }
            }
        }

        connectDiscoveryListener = listener
        try {
            manager.discoverServices(SERVICE_TYPE_CONNECT, NsdManager.PROTOCOL_DNS_SD, listener)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start connect discovery", e)
        }
    }

    private val resolveMutex = kotlinx.coroutines.sync.Mutex()

    private fun resolveDiscoveredService(
        manager: NsdManager,
        serviceInfo: NsdServiceInfo,
        isPairing: Boolean
    ) {
        scope.launch {
            resolveMutex.lock()
            try {
                var attempts = 0
                var resolved: NsdServiceInfo? = null
                while (attempts < 3 && resolved == null) {
                    attempts++
                    resolved = resolveSingleServiceSuspended(manager, serviceInfo)
                    if (resolved == null && attempts < 3) {
                        kotlinx.coroutines.delay(250L * attempts)
                    }
                }
                if (resolved != null) {
                    handleResolvedServiceInfo(resolved, isPairing)
                }
            } catch (e: Exception) {
                Log.w(TAG, "Queued resolveService exception", e)
            } finally {
                resolveMutex.unlock()
            }
        }
    }

    private suspend fun resolveSingleServiceSuspended(
        manager: NsdManager,
        serviceInfo: NsdServiceInfo
    ): NsdServiceInfo? = kotlinx.coroutines.withTimeoutOrNull(2500L) {
        kotlinx.coroutines.suspendCancellableCoroutine { cont ->
            val hasResumed = java.util.concurrent.atomic.AtomicBoolean(false)
            fun safeResume(result: NsdServiceInfo?) {
                if (hasResumed.compareAndSet(false, true)) {
                    try {
                        if (cont.isActive) {
                            cont.resumeWith(Result.success(result))
                        }
                    } catch (_: Throwable) {}
                }
            }
            try {
                @Suppress("DEPRECATION")
                manager.resolveService(serviceInfo, object : NsdManager.ResolveListener {
                    override fun onResolveFailed(info: NsdServiceInfo?, errorCode: Int) {
                        Log.w(TAG, "Resolve failed ($errorCode) for ${info?.serviceName}")
                        safeResume(null)
                    }

                    override fun onServiceResolved(resolvedInfo: NsdServiceInfo?) {
                        safeResume(resolvedInfo)
                    }
                })
            } catch (e: Throwable) {
                safeResume(null)
            }
        }
    }

    private fun handleResolvedServiceInfo(resolvedInfo: NsdServiceInfo, isPairing: Boolean) {
        val port = resolvedInfo.port
        if (port <= 0) return

        @Suppress("DEPRECATION")
        val hostAddress = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            val ipv4 = resolvedInfo.hostAddresses.firstOrNull {
                it is java.net.Inet4Address && !it.isLoopbackAddress
            }?.hostAddress
            ipv4 ?: "127.0.0.1"
        } else {
            val raw = resolvedInfo.host?.hostAddress
            if (raw != null && !raw.contains(":")) raw else "127.0.0.1"
        }

        if (isPairing) {
            Log.i(TAG, "✅ Resolved _adb-tls-pairing._tcp -> $hostAddress:$port")
            _state.value = _state.value.copy(
                pairingPort = port,
                pairingHost = hostAddress,
                pairingServiceName = resolvedInfo.serviceName,
                statusText = "🟢 Đã tự động bắt được cổng ghép nối: $port! Chỉ cần nhập mã PIN 6 số."
            )
            onPairingPortDiscovered?.invoke(port, hostAddress)
        } else {
            Log.i(TAG, "✅ Resolved _adb-tls-connect._tcp -> $hostAddress:$port")
            lastKnownConnectPort = port
            _state.value = _state.value.copy(
                connectPort = port,
                connectHost = hostAddress,
                connectServiceName = resolvedInfo.serviceName,
                statusText = if (_state.value.pairingPort != null) {
                    _state.value.statusText
                } else {
                    "🟢 Đã phát hiện cổng kết nối ADB: $port"
                }
            )
            onConnectPortDiscovered?.invoke(port, hostAddress)
        }
    }
}
