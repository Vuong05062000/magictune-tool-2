package com.example.core.assistant

import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import com.example.core.widget.GeminiLiveFloatingOverlay
import com.example.core.widget.GeminiVoiceLockscreenActivity

/**
 * Activity tiếp nhận sự kiện ASSIST & VOICE_ASSIST từ hệ điều hành Honor MagicOS.
 * Hoạt động ngay cả khi điện thoại đang KHÓA MÀN HÌNH (ShowWhenLocked + TurnScreenOn).
 */
class MagicTuneAssistantActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Cấu hình hiển thị đè trên màn hình khóa và bật màn hình sáng
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
            )
        }

        // Kích hoạt ngay hộp thoại Gemini Voice Nổi trực tiếp trên màn hình hiện tại
        val launched = GeminiLiveFloatingOverlay.showAndStartListening(this)
        if (!launched) {
            GeminiVoiceLockscreenActivity.launchFromOverlay(this)
        }

        finish()
    }
}
