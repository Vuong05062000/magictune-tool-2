package com.example.core.widget

import android.app.ActivityManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.widget.RemoteViews
import android.widget.Toast
import com.example.R
import com.example.core.shell.ShellEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.roundToInt

class MagicTuneMemoryWidgetProvider : AppWidgetProvider() {

    companion object {
        const val ACTION_BOOST_RAM = "com.example.core.widget.ACTION_BOOST_RAM"
        private val widgetScope = CoroutineScope(Dispatchers.IO)

        fun updateWidget(
            context: Context,
            appWidgetManager: AppWidgetManager,
            appWidgetId: Int,
            overrideStatus: String? = null
        ) {
            val views = RemoteViews(context.packageName, R.layout.widget_ram_rom_live)

            // 1. Đo RAM Thực Tế
            var ramUsedPct = 0
            var ramText = "Đang đọc..."
            try {
                val actManager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
                val memInfo = ActivityManager.MemoryInfo()
                actManager?.getMemoryInfo(memInfo)
                val totalRamGb = memInfo.totalMem.toDouble() / (1024 * 1024 * 1024)
                val availRamGb = memInfo.availMem.toDouble() / (1024 * 1024 * 1024)
                val usedRamGb = (totalRamGb - availRamGb).coerceAtLeast(0.0)
                ramUsedPct = if (totalRamGb > 0) ((usedRamGb / totalRamGb) * 100).roundToInt() else 0
                ramText = String.format(Locale.US, "%.1fG / %.0fGB (%d%%)", usedRamGb, totalRamGb, ramUsedPct)
            } catch (_: Exception) {}

            views.setTextViewText(R.id.widget_ram_text, ramText)
            views.setProgressBar(R.id.widget_ram_progress, 100, ramUsedPct, false)

            // 2. Đo Bộ Nhớ ROM Trong Thực Tế
            var romUsedPct = 0
            var romText = "Đang đọc..."
            try {
                val stat = StatFs(Environment.getDataDirectory().path)
                val blockSize = stat.blockSizeLong
                val totalBlocks = stat.blockCountLong
                val availableBlocks = stat.availableBlocksLong

                val totalRomGb = (totalBlocks * blockSize).toDouble() / (1024 * 1024 * 1024)
                val availRomGb = (availableBlocks * blockSize).toDouble() / (1024 * 1024 * 1024)
                val usedRomGb = (totalRomGb - availRomGb).coerceAtLeast(0.0)
                romUsedPct = if (totalRomGb > 0) ((usedRomGb / totalRomGb) * 100).roundToInt() else 0
                romText = String.format(Locale.US, "%.1fG / %.0fGB (%d%%)", usedRomGb, totalRomGb, romUsedPct)
            } catch (_: Exception) {}

            views.setTextViewText(R.id.widget_rom_text, romText)
            views.setProgressBar(R.id.widget_rom_progress, 100, romUsedPct, false)

            // Trạng thái tổng quát
            val status = overrideStatus ?: when {
                ramUsedPct > 85 -> "Cần dọn RAM"
                ramUsedPct > 70 -> "Ổn định"
                else -> "Rất mượt mà"
            }
            views.setTextViewText(R.id.widget_memory_status, status)

            // 1 CHẠM TỰ ĐỘNG DỌN SẠCH RAM & RÁC TRỰC TIẾP TỪ MÀN HÌNH CHÍNH
            val boostIntent = Intent(context, MagicTuneMemoryWidgetProvider::class.java).apply {
                action = ACTION_BOOST_RAM
            }
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                1004,
                boostIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_ram_rom_container, pendingIntent)

            appWidgetManager.updateAppWidget(appWidgetId, views)
        }
    }

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        for (appWidgetId in appWidgetIds) {
            updateWidget(context, appWidgetManager, appWidgetId)
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_BOOST_RAM) {
            val appWidgetManager = AppWidgetManager.getInstance(context)
            val componentName = ComponentName(context, MagicTuneMemoryWidgetProvider::class.java)
            val appWidgetIds = appWidgetManager.getAppWidgetIds(componentName)

            // 1. Phản hồi thị giác tức thì trên thẻ widget
            for (id in appWidgetIds) {
                updateWidget(context, appWidgetManager, id, overrideStatus = "⚡ Đang dọn RAM...")
            }

            // 2. Chạy giải phóng RAM ngầm
            widgetScope.launch {
                try {
                    val actManager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
                    val memBefore = ActivityManager.MemoryInfo()
                    actManager?.getMemoryInfo(memBefore)

                    // Danh sách các ứng dụng chat, mạng xã hội, tin nhắn TUYỆT ĐỐI BẢO VỆ (không bao giờ kill để 100% không trễ thông báo)
                    val protectedPackages = setOf(
                        "com.zing.zalo", "com.facebook.orca", "com.facebook.katana",
                        "com.google.android.gm", "com.viber.voip", "org.telegram.messenger",
                        "com.whatsapp", "com.google.android.apps.messaging", "com.instagram.android",
                        "com.shopee.vn", "com.lazada.vn", "com.ss.android.ugc.aweme", "com.zhiliaoapp.musically",
                        context.packageName
                    )

                    // Chỉ giải phóng tiến trình nền của các app rác / ứng dụng đã đóng không nằm trong danh sách bảo vệ
                    actManager?.runningAppProcesses?.forEach { proc ->
                        if (proc.pkgList != null && proc.importance >= ActivityManager.RunningAppProcessInfo.IMPORTANCE_CACHED) {
                            for (pkg in proc.pkgList) {
                                val isProtected = protectedPackages.contains(pkg) ||
                                    pkg.startsWith("com.google.android.gms") ||
                                    pkg.startsWith("com.hihonor.") ||
                                    pkg.startsWith("android")
                                if (!isProtected) {
                                    actManager.killBackgroundProcesses(pkg)
                                }
                            }
                        }
                    }

                    // Tối ưu hóa sâu qua Shell (Shizuku / ADB nếu có)
                    val shell = ShellEngine(context.applicationContext)
                    shell.execute("sync; echo 3 > /proc/sys/vm/drop_caches 2>/dev/null")
                    shell.execute("am trim-memory --all")

                    // Dọn bộ thu gom rác Java/Kotlin VM
                    System.gc()
                    Runtime.getRuntime().gc()

                    // Chờ 1 giây để bộ nhớ hệ thống ổn định
                    kotlinx.coroutines.delay(1000)

                    val memAfter = ActivityManager.MemoryInfo()
                    actManager?.getMemoryInfo(memAfter)
                    val freedMb = ((memAfter.availMem - memBefore.availMem) / (1024 * 1024)).coerceAtLeast(0)

                    Handler(Looper.getMainLooper()).post {
                        val msg = if (freedMb > 50) {
                            "✨ Đã giải phóng ~${freedMb}MB RAM! Máy cực kỳ mượt mà"
                        } else {
                            "⚡ Đã dọn sạch RAM & Tối ưu bộ đệm thành công!"
                        }
                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()

                        for (id in appWidgetIds) {
                            updateWidget(context, appWidgetManager, id, overrideStatus = "Đã tối ưu ✨")
                        }
                    }
                } catch (e: Exception) {
                    Handler(Looper.getMainLooper()).post {
                        Toast.makeText(context, "⚡ Đã dọn sạch RAM!", Toast.LENGTH_SHORT).show()
                        for (id in appWidgetIds) {
                            updateWidget(context, appWidgetManager, id)
                        }
                    }
                }
            }
        }
    }
}
