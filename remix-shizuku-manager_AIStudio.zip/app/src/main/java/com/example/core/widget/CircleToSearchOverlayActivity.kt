package com.example.core.widget

import android.annotation.SuppressLint
import android.app.Activity
import android.app.ActivityOptions
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.ui.platform.LocalContext
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import android.speech.RecognizerIntent
import android.util.Base64
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import com.example.MainActivity
import com.example.core.license.LicenseManager
import com.example.core.service.MagicTuneCtsAccessibilityService
import com.example.core.shell.ShellEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.max

/**
 * Activity ÉP BẬT KHOANH TRÒN TÌM KIẾM & GOOGLE DỊCH MÀN HÌNH TỨC THÌ (Forced Circle to Search + Google Screen Translate)
 * dành riêng cho điện thoại Honor MagicOS (Hoạt động 100% NGAY CẢ KHI ĐÃ TẮT GỠ LỖI WLAN / TẮT SHIZUKU).
 *
 * Cơ chế hoạt động:
 * 1. Chụp màn hình ngầm siêu tốc (~80ms) kèm trích xuất toàn bộ tọa độ văn bản trên màn hình (~8ms)
 *    thông qua `MagicTuneCtsAccessibilityService`.
 * 2. Chế độ 🔍 Tìm Google: Khoanh tròn bất kỳ sản phẩm, vật thể, hình ảnh nào để tìm kiếm trên Google Lens.
 * 3. Chế độ 🌐 Google Dịch (Tức thì + Cuộn Đến Đâu Dịch Đến Đó cho Taobao, 1688, App Ngoại Ngữ):
 *    - Sử dụng 100% công cụ GOOGLE DỊCH (`translate.googleapis.com`) siêu tốc (~100ms), KHÔNG dùng Groq AI.
 *    - Tự động nhận diện và quy đổi giá tiền nước ngoài (Nhân dân tệ ¥/RMB/CNY, USD $, Won ₩, Yên 円...) sang VNĐ (đ).
 *    - Kích hoạt lớp phủ xuyên thấu (`GoogleLiveTranslateOverlay`) cho phép người dùng cuộn trang, bấm mua hàng
 *      trực tiếp trên Taobao / 1688 trong khi bản dịch Tiếng Việt (kích thước chữ nhỏ gọn 8.5sp - 9sp, tự động né nhau)
 *      cập nhật tức thì theo từng nhịp cuộn!
 */
class CircleToSearchOverlayActivity : ComponentActivity() {

    enum class LensMode(val code: String, val label: String) {
        SEARCH("un", "🔍 Kết Quả Google"),
        TRANSLATE("tr", "🌐 Google Dịch"),
        TEXT("text", "📝 Chép Chữ")
    }

    data class TranslatedTextBox(
        val ymin: Float,
        val xmin: Float,
        val ymax: Float,
        val xmax: Float,
        val originalText: String,
        val translatedText: String
    )

    data class GoogleTranslationResult(
        val translatedText: String,
        val originalText: String,
        val engineUsed: String = "Google Dịch + Tự đổi VNĐ",
        val isSuccess: Boolean,
        val boxes: List<TranslatedTextBox> = emptyList()
    )

    private var capturedBitmap by mutableStateOf<Bitmap?>(null)
    private var croppedPreviewBitmap by mutableStateOf<Bitmap?>(null)
    private var lastCroppedFile by mutableStateOf<File?>(null)
    private var lastCroppedJpegBase64 by mutableStateOf<String?>(null)
    private var lastSelectionBounds by mutableStateOf<Rect?>(null)
    private var isCapturing by mutableStateOf(true)
    private var isUploadingToGoogle by mutableStateOf(false)
    private var isTranslatingWithGoogle by mutableStateOf(false)
    private var googleTranslationResult by mutableStateOf<GoogleTranslationResult?>(null)
    private var baseLensResultUrl by mutableStateOf<String?>(null)
    private var activeLensMode by mutableStateOf(LensMode.SEARCH)
    private var uploadErrorMessage by mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Google Khoanh Tròn Tìm Kiếm & Google Lens: MỞ CHO TẤT CẢ NGƯỜI DÙNG (Không cần Pro)
        isOverlayActive = true
        activeInstanceRef = java.lang.ref.WeakReference(this)
        lastCreatedTimestampMs = System.currentTimeMillis()
        // Tự ẩn & thu nhỏ thụt nút điều hướng ảo xuống dưới để tránh bấm nhầm khi thao tác hàng nút chức năng Khoanh Tròn
        com.example.core.service.SystemFloatingHudOverlay.setNavBridgeSuppressedForOverlay(applicationContext, true)
        enableEdgeToEdge()
        @Suppress("DEPRECATION")
        overridePendingTransition(0, 0)

        // Nếu đang bật lớp phủ Dịch Cuộn Trực Tiếp thì tạm tắt để chụp màn hình sạch
        if (GoogleLiveTranslateOverlay.isRunning) {
            GoogleLiveTranslateOverlay.stop(applicationContext)
        }

        // Ép cửa sổ hiển thị toàn màn hình (bất kể app đang mở đa nhiệm, thu nhỏ hay chia đôi màn hình)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        window.setFlags(
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        )

        // Giữ cửa sổ trong suốt trong lúc chụp màn hình ứng dụng phía dưới
        window.decorView.alpha = 0f

        setContent {
            BackHandler(enabled = baseLensResultUrl != null || isUploadingToGoogle || isTranslatingWithGoogle || googleTranslationResult != null) {
                baseLensResultUrl = null
                isUploadingToGoogle = false
                isTranslatingWithGoogle = false
                googleTranslationResult = null
                uploadErrorMessage = null
            }

            ForcedCircleToSearchScreen(
                bitmap = capturedBitmap,
                croppedPreview = croppedPreviewBitmap,
                lastCroppedJpegBase64 = lastCroppedJpegBase64,
                selectionNormBounds = lastSelectionBounds,
                isCapturing = isCapturing,
                isUploadingToGoogle = isUploadingToGoogle,
                isTranslatingWithGoogle = isTranslatingWithGoogle,
                googleTranslationResult = googleTranslationResult,
                baseLensResultUrl = baseLensResultUrl,
                activeLensMode = activeLensMode,
                uploadErrorMessage = uploadErrorMessage,
                onSelectLensMode = { newMode ->
                    activeLensMode = newMode
                    if (newMode == LensMode.TRANSLATE) {
                        // Chuyển ngay sang tính năng Dịch màn hình xuyên thấu theo yêu cầu người dùng
                        GoogleLiveTranslateOverlay.start(this@CircleToSearchOverlayActivity)
                        Toast.makeText(this@CircleToSearchOverlayActivity, "🌐 Đã chuyển sang Dịch màn hình trực tiếp!", Toast.LENGTH_SHORT).show()
                        finish()
                    }
                },
                onCircleSelectionCompleted = { normLeft, normTop, normRight, normBottom, preferredMode ->
                    if (preferredMode == LensMode.TRANSLATE) {
                        translateRegionWithGoogleNow(
                            normLeft = normLeft,
                            normTop = normTop,
                            normRight = normRight,
                            normBottom = normBottom,
                            activateLiveScrollOverlay = false
                        )
                    } else {
                        processCroppedRegionAndSearchGoogle(
                            normLeft = normLeft,
                            normTop = normTop,
                            normRight = normRight,
                            normBottom = normBottom,
                            initialMode = preferredMode
                        )
                    }
                },
                onActivateInstantGoogleTranslateAndScroll = {
                    translateRegionWithGoogleNow(
                        normLeft = 0f,
                        normTop = 0f,
                        normRight = 1f,
                        normBottom = 1f,
                        activateLiveScrollOverlay = true
                    )
                },
                onSearchFullScreen = {
                    processCroppedRegionAndSearchGoogle(
                        normLeft = 0f,
                        normTop = 0f,
                        normRight = 1f,
                        normBottom = 1f,
                        initialMode = LensMode.SEARCH
                    )
                },
                onLaunchGoogleVoiceSearch = {
                    launchGoogleVoiceSearchNow()
                },
                onLaunchGeminiFloatingOverlay = {
                    launchGeminiFloatingOverlayAndYield()
                },
                onOpenExternalLensApp = {
                    val file = lastCroppedFile
                    if (file != null && file.exists()) {
                        if (!sendImageToExternalGoogleLens(file)) {
                            baseLensResultUrl?.let { url ->
                                try {
                                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    })
                                } catch (_: Exception) {}
                            }
                        }
                    }
                },
                onResetCircleSelection = {
                    baseLensResultUrl = null
                    isUploadingToGoogle = false
                    isTranslatingWithGoogle = false
                    googleTranslationResult = null
                    lastSelectionBounds = null
                    uploadErrorMessage = null
                },
                onDismiss = {
                    finishWithoutAnimation()
                }
            )
        }

        captureScreenBehindAndShowOverlay()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        com.example.core.service.SystemFloatingHudOverlay.setNavBridgeSuppressedForOverlay(applicationContext, true)
        val now = System.currentTimeMillis()
        if (now - lastCreatedTimestampMs < 900L) {
            // Tránh chụp đúp khi lệnh dự phòng am start chạy ngay sau launch()
            return
        }
        lastCreatedTimestampMs = now
        baseLensResultUrl = null
        isUploadingToGoogle = false
        isTranslatingWithGoogle = false
        googleTranslationResult = null
        lastSelectionBounds = null
        uploadErrorMessage = null
        isCapturing = true
        captureScreenBehindAndShowOverlay()
    }

    override fun onResume() {
        super.onResume()
        isOverlayActive = true
        com.example.core.service.SystemFloatingHudOverlay.setNavBridgeSuppressedForOverlay(applicationContext, true)
    }

    override fun onPause() {
        super.onPause()
        if (isFinishing) {
            com.example.core.service.SystemFloatingHudOverlay.setNavBridgeSuppressedForOverlay(applicationContext, false)
        }
    }

    override fun onDestroy() {
        isOverlayActive = false
        if (activeInstanceRef?.get() === this) {
            activeInstanceRef = null
        }
        com.example.core.service.SystemFloatingHudOverlay.setNavBridgeSuppressedForOverlay(applicationContext, false)
        super.onDestroy()
        try {
            if (!GoogleLiveTranslateOverlay.isRunning) {
                MagicTuneCtsAccessibilityService.disableServiceViaSecureSettings(applicationContext)
            }
        } catch (_: Throwable) {}
    }

    /**
     * Chụp màn hình ứng dụng phía dưới (Hoạt động cả khi ĐÃ TẮT GỠ LỖI WLAN lẫn khi đang bật ADB/Shizuku).
     */
    private fun captureScreenBehindAndShowOverlay() {
        lifecycleScope.launch {
            window.decorView.alpha = 0f
            delay(55L)

            // Tầng 1: Chụp màn hình Offline + Trích xuất toàn bộ tọa độ văn bản trên màn hình qua AccessibilityService (Hoàn toàn trên IO)
            var bmp: Bitmap? = withContext(Dispatchers.IO) {
                MagicTuneCtsAccessibilityService.captureScreenOffline(applicationContext)
            }

            // Tầng 2: Dự phòng qua Shell nếu Accessibility chưa kịp kết nối ở lần chạy đầu tiên
            val shell = ShellEngine.getInstance(applicationContext)
            if (bmp == null && shell.state.value.isAdbReady) {
                bmp = withContext(Dispatchers.IO) {
                    try {
                        withTimeoutOrNull(2500L) {
                            val pkg = applicationContext.packageName
                            val sharedDir = externalCacheDir ?: cacheDir
                            if (!sharedDir.exists()) sharedDir.mkdirs()
                            val shotFile = File(sharedDir, "magictune_cts_capture.png")
                            if (shotFile.exists()) shotFile.delete()

                            shell.execute(
                                "cmd appops set $pkg ACCESS_RESTRICTED_SETTINGS allow >/dev/null 2>&1; " +
                                    "cmd appops set $pkg SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1; " +
                                    "cmd statusbar collapse >/dev/null 2>&1; " +
                                    "screencap -p '${shotFile.absolutePath}' >/dev/null 2>&1; " +
                                    "chmod 666 '${shotFile.absolutePath}' >/dev/null 2>&1 || true"
                            )

                            if (shotFile.exists() && shotFile.length() > 1024L) {
                                BitmapFactory.decodeFile(shotFile.absolutePath)
                            } else {
                                val tmpPath = "/data/local/tmp/magictune_cts.png"
                                shell.execute("screencap -p '$tmpPath' >/dev/null 2>&1; cp '$tmpPath' '${shotFile.absolutePath}' >/dev/null 2>&1; chmod 666 '${shotFile.absolutePath}' >/dev/null 2>&1 || true")
                                if (shotFile.exists() && shotFile.length() > 1024L) {
                                    BitmapFactory.decodeFile(shotFile.absolutePath)
                                } else {
                                    null
                                }
                            }
                        }
                    } catch (_: Throwable) {
                        null
                    }
                }
            }

            if (bmp == null) {
                bmp = withContext(Dispatchers.IO) {
                    MagicTuneCtsAccessibilityService.captureScreenOffline(applicationContext)
                }
            }

            capturedBitmap = bmp
            isCapturing = false
            window.decorView.alpha = 1f
            triggerGentleHaptic()
        }
    }

    /**
     * Dịch tức thì vùng chọn hoặc kích hoạt Lớp Phủ Xuyên Thấu "Cuộn Đến Đâu Dịch Đến Đó" 100% bằng GOOGLE DỊCH (`GoogleScreenTranslator`)
     * kèm quy đổi ngoại tệ sang VNĐ (Tệ ¥/RMB/CNY, USD $, Won ₩, Yên 円...).
     *
     * Khi `activateLiveScrollOverlay = true` (người dùng bấm nút "🌐 Google Dịch (Cuộn & Dịch)"),
     * hệ thống ĐÓNG NGAY màn hình ảnh chụp tĩnh (`finishWithoutAnimation()`) và gắn lớp phủ xuyên thấu
     * `GoogleLiveTranslateOverlay` (`FLAG_NOT_TOUCHABLE`) trực tiếp lên trên ứng dụng thực tế (Taobao, 1688)
     * để người dùng vừa chạm vuốt cuộn trang trực tiếp vừa xem bản dịch Tiếng Việt + giá tiền VNĐ thời gian thực!
     */
    private fun translateRegionWithGoogleNow(
        normLeft: Float,
        normTop: Float,
        normRight: Float,
        normBottom: Float,
        activateLiveScrollOverlay: Boolean
    ) {
        triggerGentleHaptic()

        if (activateLiveScrollOverlay) {
            lifecycleScope.launch {
                val dm = resources.displayMetrics
                val screenW = dm.widthPixels.coerceAtLeast(1)
                val screenH = dm.heightPixels.coerceAtLeast(1)

                if (!Settings.canDrawOverlays(applicationContext)) {
                    val shell = ShellEngine.getInstance(applicationContext)
                    if (shell.state.value.isAdbReady) {
                        withContext(Dispatchers.IO) {
                            try {
                                shell.execute("cmd appops set ${applicationContext.packageName} SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1")
                            } catch (_: Throwable) {}
                        }
                    }
                }

                // Lấy ngay các hộp giá tiền / bộ nhớ đệm từ node đã chụp (0ms) để hiện tức thì khi vừa đóng màn tĩnh
                val preCapturedNodes = MagicTuneCtsAccessibilityService.lastCapturedScreenNodes
                val (instantBoxes, _) = if (preCapturedNodes.isNotEmpty()) {
                    GoogleScreenTranslator.buildInstantCachedBoxesForNodes(preCapturedNodes, screenW, screenH)
                } else {
                    Pair(emptyList(), false)
                }

                val started = GoogleLiveTranslateOverlay.start(
                    context = applicationContext,
                    initialBoxes = instantBoxes
                )
                if (started) {
                    Toast.makeText(
                        applicationContext,
                        "🌐 Đã bật Dịch Cuộn Xuyên Thấu! Hãy vuốt cuộn trực tiếp trên Taobao/1688 để dịch & đổi VNĐ.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
                // Luôn đóng màn hình ảnh chụp tĩnh ngay lập tức để trả lại cảm ứng trực tiếp cho ứng dụng phía dưới!
                finishWithoutAnimation()
            }
            return
        }

        if (isTranslatingWithGoogle) return
        isTranslatingWithGoogle = true
        activeLensMode = LensMode.TRANSLATE
        uploadErrorMessage = null
        baseLensResultUrl = null
        lastSelectionBounds = Rect(normLeft, normTop, normRight, normBottom)

        lifecycleScope.launch {
            val dm = resources.displayMetrics
            val screenW = dm.widthPixels.coerceAtLeast(1)
            val screenH = dm.heightPixels.coerceAtLeast(1)

            var nodes = MagicTuneCtsAccessibilityService.lastCapturedScreenNodes
            if (nodes.isEmpty()) {
                nodes = withContext(Dispatchers.IO) {
                    MagicTuneCtsAccessibilityService.ensureServiceEnabledViaSecureSettings(applicationContext)
                    val liveNodes = MagicTuneCtsAccessibilityService.extractVisibleScreenNodesNow(applicationContext)
                    if (liveNodes.isNotEmpty()) {
                        liveNodes
                    } else {
                        GoogleScreenTranslator.extractNodesViaUiAutomatorFallback(applicationContext)
                    }
                }
            }

            val translatedBoxes = GoogleScreenTranslator.translateScreenNodesToBoxes(
                nodes = nodes,
                screenWidth = screenW,
                screenHeight = screenH,
                normRegion = Rect(normLeft, normTop, normRight, normBottom)
            )

            isTranslatingWithGoogle = false

            if (translatedBoxes.isNotEmpty()) {
                googleTranslationResult = GoogleTranslationResult(
                    translatedText = translatedBoxes.joinToString("\n") { it.translatedText },
                    originalText = translatedBoxes.joinToString("\n") { it.originalText },
                    engineUsed = "Google Dịch + Tự đổi VNĐ",
                    isSuccess = true,
                    boxes = translatedBoxes
                )
            } else {
                // Nếu vùng khoanh tròn là một bức ảnh tĩnh không chứa văn bản UI (node rỗng),
                // chuyển trực tiếp vùng ảnh đó sang Google Lens Dịch Ảnh (lns_mode=tr) của Google!
                processCroppedRegionAndSearchGoogle(
                    normLeft = normLeft,
                    normTop = normTop,
                    normRight = normRight,
                    normBottom = normBottom,
                    initialMode = LensMode.TRANSLATE,
                    forceOpenGoogleLensTranslateSheet = true
                )
            }
        }
    }

    /**
     * Cắt vùng người dùng vừa khoanh tròn và tải lên máy chủ Google Lens (`https://lens.google.com/v3/upload?hl=vi`).
     */
    private fun processCroppedRegionAndSearchGoogle(
        normLeft: Float,
        normTop: Float,
        normRight: Float,
        normBottom: Float,
        initialMode: LensMode,
        forceOpenGoogleLensTranslateSheet: Boolean = false
    ) {
        val sourceBitmap = capturedBitmap
        if (sourceBitmap == null) {
            Toast.makeText(
                this,
                "⚠️ Chưa chụp được màn hình. Hãy bấm 'Bật Ép Khoanh Tròn' trong MagicTune 1 lần khi đang kết nối để cấp quyền chụp không cần WLAN!",
                Toast.LENGTH_LONG
            ).show()
            return
        }

        if (isUploadingToGoogle) return
        isUploadingToGoogle = true
        activeLensMode = initialMode
        uploadErrorMessage = null
        baseLensResultUrl = null
        googleTranslationResult = null
        lastSelectionBounds = Rect(normLeft, normTop, normRight, normBottom)
        triggerGentleHaptic()

        lifecycleScope.launch {
            var preparedBase64 = ""
            val resultUrl = withContext(Dispatchers.IO) {
                try {
                    val swSource = if (sourceBitmap.config == Bitmap.Config.HARDWARE) {
                        sourceBitmap.copy(Bitmap.Config.ARGB_8888, false) ?: sourceBitmap
                    } else {
                        sourceBitmap
                    }

                    val w = swSource.width
                    val h = swSource.height

                    val leftPx = (normLeft * w).toInt().coerceIn(0, max(0, w - 20))
                    val topPx = (normTop * h).toInt().coerceIn(0, max(0, h - 20))
                    val rightPx = (normRight * w).toInt().coerceIn(leftPx + 20, w)
                    val bottomPx = (normBottom * h).toInt().coerceIn(topPx + 20, h)

                    val cropW = (rightPx - leftPx).coerceIn(20, w - leftPx)
                    val cropH = (bottomPx - topPx).coerceIn(20, h - topPx)

                    val rawCropped = Bitmap.createBitmap(swSource, leftPx, topPx, cropW, cropH)
                    croppedPreviewBitmap = rawCropped

                    try {
                        val outDir = File(cacheDir, "cts_shares").apply { if (!exists()) mkdirs() }
                        val outFile = File(outDir, "cts_region_latest.jpg")
                        FileOutputStream(outFile).use { fos ->
                            rawCropped.compress(Bitmap.CompressFormat.JPEG, 92, fos)
                            fos.flush()
                        }
                        lastCroppedFile = outFile
                    } catch (_: Throwable) {}

                    val maxDim = max(rawCropped.width, rawCropped.height)
                    val uploadBitmap = if (maxDim > 1280) {
                        val scale = 1280f / maxDim.toFloat()
                        val scaledW = (rawCropped.width * scale).toInt().coerceAtLeast(1)
                        val scaledH = (rawCropped.height * scale).toInt().coerceAtLeast(1)
                        Bitmap.createScaledBitmap(rawCropped, scaledW, scaledH, true)
                    } else {
                        rawCropped
                    }

                    val jpegBytes = ByteArrayOutputStream().use { baos ->
                        uploadBitmap.compress(Bitmap.CompressFormat.JPEG, 90, baos)
                        baos.toByteArray()
                    }
                    preparedBase64 = Base64.encodeToString(jpegBytes, Base64.NO_WRAP)

                    val uploaded = uploadImageBytesToGoogleLens(
                        jpegBytes = jpegBytes,
                        imgWidth = uploadBitmap.width,
                        imgHeight = uploadBitmap.height
                    )
                    uploaded ?: "DIRECT_WEBVIEW_UPLOAD"
                } catch (_: Throwable) {
                    "DIRECT_WEBVIEW_UPLOAD"
                }
            }

            lastCroppedJpegBase64 = preparedBase64
            isUploadingToGoogle = false
            baseLensResultUrl = resultUrl
            if (forceOpenGoogleLensTranslateSheet) {
                activeLensMode = LensMode.TRANSLATE
            }
        }
    }

    /**
     * Tải trực tiếp mảng byte JPEG của vùng vừa khoanh tròn lên máy chủ chính thức của Google Lens
     * (`https://lens.google.com/v3/upload?hl=vi`) và đồng bộ toàn bộ Cookie phiên làm việc sang WebView.
     */
    private fun uploadImageBytesToGoogleLens(
        jpegBytes: ByteArray,
        imgWidth: Int,
        imgHeight: Int
    ): String? {
        val boundary = "----MagicTuneLensBoundary${System.currentTimeMillis()}"
        val ts = System.currentTimeMillis()
        val endpoint = "https://lens.google.com/v3/upload?hl=vi&re=df&st=$ts&vpw=$imgWidth&vph=$imgHeight&ep=gsbubb"
        val userAgent = "Mozilla/5.0 (Linux; Android 14; SM-S928B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36"

        var conn: HttpURLConnection? = null
        return try {
            val cookieManager = CookieManager.getInstance()
            cookieManager.setAcceptCookie(true)
            val existingCookies = cookieManager.getCookie("https://lens.google.com")
                ?: cookieManager.getCookie("https://www.google.com")

            val url = URL(endpoint)
            conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                doInput = true
                instanceFollowRedirects = false
                connectTimeout = 12_000
                readTimeout = 15_000
                setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
                setRequestProperty("User-Agent", userAgent)
                setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8")
                setRequestProperty("Accept-Language", "vi-VN,vi;q=0.9,en-US;q=0.8")
                setRequestProperty("Origin", "https://lens.google.com")
                setRequestProperty("Referer", "https://lens.google.com/")
                if (!existingCookies.isNullOrBlank()) {
                    setRequestProperty("Cookie", existingCookies)
                }
            }

            conn.outputStream.use { os ->
                val header = buildString {
                    append("--").append(boundary).append("\r\n")
                    append("Content-Disposition: form-data; name=\"encoded_image\"; filename=\"cts_${imgWidth}x${imgHeight}.jpg\"\r\n")
                    append("Content-Type: image/jpeg\r\n\r\n")
                }
                os.write(header.toByteArray(Charsets.UTF_8))
                os.write(jpegBytes)
                val footer = "\r\n--$boundary--\r\n"
                os.write(footer.toByteArray(Charsets.UTF_8))
                os.flush()
            }

            val code = conn.responseCode

            try {
                val headerFields = conn.headerFields
                val cookies = headerFields["Set-Cookie"] ?: headerFields["set-cookie"]
                cookies?.forEach { cookieStr ->
                    cookieManager.setCookie("https://lens.google.com", cookieStr)
                    cookieManager.setCookie("https://www.google.com", cookieStr)
                }
                cookieManager.flush()
            } catch (_: Throwable) {}

            val locationHeader = conn.getHeaderField("Location")
            if ((code == 301 || code == 302 || code == 303 || code == 307 || code == 308) && !locationHeader.isNullOrBlank()) {
                val fullRedirect = if (locationHeader.startsWith("http")) {
                    locationHeader
                } else {
                    "https://lens.google.com$locationHeader"
                }
                if (!fullRedirect.contains("hl=vi")) "$fullRedirect&hl=vi" else fullRedirect
            } else {
                val body = try {
                    conn.inputStream.bufferedReader().use { it.readText() }
                } catch (_: Throwable) {
                    ""
                }
                val regexLens = Regex("""https://lens\.google\.com/search\?[^"'\s<>]+""")
                val regexGoogle = Regex("""https://www\.google\.com/search\?[^"'\s<>]+""")
                val found = (regexLens.find(body)?.value ?: regexGoogle.find(body)?.value)?.replace("&amp;", "&")
                if (!found.isNullOrBlank()) found else null
            }
        } catch (_: Throwable) {
            null
        } finally {
            try {
                conn?.disconnect()
            } catch (_: Throwable) {}
        }
    }

    /**
     * Chuyển ảnh vừa khoanh sang ứng dụng Google Lens cài trên máy (nếu người dùng bấm nút "Mở App Lens").
     */
    private fun sendImageToExternalGoogleLens(imageFile: File): Boolean {
        return try {
            val authority = "${applicationContext.packageName}.fileprovider"
            val contentUri: Uri = FileProvider.getUriForFile(this, authority, imageFile)

            val targetPackages = listOf(
                "com.google.ar.lens",
                "com.google.android.googlequicksearchbox"
            )
            for (pkg in targetPackages) {
                try {
                    grantUriPermission(pkg, contentUri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: Exception) {}
            }

            val baseSendIntent = Intent(Intent.ACTION_SEND).apply {
                type = "image/jpeg"
                putExtra(Intent.EXTRA_STREAM, contentUri)
                clipData = ClipData.newRawUri("CircleToSearch", contentUri)
                addFlags(
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or
                        Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_CLEAR_TOP
                )
            }

            val pm = packageManager
            val resolvedList = pm.queryIntentActivities(baseSendIntent, 0)
            val lensActivityInfo = resolvedList.firstOrNull { info ->
                val pkg = info.activityInfo.packageName
                val cls = info.activityInfo.name
                (pkg == "com.google.ar.lens" || pkg == "com.google.android.googlequicksearchbox") &&
                    cls.contains("lens", ignoreCase = true)
            } ?: resolvedList.firstOrNull { info ->
                info.activityInfo.packageName == "com.google.ar.lens"
            }

            if (lensActivityInfo != null) {
                val explicitLensIntent = Intent(baseSendIntent).apply {
                    setClassName(
                        lensActivityInfo.activityInfo.packageName,
                        lensActivityInfo.activityInfo.name
                    )
                }
                if (startActivitySafe(explicitLensIntent)) return true
            }

            for (pkg in targetPackages) {
                val pkgIntent = Intent(baseSendIntent).apply {
                    setPackage(pkg)
                }
                if (startActivitySafe(pkgIntent)) return true
            }
            false
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Mở trực tiếp hộp thoại Tìm Kiếm Giọng Nói chính gốc của App Google (`VoiceSearchActivity`).
     */
    private fun launchGoogleVoiceSearchNow() {
        triggerGentleHaptic()
        val candidates = listOf(
            Intent(RecognizerIntent.ACTION_WEB_SEARCH).apply {
                setClassName(
                    "com.google.android.googlequicksearchbox",
                    "com.google.android.googlequicksearchbox.VoiceSearchActivity"
                )
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_WEB_SEARCH)
                putExtra("com.google.android.voicesearch.extra.CALLED_FROM_SEARCH_PLATE", true)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            },
            Intent().apply {
                setClassName(
                    "com.google.android.googlequicksearchbox",
                    "com.google.android.googlequicksearchbox.VoiceSearchActivity"
                )
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            },
            Intent(RecognizerIntent.ACTION_WEB_SEARCH).apply {
                setPackage("com.google.android.googlequicksearchbox")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_WEB_SEARCH)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            }
        )

        var launched = false
        for (intent in candidates) {
            if (startActivitySafe(intent)) {
                launched = true
                break
            }
        }

        val shell = ShellEngine.getInstance(applicationContext)
        if (shell.state.value.isAdbReady) {
            lifecycleScope.launch(Dispatchers.IO) {
                try {
                    shell.execute(
                        "am start --user 0 -a android.speech.action.WEB_SEARCH -n com.google.android.googlequicksearchbox/com.google.android.googlequicksearchbox.VoiceSearchActivity --es android.speech.extra.LANGUAGE_MODEL web_search --ez com.google.android.voicesearch.extra.CALLED_FROM_SEARCH_PLATE true >/dev/null 2>&1 || am start --user 0 -n com.google.android.googlequicksearchbox/com.google.android.googlequicksearchbox.VoiceSearchActivity >/dev/null 2>&1 || true"
                    )
                } catch (_: Exception) {}
            }
            launched = true
        }

        if (!launched) {
            Toast.makeText(
                this,
                "⚠️ Vui lòng cài đặt ứng dụng Google từ CH Play để dùng Tìm kiếm giọng nói!",
                Toast.LENGTH_SHORT
            ).show()
        }
        finishWithoutAnimation()
    }

    private fun startActivitySafe(intent: Intent): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                val options = ActivityOptions.makeBasic().apply {
                    setPendingIntentBackgroundActivityStartMode(
                        @Suppress("DEPRECATION") ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED
                    )
                }
                startActivity(intent, options.toBundle())
            } else {
                startActivity(intent)
            }
            true
        } catch (_: Exception) {
            try {
                startActivity(intent)
                true
            } catch (_: Exception) {
                false
            }
        }
    }

    private fun triggerGentleHaptic() {
        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(30L, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(30L)
            }
        } catch (_: Exception) {}
    }

    /**
     * Nhường quyền hiển thị nổi trên màn hình cho Gemini Voice Overlay kèm vùng ảnh vừa khoanh:
     * Chuyển trực tiếp hình ảnh vừa khoanh + chữ trích xuất trên màn hình sang cho Gemini Live để người dùng hỏi trực tiếp!
     */
    private fun launchGeminiFloatingOverlayAndYield() {
        triggerGentleHaptic()

        // 1. Tóm tắt nội dung văn bản trong vùng khoanh (nếu có)
        val bounds = lastSelectionBounds
        val ocrSummary = if (bounds != null && capturedBitmap != null) {
            val sw = capturedBitmap!!.width.toFloat()
            val sh = capturedBitmap!!.height.toFloat()
            val regionNodes = MagicTuneCtsAccessibilityService.lastCapturedScreenNodes.filter { node ->
                val normX = (node.boundsInScreen.left.toFloat() + node.boundsInScreen.right.toFloat()) / (2f * sw)
                val normY = (node.boundsInScreen.top.toFloat() + node.boundsInScreen.bottom.toFloat()) / (2f * sh)
                normX >= bounds.left && normX <= bounds.right && normY >= bounds.top && normY <= bounds.bottom
            }
            if (regionNodes.isNotEmpty()) {
                regionNodes.map { it.text.trim() }.filter { it.isNotBlank() }.distinct().joinToString(" | ").take(250)
            } else null
        } else null

        // 2. Kích hoạt Gemini Live Floating Overlay kèm dữ liệu hình ảnh vừa khoanh
        val shown = GeminiLiveFloatingOverlay.showWithAttachedScreenQuery(
            context = this,
            base64Jpeg = lastCroppedJpegBase64,
            imageFile = lastCroppedFile,
            ocrSummary = ocrSummary
        )

        if (shown) {
            finishWithoutAnimation()
            return
        }
        val launched = com.example.core.service.SystemFloatingHudOverlay.launchGeminiAssistantFromForeground(this)
        if (launched) {
            lifecycleScope.launch {
                delay(120L)
                finishWithoutAnimation()
            }
        } else {
            finishWithoutAnimation()
        }
    }

    private fun finishWithoutAnimation() {
        isOverlayActive = false
        if (activeInstanceRef?.get() === this) {
            activeInstanceRef = null
        }
        com.example.core.service.SystemFloatingHudOverlay.setNavBridgeSuppressedForOverlay(applicationContext, false)
        try {
            finishAndRemoveTask()
        } catch (_: Throwable) {
            finish()
        }
        @Suppress("DEPRECATION")
        overridePendingTransition(0, 0)
    }

    companion object {
        @Volatile
        var isOverlayActive: Boolean = false

        @Volatile
        var lastCreatedTimestampMs: Long = 0L

        @Volatile
        private var activeInstanceRef: java.lang.ref.WeakReference<CircleToSearchOverlayActivity>? = null

        /**
         * Tự động đóng Khoanh Tròn Tìm Kiếm để nhường màn hình cho cửa sổ nổi Gemini Voice AI.
         */
        fun dismissIfActiveForGemini() {
            isOverlayActive = false
            val act = activeInstanceRef?.get()
            activeInstanceRef = null
            if (act != null) {
                try {
                    com.example.core.service.SystemFloatingHudOverlay.setNavBridgeSuppressedForOverlay(act.applicationContext, false)
                } catch (_: Throwable) {}
                try {
                    act.runOnUiThread {
                        try {
                            act.finishWithoutAnimation()
                        } catch (_: Throwable) {}
                    }
                } catch (_: Throwable) {}
            }
        }

        fun launch(context: Context): Boolean {
            val appCtx = context.applicationContext
            val (hasQuota, quotaMsg) = LicenseManager.checkAndConsumeProOrTrial(appCtx, "Khoanh Tròn Tìm Kiếm & Dịch Màn Hình")
            if (!hasQuota) {
                Toast.makeText(appCtx, quotaMsg, Toast.LENGTH_LONG).show()
                try {
                    val intent = Intent(appCtx, MainActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                        putExtra("navigate_to", "pro_license")
                    }
                    appCtx.startActivity(intent)
                } catch (_: Throwable) {}
                return false
            }

            return try {
                GeminiLiveFloatingOverlay.dismiss(context)
                val intent = Intent(context, CircleToSearchOverlayActivity::class.java).apply {
                    addFlags(
                        Intent.FLAG_ACTIVITY_NEW_TASK or
                            Intent.FLAG_ACTIVITY_CLEAR_TOP or
                            Intent.FLAG_ACTIVITY_SINGLE_TOP or
                            Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS or
                            Intent.FLAG_ACTIVITY_NO_ANIMATION
                    )
                }
                val options = ActivityOptions.makeBasic().apply {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        try {
                            val method = ActivityOptions::class.java.getMethod("setLaunchWindowingMode", Int::class.javaPrimitiveType)
                            method.invoke(this, 1) // WINDOWING_MODE_FULLSCREEN = 1
                        } catch (_: Throwable) {}
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                        setPendingIntentBackgroundActivityStartMode(
                            ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED
                        )
                    }
                }
                context.startActivity(intent, options.toBundle())
                true
            } catch (_: Exception) {
                false
            }
        }
    }
}

@Composable
private fun ForcedCircleToSearchScreen(
    bitmap: Bitmap?,
    croppedPreview: Bitmap?,
    lastCroppedJpegBase64: String?,
    selectionNormBounds: Rect?,
    isCapturing: Boolean,
    isUploadingToGoogle: Boolean,
    isTranslatingWithGoogle: Boolean,
    googleTranslationResult: CircleToSearchOverlayActivity.GoogleTranslationResult?,
    baseLensResultUrl: String?,
    activeLensMode: CircleToSearchOverlayActivity.LensMode,
    uploadErrorMessage: String?,
    onSelectLensMode: (CircleToSearchOverlayActivity.LensMode) -> Unit,
    onCircleSelectionCompleted: (Float, Float, Float, Float, CircleToSearchOverlayActivity.LensMode) -> Unit,
    onActivateInstantGoogleTranslateAndScroll: () -> Unit,
    onSearchFullScreen: () -> Unit,
    onLaunchGoogleVoiceSearch: () -> Unit,
    onLaunchGeminiFloatingOverlay: () -> Unit,
    onOpenExternalLensApp: () -> Unit,
    onResetCircleSelection: () -> Unit,
    onDismiss: () -> Unit
) {
    val density = LocalDensity.current
    val googleColors = remember {
        listOf(
            Color(0xFF4285F4), // Google Blue
            Color(0xFFEA4335), // Google Red
            Color(0xFFFBBC05), // Google Yellow
            Color(0xFF34A853), // Google Green
            Color(0xFF4285F4)
        )
    }

    val infiniteTransition = rememberInfiniteTransition(label = "cts_glow")
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.45f,
        targetValue = 0.95f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow_alpha"
    )

    val fingerPoints = remember { mutableStateListOf<Offset>() }
    var canvasSize by remember { mutableStateOf(IntSize.Zero) }
    var preferredCircleMode by remember { mutableStateOf(CircleToSearchOverlayActivity.LensMode.SEARCH) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .onSizeChanged { canvasSize = it }
            .testTag("circle_to_search_overlay_root")
            .pointerInput(baseLensResultUrl, googleTranslationResult, isTranslatingWithGoogle) {
                if (baseLensResultUrl != null || googleTranslationResult != null || isTranslatingWithGoogle) {
                    detectTapGestures(
                        onTap = {
                            onResetCircleSelection()
                        }
                    )
                }
            }
    ) {
        // 1. Nền màn hình vừa chụp đóng băng
        if (bitmap != null) {
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = "Màn hình khoanh tròn tìm kiếm",
                contentScale = ContentScale.FillBounds,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0x38020617))
            )
        } else if (!isCapturing) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xCC020617))
            )
        }

        // 2. Bề mặt cảm ứng đón nét vẽ ngón tay KHOANH TRÒN (Lasso / Circle Gesture) - Vô hiệu hóa vẽ khi đang hiện bảng kết quả
        val canDraw = !isCapturing && baseLensResultUrl == null && !isTranslatingWithGoogle && googleTranslationResult == null
        if (canDraw) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(bitmap, canvasSize, preferredCircleMode) {
                        detectDragGestures(
                            onDragStart = { startOffset ->
                                fingerPoints.clear()
                                fingerPoints.add(startOffset)
                            },
                            onDrag = { change, _ ->
                                change.consume()
                                fingerPoints.add(change.position)
                            },
                            onDragEnd = {
                                if (fingerPoints.size >= 3 && canvasSize.width > 0 && canvasSize.height > 0) {
                                    val minX = fingerPoints.minOf { it.x }
                                    val maxX = fingerPoints.maxOf { it.x }
                                    val minY = fingerPoints.minOf { it.y }
                                    val maxY = fingerPoints.maxOf { it.y }

                                    val spanX = maxX - minX
                                    val spanY = maxY - minY

                                    if (spanX > 20f || spanY > 20f) {
                                        val normLeft = (minX / canvasSize.width).coerceIn(0f, 1f)
                                        val normTop = (minY / canvasSize.height).coerceIn(0f, 1f)
                                        val normRight = (maxX / canvasSize.width).coerceIn(0f, 1f)
                                        val normBottom = (maxY / canvasSize.height).coerceIn(0f, 1f)
                                        onCircleSelectionCompleted(
                                            normLeft,
                                            normTop,
                                            normRight,
                                            normBottom,
                                            preferredCircleMode
                                        )
                                    } else {
                                        fingerPoints.clear()
                                    }
                                } else {
                                    fingerPoints.clear()
                                }
                            },
                            onDragCancel = {
                                fingerPoints.clear()
                            }
                        )
                    }
            ) {
                // Viền phát sáng 4 màu Google dọc xung quanh mép màn hình
                drawRoundRect(
                    brush = Brush.sweepGradient(googleColors),
                    topLeft = Offset.Zero,
                    size = size,
                    cornerRadius = CornerRadius(32.dp.toPx(), 32.dp.toPx()),
                    style = Stroke(width = 5.dp.toPx()),
                    alpha = glowAlpha
                )

                // Vẽ nét khoanh tròn lấp lánh theo ngón tay người dùng
                if (fingerPoints.size > 1) {
                    val path = Path().apply {
                        moveTo(fingerPoints.first().x, fingerPoints.first().y)
                        for (i in 1 until fingerPoints.size) {
                            lineTo(fingerPoints[i].x, fingerPoints[i].y)
                        }
                    }

                    drawPath(
                        path = path,
                        brush = Brush.linearGradient(googleColors),
                        style = Stroke(
                            width = 16.dp.toPx(),
                            cap = StrokeCap.Round,
                            join = StrokeJoin.Round
                        ),
                        alpha = 0.48f
                    )

                    drawPath(
                        path = path,
                        color = Color.White,
                        style = Stroke(
                            width = 5.dp.toPx(),
                            cap = StrokeCap.Round,
                            join = StrokeJoin.Round
                        ),
                        alpha = 0.96f
                    )

                    val minX = fingerPoints.minOf { it.x }
                    val maxX = fingerPoints.maxOf { it.x }
                    val minY = fingerPoints.minOf { it.y }
                    val maxY = fingerPoints.maxOf { it.y }
                    val rect = Rect(minX, minY, maxX, maxY)
                    if (rect.width > 18f && rect.height > 18f) {
                        drawRoundRect(
                            color = Color.White.copy(alpha = 0.14f),
                            topLeft = Offset(rect.left, rect.top),
                            size = Size(rect.width, rect.height),
                            cornerRadius = CornerRadius(18.dp.toPx(), 18.dp.toPx())
                        )
                        drawRoundRect(
                            brush = Brush.linearGradient(googleColors),
                            topLeft = Offset(rect.left, rect.top),
                            size = Size(rect.width, rect.height),
                            cornerRadius = CornerRadius(18.dp.toPx(), 18.dp.toPx()),
                            style = Stroke(width = 3.dp.toPx())
                        )
                    }
                }
            }
        }

        // 2B. LỚP PHỦ BẢN DỊCH NỔI GOOGLE DỊCH THEO TỪNG KHUNG CHỮ (Nhỏ gọn 8.5sp, tự động né nhau & quy đổi VNĐ)
        if (activeLensMode == CircleToSearchOverlayActivity.LensMode.TRANSLATE &&
            googleTranslationResult != null &&
            googleTranslationResult.isSuccess &&
            canvasSize.width > 0 && canvasSize.height > 0
        ) {
            val selLeft = selectionNormBounds?.left ?: 0f
            val selTop = selectionNormBounds?.top ?: 0f
            val selRight = selectionNormBounds?.right ?: 1f
            val selBottom = selectionNormBounds?.bottom ?: 1f

            if (googleTranslationResult.boxes.isNotEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(Unit) {
                            detectTapGestures(
                                onTap = {
                                    onResetCircleSelection()
                                }
                            )
                        }
                ) {
                    for (box in googleTranslationResult.boxes) {
                        val boxLeftPx = (canvasSize.width * (selLeft + (box.xmin / 1000f) * (selRight - selLeft))).toInt()
                        val boxTopPx = (canvasSize.height * (selTop + (box.ymin / 1000f) * (selBottom - selTop))).toInt()
                        val rawBoxWidthPx = (canvasSize.width * ((box.xmax - box.xmin) / 1000f) * (selRight - selLeft)).toInt()
                        val maxBoxWidthDp = with(density) { rawBoxWidthPx.coerceAtLeast(110).toDp() }
                        val isPriceBox = box.translatedText.contains("≈") && box.translatedText.contains("đ")

                        Box(
                            modifier = Modifier
                                .offset { IntOffset(boxLeftPx, boxTopPx) }
                                .widthIn(min = 36.dp, max = maxOf(96.dp, maxBoxWidthDp))
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (isPriceBox) Color(0xF07C2D12) else Color(0xE8064E3B))
                                .border(
                                    width = 0.75.dp,
                                    color = if (isPriceBox) Color(0xFFFBBF24) else Color(0xFF34D399),
                                    shape = RoundedCornerShape(4.dp)
                                )
                                .padding(horizontal = 3.5.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = box.translatedText,
                                color = Color.White,
                                fontSize = 8.5.sp,
                                fontWeight = FontWeight.Bold,
                                lineHeight = 10.5.sp,
                                maxLines = 3,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }

        // 4. Hộp chỉ báo đang xử lý
        if (isUploadingToGoogle || isTranslatingWithGoogle) {
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(horizontal = 24.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(Color(0xF20F172A))
                    .border(1.5.dp, Brush.horizontalGradient(googleColors), RoundedCornerShape(22.dp))
                    .padding(horizontal = 22.dp, vertical = 18.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    CircularProgressIndicator(
                        color = Color(0xFF4285F4),
                        strokeWidth = 3.dp,
                        modifier = Modifier.size(26.dp)
                    )
                    Column {
                        Text(
                            text = if (isTranslatingWithGoogle || activeLensMode == CircleToSearchOverlayActivity.LensMode.TRANSLATE) {
                                "🌐 Google Dịch đang dịch tức thì & quy đổi VNĐ..."
                            } else {
                                "🔍 Đang truyền ảnh vùng khoanh sang Google Lens..."
                            },
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = if (isTranslatingWithGoogle || activeLensMode == CircleToSearchOverlayActivity.LensMode.TRANSLATE) {
                                "Hỗ trợ cuộn đến đâu dịch đến đó cho Taobao, 1688"
                            } else {
                                "Kết quả tìm kiếm Google sẽ hiển thị ngay bên dưới"
                            },
                            color = Color(0xFF94A3B8),
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        // Thông báo lỗi mạng nếu có
        if (uploadErrorMessage != null && !isUploadingToGoogle && baseLensResultUrl == null) {
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(horizontal = 24.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(Color(0xF20F172A))
                    .border(1.dp, Color(0xFFEF4444), RoundedCornerShape(18.dp))
                    .padding(16.dp)
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = uploadErrorMessage,
                        color = Color(0xFFFCA5A5),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF1E293B))
                            .clickable { onResetCircleSelection() }
                            .padding(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Text("Thử khoanh lại", color = Color.White, fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // 5. Thanh công cụ Google Circle-to-Search nổi ở đáy màn hình (Khi chưa mở bảng kết quả Google)
        if (!isCapturing && (baseLensResultUrl == null || activeLensMode == CircleToSearchOverlayActivity.LensMode.TRANSLATE)) {
            Column(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 26.dp)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier
                        
                        .clip(RoundedCornerShape(32.dp))
                        .background(Color(0xF50F172A))
                        .border(
                            width = 1.5.dp,
                            brush = Brush.horizontalGradient(googleColors),
                            shape = RoundedCornerShape(32.dp)
                        )
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Nút Tìm Cả Trang (Toàn bộ màn hình đang hiển thị) - Biểu tượng gọn gàng
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.horizontalGradient(
                                    listOf(Color(0xFF2563EB), Color(0xFF3B82F6))
                                )
                            )
                            .border(1.dp, Color.White.copy(alpha = 0.25f), CircleShape)
                            .clickable { onSearchFullScreen() }
                            .testTag("cts_search_full_page_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Tìm kiếm cả trang",
                            tint = Color.White,
                            modifier = Modifier.size(21.dp)
                        )
                    }

                    // Nút Dịch Màn Hình Trực Tiếp - Biểu tượng gọn gàng
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.horizontalGradient(
                                    listOf(Color(0xFF059669), Color(0xFF10B981))
                                )
                            )
                            .border(1.dp, Color.White.copy(alpha = 0.25f), CircleShape)
                            .clickable { onActivateInstantGoogleTranslateAndScroll() }
                            .testTag("cts_screen_translate_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Translate,
                            contentDescription = "Dịch màn hình",
                            tint = Color.White,
                            modifier = Modifier.size(21.dp)
                        )
                    }

                    // Nút Nhường Màn Hình & Gọi Trò Chuyện Gemini Nổi Trực Tiếp
                    // Chỉ hiển thị khi có quyền: Admin, Pro, còn lượt Dùng Thử hoặc đã tự thêm Gemini API Key
                    val context = androidx.compose.ui.platform.LocalContext.current
                    val canUseGemini = LicenseManager.canAccessGeminiLive(context)
                    if (canUseGemini) {
                        Row(
                            modifier = Modifier
                                .height(44.dp)
                                .clip(RoundedCornerShape(22.dp))
                                .background(
                                    Brush.linearGradient(
                                        listOf(Color(0xFF7C3AED), Color(0xFF2563EB), Color(0xFF06B6D4))
                                    )
                                )
                                .border(1.dp, Color.White.copy(alpha = 0.35f), RoundedCornerShape(22.dp))
                                .clickable { onLaunchGeminiFloatingOverlay() }
                                .padding(horizontal = 14.dp)
                                .testTag("cts_gemini_floating_button"),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = "✨ Gemini",
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black,
                                maxLines = 1
                            )
                        }
                    }

                    // Nút Tìm Kiếm Giọng Nói Google - Biểu tượng tròn
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(
                                    listOf(Color(0xFF4285F4), Color(0xFF2563EB))
                                )
                            )
                            .border(1.dp, Color.White.copy(alpha = 0.25f), CircleShape)
                            .clickable { onLaunchGoogleVoiceSearch() }
                            .testTag("cts_google_voice_search_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = "Tìm bằng giọng nói",
                            tint = Color.White,
                            modifier = Modifier.size(21.dp)
                        )
                    }

                    // Nút Đóng - Biểu tượng tròn
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF1E293B))
                            .border(1.dp, Color.White.copy(alpha = 0.25f), CircleShape)
                            .clickable { onDismiss() }
                            .testTag("cts_close_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Đóng",
                            tint = Color.White,
                            modifier = Modifier.size(21.dp)
                        )
                    }
                }
            }
        }

        // 6. BẢNG KẾT QUẢ GOOGLE LENS TRƯỢT TỪ DƯỚI ĐÁY LÊN (Dùng cho Google Tìm Kiếm hoặc khi dịch ảnh tĩnh không có node chữ)
        AnimatedVisibility(
            visible = !baseLensResultUrl.isNullOrBlank() &&
                (activeLensMode != CircleToSearchOverlayActivity.LensMode.TRANSLATE || googleTranslationResult == null),
            enter = slideInVertically(initialOffsetY = { it }),
            exit = slideOutVertically(targetOffsetY = { it }),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            val targetUrl = remember(baseLensResultUrl, activeLensMode) {
                val raw = baseLensResultUrl ?: ""
                if (raw == "DIRECT_WEBVIEW_UPLOAD") {
                    "DIRECT_WEBVIEW_UPLOAD_${activeLensMode.code}"
                } else if (raw.contains("lns_mode=")) {
                    raw.replace(Regex("lns_mode=[a-z_]+"), "lns_mode=${activeLensMode.code}")
                } else if (raw.isNotEmpty()) {
                    "$raw&lns_mode=${activeLensMode.code}"
                } else {
                    "DIRECT_WEBVIEW_UPLOAD_${activeLensMode.code}"
                }
            }

            GoogleLensResultBottomSheet(
                targetUrl = targetUrl,
                lastCroppedJpegBase64 = lastCroppedJpegBase64,
                croppedPreview = croppedPreview,
                activeLensMode = activeLensMode,
                googleColors = googleColors,
                onSelectMode = { mode ->
                    onSelectLensMode(mode)
                },
                onOpenExternalLens = onOpenExternalLensApp,
                onCircleAgain = {
                    fingerPoints.clear()
                    onResetCircleSelection()
                },
                onCloseAll = onDismiss
            )
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun GoogleLensResultBottomSheet(
    targetUrl: String,
    lastCroppedJpegBase64: String?,
    croppedPreview: Bitmap?,
    activeLensMode: CircleToSearchOverlayActivity.LensMode,
    googleColors: List<Color>,
    onSelectMode: (CircleToSearchOverlayActivity.LensMode) -> Unit,
    onOpenExternalLens: () -> Unit,
    onCircleAgain: () -> Unit,
    @Suppress("UNUSED_PARAMETER") onCloseAll: () -> Unit
) {
    val context = LocalContext.current
    val hostActivity = context as? Activity
    var isPageLoading by remember { mutableStateOf(true) }
    var lastSubmittedSignature by remember { mutableStateOf("") }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var canGoBack by remember { mutableStateOf(false) }
    var canGoForward by remember { mutableStateOf(false) }

    val navigateBackInResults: () -> Unit = {
        webViewRef?.let { wv ->
            if (wv.canGoBack()) {
                val history = wv.copyBackForwardList()
                val prevItem = if (history.currentIndex > 0) history.getItemAtIndex(history.currentIndex - 1) else null
                if (prevItem?.url == "about:blank") {
                    wv.stopLoading()
                    wv.clearHistory()
                    loadLensTargetOrDirectUpload(
                        webView = wv,
                        targetUrl = targetUrl,
                        base64Jpeg = lastCroppedJpegBase64,
                        modeCode = activeLensMode.code
                    )
                    canGoBack = false
                    canGoForward = false
                } else {
                    wv.goBack()
                    canGoBack = wv.canGoBack()
                    canGoForward = wv.canGoForward()
                }
            }
        }
    }

    val navigateForwardInResults: () -> Unit = {
        webViewRef?.let { wv ->
            if (wv.canGoForward()) {
                wv.goForward()
                canGoBack = wv.canGoBack()
                canGoForward = wv.canGoForward()
            }
        }
    }

    BackHandler(enabled = canGoBack) {
        navigateBackInResults()
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .fillMaxHeight(0.78f)
            .clip(RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp))
            .background(Color(0xFF0F172A))
            .border(
                width = 1.5.dp,
                brush = Brush.horizontalGradient(googleColors),
                shape = RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp)
            )
            .navigationBarsPadding()
            .testTag("cts_google_lens_result_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF0F172A))
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    if (croppedPreview != null) {
                        Image(
                            bitmap = croppedPreview.asImageBitmap(),
                            contentDescription = "Vùng vừa khoanh",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .border(1.dp, Color(0xFF38BDF8), RoundedCornerShape(8.dp))
                        )
                    }
                    Column {
                        Text(
                            text = "Google",
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "Tìm kiếm hình ảnh",
                            color = Color(0xFF94A3B8),
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {


                    // Nút Lui (Back) để điều hướng lùi giữa các trang web trong kết quả Google
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(if (canGoBack) Color(0xFF1E293B) else Color(0xFF1E293B).copy(alpha = 0.45f))
                            .border(
                                width = 1.dp,
                                color = if (canGoBack) Color(0xFF38BDF8).copy(alpha = 0.65f) else Color.White.copy(alpha = 0.1f),
                                shape = CircleShape
                            )
                            .clickable(enabled = canGoBack) { navigateBackInResults() }
                            .testTag("cts_webview_back_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Lùi trang trước",
                            tint = if (canGoBack) Color(0xFF38BDF8) else Color(0xFF64748B),
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    // Nút Tiến (Forward) để điều hướng tiến giữa các trang web trong kết quả Google
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(if (canGoForward) Color(0xFF1E293B) else Color(0xFF1E293B).copy(alpha = 0.45f))
                            .border(
                                width = 1.dp,
                                color = if (canGoForward) Color(0xFF38BDF8).copy(alpha = 0.65f) else Color.White.copy(alpha = 0.1f),
                                shape = CircleShape
                            )
                            .clickable(enabled = canGoForward) { navigateForwardInResults() }
                            .testTag("cts_webview_forward_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = "Tiến trang sau",
                            tint = if (canGoForward) Color(0xFF38BDF8) else Color(0xFF64748B),
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    // Nút Khoanh lại (đóng vai trò trở lại màn hình khoanh vùng; đã bỏ nút X ở góc phải theo yêu cầu)
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color(0xFF1E293B))
                            .border(1.dp, Color(0xFF38BDF8).copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                            .clickable { onCircleAgain() }
                            .padding(horizontal = 9.dp, vertical = 6.dp)
                            .testTag("cts_circle_again_button"),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Khoanh lại",
                            tint = Color(0xFF38BDF8),
                            modifier = Modifier.size(13.dp)
                        )
                        Text(
                            text = "Khoanh lại",
                            color = Color(0xFF38BDF8),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF1E293B))
                            .clickable { onOpenExternalLens() }
                            .testTag("cts_open_external_lens_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.OpenInNew,
                            contentDescription = "Mở bằng ứng dụng ngoài",
                            tint = Color(0xFFE2E8F0),
                            modifier = Modifier.size(15.dp)
                        )
                    }
                }
            }

            // Hàng hành động chức năng trong bảng kết quả: [🔍 Kết Quả Google] [🌐 Dịch Màn Hình] [📝 Chép Chữ]
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // 1. Nút Kết Quả Google
                val isSearchMode = activeLensMode == CircleToSearchOverlayActivity.LensMode.SEARCH
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            if (isSearchMode) {
                                Brush.horizontalGradient(listOf(Color(0xFF2563EB), Color(0xFF0EA5E9)))
                            } else {
                                Brush.horizontalGradient(listOf(Color(0xFF1E293B), Color(0xFF1E293B)))
                            }
                        )
                        .border(
                            width = 1.dp,
                            color = if (isSearchMode) Color(0xFF38BDF8) else Color.White.copy(alpha = 0.12f),
                            shape = RoundedCornerShape(12.dp)
                        )
                        .clickable {
                            onSelectMode(CircleToSearchOverlayActivity.LensMode.SEARCH)
                            webViewRef?.let { wv ->
                                wv.stopLoading()
                                wv.clearHistory()
                                isPageLoading = true
                                loadLensTargetOrDirectUpload(
                                    webView = wv,
                                    targetUrl = targetUrl,
                                    base64Jpeg = lastCroppedJpegBase64,
                                    modeCode = CircleToSearchOverlayActivity.LensMode.SEARCH.code
                                )
                                lastSubmittedSignature = "$targetUrl|${lastCroppedJpegBase64?.hashCode()}"
                                canGoBack = false
                                canGoForward = false
                            }
                        }
                        .padding(vertical = 8.dp)
                        .testTag("cts_lens_mode_search"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "🔍 Kết Quả Google",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = if (isSearchMode) FontWeight.Black else FontWeight.SemiBold,
                        textAlign = TextAlign.Center
                    )
                }

                // 2. Nút Dịch Màn Hình (Được đưa trực tiếp ra hàng hành động thay thế cho nút Google Dịch)
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            Brush.horizontalGradient(listOf(Color(0xFF059669), Color(0xFF10B981)))
                        )
                        .border(
                            width = 1.dp,
                            color = Color(0xFF34D399).copy(alpha = 0.6f),
                            shape = RoundedCornerShape(12.dp)
                        )
                        .clickable {
                            GoogleLiveTranslateOverlay.start(hostActivity ?: context)
                            Toast.makeText(context, "🌐 Đã mở Dịch màn hình trực tiếp!", Toast.LENGTH_SHORT).show()
                            hostActivity?.finish()
                        }
                        .padding(vertical = 8.dp)
                        .testTag("cts_lens_mode_screen_translate"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "🌐 Dịch Màn Hình",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                }

                // 3. Nút Chép Chữ
                val isTextMode = activeLensMode == CircleToSearchOverlayActivity.LensMode.TEXT
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            if (isTextMode) {
                                Brush.horizontalGradient(listOf(Color(0xFF2563EB), Color(0xFF0EA5E9)))
                            } else {
                                Brush.horizontalGradient(listOf(Color(0xFF1E293B), Color(0xFF1E293B)))
                            }
                        )
                        .border(
                            width = 1.dp,
                            color = if (isTextMode) Color(0xFF38BDF8) else Color.White.copy(alpha = 0.12f),
                            shape = RoundedCornerShape(12.dp)
                        )
                        .clickable {
                            onSelectMode(CircleToSearchOverlayActivity.LensMode.TEXT)
                        }
                        .padding(vertical = 8.dp)
                        .testTag("cts_lens_mode_text"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "📝 Chép Chữ",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = if (isTextMode) FontWeight.Black else FontWeight.SemiBold,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        if (isPageLoading) {
            LinearProgressIndicator(
                modifier = Modifier.fillMaxWidth().height(3.dp),
                color = Color(0xFF38BDF8),
                trackColor = Color(0xFF1E293B)
            )
        }

        AndroidView(
            factory = { ctx ->
                WebView(ctx).apply {
                    webViewRef = this
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    CookieManager.getInstance().setAcceptCookie(true)
                    CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)

                    settings.apply {
                        javaScriptEnabled = true
                        domStorageEnabled = true
                        databaseEnabled = true
                        loadsImagesAutomatically = true
                        useWideViewPort = true
                        loadWithOverviewMode = true
                        builtInZoomControls = true
                        displayZoomControls = false
                        mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                        userAgentString =
                            "Mozilla/5.0 (Linux; Android 14; SM-S928B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36"
                    }

                    webChromeClient = WebChromeClient()
                    webViewClient = object : WebViewClient() {
                        override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                            super.onPageStarted(view, url, favicon)
                            isPageLoading = true
                            canGoBack = view?.canGoBack() == true
                            canGoForward = view?.canGoForward() == true
                        }

                        override fun onPageFinished(view: WebView?, url: String?) {
                            super.onPageFinished(view, url)
                            isPageLoading = false
                            canGoBack = view?.canGoBack() == true
                            canGoForward = view?.canGoForward() == true
                        }

                        override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
                            super.doUpdateVisitedHistory(view, url, isReload)
                            canGoBack = view?.canGoBack() == true
                            canGoForward = view?.canGoForward() == true
                        }

                        override fun shouldOverrideUrlLoading(
                            view: WebView?,
                            request: WebResourceRequest?
                        ): Boolean {
                            val reqUrl = request?.url?.toString() ?: return false
                            if (reqUrl.startsWith("http://") || reqUrl.startsWith("https://")) {
                                return false
                            }
                            return try {
                                val intent = Intent.parseUri(reqUrl, Intent.URI_INTENT_SCHEME)
                                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                ctx.startActivity(intent)
                                true
                            } catch (_: Throwable) {
                                true
                            }
                        }
                    }

                    loadLensTargetOrDirectUpload(
                        webView = this,
                        targetUrl = targetUrl,
                        base64Jpeg = lastCroppedJpegBase64,
                        modeCode = activeLensMode.code
                    )
                    lastSubmittedSignature = "$targetUrl|${lastCroppedJpegBase64?.hashCode()}"
                }
            },
            update = { webView ->
                webViewRef = webView
                val newSig = "$targetUrl|${lastCroppedJpegBase64?.hashCode()}"
                if (newSig != lastSubmittedSignature) {
                    lastSubmittedSignature = newSig
                    loadLensTargetOrDirectUpload(
                        webView = webView,
                        targetUrl = targetUrl,
                        base64Jpeg = lastCroppedJpegBase64,
                        modeCode = activeLensMode.code
                    )
                    canGoBack = false
                    canGoForward = false
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        )
    }
}

private fun loadLensTargetOrDirectUpload(
    webView: WebView,
    targetUrl: String,
    base64Jpeg: String?,
    modeCode: String
) {
    val shouldUseInWebViewUpload = targetUrl.startsWith("DIRECT_WEBVIEW_UPLOAD") ||
        (!targetUrl.contains("vsrid=") && !targetUrl.contains("tbs=") && !targetUrl.contains("/search?p="))

    if (shouldUseInWebViewUpload && !base64Jpeg.isNullOrBlank()) {
        val ts = System.currentTimeMillis()
        val actionUrl = "https://lens.google.com/v3/upload?hl=vi&re=df&st=$ts&ep=gsbubb&lns_mode=$modeCode"
        val html = """
            <!DOCTYPE html>
            <html>
            <head>
              <meta charset="utf-8">
              <meta name="viewport" content="width=device-width,initial-scale=1">
            </head>
            <body style="background:#0F172A;color:#E2E8F0;font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:85vh;margin:0;">
              <div style="text-align:center;padding:20px;">
                <div style="font-size:15px;font-weight:bold;color:#38BDF8;margin-bottom:8px;">🔍 Đang gửi ảnh vùng khoanh tới Google Lens...</div>
                <div style="font-size:12px;color:#94A3B8;">Vui lòng đợi trong giây lát để Google hiển thị kết quả</div>
              </div>
              <form id="lensUploadForm" action="$actionUrl" method="POST" enctype="multipart/form-data" style="display:none;">
                <input type="file" name="encoded_image" id="encodedImageInput" />
              </form>
              <script>
                (function() {
                  try {
                    var b64 = "$base64Jpeg";
                    var binary = atob(b64);
                    var len = binary.length;
                    var bytes = new Uint8Array(len);
                    for (var i = 0; i < len; i++) {
                      bytes[i] = binary.charCodeAt(i);
                    }
                    var blob = new Blob([bytes], { type: "image/jpeg" });
                    var file = new File([blob], "cts_capture.jpg", { type: "image/jpeg", lastModified: Date.now() });
                    var dataTransfer = new DataTransfer();
                    dataTransfer.items.add(file);
                    var fileInput = document.getElementById("encodedImageInput");
                    fileInput.files = dataTransfer.files;
                    document.getElementById("lensUploadForm").submit();
                  } catch (err) {
                    window.location.href = "https://lens.google.com/search?p=0&hl=vi";
                  }
                })();
              </script>
            </body>
            </html>
        """.trimIndent()
        webView.loadDataWithBaseURL("https://lens.google.com/", html, "text/html", "UTF-8", null)
    } else if (targetUrl.isNotBlank()) {
        webView.loadUrl(targetUrl)
    }
}
