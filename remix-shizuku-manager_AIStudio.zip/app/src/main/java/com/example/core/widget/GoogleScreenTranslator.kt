package com.example.core.widget

import com.example.MainActivity
import com.example.core.license.LicenseManager

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.example.core.service.MagicTuneCtsAccessibilityService
import com.example.core.shell.ShellEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToLong

/**
 * Công cụ Dịch Màn Hình Tức Thì 100% Bằng GOOGLE DỊCH (`translate.googleapis.com`)
 * Kết hợp Quy Đổi Tiền Tệ Tự Động sang VNĐ (Tệ ¥/RMB/CNY, Đô la $, Won ₩, Yên 円, Euro €...)
 * và Lớp Phủ Xuyên Thấu "CUỘN ĐẾN ĐÂU DỊCH ĐẾN ĐÓ" chuyên dụng cho Taobao, 1688, Tmall, Pinduoduo & App Ngoại Ngữ.
 *
 * Lưu ý kiến trúc:
 * - TUYỆT ĐỐI KHÔNG DÙNG GROQ AI ở đây (Groq chỉ dành riêng cho Chatbot Hỗ Trợ Người Dùng & Đọc Bill).
 * - Tốc độ phản hồi cực nhanh (~80-150ms cho trang mới, 0ms cho các dòng đã lưu trong bộ nhớ đệm khi cuộn lên/xuống).
 * - Kích thước chữ bản dịch nhỏ gọn (8.5sp - 9.5sp) nhỏ hơn văn bản gốc và tự động né nhau (Collision Avoidance).
 */
object GoogleScreenTranslator {

    private val translationCache = ConcurrentHashMap<String, String>()
    private val inFlightTexts = ConcurrentHashMap.newKeySet<String>()

    // Tỷ giá quy đổi xấp xỉ sang VNĐ phục vụ mua sắm quốc tế (Taobao, 1688, Amazon, Hàn, Nhật...)
    private const val RATE_CNY_TO_VND = 3550.0     // 1 Nhân dân tệ (¥ / 元 / RMB) ≈ 3.550đ
    private const val RATE_USD_TO_VND = 25400.0    // 1 USD ($) ≈ 25.400đ
    private const val RATE_KRW_TO_VND = 18.5       // 1 Won Hàn Quốc (₩ / 원) ≈ 18.5đ
    private const val RATE_JPY_TO_VND = 170.0      // 1 Yên Nhật (円 / JPY) ≈ 170đ
    private const val RATE_EUR_TO_VND = 27500.0    // 1 Euro (€) ≈ 27.500đ
    private const val RATE_GBP_TO_VND = 32500.0    // 1 Bảng Anh (£) ≈ 32.500đ
    private const val RATE_THB_TO_VND = 740.0      // 1 Baht Thái (฿) ≈ 740đ
    private const val RATE_TWD_TO_VND = 790.0      // 1 Đài tệ (NT$) ≈ 790đ

    // Từ điển thuật ngữ mua sắm Taobao / 1688 / Tmall / Pinduoduo giúp dịch tức thì 0ms và chuẩn ngữ cảnh mua hàng
    private val ecommerceQuickGlossary = listOf(
        "加入购物车" to "Thêm vào giỏ",
        "立即购买" to "Mua ngay",
        "立即抢购" to "Săn ngay",
        "领券购买" to "Nhận mã & Mua",
        "券后价" to "Giá sau mã",
        "券后" to "Sau mã",
        "到手价" to "Giá về tay",
        "折后价" to "Giá sau giảm",
        "活动价" to "Giá KM",
        "批发价" to "Giá sỉ",
        "包邮" to "Freeship",
        "满减" to "Giảm theo đơn",
        "运费险" to "BH vận chuyển",
        "退货宝" to "Hỗ trợ trả hàng",
        "七天无理由退换" to "Đổi trả 7 ngày",
        "7天无理由退货" to "Đổi trả 7 ngày",
        "48小时内发货" to "Giao trong 48h",
        "24小时内发货" to "Giao trong 24h",
        "已售" to "Đã bán ",
        "万人付款" to " vạn người mua",
        "人付款" to " người mua",
        "人已买" to " người đã mua",
        "回头客" to "Khách quay lại",
        "好评率" to "Tỷ lệ khen",
        "好评" to "Đánh giá tốt",
        "宝贝评价" to "Đánh giá SP",
        "查看全部" to "Xem tất cả",
        "进店逛逛" to "Vào xem shop",
        "进店" to "Vào shop",
        "店铺" to "Cửa hàng",
        "客服" to "CSKH",
        "收藏" to "Lưu",
        "购物车" to "Giỏ hàng",
        "我的淘宝" to "Taobao của tôi",
        "猜你喜欢" to "Gợi ý cho bạn",
        "百亿补贴" to "Trợ giá tỷ tệ",
        "官方旗舰店" to "Shop Chính Hãng",
        "旗舰店" to "Flagship Store",
        "起批" to "Sỉ từ",
        "成交" to "Đã giao dịch",
        "复购率" to "Tỷ lệ mua lại",
        "件起批" to " sp sỉ",
        "选择规格" to "Chọn phân loại",
        "规格" to "Phân loại",
        "参数" to "Thông số",
        "详情" to "Chi tiết",
        "评价" to "Đánh giá",
        "推荐" to "Đề xuất",
        "现货" to "Hàng sẵn",
        "代发" to "Dropship",
        "一件代发" to "Sỉ lẻ 1 cái",
        "进货单" to "Đơn nhập sỉ"
    )

    private val vndFormatter = DecimalFormat("#,###", DecimalFormatSymbols(Locale.US).apply {
        groupingSeparator = '.'
    })

    /**
     * Định dạng số tiền VNĐ ngắn gọn để hộp chữ dịch luôn nhỏ gọn, không làm chật màn hình Taobao / 1688.
     */
    fun formatVndCompact(vndAmount: Double): String {
        val rounded = vndAmount.roundToLong()
        return when {
            rounded <= 0L -> "0đ"
            rounded < 10_000L -> "${vndFormatter.format(rounded)}đ"
            rounded < 1_000_000L -> {
                val k = rounded / 1000.0
                if (k >= 100 || k % 1.0 == 0.0) {
                    "${k.roundToLong()}k đ"
                } else {
                    String.format(Locale.US, "%.1fk đ", k).replace(".0k", "k")
                }
            }
            else -> {
                val tr = rounded / 1_000_000.0
                String.format(Locale.US, "%.2ftr đ", tr)
                    .replace(".00tr", "tr")
                    .replace(Regex("""(\.\d)0tr"""), "$1tr")
                    .replace('.', ',')
            }
        }
    }

    /**
     * Nhận diện giá tiền ngoại tệ (¥, ￥, 元, RMB, CNY, $, USD, ₩, KRW, 円, JPY, €, £, ฿, NT$)
     * và quy đổi sang VNĐ. Hỗ trợ cả khoảng giá (ví dụ: ¥19.9-39.9 -> ≈ 71k-142k đ), đơn vị 万 (vạn = 10.000),
     * và giá chính trên 1688 khi số nguyên + phần thập phân `.00`/`.50` đứng độc lập.
     */
    fun convertForeignPricesToVnd(originalText: String, translatedText: String): String {
        val source = originalText.trim()
        var result = translatedText.trim().ifBlank { source }

        val isJapaneseContext = source.any { it in '\u3040'..'\u309F' || it in '\u30A0'..'\u30FF' } ||
            source.contains("円") || source.contains("税込") || source.contains("JPY", ignoreCase = true)

        // 1. Kiểm tra khoảng giá trước: Ví dụ "¥ 19.9 - 39.9" hoặc "$10 - $20"
        val rangeRegex = Regex(
            """(NT\$|US\$|RMB|CNY|USD|KRW|JPY|EUR|GBP|THB|[¥￥\$₩€£฿])?\s*(\d{1,7}(?:[.,]\d{1,2})?)\s*[-~～]\s*[¥￥\$₩€£฿]?\s*(\d{1,7}(?:[.,]\d{1,2})?)\s*(元|円|원|块)?""",
            RegexOption.IGNORE_CASE
        )
        val rangeMatch = rangeRegex.find(source)
        if (rangeMatch != null) {
            val prefix = rangeMatch.groupValues[1].uppercase()
            val suffix = rangeMatch.groupValues[4]
            if (prefix.isNotEmpty() || suffix.isNotEmpty()) {
                val v1 = rangeMatch.groupValues[2].replace(",", ".").toDoubleOrNull()
                val v2 = rangeMatch.groupValues[3].replace(",", ".").toDoubleOrNull()
                val rate = resolveCurrencyRate(prefix, suffix, isJapaneseContext)
                if (v1 != null && v2 != null && rate > 0.0 && v1 > 0 && v2 >= v1) {
                    val vndRange = "≈ ${formatVndCompact(v1 * rate)} - ${formatVndCompact(v2 * rate)}"
                    if (!result.contains("đ") && !result.contains("VNĐ", ignoreCase = true)) {
                        return "$result ($vndRange)"
                    }
                }
            }
        }

        // 2. Kiểm tra mức giá đơn: Ví dụ "¥128", "￥39.90", "128元", "券后¥89", "$24.99", "15,000원", "¥1.2万", "¥128/件"
        val singlePriceRegex = Regex(
            """(NT\$|US\$|RMB|CNY|USD|KRW|JPY|EUR|GBP|THB|[¥￥\$₩€£฿])\s*(\d{1,7}(?:[.,]\d{1,2})?)\s*(万)?|(\d{1,7}(?:[.,]\d{1,2})?)\s*(万)?\s*(元|円|원|块|RMB|CNY|USD|KRW|JPY)""",
            RegexOption.IGNORE_CASE
        )

        val matches = singlePriceRegex.findAll(source).toList()
        if (matches.isNotEmpty() && !result.contains("≈") && !result.contains("k đ") && !result.contains("tr đ")) {
            val first = matches.first()
            val prefixSymbol = first.groupValues[1].uppercase()
            val numStr1 = first.groupValues[2]
            val wan1 = first.groupValues[3]
            val numStr2 = first.groupValues[4]
            val wan2 = first.groupValues[5]
            val suffixSymbol = first.groupValues[6].uppercase()

            val rawNumberStr = numStr1.ifEmpty { numStr2 }
            val hasWan = wan1.isNotEmpty() || wan2.isNotEmpty()
            val rate = resolveCurrencyRate(prefixSymbol, suffixSymbol, isJapaneseContext)

            val parsedValue = parsePriceNumber(rawNumberStr, prefixSymbol, suffixSymbol)
            if (parsedValue != null && parsedValue > 0.0 && rate > 0.0) {
                val multiplier = if (hasWan) 10_000.0 else 1.0
                val vndValue = parsedValue * multiplier * rate
                val vndFormatted = formatVndCompact(vndValue)

                if (source.length <= 20) {
                    val cleanOrigPrice = first.value.replace(" ", "")
                    val prefixLabel = when {
                        source.contains("券后") -> "Sau mã: "
                        source.contains("到手") -> "Về tay: "
                        source.contains("折后") -> "Giảm còn: "
                        source.contains("起批") -> "Giá sỉ: "
                        else -> ""
                    }
                    return "$prefixLabel$cleanOrigPrice (≈ $vndFormatted)"
                } else {
                    result = "$result (≈ $vndFormatted)"
                }
            }
        }

        // 3. Đặc trị giá chính trên 1688/Taobao khi ký hiệu ¥ bị vẽ bằng ảnh icon riêng và chỉ còn số thập phân dạng "128.50" hoặc "39.90"
        val standaloneDecimalCnyRegex = Regex("""^(券后|到手价|折后|原价|一口价|批发价)?\s*(\d{1,6}\.\d{1,2})\s*(起|/[件个双套箱包条斤])?$""")
        val standaloneMatch = standaloneDecimalCnyRegex.matchEntire(source)
        if (standaloneMatch != null && !result.contains("≈")) {
            val numVal = standaloneMatch.groupValues[2].toDoubleOrNull()
            if (numVal != null && numVal >= 0.5 && numVal <= 999_999.0) {
                val vndFormatted = formatVndCompact(numVal * RATE_CNY_TO_VND)
                return "¥${standaloneMatch.groupValues[2]} (≈ $vndFormatted)"
            }
        }

        return result
    }

    private fun parsePriceNumber(raw: String, prefix: String, suffix: String): Double? {
        val isKrwOrJpy = prefix == "₩" || prefix == "KRW" || suffix == "원" || suffix == "円" || prefix == "JPY"
        return if (isKrwOrJpy && raw.contains(",")) {
            raw.replace(",", "").toDoubleOrNull()
        } else if (raw.count { it == ',' } == 1 && raw.substringAfter(',').length == 3 && !raw.contains('.')) {
            raw.replace(",", "").toDoubleOrNull()
        } else {
            raw.replace(",", ".").toDoubleOrNull()
        }
    }

    private fun resolveCurrencyRate(prefix: String, suffix: String, isJapaneseContext: Boolean): Double {
        val token = prefix.ifEmpty { suffix }.uppercase()
        return when {
            token == "NT$" -> RATE_TWD_TO_VND
            token == "US$" || token == "$" || token == "USD" -> RATE_USD_TO_VND
            token == "₩" || token == "KRW" || token == "원" -> RATE_KRW_TO_VND
            token == "円" || token == "JPY" -> RATE_JPY_TO_VND
            token == "€" || token == "EUR" -> RATE_EUR_TO_VND
            token == "£" || token == "GBP" -> RATE_GBP_TO_VND
            token == "฿" || token == "THB" -> RATE_THB_TO_VND
            token == "¥" || token == "￥" -> if (isJapaneseContext) RATE_JPY_TO_VND else RATE_CNY_TO_VND
            token == "元" || token == "块" || token == "RMB" || token == "CNY" -> RATE_CNY_TO_VND
            else -> 0.0
        }
    }

    /**
     * Kiểm tra một chuỗi văn bản trên màn hình có cần dịch hoặc quy đổi tiền tệ hay không.
     * Bỏ qua các số thuần túy không có đơn vị tiền tệ và bỏ qua văn bản thuần Tiếng Việt của hệ thống.
     */
    fun shouldTranslateOrConvertNode(text: String): Boolean {
        val trimmed = text.trim()
        if (trimmed.isEmpty() || trimmed.length > 260) return false

        // Nếu có ký hiệu tiền tệ kèm chữ số -> LUÔN DỊCH & QUY ĐỔI TIỀN TỆ!
        val hasCurrency = trimmed.any { it in "¥￥$₩€£฿元円원" } ||
            Regex("""\b(RMB|CNY|USD|KRW|JPY|EUR|NT\$)\b""", RegexOption.IGNORE_CASE).containsMatchIn(trimmed)
        val hasDigit = trimmed.any { it.isDigit() }
        if (hasCurrency && hasDigit) return true

        // Nếu là giá thập phân chuẩn kiểu 1688/Taobao (ví dụ "128.00", "39.90") khi ký hiệu ¥ là icon ảnh
        if (Regex("""^\d{1,6}\.\d{2}$""").matches(trimmed)) return true

        // Nếu có chữ Trung / Nhật / Hàn / Thái / Nga / Ả Rập -> LUÔN DỊCH!
        val hasCjkOrForeignScript = trimmed.any { ch ->
            val code = ch.code
            code in 0x4E00..0x9FFF || // CJK Unified Ideographs (Tiếng Trung / Kanji)
                code in 0x3400..0x4DBF ||
                code in 0x3040..0x30FF || // Hiragana & Katakana (Tiếng Nhật)
                code in 0xAC00..0xD7AF || // Hangul (Tiếng Hàn)
                code in 0x0E00..0x0E7F || // Tiếng Thái
                code in 0x0400..0x04FF    // Cyrillic (Tiếng Nga)
        }
        if (hasCjkOrForeignScript) return true

        // Nếu có chữ cái Latinh nhưng KHÔNG chứa dấu đặc trưng Tiếng Việt -> Dịch sang Tiếng Việt
        val hasLatinLetter = trimmed.any { it in 'a'..'z' || it in 'A'..'Z' }
        if (!hasLatinLetter) return false

        val vietnameseSpecificChars = "ăâđêôơưĂÂĐÊÔƠƯáàảãạấầẩẫậắằẳẵặéèẻẽẹếềểễệíìỉĩịóòỏõọốồổỗộớờởỡợúùủũụứừửữựýỳỷỹỵ"
        val vietCount = trimmed.count { it in vietnameseSpecificChars }
        if (vietCount >= 2) return false

        return trimmed.length >= 2
    }

    private val purePriceFastRegex = Regex(
        """^(券后|到手价|折后|原价|一口价|批发价)?\s*(NT\$|US\$|RMB|CNY|USD|KRW|JPY|[¥￥\$₩€£฿])?\s*\d+([.,]\d+)?(\s*[-~～]\s*[¥￥\$₩€£฿]?\s*\d+([.,]\d+)?)?\s*(万|元|円|원|块|起|/[件个双套箱包条斤])?$""",
        RegexOption.IGNORE_CASE
    )

    /**
     * Dịch một câu đơn lẻ bằng Google Translate (`translate.googleapis.com`) kèm quy đổi tiền tệ VNĐ.
     */
    fun translateSingleTextWithGoogle(rawText: String): String {
        val clean = rawText.trim().replace("\n", " ")
        if (clean.isEmpty()) return ""

        translationCache[clean]?.let { return it }

        // Nếu chỉ là giá tiền thuần túy (ví dụ: "19.90", "128.50", "¥128.50", "￥39.9", "$19.99") -> Quy đổi tức thì 0ms!
        if (purePriceFastRegex.matches(clean)) {
            val converted = convertForeignPricesToVnd(clean, clean)
            translationCache[clean] = converted
            return converted
        }

        // Kiểm tra từ điển thuật ngữ Taobao/1688 khớp chính xác 100% -> 0ms!
        ecommerceQuickGlossary.firstOrNull { it.first.equals(clean, ignoreCase = true) }?.let { (_, vn) ->
            translationCache[clean] = vn
            return vn
        }

        var conn: HttpURLConnection? = null
        return try {
            val encoded = URLEncoder.encode(clean, "UTF-8")
            val url = URL("https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=vi&dt=t&q=$encoded")
            conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 3_500
                readTimeout = 3_500
                setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/125.0.0.0 Mobile Safari/537.36")
            }
            if (conn.responseCode in 200..299) {
                val response = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                val rootArray = JSONArray(response)
                val sentences = rootArray.optJSONArray(0)
                val sb = StringBuilder()
                if (sentences != null) {
                    for (i in 0 until sentences.length()) {
                        val seg = sentences.optJSONArray(i)?.optString(0, "").orEmpty()
                        sb.append(seg)
                    }
                }
                val googleTranslated = sb.toString().trim().ifBlank { clean }
                val finalTranslated = convertForeignPricesToVnd(clean, googleTranslated)
                translationCache[clean] = finalTranslated
                finalTranslated
            } else {
                convertForeignPricesToVnd(clean, clean)
            }
        } catch (_: Throwable) {
            convertForeignPricesToVnd(clean, clean)
        } finally {
            try {
                conn?.disconnect()
            } catch (_: Throwable) {}
        }
    }

    /**
     * Pha 1 (0ms - Tức thì): Trả về ngay lập tức các hộp dịch đã có trong bộ nhớ đệm hoặc là giá tiền ngoại tệ
     * (`¥128`, `$19.99`, `128.50`, từ khóa Taobao/1688) theo tọa độ mới ngay khi người dùng vừa cuộn màn hình!
     * Trả về Pair(Danh sách hộp đã có sẵn, Danh sách các chuỗi mới chưa có trong cache cần dịch ngầm).
     */
    fun buildInstantCachedBoxesForNodes(
        nodes: List<MagicTuneCtsAccessibilityService.ScreenTextNode>,
        screenWidth: Int,
        screenHeight: Int
    ): Pair<List<CircleToSearchOverlayActivity.TranslatedTextBox>, Boolean> {
        val sw = screenWidth.coerceAtLeast(1).toFloat()
        val sh = screenHeight.coerceAtLeast(1).toFloat()
        val filteredNodes = nodes.filter { shouldTranslateOrConvertNode(it.text) }.take(52)
        if (filteredNodes.isEmpty()) return Pair(emptyList(), false)

        var hasUncached = false
        val rawBoxes = ArrayList<CircleToSearchOverlayActivity.TranslatedTextBox>(filteredNodes.size)

        for (node in filteredNodes) {
            val cleanOrig = node.text.trim().replace("\n", " ")
            var trans = translationCache[cleanOrig]
            if (trans == null) {
                val glossaryHit = ecommerceQuickGlossary.firstOrNull { it.first.equals(cleanOrig, ignoreCase = true) }
                if (purePriceFastRegex.matches(cleanOrig)) {
                    trans = convertForeignPricesToVnd(cleanOrig, cleanOrig)
                    translationCache[cleanOrig] = trans
                } else if (glossaryHit != null) {
                    trans = glossaryHit.second
                    translationCache[cleanOrig] = trans
                } else {
                    hasUncached = true
                }
            }

            if (!trans.isNullOrBlank() && !trans.equals(cleanOrig, ignoreCase = true)) {
                val r = node.boundsInScreen
                val ymin = ((r.top / sh) * 1000f).coerceIn(0f, 985f)
                val xmin = ((r.left / sw) * 1000f).coerceIn(0f, 960f)
                val ymax = ((r.bottom / sh) * 1000f).coerceIn(ymin + 12f, 1000f)
                val xmax = ((r.right / sw) * 1000f).coerceIn(xmin + 35f, 1000f)

                rawBoxes.add(
                    CircleToSearchOverlayActivity.TranslatedTextBox(
                        ymin = ymin,
                        xmin = xmin,
                        ymax = ymax,
                        xmax = xmax,
                        originalText = cleanOrig,
                        translatedText = trans
                    )
                )
            }
        }

        return Pair(resolveBoxCollisions(rawBoxes), hasUncached)
    }

    /**
     * Lấy danh sách văn bản mới chưa có trong bộ nhớ đệm và chưa nằm trong hàng đợi đang dịch
     * để dịch ngầm song song mà KHÔNG BAO GIỜ bị hủy (cancel) khi người dùng tiếp tục cuộn trang!
     */
    fun claimUncachedTextsForStreaming(
        nodes: List<MagicTuneCtsAccessibilityService.ScreenTextNode>
    ): List<String> {
        val claimed = mutableListOf<String>()
        for (node in nodes) {
            if (!shouldTranslateOrConvertNode(node.text)) continue
            val clean = node.text.trim().replace("\n", " ")
            if (clean.isEmpty() || translationCache.containsKey(clean)) continue
            if (inFlightTexts.add(clean)) {
                claimed.add(clean)
                if (claimed.size >= 36) break
            }
        }
        return claimed
    }

    fun translateClaimedChunkStreaming(chunk: List<String>) {
        try {
            translateChunkWithGoogle(chunk)
        } finally {
            inFlightTexts.removeAll(chunk.toSet())
        }
    }

    /**
     * Dịch hàng loạt các khối văn bản trên màn hình bằng Google Translate (`translate.googleapis.com`)
     * chỉ trong ~60-110ms (Gộp batch thông minh + xử lý song song + quy đổi tiền tệ VNĐ + chống đè chữ).
     */
    suspend fun translateScreenNodesToBoxes(
        nodes: List<MagicTuneCtsAccessibilityService.ScreenTextNode>,
        screenWidth: Int,
        screenHeight: Int,
        normRegion: androidx.compose.ui.geometry.Rect? = null
    ): List<CircleToSearchOverlayActivity.TranslatedTextBox> = withContext(Dispatchers.IO) {
        val sw = screenWidth.coerceAtLeast(1)
        val sh = screenHeight.coerceAtLeast(1)

        val minLeftPx = ((normRegion?.left ?: 0f) * sw).toInt()
        val minTopPx = ((normRegion?.top ?: 0f) * sh).toInt()
        val maxRightPx = ((normRegion?.right ?: 1f) * sw).toInt()
        val maxBottomPx = ((normRegion?.bottom ?: 1f) * sh).toInt()

        val filteredNodes = nodes.filter { node ->
            val r = node.boundsInScreen
            val cx = r.centerX()
            val cy = r.centerY()
            val insideRegion = cx in minLeftPx..maxRightPx && cy in minTopPx..maxBottomPx
            insideRegion && shouldTranslateOrConvertNode(node.text)
        }.take(52)

        if (filteredNodes.isEmpty()) return@withContext emptyList()

        // 1. Tách các chuỗi chưa có trong bộ nhớ đệm để gọi Google Translate
        val uncachedTexts = filteredNodes
            .map { it.text.trim().replace("\n", " ") }
            .distinct()
            .filter { !translationCache.containsKey(it) }

        if (uncachedTexts.isNotEmpty()) {
            // Dịch gộp theo từng lô 10 câu song song qua Google Translate để đạt tốc độ tức thì (~65ms)
            val chunks = uncachedTexts.chunked(10)
            coroutineScope {
                chunks.map { chunk ->
                    async(Dispatchers.IO) {
                        translateChunkWithGoogle(chunk)
                    }
                }.awaitAll()
            }
        }

        // 2. Tạo danh sách hộp văn bản dịch theo tọa độ chuẩn hóa 0..1000 trong vùng chọn
        val regionW = (maxRightPx - minLeftPx).coerceAtLeast(1).toFloat()
        val regionH = (maxBottomPx - minTopPx).coerceAtLeast(1).toFloat()

        val rawBoxes = mutableListOf<CircleToSearchOverlayActivity.TranslatedTextBox>()
        for (node in filteredNodes) {
            val cleanOrig = node.text.trim().replace("\n", " ")
            var trans = translationCache[cleanOrig] ?: translateSingleTextWithGoogle(cleanOrig)
            // Nếu bản dịch trống hoặc trùng nguyên gốc mà gốc chứa chữ Trung/ngoại ngữ,
            // thử tra cứu từ điển nhanh hoặc giữ lại bản dịch để không bao giờ bị biến mất hộp dịch
            if (trans.isBlank()) continue
            if (trans.equals(cleanOrig, ignoreCase = true)) {
                val hasForeign = cleanOrig.any { it.code in 0x4E00..0x9FFF || it.code in 0x3040..0x30FF || it.code in 0xAC00..0xD7AF }
                if (hasForeign) {
                    val fallbackTrans = ecommerceQuickGlossary.firstOrNull { cleanOrig.contains(it.first, ignoreCase = true) }?.second
                    if (fallbackTrans != null) {
                        trans = fallbackTrans
                    }
                }
            }

            val r = node.boundsInScreen
            val ymin = (((r.top - minTopPx) / regionH) * 1000f).coerceIn(0f, 985f)
            val xmin = (((r.left - minLeftPx) / regionW) * 1000f).coerceIn(0f, 960f)
            val ymax = (((r.bottom - minTopPx) / regionH) * 1000f).coerceIn(ymin + 12f, 1000f)
            val xmax = (((r.right - minLeftPx) / regionW) * 1000f).coerceIn(xmin + 35f, 1000f)

            rawBoxes.add(
                CircleToSearchOverlayActivity.TranslatedTextBox(
                    ymin = ymin,
                    xmin = xmin,
                    ymax = ymax,
                    xmax = xmax,
                    originalText = cleanOrig,
                    translatedText = trans
                )
            )
        }

        resolveBoxCollisions(rawBoxes)
    }

    /**
     * Gộp nhiều dòng văn bản trong 1 request Google Translate duy nhất để dịch siêu tốc (~65-95ms).
     */
    private fun translateChunkWithGoogle(chunk: List<String>) {
        val stillNeeded = mutableListOf<String>()
        for (item in chunk) {
            val glossaryHit = ecommerceQuickGlossary.firstOrNull { it.first.equals(item, ignoreCase = true) }
            if (purePriceFastRegex.matches(item)) {
                translationCache[item] = convertForeignPricesToVnd(item, item)
            } else if (glossaryHit != null) {
                translationCache[item] = glossaryHit.second
            } else {
                stillNeeded.add(item)
            }
        }

        if (stillNeeded.isEmpty()) return

        if (stillNeeded.size == 1) {
            translateSingleTextWithGoogle(stillNeeded.first())
            return
        }

        var conn: HttpURLConnection? = null
        try {
            val joined = stillNeeded.joinToString("\n")
            val encoded = URLEncoder.encode(joined, "UTF-8")
            val url = URL("https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=vi&dt=t&q=$encoded")
            conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 3_500
                readTimeout = 3_500
                setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/125.0.0.0 Mobile Safari/537.36")
            }

            if (conn.responseCode in 200..299) {
                val response = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                val rootArray = JSONArray(response)
                val sentences = rootArray.optJSONArray(0)
                val sb = StringBuilder()
                if (sentences != null) {
                    for (i in 0 until sentences.length()) {
                        val seg = sentences.optJSONArray(i)?.optString(0, "").orEmpty()
                        sb.append(seg)
                    }
                }
                val lines = sb.toString().split("\n").map { it.trim() }
                if (lines.size == stillNeeded.size) {
                    for (idx in stillNeeded.indices) {
                        val orig = stillNeeded[idx]
                        val trans = lines[idx].ifBlank { orig }
                        translationCache[orig] = convertForeignPricesToVnd(orig, trans)
                    }
                    return
                }
            }
        } catch (_: Throwable) {
        } finally {
            try {
                conn?.disconnect()
            } catch (_: Throwable) {}
        }

        // Dự phòng nếu gộp dòng không khớp số dòng: dịch từng câu
        for (item in stillNeeded) {
            translateSingleTextWithGoogle(item)
        }
    }

    /**
     * Thuật toán chống đè chữ 2 chiều (2D Collision Avoidance):
     * Sắp xếp các hộp dịch từ trên xuống dưới, trái sang phải. Nếu hai hộp giao nhau theo cả trục X và trục Y,
     * tự động đẩy hộp phía dưới dịch xuống vừa đủ để các hộp chữ biết né nhau, không bao giờ đè lên nhau.
     */
    fun resolveBoxCollisions(
        boxes: List<CircleToSearchOverlayActivity.TranslatedTextBox>
    ): List<CircleToSearchOverlayActivity.TranslatedTextBox> {
        if (boxes.size <= 1) return boxes

        val sorted = boxes.sortedWith(compareBy<CircleToSearchOverlayActivity.TranslatedTextBox> { it.ymin }.thenBy { it.xmin })
        val placed = mutableListOf<CircleToSearchOverlayActivity.TranslatedTextBox>()

        for (box in sorted) {
            val origW = (box.xmax - box.xmin).coerceIn(75f, 460f)
            // Ước lượng chiều cao hộp chữ nhỏ gọn (font 9sp) trên thang tọa độ 0..1000
            val estCharsPerLine = max(8, (origW / 14f).toInt())
            val estLines = ((box.translatedText.length + estCharsPerLine - 1) / estCharsPerLine).coerceIn(1, 3)
            val estHeight = (estLines * 20f + 8f).coerceAtLeast(24f)

            var curYMin = box.ymin
            var curXMin = box.xmin
            var curXMax = (curXMin + origW).coerceAtMost(992f)
            var curYMax = curYMin + estHeight

            // Kiểm tra va chạm với các hộp đã đặt trước đó
            var pass = 0
            while (pass < 6) {
                var collided = false
                for (prev in placed) {
                    val prevW = (prev.xmax - prev.xmin).coerceIn(75f, 460f)
                    val prevRight = prev.xmin + prevW
                    val prevBottom = prev.ymax

                    val overlapX = min(curXMax, prevRight) - max(curXMin, prev.xmin)
                    val overlapY = min(curYMax, prevBottom) - max(curYMin, prev.ymin)

                    if (overlapX > 8f && overlapY > 2f) {
                        curYMin = prevBottom + 4f
                        curYMax = curYMin + estHeight
                        collided = true
                    }
                }
                if (!collided) break
                pass++
            }

            if (curYMin < 975f) {
                placed.add(
                    box.copy(
                        ymin = curYMin.coerceIn(0f, 975f),
                        xmin = curXMin.coerceIn(0f, 950f),
                        ymax = curYMax.coerceIn(curYMin + 20f, 1000f),
                        xmax = curXMax.coerceIn(curXMin + 60f, 1000f)
                    )
                )
            }
        }

        return placed
    }

    /**
     * Dự phòng trích xuất tọa độ văn bản bằng `uiautomator dump` khi Shizuku / ADB đang bật
     * mà Accessibility chưa kịp kết nối.
     */
    suspend fun extractNodesViaUiAutomatorFallback(
        context: Context
    ): List<MagicTuneCtsAccessibilityService.ScreenTextNode> = withContext(Dispatchers.IO) {
        val shell = ShellEngine.getInstance(context.applicationContext)
        if (!shell.state.value.isAdbReady) return@withContext emptyList()

        return@withContext try {
            val res = shell.execute("uiautomator dump /data/local/tmp/cts_nodes.xml >/dev/null 2>&1 && cat /data/local/tmp/cts_nodes.xml")
            val xml = res.output
            if (xml.isBlank() || !xml.contains("<node")) return@withContext emptyList()

            val nodes = mutableListOf<MagicTuneCtsAccessibilityService.ScreenTextNode>()
            val nodeRegex = Regex("""<node\b[^>]*>""")
            val textRegex = Regex("""\btext="([^"]*)"""")
            val descRegex = Regex("""\bcontent-desc="([^"]*)"""")
            val boundsRegex = Regex("""\bbounds="\[(\d+),(\d+)\]\[(\d+),(\d+)\]"""")

            for (match in nodeRegex.findAll(xml)) {
                val tag = match.value
                val text = textRegex.find(tag)?.groupValues?.get(1)?.trim().orEmpty()
                    .ifEmpty { descRegex.find(tag)?.groupValues?.get(1)?.trim().orEmpty() }
                if (text.isEmpty() || text.length > 240) continue

                val bMatch = boundsRegex.find(tag) ?: continue
                val x1 = bMatch.groupValues[1].toIntOrNull() ?: continue
                val y1 = bMatch.groupValues[2].toIntOrNull() ?: continue
                val x2 = bMatch.groupValues[3].toIntOrNull() ?: continue
                val y2 = bMatch.groupValues[4].toIntOrNull() ?: continue

                if (x2 - x1 >= 12 && y2 - y1 >= 10) {
                    nodes.add(
                        MagicTuneCtsAccessibilityService.ScreenTextNode(
                            text = decodeXmlEntities(text),
                            boundsInScreen = Rect(x1, y1, x2, y2)
                        )
                    )
                }
            }
            nodes
        } catch (_: Throwable) {
            emptyList()
        }
    }

    private fun decodeXmlEntities(input: String): String {
        return input
            .replace("&amp;", "&")
            .replace("&quot;", "\"")
            .replace("&apos;", "'")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&#10;", " ")
    }
}

/**
 * LỚP PHỦ GOOGLE DỊCH XUYÊN THẤU "CUỘN ĐẾN ĐÂU DỊCH ĐẾN ĐÓ" (GoogleLiveTranslateOverlay):
 * - Đóng hoàn toàn màn hình ảnh chụp tĩnh (`CircleToSearchOverlayActivity`) để gắn trực tiếp lớp phủ xuyên thấu
 *   (`TYPE_APPLICATION_OVERLAY` với `FLAG_NOT_TOUCHABLE | FLAG_NOT_FOCUSABLE`) lên trên ứng dụng đang mở (Taobao, 1688, Pinduoduo, AliExpress...).
 * - Mọi thao tác chạm, vuốt cuộn trang, bấm chọn sản phẩm trên Taobao & 1688 đi xuyên qua lớp dịch 100% theo thời gian thực.
 * - Kiến trúc Zero-Latency Dual-Pipeline:
 *   + Pipeline 1 (Fast Track 0ms): Cập nhật vị trí các hộp đã dịch & quy đổi giá tiền VNĐ tức thì ngay trên mỗi khung hình cuộn mà không có bất kỳ delay nào.
 *   + Pipeline 2 (Non-Cancelling Streaming Worker): Các câu tiếng nước ngoài mới xuất hiện khi cuộn được đưa vào luồng dịch song song chạy ngầm KHÔNG BỊ HỦY khi người dùng tiếp tục vuốt. Dịch xong lô nào hiển thị ngay lô đó!
 */
object GoogleLiveTranslateOverlay {

    private val mainHandler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    @Volatile
    var isRunning: Boolean = false
        private set

    @Volatile
    private var isBoxesTemporarilyHidden: Boolean = false

    private var arOverlayView: LiveArBoxesCanvasView? = null
    private var controlBarView: View? = null
    private var statusBadgeTextView: TextView? = null
    private var hideShowBtnView: TextView? = null

    private var fastTrackJob: Job? = null
    private var periodicWatchJob: Job? = null
    private var lastNodesSignature: String = ""
    private var lastFastTrackTimeMs: Long = 0L

    fun start(
        context: Context,
        initialBoxes: List<CircleToSearchOverlayActivity.TranslatedTextBox> = emptyList()
    ): Boolean {
        val appCtx = context.applicationContext
        val (hasQuota, quotaMsg) = LicenseManager.checkAndConsumeProOrTrial(appCtx, "Dịch Cuộn Trực Tiếp")
        if (!hasQuota) {
            Toast.makeText(appCtx, quotaMsg, Toast.LENGTH_LONG).show()
            try {
                val intent = android.content.Intent(appCtx, MainActivity::class.java).apply {
                    addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    putExtra("navigate_to", "pro_license")
                }
                appCtx.startActivity(intent)
            } catch (_: Throwable) {}
            return false
        }
        if (!Settings.canDrawOverlays(appCtx)) {
            Toast.makeText(
                appCtx,
                "⚠️ Vui lòng BẬT quyền 'Hiển thị trên ứng dụng khác' cho MagicTune để cuộn & dịch xuyên thấu trên Taobao/1688!",
                Toast.LENGTH_LONG
            ).show()
            try {
                val intent = android.content.Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    android.net.Uri.parse("package:${appCtx.packageName}")
                ).apply {
                    addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                appCtx.startActivity(intent)
            } catch (_: Throwable) {}
            return false
        }

        // Đặt cờ đồng bộ ngay lập tức trước khi CircleToSearchOverlayActivity đóng để onDestroy() không tắt AccessibilityService!
        isRunning = true
        isBoxesTemporarilyHidden = false
        MagicTuneCtsAccessibilityService.isLiveScrollTranslateActive = true
        MagicTuneCtsAccessibilityService.ensureServiceEnabledViaSecureSettings(appCtx)

        MagicTuneCtsAccessibilityService.onBankingAppDetectedCallback = {
            stop(appCtx)
        }

        MagicTuneCtsAccessibilityService.onLiveScrollEventCallback = { _ ->
            mainHandler.post {
                if (!isRunning || isBoxesTemporarilyHidden) return@post
                val now = System.currentTimeMillis()
                // Tần số quét 60fps (~16ms): bám dính tức thì 0 độ trễ theo ngón tay vuốt mà không làm mờ hay hủy request đang dịch
                if (now - lastFastTrackTimeMs >= 16L) {
                    lastFastTrackTimeMs = now
                    triggerZeroLatencyScan(appCtx)
                }
            }
        }

        mainHandler.post {
            if (!isRunning) return@post
            ensureOverlayViewsCreated(appCtx)
            if (initialBoxes.isNotEmpty()) {
                arOverlayView?.setScrollingAlpha(1f)
                arOverlayView?.updateBoxes(initialBoxes)
                statusBadgeTextView?.text = "🌐 Dịch Cuộn: ${initialBoxes.size} mục (Đổi VNĐ)"
                triggerZeroLatencyScan(appCtx)
            } else {
                triggerZeroLatencyScan(appCtx)
            }
            startPeriodicScreenWatcher(appCtx)
        }
        return true
    }

    fun stop(context: Context) {
        val appCtx = context.applicationContext
        isRunning = false
        MagicTuneCtsAccessibilityService.isLiveScrollTranslateActive = false
        MagicTuneCtsAccessibilityService.onLiveScrollEventCallback = null
        MagicTuneCtsAccessibilityService.onBankingAppDetectedCallback = null
        fastTrackJob?.cancel()
        periodicWatchJob?.cancel()
        lastNodesSignature = ""

        mainHandler.post {
            removeOverlayViews(appCtx)
        }
        MagicTuneCtsAccessibilityService.forceDisableServiceNow(appCtx)
    }

    private fun startPeriodicScreenWatcher(context: Context) {
        periodicWatchJob?.cancel()
        periodicWatchJob = scope.launch {
            while (isRunning) {
                delay(180L)
                if (isRunning && !isBoxesTemporarilyHidden) {
                    val nodes = withContext(Dispatchers.Default) {
                        MagicTuneCtsAccessibilityService.ensureServiceEnabledViaSecureSettings(context)
                        MagicTuneCtsAccessibilityService.extractVisibleScreenNodesNow(context)
                    }
                    if (nodes.isNotEmpty()) {
                        val sig = nodes.take(24).joinToString("|") { "${it.text}@${it.boundsInScreen.top / 6}_${it.boundsInScreen.left / 8}" }
                        if (sig != lastNodesSignature) {
                            triggerZeroLatencyScan(context)
                        }
                    }
                }
            }
        }
    }

    /**
     * Quét 0 độ trễ (Zero-Latency):
     * 1. Cập nhật ngay lập tức vị trí mọi hộp đã dịch + mọi mức giá tiền VNĐ (0ms).
     * 2. Đẩy các câu mới chưa dịch vào luồng chạy ngầm độc lập (KHÔNG bị cancel khi cuộn tiếp).
     *    Mỗi lô 8 câu dịch xong sẽ lập tức vẽ bổ sung lên màn hình!
     */
    private fun triggerZeroLatencyScan(context: Context) {
        fastTrackJob?.cancel()
        fastTrackJob = scope.launch {
            if (!isRunning || isBoxesTemporarilyHidden) return@launch

            val dm = context.resources.displayMetrics
            val sw = dm.widthPixels.coerceAtLeast(1)
            val sh = dm.heightPixels.coerceAtLeast(1)

            val nodes = withContext(Dispatchers.Default) {
                MagicTuneCtsAccessibilityService.ensureServiceEnabledViaSecureSettings(context)
                val a11yNodes = MagicTuneCtsAccessibilityService.extractVisibleScreenNodesNow(context)
                if (a11yNodes.isNotEmpty()) {
                    a11yNodes
                } else {
                    GoogleScreenTranslator.extractNodesViaUiAutomatorFallback(context)
                }
            }

            if (!isRunning || isBoxesTemporarilyHidden) return@launch

            val sig = nodes.take(24).joinToString("|") { "${it.text}@${it.boundsInScreen.top / 6}_${it.boundsInScreen.left / 8}" }
            lastNodesSignature = sig

            if (nodes.isEmpty()) {
                arOverlayView?.updateBoxes(emptyList())
                statusBadgeTextView?.text = "🌐 Dịch Cuộn: Vuốt cuộn trang để dịch"
                return@launch
            }

            // PIPELINE 1 (0ms - Tức thì): Hiển thị ngay lập tức toàn bộ giá tiền VNĐ + các câu đã dịch theo tọa độ cuộn mới!
            val (instantBoxes, hasUncached) = withContext(Dispatchers.Default) {
                GoogleScreenTranslator.buildInstantCachedBoxesForNodes(nodes, sw, sh)
            }
            if (!isRunning || isBoxesTemporarilyHidden) return@launch
            arOverlayView?.setScrollingAlpha(1f)
            arOverlayView?.updateBoxes(instantBoxes)

            if (!hasUncached) {
                statusBadgeTextView?.text = "🌐 Dịch Cuộn: ${instantBoxes.size} mục (Đổi VNĐ)"
                return@launch
            }

            // PIPELINE 2 (Non-Cancelling Streaming): Chỉ lấy các câu mới chưa nằm trong hàng đợi để dịch song song
            val newlyClaimed = withContext(Dispatchers.Default) {
                GoogleScreenTranslator.claimUncachedTextsForStreaming(nodes)
            }
            if (newlyClaimed.isEmpty()) return@launch

            statusBadgeTextView?.text = if (instantBoxes.isNotEmpty()) {
                "🌐 Dịch Cuộn: ${instantBoxes.size} mục • Đang dịch thêm..."
            } else {
                "🌐 Google Dịch đang dịch tức thì..."
            }

            // Khởi chạy các worker độc lập trên scope (không bị hủy bởi fastTrackJob khi người dùng cuộn tiếp)
            val chunks = newlyClaimed.chunked(8)
            for (chunk in chunks) {
                scope.launch(Dispatchers.IO) {
                    GoogleScreenTranslator.translateClaimedChunkStreaming(chunk)
                    if (!isRunning || isBoxesTemporarilyHidden) return@launch
                    // Ngay khi lô 8 câu này vừa dịch xong, quét lại tọa độ hiện tại trên màn hình để gắn bản dịch vào đúng vị trí đang cuộn!
                    val latestNodes = MagicTuneCtsAccessibilityService.extractVisibleScreenNodesNow(context)
                    if (latestNodes.isNotEmpty()) {
                        val (updatedBoxes, stillHasUncached) = GoogleScreenTranslator.buildInstantCachedBoxesForNodes(latestNodes, sw, sh)
                        withContext(Dispatchers.Main.immediate) {
                            if (isRunning && !isBoxesTemporarilyHidden) {
                                arOverlayView?.setScrollingAlpha(1f)
                                arOverlayView?.updateBoxes(updatedBoxes)
                                statusBadgeTextView?.text = if (stillHasUncached) {
                                    "🌐 Dịch Cuộn: ${updatedBoxes.size} mục • Đang dịch..."
                                } else {
                                    "🌐 Dịch Cuộn: ${updatedBoxes.size} mục (Đổi VNĐ)"
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun ensureOverlayViewsCreated(context: Context) {
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return
        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        // 1. Lớp phủ AR Boxes XUYÊN THẤU CẢM ỨNG 100% (FLAG_NOT_TOUCHABLE | FLAG_NOT_FOCUSABLE)
        if (arOverlayView == null) {
            val canvasView = LiveArBoxesCanvasView(context)
            val canvasParams = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                overlayType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                }
            }
            try {
                wm.addView(canvasView, canvasParams)
                arOverlayView = canvasView
            } catch (_: Throwable) {}
        }

        // 2. Thanh điều khiển nổi 2 hàng (Tự động ẩn khi bàn phím ảo xuất hiện)
        if (controlBarView == null) {
            val density = context.resources.displayMetrics.density
            fun dp(v: Int): Int = (v * density).toInt()

            val rootContainer = LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(8), dp(6), dp(8), dp(6))
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(20).toFloat()
                    setColor(Color.parseColor("#EE0F172A"))
                    setStroke(dp(1), Color.parseColor("#34D399"))
                }
                elevation = dp(8).toFloat()
            }

            // Hàng 1: Trạng thái (Title)
            val row1 = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, 0, 0, dp(4))
            }

            val statusTv = TextView(context).apply {
                text = "🌐 Dịch Cuộn (Đổi VNĐ)"
                setTextColor(Color.parseColor("#A7F3D0"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(4), 0, dp(4), 0)
            }
            statusBadgeTextView = statusTv
            row1.addView(statusTv)

            rootContainer.addView(row1)

            // Hàng 2: Tất cả 4 nút hành động nằm trọn trên hàng 2
            val row2 = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, 0, 0, 0)
            }

            // Nút Dịch lại ngay
            val refreshBtn = createPillButton(context, "🔄 Dịch lại", "#059669") {
                isBoxesTemporarilyHidden = false
                arOverlayView?.visibility = View.VISIBLE
                hideShowBtnView?.text = "👁 Ẩn"
                lastNodesSignature = ""
                triggerZeroLatencyScan(context)
            }
            row2.addView(refreshBtn)

            // Nút Tạm Ẩn / Hiện bản dịch
            val toggleBtn = createPillButton(context, "👁 Ẩn", "#1E293B") {
                isBoxesTemporarilyHidden = !isBoxesTemporarilyHidden
                if (isBoxesTemporarilyHidden) {
                    arOverlayView?.visibility = View.GONE
                    hideShowBtnView?.text = "👁 Hiện"
                    statusBadgeTextView?.text = "🌐 Đang tạm ẩn chữ dịch"
                } else {
                    arOverlayView?.visibility = View.VISIBLE
                    hideShowBtnView?.text = "👁 Ẩn"
                    triggerZeroLatencyScan(context)
                }
            }
            hideShowBtnView = toggleBtn
            row2.addView(toggleBtn)

            // Nút chuyển sang Khoanh Tròn Tìm Kiếm Google Lens
            val circleBtn = createPillButton(context, "🔍 Khoanh tìm kiếm", "#2563EB") {
                stop(context)
                CircleToSearchOverlayActivity.launch(context)
            }
            row2.addView(circleBtn)

            // Nút Đóng hẳn
            val closeBtn = createPillButton(context, "✕ Tắt", "#DC2626") {
                stop(context)
            }
            row2.addView(closeBtn)

            rootContainer.addView(row2)

            val barParams = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                y = dp(56)
            }

            // Tự động ẩn thanh điều khiển khi bất kỳ bàn phím ảo nào (bao gồm Laban Key, Gboard, Baidu IME...) xuất hiện
            val decorView = controlBarView?.rootView ?: rootContainer.rootView
            decorView.setOnApplyWindowInsetsListener { _, insets ->
                try {
                    val isImeVisible = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        insets.isVisible(android.view.WindowInsets.Type.ime())
                    } else {
                        val r = android.graphics.Rect()
                        rootContainer.getWindowVisibleDisplayFrame(r)
                        val screenHeight = rootContainer.rootView.height
                        (screenHeight - r.bottom) > screenHeight * 0.12
                    }

                    if (isImeVisible) {
                        if (rootContainer.visibility == View.VISIBLE) {
                            rootContainer.visibility = View.GONE
                        }
                    } else {
                        if (rootContainer.visibility != View.VISIBLE && isRunning) {
                            rootContainer.visibility = View.VISIBLE
                        }
                    }
                } catch (_: Throwable) {}
                insets
            }

            // Fallback kiểm tra qua Global Layout thay đổi chiều cao
            rootContainer.viewTreeObserver.addOnGlobalLayoutListener {
                try {
                    val r = android.graphics.Rect()
                    rootContainer.getWindowVisibleDisplayFrame(r)
                    val screenHeight = rootContainer.rootView.height
                    val keypadHeight = screenHeight - r.bottom
                    // Hạ ngưỡng nhận diện bàn phím Laban Key xuống 10% chiều cao màn hình để bắt nhạy tuyệt đối
                    if (keypadHeight > screenHeight * 0.10) {
                        if (rootContainer.visibility == View.VISIBLE) {
                            rootContainer.visibility = View.GONE
                        }
                    } else {
                        if (rootContainer.visibility != View.VISIBLE && isRunning) {
                            rootContainer.visibility = View.VISIBLE
                        }
                    }
                } catch (_: Throwable) {}
            }

            // Cho phép người dùng nắm kéo thanh điều khiển tới bất kỳ vị trí nào nếu vướng nút mua hàng
            var initialX = 0
            var initialY = 0
            var initialTouchX = 0f
            var initialTouchY = 0f
            statusTv.setOnTouchListener { _, event ->
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = barParams.x
                        initialY = barParams.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - initialTouchX).toInt()
                        val dy = (initialTouchY - event.rawY).toInt()
                        barParams.x = initialX + dx
                        barParams.y = (initialY + dy).coerceIn(dp(24), context.resources.displayMetrics.heightPixels - dp(100))
                        try {
                            wm.updateViewLayout(rootContainer, barParams)
                        } catch (_: Throwable) {}
                        true
                    }
                    else -> false
                }
            }

            try {
                wm.addView(rootContainer, barParams)
                controlBarView = rootContainer
            } catch (_: Throwable) {}
        }
    }

    private fun createPillButton(
        context: Context,
        label: String,
        bgColorHex: String,
        onClick: () -> Unit
    ): TextView {
        val density = context.resources.displayMetrics.density
        fun dp(v: Int): Int = (v * density).toInt()

        return TextView(context).apply {
            text = label
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(8), dp(4), dp(8), dp(4))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(14).toFloat()
                setColor(Color.parseColor(bgColorHex))
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                marginStart = dp(4)
            }
            setOnClickListener { onClick() }
        }
    }

    private fun removeOverlayViews(context: Context) {
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return
        arOverlayView?.let {
            try {
                wm.removeView(it)
            } catch (_: Throwable) {}
        }
        arOverlayView = null

        controlBarView?.let {
            try {
                wm.removeView(it)
            } catch (_: Throwable) {}
        }
        controlBarView = null
        statusBadgeTextView = null
        hideShowBtnView = null
    }

    /**
     * Custom View vẽ trực tiếp các hộp chữ Google Dịch nhỏ gọn (8.8sp), tự động xuống dòng
     * và né nhau (Collision-Resolved) ngay trên tọa độ văn bản gốc.
     * Tích hợp bộ nhớ đệm `StaticLayout` (Cached Layout Pool) để hàm `onDraw` đạt chuẩn 120FPS không giật lag khi cuộn nhanh.
     */
    private class LiveArBoxesCanvasView(context: Context) : View(context) {
        private var boxes: List<CircleToSearchOverlayActivity.TranslatedTextBox> = emptyList()
        private var overallAlpha: Float = 1f

        private val density = context.resources.displayMetrics.density
        private val scaledDensity = context.resources.configuration.fontScale * context.resources.displayMetrics.density

        private val layoutCache = ConcurrentHashMap<String, Pair<StaticLayout, Float>>()

        private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = Color.parseColor("#E8064E3B")
        }
        private val priceBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = Color.parseColor("#F07C2D12") // Màu cam đậm nổi bật riêng cho thẻ Giá tiền đã quy đổi VNĐ
        }
        private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 0.8f * density
            color = Color.parseColor("#34D399")
        }
        private val priceBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 0.9f * density
            color = Color.parseColor("#FBBF24")
        }
        private val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 8.8f * scaledDensity // Nhỏ gọn hơn văn bản gốc để không gây chật chội chen chúc
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }

        fun updateBoxes(newBoxes: List<CircleToSearchOverlayActivity.TranslatedTextBox>) {
            boxes = newBoxes
            postInvalidateOnAnimation()
        }

        fun setScrollingAlpha(alpha: Float) {
            if (abs(overallAlpha - alpha) > 0.05f) {
                overallAlpha = alpha
                this.alpha = alpha
            }
        }

        private fun getOrBuildStaticLayout(text: String, textWidthBucket: Int): Pair<StaticLayout, Float> {
            val key = "$text|$textWidthBucket"
            layoutCache[key]?.let { return it }

            val staticLayout = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                StaticLayout.Builder.obtain(text, 0, text.length, textPaint, textWidthBucket)
                    .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                    .setLineSpacing(0f, 0.96f)
                    .setIncludePad(false)
                    .setMaxLines(3)
                    .build()
            } else {
                @Suppress("DEPRECATION")
                StaticLayout(text, textPaint, textWidthBucket, Layout.Alignment.ALIGN_NORMAL, 0.96f, 0f, false)
            }

            var maxLineW = 0f
            for (line in 0 until staticLayout.lineCount) {
                maxLineW = max(maxLineW, staticLayout.getLineWidth(line))
            }

            if (layoutCache.size > 400) {
                layoutCache.clear()
            }
            val pair = Pair(staticLayout, maxLineW)
            layoutCache[key] = pair
            return pair
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat()
            val h = height.toFloat()
            if (w <= 0f || h <= 0f || boxes.isEmpty()) return

            val padH = 3.5f * density
            val padV = 2.0f * density
            val cornerRadius = 4.0f * density

            // Trạng thái né va chạm Pixel thực tế ngay lúc vẽ (Pixel-level collision guard)
            val drawnRects = ArrayList<RectF>(boxes.size)

            for (box in boxes) {
                val rawLeft = (box.xmin / 1000f) * w
                val rawTop = (box.ymin / 1000f) * h
                val rawRight = (box.xmax / 1000f) * w

                val availWidth = (rawRight - rawLeft).coerceIn(58f * density, w * 0.46f).toInt()
                val rawTextWidth = (availWidth - (padH * 2).toInt()).coerceAtLeast((44f * density).toInt())
                // Làm tròn chiều rộng theo bước 8px để tái sử dụng 100% StaticLayout trong bộ nhớ đệm khi cuộn
                val textWidthBucket = ((rawTextWidth + 7) / 8) * 8

                val (staticLayout, maxLineW) = getOrBuildStaticLayout(box.translatedText, textWidthBucket)

                val boxW = maxLineW + padH * 2
                val boxH = staticLayout.height + padV * 2

                var drawLeft = rawLeft.coerceIn(2f * density, (w - boxW - 2f * density).coerceAtLeast(2f * density))
                var drawTop = rawTop.coerceIn(2f * density, (h - boxH - 50f * density).coerceAtLeast(2f * density))
                val candidateRect = RectF(drawLeft, drawTop, drawLeft + boxW, drawTop + boxH)

                // Đảm bảo không đè lên bất kỳ hộp chữ nào đã vẽ trước đó ở cấp độ Pixel
                var tries = 0
                while (tries < 5) {
                    var hit: RectF? = null
                    for (prev in drawnRects) {
                        if (RectF.intersects(candidateRect, prev)) {
                            hit = prev
                            break
                        }
                    }
                    if (hit == null) break
                    drawTop = hit.bottom + 2f * density
                    candidateRect.set(drawLeft, drawTop, drawLeft + boxW, drawTop + boxH)
                    tries++
                }

                if (candidateRect.bottom > h - 42f * density) continue
                drawnRects.add(candidateRect)

                val isPriceConverted = box.translatedText.contains("≈") && box.translatedText.contains("đ")
                canvas.drawRoundRect(
                    candidateRect,
                    cornerRadius,
                    cornerRadius,
                    if (isPriceConverted) priceBgPaint else bgPaint
                )
                canvas.drawRoundRect(
                    candidateRect,
                    cornerRadius,
                    cornerRadius,
                    if (isPriceConverted) priceBorderPaint else borderPaint
                )

                canvas.save()
                canvas.translate(candidateRect.left + padH, candidateRect.top + padV)
                staticLayout.draw(canvas)
                canvas.restore()
            }
        }
    }
}
