package com.example.core.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.SystemClock
import android.view.View
import android.widget.RemoteViews
import com.example.MainActivity
import com.example.R
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MagicTuneBatteryWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        for (appWidgetId in appWidgetIds) {
            updateWidget(context, appWidgetManager, appWidgetId)
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val action = intent.action
        if (action == Intent.ACTION_POWER_DISCONNECTED || action == "android.intent.action.ACTION_POWER_DISCONNECTED") {
            BatteryInfoReader.forceDisconnected = true
            BatteryInfoReader.forceConnected = false
        } else if (action == Intent.ACTION_POWER_CONNECTED || action == "android.intent.action.ACTION_POWER_CONNECTED") {
            BatteryInfoReader.forceConnected = true
            BatteryInfoReader.forceDisconnected = false
        } else if (action == Intent.ACTION_BATTERY_CHANGED) {
            // Khi ACTION_BATTERY_CHANGED đến sau, xóa cờ force để đọc theo chu kỳ bình thường
            BatteryInfoReader.forceConnected = false
            BatteryInfoReader.forceDisconnected = false
        }

        if (action == Intent.ACTION_BATTERY_CHANGED ||
            action == Intent.ACTION_POWER_CONNECTED ||
            action == Intent.ACTION_POWER_DISCONNECTED ||
            action == "android.intent.action.ACTION_POWER_CONNECTED" ||
            action == "android.intent.action.ACTION_POWER_DISCONNECTED"
        ) {
            val appWidgetManager = AppWidgetManager.getInstance(context)
            val componentName = android.content.ComponentName(context, MagicTuneBatteryWidgetProvider::class.java)
            val appWidgetIds = appWidgetManager.getAppWidgetIds(componentName)
            for (id in appWidgetIds) {
                updateWidget(context, appWidgetManager, id)
            }
        }
    }

    companion object {
        fun updateWidget(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int) {
            val views = RemoteViews(context.packageName, R.layout.widget_battery_live)
            val prefs = context.getSharedPreferences("magictune_widget_prefs", Context.MODE_PRIVATE)

            val batteryIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val data = BatteryInfoReader.read(context, batteryIntent)

            // 1. Tiêu đề ứng dụng giữ nguyên chuẩn
            views.setTextViewText(R.id.widget_title, "⚡ MAGICTUNE BATTERY v3.3.5")

            // 2. Tên điện thoại hiển thị riêng biệt ở hàng bên dưới (không đè lên tên app)
            views.setTextViewText(R.id.widget_phone_name_footer, "📱 Thiết bị: ${data.phoneDisplayName}")

            // 3. Nhiệt độ và chu kỳ
            var tempStr = "32°C"
            if (batteryIntent != null) {
                val tempTenths = batteryIntent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1)
                if (tempTenths > 0) {
                    tempStr = String.format(Locale.US, "%.1f°C", tempTenths / 10.0)
                }
            }

            var cycleCount = -1
            if (android.os.Build.VERSION.SDK_INT >= 34 && batteryIntent != null) {
                cycleCount = batteryIntent.getIntExtra("android.os.extra.CYCLE_COUNT", -1)
            }
            if (cycleCount <= 0) {
                val cyclePaths = listOf(
                    "/sys/class/power_supply/bk_battery/cycle_count",
                    "/sys/class/power_supply/battery/cycle_count"
                )
                for (p in cyclePaths) {
                    try {
                        val f = File(p)
                        if (f.exists() && f.canRead()) {
                            val c = f.readText().trim().toIntOrNull()
                            if (c != null && c > 0) {
                                cycleCount = c
                                break
                            }
                        }
                    } catch (_: Exception) {}
                }
            }
            val cycleStr = if (cycleCount > 0) "$cycleCount lần" else "Tốt (Mới)"

            // Gán phần trăm pin
            views.setTextViewText(R.id.widget_battery_pct, "${data.batteryPct}%")
            views.setTextViewText(R.id.widget_cycle_and_temp, "🔄 Chu kỳ: $cycleStr • Nhiệt độ: $tempStr")
            views.setTextViewText(R.id.widget_estimated_usage, data.estimatedUsageText)

            if (data.isCharging) {
                var startRealtime = prefs.getLong("charge_start_realtime", 0L)
                if (startRealtime <= 0L || startRealtime > SystemClock.elapsedRealtime()) {
                    startRealtime = SystemClock.elapsedRealtime()
                    prefs.edit().putLong("charge_start_realtime", startRealtime).apply()
                }

                views.setViewVisibility(R.id.widget_chronometer, View.VISIBLE)
                views.setChronometer(R.id.widget_chronometer, startRealtime, "%s", true)

                // Công suất đo được hiển thị ĐỘC LẬP trên hàng riêng của nó
                val wattDisplay = String.format(Locale.US, "Công suất đo được: %.1f W", data.currentWatts)
                views.setTextViewText(R.id.widget_status, data.speedTitle)
                views.setTextViewText(R.id.widget_charge_watt, data.speedTitle)
                views.setTextViewText(R.id.widget_charge_speed_type, wattDisplay)

                // HÀNG RIÊNG: CẢNH BÁO NÓNG & BẢO VỆ PIN (Tách biệt khỏi công suất đo được)
                views.setViewVisibility(R.id.widget_safety_note, View.VISIBLE)
                views.setTextViewText(R.id.widget_safety_note, data.chargingSafetyNote)
                val safetyColor = when {
                    data.temperatureC >= 42.0 -> 0xFFEF4444.toInt() // Đỏ cảnh báo nóng
                    data.temperatureC >= 39.0 -> 0xFFF59E0B.toInt() // Vàng cam làm mát thông minh
                    else -> 0xFF34D399.toInt() // Xanh lá mát mẻ & bảo vệ pin
                }
                views.setTextColor(R.id.widget_safety_note, safetyColor)

                val fullText = if (data.batteryPct >= 100) {
                    // Nếu đã đầy pin trong lúc cắm sạc, lưu lại thời điểm đầy pin
                    if (!prefs.contains("charge_full_duration_minutes")) {
                        val durationMinutes = ((SystemClock.elapsedRealtime() - startRealtime) / (1000 * 60)).coerceAtLeast(1)
                        val timeStr = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
                        prefs.edit()
                            .putLong("charge_full_duration_minutes", durationMinutes)
                            .putString("charge_full_time_str", timeStr)
                            .apply()
                    }
                    String.format(Locale.US, "Điện áp: %.2fV • ĐÃ SẠC ĐẦY 100% • Ghim: ", data.voltageV)
                } else {
                    String.format(Locale.US, "Điện áp: %.2fV • Đầy sau: ~%dp • Đã ghim: ", data.voltageV, data.minutesToFull)
                }
                views.setTextViewText(R.id.widget_time_full, fullText)

                // Ẩn dòng tổng kết sạc cuối khi đang cắm sạc
                views.setViewVisibility(R.id.widget_last_charge_summary, View.GONE)

                // Ghi chú nhắc nhở khi phát hiện SẠC CHẬM
                if (data.isSlowCharge) {
                    views.setViewVisibility(R.id.widget_slow_charge_note, View.VISIBLE)
                    views.setTextViewText(
                        R.id.widget_slow_charge_note,
                        "💡 Sạc chậm: Đổi củ/cáp nhanh để giảm giờ chờ, hoặc giữ nguyên sạc qua đêm bảo vệ pin."
                    )
                } else {
                    views.setViewVisibility(R.id.widget_slow_charge_note, View.GONE)
                }
            } else {
                // KHI RÚT SẠC: Nếu trước đó đang sạc, tính tổng thời gian cắm sạc để lưu vào "Lịch sử sạc cuối"
                val startRealtime = prefs.getLong("charge_start_realtime", 0L)
                if (startRealtime > 0L) {
                    val totalChargeMinutes = ((SystemClock.elapsedRealtime() - startRealtime) / (1000 * 60)).coerceAtLeast(1)
                    val timeStr = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
                    val wasFull = prefs.getLong("charge_full_duration_minutes", -1L)

                    val summaryText = if (wasFull > 0L) {
                        "⏱️ Đã sạc đầy sau $wasFull phút (Rút sạc lúc $timeStr)"
                    } else {
                        "⏱️ Lần sạc gần nhất: Dừng sau $totalChargeMinutes phút sạc (Lúc $timeStr)"
                    }
                    prefs.edit()
                        .putString("last_charge_summary_text", summaryText)
                        .remove("charge_start_realtime")
                        .remove("charge_full_duration_minutes")
                        .apply()
                }

                views.setViewVisibility(R.id.widget_chronometer, View.GONE)
                views.setChronometer(R.id.widget_chronometer, 0L, null, false)
                views.setViewVisibility(R.id.widget_slow_charge_note, View.GONE)

                views.setTextViewText(R.id.widget_status, "Đang dùng Pin")
                views.setTextViewText(R.id.widget_charge_watt, "CHƯA CẮM SẠC")
                val drainText = if (data.currentWatts > 0.1) String.format(Locale.US, "Tiêu thụ: -%.2f W", data.currentWatts) else "Tiết kiệm pin thông minh"
                views.setTextViewText(R.id.widget_charge_speed_type, drainText)
                views.setTextViewText(
                    R.id.widget_time_full,
                    String.format(Locale.US, "Điện áp: %.2fV • Sức khỏe pin: Tốt", data.voltageV)
                )

                // HÀNG RIÊNG: CẢNH BÁO NÓNG & BẢO VỆ PIN KHI DÙNG PIN
                views.setViewVisibility(R.id.widget_safety_note, View.VISIBLE)
                views.setTextViewText(R.id.widget_safety_note, data.chargingSafetyNote)
                val safetyColor = when {
                    data.temperatureC >= 42.0 -> 0xFFEF4444.toInt()
                    data.temperatureC >= 39.0 -> 0xFFF59E0B.toInt()
                    else -> 0xFF38BDF8.toInt()
                }
                views.setTextColor(R.id.widget_safety_note, safetyColor)

                // HIỂN THỊ DÒNG THỜI GIAN SẠC CUỐI ĐỂ NGƯỜI DÙNG BIẾT ĐỒNG HỒ ĐÃ DỪNG SAU BAO NHIÊU PHÚT
                val lastSummary = prefs.getString("last_charge_summary_text", null)
                if (!lastSummary.isNullOrBlank()) {
                    views.setViewVisibility(R.id.widget_last_charge_summary, View.VISIBLE)
                    views.setTextViewText(R.id.widget_last_charge_summary, lastSummary)
                } else {
                    views.setViewVisibility(R.id.widget_last_charge_summary, View.GONE)
                }
            }

            val openIntent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val pendingIntent = PendingIntent.getActivity(
                context,
                0,
                openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_container, pendingIntent)

            appWidgetManager.updateAppWidget(appWidgetId, views)
        }
    }
}
