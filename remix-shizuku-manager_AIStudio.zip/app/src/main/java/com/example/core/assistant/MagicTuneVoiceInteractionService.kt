package com.example.core.assistant

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.voice.VoiceInteractionService
import com.example.core.service.SystemFloatingHudOverlay
import com.example.core.widget.GeminiLiveFloatingOverlay

/**
 * Dịch vụ Trợ Lý Giọng Nói Hệ Thống (VoiceInteractionService) chuẩn Android.
 * Biến MagicTune thành ỨNG DỤNG TRỢ LÝ ẢO MẶC ĐỊNH (Default Assistant App) cho điện thoại Honor MagicOS:
 * 1. Xuất hiện chính thức trong Cài đặt Honor -> Ứng dụng mặc định -> Ứng dụng hỗ trợ & đầu vào giọng nói.
 * 2. Đón nhận toàn bộ cử chỉ hệ thống: Nhấn giữ nút nguồn, vuốt từ góc dưới màn hình, nhấn giữ phím Home.
 * 3. Hỗ trợ kích hoạt trực tiếp Trò chuyện Gemini Live ngay cả khi màn hình đang khóa (Lockscreen & Screen-off wake).
 */
class MagicTuneVoiceInteractionService : VoiceInteractionService() {

    override fun onReady() {
        super.onReady()
        // Đồng bộ cầu nối cử chỉ & lắng nghe giọng nói rảnh tay khi được hệ thống trao quyền Trợ lý mặc định
        com.example.core.service.MagicTuneKeepAliveService.startOrUpdate(
            applicationContext,
            "Đang duy trì Google Khoanh Tròn & Trò chuyện Gemini 24/7",
            forceFromBootOrOverlay = true
        )
        SystemFloatingHudOverlay.syncNavBarBridge(applicationContext)
    }

    override fun onShutdown() {
        super.onShutdown()
        GeminiLiveFloatingOverlay.dismiss(applicationContext)
    }

    companion object {
        fun isDefaultAssistant(context: Context): Boolean {
            return try {
                val currentAssistant = android.provider.Settings.Secure.getString(
                    context.contentResolver,
                    "assistant"
                ) ?: ""
                currentAssistant.contains(context.packageName)
            } catch (_: Throwable) {
                false
            }
        }
    }
}
