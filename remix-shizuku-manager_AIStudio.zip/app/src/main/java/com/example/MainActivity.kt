package com.example

import com.example.ui.components.SelfPermissionModal
import com.example.core.permission.AppPermissionChecker

import android.app.PictureInPictureParams
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Rational
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.data.LogType
import com.example.data.SearchableActionItem
import androidx.compose.foundation.border
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MagicCyan
import com.example.ui.theme.MagicCyanLight
import com.example.ui.theme.MagicBorder
import com.example.ui.theme.MagicSurfaceDark
import com.example.ui.theme.MagicSurfaceCard
import com.example.ui.theme.MagicEmerald
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextMuted
import com.example.ui.MagicTuneViewModel
import com.example.ui.MainTab
import com.example.ui.components.AppsScreen
import com.example.ui.components.ConnectionScreen
import com.example.ui.components.EdgeDockedTerminalButton
import com.example.ui.components.FloatingAutomationOverlay
import com.example.ui.components.HeaderSection
import com.example.ui.components.NotificationScreen
import com.example.ui.components.RevertModal
import com.example.ui.components.SetupScreen
import com.example.ui.components.ShellRunnerScreen
import com.example.ui.components.ShizukuWlanScreen
import com.example.ui.components.TerminalBottomSheet
import com.example.ui.components.ThermalPrinterScreen
import com.example.ui.components.TuneScreen
import com.example.ui.components.WirelessAdbDialog
import com.example.ui.theme.MagicDarkBackground
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MagicTuneViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        enforceHighRefreshRate()
        try {
            com.example.core.license.LicenseManager.listenToGlobalConfigChanges(this)
            com.example.core.auth.FirebaseAuthManager.startSingleDeviceSessionGuard(this)
            handleIncomingPrintIntent(intent)
            checkTargetTabIntent(intent)
        } catch (_: Throwable) {}
        setContent {
            MyApplicationTheme {
                MagicTuneApp(
                    viewModel = viewModel,
                    onEnterPipMode = { enterFloatingPipWindow() }
                )
            }
        }
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        try {
            handleIncomingPrintIntent(intent)
            checkTargetTabIntent(intent)
        } catch (_: Throwable) {}
    }

    private val pickFileLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.GetContent()
    ) { uri: android.net.Uri? ->
        if (uri != null) {
            viewModel.setSharedPrintUri(uri)
        }
    }

    private fun checkTargetTabIntent(intent: android.content.Intent?) {
        val targetTab = intent?.getStringExtra("TARGET_TAB")
        val targetAction = intent?.getStringExtra("TARGET_ACTION")

        if (targetAction == "GLOBAL_SEARCH") {
            viewModel.setGlobalSearchQuery(" ")
            viewModel.setGlobalSearchQuery("")
        } else if (targetTab == "APPS") {
            viewModel.setTab(MainTab.APPS)
        } else if (targetTab == "SHIZUKU") {
            viewModel.setTab(MainTab.SHIZUKU)
        } else if (targetTab == "LOGIN") {
            viewModel.setTab(MainTab.LOGIN)
        } else if (targetTab == "ACCOUNT") {
            viewModel.setTab(MainTab.ACCOUNT)
        } else if (targetTab == "PRINTER") {
            viewModel.setTab(MainTab.PRINTER)
            if (intent.getBooleanExtra("ACTION_PICK_FILE", false)) {
                pickFileLauncher.launch("*/*")
            }
        }
    }

    private fun handleIncomingPrintIntent(intent: android.content.Intent) {
        val action = intent.action
        val type = intent.type
        if (android.content.Intent.ACTION_SEND == action && type != null) {
            val uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                intent.getParcelableExtra(android.content.Intent.EXTRA_STREAM, android.net.Uri::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableExtra(android.content.Intent.EXTRA_STREAM) as? android.net.Uri
            }
            if (uri != null) {
                viewModel.setSharedPrintUri(uri)
            }
        } else if (android.content.Intent.ACTION_VIEW == action) {
            intent.data?.let { uri ->
                viewModel.setSharedPrintUri(uri)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        enforceHighRefreshRate()
        try {
            viewModel.onAppResumed()
            com.example.core.license.LicenseManager.syncDevicePresenceToCloud(this)
            com.example.core.auth.FirebaseAuthManager.startSingleDeviceSessionGuard(this)
        } catch (_: Throwable) {}
    }

    /**
     * Khóa cứng tần số quét màn hình ở mức cao nhất phần cứng hỗ trợ (90Hz / 120Hz / 144Hz)
     * Ngăn chặn hoàn toàn hiện tượng MagicOS tự giảm tần số quét xuống 30-45-60Hz gây khựng giật khi cuộn trang.
     */
    private fun enforceHighRefreshRate() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val maxMode = display?.supportedModes?.maxByOrNull { it.refreshRate }
                if (maxMode != null) {
                    val lp = window.attributes
                    lp.preferredDisplayModeId = maxMode.modeId
                    @Suppress("DEPRECATION")
                    lp.preferredRefreshRate = maxMode.refreshRate
                    window.attributes = lp
                }
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                @Suppress("DEPRECATION")
                val maxMode = windowManager.defaultDisplay?.supportedModes?.maxByOrNull { it.refreshRate }
                if (maxMode != null) {
                    val lp = window.attributes
                    lp.preferredDisplayModeId = maxMode.modeId
                    lp.preferredRefreshRate = maxMode.refreshRate
                    window.attributes = lp
                }
            }
        } catch (_: Throwable) {}
    }

    private fun enterFloatingPipWindow() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val params = PictureInPictureParams.Builder()
                    .setAspectRatio(Rational(16, 10))
                    .build()
                enterPictureInPictureMode(params)
            }
        } catch (_: Exception) {}
    }
}

@Composable
fun MagicTuneApp(
    viewModel: MagicTuneViewModel,
    onEnterPipMode: () -> Unit = {}
) {
    val uiState by viewModel.uiState.collectAsState()
    val shellState by viewModel.shellState.collectAsState()
    val deviceInfo by viewModel.deviceInfo.collectAsState()
    val setupStatus by viewModel.setupStatus.collectAsState()
    val shizukuInfo by viewModel.shizukuInfo.collectAsState()
    val appsList by viewModel.appsList.collectAsState()
    val diagnosticScan by viewModel.diagnosticScan.collectAsState()
    val floatingState by viewModel.floatingWindowState.collectAsState()
    val tuneStatus by viewModel.tuneStatus.collectAsState()
    val logs by viewModel.logs.collectAsState()

    val context = androidx.compose.ui.platform.LocalContext.current
    val scrollState = rememberScrollState()

    // Tự động cuộn về đỉnh đầu trang mỗi khi chuyển Tab
    androidx.compose.runtime.LaunchedEffect(uiState.currentTab) {
        scrollState.scrollTo(0)
    }

    val runtimePermLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions()
    ) {
        viewModel.checkSelfPermissions()
    }

    androidx.compose.runtime.LaunchedEffect(Unit) {
        try {
            val permsToRequest = mutableListOf<String>()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                if (context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    permsToRequest.add(android.Manifest.permission.POST_NOTIFICATIONS)
                }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (context.checkSelfPermission(android.Manifest.permission.BLUETOOTH_CONNECT) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    permsToRequest.add(android.Manifest.permission.BLUETOOTH_CONNECT)
                }
                if (context.checkSelfPermission(android.Manifest.permission.BLUETOOTH_SCAN) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    permsToRequest.add(android.Manifest.permission.BLUETOOTH_SCAN)
                }
            }
            if (context.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                permsToRequest.add(android.Manifest.permission.RECORD_AUDIO)
            }
            if (permsToRequest.isNotEmpty()) {
                runtimePermLauncher.launch(permsToRequest.toTypedArray())
            }
        } catch (_: Throwable) {}
    }

    BackHandler(enabled = uiState.currentTab != MainTab.SETUP) {
        viewModel.setTab(MainTab.SETUP)
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = MagicDarkBackground,
        contentWindowInsets = WindowInsets.safeDrawing
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Column(
                modifier = Modifier.fillMaxSize()
            ) {
                // Header Section (Single unified UI, v1.3 badge, explicit WLAN status & Global Search)
                if (uiState.currentTab != MainTab.CHAT_SUPPORT) {
                    HeaderSection(
                        deviceInfo = deviceInfo,
                        shellState = shellState,
                        currentTab = uiState.currentTab,
                        onTabSelected = { viewModel.setTab(it); viewModel.setGlobalSearchQuery("") },
                        onOpenRevertModal = { viewModel.setShowRevertModal(true) },
                        onOpenWlanDialog = { viewModel.setShowWlanDialog(true) },
                        onDisconnectWlan = { viewModel.disconnectSession() },
                        onRequestShizukuPermission = { viewModel.requestShizukuPermission() },
                        onOpenShizukuTab = { viewModel.setTab(MainTab.SHIZUKU) },
                        onOpenYouTube = { viewModel.openYouTubeChannel() },
                        onOpenPermissionDialog = { viewModel.setShowPermissionDialog(true) },
                        isPermissionFullyGranted = uiState.selfPermissionStatus.isFullyGranted,
                        globalSearchQuery = uiState.globalSearchQuery,
                        onGlobalSearchChange = { viewModel.setGlobalSearchQuery(it) },
                        onOpenChatSupport = { viewModel.setTab(MainTab.CHAT_SUPPORT) }
                    )
                }

                // Scrollable Content (MainTab.SHELL uses its own internal LazyColumn)
                val isShellTabActive = (uiState.currentTab == MainTab.SHELL || uiState.currentTab == MainTab.SHELL_TAB) &&
                    uiState.globalSearchQuery.isBlank() &&
                    (shellState.isAdbReady || uiState.currentTab != MainTab.SETUP)
                val isLazyColumnTab = uiState.currentTab == MainTab.APPS ||
                    uiState.currentTab == MainTab.SHELL ||
                    uiState.currentTab == MainTab.SHELL_TAB ||
                    uiState.currentTab == MainTab.ADMIN ||
                    uiState.currentTab == MainTab.LOGIN ||
                    uiState.currentTab == MainTab.ACCOUNT ||
                    uiState.currentTab == MainTab.APP_STORE ||
                    uiState.currentTab == MainTab.CHAT_SUPPORT ||
                    uiState.currentTab == MainTab.UNIVERSAL_TUNE ||
                    uiState.currentTab == MainTab.PRINTER
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .then(if (isLazyColumnTab) Modifier else Modifier.verticalScroll(scrollState))
                ) {
                    if (uiState.globalSearchQuery.isNotBlank()) {
                        // Global Instant Search View (Lọc trực tiếp ngay khi gõ từ khóa)
                        val q = androidx.compose.runtime.remember(uiState.globalSearchQuery) {
                            uiState.globalSearchQuery.trim().lowercase()
                        }
                        val catalog = androidx.compose.runtime.remember {
                            listOf(
                                SearchableActionItem("[Ô #22] Gọi Google Tìm Kiếm Bằng Giọng Nói (Voice Search) Bằng Phím Điều Hướng", "Nhấn giữ thanh điều hướng dưới đáy để gọi ngay trang Google Tìm Kiếm Bằng Giọng Nói (Google Voice Search), giữ nguyên khi tắt gỡ lỗi", "3. Làm Mượt (Ô #22)", "o 22,#22,22,search circle,khoanh tron,circle to search,voice search,giong noi,tim kiem giong noi,google,tim kiem,yoyo,dieu huong,phim dieu huong", "mod_circle_to_search"),
                                SearchableActionItem("[Ô #29] Mod Phím Điều Hướng Gọi Gemini Voice Trò Chuyện AI", "Đổi nhấn giữ YOYO thành gọi Gemini Voice AI trò chuyện trực tiếp, giữ nguyên khi tắt gỡ lỗi", "3. Làm Mượt (Ô #29)", "o 29,#29,29,gemini,gemini voice,tro chuyen ai,google,yoyo,dieu huong,voice", "mod_gemini_voice"),

                                SearchableActionItem("[Ô #29] Tăng độ nhạy vuốt đáy (Fix cường lực)", "Tăng độ nhạy cảm ứng & mở rộng vùng vuốt mép dưới", "3. Làm Mượt (Ô #29)", "o 29,#29,cam ung,do nhay,vuot day,cuong luc,gesture", "enhance_touch"),
                                SearchableActionItem("[Ô #23] Siêu Tiết Kiệm Pin (Zero Delay)", "Kích hoạt siêu tiết kiệm pin thông minh không trễ thông báo", "3. Làm Mượt (Ô #23)", "o 23,#23,23,tiet kiem pin,pin,battery,sieu tiet kiem,oled", "smart_battery"),
                                SearchableActionItem("[Ô #33B] Đặc trị lỗi Android Auto (Màn hình ô tô)", "Cấp full quyền, chống ngắt kết nối xe hơi", "3. Làm Mượt (Ô #33B)", "o 33,#33,33,android auto,xe hoi,oto,car,gearhead", "android_auto"),
                                SearchableActionItem("[Ô #32] Ép màn hình 120Hz / 144Hz", "Khóa tần số quét cao mượt mà không tụt FPS", "3. Làm Mượt (Ô #32)", "o 32,#32,32,120hz,144hz,tan so quet,man hinh,fps,muot", "refresh_rate"),
                                SearchableActionItem("[Ô #32] Tốc độ chuyển cảnh 0.5x", "Tăng tốc hoạt ảnh mở ứng dụng cực nhanh", "3. Làm Mượt (Ô #32)", "o 32,#32,32,animation,chuyen canh,0.5x,nhanh,toc do", "anim_scale"),
                                SearchableActionItem("[Ô #28] Chặn Quảng Cáo (AdBlocker Pro)", "Chặn quảng cáo toàn hệ thống qua Private DNS", "3. Làm Mượt (Ô #28)", "o 28,#28,28,quang cao,adblock,dns,chan qc", "adblock"),
                                SearchableActionItem("[Ô #09 & #30] Chặn Chợ App Honor Tự Cập Nhật", "Chặn tự động cài đè app tiếng Việt sang bản Trung", "1. Cài Máy (Ô #09) & 3. Làm Mượt (Ô #30)", "o 09,#09,09,o 30,#30,30,update,cho honor,cap nhat,appmarket,market", "block_update"),
                                SearchableActionItem("[Ô #10 & #14] Mở 100% Thông Báo & Phá Báo Nhẹ Nhàng", "Tắt PowerGenius, bật biểu ngữ nổi cho mọi app", "2. Chuông (Ô #14)", "o 10,#10,10,o 14,#14,14,thong bao,chuong,tin nhan,zalo,facebook,fcm,notif", "fix_notif"),
                                SearchableActionItem("[Ô #16] Cấp lại FCM Facebook không nổ chuông", "Sửa lỗi Facebook câm lặng, trễ thông báo", "2. Chuông (Ô #16)", "o 16,#16,16,facebook,chuong,fcm,no chuong", "fix_fb"),
                                SearchableActionItem("[Ô #17] Phá gom cụm 0s Gmail & Facebook", "Nhận mail và thông báo tức thì 0 giây trễ", "2. Chuông (Ô #17)", "o 17,#17,17,gmail,gom cum,0s,email,delay", "boost_gmail"),
                                SearchableActionItem("Gỡ App Rác Hệ Thống", "Đóng băng app tiếng Trung nội địa an toàn", "4. Gỡ App", "go app,xoa app,bloatware,app rac,hiboard", "debloat"),
                                SearchableActionItem("[Ô #01] 1-Chạm Thiết Lập Toàn Diện 8-trong-1", "Cài tiếng Việt, Google, GPS, phím Laban Key cho máy mới", "1. Cài Máy (Ô #01)", "o 01,#01,01,1,8 trong 1,cai moi,tieng viet,google,labankey,gps", "setup_master"),
                                SearchableActionItem("[Ô #40–#43] Kết Nối Không Dây Trực Tiếp (WLAN / Mã 6 Số)", "Kết nối trực tiếp độc lập siêu mượt (Khuyên dùng) hoặc kết nối dự phòng", "7. Kết Nối (Ô #40)", "o 40,#40,40,o 41,#41,41,adb,ket noi,wlan,wifi,ma 6 so,direct adb", "connect_shizuku"),
                                SearchableActionItem("[Ô #11] Máy In Nhiệt K80 (LAN / Wi-Fi)", "In đơn Shopee, TikTok, hóa đơn trực tiếp, tự động cắt giấy", "6. Máy In", "o 11,#11,11,in,may in,k80,in bill,shopee,tiktok,pdf,lan,wifi,cat giay", "printer_k80"),
                                SearchableActionItem("[Ô #35] Ẩn Nhà Phát Triển Mở Full Ngân Hàng & Game", "Vào mọi app Ngân hàng không bị báo lỗi bật Gỡ lỗi USB / Nhà phát triển", "3. Làm Mượt (Ô #35)", "o 35,#35,35,ngan hang,bank,nha phat trien,dev mode,stealth,an go loi", "stealth_dev_mode"),
                                SearchableActionItem("[Ô #36] Mở Khóa & Giải Nén Android/data & Android/obb", "Đọc, ghi, giải nén và truy cập trực tiếp thư mục bị hạn chế nghiêm ngặt trên Android 11–17", "3. Làm Mượt (Ô #36)", "o 36,#36,36,android data,obb,file he thong,giai nen,thu muc han che,saf", "restricted_storage"),
                                SearchableActionItem("[Ô #38] Kiểm Soát Quyền Riêng Tư Cảm Biến Cấp Độ Sâu", "Tinh chỉnh và ngắt quyền truy cập Camera, Micro, Vị trí GPS, Clipboard ở cấp hệ thống", "3. Làm Mượt (Ô #38)", "o 38,#38,38,quyen rieng tu,camera,micro,vi tri,gps,cam bien,clipboard,privacy", "deep_privacy"),
                                SearchableActionItem("[Ô #08 & #34] Đặc Trị Timestamp Camera & Định Vị GPS Honor (Fix Chụp Khu A Báo Khu B)", "Cấp đủ 100% quyền Timestamp Camera, tắt định vị Baidu/AMap lệch khu vực, xóa cache vị trí cũ & chuyển sang A-GPS Google", "1. Cài Máy (Ô #08) & 3. Làm Mượt (Ô #34)", "o 08,#08,08,8,o 34,#34,34,gps,dinh vi,lech vi tri,sai vi tri,timestamp,timestamp camera,chup anh,khu a,khu b,ban do,google maps,la ban,supl,grab", "fix_gps"),
                                SearchableActionItem("[Ô #02 & #26] Khôi Phục & Mở Cập Nhật Hệ Điều Hành MagicOS (OUC / HOTA)", "Bật lại tính năng cập nhật phần mềm hệ thống bị ẩn/mất và mở thẳng trang Cập nhật hệ điều hành", "1. Cài Máy (Ô #02) & 3. Làm Mượt (Ô #26)", "o 02,#02,02,2,o 26,#26,26,cap nhat,he dieu hanh,magicos,ouc,hota,ota,phan mem,system update,mat cap nhat", "fix_system_update"),
                                SearchableActionItem("[Ô #39] Tự Động Hóa & Gán Phím Cứng Hệ Thống", "Kịch bản hóa tác vụ hệ thống, mô phỏng thao tác và gán phím cứng thông minh", "3. Làm Mượt (Ô #39)", "o 39,#39,39,tu dong hoa,kich ban,macro,phim cung,dieu khien", "automation_macros")
                            )
                        }

                        val searchResults = androidx.compose.runtime.remember(q, catalog) {
                            catalog.filter { item ->
                                item.title.lowercase().contains(q) ||
                                item.description.lowercase().contains(q) ||
                                item.tag.lowercase().contains(q)
                            }
                        }

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "KẾT QUẢ TÌM KIẾM (${searchResults.size})",
                                    color = MagicCyan,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Black
                                )
                                Text(
                                    text = "Từ khóa: \"${uiState.globalSearchQuery}\"",
                                    color = TextMuted,
                                    fontSize = 11.sp
                                )
                            }

                            if (searchResults.isEmpty()) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(MagicSurfaceDark)
                                        .padding(24.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = TextMuted, modifier = Modifier.size(28.dp))
                                        Text(text = "Không tìm thấy tính năng nào phù hợp", color = TextSecondary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                        Text(text = "Hãy thử gõ: Cập nhật, Timestamp, GPS, 120Hz, Google, Thông báo...", color = TextMuted, fontSize = 11.sp)
                                    }
                                }
                            } else {
                                searchResults.forEach { action ->
                                    Card(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                when (action.actionType) {
                                                    "mod_circle_to_search" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.TUNE)
                                                        viewModel.modNavBarToCircleToSearch()
                                                    }
                                                    "mod_gemini_voice" -> {
                                                        if (context.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                                                            runtimePermLauncher.launch(arrayOf(android.Manifest.permission.RECORD_AUDIO))
                                                        }
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.TUNE)
                                                        viewModel.modNavBarToGeminiVoice()
                                                    }
                                                    "nav_gemini" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        try {
                                                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.google.android.apps.bard"))
                                                            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                                            context.startActivity(intent)
                                                        } catch (_: Exception) {}
                                                    }
                                                    "enhance_touch" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.TUNE)
                                                        viewModel.enhanceBottomGestureSensitivity()
                                                    }
                                                    "smart_battery" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.TUNE)
                                                        viewModel.applySmartBatterySaver()
                                                    }
                                                    "android_auto" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.TUNE)
                                                        viewModel.fixAndroidAuto()
                                                    }
                                                    "refresh_rate" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.TUNE)
                                                        viewModel.setRefreshRate(144)
                                                    }
                                                    "anim_scale" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.TUNE)
                                                        viewModel.setAnimationScale(0.5f)
                                                    }
                                                    "adblock" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.TUNE)
                                                        if (tuneStatus.isAdBlockerEnabled) viewModel.disableAdBlocker() else viewModel.enableAdBlocker()
                                                    }
                                                    "block_update" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.TUNE)
                                                        viewModel.blockHonorMarket()
                                                    }
                                                    "fix_notif" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.NOTIFICATIONS)
                                                        viewModel.fixAllNotifications()
                                                    }
                                                    "fix_fb" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.NOTIFICATIONS)
                                                        viewModel.fixFacebook()
                                                    }
                                                    "boost_gmail" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.NOTIFICATIONS)
                                                        viewModel.boostGmailAndFacebookBatching()
                                                    }
                                                    "debloat" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.APPS)
                                                    }
                                                    "setup_master" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.SETUP)
                                                        viewModel.runOneClickSetup()
                                                    }
                                                    "fix_gps" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.TUNE)
                                                        viewModel.setupGpsVietnam()
                                                    }
                                                    "fix_system_update" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.TUNE)
                                                        viewModel.fixMagicOSSystemUpdate()
                                                    }
                                                    "connect_shizuku" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.SHIZUKU)
                                                        viewModel.requestShizukuPermission()
                                                    }
                                                    "printer_k80" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.PRINTER)
                                                    }
                                                    "stealth_dev_mode" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.TUNE)
                                                        viewModel.enableStealthDeveloperModeBypass()
                                                    }
                                                    "restricted_storage" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.TUNE)
                                                        viewModel.unlockAndInspectRestrictedStorage()
                                                    }
                                                    "deep_privacy" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.TUNE)
                                                    }
                                                    "automation_macros" -> {
                                                        viewModel.setGlobalSearchQuery("")
                                                        viewModel.setTab(MainTab.TUNE)
                                                        viewModel.runSystemAutomationMacro("gaming_boost")
                                                    }
                                                }
                                            },
                                        shape = RoundedCornerShape(12.dp),
                                        colors = CardDefaults.cardColors(containerColor = MagicSurfaceDark),
                                        border = androidx.compose.foundation.BorderStroke(1.dp, MagicBorder)
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                                Text(
                                                    text = action.title,
                                                    color = Color.White,
                                                    fontSize = 13.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    lineHeight = 17.sp
                                                )
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Box(
                                                        modifier = Modifier
                                                            .clip(RoundedCornerShape(4.dp))
                                                            .background(MagicCyan.copy(alpha = 0.15f))
                                                            .border(0.5.dp, MagicCyan.copy(alpha = 0.35f), RoundedCornerShape(4.dp))
                                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                                    ) {
                                                        Text(
                                                            text = "📍 ${action.tab}",
                                                            color = MagicCyanLight,
                                                            fontSize = 9.5.sp,
                                                            fontWeight = FontWeight.Bold
                                                        )
                                                    }
                                                }
                                                Text(
                                                    text = action.description,
                                                    color = TextSecondary,
                                                    fontSize = 11.sp,
                                                    lineHeight = 15.sp
                                                )
                                            }
                                            Box(
                                                modifier = Modifier
                                                    .size(32.dp)
                                                    .clip(RoundedCornerShape(8.dp))
                                                    .background(MagicCyan),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, tint = Color(0xFF020617), modifier = Modifier.size(16.dp))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } else if (!shellState.isAdbReady && uiState.currentTab == MainTab.SETUP) {
                        ConnectionScreen(
                            shellState = shellState,
                            isBusy = false,
                            onRequestShizukuPermission = { viewModel.requestShizukuPermission() },
                            onOpenShizukuApp = { viewModel.openShizukuApp() },
                            onOpenDeveloperSettings = { viewModel.openDeveloperSettings() },
                            onOpenWlanDialog = { viewModel.setShowWlanDialog(true) }
                        )
                    } else {
                        when (uiState.currentTab) {
                            MainTab.SETUP -> {
                                SetupScreen(
                                    status = setupStatus,
                                    shizukuInfo = shizukuInfo,
                                    deviceInfo = deviceInfo,
                                    isBusy = false,
                                    onRunSetupAll = { viewModel.runOneClickSetup() },
                                    onRunSetupForceFull = { viewModel.runOneClickSetupForceFull() },
                                    onRunSingleSetupItem = { index ->
                                        when (index) {
                                            1 -> viewModel.setupVietnameseLanguage()
                                            2 -> viewModel.setupGoogleAndSync()
                                            3 -> viewModel.setupKeyboard()
                                            4 -> viewModel.fixCallerIdAndWifi()
                                            5 -> viewModel.cleanChineseUi()
                                            6 -> viewModel.setupGpsVietnam()
                                            7 -> viewModel.blockHonorMarket()
                                            8 -> viewModel.fixAllNotifications()
                                        }
                                    },
                                    onOpenPlayStore = { viewModel.openPlayStore(it) },
                                    onOpenYouTube = { viewModel.openYouTubeChannel() },
                                    onRefreshDeviceInfo = { viewModel.refreshAll() },
                                    onOpenPrinter = { viewModel.setTab(MainTab.PRINTER) },
                                    onRestartShizuku = { viewModel.startShizukuServerDirectly() },
                                    onRequestShizukuPermission = { viewModel.requestShizukuPermission() },
                                    onOpenShizukuApp = { viewModel.setTab(MainTab.SHIZUKU) },
                                    onOpenDirectWlanTab = { viewModel.setTab(MainTab.SHIZUKU) },
                                    onFixMagicOSSystemUpdate = { viewModel.fixMagicOSSystemUpdate() },
                                    onNavigateToUniversalFix = { viewModel.setTab(MainTab.UNIVERSAL_TUNE) }
                                )
                            }
                            MainTab.NOTIFICATIONS -> {
                                NotificationScreen(
                                    isBusy = false,
                                    diagnosticScan = diagnosticScan,
                                    floatingState = floatingState,
                                    onFixAllNotifications = { viewModel.fixNotificationSettingsOnly() },
                                    onBatchGrantPermissions = { viewModel.fixAppPermissionsOnly() },
                                    onRunDiagnosticScan = { viewModel.runDiagnosticScan() },
                                    onResetAndRescan = { viewModel.resetAndRescanNotifications() },
                                    onFixSingleApp = { pkg, name -> viewModel.fixSingleAppNotificationAndPerm(pkg, name) },
                                    onOpenAppNotificationSettings = { pkg -> viewModel.openAppNotificationSettings(pkg) },
                                    onOpenAppDetailsSettings = { pkg -> viewModel.openAppDetailsSettings(pkg) },
                                    onGrantSelfControlAndOverlay = { viewModel.grantSelfControlAndOverlayPermissions() },
                                    onRequestOverlaySettingIntent = { viewModel.openOverlayPermissionSettings() },
                                    onStartLiveFloatingAutomation = { viewModel.startLiveFloatingMiniWindowAutomation() },
                                    onEnterPipMode = onEnterPipMode,
                                    onFixFacebook = { viewModel.fixFacebook() },
                                    onBoostBatching = { viewModel.boostGmailAndFacebookBatching() },
                                    onPrioritizeCustomSounds = { viewModel.prioritizeAppCustomSounds() },
                                    onRemovePowerGenius = { viewModel.removePowerGenius() },
                                    onTestNotification = { pkg, name -> viewModel.testPushNotification(pkg, name) },
                                    isAutoWakeupEnabled = uiState.isAutoWakeupPatrolEnabled,
                                    onToggleAutoWakeup = { viewModel.toggleAutoWakeupPatrol(it) },
                                    isChargingNotificationEnabled = uiState.isChargingNotificationEnabled,
                                    onToggleChargingNotification = { viewModel.toggleChargingNotification(it) },
                                    isSearchNotificationEnabled = uiState.isSearchNotificationEnabled,
                                    onToggleSearchNotification = { viewModel.toggleSearchNotification(it) },
                                    onNavigateToUniversalFix = { viewModel.setTab(MainTab.UNIVERSAL_TUNE) }
                                )
                            }
                            MainTab.APPS -> {
                                AppsScreen(
                                    apps = appsList,
                                    searchQuery = uiState.searchQuery,
                                    selectedFilter = uiState.selectedAppLevelFilter,
                                    isBusy = false,
                                    onSearchChange = { viewModel.setSearchQuery(it) },
                                    onFilterChange = { viewModel.setAppLevelFilter(it) },
                                    onDebloatSafeApps = { viewModel.debloatSafeApps() },
                                    onGrantAllPermissions = { viewModel.grantAllPermissions() },
                                    onBlockAppMarketUpdates = { viewModel.blockHonorMarket() },
                                    onFixSingleAppNotificationAndPerm = { pkg, name ->
                                        viewModel.fixSingleAppNotificationAndPerm(pkg, name)
                                    },
                                    onFreezeApp = { pkg, freeze ->
                                        viewModel.freezeAppPackage(pkg, freeze)
                                    },
                                    onRevokeSensitivePermissions = { pkg ->
                                        viewModel.revokeSensitivePermissionsFromApp(pkg)
                                    },
                                    onUninstallApp = { viewModel.uninstallApp(it) },
                                    onRestoreApp = { viewModel.restoreApp(it) },
                                    onNavigateToUniversalFix = { viewModel.setTab(MainTab.UNIVERSAL_TUNE) },
                                    onRefreshApps = { viewModel.refreshAppsList() }
                                )
                            }
                            MainTab.TUNE -> {
                                TuneScreen(
                                    deviceInfo = deviceInfo,
                                    tuneStatus = tuneStatus,
                                    isBusy = false,
                                    onApplyMaxSettings = { viewModel.applyMaxSettings() },
                                    onApplySmartBatterySaver = { viewModel.applySmartBatterySaver() },
                                    onEnhanceGestureSensitivity = { viewModel.enhanceBottomGestureSensitivity() },
                                    onSetRefreshRate = { viewModel.setRefreshRate(it) },
                                    onSetAnimationScale = { viewModel.setAnimationScale(it) },
                                    onDisableYoyoWake = { viewModel.disableYoyoNavigationWake() },
                                    onRemapNavBarToGoogleAssistant = { viewModel.remapNavBarToGoogleAssistant() },
                                    onModCircleToSearch = {
                                        if (context.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                                            runtimePermLauncher.launch(arrayOf(android.Manifest.permission.RECORD_AUDIO))
                                        }
                                        viewModel.modNavBarToCircleToSearch()
                                    },
                                    onModGeminiVoice = {
                                        viewModel.toggleGeminiVoice()
                                    },
                                    onSetDefaultAssistant = {
                                        viewModel.setMagicTuneAsDefaultAssistant()
                                    },
                                    onTestTriggerNavAssistant = { viewModel.testTriggerNavAssistantNow() },
                                    onTestCircleToSearch = { viewModel.testCircleToSearchNow() },
                                    onRestoreYoyoOriginal = { viewModel.restoreYoyoOriginal() },
                                    onToggleNavigationBarPill = { viewModel.toggleNavigationBarPill(it) },
                                    onHideNavigationBar = { viewModel.hideNavigationBar() },
                                    onReplaceHonorSearch = { viewModel.replaceHonorSearch(it) },
                                    onBlockAppMarketUpdates = { viewModel.blockHonorMarket() },
                                    onUnblockAppMarketUpdates = { viewModel.unblockHonorMarket() },
                                    onApplyThermalCooling = { viewModel.applyThermalCooling() },
                                    isAutoCoolingEnabled = uiState.isAutoCoolingEnabled,
                                    onToggleAutoCooling = { viewModel.toggleAutoCooling(it) },
                                    onFixAudio = { viewModel.fixAudio() },
                                    onFixAndroidAuto = { viewModel.fixAndroidAuto() },
                                    onFixGps = { viewModel.setupGpsVietnam() },
                                    onRefreshSatellites = { viewModel.refreshGpsSatellites() },
                                    onSetFontLarge = { viewModel.setFontBoldLarge(it) },
                                    onSetDarkModeOled = { viewModel.setDarkModeOled(it) },
                                    onUnlockScreenshot = { viewModel.unlockSecureScreenshot() },
                                    onEnableAdBlocker = { viewModel.enableAdBlocker() },
                                    onDisableAdBlocker = { viewModel.disableAdBlocker() },
                                    onEnableStealthDevMode = { viewModel.enableStealthDeveloperModeBypass() },
                                    onRestoreDevModeVisibility = { viewModel.restoreDeveloperModeVisibility() },
                                    onFixMagicOSSystemUpdate = { viewModel.fixMagicOSSystemUpdate() },
                                    onUnlockRestrictedStorage = { viewModel.unlockAndInspectRestrictedStorage() },
                                    onExtractAndSyncRestrictedData = { viewModel.extractAndSyncRestrictedObbAndData() },
                                    onCleanRestrictedCaches = { viewModel.cleanRestrictedAppCaches() },
                                    onToggleDeepPrivacySensor = { sensor, block -> viewModel.toggleDeepPrivacySensor(sensor, block) },
                                    onRunAutomationMacro = { macro -> viewModel.runSystemAutomationMacro(macro) },
                                    onOpenAppsManagerTab = { viewModel.setTab(MainTab.APPS) },
                                    onOpenPlayStore = { viewModel.openPlayStore(it) },
                                    onRequestOverlaySettingIntent = { viewModel.openOverlayPermissionSettings() },
                                    onRefreshDeviceInfo = { viewModel.refreshAll() },
                                    onNavigateToUniversalFix = { viewModel.setTab(MainTab.UNIVERSAL_TUNE) }
                                )
                            }
                            MainTab.SHIZUKU -> {
                                ShizukuWlanScreen(
                                    shizukuInfo = shizukuInfo,
                                    shellState = shellState,
                                    logs = logs,
                                    isBusy = false,
                                    onRequestShizukuPermission = { viewModel.requestShizukuPermission() },
                                    onOpenShizukuApp = { viewModel.openShizukuApp() },
                                    onOpenDeveloperSettings = { viewModel.openDeveloperSettings() },
                                    onOpenWlanDialog = { viewModel.setShowWlanDialog(true) },
                                    onProtectShizuku = { viewModel.protectShizukuImmortal() },
                                    onAuthorizeCompanions = { viewModel.authorizeShizukuCompanions() },
                                    onTestShizukuDiagnostic = { viewModel.testShizukuDiagnostic() },
                                    onStartNotificationPairing = { viewModel.startNotificationPairingMode() },
                                    onStartShizukuDirectly = { viewModel.startShizukuServerDirectly() },
                                    onUnlockRestrictedSettings = { viewModel.unlockRestrictedSettingsAllApps() },
                                    onConnectWlanPort = { viewModel.connectWirelessAdb(it) },
                                    onRunShellCommand = { viewModel.runCustomShellCommand(it) },
                                    onForceResetShizuku = { viewModel.forceResetShizuku() }
                                )
                            }
                            MainTab.SHELL -> {
                                ShellRunnerScreen(
                                    logs = logs,
                                    isBusy = uiState.isBusy,
                                    onRunCommand = { viewModel.runCustomShellCommand(it) },
                                    onClearLogs = { viewModel.clearLogs() },
                                    onCancelOldCommands = { viewModel.cancelOldCommandsAndFreeTerminal() }
                                )
                            }
                            MainTab.SHELL_TAB -> {
                                ShellRunnerScreen(
                                    logs = logs,
                                    isBusy = uiState.isBusy,
                                    onRunCommand = { viewModel.runCustomShellCommand(it) },
                                    onClearLogs = { viewModel.clearLogs() },
                                    onCancelOldCommands = { viewModel.cancelOldCommandsAndFreeTerminal() }
                                )
                            }
                            MainTab.PRINTER -> {
                                ThermalPrinterScreen(
                                    sharedUri = uiState.sharedPrintUri,
                                    isPrinting = uiState.isPrinting,
                                    statusMessage = uiState.printStatusMessage,
                                    onSetPrinting = { viewModel.setIsPrinting(it) },
                                    onSetStatusMessage = { viewModel.setPrintStatusMessage(it) }
                                )
                            }
                            MainTab.LOGIN -> {
                                com.example.ui.components.LoginScreen(
                                    onNavigateBack = { viewModel.setTab(MainTab.SETUP) },
                                    onLoginSuccess = { viewModel.setTab(MainTab.ACCOUNT) },
                                    onNavigateToAccount = { viewModel.setTab(MainTab.ACCOUNT) }
                                )
                            }
                            MainTab.ADMIN -> {
                                com.example.ui.components.AdminManagementScreen(
                                    onNavigateBack = { viewModel.setTab(MainTab.SETUP) }
                                )
                            }
                            MainTab.ACCOUNT -> {
                                com.example.ui.components.AccountSettingsScreen(
                                    onNavigateBack = { viewModel.setTab(MainTab.SETUP) },
                                    onNavigateToLogin = { viewModel.setTab(MainTab.LOGIN) },
                                    onNavigateToChatSupport = { viewModel.setTab(MainTab.CHAT_SUPPORT) }
                                )
                            }
                            MainTab.APP_STORE -> {
                                com.example.ui.components.AppStoreScreen(
                                    onNavigateBack = { viewModel.setTab(MainTab.SETUP) }
                                )
                            }
                            MainTab.CHAT_SUPPORT -> {
                                com.example.ui.components.ChatSupportScreen(
                                    onNavigateBack = { viewModel.setTab(MainTab.ACCOUNT) }
                                )
                            }
                            MainTab.UNIVERSAL_TUNE -> {
                                com.example.ui.components.UniversalOemFixScreen(
                                    isBusy = uiState.isBusy,
                                    onBack = { viewModel.setTab(MainTab.SETUP) },
                                    onFixUniversalAll = { viewModel.applyUniversalOemNotificationFix() },
                                    onFixXiaomi = { viewModel.fixXiaomiMiuiNotificationLag() },
                                    onFixOppo = { viewModel.fixOppoRealmeNotificationLag() },
                                    onFixVivo = { viewModel.fixVivoIqooNotificationLag() },
                                    onFixHuawei = { viewModel.fixHuaweiHarmonyNotificationLag() }
                                )
                            }
                        }
                    }
                }
            }

            // Draggable Floating Mini Multi-Window Overlay (Live Visual Automation HUD)
            FloatingAutomationOverlay(
                state = floatingState,
                onMinimizeToggle = { viewModel.setFloatingMiniWindowMinimized(it) },
                onClose = { viewModel.setFloatingMiniWindowVisible(false) },
                onStartLiveAutomation = { viewModel.startLiveFloatingMiniWindowAutomation() },
                onEnterPipMultiWindow = onEnterPipMode,
                onOpenCurrentAppNotificationSettings = { viewModel.openAppNotificationSettings(it) },
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 96.dp)
            )

            // Sleek Edge-Docked Floating Button
            // CHỈ HIỂN THỊ NÚT NỔI TERMINAL CHO ADMIN ĐÃ ĐĂNG NHẬP (Bảo vệ bí mật công nghệ các chuỗi lệnh hệ thống)
            val isLiveAdmin = androidx.compose.runtime.remember(uiState.currentTab, com.example.core.auth.FirebaseAuthManager.getCurrentUser()?.uid) {
                com.example.core.auth.FirebaseAuthManager.getCurrentUser() != null &&
                        (com.example.core.auth.FirebaseAuthManager.isCurrentAdmin(context, null) ||
                                com.example.core.license.LicenseManager.isCurrentUserAdmin(context))
            }
            if (isLiveAdmin) {
                val errorCount = androidx.compose.runtime.remember(logs) { logs.count { it.type == LogType.ERROR } }
                EdgeDockedTerminalButton(
                    isScrolling = false,
                    errorCount = errorCount,
                    onClick = { viewModel.setShowTerminalBottomSheet(true) },
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(bottom = 24.dp)
                )
            }
        }
    }

    // Floating Terminal Dialog / BottomSheet
    if (uiState.showTerminalBottomSheet) {
        TerminalBottomSheet(
            logs = logs,
            onDismiss = { viewModel.setShowTerminalBottomSheet(false) },
            onClearLogs = { viewModel.clearLogs() },
            onRunCommand = { viewModel.runCustomShellCommand(it) },
            onCancelOldCommands = { viewModel.cancelOldCommandsAndFreeTerminal() }
        )
    }

    // Dialogs
    if (uiState.showWlanDialog) {
        WirelessAdbDialog(
            currentPort = shellState.wirelessAdbPort,
            isConnected = shellState.isWirelessAdbConnected,
            onDismiss = { viewModel.setShowWlanDialog(false) },
            onPair = { port, pin, callback -> viewModel.pairWirelessAdb(port, pin, callback) },
            onConnect = { viewModel.connectWirelessAdb(it) },
            onDisconnect = { viewModel.disconnectWirelessAdb() },
            onOpenDeveloperSettings = { viewModel.openDeveloperSettings() },
            onStartNotificationPairing = { viewModel.startNotificationPairingMode() }
        )
    }

    if (uiState.showRevertModal) {
        RevertModal(
            onDismiss = { viewModel.setShowRevertModal(false) },
            onConfirmRevert = { viewModel.restoreFactoryDefault() }
        )
    }

    if (uiState.showPermissionDialog) {
        SelfPermissionModal(
            status = uiState.selfPermissionStatus,
            isShizukuReady = shellState.isAdbReady || (shizukuInfo.isRunning && shizukuInfo.isPermissionGranted),
            onGrantAllViaShizuku = { viewModel.grantAllSelfPermissionsViaShell() },
            onRequestNotification = { AppPermissionChecker.requestNotificationPermission(context) },
            onRequestBattery = { AppPermissionChecker.requestIgnoreBatteryOptimizations(context) },
            onRequestOverlay = { AppPermissionChecker.requestOverlayPermission(context) },
            onRequestUsageStats = { AppPermissionChecker.requestUsageStatsPermission(context) },
            onRequestWriteSecure = {
                if (shellState.isAdbReady || (shizukuInfo.isRunning && shizukuInfo.isPermissionGranted)) {
                    viewModel.grantAllSelfPermissionsViaShell()
                } else {
                    viewModel.openShizukuApp()
                }
            },
            onOpenAppSettings = { AppPermissionChecker.openAppDetailsSettings(context) },
            onOpenHonorAppLaunch = { AppPermissionChecker.openHonorAppLaunchSettings(context) },
            onRepairHonor = { viewModel.repairHonorPermissions() },
            onOpenSpecialAccess = { viewModel.openSpecialAppAccess() },
            onDismiss = { viewModel.setShowPermissionDialog(false) }
        )
    }

    if (uiState.showUpgradeProDialog) {
        com.example.ui.components.UpgradeProRequiredDialog(
            reason = uiState.upgradeDialogReason,
            deviceId = com.example.core.license.LicenseManager.getDeviceId(context),
            onDismiss = { viewModel.setShowUpgradeProDialog(false) },
            onNavigateToAccount = {
                viewModel.setTab(com.example.ui.MainTab.ACCOUNT)
            }
        )
    }
}

