package com.example

import android.app.Application
import android.os.Handler
import android.os.Looper
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.SupervisorJob

/**
 * MagicTuneApplication: Lớp khởi tạo gốc của ứng dụng.
 * Thiết lập Global Uncaught Exception Handler & Main Looper Guard để bảo vệ ứng dụng
 * khỏi văng đột ngột (crash dialog) trên mọi phiên bản từ Android 8 đến Android 17 (API 37+).
 */
class MagicTuneApplication : Application() {

    override fun onCreate() {
        super.onCreate()

        // 1. Bảo vệ Main Looper an toàn tuyệt đối (Cockroach Crash Shield)
        // Bắt mọi ngoại lệ trên luồng chính để ngăn chặn văng hộp thoại "MagicTune keeps stopping"
        Handler(Looper.getMainLooper()).post {
            while (true) {
                try {
                    Looper.loop()
                } catch (t: Throwable) {
                    if (t is Error && t !is AssertionError) throw t
                    Log.e("MagicTuneApplication", "🚨 Shielded MainLooper exception: ${t.message}", t)
                }
            }
        }

        // 2. Bảo vệ các luồng nền (Coroutines, Socket, Binder, mDNS)
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            Log.e(
                "MagicTuneApplication",
                "🚨 Shielded uncaught exception on thread [${thread.name}]: ${throwable.message}",
                throwable
            )
        }

        // 3. Tự động khôi phục cầu nối Google Khoanh Tròn & Gemini Voice ngay khi tiến trình khởi tạo (kể cả sau khi khởi động lại máy hay tắt WLAN/ADB)
        try {
            com.example.core.service.SystemFloatingHudOverlay.syncNavBarBridge(applicationContext)
            com.example.core.service.MagicTuneKeepAliveService.startOrUpdate(
                applicationContext,
                "Đang duy trì Google Khoanh Tròn & Trò chuyện Gemini 24/7",
                forceFromBootOrOverlay = true
            )
        } catch (_: Throwable) {}

        // 4. Tự động khôi phục bản quyền Pro từ Cloud Firestore ngay khi mở app (trường hợp gỡ app cài lại)
        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.SupervisorJob() + kotlinx.coroutines.Dispatchers.IO).launch {
            try {
                com.example.core.license.LicenseManager.checkDeviceRecognizedProInCloud(applicationContext)
            } catch (_: Throwable) {}
        }
    }
}
