import http.server
import socketserver
import os

PORT = 3000
DIRECTORY = "/app/applet"

class ApkDownloadHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=DIRECTORY, **kwargs)

    def end_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
        super().end_headers()

    def do_GET(self):
        if self.path in ("/", "/index.html"):
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            
            apk_path = os.path.join(DIRECTORY, "MagicTune_v2.7.8_MOI_NHAT.apk")
            apk_size_mb = "38.7"
            if os.path.exists(apk_path):
                size_bytes = os.path.getsize(apk_path)
                apk_size_mb = f"{size_bytes / (1024 * 1024):.1f}"
            
            html = f"""<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Tải MagicTune_Tool v2.7.8 Mới Nhất</title>
</head>
<body style="font-family: sans-serif; text-align: center; padding: 50px;">
    <h1>MagicTune_Tool v2.7.8</h1>
    <a href="/MagicTune_v2.7.8_MOI_NHAT.apk" style="font-size: 20px; font-weight: bold; color: blue;">⚡ TẢI NGAY APK v2.7.8 ({apk_size_mb} MB)</a>
</body>
</html>"""
            self.wfile.write(html.encode("utf-8"))
            return

        elif self.path.endswith(".apk"):
            filepath = os.path.join(DIRECTORY, os.path.basename(self.path))
            if os.path.exists(filepath):
                self.send_response(200)
                self.send_header("Content-Type", "application/vnd.android.package-archive")
                self.send_header("Content-Disposition", f'attachment; filename="{os.path.basename(self.path)}"')
                self.send_header("Content-Length", str(os.path.getsize(filepath)))
                self.end_headers()
                with open(filepath, "rb") as f:
                    while chunk := f.read(1024 * 1024):
                        self.wfile.write(chunk)
                return

        super().do_GET()

if __name__ == "__main__":
    socketserver.TCPServer.allow_reuse_address = True
    with socketserver.TCPServer(("0.0.0.0", PORT), ApkDownloadHandler) as httpd:
        print(f"Apk Download Server running on port {PORT}...")
        httpd.serve_forever()
