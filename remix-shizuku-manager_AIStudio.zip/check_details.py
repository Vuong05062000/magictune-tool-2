import sys

with open('E:/remix-shizuku-manager/app/src/main/java/com/example/ui/components/TuneScreen.kt', 'r', encoding='utf-8') as f:
    lines = f.readlines()

out = []
for idx in [371, 390, 699, 867, 1199, 1291, 2213, 2837, 2968, 3099, 3316, 3960, 4023, 4610, 4843, 5086, 5101, 5256, 5549, 5940, 6127, 6534, 6849, 7118, 7143]:
    start = max(0, idx - 5)
    end = min(len(lines), idx + 20)
    out.append(f"--- AT LINE {idx} ---\n")
    for j in range(start, end):
        if any(w in lines[j] for w in ["// Ô", "// NHÓM", "Card(", "Text(", "title ="]):
            out.append(f"{j+1}: {lines[j].strip()}\n")

with open('E:/remix-shizuku-manager/card_details_out.txt', 'w', encoding='utf-8') as f:
    f.writelines(out)
print("Done writing card_details_out.txt")
