with open('E:/remix-shizuku-manager/app/src/main/java/com/example/ui/components/TuneScreen.kt', 'r', encoding='utf-8') as f:
    lines = f.readlines()

import re

# Look for defaultMinSize or fixed height on Buttons or Cards or Rows
print("=== FIXED HEIGHT ON BUTTONS / ROWS / BOXES ===")
for i, line in enumerate(lines):
    if re.search(r'\.height\([0-9]+\.dp\)', line):
        # check if it's Spacer
        prev = lines[i-1] if i > 0 else ""
        if "Spacer" not in prev and "Spacer" not in line and "Icon" not in prev and "Icon" not in line and "size" not in line:
            print(f"Line {i+1}: {line.strip()} (Context: {prev.strip()})")

