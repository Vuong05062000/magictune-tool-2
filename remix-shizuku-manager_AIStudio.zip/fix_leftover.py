with open('E:/remix-shizuku-manager/app/src/main/java/com/example/ui/components/TuneScreen.kt', 'r', encoding='utf-8') as f:
    lines = f.readlines()

# Lines around 1383 to 1398:
# We want to delete from 1384 (0-based 1383) to 1398 (0-based 1397)
# Let's inspect what lines 1383 to 1400 contain
print("Before:", repr(lines[1382])) # 1383
print("Start delete:", repr(lines[1383][:20]))
print("End delete:", repr(lines[1397][:20]))
print("After:", repr(lines[1398]))

# Replace lines 1383 to 1398 with nothing
new_lines = lines[:1383] + lines[1398:]

with open('E:/remix-shizuku-manager/app/src/main/java/com/example/ui/components/TuneScreen.kt', 'w', encoding='utf-8') as f:
    f.writelines(new_lines)

print("Replacement done successfully!")
