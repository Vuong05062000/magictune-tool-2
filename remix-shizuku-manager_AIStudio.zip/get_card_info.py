with open('E:/remix-shizuku-manager/app/src/main/java/com/example/ui/components/TuneScreen.kt', 'r', encoding='utf-8') as f:
    text = f.read()

lines = text.splitlines()

cards_info = []

for line_num in [371, 390, 699, 867, 1199, 1291, 2213, 2837, 2968, 3099, 3316, 3960, 4023, 4610, 4843, 5086, 5101, 5256, 5549, 5940, 6127, 6534, 6849, 7118, 7143]:
    # Look around line_num for title
    chunk = lines[max(0, line_num-5):min(len(lines), line_num+25)]
    badge = ""
    title = ""
    for c in chunk:
        if "Ô #" in c or "badgeText" in c:
            badge += c.strip() + " "
        if "text =" in c and ("BẬT" in c or "Mod" in c or "Max" in c or "Setting" in c or "Đặc trị" in c or "Chặn" in c or "Khôi phục" in c or "Ép" in c or "Tối ưu" in c):
            title += c.strip() + " "
    cards_info.append(f"Line {line_num}: badge=[{badge}] title=[{title[:60]}]\n")

with open('E:/remix-shizuku-manager/cards_info.txt', 'w', encoding='utf-8') as f:
    f.writelines(cards_info)

print("Done cards_info.txt")
