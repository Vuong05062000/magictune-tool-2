with open('E:/remix-shizuku-manager/app/src/main/java/com/example/ui/components/TuneScreen.kt', 'r', encoding='utf-8') as f:
    text = f.read()

lines = text.splitlines()

stack = []
for i, line in enumerate(lines):
    for char in line:
        if char == '{':
            stack.append((i+1, line.strip()))
        elif char == '}':
            if stack:
                stack.pop()
            else:
                print(f"Extra closing brace at {i+1}")

print(f"Remaining unclosed: {len(stack)}")
for s in stack:
    print(f"Unclosed opened at {s[0]}: {s[1][:40]}")
