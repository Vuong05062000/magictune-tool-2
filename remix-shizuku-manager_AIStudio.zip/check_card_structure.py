with open('E:/remix-shizuku-manager/app/src/main/java/com/example/ui/components/TuneScreen.kt', 'r', encoding='utf-8') as f:
    lines = f.readlines()

card_stack = []
for i, line in enumerate(lines):
    # check for Card(
    if "Card(" in line or "ProLicenseCard(" in line or "HonorGpsFixCard(" in line or "HardwareAndFeaturesCard(" in line:
        card_stack.append((i+1, line.strip()))
    # check for CollapsibleSectionHeader
    if "CollapsibleSectionHeader(" in line:
        card_stack.append((i+1, "HEADER: " + line.strip()))

out = [f"Line {c[0]}: {c[1]}\n" for c in card_stack]
with open('E:/remix-shizuku-manager/cards_structure.txt', 'w', encoding='utf-8') as f:
    f.writelines(out)

print(f"Total entries: {len(out)}")
