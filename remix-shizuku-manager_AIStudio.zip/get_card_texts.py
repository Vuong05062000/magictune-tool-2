with open('E:/remix-shizuku-manager/app/src/main/java/com/example/ui/components/TuneScreen.kt', 'r', encoding='utf-8') as f:
    lines = f.readlines()

cards = [371, 390, 699, 867, 1199, 1291, 2213, 2837, 2968, 3099, 3316, 3960, 4023, 4610, 4843, 5086, 5101, 5256, 5549, 5940, 6127, 6534, 6849, 7118, 7143]

res = []
for c in cards:
    block = lines[c-1:min(len(lines), c+35)]
    texts = [l.strip() for l in block if "Text(" in l or "text =" in l]
    res.append(f"Card at line {c}:\n" + "\n".join("  " + t for t in texts[:3]) + "\n")

with open('E:/remix-shizuku-manager/card_texts.txt', 'w', encoding='utf-8') as f:
    f.writelines(res)
print("Done card_texts.txt")
