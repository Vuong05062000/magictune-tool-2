with open('E:/remix-shizuku-manager/app/src/main/java/com/example/ui/components/TuneScreen.kt', 'r', encoding='utf-8') as f:
    lines = f.readlines()

stack = []
for i in range(378, 2200): # Group 1
    for char in lines[i]:
        if char == '{':
            stack.append((i+1, lines[i].strip()))
        elif char == '}':
            if stack:
                s_l, s_t = stack.pop()
                print(f"Brace from {s_l} closed at {i+1} [{s_t[:30]}]")
            else:
                print(f"Extra close at {i+1}")

print("Left:", len(stack))
for s in stack:
    print(s)
