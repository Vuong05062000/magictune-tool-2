with open('E:/remix-shizuku-manager/app/src/main/java/com/example/ui/components/TuneScreen.kt', 'r', encoding='utf-8') as f:
    lines = f.readlines()

# insert '}' at line 2182 (after line 2182)
lines.insert(2182, "        }\n")

with open('E:/remix-shizuku-manager/app/src/main/java/com/example/ui/components/TuneScreen.kt', 'w', encoding='utf-8') as f:
    f.writelines(lines)

print("Inserted closing brace for Group 1 CollapsibleSectionHeader!")
