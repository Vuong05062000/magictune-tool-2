with open('E:/remix-shizuku-manager/app/src/main/java/com/example/ui/components/TuneScreen.kt', 'r', encoding='utf-8') as f:
    lines = f.readlines()

cards = []
for i in range(3313, 7130):
    l = lines[i]
    if "Card(" in l or "HonorGpsFixCard(" in l or "HardwareAndFeaturesCard(" in l:
        cards.append((i+1, l.strip()))

out = [f"{c[0]}: {c[1]}\n" for c in cards]
with open('E:/remix-shizuku-manager/group3_list.txt', 'w', encoding='utf-8') as f:
    f.writelines(out)
print(f"Total cards in group 3: {len(cards)}")
