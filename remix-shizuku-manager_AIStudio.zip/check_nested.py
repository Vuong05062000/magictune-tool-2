with open('E:/remix-shizuku-manager/app/src/main/java/com/example/ui/components/TuneScreen.kt', 'r', encoding='utf-8') as f:
    lines = f.readlines()

def print_section(start_line, count=40):
    for idx in range(start_line - 1, min(len(lines), start_line - 1 + count)):
        line = lines[idx].rstrip()
        if any(keyword in line for keyword in ['Card(', 'Row(', 'Column(', 'Box(', 'Text(', 'title =', 'badgeText =', 'cardNumberBadge']):
            print(f"{idx+1:4d}: {line}")

print("=== CHECK GROUP 1 AROUND 1199 & 1291 ===")
print_section(1185, 30)
print("=== AROUND 1285 ===")
print_section(1285, 30)
