with open('E:/remix-shizuku-manager/app/src/main/java/com/example/ui/components/TuneScreen.kt', 'r', encoding='utf-8') as f:
    lines = f.readlines()

stack = []
for i in range(3313, 7130):
    line = lines[i]
    for char in line:
        if char == '{':
            stack.append((i+1, line.strip()))
        elif char == '}':
            if stack:
                start_l, start_t = stack.pop()
                if "Card(" in start_t:
                    print(f"Card opened at {start_l} -> closed at {i+1}")

print(f"Left unclosed in Nhóm 3: {len(stack)}")
for s in stack:
    print("Unclosed:", s)
