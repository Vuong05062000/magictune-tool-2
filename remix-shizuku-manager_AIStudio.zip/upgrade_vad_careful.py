path = r'E:\remix-shizuku-manager\app\src\main\java\com\example\core\widget\GeminiLiveFloatingOverlay.kt'

with open(path, 'r', encoding='utf-8') as f:
    lines = f.readlines()

start_idx = -1
end_idx = -1

for i, l in enumerate(lines):
    if 'val isSpeechCandidate = (rms > 14.0' in l:
        # Lùi lại tìm dòng trống hoặc comment phía trước
        start_idx = i - 1
        while start_idx > 0 and ('//' in lines[start_idx] or lines[start_idx].strip() == ''):
            start_idx -= 1
        start_idx += 1 # Bắt đầu từ comment đầu tiên của VAD
        break

if start_idx != -1:
    for j in range(start_idx, min(len(lines), start_idx + 180)):
        if 'preRollQueue.removeFirst()' in lines[j]:
            # Sau preRollQueue.removeFirst() có các dòng đóng ngoặc:
            # dòng } của while, sau đó là } của else
            for k in range(j + 1, min(len(lines), j + 25)):
                if lines[k].strip() == '}' and lines[k+2 if k+2 < len(lines) else k].strip().startswith('} else {'):
                    end_idx = k + 1
                    break
                elif lines[k].strip() == '}' and any('} else {' in lines[m] for m in range(k+1, min(len(lines), k+8))):
                    end_idx = k + 1
            break

print(f"Identified start_idx={start_idx+1}, end_idx={end_idx}")

new_code = """                    if (!hasDetectedSpeech) {
                        // 1. Giai đoạn lắng nghe câu mở đầu:
                        // Liên tục học mức tạp âm nền phòng (quạt gió, máy lạnh, tiếng ồn tĩnh)
                        if (rms < 35.0 && maxAbsSample < 180) {
                            ambientNoiseRms = (ambientNoiseRms * 0.85) + (rms * 0.15)
                        }

                        // Ngưỡng bắt đầu nói: Nhạy vừa đủ để bắt trọn từ đầu tiên, không bị kích hoạt bởi tiếng thở
                        val startSpeechThresholdRms = (ambientNoiseRms * 1.55).coerceIn(22.0, 40.0)
                        val isStartCandidate = (rms > startSpeechThresholdRms && maxAbsSample > 95) ||
                                (rms > 32.0 && maxAbsSample > 150)

                        if (isStartCandidate) {
                            speechFramesCount++
                            if (speechFramesCount >= 2) {
                                hasDetectedSpeech = true
                                firstSpeechTimestamp = now
                                lastSpeechTimestamp = now
                                // Đổ bộ đệm Pre-Roll (~450ms) để bảo toàn 100% từ đầu tiên của câu hỏi
                                while (preRollQueue.isNotEmpty()) {
                                    pcmOut.write(preRollQueue.removeFirst())
                                }
                            }
                        } else {
                            speechFramesCount = (speechFramesCount - 1).coerceAtLeast(0)
                        }

                        preRollQueue.addLast(frameBytes)
                        while (preRollQueue.size > 7) {
                            preRollQueue.removeFirst()
                        }
                    } else {
                        // 2. Giai đoạn người dùng đang nói:
                        pcmOut.write(frameBytes)

                        // Phân biệt chính xác giữa giọng nói thực tế và tiếng thở nhẹ / tiếng ồn sau khi dứt câu:
                        val ongoingSpeechThresholdRms = (ambientNoiseRms * 1.65).coerceIn(28.0, 48.0)
                        val isOngoingSpeech = (rms > ongoingSpeechThresholdRms && maxAbsSample > 140) ||
                                (rms > 42.0 && maxAbsSample > 200)

                        if (isOngoingSpeech) {
                            lastSpeechTimestamp = now
                        }

                        val silenceAfterSpeechMs = now - lastSpeechTimestamp
                        val totalSpeechWindowMs = now - firstSpeechTimestamp

                        // Tự động ngắt câu thông minh & dứt khoát:
                        // - Câu bình thường (> 450ms): Chỉ cần dứt lời im lặng 580ms là ngắt ngay lập tức!
                        // - Câu dài (> 1200ms): Người dùng đã nói xong trọn vẹn, chỉ cần 520ms im lặng là chốt và gửi xử lý!
                        val requiredSilenceMs = if (totalSpeechWindowMs > 1200L) 520L else 580L

                        if (totalSpeechWindowMs >= 400L && silenceAfterSpeechMs >= requiredSilenceMs) {
                            break
                        }
                    }
"""

if start_idx != -1 and end_idx != -1:
    patched = lines[:start_idx] + [new_code] + lines[end_idx:]
    with open(path, 'w', encoding='utf-8') as f:
        f.writelines(patched)
    print("SUCCESSFULLY APPLIED VAD UPGRADE")
else:
    print("COULD NOT FIND EXACT BOUNDARIES")
