import os
import glob

# Search in typical locations
files = glob.glob('C:/**/git.exe', recursive=True)
print("Git found:", files)
