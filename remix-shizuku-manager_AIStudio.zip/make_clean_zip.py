import os
import zipfile

project_root = r"E:\remix-shizuku-manager"
zip_path = r"E:\remix-shizuku-manager_AIStudio.zip"

# Folders to completely skip
EXCLUDE_DIRS = {
    ".gradle",
    "build",
    ".kotlin",
    ".idea",
    ".git",
    "scratch",
    "__pycache__"
}

# File extensions or specific files to exclude
EXCLUDE_FILES = {
    "MagicTune_v3.0.apk",
    "MagicTune_v3.1.apk",
    "server.log"
}

def should_exclude_dir(dirpath):
    parts = os.path.relpath(dirpath, project_root).split(os.sep)
    for p in parts:
        if p in EXCLUDE_DIRS:
            return True
        if p == "build": # skip app/build as well
            return True
    return False

def should_exclude_file(filename, relpath):
    if filename in EXCLUDE_FILES:
        return True
    if filename.endswith(".py") and filename not in ["server.py"]: # exclude temporary check python scripts
        return True
    if filename.endswith(".txt") and any(k in filename for k in ["card", "row", "check", "debug", "group"]):
        return True
    if filename.endswith(".apk"):
        return True
    return False

print(f"Creating zip at {zip_path}...")
count = 0
total_size = 0

with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for root, dirs, files in os.walk(project_root):
        # Filter dirs in-place to avoid recursing into excluded dirs
        dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS and d != "build"]
        
        if should_exclude_dir(root):
            continue
            
        for file in files:
            relpath = os.path.relpath(os.path.join(root, file), project_root)
            if should_exclude_file(file, relpath):
                continue
            
            filepath = os.path.join(root, file)
            zipf.write(filepath, relpath)
            count += 1
            total_size += os.path.getsize(filepath)

print(f"Successfully zipped {count} files.")
print(f"Total uncompressed size: {total_size / (1024*1024):.2f} MB")
print(f"Zip archive size: {os.path.getsize(zip_path) / (1024*1024):.2f} MB")
