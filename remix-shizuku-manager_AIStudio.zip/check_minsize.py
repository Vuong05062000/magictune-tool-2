with open('E:/remix-shizuku-manager/app/src/main/java/com/example/ui/components/TuneScreen.kt', 'r', encoding='utf-8') as f:
    lines = f.readlines()

print("Lines with defaultMinSize:")
for i, l in enumerate(lines):
    if "defaultMinSize" in l:
        print(f"Line {i+1}: {l.strip()}")
