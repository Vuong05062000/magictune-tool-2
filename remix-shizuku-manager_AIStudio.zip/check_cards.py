import re

with open('E:/remix-shizuku-manager/app/src/main/java/com/example/ui/components/TuneScreen.kt', 'r', encoding='utf-8') as f:
    lines = f.readlines()

print(f"Total lines: {len(lines)}")
# Find all Card, Row, Box, Spacer, etc.
cards = []
for i, l in enumerate(lines):
    if "Card(" in l:
        cards.append((i+1, l.strip()))

print(f"Total Cards in TuneScreen: {len(cards)}")
for c in cards:
    print(c)
