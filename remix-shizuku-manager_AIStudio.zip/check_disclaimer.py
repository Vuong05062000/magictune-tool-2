import glob

files = glob.glob('E:/remix-shizuku-manager/app/src/main/java/**/*.kt', recursive=True)
for f in files:
    with open(f, 'r', encoding='utf-8') as fl:
        text = fl.read()
        if 'HonorOptimizationDisclaimerFooter' in text:
            print(f"Found in: {f}")
