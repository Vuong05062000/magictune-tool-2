import glob

files = glob.glob('E:/remix-shizuku-manager/app/src/main/java/**/*.kt', recursive=True)
keywords = ['ngam', 'ngầm', 'đa năng', 'chuc nang ngam', 'universal', 'HonorOptimizationDisclaimerFooter']
for f in files:
    try:
        with open(f, 'r', encoding='utf-8') as fl:
            content = fl.read()
            for kw in ['ngầm', 'đa hãng', 'chức năng ngầm', 'HonorOptimizationDisclaimerFooter']:
                if kw in content:
                    print(f"Match '{kw}' in: {f}")
    except Exception as e:
        pass
