with open('E:/remix-shizuku-manager/app/src/main/java/com/example/ui/components/TuneScreen.kt', 'r', encoding='utf-8') as f:
    lines = f.readlines()

out = []
for i, line in enumerate(lines):
    if "Row(" in line:
        row_block = lines[i:i+30]
        row_text = "".join(row_block)
        texts = [l.strip() for l in row_block if "Text(" in l]
        weights = [l.strip() for l in row_block if "weight(" in l]
        if len(texts) >= 2 and len(weights) == 0 and "Spacer" not in row_text:
            out.append(f"Row at line {i+1} has {len(texts)} texts without weight\n")

with open('E:/remix-shizuku-manager/rows_out.txt', 'w', encoding='utf-8') as f:
    f.writelines(out)

print(f"Total problematic rows: {len(out)}")
