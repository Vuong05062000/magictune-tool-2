with open('E:/remix-shizuku-manager/app/src/main/java/com/example/ui/components/TuneScreen.kt', 'r', encoding='utf-8') as f:
    text = f.read()

lines = text.splitlines()

stack = []
for i, line in enumerate(lines):
    for char in line:
        if char == '{':
            stack.append(i+1)
        elif char == '}':
            if stack:
                start_l = stack.pop()
                if start_l in [386, 387, 2205, 2206, 2207, 3309, 3310, 3311, 7141, 7142]:
                    print(f"Brace opened at line {start_l} was closed at line {i+1}")
