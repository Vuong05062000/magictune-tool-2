import http.server
import socketserver
import os
import hashlib

PORT = 3000
DIRECTORY = "/app/applet"

class ApkDownloadHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=DIRECTORY, **kwargs)

    def end_headers(self):
        # Enable CORS and disable caching for fresh downloads
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
        super().end_headers()

    def do_GET(self):
        if self.path in ("/", "/index.html"):
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            
            apk_path = os.path.join(DIRECTORY, "MagicTune_v2.8_MOI_NHAT.apk")
            if not os.path.exists(apk_path):
                apk_path = os.path.join(DIRECTORY, "MagicTune_v2.7.9_MOI_NHAT.apk")
            apk_size_mb = "29.0"
            if os.path.exists(apk_path):
                size_bytes = os.path.getsize(apk_path)
                apk_size_mb = f"{size_bytes / (1024 * 1024):.1f}"
            
            html = f"""<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tải MagicTune_Tool v2.8 Mới Nhất</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{
            background: linear-gradient(135deg, #090d16 0%, #0f172a 50%, #1e1b4b 100%);
            color: #f1f5f9;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }}
        .card {{
            background: rgba(15, 23, 42, 0.85);
            backdrop-filter: blur(16px);
            border: 1px solid rgba(59, 130, 246, 0.3);
            border-radius: 24px;
            max-width: 520px;
            width: 100%;
            padding: 32px 24px;
            text-align: center;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.6), 0 0 40px rgba(59, 130, 246, 0.2);
        }}
        .badge {{
            display: inline-block;
            background: linear-gradient(90deg, #10b981, #059669);
            color: white;
            font-size: 12px;
            font-weight: 800;
            padding: 4px 12px;
            border-radius: 20px;
            letter-spacing: 0.5px;
            margin-bottom: 16px;
        }}
        h1 {{
            font-size: 26px;
            font-weight: 800;
            color: #ffffff;
            margin-bottom: 8px;
            letter-spacing: -0.5px;
        }}
        .subtitle {{
            font-size: 13.5px;
            color: #94a3b8;
            margin-bottom: 24px;
            line-height: 1.5;
        }}
        .features {{
            background: rgba(30, 41, 59, 0.6);
            border: 1px solid rgba(148, 163, 184, 0.15);
            border-radius: 16px;
            padding: 16px;
            text-align: left;
            margin-bottom: 24px;
            font-size: 13px;
            color: #cbd5e1;
            line-height: 1.6;
        }}
        .features li {{
            margin-bottom: 8px;
            list-style: none;
            display: flex;
            align-items: flex-start;
        }}
        .features li::before {{
            content: "✓";
            color: #10b981;
            font-weight: bold;
            margin-right: 8px;
        }}
        .btn {{
            display: flex;
            align-items: center;
            justify-content: center;
            width: 100%;
            background: linear-gradient(135deg, #2563eb 0%, #4f46e5 50%, #7c3aed 100%);
            color: white;
            text-decoration: none;
            font-size: 16px;
            font-weight: 700;
            padding: 16px 24px;
            border-radius: 16px;
            box-shadow: 0 10px 25px -5px rgba(79, 70, 229, 0.5);
            transition: all 0.2s ease;
            margin-bottom: 14px;
        }}
        .btn:hover {{
            transform: translateY(-2px);
            box-shadow: 0 15px 30px -5px rgba(79, 70, 229, 0.7);
        }}
        .file-info {{
            font-size: 12px;
            color: #64748b;
            margin-bottom: 20px;
        }}
        .guide {{
            border-top: 1px solid rgba(148, 163, 184, 0.15);
            padding-top: 18px;
            font-size: 12px;
            color: #94a3b8;
            text-align: left;
            line-height: 1.6;
        }}
        .guide strong {{
            color: #38bdf8;
        }}
    </style>
</head>
<body>
    <div class="card">
        <div class="badge">BẢN CHÍNH THỨC v2.8</div>
        <h1>MagicTune_Tool v2.8</h1>
        <p class="subtitle">Bộ công cụ Tối ưu Honor MagicOS & Android Chuyên Sâu<br>Hỗ trợ Gemini Voice Nổi & Khoanh Tròn Tìm Kiếm</p>
        
        <div class="features">
            <ul>
                <li><strong>Cử chỉ vuốt dọc 1mm siêu nhạy:</strong> Không che thanh dock hay nội dung, vuốt cực nhạy bắt cảm ứng tức thì.</li>
                <li><strong>Trò chuyện liền mạch với Gemini:</strong> Tự động bật lại Micro sau mỗi câu nói để trò chuyện liên tục không cần bấm nút.</li>
                <li><strong>Chế độ Admin Preview:</strong> Cho phép admin tạm ẩn trạng thái Pro để trải nghiệm góc nhìn chưa có Pro dễ dàng.</li>
            </ul>
        </div>

        <a href="/MagicTune_v2.8_MOI_NHAT.apk" class="btn" download="MagicTune_v2.8_MOI_NHAT.apk">
            ⚡ TẢI NGAY APK v2.8 ({apk_size_mb} MB)
        </a>

        <div class="file-info">
            Tên tệp: <strong>MagicTune_v2.8_MOI_NHAT.apk</strong> • Dung lượng: <strong>{apk_size_mb} MB</strong> (Chuẩn v2.8, tối ưu pin & hiệu năng)
        </div>

        <div class="guide">
            <strong>💡 Hướng dẫn cài đặt:</strong><br>
            1. Bấm nút <strong>TẢI NGAY APK</strong> ở trên để tải trực tiếp file về máy.<br>
            2. Mở file APK vừa tải và chọn <strong>Cài đặt</strong> (hoặc Cập nhật đè lên bản cũ).<br>
            3. Vào ứng dụng để trải nghiệm cử chỉ vuốt dọc mới và trò chuyện Gemini liền mạch!
        </div>
    </div>
</body>
</html>"""
            self.wfile.write(html.encode("utf-8"))
            return

        elif self.path.endswith(".apk") or "MagicTune" in self.path:
            # Ensure correct mime type and headers for APK download
            filename = os.path.basename(self.path)
            if not filename.endswith(".apk"):
                filename = "MagicTune_v2.8_MOI_NHAT.apk"
            filepath = os.path.join(DIRECTORY, filename)
            if not os.path.exists(filepath):
                filepath = os.path.join(DIRECTORY, "MagicTune_v2.8_MOI_NHAT.apk")
            if os.path.exists(filepath):
                self.send_response(200)
                self.send_header("Content-Type", "application/vnd.android.package-archive")
                self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
                self.send_header("Content-Length", str(os.path.getsize(filepath)))
                self.end_headers()
                with open(filepath, "rb") as f:
                    while chunk := f.read(1024 * 1024):
                        self.wfile.write(chunk)
                return

        super().do_GET()

if __name__ == "__main__":
    socketserver.TCPServer.allow_reuse_address = True
    with socketserver.TCPServer(("0.0.0.0", PORT), ApkDownloadHandler) as httpd:
        print(f"Apk Download Server running on port {PORT}...")
        httpd.serve_forever()
